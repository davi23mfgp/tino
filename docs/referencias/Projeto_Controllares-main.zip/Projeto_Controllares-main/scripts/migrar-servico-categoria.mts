/**
 * Move o serviço de categoria para dentro do preço dos produtos daquela
 * categoria, nas propostas montadas antes dessa regra existir.
 *
 * Simulação (não grava nada):  npx tsx scripts/migrar-servico-categoria.mts
 * Gravando:                    npx tsx scripts/migrar-servico-categoria.mts --aplicar
 *
 * POR QUE
 *
 * Serviço cadastrado numa categoria deixou de virar linha na proposta: ele
 * entra no preço de cada produto daquela categoria. Proposta montada antes
 * disso tem o serviço como linha e o produto com o preço "limpo" — os dois
 * modelos convivendo.
 *
 * Conviver seria tolerável se ninguém editasse as antigas. Mas ao acrescentar
 * um produto da categoria numa proposta antiga, o item novo nasce com o
 * percentual já dentro do preço E a linha antiga cobra sobre a categoria
 * inteira, incluindo ele. O mesmo serviço, duas vezes. Este script acaba com a
 * convivência.
 *
 * O QUE MUDA E O QUE NÃO MUDA
 *
 *   muda   valor_unitario e valor_total dos itens da categoria
 *   muda   valor_servico da proposta (cai exatamente o que foi diluído)
 *   muda   servicos_detalhe (a linha de categoria sai)
 *   NÃO    valor_total da proposta — é o número combinado com o cliente
 *
 * Serviço SEM categoria não é tocado: projeto, instalação e administração
 * incidem sobre a proposta inteira e continuam sendo linha, com nome. Como o
 * total de produtos mais serviços não muda, o percentual deles dá o mesmo
 * valor de antes.
 *
 * O script confere isso item a item e RECUSA gravar a proposta se o total
 * fechar diferente de mais ou menos um centavo. Migração de dinheiro que não
 * fecha não é migração, é prejuízo.
 *
 * Antes de gravar, salva o estado atual de tudo que vai mexer em
 * pesquisa/BACKUP-migracao-servico-categoria-<carimbo>.json.
 */
import { PrismaClient, Prisma } from "@prisma/client"
import { writeFileSync, mkdirSync } from "fs"

const APLICAR = process.argv.includes("--aplicar")
const prisma = new PrismaClient()

const brl = (v: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" })
    .format(v || 0).replace(/\u00A0/g, " ")
const cent = (v: number) => Math.round(v * 100) / 100

type ServicoJson = {
  nome?: string; tipo?: string; valor?: string | number
  environmentId?: string | null; categoryId?: string | null
}

const propostas = await prisma.proposal.findMany({
  where: { servicos_detalhe: { not: Prisma.DbNull } },
  select: {
    id: true, numero: true, status: true,
    valor_total: true, valor_servico: true, desconto_aplicado: true,
    servicos_detalhe: true,
    environments: {
      where: { status: "ATIVO" },
      select: {
        proposalItems: {
          select: {
            id: true, quantidade: true, valor_unitario: true, valor_total: true,
            categoryId: true, nome_snapshot: true,
            product: { select: { nome: true, categoryId: true } },
            kit: { select: { nome: true } },
          },
        },
      },
    },
  },
  orderBy: { createdAt: "desc" },
})

const alvos = propostas.filter(p =>
  Array.isArray(p.servicos_detalhe)
  && (p.servicos_detalhe as unknown as ServicoJson[]).some(s => s?.categoryId))

console.log(`propostas com serviço de categoria: ${alvos.length} de ${propostas.length}\n`)

type Escrita = {
  propostaId: string
  numero: string
  itens: { id: string; unit: number; total: number }[]
  valor_servico: number
  servicos: ServicoJson[]
}
const escritas: Escrita[] = []
const recusadas: string[] = []

for (const p of alvos) {
  console.log("=".repeat(76))
  console.log(`${p.numero}  [${p.status}]   total ${brl(Number(p.valor_total))}`)

  const itens = p.environments.flatMap(e => e.proposalItems).map(i => ({
    id: i.id,
    nome: i.nome_snapshot ?? i.product?.nome ?? i.kit?.nome ?? "Item",
    quantidade: i.quantidade,
    unit: Number(i.valor_unitario),
    total: Number(i.valor_total),
    cat: i.categoryId ?? i.product?.categoryId ?? null,
  }))

  const servicos = p.servicos_detalhe as unknown as ServicoJson[]
  const deCategoria = servicos.filter(s => s?.categoryId)
  const ficam = servicos.filter(s => !s?.categoryId)

  const acrescimo = new Map<string, number>()
  let diluido = 0
  let impossivel = false

  for (const s of deCategoria) {
    const alvo = itens.filter(i => i.cat === s.categoryId)
    const v = parseFloat(String(s.valor ?? "").replace(",", ".")) || 0
    const base = alvo.reduce((t, i) => t + i.total, 0)
    const valor = s.tipo === "percentual" ? base * v / 100 : v

    console.log(`\n  "${s.nome}"  ${s.tipo === "percentual" ? v + "%" : brl(v)}  sobre ${brl(base)}  =  ${brl(valor)}`)

    /* Categoria sem produto na proposta: não há onde diluir. Apagar a linha
       aqui sumiria com o valor. A proposta inteira fica de fora. */
    if (!alvo.length) {
      console.log("    SEM PRODUTO DESSA CATEGORIA — proposta fica de fora")
      impossivel = true
      continue
    }

    diluido += valor
    for (const i of alvo) {
      /* Percentual: cada item sobe a mesma porcentagem, que dá o mesmo que
         aplicar sobre a soma. Fixo: o valor da categoria entra em cada item,
         que é como a regra foi definida. */
      const add = s.tipo === "percentual" ? i.total * v / 100 : v * i.quantidade
      acrescimo.set(i.id, (acrescimo.get(i.id) ?? 0) + add)
    }
  }

  if (impossivel) { recusadas.push(`${p.numero}: categoria sem produto na proposta`); continue }

  const novos = itens.map(i => {
    const add = acrescimo.get(i.id) ?? 0
    const total = cent(i.total + add)
    return { id: i.id, nome: i.nome, quantidade: i.quantidade, antes: i.total, total, unit: cent(total / Math.max(1, i.quantidade)), mudou: add > 0 }
  })

  console.log("\n  itens:")
  for (const n of novos) {
    console.log(`    ${n.nome.slice(0, 36).padEnd(36)} ${brl(n.antes).padStart(14)} -> ${brl(n.total).padStart(14)}${n.mudou ? "  <<<" : ""}`)
  }

  const produtosDepois = novos.reduce((t, n) => t + n.total, 0)
  const servicoDepois = cent(Number(p.valor_servico) - diluido)
  const desc = Number(p.desconto_aplicado ?? 0)
  const totalDepois = cent((produtosDepois + servicoDepois) * (1 - desc / 100))
  const totalAntes = Number(p.valor_total)
  const dif = cent(totalDepois - totalAntes)

  console.log(`\n  serviço ${brl(Number(p.valor_servico))} -> ${brl(servicoDepois)}   linhas ${servicos.length} -> ${ficam.length}`)
  console.log(`  TOTAL   ${brl(totalAntes)} -> ${brl(totalDepois)}   diferença ${brl(dif)}`)

  /* A trava. O total é o número combinado com o cliente: se ele se move, a
     migração está errada e gravar seria pior que não migrar. */
  if (Math.abs(dif) > 0.01) {
    console.log("  RECUSADO: o total não fecha.")
    recusadas.push(`${p.numero}: total fecharia ${brl(dif)} diferente`)
    continue
  }

  escritas.push({
    propostaId: p.id,
    numero: p.numero,
    itens: novos.filter(n => n.mudou).map(n => ({ id: n.id, unit: n.unit, total: n.total })),
    valor_servico: servicoDepois,
    servicos: ficam,
  })
}

console.log("\n" + "=".repeat(76))
console.log(`${escritas.length} proposta(s) prontas para gravar.`)
if (recusadas.length) {
  console.log(`${recusadas.length} recusada(s):`)
  for (const r of recusadas) console.log("  " + r)
}

if (!APLICAR) {
  console.log("\nSimulação. Nada foi gravado. Use --aplicar para valer.")
  await prisma.$disconnect()
  process.exit(0)
}

const carimbo = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")
mkdirSync("pesquisa", { recursive: true })
writeFileSync(
  `pesquisa/BACKUP-migracao-servico-categoria-${carimbo}.json`,
  JSON.stringify(alvos.filter(a => escritas.some(e => e.propostaId === a.id)), null, 2),
)

for (const e of escritas) {
  /* Tudo de uma proposta numa transação só: item com preço novo e proposta com
     serviço velho é uma proposta que não fecha consigo mesma. */
  await prisma.$transaction([
    ...e.itens.map(i => prisma.proposalItem.update({
      where: { id: i.id },
      data: { valor_unitario: i.unit, valor_total: i.total },
    })),
    prisma.proposal.update({
      where: { id: e.propostaId },
      data: {
        valor_servico: e.valor_servico,
        servicos_detalhe: e.servicos as unknown as Prisma.InputJsonValue,
      },
    }),
  ])
  console.log(`gravado: ${e.numero}  (${e.itens.length} itens)`)
}

console.log(`\n${escritas.length} proposta(s) migradas.`)
await prisma.$disconnect()
