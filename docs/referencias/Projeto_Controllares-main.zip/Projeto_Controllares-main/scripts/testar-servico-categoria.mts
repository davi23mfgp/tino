/**
 * Prova a diluição do serviço de categoria no preço dos produtos.
 *
 *   npx tsx scripts/testar-servico-categoria.mts
 *
 * Duas coisas precisam valer sempre, e é por elas que a proposta fecha consigo
 * mesma:
 *
 *   1. A soma do que foi distribuído é EXATAMENTE o valor do serviço. Um
 *      centavo perdido aqui aparece como diferença no rodapé da proposta.
 *   2. No caso percentual, cada produto da categoria sobe exatamente a mesma
 *      porcentagem — que é como o dono descreveu a regra. Produto de outra
 *      categoria não é tocado.
 */
import { diluirServicosDeCategoria, valorDoServico, type ItemParaServico, type ServicoProposta } from "../src/lib/servicos-proposta"

let falhas = 0
const cent = (v: number) => Math.round(v * 100) / 100

function conferir(nome: string, condicao: boolean, detalhe = "") {
  if (condicao) { console.log(`  ok  ${nome}`) }
  else { falhas++; console.log(`  XX  ${nome}${detalhe ? "\n      " + detalhe : ""}`) }
}

/* ── O exemplo do dono ──────────────────────────────────────────────── */
console.log("\n30% na categoria Control4, com 2 produtos Control4 e 1 de fora")

const C4 = "cat-control4"
const OUTRA = "cat-outra"
const itens: ItemParaServico[] = [
  { environmentId: "amb1", categoryId: C4, valor_total: 6442.80 },
  { environmentId: "amb1", categoryId: C4, valor_total: 7712.25 },
  { environmentId: "amb1", categoryId: OUTRA, valor_total: 197.44 },
]
const servicos: ServicoProposta[] = [
  { nome: "Serviço Control4", tipo: "percentual", valor: "30", categoryId: C4, origem: "categoria" },
]

const r = diluirServicosDeCategoria(servicos, itens)
const baseC4 = 6442.80 + 7712.25
/* O esperado sai da PRÓPRIA lib, não de uma conta paralela aqui: dinheiro
   vive em centavos, e duas contas em ponto flutuante do mesmo número podem
   cair em centavos diferentes. Comparar a lib com ela mesma é o que testa a
   distribuição; comparar com uma segunda conta testa o ponto flutuante. */
const esperado = cent(valorDoServico(servicos[0], itens))

console.log(`  base Control4 = ${baseC4.toFixed(2)}   serviço 30% = ${esperado.toFixed(2)}`)
itens.forEach((it, i) => {
  const pct = it.valor_total ? (r.acrescimoPorItem[i] / it.valor_total) * 100 : 0
  console.log(`    item ${i} (${it.categoryId === C4 ? "Control4" : "outra  "}) ${it.valor_total.toFixed(2)} + ${r.acrescimoPorItem[i].toFixed(2)} = ${(it.valor_total + r.acrescimoPorItem[i]).toFixed(2)}  (+${pct.toFixed(4)}%)`)
})

conferir("o produto de outra categoria não é tocado", r.acrescimoPorItem[2] === 0)
conferir("a soma distribuída é exatamente o valor do serviço",
  cent(r.acrescimoPorItem.reduce((a, b) => a + b, 0)) === esperado,
  `somou ${cent(r.acrescimoPorItem.reduce((a, b) => a + b, 0))}, esperado ${esperado}`)
conferir("cada Control4 sobe 30% cravado",
  // Um centavo de tolerância: abaixo disso não existe dinheiro.
  Math.abs(r.acrescimoPorItem[0] - itens[0].valor_total * 0.30) <= 0.01 &&
  Math.abs(r.acrescimoPorItem[1] - itens[1].valor_total * 0.30) <= 0.01)
conferir("o serviço sai da lista de linhas", r.diluidos.length === 1 && r.restantes.length === 0)

/* ── Valor fixo ─────────────────────────────────────────────────────── */
console.log("\nValor fixo de R$ 1.000 na categoria")
const fixo = diluirServicosDeCategoria(
  [{ nome: "Setup", tipo: "fixo", valor: 1000, categoryId: C4, origem: "categoria" }], itens)
itens.forEach((it, i) => console.log(`    item ${i} + ${fixo.acrescimoPorItem[i].toFixed(2)}`))
conferir("soma dá exatamente 1000",
  cent(fixo.acrescimoPorItem.reduce((a, b) => a + b, 0)) === 1000)
conferir("proporcional ao valor de cada um",
  Math.abs(fixo.acrescimoPorItem[0] - 1000 * (6442.80 / 14155.05)) <= 0.01)
conferir("não pinga em produto de outra categoria", fixo.acrescimoPorItem[2] === 0)

/* ── O que NÃO deve ser diluído ─────────────────────────────────────── */
console.log("\nServiço escrito à mão continua sendo linha")
const manual = diluirServicosDeCategoria(
  [{ nome: "Projeto", tipo: "percentual", valor: "10", categoryId: C4, origem: "manual" }], itens)
conferir("projeto amarrado a categoria NÃO some",
  manual.restantes.length === 1 && manual.acrescimoPorItem.every(v => v === 0))

const semOrigem = diluirServicosDeCategoria(
  [{ nome: "Instalação", tipo: "fixo", valor: 500, categoryId: C4 }], itens)
conferir("serviço antigo, sem a marca de origem, NÃO some",
  semOrigem.restantes.length === 1 && semOrigem.acrescimoPorItem.every(v => v === 0))

/* ── Dinheiro não pode evaporar ─────────────────────────────────────── */
console.log("\nCategoria sem produto na proposta")
const orfao = diluirServicosDeCategoria(
  [{ nome: "Serviço X", tipo: "fixo", valor: 300, categoryId: "cat-inexistente", origem: "categoria" }], itens)
conferir("vira linha em vez de sumir com o valor",
  orfao.restantes.length === 1 && orfao.acrescimoPorItem.every(v => v === 0))

/* ── Arredondamento feio de propósito ───────────────────────────────── */
console.log("\nTrês itens que não dividem redondo")
const tres: ItemParaServico[] = [
  { environmentId: "a", categoryId: C4, valor_total: 10 },
  { environmentId: "a", categoryId: C4, valor_total: 10 },
  { environmentId: "a", categoryId: C4, valor_total: 10 },
]
const r3 = diluirServicosDeCategoria(
  [{ nome: "S", tipo: "fixo", valor: 10, categoryId: C4, origem: "categoria" }], tres)
console.log(`    ${r3.acrescimoPorItem.map(v => v.toFixed(2)).join(" + ")} = ${cent(r3.acrescimoPorItem.reduce((a, b) => a + b, 0)).toFixed(2)}`)
conferir("R$ 10 em três partes ainda soma 10",
  cent(r3.acrescimoPorItem.reduce((a, b) => a + b, 0)) === 10)

console.log(falhas === 0 ? "\nTudo certo.\n" : `\n${falhas} falha(s).\n`)
process.exit(falhas === 0 ? 0 : 1)
