// Varredura: tira travessão de texto visível na tela (prosa, labels, opções),
// sem mexer em comentários de código (// e /* */) nem no "—" isolado usado
// como marcador de valor vazio (ex.: placeholder="—", célula sem dado) — esse
// é convenção de "sem dado", não estilo de escrita.
import fs from "node:fs"
import { execSync } from "node:child_process"

const arquivos = execSync('git ls-files "src/app/**/*.tsx" "src/components/**/*.tsx"', { cwd: process.cwd(), encoding: "utf8" })
  .split("\n").filter(Boolean)

let totalTrocas = 0
const tocados = []

for (const rel of arquivos) {
  const original = fs.readFileSync(rel, "utf8")
  const linhas = original.split("\n")

  // Marca quais linhas estão (total ou parcialmente) dentro de comentário de bloco.
  let dentroBloco = false
  const inicioBloco = linhas.map(l => {
    const antes = dentroBloco
    if (dentroBloco) {
      if (l.includes("*/")) dentroBloco = false
    } else if (l.includes("/*") && !l.includes("*/")) {
      dentroBloco = true
    } else if (l.trim().startsWith("/*") && l.includes("*/")) {
      // linha de bloco de uma linha só, ex: /* nota */
    }
    return antes
  })

  let trocasArquivo = 0
  const novasLinhas = linhas.map((linha, i) => {
    // Ignora linha totalmente dentro de bloco de comentário, ou que é comentário puro.
    const semEspacos = linha.trim()
    if (inicioBloco[i]) return linha
    if (semEspacos.startsWith("//") || semEspacos.startsWith("*") || semEspacos.startsWith("/*")) return linha

    // Corta fora comentário de linha (// até o fim) antes de mexer, mas preserva
    // ele na saída sem alteração.
    const idxComentario = linha.indexOf("//")
    const codigo = idxComentario >= 0 ? linha.slice(0, idxComentario) : linha
    const resto = idxComentario >= 0 ? linha.slice(idxComentario) : ""

    if (!codigo.includes("—")) return linha

    let nova = codigo

    // "— Palavra —" (bloco decorativo em option/placeholder) → "Palavra", sem
    // travessão. Ex.: "— Ninguém —" → "Ninguém".
    nova = nova.replace(/—\s*([^—"'<>]{1,60}?)\s*—/g, "$1")

    // "algo — algo" no meio de frase (com letra de cada lado) → vírgula.
    nova = nova.replace(/(\S)\s+—\s+(\S)/g, "$1, $2")

    if (nova !== codigo) trocasArquivo++
    return nova + resto
  })

  if (trocasArquivo > 0) {
    fs.writeFileSync(rel, novasLinhas.join("\n"))
    totalTrocas += trocasArquivo
    tocados.push(`${rel} (${trocasArquivo})`)
  }
}

console.log(`Trocas: ${totalTrocas} em ${tocados.length} arquivos`)
tocados.forEach(t => console.log(" -", t))
