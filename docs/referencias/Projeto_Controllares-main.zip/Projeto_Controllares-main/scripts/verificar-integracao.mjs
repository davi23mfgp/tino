/**
 * Verificação de integração das mudanças novas, contra o banco de verdade.
 *
 * Tudo roda dentro de uma transação que termina em rollback: nenhum registro
 * sobrevive ao teste. É o que permite exercitar o schema real (colunas novas,
 * chaves estrangeiras, cascade) sem sujar dado de produção — e sem depender de
 * login, que é o que hoje impede o teste pela tela.
 */
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()
const falhas = []
const ok = (nome, cond) => {
  console.log(`${cond ? "  ok  " : "FALHA "} ${nome}`)
  if (!cond) falhas.push(nome)
}

class Rollback extends Error {}

try {
  await prisma.$transaction(async tx => {
    const company = await tx.company.findFirst({ select: { id: true } })
    if (!company) throw new Error("Sem empresa no banco para testar")
    const vendedor = await tx.user.findFirst({ where: { companyId: company.id }, select: { id: true } })
    if (!vendedor) throw new Error("Sem usuario no banco para testar")

    // ── 1. Projetos por lead ──────────────────────────────────────────────
    const lead = await tx.lead.create({
      data: { companyId: company.id, nome: "TESTE ROLLBACK", email: "t@t.t", status: "QUALIFICADO" },
    })
    const projA = await tx.leadProjeto.create({ data: { leadId: lead.id, nome: "Cobertura", posicao: 0 } })
    const projB = await tx.leadProjeto.create({ data: { leadId: lead.id, nome: "Casa de praia", posicao: 1 } })
    const projetos = await tx.leadProjeto.findMany({ where: { leadId: lead.id }, orderBy: { posicao: "asc" } })
    ok("lead aceita varios projetos", projetos.length === 2)
    ok("projetos saem na ordem definida", projetos[0].nome === "Cobertura")
    ok("projeto nasce em ELABORANDO_PROPOSTA (cartao proprio no kanban)", projetos[0].status === "ELABORANDO_PROPOSTA")

    // ── 1b. Status de projeto e independente do outro (kanban por projeto) ─
    await tx.leadProjeto.update({ where: { id: projA.id }, data: { status: "GANHO" } })
    const [aDepois, bDepois] = await Promise.all([
      tx.leadProjeto.findUnique({ where: { id: projA.id }, select: { status: true } }),
      tx.leadProjeto.findUnique({ where: { id: projB.id }, select: { status: true } }),
    ])
    ok("mover um projeto pro Ganho nao mexe no outro", aDepois.status === "GANHO" && bDepois.status === "ELABORANDO_PROPOSTA")

    // ── 2. Proposta amarrada a um projeto ─────────────────────────────────
    const prop = await tx.proposal.create({
      data: {
        company: { connect: { id: company.id } },
        numero: "TESTE-ROLLBACK-001",
        client_name: "TESTE", valor_total: 0,
        vendedor: { connect: { id: vendedor.id } },
        lead: { connect: { id: lead.id } },
        leadProjeto: { connect: { id: projB.id } },
      },
    })
    const lida = await tx.proposal.findUnique({
      where: { id: prop.id },
      select: { leadProjetoId: true, leadProjeto: { select: { nome: true } } },
    })
    ok("proposta guarda de qual projeto e", lida.leadProjeto?.nome === "Casa de praia")

    // ── 3. Sistemas com status ────────────────────────────────────────────
    const sisAtivo = await tx.environment.create({
      data: { nome: "Automacao", companyId: company.id, proposalId: prop.id, status: "ATIVO" },
    })
    const sisGuardado = await tx.environment.create({
      data: { nome: "Som", companyId: company.id, proposalId: prop.id, status: "GUARDADO" },
    })
    await tx.proposalItem.createMany({
      data: [
        { proposalId: prop.id, environmentId: sisAtivo.id, quantidade: 1, valor_unitario: 1000, valor_total: 1000 },
        { proposalId: prop.id, environmentId: sisGuardado.id, quantidade: 1, valor_unitario: 7777, valor_total: 7777 },
      ],
    })

    // A regra que vale dinheiro: guardado nao soma.
    const soAtivos = await tx.environment.findMany({
      where: { proposalId: prop.id, status: "ATIVO" },
      include: { proposalItems: true },
    })
    const total = soAtivos.reduce((s, e) => s + e.proposalItems.reduce((ss, i) => ss + Number(i.valor_total), 0), 0)
    ok("total ignora sistema guardado (1000, nao 8777)", total === 1000)

    // O que a pagina publica enxerga.
    const publicos = await tx.environment.findMany({ where: { proposalId: prop.id, status: "ATIVO" } })
    ok("pagina publica nao mostra o guardado", publicos.length === 1 && publicos[0].nome === "Automacao")

    // O que a ficha do cliente resgata.
    const guardados = await tx.environment.findMany({
      where: { status: { in: ["GUARDADO", "RECUSADO"] }, proposal: { leadId: lead.id } },
      include: { proposalItems: true },
    })
    ok("ficha do cliente acha o sistema guardado", guardados.length === 1)
    ok("guardado preserva os itens da epoca",
      guardados[0]?.proposalItems.reduce((s, i) => s + Number(i.valor_total), 0) === 7777)

    // ── 4. Ambiente fisico da obra (entidade, nao texto) ──────────────────
    const obra = await tx.obra.create({
      data: { companyId: company.id, client_name: "TESTE ROLLBACK" },
    })
    // sisAtivo tem 1 item, sisGuardado tem 1 item — os dois entram na obra,
    // mas so o item do sistema ATIVO e o que interessa pra pendencia (o
    // guardado nem esta sendo oferecido ainda).
    await tx.environment.updateMany({
      where: { id: { in: [sisAtivo.id, sisGuardado.id] } },
      data: { obraId: obra.id },
    })
    const itemAtivo = await tx.proposalItem.findFirst({ where: { environmentId: sisAtivo.id } })

    // Antes de criar ambiente: pendencia deve acusar item sem ambiente.
    const pendenteAntes = await tx.proposalItem.findMany({
      where: { environment: { obraId: obra.id, status: "ATIVO" }, obraAmbienteId: null },
    })
    ok("pendencia acusa item sem ambiente antes de organizar", pendenteAntes.length === 1)

    const ambiente = await tx.obraAmbiente.create({ data: { obraId: obra.id, nome: "Suite 2" } })
    await tx.proposalItem.update({ where: { id: itemAtivo.id }, data: { obraAmbienteId: ambiente.id } })

    const comAmbiente = await tx.proposalItem.findUnique({
      where: { id: itemAtivo.id }, select: { obraAmbienteId: true, obraAmbiente: { select: { nome: true } } },
    })
    ok("item guarda o ambiente ligado por id", comAmbiente.obraAmbiente?.nome === "Suite 2")

    const pendenteDepois = await tx.proposalItem.findMany({
      where: { environment: { obraId: obra.id, status: "ATIVO" }, obraAmbienteId: null },
    })
    ok("pendencia zera depois de organizar o unico item ativo", pendenteDepois.length === 0)

    // Excluir o ambiente devolve o item pra fila — nao apaga o item.
    await tx.obraAmbiente.delete({ where: { id: ambiente.id } })
    const depoisExcluir = await tx.proposalItem.findUnique({
      where: { id: itemAtivo.id }, select: { obraAmbienteId: true },
    })
    ok("excluir ambiente devolve item pra fila (SetNull), nao apaga", depoisExcluir.obraAmbienteId === null)

    // ── 5. Apagar o lead leva os projetos junto (cascade) ─────────────────
    await tx.lead.delete({ where: { id: lead.id } })
    const orfaos = await tx.leadProjeto.findMany({ where: { leadId: lead.id } })
    ok("apagar o lead leva os projetos (cascade)", orfaos.length === 0)
    // ...mas NAO leva a proposta, que e documento comercial.
    const propSobrevive = await tx.proposal.findUnique({
      where: { id: prop.id }, select: { id: true, leadProjetoId: true },
    })
    ok("proposta sobrevive ao lead apagado", !!propSobrevive)
    ok("vinculo com o projeto vira nulo, nao quebra", propSobrevive.leadProjetoId === null)

    throw new Rollback()
  })
} catch (e) {
  if (!(e instanceof Rollback)) {
    console.error("ERRO:", e.message)
    process.exit(1)
  }
}

// Prova que nada ficou para tras.
const sobrou = await prisma.proposal.count({ where: { numero: "TESTE-ROLLBACK-001" } })
const leadSobrou = await prisma.lead.count({ where: { nome: "TESTE ROLLBACK" } })
ok("rollback limpou tudo (proposta)", sobrou === 0)
ok("rollback limpou tudo (lead)", leadSobrou === 0)

console.log(falhas.length === 0 ? "\nTUDO PASSOU" : `\n${falhas.length} FALHA(S): ${falhas.join(", ")}`)
await prisma.$disconnect()
process.exit(falhas.length === 0 ? 0 : 1)
