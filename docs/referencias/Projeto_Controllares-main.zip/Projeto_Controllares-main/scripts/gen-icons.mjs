import sharp from "sharp";
import { writeFileSync } from "fs";

// Mesmo desenho do componente ControlDealLogo (círculo + 5 barras), com fundo
// sólido preto (fica igual em qualquer launcher, sem transparência esquisita).
function svg(size, { withBg = true } = {}) {
  const bars = [
    { x: 22, h: 30, fill: "#2e9e3f" },
    { x: 34, h: 40, fill: "#8bc53f" },
    { x: 46, h: 46, fill: "#f4c020" },
    { x: 58, h: 40, fill: "#ef7d1a" },
    { x: 70, h: 30, fill: "#2aa3d5" },
  ];
  const rects = bars.map(b => `<rect x="${b.x}" y="${50 - b.h / 2}" width="9" height="${b.h}" rx="4.5" fill="${b.fill}"/>`).join("");
  return `<svg width="${size}" height="${size}" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
    ${withBg ? '<rect width="100" height="100" fill="#000000"/>' : ""}
    <circle cx="50" cy="50" r="43" fill="none" stroke="#37474f" stroke-width="6"/>
    ${rects}
  </svg>`;
}

async function gen(name, size, opts) {
  await sharp(Buffer.from(svg(size, opts))).png().toFile(`public/icons/${name}`);
  console.log("gerado:", name);
}

// maskable precisa de margem de segurança (conteúdo dentro de ~80% central)
function svgMaskable(size) {
  const bars = [
    { x: 30, h: 20, fill: "#2e9e3f" },
    { x: 40, h: 27, fill: "#8bc53f" },
    { x: 50, h: 31, fill: "#f4c020" },
    { x: 60, h: 27, fill: "#ef7d1a" },
    { x: 70, h: 20, fill: "#2aa3d5" },
  ];
  const rects = bars.map(b => `<rect x="${b.x}" y="${50 - b.h / 2}" width="6" height="${b.h}" rx="3" fill="${b.fill}"/>`).join("");
  return `<svg width="${size}" height="${size}" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
    <rect width="100" height="100" fill="#000000"/>
    <circle cx="50" cy="50" r="29" fill="none" stroke="#37474f" stroke-width="4"/>
    ${rects}
  </svg>`;
}

await gen("icon-192.png", 192);
await gen("icon-512.png", 512);
await sharp(Buffer.from(svgMaskable(512))).png().toFile("public/icons/icon-maskable-512.png");
console.log("gerado: icon-maskable-512.png");

// favicon simples (32px, sem fundo, mais nítido em barra pequena)
await sharp(Buffer.from(svg(64, { withBg: false }))).png().toFile("public/icons/favicon-src.png");
console.log("done");
