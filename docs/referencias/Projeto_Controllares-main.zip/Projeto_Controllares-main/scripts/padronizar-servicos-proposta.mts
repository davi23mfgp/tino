/**
 * Padroniza o serviço das propostas antigas.
 *
 * Instalação e administração de obra eram lançadas fora da composição: só
 * entravam somadas em `valor_servico`, sem nome. Com o serviço virando BLOCO
 * na proposta, essas propostas mostravam a lista detalhada somando menos que o
 * total — a diferença não tinha linha, e a conta do cliente parecia errada.
 *
 * Este script escreve a diferença como uma linha nomeada em `servicos_detalhe`,
 * para que a composição gravada passe a fechar com `valor_servico`. Nenhum
 * valor muda: `valor_servico` e `valor_total` ficam como estão — o que muda é
 * a proposta passar a DIZER de onde vem o serviço que ela já cobrava.
 *
 * A divisão original entre instalação e administração não é recuperável (só a
 * soma foi gravada), então a linha sai com o nome do bloco.
 *
 * Simulação (não grava nada):  npm run padronizar:servicos
 * Gravando:                    npm run padronizar:servicos -- --aplicar
 */
import { PrismaClient } from "@prisma/client"
import { valorDoServico, type ServicoProposta } from "../src/lib/servicos-proposta"
import { NOME_BLOCO_SERVICO } from "../src/lib/blocos-proposta"

const aplicar = process.argv.includes("--aplicar")
const prisma = new PrismaClient()
const brl = (v: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v)

const propostas = await prisma.proposal.findMany({
  select: {
    id: true, numero: true, client_name: true, status: true,
    valor_servico: true, servicos_detalhe: true,
    environments: {
      where: { status: "ATIVO" },
      select: { id: true, proposalItems: { select: { valor_total: true, categoryId: true } } },
    },
  },
  orderBy: { createdAt: "desc" },
})

let ajustadas = 0
let jaCertas = 0

for (const p of propostas) {
  const gravado = Number(p.valor_servico ?? 0)
  if (gravado <= 0) continue

  const itens = p.environments.flatMap(e =>
    e.proposalItems.map(i => ({
      environmentId: e.id,
      categoryId: i.categoryId ?? null,
      valor_total: Number(i.valor_total),
    })))

  const detalhe: ServicoProposta[] = Array.isArray(p.servicos_detalhe)
    ? (p.servicos_detalhe as unknown as ServicoProposta[])
    : []
  const soma = detalhe.reduce((s, sv) => s + valorDoServico(sv, itens), 0)
  const falta = gravado - soma

  // Um centavo de folga: percentual sobre centavos não fecha exato.
  if (falta <= 0.01) { jaCertas++; continue }

  ajustadas++
  console.log(
    `${p.numero} · ${p.client_name} · ${p.status}\n`
    + `   serviço gravado ${brl(gravado)} · composição ${brl(soma)}`
    + ` · falta ${brl(falta)} → linha "${NOME_BLOCO_SERVICO}"`,
  )

  if (aplicar) {
    await prisma.proposal.update({
      where: { id: p.id },
      data: {
        servicos_detalhe: [
          ...detalhe,
          { id: `sv_padronizado_${p.id}`, nome: NOME_BLOCO_SERVICO, tipo: "fixo", valor: String(falta.toFixed(2)) },
        ] as never,
      },
    })
  }
}

console.log(
  `\n${ajustadas} proposta(s) com serviço sem linha, ${jaCertas} já fechando.`
  + (aplicar ? " Gravado." : " Simulação: nada foi gravado (use --aplicar)."),
)
await prisma.$disconnect()
