/**
 * Gera ícones PNG para o PWA a partir do SVG do logo.
 * Requer: sharp (npm install -D sharp)
 * Uso: node scripts/generate-icons.mjs
 */

import { createRequire } from "module"
import { writeFileSync, mkdirSync } from "fs"
import { join, dirname } from "path"
import { fileURLToPath } from "url"

const __dir = dirname(fileURLToPath(import.meta.url))
const root  = join(__dir, "..")
const out   = join(root, "public", "icons")
mkdirSync(out, { recursive: true })

// SVG do logo Control.Deal (mesmas coordenadas do logo.tsx)
const logoSvg = `<svg width="512" height="512" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
  <rect width="100" height="100" fill="#000000"/>
  <polygon points="10,20 45,20 55,80 20,80" fill="#1a7a2e"/>
  <polygon points="20,18 55,18 63,78 28,78" fill="#4caf22"/>
  <polygon points="30,16 65,16 71,76 36,76" fill="#f5c800"/>
  <polygon points="40,14 75,14 79,74 44,74" fill="#e85c1a"/>
  <polygon points="52,12 88,12 95,50 88,85 52,85" fill="#3b9fd4"/>
</svg>`

// SVG maskable — safe zone é 80% do centro, adiciona padding extra (fundo preto)
const maskableSvg = `<svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
  <rect width="512" height="512" fill="#000000"/>
  <g transform="translate(76, 76) scale(3.6)">
    <polygon points="10,20 45,20 55,80 20,80" fill="#1a7a2e"/>
    <polygon points="20,18 55,18 63,78 28,78" fill="#4caf22"/>
    <polygon points="30,16 65,16 71,76 36,76" fill="#f5c800"/>
    <polygon points="40,14 75,14 79,74 44,74" fill="#e85c1a"/>
    <polygon points="52,12 88,12 95,50 88,85 52,85" fill="#3b9fd4"/>
  </g>
</svg>`

const require = createRequire(import.meta.url)
let sharp
try {
  sharp = require("sharp")
} catch {
  console.error("❌  sharp não encontrado. Instale: npm install -D sharp")
  process.exit(1)
}

async function gen(svgStr, filename, size) {
  const buf = Buffer.from(svgStr)
  await sharp(buf)
    .resize(size, size)
    .png()
    .toFile(join(out, filename))
  console.log(`✅  public/icons/${filename}`)
}

await gen(logoSvg,      "icon-192.png",          192)
await gen(logoSvg,      "icon-512.png",           512)
await gen(maskableSvg,  "icon-maskable-512.png",  512)
console.log("\n🎉  Ícones gerados em public/icons/")
