/**
 * O cliente escolhendo só parte dos sistemas, contra o banco de verdade.
 *
 * Tudo roda dentro de uma transação que termina em rollback: nenhum registro
 * sobrevive. É o que permite exercitar a regra real (status GUARDADO, serviço
 * recalculado, parcelas antigas removidas) sem depender de login e sem sujar
 * dado de produção.
 *
 * Rodar: npx tsx scripts/verificar-escolha-sistemas.mts
 */
import { PrismaClient } from "@prisma/client"
import { aplicarEscolhaDeSistemas } from "../src/lib/escolha-sistemas"

const prisma = new PrismaClient()
const falhas: string[] = []
const ok = (nome: string, cond: boolean) => {
  console.log(`${cond ? "  ok  " : "FALHA "} ${nome}`)
  if (!cond) falhas.push(nome)
}
const perto = (a: number, b: number) => Math.abs(a - b) < 0.01

class Rollback extends Error {}

try {
  await prisma.$transaction(async tx => {
    const company = await tx.company.findFirst({ select: { id: true } })
    const vendedor = await tx.user.findFirst({ where: { companyId: company!.id }, select: { id: true } })
    if (!company || !vendedor) throw new Error("Sem empresa/usuario para testar")

    /* Proposta com dois sistemas: Automação (1000) e Som (400). Serviço de 10%
       preso ao Som — some junto se ele não for escolhido. */
    const prop = await tx.proposal.create({
      data: {
        companyId: company.id, vendedorId: vendedor.id,
        numero: "TESTE-ESCOLHA-001", client_name: "TESTE ESCOLHA",
        status: "ENVIADA", link_token: `teste-escolha-${Date.now()}`,
        valor_total: 1440, valor_servico: 40,
        project_type: "RESIDENCIAL",
      },
    })
    const automacao = await tx.environment.create({
      data: { proposalId: prop.id, companyId: company.id, nome: "Automacao", status: "ATIVO" },
    })
    const som = await tx.environment.create({
      data: { proposalId: prop.id, companyId: company.id, nome: "Som", status: "ATIVO" },
    })
    await tx.proposalItem.create({
      data: { proposalId: prop.id, environmentId: automacao.id, quantidade: 1, valor_unitario: 1000, valor_total: 1000, nome_snapshot: "Central" },
    })
    await tx.proposalItem.create({
      data: { proposalId: prop.id, environmentId: som.id, quantidade: 1, valor_unitario: 400, valor_total: 400, nome_snapshot: "Caixa" },
    })
    await tx.proposal.update({
      where: { id: prop.id },
      data: { servicos_detalhe: [{ nome: "Instalacao do som", tipo: "percentual", valor: 10, environmentId: som.id }] },
    })
    // Parcela montada com o valor cheio: precisa sumir quando o valor muda.
    await tx.installment.create({
      data: { proposalId: prop.id, numero_parcela: 1, valor: 1440, data_vencimento: new Date() },
    })

    // ── Cliente leva só a Automação ──────────────────────────────────────
    const r = await aplicarEscolhaDeSistemas(tx, prop.id, [automacao.id], 0)
    ok("aplicou a escolha parcial", !!r)
    ok("guardou 1 e seguiu com 1", r?.guardados === 1 && r?.sobraram === 1)

    const somDepois = await tx.environment.findUnique({ where: { id: som.id }, select: { status: true } })
    const autoDepois = await tx.environment.findUnique({ where: { id: automacao.id }, select: { status: true } })
    ok("sistema nao escolhido vira GUARDADO", somDepois?.status === "GUARDADO")
    ok("sistema escolhido continua ATIVO", autoDepois?.status === "ATIVO")

    const depois = await tx.proposal.findUnique({
      where: { id: prop.id }, select: { valor_total: true, valor_servico: true },
    })
    // Serviço era 10% do Som; o Som saiu, então o serviço zera e sobram os 1000.
    ok("servico preso ao sistema guardado sai junto", perto(Number(depois!.valor_servico), 0))
    ok("valor total vira so o do sistema escolhido (1000)", perto(Number(depois!.valor_total), 1000))

    const parcelas = await tx.installment.count({ where: { proposalId: prop.id } })
    ok("parcela do valor antigo foi removida", parcelas === 0)

    // ── Itens do guardado continuam intactos, para resgate na ficha ──────
    const itensDoSom = await tx.proposalItem.count({ where: { environmentId: som.id } })
    ok("itens do sistema guardado ficam salvos", itensDoSom === 1)

    // ── Escolher tudo não mexe em nada ───────────────────────────────────
    const prop2 = await tx.proposal.create({
      data: {
        companyId: company.id, vendedorId: vendedor.id,
        numero: "TESTE-ESCOLHA-002", client_name: "TESTE ESCOLHA 2",
        status: "ENVIADA", link_token: `teste-escolha2-${Date.now()}`,
        valor_total: 500, valor_servico: 0, project_type: "RESIDENCIAL",
      },
    })
    const e1 = await tx.environment.create({ data: { proposalId: prop2.id, companyId: company.id, nome: "A", status: "ATIVO" } })
    const e2 = await tx.environment.create({ data: { proposalId: prop2.id, companyId: company.id, nome: "B", status: "ATIVO" } })
    const semMudanca = await aplicarEscolhaDeSistemas(tx, prop2.id, [e1.id, e2.id], 0)
    ok("escolher todos nao mexe na proposta", semMudanca === null)

    // ── Lista vazia é ignorada (cliente sem escolha explícita) ───────────
    const vazio = await aplicarEscolhaDeSistemas(tx, prop2.id, [], 0)
    ok("lista vazia nao guarda nada", vazio === null)

    // ── Desconto entra no valor refeito ──────────────────────────────────
    const prop3 = await tx.proposal.create({
      data: {
        companyId: company.id, vendedorId: vendedor.id,
        numero: "TESTE-ESCOLHA-003", client_name: "TESTE ESCOLHA 3",
        status: "ENVIADA", link_token: `teste-escolha3-${Date.now()}`,
        valor_total: 2000, valor_servico: 0, project_type: "RESIDENCIAL",
      },
    })
    const x1 = await tx.environment.create({ data: { proposalId: prop3.id, companyId: company.id, nome: "X", status: "ATIVO" } })
    const x2 = await tx.environment.create({ data: { proposalId: prop3.id, companyId: company.id, nome: "Y", status: "ATIVO" } })
    await tx.proposalItem.create({ data: { proposalId: prop3.id, environmentId: x1.id, quantidade: 1, valor_unitario: 1000, valor_total: 1000, nome_snapshot: "X1" } })
    await tx.proposalItem.create({ data: { proposalId: prop3.id, environmentId: x2.id, quantidade: 1, valor_unitario: 1000, valor_total: 1000, nome_snapshot: "Y1" } })
    await aplicarEscolhaDeSistemas(tx, prop3.id, [x1.id], 10)
    const p3 = await tx.proposal.findUnique({ where: { id: prop3.id }, select: { valor_total: true } })
    ok("desconto de 10% entra no valor refeito (900)", perto(Number(p3!.valor_total), 900))

    throw new Rollback()
  }, { timeout: 30000 })
} catch (e) {
  if (!(e instanceof Rollback)) {
    console.error("ERRO:", (e as Error).message)
    process.exit(1)
  }
}

// Prova que nada ficou para trás.
const sobrou = await prisma.proposal.count({ where: { numero: { startsWith: "TESTE-ESCOLHA-" } } })
ok("rollback limpou tudo", sobrou === 0)

console.log(falhas.length === 0 ? "\nTUDO PASSOU" : `\n${falhas.length} FALHA(S): ${falhas.join(", ")}`)
await prisma.$disconnect()
process.exit(falhas.length === 0 ? 0 : 1)
