/**
 * Prova o ida-e-volta da dimensão do catálogo: banco (mm) -> campo (cm) -> banco.
 *
 *   npx tsx scripts/testar-dimensao-catalogo.mts
 *
 * O formulário do catálogo guarda centímetro e o banco guarda milímetro. A
 * conversão mora em duas linhas distantes uma da outra (carregar divide por 10,
 * salvar multiplica por 10), e é o tipo de par que quebra sem ninguém ver.
 *
 * O que precisa valer:
 *   1. Quem não mexe no campo salva exatamente o que estava lá, sem perder
 *      casa decimal por causa do arredondamento da tela.
 *   2. Quem mexe salva o que digitou, com a mesma precisão que o campo
 *      type="number" step="0.1" já aceitava.
 */
import { MASCARAS } from "../src/lib/mascara"

const cm = MASCARAS.cm

/** Igual à linha 592 do catálogo. */
const carregar = (mm: number | null) => (mm != null ? String(mm / 10) : "")
/** Igual à linha 673. */
const salvar = (campo: string) => (campo === "" ? null : Number(campo) * 10)

let falhas = 0

function semMexer(mmNoBanco: number | null, textoNaTela: string) {
  const campo = carregar(mmNoBanco)
  const tela = cm.exibir(campo)
  const devolta = salvar(campo)
  const ok = tela === textoNaTela && devolta === mmNoBanco
  if (!ok) falhas++
  console.log(`  ${ok ? "ok" : "XX"}  banco ${String(mmNoBanco).padStart(7)} mm -> tela "${tela}" -> banco ${devolta} mm`)
  if (!ok && tela !== textoNaTela) console.log(`      tela esperada "${textoNaTela}"`)
}

function digitando(teclas: string, mmEsperado: number | null, telaEsperada: string) {
  let texto = ""
  let bruto = ""
  for (const t of teclas) {
    const r = cm.aoDigitar(texto + t)
    texto = r.texto
    bruto = r.bruto
  }
  const devolta = salvar(bruto)
  const ok = devolta === mmEsperado && texto === telaEsperada
  if (!ok) falhas++
  console.log(`  ${ok ? "ok" : "XX"}  digitou "${teclas}" -> tela "${texto}" -> banco ${devolta} mm`)
  if (!ok) console.log(`      esperado tela "${telaEsperada}", banco ${mmEsperado} mm`)
}

console.log("\nSEM MEXER NO CAMPO (o valor do banco tem que voltar intacto)")
semMexer(257, "25,7 cm")
semMexer(1178, "117,8 cm")
semMexer(null, "")
// Medida com mais precisão do que a tela mostra: a tela arredonda, mas quem
// não editar o campo não pode perder o número original.
semMexer(257.18, "25,7 cm")

console.log("\nDIGITANDO")
digitando("25,7", 257, "25,7 cm")
digitando("117,8", 1178, "117,8 cm")
digitando("25.7", 257, "25,7 cm")   // ponto do teclado numérico
digitando("40", 400, "40 cm")

console.log(falhas === 0 ? "\nIda e volta fecha.\n" : `\n${falhas} falha(s).\n`)
process.exit(falhas === 0 ? 0 : 1)
