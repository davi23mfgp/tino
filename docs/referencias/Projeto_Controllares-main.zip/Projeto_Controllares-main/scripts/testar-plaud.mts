/**
 * Roda as reuniões de referência e diz se a leitura ainda funciona.
 *
 * Chame depois de mexer no prompt de extração, no casamento com o catálogo ou
 * no cliente de IA — os três lugares onde uma melhoria local costuma quebrar um
 * caso que ninguém estava olhando.
 *
 *   npx tsx scripts/testar-plaud.mts
 *
 * Cada caso roda três vezes. Modelo de linguagem varia entre chamadas, e um
 * caso que passa em uma de três não está funcionando — está com sorte. O que
 * interessa é quantas das três atendem a expectativa.
 *
 * Sai com código 1 quando algum caso reprova, para servir em CI sem ninguém ler
 * a saída.
 */
process.loadEnvFile(".env")

import { CASOS } from "../src/lib/plaud-fixtures.ts"
import { extrairEscopo } from "../src/lib/plaud-extrair.ts"
import { casarComCatalogo } from "../src/lib/plaud-casar.ts"
import { marcasDaCasa } from "../src/lib/plaud-vocabulario.ts"
import { PrismaClient } from "@prisma/client"

const RODADAS = 3
const prisma = new PrismaClient()

const empresa = await prisma.company.findFirst({ select: { id: true } })
if (!empresa) {
  console.error("Nenhuma empresa no banco — o teste precisa de um catálogo real.")
  process.exit(1)
}
const marcas = await marcasDaCasa(empresa.id)

let reprovados = 0

for (const caso of CASOS) {
  const resultados: { itens: number; skus: string[]; pendencias: number }[] = []

  for (let i = 0; i < RODADAS; i++) {
    const escopo = await extrairEscopo(caso.transcricao, [], marcas)
    const falados = escopo.ambientes.flatMap(a => a.itens)
    const casado = falados.length
      ? await casarComCatalogo(empresa.id, falados)
      : { itens: [], novasPendencias: [] }
    resultados.push({
      itens: casado.itens.length,
      skus: casado.itens.map(i => i.sku),
      pendencias: escopo.pendencias.length + casado.novasPendencias.length,
    })
  }

  const ok = resultados.filter(r => {
    if (r.itens < caso.minimoItens) return false
    if (!caso.skusEsperados.every(s => r.skus.includes(s))) return false
    if (caso.pendenciasEsperadas != null && r.pendencias < caso.pendenciasEsperadas) return false
    return true
  }).length

  /* Passa com dois de três. Exigir três seria exigir determinismo de algo que
     não é determinístico, e o teste viraria ruído até alguém desligar. */
  const passou = ok >= 2
  if (!passou) reprovados++

  console.log(`${passou ? "OK  " : "FALHA"} ${caso.nome}  (${ok}/${RODADAS})`)
  for (const r of resultados) {
    console.log(`        itens=${r.itens} pendencias=${r.pendencias} skus=${r.skus.join(",") || "—"}`)
  }
  if (!passou) {
    console.log(`        esperado: >=${caso.minimoItens} itens`
      + (caso.skusEsperados.length ? `, com ${caso.skusEsperados.join(", ")}` : "")
      + (caso.pendenciasEsperadas != null ? `, >=${caso.pendenciasEsperadas} pendência(s)` : ""))
  }
}

await prisma.$disconnect()

console.log(reprovados
  ? `\n${reprovados} caso(s) reprovado(s).`
  : "\nTodos os casos passaram.")
process.exit(reprovados ? 1 : 0)
