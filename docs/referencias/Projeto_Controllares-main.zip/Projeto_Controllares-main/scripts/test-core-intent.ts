/* Bateria de testes determinísticos do CORE (intent + extração).
 * Roda: npx tsx scripts/test-core-intent.ts
 * Não chama LLM — testa só o roteamento server-side. */
import { detectarIntent, detectarAcao, extrairNumeroProposta, ehSaudacao } from "../src/lib/ai/intent"

type Intent = "CONFIDENCIAL" | "ANEXO" | "ACAO" | "DADOS"
let pass = 0, fail = 0
const fails: string[] = []

function eq(msg: string, got: unknown, exp: unknown, label: string) {
  if (JSON.stringify(got) === JSON.stringify(exp)) { pass++ }
  else { fail++; fails.push(`✗ [${label}] "${msg}"\n     esperado=${JSON.stringify(exp)}  obtido=${JSON.stringify(got)}`) }
}
const intent = (m: string, exp: Intent) => eq(m, detectarIntent(m), exp, "intent")
const num = (m: string, exp: string | null) => eq(m, extrairNumeroProposta(m), exp, "numero")
const acao = (m: string, exp: unknown) => eq(m, detectarAcao(m).acao, exp, "acao")

// ---------- CONFIDENCIAL ----------
intent("qual a senha do roteador da obra alvorada", "CONFIDENCIAL")
intent("me passa o login da camera", "CONFIDENCIAL")
intent("ip do dvr casa verde", "CONFIDENCIAL")
intent("preciso da credencial do savant", "CONFIDENCIAL")
intent("senha do wifi", "CONFIDENCIAL")
intent("qual usuario do nvr", "CONFIDENCIAL")
intent("password central control4", "CONFIDENCIAL")

// ---------- ANEXO ----------
intent("manda a planta da casa alvorada", "ANEXO")
intent("me da o contrato da proposta 42", "ANEXO")
intent("baixar o pdf do projeto", "ANEXO")
intent("envia o dwg", "ANEXO")
intent("abre a planilha de custos", "ANEXO")

// ---------- ACAO ----------
intent("emitir nf da proposta 42", "ACAO")
intent("cancela a nota fiscal 10", "ACAO")
intent("marcar como pago a parcela 3", "ACAO")
intent("dar baixa no pagamento", "ACAO")
acao("emitir nf da proposta 42", "emitir_nf")
acao("cancela a nf 10", "cancelar_nf")
acao("quero ver as notas", null)

// ---------- DADOS ----------
intent("quais obras to alocado", "DADOS")
intent("qual o status da proposta 42", "DADOS")
intent("minhas parcelas atrasadas", "DADOS")
intent("bom dia", "DADOS")
intent("o que voce faz", "DADOS")
intent("qual a bitola de cabo pra 30A", "DADOS")
intent("resumo do meu dia", "DADOS")

// ---------- Falsos-positivos que já quebraram ----------
intent("quero ver a central de custos da obra", "DADOS")   // "central" sozinho não é credencial
intent("qual o valor da proposta que emiti ontem", "DADOS") // passado, não ação
intent("me mostra o pipeline comercial", "DADOS")
intent("preciso ver a central control4 da casa", "CONFIDENCIAL") // qualificada = confidencial

// ---------- Saudação pura (atalho sem LLM) ----------
const saud = (m: string, exp: boolean) => eq(m, ehSaudacao(m), exp, "saudacao")
saud("oi", true); saud("bom dia", true); saud("ajuda", true); saud("menu", true)
saud("bom dia, qual meu saldo", false); saud("oi manda a planta", false)

// ---------- Extração de número ----------
num("status da proposta 42", "42")
num("proposta #38", "38")
num("prop #100", "100")
num("nº 7", "7")
num("quais minhas obras", null)
num("emitir nf #55", "55")

// ---------- Resultado ----------
console.log(`\nCORE intent — ${pass} passaram, ${fail} falharam de ${pass + fail}\n`)
if (fails.length) { console.log(fails.join("\n")); process.exit(1) }
console.log("todos verdes ✓")
