/**
 * Prova a conta do "já incluído no preço dos produtos".
 *
 *   npx tsx scripts/testar-servico-embutido.mts
 *
 * O serviço da categoria entra no preço do item quando ele é adicionado:
 *
 *   preço = limpo × (1 + r) + fixo
 *
 * Para MOSTRAR quanto disso é serviço, é preciso desfazer a conta. O erro fácil
 * é multiplicar o total pela porcentagem: num item de R$ 100 que virou R$ 130,
 * 30% de 130 dá R$ 39, e o serviço foi R$ 30. A conta certa é
 * `total × r / (1 + r)`.
 *
 * O teste vai pelo caminho inteiro: parte do preço limpo, aplica a regra como a
 * tela aplica, e confere se o desfazer devolve exatamente o que foi somado.
 */

const cent = (v: number) => Math.round(v * 100) / 100
let falhas = 0

function conferir(nome: string, a: number, b: number, tol = 0.01) {
  const ok = Math.abs(a - b) <= tol
  if (!ok) falhas++
  console.log(`  ${ok ? "ok" : "XX"}  ${nome}: ${cent(a)} ${ok ? "==" : "!="} ${cent(b)}`)
}

/** Como a tela monta o preço do item. */
const comServico = (limpo: number, pct: number, fixo: number) => limpo * (1 + pct / 100) + fixo

/** Como o painel desfaz, para mostrar quanto é serviço. */
function embutido(totalCategoria: number, qtdTotal: number, pct: number, fixo: number) {
  const embFixo = fixo * qtdTotal
  const r = pct / 100
  const embPct = r > 0 ? (totalCategoria - embFixo) * r / (1 + r) : 0
  return { embFixo, embPct, soma: embFixo + embPct }
}

console.log("\nUM ITEM, 30%")
{
  const limpo = 100, pct = 30, fixo = 0, qtd = 1
  const preco = comServico(limpo, pct, fixo)
  const e = embutido(preco * qtd, qtd, pct, fixo)
  console.log(`  limpo ${limpo} -> preço ${cent(preco)}`)
  conferir("o serviço embutido é o que foi somado", e.soma, preco - limpo)
  conferir("a conta ingênua daria mais", cent(preco * 0.30), 39)
}

console.log("\nVÁRIOS ITENS E QUANTIDADES, 30%")
{
  const pct = 30, fixo = 0
  const itens = [{ limpo: 6442.80, q: 1 }, { limpo: 7712.25, q: 5 }, { limpo: 98.72, q: 2 }]
  let total = 0, somado = 0, qtd = 0
  for (const i of itens) {
    const preco = comServico(i.limpo, pct, fixo)
    total += preco * i.q; somado += (preco - i.limpo) * i.q; qtd += i.q
  }
  const e = embutido(total, qtd, pct, fixo)
  console.log(`  total da categoria ${cent(total)}`)
  conferir("desfaz exatamente o que foi somado", e.soma, somado)
}

console.log("\nPORCENTAGEM E VALOR FIXO JUNTOS")
{
  const pct = 10, fixo = 1000
  const itens = [{ limpo: 5000, q: 2 }, { limpo: 3000, q: 1 }]
  let total = 0, somado = 0, qtd = 0
  for (const i of itens) {
    const preco = comServico(i.limpo, pct, fixo)
    total += preco * i.q; somado += (preco - i.limpo) * i.q; qtd += i.q
  }
  const e = embutido(total, qtd, pct, fixo)
  console.log(`  total ${cent(total)}   fixo embutido ${cent(e.embFixo)}   pct embutido ${cent(e.embPct)}`)
  conferir("a parte fixa é valor × quantidade", e.embFixo, fixo * qtd)
  conferir("a soma desfaz o que foi somado", e.soma, somado)
}

console.log("\nCATEGORIA SEM SERVIÇO")
{
  const e = embutido(5000, 3, 0, 0)
  conferir("não inventa serviço", e.soma, 0)
}

console.log(falhas === 0 ? "\nA conta fecha.\n" : `\n${falhas} falha(s).\n`)
process.exit(falhas === 0 ? 0 : 1)
