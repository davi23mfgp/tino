import { parseEstudoTeclas } from "../src/lib/keypad-parser"

// Colagem fiel do Excel (TSV), incluindo os casos-limite reais
const tsv = [
  "AMBIENTES\tINTERRUPÇÃO\tCIRCUITOS\tACABAMENTOS\tMEDIDAS\tQTD. TECLAS AUTOMAÇÃO\tCOMPRA PULSADORES\t",
  "GARAGEM\tKP01\t\tPADRÃO\t4X2\t1\t1\t",
  "GARAGEM\tKP02\t\tPADRÃO\t4X2\t0\t1\tLIGAR JUNTO KP01",
  "GARAGEM\tKP03\t\tPADRÃO\t4X2\t0\t1\tLIGAR JUNTO KP01",
  "ESCRITÓRIO\tKP04\t\tPADRÃO\t4X2\t2\t2\t",
  "SENSOR GARAGEM\t\t\t\t\t1\t0\t",
  "HALL ENTRADA\tKP40\t\tKEYPAD\t4X4\t3\t0\t",
  "PAVIMENTO SUPERIOR\t\t\t\t\t\t\t",
  "CIRCULAÇÃO\tKP22\t\tPADRÃO\t4X2\t2\t2\t",
  "CIRCULAÇÃO\tKP31\t\tPADRÃO\t4X2\t0\t2\tLIGAR JUNTO KP22",
  "HOME CINEMA\tKP08\t\tPADRÃO\t4X2\t0\t2\tLIGAR JUNNTO KP07",
].join("\n")

const r = parseEstudoTeclas(tsv)
console.log("total:", r.length)
for (const k of r) {
  console.log(
    `${(k.codigo ?? "—").padEnd(6)} setor=${(k.setor ?? "-").padEnd(20)} amb=${(k.ambiente ?? "-").padEnd(16)}` +
    ` acab=${(k.acabamento ?? "-").padEnd(7)} med=${(k.medida ?? "-").padEnd(4)}` +
    ` tec=${k.teclas_automacao} puls=${k.pulsadores_compra} junto=${k.ligar_junto ?? "-"}`
  )
}
