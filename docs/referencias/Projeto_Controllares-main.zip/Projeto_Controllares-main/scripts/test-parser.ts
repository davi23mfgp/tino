import { parseLigacaoModulos } from "../src/lib/automacao-parser"

const texto = `Ligação módulos Superior
M-03
Entradas
01 a 02 (KP-22; KP-31; KP-32)
03 (KP-17)
04 a 06 ( KP-18; KP-19; KP-20)
07 (KP-21)
08 a 09 (KP-16)
10 a 12 (KP-41; KP-24; KP-25)
13 a 15 (KP-27; KP-28; KP-30)
16 (KP-36)

Saidas
01= Mini Spots Circulação
02= Spots Chuveiro
03= Spots + Perfil Led Closet Master
12= Perfil Led & Spot WC Suíte 01

M-04
Entradas
01 a 03 (KP-33; KP-34; KP-35)

Saidas
01=  Perfil Led Suíte Master
06= Perfil Led Suíte 03`

const mods = parseLigacaoModulos(texto)
for (const m of mods) {
  console.log(`\n### ${m.nome} — ${m.entradas.length} entradas, ${m.saidas.length} saídas`)
  console.log("  entradas:", m.entradas.map(e => `${e.numero}[${e.keypads.join(",")}]`).join(" "))
  console.log("  saidas:  ", m.saidas.map(s => `${s.numero}=${s.descricao}`).join(" | "))
}
