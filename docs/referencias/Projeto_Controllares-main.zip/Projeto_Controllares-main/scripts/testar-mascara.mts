/**
 * Confere o motor de máscara sem abrir o navegador.
 *
 *   npx tsx scripts/testar-mascara.mts
 *
 * Simula a digitação tecla a tecla: a cada tecla o texto volta para a tela e é
 * dali que a próxima tecla parte, que é exatamente o ciclo do componente. Um
 * teste que só chama aoDigitar uma vez com a string pronta não pega o erro
 * mais comum, que é a máscara brigar com ela mesma na segunda tecla.
 */
import { MASCARAS, type NomeMascara } from "../src/lib/mascara"

let falhas = 0

function digitando(mascara: NomeMascara, teclas: string) {
  const m = MASCARAS[mascara]
  let texto = ""
  let bruto = ""
  for (const t of teclas) {
    const r = m.aoDigitar(texto + t)
    texto = r.texto
    bruto = r.bruto
  }
  return { texto, bruto }
}

function conferir(mascara: NomeMascara, teclas: string, esperado: string, brutoEsperado?: string) {
  const r = digitando(mascara, teclas)
  const okTexto = r.texto === esperado
  const okBruto = brutoEsperado === undefined || r.bruto === brutoEsperado
  if (okTexto && okBruto) {
    console.log(`  ok  ${mascara.padEnd(12)} "${teclas}" -> "${r.texto}"${brutoEsperado !== undefined ? `  bruto=${r.bruto}` : ""}`)
  } else {
    falhas++
    console.log(`  XX  ${mascara.padEnd(12)} "${teclas}"`)
    console.log(`      texto esperado "${esperado}"  veio "${r.texto}"`)
    if (!okBruto) console.log(`      bruto esperado "${brutoEsperado}"  veio "${r.bruto}"`)
  }
}

function conferirExibir(mascara: NomeMascara, bruto: string | number, esperado: string) {
  const veio = MASCARAS[mascara].exibir(bruto)
  if (veio === esperado) {
    console.log(`  ok  ${mascara.padEnd(12)} exibir(${JSON.stringify(bruto)}) -> "${veio}"`)
  } else {
    falhas++
    console.log(`  XX  ${mascara.padEnd(12)} exibir(${JSON.stringify(bruto)}) esperado "${esperado}" veio "${veio}"`)
  }
}

console.log("\nTELEFONE")
conferir("telefone", "17988211987", "(17) 98821-1987", "17988211987")
conferir("telefone", "1733214455", "(17) 3321-4455", "1733214455")
conferir("telefone", "17", "(17", "17")
conferir("telefone", "1", "(1", "1")
conferir("telefone", "179882119879999", "(17) 98821-1987", "17988211987")
conferirExibir("telefone", "17988211987", "(17) 98821-1987")
conferirExibir("telefone", "", "")

console.log("\nDOCUMENTO")
conferir("documento", "12345678901", "123.456.789-01", "12345678901")
conferir("documento", "12345678000199", "12.345.678/0001-99", "12345678000199")
conferir("documento", "123", "123", "123")
conferir("documento", "1234", "123.4", "1234")

console.log("\nCEP")
conferir("cep", "15015000", "15015-000", "15015000")
conferir("cep", "15015", "15015", "15015")

console.log("\nMOEDA")
conferir("moeda", "1", "R$ 0,01", "0.01")
conferir("moeda", "1987", "R$ 19,87", "19.87")
conferir("moeda", "123456789", "R$ 1.234.567,89", "1234567.89")
conferirExibir("moeda", 1500, "R$ 1.500,00")
conferirExibir("moeda", "", "")

console.log("\nMEDIDA")
conferir("mm", "125", "125 mm", "125")
conferir("mm", "12,5", "12,5 mm", "12.5")
conferir("mm", "12.5", "12,5 mm", "12.5")
conferir("cm", "12,", "12, cm", "12")
conferir("porcentagem", "17,5", "17,5 %", "17.5")
conferir("quantidade", "12,5", "125", "125")
conferirExibir("mm", 257.18, "257,2 mm")
conferirExibir("kg", 2.55, "2,55 kg")

console.log(falhas === 0 ? "\nTudo certo.\n" : `\n${falhas} falha(s).\n`)
process.exit(falhas === 0 ? 0 : 1)
