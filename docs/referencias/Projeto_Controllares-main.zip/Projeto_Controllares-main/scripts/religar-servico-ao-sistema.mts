/**
 * Religa o serviço ao sistema nas propostas em que o vínculo aponta para um
 * ambiente que não existe.
 *
 * Simulação (não grava):  npx tsx scripts/religar-servico-ao-sistema.mts
 * Gravando:               npx tsx scripts/religar-servico-ao-sistema.mts --aplicar
 *
 * O QUE ESTÁ QUEBRADO
 *
 * O editor da proposta cria cada sistema com um id do navegador
 * (crypto.randomUUID) e o serviço preso a um sistema guarda esse id. Ao salvar,
 * o banco gera o id dele (cuid) e o vínculo do serviço fica apontando para um
 * ambiente que não existe em lugar nenhum.
 *
 * O efeito é silencioso e por isso perigoso: `baseDoServico` não acha o
 * ambiente, devolve base zero, e o serviço vale R$ 0 na página do cliente, no
 * contrato e no pedido do Olist. Mas `valor_servico` foi gravado com o número
 * que o navegador calculou — então o total COBRA e a composição MOSTRA ZERO. O
 * documento desmente a si mesmo.
 *
 * COMO RELIGA
 *
 * Pela ordem. O navegador cria os ambientes em sequência e o banco os grava na
 * mesma sequência, então o primeiro id órfão é o primeiro ambiente, e assim por
 * diante.
 *
 * Isso é inferência, não certeza — por isso o script só grava se, depois de
 * religar, a composição bater com o `valor_servico` que já estava salvo, ao
 * centavo. Se bater, a ordem estava certa. Se não bater, a proposta fica de
 * fora e aparece na lista de recusadas.
 *
 * Nenhum valor muda: `valor_servico` e `valor_total` ficam como estão. O que
 * muda é a proposta voltar a DIZER de onde vem o serviço que ela já cobrava.
 *
 * Serviço sem nome também ganha um: sem nome ele chega ao cliente como linha em
 * branco. O nome sai do sistema sobre o qual ele incide.
 */
import { PrismaClient, Prisma } from "@prisma/client"
import { writeFileSync, mkdirSync } from "fs"
import { valorDoServico, type ItemParaServico, type ServicoProposta } from "../src/lib/servicos-proposta"

const APLICAR = process.argv.includes("--aplicar")
const prisma = new PrismaClient()

const brl = (v: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" })
    .format(v || 0).replace(/\u00A0/g, " ")
const cent = (v: number) => Math.round(v * 100) / 100

const propostas = await prisma.proposal.findMany({
  /* Só rascunho. Proposta enviada, aceita ou em contrato já foi lida pelo
     cliente: mexer na composição dela depois disso é mudar um documento que
     já está em circulação, mesmo sem mudar o valor. */
  where: { status: "RASCUNHO", servicos_detalhe: { not: Prisma.DbNull } },
  select: {
    id: true, numero: true, status: true, valor_servico: true, servicos_detalhe: true,
    environments: {
      where: { status: "ATIVO" },
      orderBy: { createdAt: "asc" },
      select: {
        id: true, nome: true,
        proposalItems: {
          select: {
            environmentId: true, categoryId: true, valor_total: true,
            product: { select: { categoryId: true } },
          },
        },
      },
    },
  },
  orderBy: { numero: "asc" },
})

type Plano = { id: string; numero: string; servicos: ServicoProposta[]; antes: number; depois: number }
const planos: Plano[] = []
const recusadas: string[] = []

for (const p of propostas) {
  const linhas = (p.servicos_detalhe as unknown as ServicoProposta[]).filter(Boolean)
  if (!linhas.length) continue

  const reais = new Set(p.environments.map(e => e.id))
  const orfas = linhas.filter(s => s.environmentId && !reais.has(s.environmentId))
  if (!orfas.length) continue

  const itens: ItemParaServico[] = p.environments.flatMap(e =>
    e.proposalItems.map(i => ({
      environmentId: i.environmentId,
      categoryId: i.categoryId ?? i.product?.categoryId ?? null,
      valor_total: Number(i.valor_total),
    })))

  const gravado = Number(p.valor_servico)
  const hoje = cent(linhas.reduce((t, s) => t + valorDoServico(s, itens), 0))

  console.log("=".repeat(74))
  console.log(`${p.numero} [${p.status}]`)
  console.log(`  gravado ${brl(gravado)}   composição hoje ${brl(hoje)}   some ${brl(cent(gravado - hoje))}`)

  /* A ordem em que os ids órfãos aparecem é a ordem em que os ambientes foram
     criados no navegador, e o banco gravou na mesma ordem. */
  const ordem: string[] = []
  for (const s of linhas) {
    if (s.environmentId && !reais.has(s.environmentId) && !ordem.includes(s.environmentId)) {
      ordem.push(s.environmentId)
    }
  }
  const mapa = new Map<string, string>()
  ordem.forEach((antigo, i) => { if (p.environments[i]) mapa.set(antigo, p.environments[i].id) })

  const religadas: ServicoProposta[] = linhas.map(s => {
    const novoEnv = s.environmentId && mapa.has(s.environmentId) ? mapa.get(s.environmentId)! : s.environmentId
    const env = p.environments.find(e => e.id === novoEnv)
    return {
      ...s,
      environmentId: novoEnv ?? null,
      // Linha em branco no documento do cliente não diz o que ele está pagando.
      nome: s.nome?.trim() ? s.nome : (env ? `Projeto e instalação — ${env.nome}` : "Projeto e instalação"),
    }
  })

  const depois = cent(religadas.reduce((t, s) => t + valorDoServico(s, itens), 0))
  console.log(`  religada por ordem: ${brl(depois)}`)
  for (const s of religadas) {
    const env = p.environments.find(e => e.id === s.environmentId)
    console.log(`    "${s.nome}"  sobre ${env ? env.nome : s.categoryId ? "categoria" : "toda a proposta"}  = ${brl(valorDoServico(s, itens))}`)
  }

  /* A prova. Se a ordem estivesse errada, a soma sairia diferente do que já
     está gravado — e aí a inferência não se sustenta. */
  if (Math.abs(depois - gravado) > 0.01) {
    console.log(`  RECUSADO: não fecha com o gravado (${brl(cent(depois - gravado))} de diferença).`)
    recusadas.push(`${p.numero}: religada daria ${brl(depois)}, gravado é ${brl(gravado)}`)
    continue
  }

  console.log("  OK: fecha ao centavo.")
  planos.push({ id: p.id, numero: p.numero, servicos: religadas, antes: hoje, depois })
}

console.log("\n" + "=".repeat(74))
console.log(`${planos.length} proposta(s) para religar.`)
if (recusadas.length) {
  console.log(`${recusadas.length} recusada(s) — precisam de olho:`)
  for (const r of recusadas) console.log("  " + r)
}

if (!APLICAR) {
  console.log("\nSimulação. Nada foi gravado. Use --aplicar para valer.")
  await prisma.$disconnect()
  process.exit(0)
}

const carimbo = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")
mkdirSync("pesquisa", { recursive: true })
writeFileSync(
  `pesquisa/BACKUP-religar-servico-${carimbo}.json`,
  JSON.stringify(propostas.filter(p => planos.some(x => x.id === p.id)), null, 2),
)

for (const x of planos) {
  await prisma.proposal.update({
    where: { id: x.id },
    data: { servicos_detalhe: x.servicos as unknown as Prisma.InputJsonValue },
  })
  console.log(`religado: ${x.numero}`)
}

console.log(`\n${planos.length} proposta(s) religadas.`)
await prisma.$disconnect()
