/**
 * Aplica as migrations no deploy — e resolve o banco que nunca foi "baselined".
 *
 * O deploy rodava só `prisma generate && next build`: campo novo no schema
 * existia no client e não no banco, o Prisma o selecionava em toda consulta e a
 * tela caía (a lista de propostas já zerou assim). A correção é o banco alcançar
 * o schema ANTES do código novo subir.
 *
 * Só que este banco foi criado sem passar por `migrate deploy`: as tabelas estão
 * lá, a tabela de controle `_prisma_migrations` não. O Prisma recusa com P3005 —
 * "the database schema is not empty" — e não é erro de migration, é o banco
 * dizendo que não sabe o que já rodou.
 *
 * Então: na primeira vez, registra como aplicadas as migrations que construíram
 * o que já está no banco (baseline, o procedimento que a própria Prisma indica)
 * e roda de verdade só as que faltam. Da segunda vez em diante o controle
 * existe, o P3005 não volta, e isto vira um `migrate deploy` comum.
 *
 * O baseline vai em UMA instrução SQL, não em `migrate resolve` por migration:
 * noventa e uma chamadas de CLI numa máquina de build de dois cores levavam
 * minutos, e o deploy inteiro ficava esperando por elas.
 */
import { spawnSync } from "node:child_process"
import { createHash } from "node:crypto"
import { existsSync, readdirSync, readFileSync } from "node:fs"
import { join } from "node:path"
import { randomUUID } from "node:crypto"

/* Migrations que NÃO podem ser baselineadas: elas ainda não rodaram neste
   banco, e registrá-las como aplicadas deixaria a coluna faltando com o schema
   dizendo que ela existe — o mesmo estrago que este script evita.
   Uma migration entra aqui quando é criada; sai quando já está em produção. */
const PENDENTES = new Set([
  "20260915130000_servico_de_categoria_por_proposta",
])

const BIN = process.platform === "win32" ? "node_modules/.bin/prisma.cmd" : "node_modules/.bin/prisma"
const usarBin = existsSync(BIN)
const prisma = (args, input) =>
  usarBin
    ? spawnSync(BIN, args, { encoding: "utf8", input })
    : spawnSync("npx", ["prisma", ...args], { encoding: "utf8", input })

function deploy() {
  const r = prisma(["migrate", "deploy"])
  process.stdout.write(r.stdout ?? "")
  process.stderr.write(r.stderr ?? "")
  return r
}

/** O checksum é o mesmo que o Prisma calcula: sha256 do arquivo da migration. */
const checksum = nome =>
  createHash("sha256")
    .update(readFileSync(join("prisma/migrations", nome, "migration.sql")))
    .digest("hex")

const aspas = v => `'${String(v).replace(/'/g, "''")}'`

/* Além do P3005 (banco cheio, controle vazio), entra aqui o build cancelado no
   meio de um baseline anterior: parte das migrations ficou registrada, então o
   Prisma não reclama mais de P3005 — tenta aplicar as que sobraram e esbarra em
   tabela ou coluna que já existe. O baseline abaixo é idempotente e fecha os
   dois casos. */
const precisaBaseline = saida =>
  ["P3005", "P3009", "already exists", "42P07", "42701"].some(m => saida.includes(m))

let r = deploy()

if (r.status !== 0 && precisaBaseline(`${r.stdout}${r.stderr}`)) {
  const migrations = readdirSync("prisma/migrations", { withFileTypes: true })
    .filter(d => d.isDirectory())
    .map(d => d.name)
    .sort()
  const baseline = migrations.filter(m => !PENDENTES.has(m))

  console.log(`\n[migrar] Banco sem o controle completo de migrations.`)
  console.log(`[migrar] Registrando ${baseline.length} migrations já refletidas no banco;`)
  console.log(`[migrar] ${migrations.length - baseline.length} serão aplicadas de verdade.\n`)

  /* A tabela é criada com o mesmo desenho que o Prisma usa; ON CONFLICT para o
     caso de o baseline ter sido feito pela metade numa tentativa anterior. */
  const sql = `
CREATE TABLE IF NOT EXISTS "_prisma_migrations" (
  "id"                    VARCHAR(36) PRIMARY KEY NOT NULL,
  "checksum"              VARCHAR(64) NOT NULL,
  "finished_at"           TIMESTAMPTZ,
  "migration_name"        VARCHAR(255) NOT NULL,
  "logs"                  TEXT,
  "rolled_back_at"        TIMESTAMPTZ,
  "started_at"            TIMESTAMPTZ NOT NULL DEFAULT now(),
  "applied_steps_count"   INTEGER NOT NULL DEFAULT 0
);
INSERT INTO "_prisma_migrations"
  ("id","checksum","finished_at","migration_name","started_at","applied_steps_count")
VALUES
${baseline.map(nome =>
  `(${aspas(randomUUID())}, ${aspas(checksum(nome))}, now(), ${aspas(nome)}, now(), 1)`
).join(",\n")}
ON CONFLICT DO NOTHING;
`

  const exec = prisma(["db", "execute", "--stdin", "--schema", "prisma/schema.prisma"], sql)
  process.stdout.write(exec.stdout ?? "")
  process.stderr.write(exec.stderr ?? "")
  if (exec.status !== 0) {
    console.error("[migrar] Baseline falhou. Nada foi publicado.")
    process.exit(exec.status ?? 1)
  }

  r = deploy()
}

process.exit(r.status ?? 1)
