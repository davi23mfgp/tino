"use client"

import { useEffect, useState } from "react"

/**
 * Filtro que sobrevive à recarga da página.
 *
 * O padrão do sistema era: escolher marca, status e período, abrir um produto,
 * voltar — e reencontrar tudo zerado. Quem trabalha na mesma fatia do catálogo
 * o dia inteiro refazia a mesma seleção dezenas de vezes por dia, e o filtro
 * deixava de ser ferramenta para virar pedágio.
 *
 * Guarda em `localStorage`, não em `sessionStorage`: o pedido é lembrar "até
 * vir a próxima mudança", e sessão morre ao fechar a aba. O que a pessoa
 * escolheu na sexta continua lá na segunda.
 *
 * Assinatura igual à do `useState` de propósito — trocar um call site é
 * acrescentar uma chave, não reescrever a tela.
 *
 *   const [status, setStatus] = useMemoriaDeFiltro("catalogo:status", "TODOS")
 *
 * ## O que NÃO deve usar isto
 *
 * Campo de busca dentro de dropdown ou diálogo (o "filtrar marca" que aparece
 * ao abrir o menu, a busca de produto dentro do modal). Lembrar ali reabre o
 * menu já filtrado por algo digitado semanas atrás, sem nada na tela
 * explicando por que a lista está curta. Filtro que molda a lista da página
 * é lembrado; caixinha de busca efêmera de widget, não.
 */

const PREFIXO = "controllares:filtro:"

export function useMemoriaDeFiltro<T>(
  chave: string,
  inicial: T,
  opcoes?: {
    /**
     * "O valor inicial é intenção explícita, não padrão — não restaure por
     * cima dele."
     *
     * Existe por causa dos filtros que nascem da URL (`?status=ACEITA`, o
     * link que o painel monta). Sem isto, abrir esse link restauraria o
     * filtro guardado por cima e a pessoa cairia numa lista que não é a que
     * ela pediu — o deep link viraria decoração. O valor da URL ainda é
     * gravado: a próxima visita sem parâmetro reencontra ele.
     */
    preferirInicial?: boolean
  },
) {
  const preferirInicial = opcoes?.preferirInicial ?? false
  const [valor, setValor] = useState<T>(inicial)

  /* Bandeira em estado, não em ref, e isso é o ponto delicado do hook.
     Componente cliente também renderiza no servidor, então ler o storage
     durante o render quebraria a hidratação: o HTML do servidor viria com o
     padrão e o cliente com o guardado. Por isso a leitura acontece depois de
     montar.
     Só que os dois efeitos rodam na MESMA passada, em ordem de declaração: se
     a bandeira fosse `ref`, o efeito de gravar já a veria ligada e escreveria
     o valor antigo (o padrão, que ainda não foi re-renderizado) por cima do
     que acabou de ser lido — apagando a memória exatamente ao restaurá-la.
     Como estado, ela só fica verdadeira no próximo render, quando `valor` já
     é o valor certo. */
  const [hidratado, setHidratado] = useState(false)

  useEffect(() => {
    if (preferirInicial) { setHidratado(true); return }
    try {
      const bruto = localStorage.getItem(PREFIXO + chave)
      if (bruto !== null) setValor(JSON.parse(bruto) as T)
    } catch {
      /* Storage bloqueado (aba anônima, cota cheia, política do navegador):
         a tela funciona com o padrão. Filtro não lembrar é chato; filtro
         derrubar a página é inaceitável. */
    }
    setHidratado(true)
  }, [chave])

  useEffect(() => {
    if (!hidratado) return
    try {
      localStorage.setItem(PREFIXO + chave, JSON.stringify(valor))
    } catch { /* idem */ }
  }, [chave, valor, hidratado])

  return [valor, setValor] as const
}
