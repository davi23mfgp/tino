"use client"

import { useEffect, useRef } from "react"
import { usePathname } from "next/navigation"

/**
 * Devolve a página ao ponto em que ela estava.
 *
 * O sistema tem dois jeitos de perder o lugar do usuário, e os dois doem no
 * mesmo momento — quando ele clica no lápis do 80º produto:
 *
 *   1. Ele navega para outra rota e volta. O painel monta vazio e a rolagem
 *      nasce em zero.
 *   2. Ele nem sai da rota: salva o formulário, a lista recarrega, o conteúdo
 *      vira um spinner de uma linha, o container encolhe e o navegador zera a
 *      rolagem. Quando a lista volta, a posição já se perdeu.
 *
 * Um mecanismo só resolve os dois, porque a regra que separa "o usuário rolou"
 * de "o conteúdo sumiu" é a mesma: **rolagem só conta como intenção do usuário
 * quando o conteúdo é alto o bastante para sustentá-la.** Se a lista encolheu
 * para 200 px, o `scrollTop = 0` que o navegador impôs não é decisão de
 * ninguém, e por isso é ignorado. Quando o conteúdo volta a crescer, o alvo
 * guardado é reaplicado.
 *
 * A posição vai para `sessionStorage` por chave, então sobrevive também a
 * recarga de página e ao botão voltar.
 *
 * Duas portas de entrada:
 *   - `useMemoriaDeRolagem(ref)` — o painel inteiro, ligado uma vez no layout.
 *   - `data-lembrar-rolagem="itens"` num elemento que rola por conta própria —
 *     as listas internas (itens da proposta, produtos do ambiente), que o
 *     painel não enxerga porque a barra de rolagem é delas, não dele.
 */

const CHAVE = "controllares:rolagem"
/** Tempo máximo esperando o conteúdo voltar a caber o alvo. */
const PACIENCIA_MS = 4000

function lerMapa(): Record<string, number> {
  try { return JSON.parse(sessionStorage.getItem(CHAVE) || "{}") } catch { return {} }
}

function guardar(chave: string, topo: number) {
  try {
    const m = lerMapa()
    if (topo > 0) m[chave] = topo
    else delete m[chave]
    sessionStorage.setItem(CHAVE, JSON.stringify(m))
  } catch { /* sessionStorage bloqueado: a memória só deixa de existir */ }
}

/**
 * Põe um elemento sob memória e devolve como desligá-la.
 *
 * É o mesmo corpo para o painel e para as listas internas — o que muda entre
 * eles é só quem chama.
 */
function vigiar(el: HTMLElement, chave: string): () => void {
  let alvo = lerMapa()[chave] ?? 0
  let vivo = true
  const limite = Date.now() + PACIENCIA_MS

  /** Cabe o alvo? Só então a rolagem tem sentido. */
  const comporta = (topo: number) => el.scrollHeight - el.clientHeight >= topo - 1

  const restaurar = () => {
    if (!vivo || alvo <= 0) return
    if (comporta(alvo) && Math.abs(el.scrollTop - alvo) > 1) el.scrollTop = alvo
  }

  /* O conteúdo chega em etapas — spinner, dados, imagens —, então tentar uma
     vez só erra. Tenta a cada quadro até o alvo grudar ou a paciência acabar. */
  const insistir = () => {
    if (!vivo) return
    restaurar()
    if (Date.now() < limite) requestAnimationFrame(insistir)
  }
  requestAnimationFrame(insistir)

  const aoRolar = () => {
    /* Rolagem com conteúdo curto é o navegador zerando, não o usuário. */
    if (!comporta(alvo)) return
    alvo = el.scrollTop
    guardar(chave, alvo)
  }
  el.addEventListener("scroll", aoRolar, { passive: true })

  /* Quando a lista volta depois do spinner, o container cresce: é a deixa para
     reaplicar o alvo, mesmo passado o tempo da montagem. */
  const observador = new ResizeObserver(() => restaurar())
  observador.observe(el)
  if (el.firstElementChild) observador.observe(el.firstElementChild)

  return () => {
    vivo = false
    observador.disconnect()
    el.removeEventListener("scroll", aoRolar)
    guardar(chave, el.scrollTop)
  }
}

/** O painel do dashboard — o container que rola a página inteira. */
export function useMemoriaDeRolagem(ref: React.RefObject<HTMLElement | null>) {
  const pathname = usePathname()

  useEffect(() => {
    const el = ref.current
    if (!el) return
    return vigiar(el, `pagina:${pathname}`)
  }, [pathname, ref])
}

/**
 * As listas que rolam por dentro.
 *
 * Uma lista de itens dentro de um cartão tem barra de rolagem própria: o painel
 * pode estar parado no mesmo pixel e mesmo assim o usuário perde o item, porque
 * quem voltou ao topo foi a lista. Elas se anunciam com
 * `data-lembrar-rolagem="<nome>"`, e são encontradas sozinhas — inclusive as
 * que só aparecem depois, quando um diálogo abre ou uma aba troca.
 */
export function useMemoriaDeRolagemInterna() {
  const pathname = usePathname()
  const ligados = useRef(new Map<Element, () => void>())

  useEffect(() => {
    const mapa = ligados.current

    const varrer = () => {
      const achados = new Set<Element>()
      for (const el of document.querySelectorAll<HTMLElement>("[data-lembrar-rolagem]")) {
        achados.add(el)
        if (mapa.has(el)) continue
        mapa.set(el, vigiar(el, `interna:${pathname}:${el.dataset.lembrarRolagem}`))
      }
      /* Elemento que saiu do DOM leva junto seu ouvinte — sem isto, trocar de
         aba dez vezes deixa dez observadores vivos apontando para o nada. */
      for (const [el, desligar] of mapa) {
        if (!achados.has(el)) { desligar(); mapa.delete(el) }
      }
    }

    varrer()
    const mo = new MutationObserver(varrer)
    mo.observe(document.body, { childList: true, subtree: true })

    return () => {
      mo.disconnect()
      for (const desligar of mapa.values()) desligar()
      mapa.clear()
    }
  }, [pathname])
}
