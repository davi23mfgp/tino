"use client"

import { useState } from "react"
import { Plus, Check } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export interface ChecklistTecnicoItem {
  id: string
  texto: string
  feito: boolean
  origem: "PROJETO" | "OBRA"
}

const ORIGEM_CORES: Record<string, string> = {
  PROJETO: "bg-ios-purple/10 text-ios-purple",
  OBRA: "bg-ios-blue/10 text-ios-blue",
}

/**
 * Checklist do responsável técnico — vive em Obra.checklist_tecnico.
 * Itens marcados com origem Projeto ou Obra; pendências agregadas no
 * dashboard do Operacional.
 */
export function ChecklistTecnico({ obraId, initial }: { obraId: string; initial: ChecklistTecnicoItem[] }) {
  const [itens, setItens] = useState<ChecklistTecnicoItem[]>(initial)
  const [novo, setNovo] = useState("")
  const [origem, setOrigem] = useState<"PROJETO" | "OBRA">("OBRA")

  async function save(list: ChecklistTecnicoItem[]) {
    setItens(list)
    await fetch(`/api/obras/${obraId}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ checklist_tecnico: list }),
    })
  }

  function add() {
    if (!novo.trim()) return
    save([...itens, { id: crypto.randomUUID(), texto: novo.trim(), feito: false, origem }])
    setNovo("")
  }

  const pendentes = itens.filter(i => !i.feito).length

  return (
    <div className="bg-card rounded-2xl border border-border p-5 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-foreground font-medium text-[15px]">Checklist técnico</h3>
        {itens.length > 0 && (
          <span className="text-xs text-muted-foreground">
            {pendentes === 0 ? "Tudo concluído" : `${pendentes} pendente${pendentes > 1 ? "s" : ""}`}
          </span>
        )}
      </div>

      {itens.length === 0 && <p className="text-muted-foreground/60 text-sm">Nenhum item ainda.</p>}

      <div className="space-y-1.5">
        {itens.map(item => (
          <div key={item.id} className="flex items-center gap-2.5 group">
            <button onClick={() => save(itens.map(c => c.id === item.id ? { ...c, feito: !c.feito } : c))}
              className={`w-5 h-5 rounded-md border flex items-center justify-center flex-shrink-0 transition-colors ${
                item.feito ? "bg-ios-blue border-ios-blue text-background" : "border-border hover:border-ios-blue/50"
              }`}>
              {item.feito && <Check className="w-3.5 h-3.5" strokeWidth={2.5} />}
            </button>
            <span className={`flex-1 text-sm ${item.feito ? "line-through text-muted-foreground/50" : "text-foreground"}`}>{item.texto}</span>
            <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded-full flex-shrink-0 ${ORIGEM_CORES[item.origem] ?? ""}`}>
              {item.origem === "PROJETO" ? "Projeto" : "Obra"}
            </span>
            <button onClick={() => save(itens.filter(c => c.id !== item.id))}
              className="opacity-0 group-hover:opacity-100 text-muted-foreground/50 hover:text-destructive transition-all text-xs flex-shrink-0">✕</button>
          </div>
        ))}
      </div>

      <div className="flex gap-2">
        <select value={origem} onChange={e => setOrigem(e.target.value as "PROJETO" | "OBRA")}
          className="h-9 px-2 rounded-xl bg-muted border border-border text-foreground text-xs outline-none flex-shrink-0">
          <option value="OBRA">Obra</option>
          <option value="PROJETO">Projeto</option>
        </select>
        <Input value={novo} onChange={e => setNovo(e.target.value)}
          onKeyDown={e => e.key === "Enter" && add()}
          placeholder="Novo item... (Enter adiciona)" className="h-9 text-sm" />
        <Button variant="outline" size="sm" className="h-9 flex-shrink-0" disabled={!novo.trim()} onClick={add}>
          <Plus className="w-4 h-4" />
        </Button>
      </div>
    </div>
  )
}
