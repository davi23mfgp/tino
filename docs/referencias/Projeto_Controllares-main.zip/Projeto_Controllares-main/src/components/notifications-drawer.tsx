"use client"

import { useState, useEffect, useCallback } from "react"
import { createPortal } from "react-dom"
import { Bell, X, CheckCircle, Eye, Clock, FileText, Check } from "lucide-react"

interface Notification {
  id: string
  endpoint: string
  label: string
  payload_json: Record<string, unknown> | null
  reenviado: boolean
  createdAt: string
}

export function NotificationsDrawer() {
  const [open, setOpen] = useState(false)
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [activeTab, setActiveTab] = useState<"all" | "unread">("all")
  const [mounted, setMounted] = useState(false)
  useEffect(() => { setMounted(true) }, [])

  const fetchNotifications = useCallback(async () => {
    try {
      const res = await fetch("/api/notificacoes?limit=50")
      if (res.ok) {
        const data = await res.json()
        setNotifications(data.notifications || [])
      }
    } catch {
      // silently fail
    }
  }, [])

  useEffect(() => {
    fetchNotifications()
    /* 5 s, e não 30: notificação que chega meio minuto depois do fato perde a
       razão de existir. Aba em segundo plano não busca — o sino só interessa
       para quem está olhando a tela. */
    const buscar = () => { if (!document.hidden) fetchNotifications() }
    const interval = setInterval(buscar, 5_000)
    document.addEventListener("visibilitychange", buscar)
    return () => {
      clearInterval(interval)
      document.removeEventListener("visibilitychange", buscar)
    }
  }, [fetchNotifications])

  const unreadCount = notifications.filter(n => !n.reenviado).length

  async function markAllRead() {
    await fetch("/api/notificacoes", { method: "PATCH" })
    fetchNotifications()
  }

  async function clearAll() {
    await fetch("/api/notificacoes", { method: "DELETE" })
    setNotifications([])
  }

  async function markOneRead(id: string) {
    await fetch(`/api/notificacoes/${id}`, { method: "PATCH" })
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, reenviado: true } : n))
  }

  const shown = activeTab === "unread" ? notifications.filter(n => !n.reenviado) : notifications

  function getIcon(endpoint: string) {
    if (endpoint.includes("aceita")) return <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
    if (endpoint.includes("visualizada")) return <Eye className="w-4 h-4 text-blue-500 flex-shrink-0" />
    if (endpoint.includes("revisao")) return <Clock className="w-4 h-4 text-yellow-500 flex-shrink-0" />
    return <FileText className="w-4 h-4 text-muted-foreground flex-shrink-0" />
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="ios-tap relative flex items-center justify-center h-9 w-9 rounded-full bg-foreground/[0.06] hover:bg-foreground/[0.09] text-muted-foreground hover:text-foreground"
        aria-label="Notificações"
      >
        <Bell className="w-4.5 h-4.5" style={{ width: "18px", height: "18px" }} />
        {unreadCount > 0 && (
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full ring-2 ring-background" />
        )}
      </button>

      {open && mounted && createPortal(
        <div className="fixed inset-0 z-[999] flex justify-end p-3 md:p-4">
          <div className="absolute inset-0 bg-black/30 backdrop-blur-[6px]" onClick={() => setOpen(false)} />
          {/* Painel flutuante estilo iOS — card destacado, cantos largos */}
          <div className="relative w-[360px] max-w-[calc(100vw-24px)] h-full rounded-[24px] bg-surface-1 border border-hairline flex flex-col shadow-2xl shadow-black/40 overflow-hidden animate-in slide-in-from-right-4 fade-in duration-200">
            {/* Header — título grande estilo Apple */}
            <div className="px-5 pt-5 pb-3">
              <div className="flex items-start justify-between">
                <h2 className="text-[22px] font-bold text-foreground tracking-tight leading-none">Notificações</h2>
                <button
                  onClick={() => setOpen(false)}
                  className="w-7 h-7 rounded-full bg-surface-2 flex items-center justify-center text-muted-fg hover:text-foreground transition-colors -mt-0.5"
                  aria-label="Fechar"
                >
                  <X className="w-3.5 h-3.5" strokeWidth={2.5} />
                </button>
              </div>
              {/* Segmented control iOS */}
              <div className="flex mt-4 p-0.5 rounded-xl bg-surface-2 gap-0.5">
                {(["all", "unread"] as const).map(tab => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`flex-1 py-1.5 text-[13px] font-medium rounded-[10px] transition-all ${
                      activeTab === tab
                        ? "bg-surface-1 text-foreground shadow-sm shadow-black/20"
                        : "text-muted-fg hover:text-foreground"
                    }`}
                  >
                    {tab === "all" ? "Todas" : `Não lidas${unreadCount > 0 ? ` · ${unreadCount}` : ""}`}
                  </button>
                ))}
              </div>
            </div>

            {/* List — cards com respiro, sem divisores duros */}
            <div className="flex-1 overflow-y-auto px-3 pb-3 space-y-1.5" style={{ scrollbarWidth: "none" }}>
              {shown.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-48 text-muted-fg gap-3">
                  <div className="w-12 h-12 rounded-full bg-surface-2 flex items-center justify-center">
                    <Bell className="w-5 h-5 opacity-40" />
                  </div>
                  <span className="text-[13px]">Nenhuma notificação</span>
                </div>
              ) : (
                shown.map(n => (
                  <div
                    key={n.id}
                    className={`rounded-2xl px-3.5 py-3 transition-colors ${
                      !n.reenviado ? "bg-surface-2" : "bg-transparent hover:bg-surface-2/50"
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full bg-surface-3 flex items-center justify-center flex-shrink-0">
                        {getIcon(n.endpoint)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline justify-between gap-2">
                          <p className={`text-[13px] truncate leading-snug ${!n.reenviado ? "font-semibold text-foreground" : "text-foreground/75"}`}>
                            {n.label}
                          </p>
                          <span className="text-[11px] text-muted-fg/70 flex-shrink-0">
                            {new Date(n.createdAt).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })}
                          </span>
                        </div>
                        {n.payload_json && (
                          <p className="text-[12px] text-muted-fg truncate mt-0.5">
                            {(n.payload_json as { client_name?: string; numero?: string }).client_name ||
                              (n.payload_json as { client_name?: string; numero?: string }).numero || ""}
                          </p>
                        )}
                      </div>
                      {!n.reenviado && (
                        <button
                          onClick={() => markOneRead(n.id)}
                          title="Marcar como lida"
                          className="flex-shrink-0 w-6 h-6 rounded-full bg-ios-blue/10 flex items-center justify-center text-ios-blue hover:bg-ios-blue/20 transition-colors"
                        >
                          <Check className="w-3 h-3" strokeWidth={2.5} />
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Footer — ações discretas */}
            {notifications.length > 0 && (
              <div className="px-4 py-3 border-t border-hairline flex gap-2">
                {unreadCount > 0 && (
                  <button onClick={markAllRead}
                    className="flex-1 py-2 rounded-xl text-[13px] font-medium text-ios-blue hover:bg-ios-blue/10 transition-colors">
                    Marcar todas lidas
                  </button>
                )}
                <button onClick={clearAll}
                  className="flex-1 py-2 rounded-xl text-[13px] font-medium text-ios-red hover:bg-ios-red/10 transition-colors">
                  Limpar tudo
                </button>
              </div>
            )}
          </div>
        </div>,
        document.body
      )}
    </>
  )
}
