"use client"

import { useEffect } from "react"

export function PwaRegister() {
  useEffect(() => {
    if (typeof window === "undefined") return
    if (!("serviceWorker" in navigator)) return
    if (process.env.NODE_ENV === "development") return

    navigator.serviceWorker
      .register("/sw.js", { scope: "/" })
      .then(reg => {
        // Verifica atualizações a cada 60s em background
        setInterval(() => reg.update(), 60_000)
      })
      .catch(() => {})
  }, [])

  return null
}
