"use client"

import { ChevronLeft, ChevronRight, X } from "lucide-react"

const MESES = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"]
const MESES_FULL = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]

interface Props {
  value: string   // YYYY-MM ou ""
  onChange: (v: string) => void
  placeholder?: string
}

export function MonthPicker({ value, onChange, placeholder = "Mês" }: Props) {
  const now = new Date()
  const selYear = value ? parseInt(value.slice(0, 4)) : now.getFullYear()
  const selMonth = value ? parseInt(value.slice(5, 7)) - 1 : -1

  function setYear(delta: number) {
    const year = selYear + delta
    if (value) onChange(`${year}-${value.slice(5)}`)
    else onChange(`${year}-${String(now.getMonth() + 1).padStart(2, "0")}`)
  }

  function pickMonth(m: number) {
    const month = String(m + 1).padStart(2, "0")
    onChange(`${selYear}-${month}`)
  }

  const label = value
    ? `${MESES_FULL[selMonth]} ${selYear}`
    : placeholder

  return (
    <div className="relative group">
      <div className="flex items-center gap-1 h-9 px-3 rounded-xl bg-slate-800 border border-slate-700 hover:border-slate-500 text-sm text-white cursor-pointer select-none min-w-[160px]">
        <span className={`flex-1 truncate ${value ? "text-white" : "text-slate-500"}`}>{label}</span>
        {value && (
          <button
            type="button"
            onClick={e => { e.stopPropagation(); onChange("") }}
            className="text-slate-500 hover:text-white transition-colors flex-shrink-0"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Dropdown */}
      <div className="absolute top-full mt-1 left-0 z-50 hidden group-focus-within:block group-hover:block bg-slate-900 border border-slate-700 rounded-xl shadow-xl p-3 w-52">
        {/* Ano */}
        <div className="flex items-center justify-between mb-3">
          <button type="button" onClick={() => setYear(-1)}
            className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors">
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-white font-semibold text-sm">{selYear}</span>
          <button type="button" onClick={() => setYear(1)}
            className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors">
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Grade de meses */}
        <div className="grid grid-cols-4 gap-1">
          {MESES.map((m, i) => (
            <button
              key={m}
              type="button"
              onClick={() => pickMonth(i)}
              className={`py-1.5 rounded-lg text-xs font-medium transition-all ${
                selMonth === i && selYear === parseInt(value?.slice(0, 4) || "0")
                  ? "bg-sky-600 text-white"
                  : i === now.getMonth() && selYear === now.getFullYear()
                  ? "border border-sky-500/40 text-sky-300 hover:bg-sky-600 hover:text-white"
                  : "text-slate-400 hover:bg-slate-700 hover:text-white"
              }`}
            >
              {m}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
