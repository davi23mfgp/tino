"use client"

/**
 * Dados de faturamento da proposta.
 *
 * Preenchidos antes de enviar ao Olist. Sem eles a nota é recusada lá, e
 * descobrir o porquê custa mais tempo do que preencher aqui.
 *
 * CEP e CNPJ são consultados automaticamente — quem digita informa o número e
 * o resto vem preenchido. O preenchimento manual continua possível: serviço
 * externo cai, e a obra não pode parar por isso.
 */
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Loader2, Search, CheckCircle2, AlertCircle } from "lucide-react"
import {
  soDigitos, tipoDocumento, formatarDocumento, formatarCEP,
  type EnderecoCEP, type DadosCNPJ,
} from "@/lib/documento"

export interface DadosFat {
  fat_razao_social: string
  fat_documento: string
  fat_ie: string
  fat_email: string
  fat_nascimento: string
  fat_cep: string; fat_logradouro: string; fat_numero: string
  fat_complemento: string; fat_bairro: string; fat_cidade: string; fat_uf: string
  obra_cep: string; obra_logradouro: string; obra_numero: string
  obra_complemento: string; obra_bairro: string; obra_cidade: string; obra_uf: string
}

export const DADOS_FAT_VAZIO: DadosFat = {
  fat_razao_social: "", fat_documento: "", fat_ie: "", fat_email: "", fat_nascimento: "",
  fat_cep: "", fat_logradouro: "", fat_numero: "", fat_complemento: "",
  fat_bairro: "", fat_cidade: "", fat_uf: "",
  obra_cep: "", obra_logradouro: "", obra_numero: "", obra_complemento: "",
  obra_bairro: "", obra_cidade: "", obra_uf: "",
}

/* A regra de "completo" mora em lib/faturamento — o servidor precisa dela para
   recusar a geração do contrato, e uma cópia aqui já significaria botão ativo
   com rota reclamando (ou pior, o contrário). Reexportada para as telas que já
   a importavam daqui. */
export { faturamentoCompleto, faltaNoFaturamento } from "@/lib/faturamento"

const campo =
  "h-10 w-full rounded-xl border border-border bg-muted px-3 text-sm text-foreground placeholder:text-muted-foreground/60 focus:border-primary/60 focus:outline-none focus:ring-1 focus:ring-primary/40"

function Campo({ label, children, className = "" }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <label className={`block space-y-1 ${className}`}>
      <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">{label}</span>
      {children}
    </label>
  )
}

export function DadosFaturamento({ dados, onChange, somenteLeitura }: {
  dados: DadosFat
  onChange: (d: DadosFat) => void
  somenteLeitura?: boolean
}) {
  const [buscandoCep, setBuscandoCep] = useState<"fat" | "obra" | null>(null)
  const [buscandoCnpj, setBuscandoCnpj] = useState(false)
  const [aviso, setAviso] = useState<{ tipo: "ok" | "erro"; texto: string } | null>(null)
  /* O que a Receita respondeu, guardado para conferência. Não vira cadastro —
     é o que permite reconhecer a empresa antes de emitir a nota. */
  const [empresa, setEmpresa] = useState<DadosCNPJ | null>(null)

  /* Pessoa física ou jurídica é escolha explícita, não dedução do que foi
     digitado. Antes o formulário só descobria o tipo depois do documento
     inteiro e válido: até lá a máscara aceitava 14 dígitos para todo mundo e o
     rótulo dizia "Razão social" para quem estava preenchendo um CPF. */
  const [ehPF, setEhPF] = useState(() => soDigitos(dados.fat_documento).length === 11)
  const setTipo = (pf: boolean) => {
    setEhPF(pf)
    setAviso(null)
    setEmpresa(null)
    // Documento do outro tipo não sobrevive à troca — 11 dígitos num campo de
    // CNPJ é sempre inválido, e deixar lá só gera erro de validação.
    const d = soDigitos(dados.fat_documento)
    const patch: Partial<DadosFat> = {}
    if (d && d.length !== (pf ? 11 : 14)) patch.fat_documento = ""
    if (pf) patch.fat_nascimento = dados.fat_nascimento
    else patch.fat_nascimento = ""
    onChange({ ...dados, ...patch })
  }

  const set = (patch: Partial<DadosFat>) => onChange({ ...dados, ...patch })
  const tipoDoc = dados.fat_documento ? tipoDocumento(dados.fat_documento) : null
  const maxDigitos = ehPF ? 11 : 14

  async function buscarCep(qual: "fat" | "obra") {
    const cep = soDigitos(qual === "fat" ? dados.fat_cep : dados.obra_cep)
    if (cep.length !== 8) { setAviso({ tipo: "erro", texto: "CEP precisa ter 8 dígitos." }); return }
    setBuscandoCep(qual); setAviso(null)
    try {
      const r = await fetch(`/api/consulta?cep=${cep}`)
      const j = await r.json()
      if (!r.ok) { setAviso({ tipo: "erro", texto: j.error || "CEP não encontrado." }); return }
      const e: EnderecoCEP = j.endereco
      if (qual === "fat") {
        set({ fat_logradouro: e.logradouro, fat_bairro: e.bairro, fat_cidade: e.cidade, fat_uf: e.uf })
      } else {
        set({ obra_logradouro: e.logradouro, obra_bairro: e.bairro, obra_cidade: e.cidade, obra_uf: e.uf })
      }
      setAviso({ tipo: "ok", texto: "Endereço preenchido. Falta o número." })
    } catch {
      setAviso({ tipo: "erro", texto: "Consulta indisponível. Preencha manualmente." })
    } finally { setBuscandoCep(null) }
  }

  /* Ao completar o CNPJ o formulário busca sozinho — quem digita não deveria
     precisar descobrir que existe um botão para o nome aparecer. */
  function aoDigitarDocumento(valor: string) {
    const d = soDigitos(valor).slice(0, maxDigitos)
    set({ fat_documento: d })
    /* Documento mudou: a empresa mostrada é de outro CNPJ. Deixar na tela
       enquanto se digita o próximo faria conferir a empresa errada. */
    setEmpresa(null)
    if (!ehPF && d.length === 14 && tipoDocumento(d) === "CNPJ") buscarCnpj(d)
  }

  async function buscarCnpj(documento?: string) {
    const cnpj = soDigitos(documento ?? dados.fat_documento)
    if (cnpj.length !== 14) { setAviso({ tipo: "erro", texto: "Informe um CNPJ para buscar." }); return }
    setBuscandoCnpj(true); setAviso(null)
    try {
      const r = await fetch(`/api/consulta?cnpj=${cnpj}`)
      const j = await r.json()
      if (!r.ok) { setAviso({ tipo: "erro", texto: j.error || "CNPJ não encontrado." }); return }
      const d: DadosCNPJ = j.dados
      setEmpresa(d)

      /* A razão social da Receita vale mais que o que estava no campo: ali
         costuma estar o nome de quem conversou com o vendedor, e a nota sai no
         nome da empresa. Por isso sobrescreve.

         Os demais campos só entram quando vêm preenchidos: consulta que não
         traz o e-mail não deve apagar o e-mail que alguém digitou à mão. */
      const seVier = (valor: string | null | undefined, atual: string) =>
        valor?.trim() ? valor : atual

      set({
        /* O documento vai junto no mesmo patch.

           A busca dispara de dentro do onChange, antes do React aplicar o
           `set` do documento — então o `dados` visto aqui ainda é o de antes
           de digitar. Sem reafirmar o CNPJ, este patch gravava por cima com o
           valor antigo e desfazia o que a pessoa acabou de digitar. */
        fat_documento: cnpj,
        fat_razao_social: d.razao_social?.trim() || dados.fat_razao_social,
        fat_email: seVier(d.email, dados.fat_email),
        fat_cep: d.cep ? formatarCEP(d.cep) : dados.fat_cep,
        fat_logradouro: seVier(d.logradouro, dados.fat_logradouro),
        fat_numero: seVier(d.numero, dados.fat_numero),
        fat_complemento: seVier(d.complemento, dados.fat_complemento),
        fat_bairro: seVier(d.bairro, dados.fat_bairro),
        fat_cidade: seVier(d.cidade, dados.fat_cidade),
        fat_uf: seVier(d.uf, dados.fat_uf),
      })

      /* A confirmação diz o nome encontrado, não "pronto". Quem digitou o CNPJ
         precisa reconhecer a empresa — número errado que existe na Receita
         preenche tudo sem erro nenhum, e só o nome denuncia. */
      const irregular = !!d.situacao && d.situacao.toUpperCase() !== "ATIVA"
      const razao = d.razao_social?.trim()
      setAviso({
        tipo: irregular ? "erro" : "ok",
        texto: irregular
          // Situação irregular não bloqueia, mas quem fatura precisa saber.
          ? `${razao ?? "Empresa encontrada"} — atenção: situação cadastral "${d.situacao}".`
          : razao
            ? `CNPJ válido · ${razao}`
            : "CNPJ válido.",
      })
    } catch {
      setAviso({ tipo: "erro", texto: "Consulta indisponível. Preencha manualmente." })
    } finally { setBuscandoCnpj(false) }
  }

  function copiarEnderecoFat() {
    set({
      obra_cep: dados.fat_cep, obra_logradouro: dados.fat_logradouro,
      obra_numero: dados.fat_numero, obra_complemento: dados.fat_complemento,
      obra_bairro: dados.fat_bairro, obra_cidade: dados.fat_cidade, obra_uf: dados.fat_uf,
    })
  }

  const ro = !!somenteLeitura

  return (
    <div className="space-y-5">
      {/* Identificação */}
      <div className="space-y-3">
        <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
          Quem será faturado
        </p>

        <div className="inline-flex rounded-xl border border-border bg-muted p-0.5 text-[13px]">
          {([["CPF", true], ["CNPJ", false]] as const).map(([rotulo, pf]) => (
            <button key={rotulo} type="button" disabled={ro} onClick={() => setTipo(pf)}
              className={`rounded-[10px] px-3.5 py-1.5 transition-colors ${
                ehPF === pf ? "bg-background font-medium text-foreground shadow-sm" : "text-muted-foreground"
              }`}>
              {rotulo}
            </button>
          ))}
        </div>

        <Campo label="Documento">
          <div className="flex gap-2">
            <input
              value={formatarDocumento(dados.fat_documento)}
              onChange={e => aoDigitarDocumento(e.target.value)}
              placeholder={ehPF ? "000.000.000-00" : "00.000.000/0001-00"}
              inputMode="numeric" disabled={ro}
              className={`${campo} ${tipoDoc === "INVALIDO" && soDigitos(dados.fat_documento).length >= maxDigitos ? "border-destructive" : ""}`}
            />
            {!ro && !ehPF && soDigitos(dados.fat_documento).length === 14 && (
              <Button type="button" variant="outline" size="sm" onClick={() => buscarCnpj()}
                disabled={buscandoCnpj} className="shrink-0 gap-1.5">
                {buscandoCnpj ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Search className="h-3.5 w-3.5" />}
                Buscar
              </Button>
            )}
          </div>
          {tipoDoc === "INVALIDO" && soDigitos(dados.fat_documento).length >= maxDigitos && (
            <span className="text-[12px] text-destructive">
              {ehPF ? "CPF" : "CNPJ"} inválido — confira os dígitos.
            </span>
          )}
          {tipoDoc === (ehPF ? "CPF" : "CNPJ") && (
            <span className="text-[12px] text-muted-foreground">
              {ehPF ? "CPF válido" : buscandoCnpj ? "Buscando dados da empresa..." : "CNPJ válido"}
            </span>
          )}
        </Campo>

        {/* Confirmação da empresa encontrada.

            Existe porque CNPJ errado que existe na Receita preenche o formulário
            inteiro sem erro nenhum — só o nome e a atividade denunciam. E porque
            Simples e MEI mudam a tributação da nota: quem emite precisa ver isso
            antes, não descobrir depois pelo contador. Nada aqui é salvo. */}
        {!ehPF && empresa && (
          <div className="rounded-xl border border-border bg-muted/40 p-3 space-y-1.5">
            <p className="text-[13px] font-medium text-foreground">
              {empresa.razao_social}
              {empresa.nome_fantasia && empresa.nome_fantasia !== empresa.razao_social && (
                <span className="text-muted-foreground font-normal"> · {empresa.nome_fantasia}</span>
              )}
            </p>

            <div className="flex flex-wrap gap-x-3 gap-y-1 text-[12px] text-muted-foreground">
              {empresa.situacao && (
                <span className={empresa.situacao.toUpperCase() === "ATIVA" ? "text-ios-green" : "text-destructive"}>
                  {empresa.situacao}
                </span>
              )}
              {empresa.simples !== null && empresa.simples !== undefined && (
                <span className={empresa.simples ? "text-ios-blue" : undefined}>
                  {empresa.mei ? "MEI" : empresa.simples ? "Simples Nacional" : "Regime normal"}
                </span>
              )}
              {empresa.porte && <span>{empresa.porte.toLowerCase()}</span>}
              {empresa.abertura && (
                <span>desde {new Date(empresa.abertura).toLocaleDateString("pt-BR")}</span>
              )}
              {empresa.telefone && <span>{empresa.telefone}</span>}
            </div>

            {empresa.atividade && (
              <p className="text-[12px] leading-relaxed text-muted-foreground">{empresa.atividade}</p>
            )}
            {!!empresa.socios?.length && (
              <p className="text-[12px] text-muted-foreground">
                Sócios: {empresa.socios.join(", ")}
              </p>
            )}
          </div>
        )}

        <Campo label={ehPF ? "Nome completo" : "Razão social"}>
          <input value={dados.fat_razao_social} disabled={ro}
            onChange={e => set({ fat_razao_social: e.target.value })}
            placeholder={ehPF ? "Nome como está no documento" : "Preenchido pelo CNPJ"}
            className={campo} />
        </Campo>

        <div className="grid gap-3 sm:grid-cols-2">
          <Campo label="E-mail">
            <input type="email" value={dados.fat_email} disabled={ro}
              onChange={e => set({ fat_email: e.target.value })}
              placeholder="para envio da nota" className={campo} />
          </Campo>
          {/* Data de nascimento só faz sentido para pessoa física. */}
          {ehPF && (
            <Campo label="Data de nascimento">
              <input type="date" value={dados.fat_nascimento} disabled={ro}
                onChange={e => set({ fat_nascimento: e.target.value })} className={campo} />
            </Campo>
          )}
        </div>

        {/* Inscrição estadual: define o enquadramento do destinatário na nota.
            Vazio em empresa significa isento — não é campo esquecido. */}
        {!ehPF && (
          <Campo label="Inscrição estadual">
            <input value={dados.fat_ie} disabled={ro}
              onChange={e => set({ fat_ie: e.target.value })}
              placeholder="deixe vazio se isento" className={campo} />
          </Campo>
        )}
      </div>

      {/* Endereço de faturamento */}
      <Endereco
        titulo="Endereço de faturamento"
        prefixo="fat"
        dados={dados}
        set={set}
        onBuscarCep={() => buscarCep("fat")}
        buscando={buscandoCep === "fat"}
        ro={ro}
      />

      {/* Endereço da obra */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            Endereço da obra
          </p>
          {!ro && (
            <button type="button" onClick={copiarEnderecoFat}
              className="text-[12px] font-medium text-primary hover:underline">
              Usar o mesmo do faturamento
            </button>
          )}
        </div>
        <Endereco titulo="" prefixo="obra" dados={dados} set={set}
          onBuscarCep={() => buscarCep("obra")} buscando={buscandoCep === "obra"} ro={ro} />
      </div>

      {aviso && (
        <p className={`flex items-center gap-2 text-[13px] ${aviso.tipo === "ok" ? "text-success" : "text-warning"}`}>
          {aviso.tipo === "ok" ? <CheckCircle2 className="h-4 w-4 shrink-0" /> : <AlertCircle className="h-4 w-4 shrink-0" />}
          {aviso.texto}
        </p>
      )}
    </div>
  )
}

function Endereco({ titulo, prefixo, dados, set, onBuscarCep, buscando, ro }: {
  titulo: string
  prefixo: "fat" | "obra"
  dados: DadosFat
  set: (p: Partial<DadosFat>) => void
  onBuscarCep: () => void
  buscando: boolean
  ro: boolean
}) {
  const k = (campo: string) => `${prefixo}_${campo}` as keyof DadosFat
  const v = (campo: string) => String(dados[k(campo)] ?? "")

  return (
    <div className="space-y-3">
      {titulo && (
        <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">{titulo}</p>
      )}

      <div className="grid gap-3 sm:grid-cols-[minmax(0,180px)_minmax(0,1fr)]">
        <Campo label="CEP">
          <div className="flex gap-2">
            <input value={formatarCEP(v("cep"))} disabled={ro}
              onChange={e => set({ [k("cep")]: formatarCEP(e.target.value) } as Partial<DadosFat>)}
              placeholder="00000-000" inputMode="numeric" className={campo} />
            {!ro && (
              <Button type="button" variant="outline" size="sm" onClick={onBuscarCep}
                disabled={buscando} className="shrink-0 gap-1.5">
                {buscando ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Search className="h-3.5 w-3.5" />}
              </Button>
            )}
          </div>
        </Campo>
        <Campo label="Logradouro">
          <input value={v("logradouro")} disabled={ro}
            onChange={e => set({ [k("logradouro")]: e.target.value } as Partial<DadosFat>)}
            placeholder="Rua, avenida..." className={campo} />
        </Campo>
      </div>

      <div className="grid gap-3 sm:grid-cols-[minmax(0,120px)_minmax(0,1fr)]">
        <Campo label="Número">
          <input value={v("numero")} disabled={ro}
            onChange={e => set({ [k("numero")]: e.target.value } as Partial<DadosFat>)}
            placeholder="123" className={campo} />
        </Campo>
        <Campo label="Complemento">
          <input value={v("complemento")} disabled={ro}
            onChange={e => set({ [k("complemento")]: e.target.value } as Partial<DadosFat>)}
            placeholder="Apto, bloco, sala" className={campo} />
        </Campo>
      </div>

      <div className="grid gap-3 sm:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_minmax(0,90px)]">
        <Campo label="Bairro">
          <input value={v("bairro")} disabled={ro}
            onChange={e => set({ [k("bairro")]: e.target.value } as Partial<DadosFat>)} className={campo} />
        </Campo>
        <Campo label="Cidade">
          <input value={v("cidade")} disabled={ro}
            onChange={e => set({ [k("cidade")]: e.target.value } as Partial<DadosFat>)} className={campo} />
        </Campo>
        <Campo label="UF">
          <input value={v("uf")} disabled={ro} maxLength={2}
            onChange={e => set({ [k("uf")]: e.target.value.toUpperCase() } as Partial<DadosFat>)}
            className={`${campo} uppercase`} />
        </Campo>
      </div>
    </div>
  )
}
