﻿"use client"

import { useEffect, useState } from "react"
import { X, Share } from "lucide-react"
import { ehDocumentoDoCliente } from "@/lib/rota-documento"
import { ControlDealLogo } from "@/components/logo"

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>
}

const DISMISSED_KEY = "pwa-install-dismissed"
const DISMISSED_DAYS = 7

export function PwaInstallBanner() {
  const documento = ehDocumentoDoCliente()
  const [show, setShow] = useState(false)
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null)
  const [isIOS, setIsIOS] = useState(false)
  const [isInstalled, setIsInstalled] = useState(false)

  useEffect(() => {
    // Não mostra se já está instalado (standalone)
    if (window.matchMedia("(display-mode: standalone)").matches) {
      setIsInstalled(true)
      return
    }

    // Checa se foi dispensado recentemente
    const dismissed = localStorage.getItem(DISMISSED_KEY)
    if (dismissed) {
      const dismissedAt = parseInt(dismissed, 10)
      if (Date.now() - dismissedAt < DISMISSED_DAYS * 86400000) return
    }

    const ios = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as { MSStream?: unknown }).MSStream
    setIsIOS(ios)

    if (ios) {
      // iOS não suporta beforeinstallprompt — mostra instrução manual após 30s
      const t = setTimeout(() => setShow(true), 30000)
      return () => clearTimeout(t)
    }

    // Android/Chrome: aguarda evento
    const handler = (e: Event) => {
      e.preventDefault()
      setDeferredPrompt(e as BeforeInstallPromptEvent)
      const t = setTimeout(() => setShow(true), 30000)
      return () => clearTimeout(t)
    }
    window.addEventListener("beforeinstallprompt", handler)
    return () => window.removeEventListener("beforeinstallprompt", handler)
  }, [])

  const dismiss = () => {
    setShow(false)
    localStorage.setItem(DISMISSED_KEY, Date.now().toString())
  }

  const install = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt()
      const { outcome } = await deferredPrompt.userChoice
      if (outcome === "accepted") setShow(false)
    }
  }

  /* No documento do cliente não existe convite para instalar aplicativo: o PDF
     que ele imprime sairia com um cartão "Adicionar" no meio da proposta. */
  if (documento) return null
  if (!show || isInstalled) return null

  return (
    <div className="print:hidden md:hidden fixed bottom-0 left-0 right-0 z-[70] animate-in slide-in-from-bottom duration-300">
      {/* Overlay suave */}
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/10 to-transparent h-8 -top-8 pointer-events-none" />

      <div className="bg-white dark:bg-[#1c1c1e] shadow-apple-float mx-3 mb-4 rounded-3xl overflow-hidden">
        {/* Drag handle */}
        <div className="flex justify-center pt-3">
          <div className="w-10 h-1 bg-black/10 dark:bg-white/15 rounded-full" />
        </div>

        <div className="px-5 pt-3 pb-5">
          {/* Ícone + texto */}
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-primary flex items-center justify-center flex-shrink-0">
              <ControlDealLogo size={28} className="text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[15px] font-semibold text-foreground leading-tight">
                Adicione o Controllares
              </p>
              <p className="text-[13px] text-muted-foreground leading-snug mt-0.5">
                {isIOS
                  ? "Toque em compartilhar e depois \"Adicionar à Tela\""
                  : "Acesse mais rápido direto da tela inicial"}
              </p>
            </div>
            <button onClick={dismiss}
              className="flex-shrink-0 w-7 h-7 rounded-full bg-black/[0.06] dark:bg-white/[0.08] flex items-center justify-center text-muted-foreground -mr-1">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Botões */}
          <div className="flex gap-2">
            {isIOS ? (
              <button
                className="flex-1 h-[48px] rounded-xl bg-primary text-primary-foreground font-semibold text-[15px] flex items-center justify-center gap-2 active:opacity-80 transition-opacity">
                <Share className="w-4 h-4" />
                Compartilhar
              </button>
            ) : (
              <button onClick={install}
                className="flex-1 h-[48px] rounded-xl bg-primary text-primary-foreground font-semibold text-[15px] active:opacity-80 transition-opacity">
                Adicionar
              </button>
            )}
            <button onClick={dismiss}
              className="flex-1 h-[48px] rounded-xl bg-black/[0.05] dark:bg-white/[0.08] text-foreground font-medium text-[15px] active:opacity-80 transition-opacity">
              Agora não
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
