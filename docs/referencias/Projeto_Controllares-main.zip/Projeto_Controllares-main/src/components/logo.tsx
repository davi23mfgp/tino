/* eslint-disable @next/next/no-img-element */
// Logo oficial da Controllares — o MESMO arquivo usado no PDF das propostas
// (public/brand/logo.png). Antes o app desenhava uma versão SVG à mão, que não
// batia com a marca real; agora usa o asset oficial em todo lugar.
// Mantém o nome ControlDealLogo para não quebrar os imports existentes.
export function ControlDealLogo({ className = "", size = 48 }: { className?: string; size?: number }) {
  return (
    <img
      src="/brand/logo.png"
      alt="Controllares"
      width={size}
      height={size}
      className={className}
      style={{ objectFit: "contain" }}
    />
  )
}

// Alias com o nome novo, para uso futuro.
export const ControllaresLogo = ControlDealLogo
