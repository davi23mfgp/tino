"use client"

import { useCallback, useEffect, useState } from "react"
import { Package, Check, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { brl } from "@/lib/formato"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog"

/**
 * Cadastro dos itens escritos direto na proposta.
 *
 * Abre no faturamento, quando ainda há item sem produto no catálogo. É o ponto
 * em que a dívida assumida na visita é paga: dali em diante o item vira pedido
 * no Olist, entra no estoque e é comprado, e nada disso encontra o que comprar
 * sem cadastro.
 *
 * É o mesmo modal do cadastro do catálogo — mesma posição no meio da tela,
 * mesmos campos, mesma ordem. Quem cadastra aqui é quem cadastra lá, e duas
 * telas diferentes para o mesmo produto obrigam a reaprender o formulário no
 * meio do faturamento.
 *
 * Dois caminhos, porque são dois casos. Cadastrar é o normal — o item é novo
 * mesmo. Anexar a um produto existente serve para quando o vendedor escreveu
 * com outro nome algo que já estava lá, e cadastrar de novo criaria duplicata
 * no catálogo e no Olist.
 */

interface ItemAvulso {
  id: string
  nome_snapshot: string | null
  avulso_marca: string | null
  avulso_unidade: string | null
  avulso_categoria: string | null
  quantidade: number
  valor_unitario: string | number
  avulso_resolvido_em: string | null
  sku_snapshot: string | null
  environment: { nome: string } | null
}

interface Opcao { id: string; nome: string; prefixo?: string }


const FORM_VAZIO = {
  supplierId: "", categoryId: "", precoCusto: "", marca: "", unidade: "UN",
  nome: "", ncm: "", impostoSt: "",
}

export function ItensAvulsos({
  proposalId, aberto, aoFechar, aoResolver,
}: {
  proposalId: string
  aberto: boolean
  aoFechar: () => void
  /** Chamado quando o último pendente é resolvido — libera o faturamento. */
  aoResolver?: () => void
}) {
  const [itens, setItens] = useState<ItemAvulso[] | null>(null)
  const [fornecedores, setFornecedores] = useState<Opcao[]>([])
  const [categorias, setCategorias] = useState<Opcao[]>([])
  const [ativo, setAtivo] = useState<string | null>(null)
  const [form, setForm] = useState(FORM_VAZIO)
  /* SKU vem do servidor, do prefixo do fornecedor — o mesmo endpoint que o
     catálogo usa. Aparece pronto para conferência e nunca é digitado: código
     inventado à mão quebra a convenção e abre porta para repetido. */
  const [sku, setSku] = useState("")
  const [salvando, setSalvando] = useState(false)
  const [erro, setErro] = useState("")

  // Anexar a existente: busca dentro do próprio modal, sem trocar de tela.
  const [modoVincular, setModoVincular] = useState(false)
  const [busca, setBusca] = useState("")
  const [achados, setAchados] = useState<{ id: string; sku: string; nome: string }[]>([])

  const carregar = useCallback(async () => {
    try {
      const r = await fetch(`/api/propostas/${proposalId}/itens-avulsos`, { cache: "no-store" })
      if (!r.ok) { setErro("Não foi possível carregar."); return }
      const j = await r.json()
      setItens(j.itens ?? [])
      setFornecedores(j.fornecedores ?? [])
      setCategorias(j.categorias ?? [])
      if (!j.pendentes) aoResolver?.()
    } catch { setErro("Falha de conexão.") }
  }, [proposalId, aoResolver])

  useEffect(() => { if (aberto) carregar() }, [aberto, carregar])

  function abrirItem(id: string, lista: ItemAvulso[]) {
    const item = lista.find(i => i.id === id)
    setAtivo(id)
    setForm({
      ...FORM_VAZIO,
      marca: item?.avulso_marca ?? "",
      unidade: item?.avulso_unidade ?? "UN",
      // O modelo já vem escrito: é o nome combinado com o cliente na visita.
      nome: item?.nome_snapshot ?? "",
    })
    setSku(""); setModoVincular(false); setBusca(""); setAchados([]); setErro("")
  }

  /* Com um único pendente não faz sentido pedir que a pessoa escolha qual:
     abre direto no formulário dele. */
  useEffect(() => {
    if (!itens || ativo) return
    const pend = itens.filter(i => !i.avulso_resolvido_em)
    if (pend.length === 1) abrirItem(pend[0].id, itens)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [itens])

  /* Escolheu o fornecedor: o SKU aparece na hora, antes de salvar. Ver o código
     que o produto vai receber é o que permite conferir o fornecedor certo sem
     sair da tela. */
  useEffect(() => {
    if (!form.supplierId) { setSku(""); return }
    let vivo = true
    fetch(`/api/produtos/next-sku?supplierId=${form.supplierId}`)
      .then(r => r.ok ? r.json() : null)
      .then(j => {
        if (!vivo || !j?.sku) return
        setSku(j.sku)
        // Marca segue o fornecedor, como no catálogo — salvo se já digitaram.
        setForm(f => f.marca.trim() ? f : { ...f, marca: j.marca ?? "" })
      })
      .catch(() => {})
    return () => { vivo = false }
  }, [form.supplierId])

  useEffect(() => {
    if (!modoVincular || busca.trim().length < 2) { setAchados([]); return }
    const t = setTimeout(async () => {
      const r = await fetch(`/api/produtos?search=${encodeURIComponent(busca)}&limit=8`)
        .catch(() => null)
      if (r?.ok) setAchados((await r.json()).products ?? [])
    }, 300)
    return () => clearTimeout(t)
  }, [busca, modoVincular])

  async function cadastrar() {
    if (!ativo) return
    setSalvando(true); setErro("")
    try {
      const r = await fetch(`/api/propostas/${proposalId}/itens-avulsos`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          itemId: ativo, ...form,
          precoCusto: form.precoCusto.replace(",", "."),
          impostoSt: form.impostoSt.replace(",", "."),
        }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { setErro(j.error ?? "Não foi possível cadastrar."); return }
      setAtivo(null)
      await carregar()
    } catch { setErro("Falha de conexão.") }
    finally { setSalvando(false) }
  }

  async function vincular(productId: string) {
    if (!ativo) return
    setSalvando(true); setErro("")
    try {
      const r = await fetch(`/api/propostas/${proposalId}/itens-avulsos`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ itemId: ativo, productId }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { setErro(j.error ?? "Não foi possível anexar."); return }
      setAtivo(null)
      await carregar()
    } catch { setErro("Falha de conexão.") }
    finally { setSalvando(false) }
  }

  const pendentes = (itens ?? []).filter(i => !i.avulso_resolvido_em)
  const item = (itens ?? []).find(i => i.id === ativo) ?? null
  const valor = item ? Number(item.valor_unitario) : 0
  const podeSalvar = !!form.supplierId && !!form.nome.trim()
    && parseFloat(form.precoCusto.replace(",", ".")) > 0

  const rotulo = "text-[11px] text-muted-foreground"
  const selectCls =
    "h-10 w-full rounded-xl border border-border bg-muted px-2.5 text-[13px] text-foreground outline-none focus:ring-2 focus:ring-primary"

  return (
    <Dialog open={aberto} onOpenChange={o => !o && aoFechar()}>
      <DialogContent className="w-[calc(100vw-32px)] sm:max-w-2xl mx-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="h-4 w-4 text-ios-orange" />
            {item ? "Cadastrar no catálogo" : "Itens fora do catálogo"}
          </DialogTitle>
        </DialogHeader>

        <div data-lembrar-rolagem="itens-avulsos" className="max-h-[calc(90vh-200px)] overflow-y-auto px-5 sm:px-6 py-1">
          {erro && <p className="mb-3 text-[12px] leading-relaxed text-ios-red">{erro}</p>}

          {!itens ? (
            <p className="py-10 text-center text-[13px] text-muted-foreground">Carregando...</p>
          ) : !pendentes.length ? (
            <p className="py-10 text-center text-[13px] text-muted-foreground">
              Tudo cadastrado. A proposta pode seguir para faturamento.
            </p>
          ) : !item ? (
            /* Mais de um pendente: escolher qual cadastrar primeiro. */
            <div className="space-y-2">
              {pendentes.map(i => (
                <button key={i.id} type="button" onClick={() => abrirItem(i.id, itens)}
                  className="flex w-full items-center justify-between gap-3 rounded-xl border border-ios-orange/30 bg-ios-orange/[0.05] p-3 text-left hover:border-ios-orange/60">
                  <span className="min-w-0">
                    <span className="block text-[14px] font-medium text-foreground">{i.nome_snapshot}</span>
                    <span className="block text-[12px] text-muted-foreground">
                      {[i.environment?.nome, `${i.quantidade} ${i.avulso_unidade ?? "UN"}`,
                        brl(Number(i.valor_unitario))].filter(Boolean).join(" · ")}
                    </span>
                  </span>
                  <span className="shrink-0 text-[12px] text-ios-orange">Cadastrar</span>
                </button>
              ))}
            </div>
          ) : modoVincular ? (
            <div className="space-y-2.5">
              <p className="text-[13px] leading-relaxed text-muted-foreground">
                Ache o produto que já está no catálogo para anexar{" "}
                <strong className="text-foreground">{item.nome_snapshot}</strong>.
              </p>
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                <Input value={busca} autoFocus onChange={e => setBusca(e.target.value)}
                  placeholder="Nome ou SKU" className="h-10 pl-8 text-[13px]" />
              </div>
              {achados.map(p => (
                <button key={p.id} type="button" disabled={salvando}
                  onClick={() => vincular(p.id)}
                  className="flex w-full items-center justify-between rounded-lg bg-foreground/[0.04] px-2.5 py-2 text-left hover:bg-foreground/[0.08]">
                  <span className="min-w-0 truncate text-[13px] text-foreground">{p.nome}</span>
                  <span className="ml-2 shrink-0 font-mono text-[11px] text-muted-foreground">{p.sku}</span>
                </button>
              ))}
            </div>
          ) : (
            <div className="space-y-3">
              <div>
                <p className="text-[14px] font-medium text-foreground">{item.nome_snapshot}</p>
                <p className="text-[12px] text-muted-foreground">
                  {[item.environment?.nome, `${item.quantidade} ${item.avulso_unidade ?? "UN"}`,
                    brl(valor)].filter(Boolean).join(" · ")}
                </p>
              </div>

              {/* Mesmos campos do cadastro do catálogo, na mesma ordem. */}
              <div className="grid grid-cols-2 gap-3">
                <label className="col-span-2 space-y-1">
                  <span className={rotulo}>Fornecedor / Marca *</span>
                  <select value={form.supplierId}
                    onChange={e => setForm(f => ({ ...f, supplierId: e.target.value }))}
                    className={selectCls}>
                    <option value="">— Selecione —</option>
                    {fornecedores.map(f => (
                      <option key={f.id} value={f.id}>{f.nome} ({f.prefixo})</option>
                    ))}
                  </select>
                </label>

                <label className="space-y-1">
                  <span className={rotulo}>SKU</span>
                  <Input value={sku || "—"} readOnly disabled className="h-10 text-[13px] font-mono" />
                </label>
                <label className="space-y-1">
                  <span className={rotulo}>Marca</span>
                  <Input value={form.marca} onChange={e => setForm(f => ({ ...f, marca: e.target.value }))}
                    placeholder="Auto (nome do fornecedor)" className="h-10 text-[13px]" />
                </label>

                <label className="col-span-2 space-y-1">
                  <span className={rotulo}>Modelo *</span>
                  <Input value={form.nome} onChange={e => setForm(f => ({ ...f, nome: e.target.value }))}
                    className="h-10 text-[13px]" />
                </label>

                <label className="space-y-1">
                  <span className={rotulo}>Preço de custo (R$) *</span>
                  <Input value={form.precoCusto} inputMode="decimal"
                    onChange={e => setForm(f => ({ ...f, precoCusto: e.target.value.replace(/[^\d.,]/g, "") }))}
                    placeholder="0,00" className="h-10 text-[13px]" />
                </label>
                <label className="space-y-1">
                  <span className={rotulo}>Preço de venda (R$)</span>
                  <Input value={brl(valor)} readOnly disabled className="h-10 text-[13px]" />
                </label>

                <label className="space-y-1">
                  <span className={rotulo}>Categoria</span>
                  <select value={form.categoryId}
                    onChange={e => setForm(f => ({ ...f, categoryId: e.target.value }))}
                    className={selectCls}>
                    <option value="">—</option>
                    {categorias.map(c => <option key={c.id} value={c.id}>{c.nome}</option>)}
                  </select>
                </label>
                <label className="space-y-1">
                  <span className={rotulo}>Unidade</span>
                  <Input value={form.unidade} onChange={e => setForm(f => ({ ...f, unidade: e.target.value }))}
                    className="h-10 text-[13px]" />
                </label>

                <label className="space-y-1">
                  <span className={rotulo}>NCM</span>
                  <Input value={form.ncm}
                    onChange={e => setForm(f => ({ ...f, ncm: e.target.value.replace(/[^\d.]/g, "") }))}
                    placeholder="0000.00.00" className="h-10 text-[13px]" />
                </label>
                <label className="space-y-1">
                  <span className={rotulo}>Imposto ST (%)</span>
                  <Input value={form.impostoSt} inputMode="decimal"
                    onChange={e => setForm(f => ({ ...f, impostoSt: e.target.value.replace(/[^\d.,]/g, "") }))}
                    placeholder="0" className="h-10 text-[13px]" />
                </label>
              </div>

              {/* O que vai ser gravado sem ninguém digitar. */}
              <p className="text-[11px] leading-relaxed text-muted-foreground">
                Venda {brl(valor)} — o que o cliente aceitou — e estoque inicial de{" "}
                {item.quantidade} {form.unidade || "UN"}, a quantidade desta proposta.
              </p>
            </div>
          )}
        </div>

        {/* Rodapé: as saídas da tela, sempre no mesmo lugar. */}
        {!!item && (
          <DialogFooter className="gap-2">
            {modoVincular ? (
              <>
                <Button type="button" variant="ghost" className="sm:mr-auto"
                  onClick={() => { setModoVincular(false); setBusca("") }}>
                  Voltar
                </Button>
                <Button type="button" variant="outline" onClick={aoFechar}>Cancelar</Button>
              </>
            ) : (
              <>
                <Button type="button" variant="ghost" className="sm:mr-auto"
                  onClick={() => setModoVincular(true)}>
                  Anexar a item existente
                </Button>
                <Button type="button" variant="outline" onClick={aoFechar}>Cancelar</Button>
                <Button type="button" disabled={salvando || !podeSalvar} onClick={cadastrar}>
                  {salvando ? "Salvando..." : "Salvar"}
                </Button>
              </>
            )}
          </DialogFooter>
        )}

        {!item && !!itens && !pendentes.length && (
          <DialogFooter>
            <Button type="button" onClick={aoFechar} className="gap-1.5">
              <Check className="h-3.5 w-3.5" /> Fechar
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  )
}
