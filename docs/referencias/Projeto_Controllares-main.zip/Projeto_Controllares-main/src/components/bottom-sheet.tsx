"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { cn } from "@/lib/utils"

interface BottomSheetProps {
  open: boolean
  onClose: () => void
  children: React.ReactNode
  /** Altura inicial: "sm" = 40%, "md" = 65%, "lg" = 92% */
  size?: "sm" | "md" | "lg"
  title?: string
  className?: string
}

const SIZE_MAP = { sm: 40, md: 65, lg: 92 }

export function BottomSheet({ open, onClose, children, size = "md", title, className }: BottomSheetProps) {
  const sheetRef = useRef<HTMLDivElement>(null)
  const dragStartY = useRef(0)
  const dragStartH = useRef(0)
  const [heightPct, setHeightPct] = useState(SIZE_MAP[size])
  const [isDragging, setIsDragging] = useState(false)
  const [visible, setVisible] = useState(false)

  // Animação de entrada/saída
  useEffect(() => {
    if (open) {
      setHeightPct(SIZE_MAP[size])
      requestAnimationFrame(() => setVisible(true))
    } else {
      setVisible(false)
    }
  }, [open, size])

  // Previne scroll do body quando aberto
  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden"
      return () => { document.body.style.overflow = "" }
    }
  }, [open])

  // ── Drag handle ──
  const onDragStart = useCallback((clientY: number) => {
    dragStartY.current = clientY
    dragStartH.current = heightPct
    setIsDragging(true)
  }, [heightPct])

  const onDragMove = useCallback((clientY: number) => {
    if (!isDragging) return
    const delta = dragStartY.current - clientY
    const winH = window.innerHeight
    const newH = Math.min(92, Math.max(20, dragStartH.current + (delta / winH) * 100))
    setHeightPct(newH)
  }, [isDragging])

  const onDragEnd = useCallback(() => {
    if (!isDragging) return
    setIsDragging(false)
    // Snapping: fecha se < 25%, ou snap para o tamanho mais próximo
    if (heightPct < 25) {
      onClose()
    } else if (heightPct < 52) {
      setHeightPct(40)
    } else if (heightPct < 78) {
      setHeightPct(65)
    } else {
      setHeightPct(92)
    }
  }, [isDragging, heightPct, onClose])

  // Touch events
  const handleTouchStart = (e: React.TouchEvent) => onDragStart(e.touches[0].clientY)
  const handleTouchMove = (e: React.TouchEvent) => onDragMove(e.touches[0].clientY)
  const handleTouchEnd = () => onDragEnd()

  // Mouse events (desktop)
  useEffect(() => {
    if (!isDragging) return
    const move = (e: MouseEvent) => onDragMove(e.clientY)
    const up = () => onDragEnd()
    window.addEventListener("mousemove", move)
    window.addEventListener("mouseup", up)
    return () => { window.removeEventListener("mousemove", move); window.removeEventListener("mouseup", up) }
  }, [isDragging, onDragMove, onDragEnd])

  if (!open && !visible) return null

  return (
    <div className="fixed inset-0 z-[60] flex flex-col justify-end">
      {/* Overlay */}
      <div
        className={`absolute inset-0 bg-black/20 backdrop-blur-sm transition-opacity duration-300 ${visible ? "opacity-100" : "opacity-0"}`}
        onClick={onClose}
      />

      {/* Sheet */}
      <div
        ref={sheetRef}
        className={cn(
          "relative bg-white dark:bg-[#1c1c1e] flex flex-col overflow-hidden",
          "transition-[height,transform] duration-300",
          isDragging ? "duration-0" : "",
          visible ? "translate-y-0" : "translate-y-full",
          className
        )}
        style={{
          height: `${heightPct}vh`,
          borderRadius: "28px 28px 0 0",
        }}
      >
        {/* Drag handle */}
        <div
          className="flex justify-center pt-3 pb-2 flex-shrink-0 cursor-grab active:cursor-grabbing touch-none"
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          onMouseDown={e => onDragStart(e.clientY)}
        >
          <div className="w-10 h-1 bg-black/20 dark:bg-white/20 rounded-full" />
        </div>

        {/* Título */}
        {title && (
          <div className="px-5 pb-3 flex-shrink-0">
            <h2 className="text-[17px] font-semibold text-center text-foreground tracking-tight">{title}</h2>
          </div>
        )}

        {/* Conteúdo scrollável */}
        <div className="flex-1 overflow-y-auto px-5 pb-8" style={{ scrollbarWidth: "none" }}>
          {children}
        </div>
      </div>
    </div>
  )
}

// ── Botão primário de sheet ───────────────────────────────────────────────────
export function SheetButton({
  children,
  onClick,
  variant = "primary",
  className,
}: {
  children: React.ReactNode
  onClick?: () => void
  variant?: "primary" | "secondary" | "danger"
  className?: string
}) {
  const variants = {
    primary: "bg-primary text-primary-foreground font-semibold active:opacity-80",
    secondary: "bg-black/[0.05] dark:bg-white/[0.08] text-foreground font-medium active:opacity-80",
    danger: "bg-destructive/10 text-destructive font-medium active:opacity-80",
  }
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full h-[52px] rounded-xl text-[16px] transition-opacity flex items-center justify-center gap-2",
        variants[variant],
        className
      )}
    >
      {children}
    </button>
  )
}
