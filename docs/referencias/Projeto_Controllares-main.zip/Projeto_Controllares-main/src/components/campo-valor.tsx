"use client"

import { useState } from "react"
import { numeroBR } from "@/lib/numero-br"

/**
 * Campo de valor em reais (ou percentual) que não briga com quem digita.
 *
 * Enquanto está em foco, o campo guarda exatamente o texto digitado — nada
 * de reformatar a cada tecla, que era o que travava ao apagar tudo ou
 * voltava o cursor para o fim. Ao sair, mostra formatado: "2000" vira
 * "2.000,00". O valor entregue a `onChange` é sempre número com ponto
 * ("2000", "10.5"), o mesmo formato que os campos type="number" davam.
 */
export function CampoValor({
  value,
  onChange,
  moeda = true,
  className,
  placeholder = "0",
}: {
  value: string | number | null | undefined
  onChange: (valor: string) => void
  /** true: mostra 2 casas ("2.000,00"); false: percentual, casas só se houver. */
  moeda?: boolean
  className?: string
  placeholder?: string
}) {
  const [txt, setTxt] = useState<string | null>(null)
  const n = Number(value) || 0
  const formatado = !value && value !== 0 ? "" : moeda
    ? n.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    : n.toLocaleString("pt-BR", { maximumFractionDigits: 4 })

  return (
    <input
      type="text"
      inputMode="decimal"
      placeholder={placeholder}
      value={txt ?? formatado}
      onFocus={() => setTxt(n ? String(n).replace(".", ",") : "")}
      onChange={e => {
        const t = e.target.value.replace(/[^\d.,]/g, "")
        setTxt(t)
        onChange(t ? String(numeroBR(t)) : "")
      }}
      onBlur={() => setTxt(null)}
      className={className}
    />
  )
}
