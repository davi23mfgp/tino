"use client"

import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
import { Command } from "cmdk"
import {
  Search, LayoutDashboard, KanbanSquare, Package, HardHat,
  DollarSign, CalendarDays, Users, Settings, FileText, Layers,
  Tag, LifeBuoy, Maximize2, X, ArrowRight,
} from "lucide-react"

interface SearchResult {
  id: string
  label: string
  sublabel?: string
  href: string
  group: "Proposta" | "Obra" | "Parceiro"
}

const NAV_ITEMS = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { label: "Propostas", href: "/propostas", icon: KanbanSquare },
  { label: "Catálogo", href: "/catalogo", icon: Package },
  { label: "Kits", href: "/kits", icon: Layers },
  { label: "Templates", href: "/templates", icon: FileText },
  { label: "Obras", href: "/operacional", icon: HardHat },
  { label: "Agenda", href: "/agenda", icon: CalendarDays },
  { label: "Financeiro", href: "/financeiro", icon: DollarSign },
  { label: "Parceiros", href: "/parceiros", icon: Users },
  { label: "Categorias", href: "/categorias", icon: Tag },
  { label: "Dimensionamento", href: "/dimensionamento", icon: Maximize2 },
  { label: "Configurações", href: "/configuracoes", icon: Settings },
  { label: "Suporte", href: "/suporte", icon: LifeBuoy },
]

export function CommandPalette() {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<SearchResult[]>([])
  const [loading, setLoading] = useState(false)

  // Ctrl+K / ⌘K
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.ctrlKey || e.metaKey)) {
        e.preventDefault()
        setOpen(o => !o)
      }
      if (e.key === "Escape") setOpen(false)
    }
    document.addEventListener("keydown", down)
    return () => document.removeEventListener("keydown", down)
  }, [])

  const search = useCallback(async (q: string) => {
    if (!q.trim() || q.length < 2) { setResults([]); return }
    setLoading(true)
    try {
      const [propostas, obras, parceiros] = await Promise.allSettled([
        fetch(`/api/propostas?search=${encodeURIComponent(q)}&limit=5`).then(r => r.ok ? r.json() : null),
        fetch(`/api/obras?search=${encodeURIComponent(q)}&limit=5`).then(r => r.ok ? r.json() : null),
        fetch(`/api/parceiros?search=${encodeURIComponent(q)}&limit=5`).then(r => r.ok ? r.json() : null),
      ])

      const out: SearchResult[] = []

      if (propostas.status === "fulfilled" && propostas.value) {
        const list = propostas.value.propostas || propostas.value.data || []
        list.forEach((p: { id: string; client_name?: string; numero?: string; status?: string }) =>
          out.push({ id: p.id, label: p.client_name || `Proposta ${p.numero}`, sublabel: p.status, href: `/propostas/${p.id}`, group: "Proposta" })
        )
      }
      if (obras.status === "fulfilled" && obras.value) {
        const list = obras.value.obras || obras.value.data || []
        list.forEach((o: { id: string; client_name?: string; status?: string }) =>
          out.push({ id: o.id, label: o.client_name || o.id, sublabel: o.status, href: `/operacional/${o.id}`, group: "Obra" })
        )
      }
      if (parceiros.status === "fulfilled" && parceiros.value) {
        const list = parceiros.value.parceiros || []
        list.forEach((p: { id: string; name: string; type?: string }) =>
          out.push({ id: p.id, label: p.name, sublabel: p.type, href: `/parceiros/${p.id}`, group: "Parceiro" })
        )
      }

      setResults(out)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    const t = setTimeout(() => search(query), 250)
    return () => clearTimeout(t)
  }, [query, search])

  function go(href: string) {
    setOpen(false)
    setQuery("")
    setResults([])
    router.push(href)
  }

  const filteredNav = query.length > 0
    ? NAV_ITEMS.filter(n => n.label.toLowerCase().includes(query.toLowerCase()))
    : NAV_ITEMS

  const groups = ["Proposta", "Obra", "Parceiro"] as const
  const hasResults = results.length > 0

  if (!open) return null

  return (
    <div className="fixed inset-0 z-[200] flex items-start justify-center pt-[15vh]">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={() => setOpen(false)}
      />

      {/* Panel */}
      <div className="relative w-full max-w-[560px] mx-4 bg-card border border-border rounded-2xl shadow-[0_24px_80px_rgba(0,0,0,0.25)] overflow-hidden">
        <Command shouldFilter={false} className="bg-transparent">
          {/* Input */}
          <div className="flex items-center gap-3 px-4 border-b border-border h-[52px]">
            <Search className="w-4 h-4 text-muted-foreground/50 flex-shrink-0" />
            <Command.Input
              value={query}
              onValueChange={setQuery}
              placeholder="Buscar propostas, obras, parceiros, páginas..."
              className="flex-1 bg-transparent text-[15px] text-foreground placeholder:text-muted-foreground/40 outline-none"
              autoFocus
            />
            {query && (
              <button onClick={() => setQuery("")} className="text-muted-foreground hover:text-foreground transition-colors">
                <X className="w-4 h-4" />
              </button>
            )}
            <kbd className="text-[11px] text-muted-foreground/40 bg-muted px-1.5 py-0.5 rounded font-mono">ESC</kbd>
          </div>

          {/* Results */}
          <Command.List className="max-h-[400px] overflow-y-auto py-2" style={{ scrollbarWidth: "none" }}>
            {loading && (
              <div className="px-4 py-3 text-sm text-muted-foreground/60">Buscando...</div>
            )}

            {/* Resultados de dados */}
            {hasResults && groups.map(group => {
              const items = results.filter(r => r.group === group)
              if (!items.length) return null
              return (
                <Command.Group key={group} heading={group + "s"} className="[&_[cmdk-group-heading]]:px-4 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-[11px] [&_[cmdk-group-heading]]:font-semibold [&_[cmdk-group-heading]]:uppercase [&_[cmdk-group-heading]]:tracking-widest [&_[cmdk-group-heading]]:text-muted-foreground/40">
                  {items.map(item => (
                    <Command.Item
                      key={item.id}
                      onSelect={() => go(item.href)}
                      className="flex items-center gap-3 px-4 py-2.5 cursor-pointer rounded-lg mx-2 data-[selected=true]:bg-muted transition-colors"
                    >
                      <ArrowRight className="w-3.5 h-3.5 text-muted-foreground/40 flex-shrink-0" />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm text-foreground font-medium truncate">{item.label}</p>
                        {item.sublabel && <p className="text-[11px] text-muted-foreground truncate">{item.sublabel}</p>}
                      </div>
                    </Command.Item>
                  ))}
                </Command.Group>
              )
            })}

            {/* Páginas */}
            {filteredNav.length > 0 && (
              <Command.Group heading="Páginas" className="[&_[cmdk-group-heading]]:px-4 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-[11px] [&_[cmdk-group-heading]]:font-semibold [&_[cmdk-group-heading]]:uppercase [&_[cmdk-group-heading]]:tracking-widest [&_[cmdk-group-heading]]:text-muted-foreground/40">
                {filteredNav.map(nav => (
                  <Command.Item
                    key={nav.href}
                    onSelect={() => go(nav.href)}
                    className="flex items-center gap-3 px-4 py-2.5 cursor-pointer rounded-lg mx-2 data-[selected=true]:bg-muted transition-colors"
                  >
                    <nav.icon className="w-4 h-4 text-muted-foreground/50 flex-shrink-0" />
                    <span className="text-sm text-foreground">{nav.label}</span>
                  </Command.Item>
                ))}
              </Command.Group>
            )}

            {!loading && !hasResults && query.length >= 2 && filteredNav.length === 0 && (
              <Command.Empty className="px-4 py-8 text-center text-sm text-muted-foreground/50">
                Nenhum resultado para &ldquo;{query}&rdquo;
              </Command.Empty>
            )}
          </Command.List>

          {/* Footer */}
          <div className="px-4 py-2.5 border-t border-border flex items-center gap-4 text-[11px] text-muted-foreground/40">
            <span><kbd className="font-mono bg-muted px-1 py-0.5 rounded">↑↓</kbd> navegar</span>
            <span><kbd className="font-mono bg-muted px-1 py-0.5 rounded">↵</kbd> abrir</span>
            <span><kbd className="font-mono bg-muted px-1 py-0.5 rounded">ESC</kbd> fechar</span>
          </div>
        </Command>
      </div>
    </div>
  )
}
