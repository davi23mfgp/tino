"use client"

import { useEffect, useState } from "react"
import { WifiOff } from "lucide-react"
import { ehDocumentoDoCliente } from "@/lib/rota-documento"

export function OfflineBanner() {
  const documento = ehDocumentoDoCliente()
  const [offline, setOffline] = useState(false)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const update = () => {
      const isOffline = !navigator.onLine
      setOffline(isOffline)
      if (isOffline) {
        setVisible(true)
      } else {
        // Mantém visível 2s depois de reconectar para confirmar ao usuário
        setTimeout(() => setVisible(false), 2000)
      }
    }

    update()
    window.addEventListener("online", update)
    window.addEventListener("offline", update)
    return () => {
      window.removeEventListener("online", update)
      window.removeEventListener("offline", update)
    }
  }, [])

  /* Fora do sistema, este aviso não tem dono.
     O link da proposta é lido pelo cliente, e "sem conexão — exibindo dados em
     cache" ali soa como defeito do documento que ele recebeu. Na impressão é
     pior: vira uma tarja no PDF que sai assinado. */
  if (documento) return null
  if (!visible) return null

  return (
    <div
      className={[
        // print:hidden é a segunda trava: mesmo dentro do sistema, o aviso não
        // pode sair no papel de um relatório impresso da tela.
        "print:hidden fixed top-0 inset-x-0 z-[300] flex items-center justify-center gap-2 py-2 px-4",
        "text-[13px] font-medium transition-colors duration-500",
        offline
          ? "bg-amber-500/90 text-amber-950 backdrop-blur-sm"
          : "bg-green-500/90 text-green-950 backdrop-blur-sm",
      ].join(" ")}
    >
      {offline ? (
        <>
          <WifiOff className="w-3.5 h-3.5 flex-shrink-0" />
          Sem conexão — exibindo dados em cache
        </>
      ) : (
        <>
          <span className="w-2 h-2 rounded-full bg-green-950/60 flex-shrink-0" />
          Conexão restaurada
        </>
      )}
    </div>
  )
}
