"use client"

import { useEffect, useRef, useState } from "react"
import { Check, ChevronDown } from "lucide-react"

/**
 * Sobre o que um serviço incide.
 *
 * Era um `<select>` nativo. Funcionava, mas a lista suspensa é desenhada pelo
 * sistema operacional: fundo branco no tema escuro, canto reto, altura de
 * formulário de 1998, e a lista inteira cobrindo o resto da tela. Num painel
 * que o vendedor abre na frente do cliente, isso é a coisa mais feia visível.
 *
 * Aqui a lista é HTML: um botão discreto com o escopo atual e um menu que
 * aparece embaixo, com o item escolhido marcado. O mesmo desenho serve para as
 * duas telas de proposta — a de criar e a de editar —, que até agora tinham
 * blocos de serviço diferentes, e só uma delas sabia falar de ambiente.
 */

export interface OpcaoEscopo {
  /** "" para a proposta inteira; senão `env:<id>` ou `cat:<id>`. */
  valor: string
  rotulo: string
  /** Aparece em cinza depois do nome: "(sistema)", "(categoria)". */
  tipo?: string
}

export function EscopoServico({
  valor,
  opcoes,
  onChange,
  sufixo,
}: {
  valor: string
  opcoes: OpcaoEscopo[]
  onChange: (valor: string) => void
  /** Texto solto depois do escopo, tipo "· 15% de R$ 12.000". */
  sufixo?: string
}) {
  const [aberto, setAberto] = useState(false)
  const caixa = useRef<HTMLDivElement>(null)

  /* Fecha ao clicar fora e no Esc. Menu que só fecha escolhendo algo obriga a
     escolher para desistir — e aí a pessoa muda o escopo sem querer. */
  useEffect(() => {
    if (!aberto) return
    const foraDaCaixa = (e: MouseEvent) => {
      if (!caixa.current?.contains(e.target as Node)) setAberto(false)
    }
    const escape = (e: KeyboardEvent) => { if (e.key === "Escape") setAberto(false) }
    document.addEventListener("mousedown", foraDaCaixa)
    document.addEventListener("keydown", escape)
    return () => {
      document.removeEventListener("mousedown", foraDaCaixa)
      document.removeEventListener("keydown", escape)
    }
  }, [aberto])

  const atual = opcoes.find(o => o.valor === valor) ?? opcoes[0]

  return (
    <div className="flex flex-wrap items-center gap-x-1.5 gap-y-1 text-[11px] text-muted-foreground">
      <span>sobre</span>

      <div className="relative" ref={caixa}>
        <button
          type="button"
          onClick={() => setAberto(a => !a)}
          className="group inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 -mx-1.5
                     font-medium text-foreground transition-colors
                     hover:bg-foreground/[0.06] active:bg-foreground/[0.1]">
          {atual?.rotulo ?? "toda a proposta"}
          <ChevronDown
            className={`h-3 w-3 text-muted-foreground transition-transform duration-200
                        ${aberto ? "rotate-180" : ""}`}
            strokeWidth={2.5}
          />
        </button>

        {aberto && (
          /* Largura mínima do próprio botão, não da tela: o menu antigo abria
             do tamanho do maior nome do catálogo e tampava o formulário. */
          <div
            className="absolute left-0 top-full z-50 mt-1 min-w-[180px] max-w-[280px]
                       overflow-hidden rounded-xl border border-border bg-popover p-1
                       shadow-xl shadow-black/20
                       animate-in fade-in-0 zoom-in-95 duration-100"
          >
            {opcoes.map(o => {
              const escolhido = o.valor === (atual?.valor ?? "")
              return (
                <button
                  key={o.valor}
                  type="button"
                  onClick={() => { onChange(o.valor); setAberto(false) }}
                  className={`flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-xs
                              transition-colors hover:bg-foreground/[0.06]
                              ${escolhido ? "text-foreground" : "text-muted-foreground"}`}
                >
                  {/* O check ocupa lugar sempre, mesmo invisível: sem isso os
                      nomes dançam para o lado ao trocar a escolha. */}
                  <Check
                    className={`h-3.5 w-3.5 shrink-0 ${escolhido ? "opacity-100" : "opacity-0"}`}
                    strokeWidth={3}
                  />
                  <span className="truncate">{o.rotulo}</span>
                  {o.tipo && (
                    <span className="ml-auto shrink-0 text-[10px] opacity-50">{o.tipo}</span>
                  )}
                </button>
              )
            })}
          </div>
        )}
      </div>

      {atual?.tipo && <span className="opacity-60">({atual.tipo})</span>}
      {sufixo && <span className="opacity-60">{sufixo}</span>}
    </div>
  )
}
