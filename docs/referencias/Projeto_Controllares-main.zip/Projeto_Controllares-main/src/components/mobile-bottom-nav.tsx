"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { HardHat, CalendarDays, LifeBuoy, Home, ClipboardList } from "lucide-react"

interface NavItem {
  href: string
  label: string
  icon: React.ReactNode
}

const INSTALADOR_ITEMS: NavItem[] = [
  { href: "/minha-area",  label: "Início",    icon: <Home className="w-5 h-5" /> },
  { href: "/agenda",      label: "Agenda",    icon: <CalendarDays className="w-5 h-5" /> },
  { href: "/suporte",     label: "Suporte",   icon: <LifeBuoy className="w-5 h-5" /> },
]

const RT_ITEMS: NavItem[] = [
  { href: "/dashboard",    label: "Painel",    icon: <Home className="w-5 h-5" /> },
  { href: "/operacional",  label: "Obras",     icon: <HardHat className="w-5 h-5" /> },
  { href: "/agenda",       label: "Agenda",    icon: <CalendarDays className="w-5 h-5" /> },
  { href: "/suporte",      label: "Suporte",   icon: <LifeBuoy className="w-5 h-5" /> },
]

interface Props {
  role: string
}

export function MobileBottomNav({ role }: Props) {
  const pathname = usePathname()

  const items =
    role === "INSTALADOR" ? INSTALADOR_ITEMS :
    role === "RESPONSAVEL_TECNICO" || role === "ENGENHEIRO_PROJETOS" ? RT_ITEMS :
    null

  if (!items) return null

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-slate-900/95 backdrop-blur border-t border-slate-700/60 safe-area-inset-bottom">
      <div className="flex items-center justify-around px-2 py-1">
        {items.map(item => {
          const active = pathname === item.href || pathname.startsWith(item.href + "/")
          return (
            <Link key={item.href} href={item.href}
              className={`flex flex-col items-center gap-0.5 px-4 py-2 rounded-xl transition-colors min-w-[64px] ${
                active
                  ? "text-sky-400"
                  : "text-slate-500 hover:text-slate-300"
              }`}>
              {item.icon}
              <span className="text-[10px] font-medium leading-none">{item.label}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
