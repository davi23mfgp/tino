"use client"

import { proxiedImg } from "@/lib/img"
import { useState, useEffect, useCallback, useRef } from "react"
import { useRouter, usePathname } from "next/navigation"
import Link from "next/link"
import { JWTPayload } from "@/lib/auth"
import { ThemeToggle } from "@/components/theme-toggle"
import { ControlDealLogo } from "@/components/logo"
import { NotificationsDrawer } from "@/components/notifications-drawer"
import { AiAssistant } from "@/components/ai-assistant"
import { CommandPalette } from "@/components/command-palette"
import { Toaster } from "@/components/ui/toast"
import { LayoutTemplate, UserCog,
  LayoutDashboard, Package, Layers, FileText, KanbanSquare, DollarSign,
  HardHat, Users, Settings, CalendarDays, Tag, LogOut, ChevronRight,
  Home, Briefcase, LifeBuoy, Sparkles, PanelLeftClose, PanelLeftOpen,
  Building2, Search, ChevronDown, Maximize2, LayoutGrid, X, Target, DraftingCompass,
  Contact, MessageCircle,
} from "lucide-react"
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Separator } from "@/components/ui/separator"
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink,
  BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import { useMemoriaDeRolagem, useMemoriaDeRolagemInterna } from "@/hooks/usar-memoria-rolagem"

// ─── Tipos ───────────────────────────────────────────────────────────────────
interface SidebarLayoutProps { children: React.ReactNode; session: JWTPayload }

interface NavItem {
  href: string
  label: string
  icon: React.ElementType
  roles: string[]
}

interface NavGroup {
  label: string
  items: NavItem[]
}

// ─── Grupos de navegação ─────────────────────────────────────────────────────
const NAV_GROUPS: NavGroup[] = [
  {
    label: "Comercial",
    items: [
      { href: "/dashboard",  label: "Dashboard",  icon: LayoutDashboard, roles: ["ADMIN","FINANCEIRO","VENDEDOR","RESPONSAVEL_TECNICO","INSTALADOR","ENGENHEIRO_PROJETOS"] },
      { href: "/propostas",  label: "Propostas",  icon: KanbanSquare,    roles: ["ADMIN","VENDEDOR","FINANCEIRO"] },
      { href: "/catalogo",   label: "Catálogo",   icon: Package,         roles: ["ADMIN","VENDEDOR","FINANCEIRO"] },
      { href: "/categorias", label: "Categorias", icon: Tag,             roles: ["ADMIN","VENDEDOR","FINANCEIRO"] },
      { href: "/kits",       label: "Kits",       icon: Layers,          roles: ["ADMIN","VENDEDOR","FINANCEIRO"] },
      { href: "/campanhas",  label: "Campanhas",  icon: Tag,             roles: ["ADMIN","FINANCEIRO"] },
      { href: "/templates",  label: "Modelos",  icon: LayoutTemplate,        roles: ["ADMIN","VENDEDOR","FINANCEIRO"] },
    ],
  },
  {
    label: "Operacional",
    items: [
      { href: "/operacional", label: "Obras",       icon: HardHat,      roles: ["ADMIN","FINANCEIRO","RESPONSAVEL_TECNICO","ENGENHEIRO_PROJETOS"] },
      { href: "/minha-area",  label: "Minha Área",  icon: HardHat,      roles: ["INSTALADOR"] },
      { href: "/agenda",      label: "Agenda",      icon: CalendarDays,  roles: ["ADMIN","VENDEDOR","FINANCEIRO","RESPONSAVEL_TECNICO","INSTALADOR","ENGENHEIRO_PROJETOS"] },
      /* Mesma tarefa, duas leituras: o quadro mostra QUEM está com o quê, a
         agenda mostra O QUE é hoje. Antes só existia a segunda, e o trabalho
         sem data marcada não aparecia em lugar nenhum. */
      { href: "/quadro",      label: "Quadro",      icon: KanbanSquare,  roles: ["ADMIN","VENDEDOR","FINANCEIRO","RESPONSAVEL_TECNICO","INSTALADOR","ENGENHEIRO_PROJETOS"] },
      { href: "/estoque", label: "Estoque", icon: Package, roles: ["ADMIN","FINANCEIRO","RESPONSAVEL_TECNICO"] },
    ],
  },
  {
    label: "Financeiro",
    items: [
      { href: "/financeiro",  label: "Financeiro", icon: DollarSign,    roles: ["ADMIN","FINANCEIRO"] },
    ],
  },
  {
    label: "CRM",
    items: [
      { href: "/leads",       label: "Leads",      icon: Target,        roles: ["ADMIN","VENDEDOR"] },
      /* Ainda pré-visualização (dado fictício, sem wacrm conectado) —
         entra no mesmo lugar que vai ficar quando ligar de verdade. */
      { href: "/chat",        label: "Chat",       icon: MessageCircle, roles: ["ADMIN","VENDEDOR","FINANCEIRO","RESPONSAVEL_TECNICO","INSTALADOR","ENGENHEIRO_PROJETOS"] },
      /* Entre o funil e os parceiros porque é onde o contato para de ser lead:
         Leads é quem ainda se decide, Clientes é quem já comprou. Mesma ficha,
         mesma linha do tempo — só a pergunta que se faz é outra. */
      { href: "/clientes",    label: "Clientes",   icon: Contact,       roles: ["ADMIN","VENDEDOR","FINANCEIRO"] },
      { href: "/parceiros",   label: "Parceiros",  icon: Users,         roles: ["ADMIN","VENDEDOR","FINANCEIRO"] },
    ],
  },
  {
    label: "Inteligência",
    items: [
      { href: "/analises", label: "Análises", icon: LayoutGrid, roles: ["ADMIN","FINANCEIRO"] },
    ],
  },
  {
    label: "Sistema",
    items: [
      { href: "/suporte",          label: "Suporte",         icon: LifeBuoy,   roles: ["ADMIN","VENDEDOR","FINANCEIRO","RESPONSAVEL_TECNICO","INSTALADOR","ENGENHEIRO_PROJETOS"] },
      { href: "/configuracoes",    label: "Configurações",   icon: Settings,   roles: ["ADMIN"] },
    ],
  },
]

// ─── Rail items por role ─────────────────────────────────────────────────────
function getRailItems(role: string): NavItem[] {
  const home = role === "INSTALADOR" ? "/minha-area" : role === "FINANCEIRO" ? "/financeiro" : "/dashboard"
  const items: NavItem[] = [{ href: home, label: "Início", icon: Home, roles: [] }]
  if (["ADMIN","VENDEDOR"].includes(role))
    items.push({ href: "/propostas", label: "Comercial", icon: Briefcase, roles: [] })
  if (["ADMIN","RESPONSAVEL_TECNICO","ENGENHEIRO_PROJETOS"].includes(role))
    items.push({ href: "/operacional", label: "Obras", icon: HardHat, roles: [] })
  if (["ADMIN","INSTALADOR"].includes(role))
    items.push({ href: "/agenda", label: "Agenda", icon: CalendarDays, roles: [] })
  if (["ADMIN","FINANCEIRO"].includes(role))
    items.push({ href: "/financeiro", label: "Finanças", icon: DollarSign, roles: [] })
  return items.slice(0, 4)
}

// ─── Breadcrumb ──────────────────────────────────────────────────────────────
const BREADCRUMB_MAP: Record<string, string> = {
  "/dashboard": "Dashboard", "/propostas": "Propostas", "/catalogo": "Catálogo",
  "/categorias": "Categorias", "/kits": "Kits", "/campanhas": "Campanhas", "/templates": "Modelos",
  "/operacional": "Obras", "/minha-area": "Minha Área", "/agenda": "Agenda",
  "/financeiro": "Financeiro", "/parceiros": "Parceiros", "/leads": "Leads", "/clientes": "Clientes",
  "/configuracoes": "Configurações", "/suporte": "Suporte",
  "/estoque": "Estoque",
  "/analises": "Análises",
  "/plataforma": "Plataforma",
  "/obras": "Obras",
}

const DYNAMIC_SEGMENT_LABELS: Record<string, string> = {
  "/propostas": "Proposta",
  "/operacional": "Obra",
  "/obras": "Obra",
  "/parceiros": "Parceiro",
  "/kits": "Kit",
  "/templates": "Modelos",
  "/categorias": "Categoria",
}

function isId(segment: string) {
  // cuid/uuid: starts with 'c' or has length>12 with mixed chars
  return segment.length > 12 || /^[a-z0-9]{20,}$/.test(segment)
}

function useBreadcrumbs(pathname: string | null) {
  if (!pathname) return []
  const segments = pathname.split("/").filter(Boolean)
  const crumbs: { label: string; href: string; isLast: boolean }[] = []
  let accumulated = ""
  for (let i = 0; i < segments.length; i++) {
    const seg = segments[i]
    accumulated += "/" + seg
    let label = BREADCRUMB_MAP[accumulated]
    if (!label) {
      if (isId(seg)) {
        // Find parent path label to make "Proposta" or "Obra" etc
        const parentPath = "/" + segments.slice(0, i).join("/")
        label = DYNAMIC_SEGMENT_LABELS[parentPath] ?? "Detalhes"
      } else {
        label = seg.charAt(0).toUpperCase() + seg.slice(1)
      }
    }
    crumbs.push({ label, href: accumulated, isLast: i === segments.length - 1 })
  }
  return crumbs
}

function initials(nome: string) {
  return nome.split(" ").filter(Boolean).slice(0, 2).map(w => w[0]).join("").toUpperCase()
}

const ROLE_LABEL: Record<string, string> = {
  ADMIN: "Administrador", VENDEDOR: "Vendedor", FINANCEIRO: "Financeiro",
  RESPONSAVEL_TECNICO: "Resp. Técnico", INSTALADOR: "Instalador",
  ENGENHEIRO_PROJETOS: "Engenheiro",
}

// ─── Componente principal ────────────────────────────────────────────────────
export function SidebarLayout({ children, session }: SidebarLayoutProps) {
  const router = useRouter()
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [megaOpen, setMegaOpen] = useState(false)
  const [empresa, setEmpresa] = useState<{ nome_empresa: string | null; logo_url: string | null }>({ nome_empresa: null, logo_url: null })
  const [headerScrolled, setHeaderScrolled] = useState(false)
  const mainRef = useRef<HTMLElement>(null)
  const touchStartX = useRef(0)

  useEffect(() => {
    fetch("/api/empresa").then(r => r.ok ? r.json() : null).then(d => {
      if (d) setEmpresa({ nome_empresa: d.nome_empresa ?? null, logo_url: d.logo_url ?? null })
    }).catch(() => {})
  }, [])

  useEffect(() => { setMobileMenuOpen(false) }, [pathname])

  // Volta para onde o usuário parou ao sair e voltar da rota, e depois que uma
  // lista se recarrega e some por um instante.
  useMemoriaDeRolagem(mainRef)
  // As listas que rolam por dentro se anunciam com data-lembrar-rolagem.
  useMemoriaDeRolagemInterna()

  // Sombra no header ao rolar
  useEffect(() => {
    const el = mainRef.current
    if (!el) return
    const handler = () => setHeaderScrolled(el.scrollTop > 4)
    el.addEventListener("scroll", handler, { passive: true })
    return () => el.removeEventListener("scroll", handler)
  }, [])

  const handleLogout = useCallback(async () => {
    await fetch("/api/auth/logout", { method: "POST" })
    router.push("/login")
    router.refresh()
  }, [router])

  // Multi-perfil: usuário enxerga item se QUALQUER um dos seus perfis o permite.
  const perfisUser = [...new Set([session.role, ...(session.roles ?? [])])]
  const podeVer = (rs: string[]) => perfisUser.some(p => rs.includes(p))
  const visibleGroups = NAV_GROUPS.map(g => ({
    ...g,
    items: g.items.filter(i => podeVer(i.roles)),
  })).filter(g => g.items.length > 0)

  const railItems = getRailItems(session.role)
  const breadcrumbs = useBreadcrumbs(pathname)
  const avatarInitials = initials(session.nome)
  const roleLabel = ROLE_LABEL[session.role] ?? session.role
  const pageTitle = breadcrumbs.length > 0 ? breadcrumbs[breadcrumbs.length - 1].label : "Controllares"

  // ── Swipe to close drawer ──
  const handleDrawerTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX
  }
  const handleDrawerTouchEnd = (e: React.TouchEvent) => {
    const delta = touchStartX.current - e.changedTouches[0].clientX
    if (delta > 60) setMobileMenuOpen(false)
  }

  // ── Sidebar item ──
  const NavLink = ({ item }: { item: NavItem }) => {
    const active = pathname === item.href || (item.href !== "/dashboard" && pathname?.startsWith(item.href + "/"))
    if (collapsed) {
      return (
        <TooltipProvider delayDuration={0}>
          <Tooltip>
            <TooltipTrigger asChild>
              <Link href={item.href}
                className={`ios-tap flex items-center justify-center h-10 w-10 rounded-[14px] mx-auto ${
                  active
                    ? "bg-primary/[0.14] text-foreground ring-1 ring-inset ring-border/70"
                    : "text-muted-fg hover:bg-foreground/[0.06] hover:text-foreground"
                }`}>
                <item.icon className="w-[18px] h-[18px] flex-shrink-0" strokeWidth={active ? 2 : 1.5} />
              </Link>
            </TooltipTrigger>
            <TooltipContent side="right" className="text-xs rounded-lg">{item.label}</TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )
    }
    return (
      <Link href={item.href}
        className={`ios-tap flex items-center gap-3 px-3 h-10 rounded-[14px] text-[14px] font-medium ${
          active
            ? "bg-primary/[0.14] text-foreground ring-1 ring-inset ring-border/70"
            : "text-muted-fg hover:bg-foreground/[0.06] hover:text-foreground"
        }`}>
        <item.icon className="w-[18px] h-[18px] flex-shrink-0" strokeWidth={active ? 2 : 1.5} />
        <span className="truncate">{item.label}</span>
      </Link>
    )
  }

  return (
    <div className="app-bg flex h-screen overflow-hidden md:gap-3 md:p-3">
      <CommandPalette />

      {/* ══════════════════════════════════════
          SIDEBAR — DESKTOP ONLY
          Cartão flutuante: descolado da borda da tela, cantos arredondados.
      ══════════════════════════════════════ */}
      <aside className={`hidden md:flex flex-col ios-card relative z-10 overflow-hidden transition-[width] duration-300 ease-apple flex-shrink-0 ${
        collapsed ? "w-[68px]" : "w-[248px]"
      }`}>

        {/* Logo + colapsar */}
        <div className={`flex items-center h-[56px] border-b border-hairline px-3 flex-shrink-0 ${collapsed ? "justify-center" : "justify-between gap-2"}`}>
          {/* Recolhido, 68px não cabem logo e botão lado a lado: a logo larga
              era cortada num quadradinho branco espremido ao lado do ícone.
              Fica só o botão de expandir. */}
          <div className={`flex items-center gap-2.5 min-w-0 ${collapsed ? "hidden" : ""}`}>
            {empresa.logo_url ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={proxiedImg(empresa.logo_url)} alt="Logo" className="h-[26px] w-auto max-w-[120px] object-contain object-left flex-shrink-0" />
            ) : (
              <ControlDealLogo size={24} />
            )}
            {!collapsed && (
              <span className="font-semibold text-sm tracking-tight truncate text-foreground">
                {empresa.nome_empresa ?? <>Controllares<span className="text-ios-blue">.</span></>}
              </span>
            )}
          </div>
          <TooltipProvider delayDuration={0}>
            <Tooltip>
              <TooltipTrigger asChild>
                <button onClick={() => setCollapsed(c => !c)}
                  className="flex-shrink-0 flex items-center justify-center h-7 w-7 rounded-xl hover:bg-accent text-muted-foreground hover:text-foreground transition-colors"
                  aria-label={collapsed ? "Expandir" : "Recolher"}>
                  {collapsed ? <PanelLeftOpen className="w-4 h-4" /> : <PanelLeftClose className="w-4 h-4" />}
                </button>
              </TooltipTrigger>
              <TooltipContent side="right" className="text-xs">{collapsed ? "Expandir" : "Recolher"}</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto overflow-x-hidden py-3 px-2 space-y-4" style={{ scrollbarWidth: "none" }}>
          {visibleGroups.map(group => (
            <div key={group.label}>
              {!collapsed && (
                <p className="text-[11px] font-medium uppercase tracking-wider text-muted-fg px-3 mt-4 mb-1 first:mt-0">
                  {group.label}
                </p>
              )}
              {collapsed && group !== visibleGroups[0] && (
                <div className="h-px bg-hairline mx-2 mb-2 mt-1" />
              )}
              <div className={`space-y-0.5 ${collapsed ? "flex flex-col items-center" : ""}`}>
                {group.items.map(item => <NavLink key={item.href} item={item} />)}
              </div>
            </div>
          ))}
        </nav>

        <Separator />

        {/* Botão CORE */}
        <div className="px-2 py-2">
          <TooltipProvider delayDuration={0}>
            <Tooltip>
              {/* Cartão em vez de item de lista: o CORE é atalho permanente,
                  não uma página da navegação. O comentário fica FORA do
                  TooltipTrigger: com asChild, o Radix exige um único filho
                  elemento, e texto solto quebra a renderização inteira. */}
              <TooltipTrigger asChild>
                <button
                  onClick={() => (document.querySelector("[data-ai-trigger]") as HTMLButtonElement)?.click()}
                  className={`ios-tap flex items-center rounded-[14px] h-10 text-[14px] font-medium text-muted-fg hover:bg-foreground/[0.06] hover:text-foreground ${collapsed ? "justify-center w-10 mx-auto" : "gap-3 px-3 w-full"}`}>
                  {/* Mesmo desenho dos itens do menu: ícone solto, sem círculo
                      colorido — o CORE fica à mão sem gritar mais que o resto. */}
                  <Sparkles className="w-[18px] h-[18px] flex-shrink-0" strokeWidth={1.5} />
                  {!collapsed && <span className="truncate">Assistente CORE</span>}
                </button>
              </TooltipTrigger>
              {collapsed && <TooltipContent side="right" className="text-xs">Assistente CORE</TooltipContent>}
            </Tooltip>
          </TooltipProvider>
        </div>

        <Separator />

        {/* Footer: avatar */}
        <div className="p-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className={`flex items-center gap-2.5 rounded-lg hover:bg-accent transition-colors p-1.5 w-full ${collapsed ? "justify-center" : ""}`}>
                <Avatar className="h-7 w-7 flex-shrink-0">
                  <AvatarFallback className="text-[10px] font-semibold bg-primary text-primary-foreground">
                    {avatarInitials}
                  </AvatarFallback>
                </Avatar>
                {!collapsed && (
                  <div className="text-left min-w-0 flex-1">
                    <p className="text-xs font-medium text-foreground truncate leading-tight">{session.nome}</p>
                    <p className="text-[10px] text-muted-foreground truncate leading-tight">{roleLabel}</p>
                  </div>
                )}
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent side="top" align={collapsed ? "center" : "start"} className="w-52">
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col gap-1">
                  <p className="text-sm font-medium">{session.nome}</p>
                  <p className="text-xs text-muted-foreground">{session.email}</p>
                  <span className="inline-block text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full w-fit mt-0.5">{roleLabel}</span>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/perfil" className="gap-2 cursor-pointer">
                  <UserCog className="w-4 h-4" /> Meu perfil
                </Link>
              </DropdownMenuItem>
              {session.role === "ADMIN" && (
                <DropdownMenuItem asChild>
                  <Link href="/configuracoes" className="gap-2 cursor-pointer">
                    <Building2 className="w-4 h-4" /> Configurações
                  </Link>
                </DropdownMenuItem>
              )}
              <DropdownMenuItem asChild>
                <Link href="/suporte" className="gap-2 cursor-pointer">
                  <LifeBuoy className="w-4 h-4" /> Suporte
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout} className="gap-2 text-destructive focus:text-destructive cursor-pointer">
                <LogOut className="w-4 h-4" /> Sair
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </aside>

      {/* ══════════════════════════════════════
          ÁREA PRINCIPAL (desktop + mobile)
      ══════════════════════════════════════ */}
      <div className="flex-1 flex flex-col overflow-hidden min-w-0 md:gap-3">

        {/* ── HEADER DESKTOP ─────────────────────────────────────────────── */}
        {/* Cartão flutuante, igual à sidebar — não encosta na borda nem no conteúdo. */}
        <header className={`hidden md:flex items-center h-[56px] px-4 ios-card relative z-40 flex-shrink-0 gap-2 transition-shadow duration-200 ${
          headerScrolled ? "shadow-[0_18px_40px_-22px_rgba(0,0,0,0.85),0_2px_16px_rgba(0,0,0,0.18)]" : ""
        }`}>
          {/* Breadcrumb */}
          <div className="flex-1 min-w-0">
            <Breadcrumb>
              <BreadcrumbList className="flex-nowrap">
                <BreadcrumbItem>
                  <BreadcrumbLink asChild>
                    <Link href="/dashboard" className="text-[13px] text-muted-foreground hover:text-foreground transition-colors">Início</Link>
                  </BreadcrumbLink>
                </BreadcrumbItem>
                {breadcrumbs.map((crumb) => (
                  <span key={crumb.href} className="contents">
                    <BreadcrumbSeparator className="text-muted-foreground/40" />
                    <BreadcrumbItem>
                      {crumb.isLast
                        ? <BreadcrumbPage className="text-[13px] font-medium text-foreground">{crumb.label}</BreadcrumbPage>
                        : <BreadcrumbLink asChild><Link href={crumb.href} className="text-[13px] text-muted-foreground hover:text-foreground transition-colors">{crumb.label}</Link></BreadcrumbLink>
                      }
                    </BreadcrumbItem>
                  </span>
                ))}
              </BreadcrumbList>
            </Breadcrumb>
          </div>

          {/* Spotlight */}
          <button
            onClick={() => { const e = new KeyboardEvent("keydown", { key: "k", ctrlKey: true, bubbles: true }); document.dispatchEvent(e) }}
            className="ios-tap flex items-center gap-2 h-9 px-3.5 rounded-full bg-foreground/[0.06] border border-border/50 hover:border-border hover:bg-foreground/[0.09] text-muted-foreground/60 text-[13px] cursor-text w-[220px]"
          >
            <Search className="w-3.5 h-3.5 flex-shrink-0" strokeWidth={2} />
            <span className="flex-1 text-left">Buscar...</span>
            <kbd className="text-[10px] bg-background/80 border border-border/40 px-1.5 py-0.5 rounded font-mono leading-none whitespace-nowrap">Ctrl K</kbd>
          </button>

          {/* Mega menu trigger */}
          <TooltipProvider delayDuration={0}>
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  onClick={() => setMegaOpen(o => !o)}
                  className={`ios-tap flex items-center justify-center h-9 w-9 rounded-full ${
                    megaOpen
                      ? "bg-primary/[0.18] text-primary ring-1 ring-inset ring-border/70"
                      : "bg-foreground/[0.06] text-muted-foreground hover:text-foreground hover:bg-foreground/[0.09]"
                  }`}
                  aria-label="Todos os módulos"
                >
                  {megaOpen ? <X className="w-4 h-4" /> : <LayoutGrid className="w-4 h-4" />}
                </button>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="text-xs">Todos os módulos</TooltipContent>
            </Tooltip>
          </TooltipProvider>

          {/* Separador */}
          <div className="w-px h-5 bg-border/60 mx-1" />

          {/* Ações */}
          <NotificationsDrawer />
          <ThemeToggle />

          {/* Avatar dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-2 rounded-lg hover:bg-muted px-2 py-1.5 transition-colors">
                <Avatar className="h-6 w-6 flex-shrink-0">
                  <AvatarFallback className="text-[10px] font-semibold bg-primary text-primary-foreground">{avatarInitials}</AvatarFallback>
                </Avatar>
                <div className="hidden lg:flex flex-col items-start leading-none">
                  <span className="text-[12px] font-medium text-foreground max-w-[100px] truncate">{session.nome.split(" ")[0]}</span>
                  <span className="text-[10px] text-muted-foreground">{roleLabel}</span>
                </div>
                <ChevronDown className="w-3 h-3 text-muted-foreground hidden lg:block" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel className="font-normal">
                <div className="flex items-center gap-2.5">
                  <Avatar className="h-8 w-8 flex-shrink-0">
                    <AvatarFallback className="text-[11px] font-semibold bg-primary text-primary-foreground">{avatarInitials}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{session.nome}</p>
                    <p className="text-xs text-muted-foreground truncate">{session.email}</p>
                    <span className="inline-block text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full mt-0.5">{roleLabel}</span>
                  </div>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/perfil" className="gap-2 cursor-pointer">
                  <UserCog className="w-4 h-4" /> Meu perfil
                </Link>
              </DropdownMenuItem>
              {session.role === "ADMIN" && (
                <DropdownMenuItem asChild>
                  <Link href="/configuracoes" className="gap-2 cursor-pointer">
                    <Settings className="w-4 h-4" /> Configurações
                  </Link>
                </DropdownMenuItem>
              )}
              <DropdownMenuItem asChild>
                <Link href="/suporte" className="gap-2 cursor-pointer"><LifeBuoy className="w-4 h-4" /> Suporte</Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout} className="gap-2 text-destructive focus:text-destructive cursor-pointer">
                <LogOut className="w-4 h-4" /> Sair
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </header>

        {/* ── MEGA MENU PANEL ────────────────────────────────────────────── */}
        {megaOpen && (
          <div className="hidden md:block fixed inset-0 z-30" style={{ top: "54px" }}>
            {/* Backdrop */}
            <div className="absolute inset-0 bg-black/20 backdrop-blur-[2px]" onClick={() => setMegaOpen(false)} />
            {/* Panel — posicionado abaixo do header, à direita da sidebar */}
            <div
              className="absolute bg-card border border-border/60 rounded-2xl shadow-[0_16px_64px_rgba(0,0,0,0.18)] overflow-hidden"
              style={{
                top: "8px",
                left: collapsed ? "72px" : "248px",
                right: "16px",
                maxWidth: "760px",
              }}
            >
              {/* Header do panel */}
              <div className="flex items-center justify-between px-5 py-3.5 border-b border-border/50">
                <p className="text-[13px] font-semibold text-foreground tracking-tight">Módulos do sistema</p>
                <button onClick={() => setMegaOpen(false)} className="p-1 rounded-xl text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>
              {/* Grid de grupos */}
              <div className="p-4 grid grid-cols-2 lg:grid-cols-3 gap-4">
                {visibleGroups.map(group => (
                  <div key={group.label}>
                    <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground/50 px-1 mb-2">
                      {group.label}
                    </p>
                    <div className="space-y-0.5">
                      {group.items.map(item => {
                        const active = pathname === item.href || (item.href !== "/dashboard" && pathname?.startsWith(item.href + "/"))
                        return (
                          <Link
                            key={item.href}
                            href={item.href}
                            onClick={() => setMegaOpen(false)}
                            className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-[13px] transition-all ${
                              active
                                ? "bg-primary/10 text-primary font-medium"
                                : "text-foreground hover:bg-muted"
                            }`}
                          >
                            <item.icon className={`w-4 h-4 flex-shrink-0 ${active ? "text-primary" : "text-muted-foreground"}`} strokeWidth={active ? 2 : 1.5} />
                            {item.label}
                          </Link>
                        )
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── HEADER MOBILE (iOS) ─────────────────────────────────────────── */}
        {/* pt = safe-area: sem isso o header fica sob o notch/Dynamic Island e o menu não é clicável */}
        <header
          style={{ paddingTop: "env(safe-area-inset-top)" }}
          className={`md:hidden flex items-center h-[52px] box-content px-4 flex-shrink-0 sticky top-0 z-30 transition-all duration-200 bg-white/80 dark:bg-black/80 backdrop-blur-xl ${
            headerScrolled ? "shadow-[0_1px_12px_rgba(0,0,0,0.1)]" : ""
          }`}>
          {/* Hambúrguer */}
          <button
            onClick={() => setMobileMenuOpen(true)}
            className="flex items-center justify-center w-10 h-10 -ml-2 rounded-xl text-muted-foreground hover:text-foreground active:bg-muted/50 transition-colors"
            aria-label="Abrir menu">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 6h18M3 12h18M3 18h18" />
            </svg>
          </button>

          {/* Título da página — estilo iOS */}
          <h1 className="flex-1 text-center text-[17px] font-semibold tracking-tight text-foreground px-2 truncate">
            {pageTitle}
          </h1>

          {/* Lupa mobile → abre CommandPalette via Ctrl+K */}
          <button
            onClick={() => document.dispatchEvent(new KeyboardEvent("keydown", { key: "k", ctrlKey: true, bubbles: true }))}
            className="flex items-center justify-center w-10 h-10 rounded-xl text-muted-foreground hover:text-foreground active:bg-muted/50 transition-colors"
            aria-label="Buscar">
            <Search className="w-5 h-5" strokeWidth={1.5} />
          </button>

          {/* Notificações — fica no header (nunca aberta em cima de outro overlay) */}
          <NotificationsDrawer />

          {/* Avatar */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center justify-center w-10 h-10 -mr-2 rounded-xl active:bg-muted/50 transition-colors">
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="text-[11px] font-semibold bg-primary text-primary-foreground">{avatarInitials}</AvatarFallback>
                </Avatar>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col gap-0.5">
                  <p className="text-sm font-medium">{session.nome}</p>
                  <p className="text-xs text-muted-foreground">{roleLabel}</p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/perfil" className="gap-2 cursor-pointer">
                  <UserCog className="w-4 h-4" /> Meu perfil
                </Link>
              </DropdownMenuItem>
              {session.role === "ADMIN" && (
                <DropdownMenuItem asChild>
                  <Link href="/configuracoes" className="gap-2 cursor-pointer"><Settings className="w-4 h-4" /> Configurações</Link>
                </DropdownMenuItem>
              )}
              <DropdownMenuItem asChild>
                <Link href="/suporte" className="gap-2 cursor-pointer"><LifeBuoy className="w-4 h-4" /> Suporte</Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout} className="gap-2 text-destructive focus:text-destructive cursor-pointer">
                <LogOut className="w-4 h-4" /> Sair
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </header>

        {/* ── CORPO ──────────────────────────────────────────────────────── */}
        <div className="flex flex-1 overflow-hidden">
          {/* ── CONTEÚDO DA PÁGINA ──────────────────────────────────────── */}
          {/* pb no mobile = altura da bottom nav flutuante (~80px) + folga + safe-area.
              Wrapper usa min-h-full (não h-full): h-full + conteúdo maior engolia o
              padding-bottom do main e o fim da página ficava atrás da nav. */}
          {/* Conteúdo rola dentro do próprio cartão; o fundo com brilho fica
              visível nas laterais, o que dá a sensação de painel flutuante. */}
          <main ref={mainRef} className="painel-conteudo flex-1 overflow-auto relative z-10 pb-[calc(112px+env(safe-area-inset-bottom))] md:pb-0">
            <div key={pathname} className="animate-page-enter min-h-full">
              {children}
            </div>
          </main>
        </div>
      </div>

      {/* ══════════════════════════════════════
          BOTTOM NAVIGATION — MOBILE ONLY
      ══════════════════════════════════════ */}
      {/* bottom respeita o home indicator (iPhones sem botão) */}
      <div
        style={{ bottom: "max(env(safe-area-inset-bottom), 1rem)" }}
        className="md:hidden fixed left-1/2 -translate-x-1/2 w-[calc(100%-32px)] max-w-md z-40">
        <nav
          className="flex items-center justify-around rounded-[32px] border border-white/10 bg-white/[0.04] px-2 py-3"
          style={{ backdropFilter: "blur(24px) saturate(160%)", WebkitBackdropFilter: "blur(24px) saturate(160%)" }}
        >
          {railItems.map(item => {
            const active = pathname === item.href || (item.href !== "/dashboard" && item.href !== "/minha-area" && pathname?.startsWith(item.href))
            return (
              <Link key={item.href} href={item.href}
                className={`flex flex-col items-center gap-1 px-1 py-0.5 active:scale-95 transition-transform flex-1 min-w-0 ${active ? "text-ios-blue" : "text-muted-fg"}`}>
                <item.icon className="w-[22px] h-[22px] flex-shrink-0" strokeWidth={active ? 2.2 : 1.8} />
                <span className="uppercase font-medium tracking-[0.02em] truncate leading-none max-w-full" style={{ fontSize: "8.5px" }}>
                  {item.label}
                </span>
              </Link>
            )
          })}
          {/* CORE */}
          <button
            onClick={() => (document.querySelector("[data-ai-trigger]") as HTMLButtonElement)?.click()}
            className="flex flex-col items-center gap-1 px-1 py-0.5 active:scale-95 transition-transform flex-1 min-w-0 text-muted-fg">
            <Sparkles className="w-[22px] h-[22px] flex-shrink-0" strokeWidth={1.8} />
            <span className="uppercase font-medium tracking-[0.02em] truncate leading-none max-w-full" style={{ fontSize: "8.5px" }}>CORE</span>
          </button>
        </nav>
      </div>

      {/* ══════════════════════════════════════
          DRAWER MOBILE — estilo iOS
      ══════════════════════════════════════ */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex">
          {/* Overlay */}
          <div
            className="absolute inset-0 bg-black/30 backdrop-blur-sm"
            onClick={() => setMobileMenuOpen(false)}
          />

          {/* Drawer — desliza da esquerda, arredondado na direita */}
          <aside
            className="relative w-[280px] max-w-[85vw] bg-white dark:bg-[#1c1c1e] flex flex-col h-full shadow-2xl"
            style={{ borderRadius: "0 24px 24px 0" }}
            onTouchStart={handleDrawerTouchStart}
            onTouchEnd={handleDrawerTouchEnd}
          >
            {/* Drag handle */}
            <div className="flex justify-center pt-3 pb-1 flex-shrink-0">
              <div className="w-10 h-1 bg-black/15 dark:bg-white/20 rounded-full" />
            </div>

            {/* Perfil */}
            <div className="px-4 pt-2 pb-4 flex-shrink-0">
              <div className="flex items-center gap-3 bg-black/[0.04] dark:bg-white/[0.06] rounded-2xl p-3">
                <Avatar className="h-12 w-12 flex-shrink-0">
                  {empresa.logo_url
                    // eslint-disable-next-line @next/next/no-img-element
                    ? <img src={proxiedImg(empresa.logo_url)} alt="Logo" className="h-12 w-auto max-w-[120px] object-contain" />
                    : <AvatarFallback className="text-sm font-bold bg-primary text-primary-foreground">{avatarInitials}</AvatarFallback>
                  }
                </Avatar>
                <div className="min-w-0">
                  <p className="text-[15px] font-semibold text-foreground truncate">{session.nome}</p>
                  <p className="text-[13px] text-muted-foreground">{roleLabel}</p>
                  <p className="text-[11px] text-muted-foreground/60 truncate">{empresa.nome_empresa ?? "Controllares"}</p>
                </div>
              </div>
            </div>

            {/* Nav */}
            <nav className="flex-1 overflow-y-auto px-3 space-y-4 pb-4" style={{ scrollbarWidth: "none" }}>
              {visibleGroups.map(group => (
                <div key={group.label}>
                  <p className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground/50 px-2 mb-1.5">
                    {group.label}
                  </p>
                  <div className="space-y-0.5">
                    {group.items.map(item => {
                      const active = pathname === item.href || (item.href !== "/dashboard" && pathname?.startsWith(item.href + "/"))
                      return (
                        <Link key={item.href} href={item.href}
                          className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-[15px] transition-all min-h-[44px] ${
                            active
                              ? "bg-primary/10 text-primary font-medium"
                              : "text-foreground/70 hover:bg-black/[0.04] dark:hover:bg-white/[0.06]"
                          }`}>
                          <item.icon className="w-[18px] h-[18px] flex-shrink-0" strokeWidth={active ? 2 : 1.5} />
                          <span className="flex-1">{item.label}</span>
                          {!active && <ChevronRight className="w-4 h-4 text-muted-foreground/30 flex-shrink-0" />}
                        </Link>
                      )
                    })}
                  </div>
                </div>
              ))}

              {/* CORE no drawer */}
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground/50 px-2 mb-1.5">
                  Assistente
                </p>
                <button
                  onClick={() => { setMobileMenuOpen(false); setTimeout(() => (document.querySelector("[data-ai-trigger]") as HTMLButtonElement)?.click(), 200) }}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-[15px] text-foreground/70 hover:bg-black/[0.04] dark:hover:bg-white/[0.06] transition-all w-full min-h-[44px]">
                  <div className="w-[18px] h-[18px] flex-shrink-0 flex items-center justify-center">
                    <Sparkles className="w-[18px] h-[18px] text-sky-500" strokeWidth={1.5} />
                  </div>
                  <span className="flex-1 text-left">CORE</span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground/30 flex-shrink-0" />
                </button>
              </div>
            </nav>

            {/* Rodapé: logout */}
            <div className="px-3 pb-6 flex-shrink-0 border-t border-black/[0.06] dark:border-white/[0.06] pt-3">
              <div className="flex items-center justify-between mb-2 px-1">
                <ThemeToggle />
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-[15px] text-destructive hover:bg-destructive/8 transition-all w-full min-h-[44px]">
                <LogOut className="w-[18px] h-[18px] flex-shrink-0" />
                <span>Sair da conta</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* FAB contextual — mobile only */}

      {/* AI Assistant */}
      <AiAssistant />

      {/* Toasts globais */}
      <Toaster />
    </div>
  )
}
