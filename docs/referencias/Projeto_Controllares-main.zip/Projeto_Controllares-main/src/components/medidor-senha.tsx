"use client"

import { useMemo } from "react"
import { avaliarSenha, type NivelSenha } from "@/lib/forca-senha"

/**
 * Mostra o quanto a senha aguenta, enquanto a pessoa digita.
 *
 * Só barrar depois de enviar é frustrante: quem escolheu uma senha fraca já
 * decorou a senha fraca. O retorno tem de aparecer na hora, e precisa dizer o
 * que fazer — "senha fraca" sozinho manda a pessoa acrescentar um "1" no fim,
 * que é justamente o que não ajuda.
 */

const CORES: Record<NivelSenha, { barra: string; texto: string }> = {
  fraca:    { barra: "bg-ios-red",    texto: "text-ios-red" },
  razoavel: { barra: "bg-ios-orange", texto: "text-ios-orange" },
  boa:      { barra: "bg-ios-blue",   texto: "text-ios-blue" },
  forte:    { barra: "bg-ios-green",  texto: "text-ios-green" },
}

/* Quatro blocos em vez de uma barra contínua: a nota é uma estimativa grossa, e
   uma barra que anda de 61% para 64% sugere uma precisão que não existe. */
const ORDEM: NivelSenha[] = ["fraca", "razoavel", "boa", "forte"]

export function MedidorSenha({
  senha,
  nome,
  email,
  className = "",
}: {
  senha: string
  /** Contexto de quem cadastra: senha feita do próprio nome é o primeiro palpite. */
  nome?: string | null
  email?: string | null
  className?: string
}) {
  const a = useMemo(() => avaliarSenha(senha, { nome, email }), [senha, nome, email])

  // Campo vazio não recebe crítica: ninguém errou nada ainda.
  if (!senha) return null

  const cor = CORES[a.nivel]
  const preenchidos = ORDEM.indexOf(a.nivel) + 1

  return (
    <div className={`space-y-1.5 ${className}`} aria-live="polite">
      <div className="flex items-center gap-2">
        <div className="flex flex-1 gap-1">
          {ORDEM.map((_, i) => (
            <span key={i}
              className={`h-1 flex-1 rounded-full transition-colors ${
                i < preenchidos ? cor.barra : "bg-foreground/[0.12]"}`} />
          ))}
        </div>
        <span className={`text-[12px] font-medium ${cor.texto}`}>{a.rotulo}</span>
      </div>

      {a.sugestoes.length > 0 && (
        <ul className="space-y-0.5">
          {a.sugestoes.map((s, i) => (
            <li key={i} className="text-[12px] leading-snug text-muted-foreground">{s}</li>
          ))}
        </ul>
      )}

      {a.nivel === "forte" && (
        <p className="text-[12px] text-ios-green">Boa senha. Guarde num gerenciador.</p>
      )}
    </div>
  )
}

/** Atalho para quem só precisa saber se pode enviar o formulário. */
export function senhaAceitavel(senha: string, ctx?: { nome?: string | null; email?: string | null }) {
  return avaliarSenha(senha, ctx ?? {}).aceitavel
}
