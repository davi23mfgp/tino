﻿"use client"

import React, { useState, useRef, useEffect, useCallback } from "react"
import { usePathname, useRouter } from "next/navigation"
import { Sparkles, Lock, Download, FileText, Image as ImageIcon, FileCode, File, Check, Ban, ChevronRight, Plus, AlertTriangle, ArrowUp, Mic, MoreHorizontal, HardHat, DollarSign, CalendarDays, KeyRound, Paperclip, Users, Target, Package, Copy, ClipboardCheck, TrendingUp, TrendingDown, AlertCircle, Search, Wifi, Server, Cpu, Camera, Monitor, Network, X as XIcon, MapPin, BarChart3, ShieldCheck, Smartphone, Tv, Layers, Upload } from "lucide-react"

type Anexo = { nome: string; url: string; tipo: string }
type Msg =
  | { role: "user"; text: string }
  | { role: "assistant"; kind: "text"; text: string; id?: string }
  | { role: "assistant"; kind: "fontes"; fontes: { marcador: string; titulo: string; url: string }[] }
  | { role: "assistant"; kind: "attachments"; text: string; anexos: Anexo[] }
  | { role: "assistant"; kind: "need_password"; text: string; query: string; tipo: string; resolved?: boolean }
  | { role: "assistant"; kind: "confirm_action"; text: string; acao: string; params: unknown; resolved?: boolean }
  | { role: "assistant"; kind: "confirm_create"; text: string; summary: string; payload: unknown; resolved?: boolean }
  | { role: "assistant"; kind: "secret"; text: string; expiresAt: number }
  | { role: "assistant"; kind: "error"; text: string }

// ─── Flow types (credenciais + anexos) ────────────────────────────────────────
type ObraLite = { id: string; client_name: string; etapa: string | null; address?: string | null }
type CredLite = { id: string; tipo_equipamento: string; login: string | null; observacoes: string | null; tem_senha: boolean; tem_mac: boolean; tem_ip: boolean }
type AnexoLite = { nome: string; url: string; ext: string; tamanho?: string | null; createdAt?: string | null }

type FlowState = {
  type: "credenciais" | "anexos"
  mode: "consultar" | "salvar"
  step: 1 | 2 | 3
  obra?: ObraLite
  cred?: CredLite
  credList?: CredLite[]
  anexoList?: AnexoLite[]
  tentativas?: number
  locked?: boolean
  revealed?: { text: string; expiresAt: number }
  uploadFile?: File | null
  anexoSel?: AnexoLite
  novaCred?: { tipo: string; login: string; senha: string; obs: string }
}

function credIcon(tipo: string): React.ElementType {
  const t = (tipo || "").toLowerCase()
  if (t.includes("roteador") || t.includes("router") || t.includes("wi-fi") || t.includes("wifi")) return Wifi
  if (t.includes("switch") || t.includes("rede") || t.includes("network")) return Network
  if (t.includes("câmera") || t.includes("camera") || t.includes("nvr") || t.includes("dvr")) return Camera
  if (t.includes("tv") || t.includes("tela") || t.includes("monitor")) return Monitor
  if (t.includes("savant") || t.includes("control4") || t.includes("central")) return Cpu
  if (t.includes("qda") || t.includes("servidor") || t.includes("server")) return Server
  if (t.includes("porteiro") || t.includes("interfone")) return Smartphone
  if (t.includes("amplificador") || t.includes("audio") || t.includes("som")) return Layers
  return ShieldCheck
}

type MenuArea = { label: string; Icon: React.ElementType; perguntas?: string[]; flow?: "credenciais" | "anexos" }
const MENU_AREAS: MenuArea[] = [
  { label: "Obras",       Icon: HardHat,     perguntas: ["Minhas obras ativas", "Próximos agendamentos", "Suprimentos pendentes", "Criar tarefa"] },
  { label: "Propostas",   Icon: FileText,    perguntas: ["Minhas propostas abertas", "Propostas perto de vencer", "Pipeline de hoje"] },
  { label: "Financeiro",  Icon: DollarSign,  perguntas: ["Contas a receber", "Contas a pagar (7 dias)", "Fluxo de caixa (30 dias)"] },
  { label: "Agenda",      Icon: CalendarDays,perguntas: ["Meus compromissos hoje", "Próximos 7 dias"] },
  { label: "Credenciais", Icon: KeyRound,    flow: "credenciais" },
  { label: "Documentos",  Icon: Paperclip,   flow: "anexos" },
]

// Chips de ação rápida — variam por contexto de página
const QUICK_CHIPS_BY_PATH: Record<string, string[]> = {
  "/obras":       ["Obras ativas", "Próximos agendamentos", "Suprimentos pendentes"],
  "/operacional": ["Status desta obra", "Próximas etapas", "Suprimentos", "Credenciais"],
  "/propostas":   ["Pipeline de hoje", "Propostas perto de vencer", "O que há hoje?"],
  "/financeiro":  ["Contas a receber", "Contas a pagar (7 dias)", "Fluxo de caixa (30 dias)"],
  "/parceiros":   ["Parceiros ativos", "Indicações recentes"],
  "/agenda":      ["Meus compromissos hoje", "Próximos 7 dias"],
}
const DEFAULT_CHIPS = ["O que há hoje?", "Obras ativas", "Parcelas a vencer", "Credenciais"]

function getQuickChips(pathname: string): string[] {
  for (const prefix of Object.keys(QUICK_CHIPS_BY_PATH)) {
    if (pathname.startsWith(prefix)) return QUICK_CHIPS_BY_PATH[prefix]
  }
  return DEFAULT_CHIPS
}

function fileTypeIcon(tipo: string) {
  const t = (tipo || "").toLowerCase()
  if (t.includes("pdf")) return <FileText className="w-5 h-5 text-red-400" />
  if (t.match(/png|jpg|jpeg|gif|webp|svg/)) return <ImageIcon className="w-5 h-5 text-blue-400" />
  if (t.match(/dwg|dxf|skp|rvt/)) return <FileCode className="w-5 h-5 text-purple-400" />
  return <File className="w-5 h-5 text-muted-foreground" />
}

// Detecta se a resposta de texto parece um sumário financeiro e extrai linhas para cards
function parseFinancialCards(text: string): { label: string; value: string; status?: "ok" | "warn" | "danger" }[] | null {
  const lines = text.split("\n").filter(l => l.includes("R$") || l.match(/parcela|venc|atraso|NF/i))
  if (lines.length < 2) return null
  return lines.slice(0, 5).map(line => {
    const val = line.match(/R\$\s*[\d.,]+/)?.[0] ?? ""
    const label = line.replace(/R\$\s*[\d.,]+/g, "").replace(/^[•\-*]\s*/, "").trim().slice(0, 48)
    const status: "ok" | "warn" | "danger" = line.match(/atraso|vencid/i) ? "danger" : line.match(/venc|pendente/i) ? "warn" : "ok"
    return { label, value: val, status }
  }).filter(c => c.label && c.value)
}

function renderMarkdown(text: string) {
  const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  // Formatação inline: links, negrito, itálico, código
  const inline = (s: string) => esc(s)
    .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noreferrer" class="text-sky-400 underline">$1</a>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong class="font-semibold text-foreground">$1</strong>')
    .replace(/`([^`]+)`/g, '<code class="px-1 py-0.5 rounded bg-black/20 text-[13px] font-mono">$1</code>')
    .replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, "<em>$1</em>")

  // Quebra em blocos por linha em branco; cada bloco vira parágrafo, lista ou título.
  const blocos = text.replace(/\r/g, "").split(/\n{2,}/)
  const out: string[] = []
  for (const bloco of blocos) {
    const linhas = bloco.split("\n").filter(l => l.trim() !== "")
    if (linhas.length === 0) continue
    // Título ## / ###
    if (/^#{1,3}\s/.test(linhas[0]) && linhas.length === 1) {
      out.push(`<p class="font-semibold text-foreground mt-1">${inline(linhas[0].replace(/^#{1,3}\s/, ""))}</p>`)
      continue
    }
    // Lista com marcador
    if (linhas.every(l => /^\s*[-*•]\s+/.test(l))) {
      out.push(`<ul class="space-y-1 my-1 pl-1">${linhas.map(l => `<li class="flex gap-2"><span class="text-sky-400 mt-0.5">•</span><span>${inline(l.replace(/^\s*[-*•]\s+/, ""))}</span></li>`).join("")}</ul>`)
      continue
    }
    // Lista numerada
    if (linhas.every(l => /^\s*\d+[.)]\s+/.test(l))) {
      out.push(`<ol class="space-y-1 my-1 pl-1">${linhas.map((l, i) => `<li class="flex gap-2"><span class="text-sky-400 font-medium min-w-[16px]">${i + 1}.</span><span>${inline(l.replace(/^\s*\d+[.)]\s+/, ""))}</span></li>`).join("")}</ol>`)
      continue
    }
    // Parágrafo normal (linhas simples viram <br/>)
    out.push(`<p class="leading-relaxed">${linhas.map(inline).join("<br/>")}</p>`)
  }
  return { __html: `<div class="space-y-2.5">${out.join("")}</div>` }
}

function tipoSenha(pathname: string): string {
  if (pathname.startsWith("/operacional") || pathname.startsWith("/obras") || pathname.startsWith("/minha-area")) return "operacional"
  if (pathname.startsWith("/financeiro")) return "financeiro"
  return "padrao"
}

// Agrupa mensagens para exibir timestamp apenas quando há +5min entre grupos
function shouldShowTimestamp(msgs: Msg[], index: number): boolean {
  if (index === 0) return true
  const prev = msgs[index - 1]
  // Simplificado: sem timestamps reais nas msgs, mostra a cada 5 mensagens
  return index % 5 === 0
}

export function AiAssistant() {
  const pathname = usePathname()
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [msgs, setMsgs] = useState<Msg[]>([])
  const [input, setInput] = useState("")
  const [busy, setBusy] = useState(false)
  const [, force] = useState(0)
  const scrollRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const busyTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  // Flow guiado (credenciais / anexos)
  const [flowState, setFlowState] = useState<FlowState | null>(null)

  const hasPendingPassword = msgs.some(
    m => m.role === "assistant" && m.kind === "need_password" && !m.resolved
  )

  useEffect(() => { if (!open) { setMsgs([]); setBusy(false) } }, [open])
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" })
  }, [msgs])

  // Countdown segredos
  useEffect(() => {
    const hasSecret = msgs.some(m => m.role === "assistant" && m.kind === "secret")
    if (!hasSecret) return
    const iv = setInterval(() => {
      setMsgs(prev => prev.filter(m => !(m.role === "assistant" && m.kind === "secret" && m.expiresAt <= Date.now())))
      force(x => x + 1)
    }, 1000)
    return () => clearInterval(iv)
  }, [msgs])

  /* Vigia o SILÊNCIO, não o tempo total.

     Era um prazo fixo de 30 s desde o envio: pergunta que exige ler a base de
     conhecimento — "o que diz o manual do Home Manager" — passa disso com
     folga, e a resposta era descartada no meio mesmo estando chegando. O que
     indica travamento é a resposta PARAR de sair; enquanto texto chega, o
     relógio volta a zero. */
  const cutucar = useCallback(() => {
    if (busyTimerRef.current) clearTimeout(busyTimerRef.current)
    busyTimerRef.current = setTimeout(() => {
      setBusy(false)
      setMsgs(prev => [...prev, {
        role: "assistant", kind: "error",
        text: "⏱️ O CORE parou de responder. Tente de novo.",
      }])
    }, 45_000)
  }, [])

  useEffect(() => {
    if (busy) cutucar()
    else if (busyTimerRef.current) clearTimeout(busyTimerRef.current)
    return () => { if (busyTimerRef.current) clearTimeout(busyTimerRef.current) }
  }, [busy, cutucar])

  /**
   * Ditado por voz, feito pelo próprio navegador.
   *
   * O botão do microfone existia desenhado e não fazia nada — clicava e o
   * cursor continuava piscando. Quem está em obra, de luva ou no alto de uma
   * escada, não digita: era justamente a pessoa para quem o CORE foi feito que
   * ficava sem entrada.
   *
   * Usa a API de reconhecimento do navegador, não uma transcrição no servidor:
   * o texto aparece enquanto a pessoa fala, sem upload de áudio, sem espera e
   * sem custo por minuto. Em troca, depende do navegador — Chrome e Edge têm,
   * Firefox não. Onde não tem, o botão some, em vez de ficar ali sem funcionar.
   */

  /* A capacidade é medida DEPOIS de montar: `typeof window !== "undefined"` no
     corpo do componente roda também no servidor, onde window não existe, e o
     botão sai do HTML. */
  const [temVoz, setTemVoz] = useState(false)
  useEffect(() => {
    setTemVoz(!!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition))
  }, [])

  /**
   * Ditado por voz, e o porquê de ele avisar quando não dá.
   *
   * A primeira versão escondia o botão quando o navegador não tinha a API e
   * não fazia nada quando o microfone era negado. As duas falhas eram mudas —
   * do lado de cá ficava impossível saber se o problema era navegador, permissão
   * ou página sem HTTPS, e do lado de lá só restava "não consigo falar".
   *
   * Agora o botão aparece sempre e cada recusa tem uma frase. Botão que explica
   * por que não funciona vale mais que botão que some.
   */
  const [ouvindo, setOuvindo] = useState(false)
  const vozRef = useRef<any>(null)

  const avisar = useCallback((texto: string) => {
    setMsgs(prev => [...prev, { role: "assistant", kind: "error", text: texto }])
  }, [])

  const alternarVoz = useCallback(() => {
    if (ouvindo) { vozRef.current?.stop(); return }

    const Rec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    if (!Rec) {
      avisar("🎙️ Este navegador não tem reconhecimento de voz. Funciona no Chrome e no Edge.")
      return
    }
    /* Sem HTTPS o navegador nem pede permissão: recusa direto. localhost é a
       exceção que o próprio navegador abre. */
    if (!window.isSecureContext) {
      avisar("🎙️ O microfone só funciona em conexão segura (https).")
      return
    }

    const rec = new Rec()
    rec.lang = "pt-BR"
    /* Parcial ligado: o texto aparece enquanto se fala. Sem isso a pessoa fica
       olhando um campo vazio sem saber se o microfone pegou. */
    rec.interimResults = true
    rec.continuous = false

    /* O que já estava escrito não se perde: o ditado entra no fim. */
    const base = input

    rec.onresult = (e: any) => {
      let texto = ""
      for (let i = 0; i < e.results.length; i++) texto += e.results[i][0].transcript
      setInput((base ? base.trimEnd() + " " : "") + texto.trim())
    }
    rec.onerror = (e: any) => {
      setOuvindo(false)
      const motivo: Record<string, string> = {
        "not-allowed": "🎙️ Permissão de microfone negada. Libere para este site nas configurações do navegador.",
        "service-not-allowed": "🎙️ O navegador bloqueou o reconhecimento de voz para este site.",
        "audio-capture": "🎙️ Nenhum microfone encontrado.",
        "network": "🎙️ O reconhecimento de voz precisa de internet e não conseguiu conectar.",
        "no-speech": "🎙️ Não ouvi nada. Tente de novo mais perto do microfone.",
      }
      /* Erro sem tradução ainda aparece com o código: nome técnico é melhor que
         silêncio quando alguém precisa investigar. */
      avisar(motivo[e?.error] ?? `🎙️ Falha no microfone (${e?.error ?? "motivo desconhecido"}).`)
    }
    rec.onend = () => setOuvindo(false)

    try {
      vozRef.current = rec
      setOuvindo(true)
      rec.start()
    } catch {
      setOuvindo(false)
      avisar("🎙️ Não consegui abrir o microfone. Tente de novo.")
    }
  }, [ouvindo, input, avisar])

  const enviar = useCallback(async (texto: string) => {
    const message = texto.trim()
    if (!message || busy || hasPendingPassword) return

    // ── Atalho: abrir fluxo guiado (lista de obras) para credenciais/documentos ──
    const t = message.toLowerCase()
    const querCred = /\bcredenci/.test(t)
    const querDoc = /\b(documento|documentos|anexo|anexos|arquivo|arquivos)\b/.test(t)
    const querSalvar = /\b(cadastr|criar?|nov[ao]|adicion|salvar|registr|inser)/.test(t)
    const querVer = /\b(ver|consult|mostr|list|acess|revel)/.test(t)
    if ((querCred || querDoc) && (querSalvar || querVer)) {
      setInput("")
      setFlowState({
        type: querCred ? "credenciais" : "anexos",
        mode: querSalvar ? "salvar" : "consultar",
        step: 1,
      })
      return
    }

    setInput("")
    setBusy(true)
    setMsgs(prev => [...prev, { role: "user", text: message }])

    const history = msgs
      .filter(m => m.role === "user" || (m.role === "assistant" && m.kind === "text"))
      .map(m => ({ role: m.role, content: m.role === "user" ? m.text : (m as { text: string }).text }))

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, history, area: pathname }),
      })
      if (!res.body) throw new Error("sem resposta")

      const reader = res.body.getReader()
      const dec = new TextDecoder()
      let buf = ""
      // Acumulador local + id estável: imune a races de índice/closure do React.
      let acc = ""
      let streamId: string | null = null

      while (true) {
        const { done, value } = await reader.read()
        if (done) { setBusy(false); break }
        // Chegou dado: o CORE está vivo, o relógio recomeça.
        cutucar()
        buf += dec.decode(value, { stream: true })
        const linhas = buf.split("\n\n")
        buf = linhas.pop() ?? ""
        for (const bloco of linhas) {
          const linha = bloco.split("\n").find(l => l.startsWith("data:"))
          if (!linha) continue
          const ev = JSON.parse(linha.slice(5).trim())

          /* Sinal de vida do servidor enquanto o provedor não responde.

             Não vira bolha nem texto: só zera o relógio de silêncio. Sem ele,
             uma espera de 30 s pedida pelo próprio provedor virava "O CORE
             parou de responder" — e a resposta certa chegava logo depois. */
          if (ev.type === "aguardando") {
            cutucar()
            continue
          }

          if (ev.type === "text") {
            acc += ev.delta
            if (streamId === null) {
              // Primeiro delta: cria a bolha com um id estável
              streamId = `s_${Date.now()}_${Math.random().toString(36).slice(2)}`
              const id = streamId
              const textoAtual = acc
              setMsgs(prev => [...prev, { role: "assistant" as const, kind: "text" as const, text: textoAtual, id }])
            } else {
              // Deltas seguintes: substitui o texto completo na MESMA bolha (por id)
              const id = streamId
              const textoAtual = acc
              setMsgs(prev => prev.map(m =>
                m.role === "assistant" && m.kind === "text" && m.id === id
                  ? { ...m, text: textoAtual }
                  : m
              ))
            }
          } else if (ev.type === "fontes") {
            /* As páginas que a resposta consultou, com link. O texto cita
               [W1], [W2]; sem a lista o marcador não leva a lugar nenhum. */
            setMsgs(prev => [...prev, { role: "assistant" as const, kind: "fontes" as const, fontes: ev.fontes }])
          } else if (ev.type === "need_password") {
            setMsgs(prev => [...prev, { role: "assistant", kind: "need_password", text: ev.message, query: ev.query, tipo: ev.tipo ?? tipoSenha(pathname) }])
            setBusy(false)
          } else if (ev.type === "open_flow") {
            // Pergunta confidencial → abre o painel guiado (mesmo do botão)
            setMsgs(prev => [...prev, { role: "assistant", kind: "text", text: ev.message }])
            setFlowState({ type: ev.flow === "anexos" ? "anexos" : "credenciais", mode: "consultar", step: 1 })
            setBusy(false)
          } else if (ev.type === "attachments") {
            setMsgs(prev => [...prev, { role: "assistant", kind: "attachments", text: ev.message, anexos: ev.attachments }])
          } else if (ev.type === "confirm_action") {
            setMsgs(prev => [...prev, { role: "assistant", kind: "confirm_action", text: ev.message, acao: ev.acao, params: ev.params }])
          } else if (ev.type === "confirm_create") {
            setMsgs(prev => [...prev, { role: "assistant", kind: "confirm_create", text: ev.message, summary: ev.summary, payload: ev.payload }])
          } else if (ev.type === "error") {
            setMsgs(prev => [...prev, { role: "assistant", kind: "error", text: ev.message }])
            setBusy(false)
          } else if (ev.type === "done") {
            setBusy(false)
            return
          }
        }
      }
    } catch {
      setMsgs(prev => [...prev, { role: "assistant", kind: "error", text: "Erro ao falar com o assistente." }])
      setBusy(false)
    }
  }, [busy, hasPendingPassword, msgs, pathname])

  async function enviarSenha(idx: number, query: string, senha: string, tipo: string) {
    setMsgs(prev => prev.map((m, i) => i === idx && m.role === "assistant" && m.kind === "need_password" ? { ...m, resolved: true } : m))
    const res = await fetch("/api/ai/verify-sensitive", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query, password: senha, tipo }),
    })
    const j = await res.json()
    if (j.ok) {
      setMsgs(prev => [...prev, { role: "assistant", kind: "secret", text: j.content, expiresAt: Date.now() + (j.expiresInSec ?? 30) * 1000 }])
    } else if (j.senhaOk) {
      // Senha CERTA, só não achou a credencial pelo texto — não re-pede senha.
      // Abre o painel guiado de Credenciais (mesmo fluxo do botão), que lista
      // tudo do escopo e revela com 1 toque.
      setMsgs(prev => [...prev, { role: "assistant", kind: "text", text: "Senha confirmada — não achei pelo texto. Escolha a credencial na lista:" }])
      setFlowState({ type: "credenciais", mode: "consultar", step: 1 })
    } else {
      setMsgs(prev => [
        ...prev,
        { role: "assistant", kind: "error", text: j.message ?? "Senha incorreta." },
        ...(j.locked ? [] : [{ role: "assistant" as const, kind: "need_password" as const, text: "Tente novamente:", query, tipo }]),
      ])
    }
  }

  async function resolverAcao(idx: number, confirmar: boolean, acao: string, params: unknown) {
    setMsgs(prev => prev.map((m, i) => i === idx && m.role === "assistant" && m.kind === "confirm_action" ? { ...m, resolved: true } : m))
    if (!confirmar) { setMsgs(prev => [...prev, { role: "assistant", kind: "text", text: "Ação cancelada." }]); return }
    const res = await fetch("/api/ai/confirm-action", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ acao, params }),
    })
    const j = await res.json()
    setMsgs(prev => [...prev, { role: "assistant", kind: j.ok ? "text" : "error", text: j.message ?? (j.ok ? "Feito." : "Erro.") }])
  }

  function resolverCreate(idx: number, confirmar: boolean, payload: unknown) {
    setMsgs(prev => prev.map((m, i) => i === idx && m.role === "assistant" && m.kind === "confirm_create" ? { ...m, resolved: true } : m))
    if (!confirmar) { setMsgs(prev => [...prev, { role: "assistant", kind: "text", text: "Criação cancelada." }]); return }
    setMsgs(prev => [...prev, {
      role: "assistant", kind: "need_password",
      text: "Para salvar, confirme sua senha de acesso.",
      query: JSON.stringify({ __create: true, payload }),
      tipo: tipoSenha(pathname),
    }])
  }

  async function enviarSenhaUnificada(idx: number, query: string, senha: string, tipo: string) {
    try {
      const parsed = JSON.parse(query)
      if (parsed.__create) {
        setMsgs(prev => prev.map((m, i) => i === idx && m.role === "assistant" && m.kind === "need_password" ? { ...m, resolved: true } : m))
        const res = await fetch("/api/ai/create-record", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ password: senha, tipo, payload: parsed.payload }),
        })
        const j = await res.json()
        setMsgs(prev => [...prev, { role: "assistant", kind: j.ok ? "text" : "error", text: j.message ?? (j.ok ? "Criado." : "Erro ao salvar.") }])
        if (j.ok) {
          // Recarrega os dados da página atual — o registro criado pelo chat
          // aparece na tela sem o usuário precisar dar F5.
          router.refresh()
          window.dispatchEvent(new CustomEvent("controllares:data-changed"))
        }
        return
      }
    } catch { /* não é JSON de criação */ }
    await enviarSenha(idx, query, senha, tipo)
  }

  const now = new Date()
  const timeLabel = now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })

  return (
    <>
      {/* Botão flutuante — HIDDEN (acessado pelo rail/sidebar) */}
      <button
        onClick={() => setOpen(true)}
        data-ai-trigger
        aria-label="Abrir assistente CORE"
        className="sr-only"
      />

      {open && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end md:justify-end md:items-end">
          {/* Overlay */}
          <div className="absolute inset-0 bg-black/30 md:bg-black/40 backdrop-blur-sm" onClick={() => setOpen(false)} />

          {/* Painel CORE — bottom-sheet mobile, slide-in panel desktop */}
          <div className="relative flex flex-col bg-[#f2f2f7] dark:bg-[#111] md:bg-card md:dark:bg-card md:w-[420px] md:h-[calc(100vh-64px)] md:rounded-tl-2xl md:shadow-apple-float h-[92dvh] w-full rounded-t-3xl md:rounded-t-none animate-in slide-in-from-bottom md:slide-in-from-right duration-300">

            {/* Drag handle — mobile only */}
            <div className="flex justify-center pt-2.5 pb-0.5 md:hidden flex-shrink-0">
              <div className="w-9 h-1 bg-black/20 dark:bg-white/20 rounded-full" />
            </div>

            {/* ── HEADER iMessage ── */}
            <div className="flex items-center h-[52px] px-4 border-b border-black/[0.08] dark:border-white/[0.08] bg-white/60 dark:bg-black/60 backdrop-blur-xl flex-shrink-0 gap-3">
              {/* Voltar */}
              <button onClick={() => setOpen(false)}
                className="flex items-center gap-1 text-primary text-[17px] font-normal -ml-1 min-w-[44px] h-[44px]">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
                </svg>
                <span className="text-[16px]">Voltar</span>
              </button>

              {/* Avatar + nome + online */}
              <div className="flex flex-col items-center flex-1">
                <div className="relative">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-sky-400 to-blue-600 flex items-center justify-center">
                    <Sparkles className="w-4 h-4 text-white" strokeWidth={2} />
                  </div>
                  {/* Indicador online */}
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white dark:border-black animate-pulse" />
                </div>
                <p className="text-[12px] font-semibold text-foreground leading-none mt-0.5">CORE</p>
              </div>

              {/* Menu */}
              <button className="flex items-center justify-center w-[44px] h-[44px] text-primary">
                <MoreHorizontal className="w-5 h-5" />
              </button>
            </div>

            {/* ── MENSAGENS ── */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-3 space-y-1 min-h-0" style={{ scrollbarWidth: "none" }}>

              {/* Estado vazio */}
              {msgs.length === 0 && (
                <div className="flex flex-col items-center justify-center h-full pb-8 text-center">
                  <div className="w-16 h-16 rounded-full bg-sky-500/15 flex items-center justify-center mb-4">
                    <Sparkles className="w-8 h-8 text-sky-500" strokeWidth={1.5} />
                  </div>
                  <p className="text-[17px] font-semibold text-foreground mb-1">CORE</p>
                  <p className="text-[14px] text-muted-foreground max-w-[220px] leading-snug">Assistente operacional Controllares. Pergunte sobre obras, propostas e documentos.</p>
                </div>
              )}

              {msgs.map((m, i) => {
                const isUser = m.role === "user"
                const showTs = shouldShowTimestamp(msgs, i)

                return (
                  <div key={i}>
                    {/* Timestamp entre grupos */}
                    {showTs && i > 0 && (
                      <div className="text-center py-2">
                        <span className="text-[11px] text-muted-foreground/60">{timeLabel}</span>
                      </div>
                    )}

                    <div className={`flex ${isUser ? "justify-end" : "justify-start"} mb-1`}>

                      {/* Balão */}
                      {m.role === "user" ? (
                        <div className="max-w-[78%] bg-ios-blue text-background px-4 py-2.5 text-[16px] leading-snug"
                          style={{ borderRadius: "20px 20px 4px 20px" }}>
                          {m.text}
                        </div>
                      ) : (
                        <div className={`max-w-[85%] ${
                          m.kind === "error"
                            ? "bg-red-500/10 border border-red-500/20 text-destructive"
                            : m.kind === "secret"
                            ? "bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/30"
                            : "bg-white dark:bg-surface-2 shadow-[0_1px_4px_rgba(0,0,0,0.08)]"
                        } px-4 py-2.5 text-[16px] leading-snug text-foreground`}
                          style={{ borderRadius: "20px 20px 20px 4px" }}>

                          {m.kind === "text" && (() => {
                            const fcards = parseFinancialCards(m.text || "")
                            return (
                              <div className="space-y-2">
                                <div className="text-[15px] leading-relaxed" dangerouslySetInnerHTML={renderMarkdown(m.text || "…")} />
                                {fcards && fcards.length >= 2 && (
                                  <div className="mt-2 space-y-1.5 border-t border-black/[0.06] dark:border-white/[0.06] pt-2">
                                    {fcards.map((c, ci) => (
                                      <div key={ci} className="flex items-center justify-between gap-2 bg-black/[0.03] dark:bg-white/[0.04] rounded-xl px-3 py-2">
                                        <div className="flex items-center gap-2 min-w-0">
                                          {c.status === "danger" && <AlertCircle className="w-3.5 h-3.5 text-destructive flex-shrink-0" />}
                                          {c.status === "warn" && <TrendingDown className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />}
                                          {c.status === "ok" && <TrendingUp className="w-3.5 h-3.5 text-green-500 flex-shrink-0" />}
                                          <span className="text-[12px] text-foreground/70 truncate">{c.label}</span>
                                        </div>
                                        <span className={`text-[13px] font-semibold flex-shrink-0 ${c.status === "danger" ? "text-destructive" : c.status === "warn" ? "text-amber-500" : "text-green-600 dark:text-green-400"}`}>
                                          {c.value}
                                        </span>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            )
                          })()}

                          {m.kind === "error" && (
                            <div className="flex items-start gap-1.5 text-[14px]">
                              <AlertTriangle className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />
                              {m.text}
                            </div>
                          )}

                          {/* Fontes da consulta na internet.

                              O texto acima cita [W1], [W2]; aqui os marcadores
                              viram link. Especificação técnica sem fonte é
                              chute com aparência de resposta — quem vai aplicar
                              um valor elétrico precisa poder abrir a página. */}
                          {m.kind === "fontes" && (
                            <div className="space-y-1">
                              <p className="text-[11px] uppercase tracking-wide opacity-60">Fontes</p>
                              {m.fontes.map(f => (
                                <a key={f.marcador} href={f.url} target="_blank" rel="noreferrer"
                                  className="flex items-start gap-1.5 text-[13px] underline underline-offset-2 opacity-90 hover:opacity-100">
                                  <span className="opacity-60">[{f.marcador}]</span>
                                  <span className="min-w-0 break-all">{f.titulo}</span>
                                </a>
                              ))}
                            </div>
                          )}

                          {/* Anexos — card estilo iMessage com tipo de arquivo */}
                          {m.kind === "attachments" && (
                            <div className="space-y-2">
                              <p className="text-[15px]">{m.text}</p>
                              {m.anexos.map((a, j) => (
                                <a key={j} href={a.url} target="_blank" rel="noreferrer"
                                  className="flex items-center gap-3 bg-[#f2f2f7] dark:bg-white/[0.06] rounded-2xl px-3 py-2.5 transition-all active:opacity-70 active:scale-[0.98]">
                                  <div className="w-10 h-10 rounded-xl bg-background dark:bg-black/30 flex items-center justify-center flex-shrink-0 shadow-sm">
                                    {fileTypeIcon(a.tipo)}
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <p className="text-[14px] font-medium text-foreground truncate">{a.nome}</p>
                                    <p className="text-[11px] text-muted-foreground uppercase tracking-wide">{a.tipo || "arquivo"}</p>
                                  </div>
                                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground flex-shrink-0">
                                    <Download className="w-3.5 h-3.5" />
                                  </div>
                                </a>
                              ))}
                            </div>
                          )}

                          {/* Senha — bottom sheet style dentro do balão */}
                          {m.kind === "need_password" && (
                            <PasswordPrompt text={m.text} disabled={!!m.resolved}
                              onSubmit={senha => enviarSenhaUnificada(i, m.query, senha, m.tipo)} />
                          )}

                          {/* Segredo com countdown */}
                          {m.kind === "secret" && (
                            <SecretBubble text={m.text} expiresAt={m.expiresAt} />
                          )}

                          {/* Confirmação de ação */}
                          {m.kind === "confirm_action" && (
                            <div className="space-y-3">
                              <p className="text-[15px]">{m.text}</p>
                              {!m.resolved && (
                                <div className="flex gap-2">
                                  <button onClick={() => resolverAcao(i, true, m.acao, m.params)}
                                    className="flex-1 flex items-center justify-center gap-1.5 bg-green-500 text-white text-[14px] font-medium h-9 rounded-xl active:opacity-80 transition-opacity">
                                    <Check className="w-3.5 h-3.5" /> Confirmar
                                  </button>
                                  <button onClick={() => resolverAcao(i, false, m.acao, m.params)}
                                    className="flex-1 flex items-center justify-center gap-1.5 bg-black/[0.06] dark:bg-white/[0.08] text-foreground text-[14px] font-medium h-9 rounded-xl active:opacity-80 transition-opacity">
                                    <Ban className="w-3.5 h-3.5" /> Cancelar
                                  </button>
                                </div>
                              )}
                            </div>
                          )}

                          {/* Confirmação de criação */}
                          {m.kind === "confirm_create" && (
                            <div className="space-y-3">
                              <p className="text-[15px]">{m.text}</p>
                              <div className="bg-black/[0.04] dark:bg-white/[0.06] rounded-xl px-3 py-2 text-[13px] font-mono text-foreground/80 whitespace-pre-wrap">{m.summary}</div>
                              {!m.resolved && (
                                <div className="flex gap-2">
                                  <button onClick={() => resolverCreate(i, true, m.payload)}
                                    className="flex-1 flex items-center justify-center gap-1.5 bg-primary text-primary-foreground text-[14px] font-medium h-9 rounded-xl active:opacity-80 transition-opacity">
                                    <Plus className="w-3.5 h-3.5" /> Criar
                                  </button>
                                  <button onClick={() => resolverCreate(i, false, m.payload)}
                                    className="flex-1 flex items-center justify-center gap-1.5 bg-black/[0.06] dark:bg-white/[0.08] text-foreground text-[14px] font-medium h-9 rounded-xl active:opacity-80 transition-opacity">
                                    <Ban className="w-3.5 h-3.5" /> Cancelar
                                  </button>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )
              })}

              {/* Digitando... */}
              {busy && (
                <div className="flex justify-start mb-1">
                  <div className="bg-white dark:bg-[#1c1c1e] shadow-[0_1px_4px_rgba(0,0,0,0.08)] px-4 py-3"
                    style={{ borderRadius: "20px 20px 20px 4px" }}>
                    <div className="flex gap-1 items-center">
                      <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                      <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                      <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* ── FLOW GUIADO (credenciais / anexos) ── */}
            {flowState && (
              <div className="absolute inset-0 z-20 bg-background flex flex-col">
                <FlowPanel
                  flowState={flowState}
                  onUpdate={setFlowState}
                  onClose={() => setFlowState(null)}
                />
              </div>
            )}

            {/* ── MENU FUNIL (quando sem mensagens) ── */}
            {msgs.length === 0 && !flowState && (
              <ProativeMenu
                onSelect={enviar}
                onFlow={(type, mode) => setFlowState({ type, mode, step: 1 })}
              />
            )}

            {/* ── INPUT AREA — estilo iMessage ── */}
            <div className="flex-shrink-0 border-t border-black/[0.08] dark:border-white/[0.08] bg-white/80 dark:bg-black/80 backdrop-blur-xl">

              {/* Chips de ação rápida — some ao digitar */}
              {!input && !hasPendingPassword && msgs.length > 0 && (
                <div className="flex gap-2 px-4 pt-2.5 pb-1 overflow-x-auto no-scrollbar">
                  {getQuickChips(pathname).map(chip => (
                    <button key={chip} onClick={() => enviar(chip)}
                      className="flex-shrink-0 bg-black/[0.05] dark:bg-white/[0.08] text-foreground text-[13px] font-medium px-3 py-1.5 rounded-full whitespace-nowrap active:opacity-70 transition-opacity">
                      {chip}
                    </button>
                  ))}
                </div>
              )}

              <div className="flex items-end gap-2 px-4 py-2.5">
                {hasPendingPassword ? (
                  <div className="flex-1 flex items-center gap-2 text-muted-foreground text-[14px] bg-black/[0.04] dark:bg-white/[0.06] rounded-2xl px-4 h-[44px]">
                    <Lock className="w-4 h-4 text-amber-500 flex-shrink-0" />
                    Digite a senha no campo acima
                  </div>
                ) : (
                  <>
                    {/* Input iMessage */}
                    <div className="flex-1 relative">
                      <input
                        ref={inputRef}
                        value={input}
                        onChange={e => setInput(e.target.value)}
                        onKeyDown={e => { if (e.key === "Enter" && !busy) enviar(input) }}
                        placeholder="Mensagem"
                        disabled={busy}
                        style={{ fontSize: "16px" }}
                        className="w-full bg-white dark:bg-[#2c2c2e] border border-black/[0.1] dark:border-white/[0.1] rounded-2xl px-4 py-[10px] pr-10 text-foreground placeholder:text-muted-foreground/50 outline-none focus:border-primary/30 focus:ring-2 focus:ring-primary/15 transition-all disabled:opacity-50 min-h-[44px] max-h-[120px] resize-none"
                      />
                    </div>

                    {/* Botão enviar / mic */}
                    {input.trim() ? (
                      <button
                        onClick={() => enviar(input)}
                        disabled={busy}
                        className="flex-shrink-0 w-9 h-9 rounded-full bg-primary text-primary-foreground flex items-center justify-center active:scale-90 transition-transform disabled:opacity-40">
                        <ArrowUp className="w-4 h-4" strokeWidth={2.5} />
                      </button>
                    ) : (
                      (
                        <button
                          type="button"
                          onClick={alternarVoz}
                          aria-label={ouvindo ? "Parar de ouvir" : "Ditar por voz"}
                          className={`flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center
                                      active:scale-90 transition-all ${
                            ouvindo
                              /* Vermelho pulsando enquanto ouve: microfone
                                 ligado sem aviso visível é o tipo de coisa que
                                 fica ligada sozinha. */
                              ? "bg-danger text-white animate-pulse"
                              /* Apagado quando o navegador não tem a API — mas
                                 clicável, para dizer o motivo. */
                              : `bg-black/[0.06] dark:bg-white/[0.08] text-muted-foreground${temVoz ? "" : " opacity-50"}`
                          }`}>
                          <Mic className="w-4 h-4" strokeWidth={1.5} />
                        </button>
                      )
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

// ── Senha com timer visual + botão copiar ────────────────────────────────────
function SecretBubble({ text, expiresAt }: { text: string; expiresAt: number }) {
  const [, tick] = useState(0)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    const iv = setInterval(() => tick(x => x + 1), 1000)
    return () => clearInterval(iv)
  }, [])

  const remaining = Math.max(0, Math.ceil((expiresAt - Date.now()) / 1000))
  const total = 30
  const pct = (remaining / total) * 100

  async function copiar() {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
      // Auto-limpa clipboard após 30s (segurança)
      setTimeout(() => navigator.clipboard.writeText("").catch(() => {}), 30_000)
    } catch { /* fallback silencioso */ }
  }

  return (
    <div className="space-y-2">
      {/* Timer bar */}
      <div className="flex items-center gap-2">
        <div className="flex-1 h-1 bg-amber-200 dark:bg-amber-500/20 rounded-full overflow-hidden">
          <div className="h-full bg-amber-500 rounded-full transition-all duration-1000" style={{ width: `${pct}%` }} />
        </div>
        <span className="text-[12px] text-amber-600 dark:text-amber-400 font-medium flex-shrink-0">{remaining}s</span>
      </div>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400 text-[12px] font-medium">
          <Lock className="w-3.5 h-3.5 flex-shrink-0" />
          Some em {remaining}s
        </div>
        <button onClick={copiar}
          className={`flex items-center gap-1 text-[12px] font-medium px-2.5 py-1 rounded-lg transition-all ${
            copied
              ? "bg-green-500/10 text-green-600 dark:text-green-400"
              : "bg-amber-500/10 text-amber-600 dark:text-amber-400 active:opacity-70"
          }`}>
          {copied ? <ClipboardCheck className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
          {copied ? "Copiado!" : "Copiar"}
        </button>
      </div>
      <div className="font-mono text-[15px] whitespace-pre-wrap break-all select-all bg-black/[0.04] dark:bg-white/[0.06] rounded-xl px-3 py-2 border border-amber-200/50 dark:border-amber-500/20">
        {text}
      </div>
    </div>
  )
}

// ── Prompt de senha ───────────────────────────────────────────────────────────
function PasswordPrompt({ text, disabled, onSubmit }: { text: string; disabled: boolean; onSubmit: (s: string) => void }) {
  const [senha, setSenha] = useState("")
  return (
    <div className="space-y-2.5">
      <p className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400 text-[14px] font-medium">
        <Lock className="w-3.5 h-3.5 flex-shrink-0" /> {text}
      </p>
      {!disabled && (
        <div className="flex gap-2">
          <input
            type="password"
            value={senha}
            onChange={e => setSenha(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && senha) { onSubmit(senha); setSenha("") } }}
            autoFocus
            placeholder="Sua senha"
            autoComplete="current-password"
            style={{ fontSize: "16px" }}
            className="flex-1 h-11 bg-black/[0.06] dark:bg-white/[0.08] border border-transparent focus:border-primary/30 rounded-xl px-4 font-mono text-foreground placeholder:text-muted-foreground/50 outline-none transition-all"
          />
          <button
            onClick={() => { if (senha) { onSubmit(senha); setSenha("") } }}
            className="h-11 px-4 bg-primary text-primary-foreground text-[14px] font-semibold rounded-xl active:opacity-80 transition-opacity">
            OK
          </button>
        </div>
      )}
    </div>
  )
}

// ── Menu funil ────────────────────────────────────────────────────────────────
function ProativeMenu({ onSelect, onFlow }: { onSelect: (q: string) => void; onFlow: (type: "credenciais" | "anexos", mode: "consultar" | "salvar") => void }) {
  const [activeArea, setActiveArea] = useState<MenuArea | null>(null)

  if (activeArea) {
    // Areas com flow guiado mostram opções Consultar / Salvar
    if (activeArea.flow) {
      return (
        <div className="px-4 pb-3 space-y-2">
          <button onClick={() => setActiveArea(null)}
            className="text-[14px] text-primary flex items-center gap-1.5 py-1">
            <ChevronRight className="w-4 h-4 rotate-180" />
            <activeArea.Icon className="w-4 h-4" strokeWidth={1.5} />
            {activeArea.label}
          </button>
          <div className="flex flex-col gap-1.5">
            {(["consultar", "salvar"] as const).map(mode => (
              <button key={mode} onClick={() => { setActiveArea(null); onFlow(activeArea.flow!, mode) }}
                className="text-left text-[15px] bg-white dark:bg-[#1c1c1e] shadow-[0_1px_4px_rgba(0,0,0,0.06)] text-foreground rounded-xl px-4 py-3 transition-opacity active:opacity-70 flex items-center justify-between">
                {mode === "consultar" ? (activeArea.flow === "credenciais" ? "Consultar credencial" : "Ver documentos") : (activeArea.flow === "credenciais" ? "Salvar credencial" : "Adicionar documento")}
                <ChevronRight className="w-4 h-4 text-muted-foreground/40 flex-shrink-0" />
              </button>
            ))}
          </div>
        </div>
      )
    }

    return (
      <div className="px-4 pb-3 space-y-2">
        <button onClick={() => setActiveArea(null)}
          className="text-[14px] text-primary flex items-center gap-1.5 py-1">
          <ChevronRight className="w-4 h-4 rotate-180" />
          <activeArea.Icon className="w-4 h-4" strokeWidth={1.5} />
          {activeArea.label}
        </button>
        <div className="flex flex-col gap-1.5">
          {(activeArea.perguntas ?? []).map(q => (
            <button key={q} onClick={() => { setActiveArea(null); onSelect(q) }}
              className="text-left text-[15px] bg-white dark:bg-[#1c1c1e] shadow-[0_1px_4px_rgba(0,0,0,0.06)] text-foreground rounded-xl px-4 py-3 transition-opacity active:opacity-70 flex items-center justify-between">
              {q}
              <ChevronRight className="w-4 h-4 text-muted-foreground/40 flex-shrink-0" />
            </button>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="px-4 pb-3">
      <p className="text-[12px] text-muted-foreground/60 mb-2 font-medium uppercase tracking-wider">O que você precisa?</p>
      <div className="grid grid-cols-3 gap-2">
        {MENU_AREAS.map(area => (
          <button key={area.label}
            onClick={() => setActiveArea(area)}
            className="flex flex-col items-center gap-1.5 bg-white dark:bg-[#1c1c1e] shadow-[0_1px_4px_rgba(0,0,0,0.06)] rounded-2xl px-2 py-3 transition-opacity active:opacity-70 min-h-[44px]">
            <area.Icon className="w-5 h-5 text-foreground/60" strokeWidth={1.5} />
            <span className="text-[11px] text-foreground/70 font-medium leading-tight text-center">{area.label}</span>
          </button>
        ))}
      </div>
    </div>
  )
}

// ── Flow guiado: Credenciais e Anexos ─────────────────────────────────────────
function FlowPanel({
  flowState,
  onUpdate,
  onClose,
}: {
  flowState: FlowState
  onUpdate: (next: FlowState | null) => void
  onClose: () => void
}) {
  const [obras, setObras] = useState<ObraLite[]>([])
  const [busca, setBusca] = useState("")
  const [loading, setLoading] = useState(false)
  const [senha, setSenha] = useState("")
  const [erroSenha, setErroSenha] = useState("")
  const [tick, setTick] = useState(0)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Carrega obras no step 1
  useEffect(() => {
    if (flowState.step !== 1) return
    setLoading(true)
    fetch("/api/obras").then(r => r.ok ? r.json() : { obras: [] })
      .then(d => setObras(d.obras ?? []))
      .finally(() => setLoading(false))
  }, [flowState.step])

  // Timer da revelação
  useEffect(() => {
    if (!flowState.revealed) return
    const iv = setInterval(() => setTick(x => x + 1), 1000)
    return () => clearInterval(iv)
  }, [flowState.revealed])

  // Auto-fecha revelação quando expirar
  useEffect(() => {
    if (!flowState.revealed) return
    if (flowState.revealed.expiresAt <= Date.now()) {
      onUpdate({ ...flowState, revealed: undefined, step: 2 })
    }
  }, [tick, flowState, onUpdate])

  const obrasFiltradas = obras.filter(o => o.client_name.toLowerCase().includes(busca.toLowerCase()))

  // Step 2: carrega credenciais ou anexos
  async function selecionarObra(obra: ObraLite) {
    setLoading(true)
    try {
      if (flowState.type === "credenciais") {
        const r = await fetch(`/api/obras/${obra.id}/credenciais`)
        const d = await r.json()
        onUpdate({ ...flowState, step: 2, obra, credList: d.credenciais ?? [] })
      } else {
        const r = await fetch(`/api/obras/${obra.id}`)
        const d = await r.json()
        onUpdate({ ...flowState, step: 2, obra, anexoList: d.anexos ?? [] })
      }
    } finally {
      setLoading(false)
    }
  }

  // Step 3: verificar senha e revelar
  async function verificarSenha() {
    if (!senha || !flowState.obra) return
    setErroSenha("")

    // ── Anexo: valida a senha do cofre e abre o arquivo ──
    if (flowState.anexoSel && !flowState.cred) {
      const rr = await fetch("/api/ai/verify-sensitive", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: `anexo:${flowState.anexoSel.url}`, password: senha, tipo: "operacional", soValida: true }),
      })
      const jj = await rr.json()
      if (jj.ok || jj.senhaOk) {
        const url = flowState.anexoSel.url
        setSenha("")
        onUpdate({ ...flowState, step: 2, anexoSel: undefined })
        window.open(url, "_blank", "noopener,noreferrer")
      } else {
        const t2 = (flowState.tentativas ?? 0) + 1
        setSenha("")
        if (jj.locked || t2 >= 3) onUpdate({ ...flowState, tentativas: t2, locked: true })
        else { setErroSenha(`${jj.message ?? "Senha incorreta."} ${3 - t2} tentativa(s) restante(s).`); onUpdate({ ...flowState, tentativas: t2 }) }
      }
      return
    }

    if (!flowState.cred) return
    const tentativas = (flowState.tentativas ?? 0) + 1

    const r = await fetch("/api/ai/verify-sensitive", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        query: `credencial:${flowState.cred.id}`,
        password: senha,
        tipo: "operacional",
      }),
    })
    const j = await r.json()

    if (j.ok) {
      setSenha("")
      onUpdate({
        ...flowState,
        tentativas: 0,
        revealed: { text: j.content, expiresAt: Date.now() + 30_000 },
      })
    } else {
      setSenha("")
      if (j.locked || tentativas >= 3) {
        onUpdate({ ...flowState, tentativas, locked: true })
      } else {
        setErroSenha(`${j.message ?? "Senha incorreta."} ${3 - tentativas} tentativa${3 - tentativas !== 1 ? "s" : ""} restante${3 - tentativas !== 1 ? "s" : ""}.`)
        onUpdate({ ...flowState, tentativas })
      }
    }
  }

  // Salvar documento (anexo da obra)
  async function salvarAnexo() {
    if (!flowState.obra || !flowState.uploadFile || !senha) return
    setErroSenha("")
    const fd = new FormData()
    fd.append("file", flowState.uploadFile)
    const upRes = await fetch("/api/upload", { method: "POST", body: fd })
    const upJson = await upRes.json()
    if (!upRes.ok || !upJson.url) { setErroSenha("Falha no upload do arquivo."); return }
    const ext = flowState.uploadFile.name.split(".").pop()?.toLowerCase() ?? ""
    const r = await fetch(`/api/obras/${flowState.obra.id}/anexos`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: senha, nome: flowState.uploadFile.name, url: upJson.url, ext }),
    })
    const j = await r.json()
    if (!j.ok) { setErroSenha(j.message ?? "Senha incorreta."); return }
    setSenha("")
    onUpdate(null)
  }

  // Salvar nova credencial
  async function salvarCredencial() {
    if (!flowState.obra || !flowState.novaCred || !senha) return
    setErroSenha("")
    const r = await fetch(`/api/obras/${flowState.obra.id}/credenciais`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        cofre_senha: senha,
        tipo_equipamento: flowState.novaCred.tipo,
        login: flowState.novaCred.login,
        senha: flowState.novaCred.senha,
        observacoes: flowState.novaCred.obs,
      }),
    })
    const j = await r.json().catch(() => ({}))
    if (!r.ok || !j.ok) { setErroSenha(j.error ?? "Senha do cofre incorreta."); return }
    setSenha("")
    onUpdate(null)
  }

  const CARD = "bg-slate-800/60 dark:bg-slate-800/60 bg-slate-100/80 rounded-2xl p-4 mb-3 flex items-center gap-3 active:opacity-70 transition-opacity cursor-pointer text-left w-full"
  const indigo = "w-full h-12 rounded-xl bg-indigo-500 hover:bg-indigo-600 text-white font-semibold text-[15px] flex items-center justify-center gap-2 transition-colors active:opacity-80"

  // ── STEP 1: Lista obras ────────────────────────────────────────────────────
  if (flowState.step === 1) {
    return (
      <div className="flex flex-col h-full">
        <div className="flex items-center gap-2 px-4 pt-3 pb-2 border-b border-black/[0.06] dark:border-white/[0.06]">
          <button onClick={onClose} className="text-primary text-[15px] flex items-center gap-1">
            <ChevronRight className="w-4 h-4 rotate-180" /> Voltar
          </button>
          <span className="flex-1 text-center text-[15px] font-semibold text-foreground">
            {flowState.type === "credenciais" ? "Credenciais" : "Documentos"}
          </span>
        </div>

        <div className="px-4 pt-3 pb-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50" />
            <input
              value={busca}
              onChange={e => setBusca(e.target.value)}
              placeholder="Buscar obra..."
              className="w-full h-10 pl-9 pr-4 rounded-xl bg-black/[0.05] dark:bg-white/[0.06] text-foreground placeholder:text-muted-foreground/50 text-[15px] outline-none"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-4 pb-4" style={{ scrollbarWidth: "none" }}>
          {loading ? (
            <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">Carregando obras...</div>
          ) : obrasFiltradas.length === 0 ? (
            <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">Nenhuma obra encontrada</div>
          ) : (
            obrasFiltradas.map(o => (
              <button key={o.id} onClick={() => selecionarObra(o)} className={CARD}>
                <div className="w-10 h-10 rounded-xl bg-amber-500/15 flex items-center justify-center flex-shrink-0">
                  <HardHat className="w-5 h-5 text-amber-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[15px] font-medium text-foreground truncate">{o.client_name}</p>
                  <p className="text-[12px] text-muted-foreground">{o.etapa ?? "Nova obra"}</p>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground/40 flex-shrink-0" />
              </button>
            ))
          )}
        </div>
      </div>
    )
  }

  // ── STEP 2: Credenciais ou Anexos ──────────────────────────────────────────
  if (flowState.step === 2) {
    const isCredenciais = flowState.type === "credenciais"
    const canSave = flowState.mode === "salvar"

    return (
      <div className="flex flex-col h-full">
        <div className="flex items-center gap-2 px-4 pt-3 pb-2 border-b border-black/[0.06] dark:border-white/[0.06]">
          <button onClick={() => onUpdate({ ...flowState, step: 1, obra: undefined })}
            className="text-primary text-[15px] flex items-center gap-1">
            <ChevronRight className="w-4 h-4 rotate-180" /> Obras
          </button>
          <span className="flex-1 text-center text-[14px] font-semibold text-foreground truncate">
            {flowState.obra?.client_name}
          </span>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-3" style={{ scrollbarWidth: "none" }}>
          {isCredenciais ? (
            <>
              {(flowState.credList ?? []).length === 0 && (
                <p className="text-muted-foreground text-sm text-center py-8">Nenhuma credencial cadastrada</p>
              )}
              {(flowState.credList ?? []).map(c => {
                const Icon = credIcon(c.tipo_equipamento)
                return (
                  <button key={c.id}
                    onClick={() => onUpdate({ ...flowState, step: 3, cred: c })}
                    className={CARD}>
                    <div className="w-10 h-10 rounded-xl bg-indigo-500/15 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5 text-indigo-500" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[15px] font-medium text-foreground truncate">{c.tipo_equipamento}</p>
                      <p className="text-[12px] text-muted-foreground">
                        {c.login ? `Login: ${c.login}` : "Sem login"}
                        {c.tem_senha ? " · Senha" : ""}
                        {c.tem_ip ? " · IP" : ""}
                        {c.tem_mac ? " · MAC" : ""}
                      </p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground/40 flex-shrink-0" />
                  </button>
                )
              })}

              {canSave && (
                <button
                  onClick={() => onUpdate({
                    ...flowState, step: 3,
                    novaCred: { tipo: "", login: "", senha: "", obs: "" },
                  })}
                  className="w-full flex items-center justify-center gap-2 border-2 border-dashed border-indigo-400/50 rounded-2xl py-4 text-indigo-500 font-medium text-[15px] mt-2 active:opacity-70 transition-opacity">
                  <Plus className="w-5 h-5" /> Nova Credencial
                </button>
              )}
            </>
          ) : (
            <>
              {(flowState.anexoList ?? []).length === 0 && (
                <p className="text-muted-foreground text-sm text-center py-8">Nenhum documento cadastrado</p>
              )}
              {(flowState.anexoList ?? []).map((a, idx) => (
                <button key={idx}
                  onClick={() => onUpdate({ ...flowState, step: 3, cred: undefined, anexoSel: a })}
                  className={CARD}>
                  <div className="w-10 h-10 rounded-xl bg-blue-500/15 flex items-center justify-center flex-shrink-0">
                    {fileTypeIcon(a.ext)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[15px] font-medium text-foreground truncate">{a.nome}</p>
                    <p className="text-[12px] text-muted-foreground uppercase">{a.ext || "arquivo"}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground/40 flex-shrink-0" />
                </button>
              ))}

              {canSave && (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full flex items-center justify-center gap-2 border-2 border-dashed border-blue-400/50 rounded-2xl py-4 text-blue-500 font-medium text-[15px] mt-2 active:opacity-70 transition-opacity">
                  <Upload className="w-5 h-5" /> Adicionar Documento
                  <input ref={fileInputRef} type="file" className="hidden"
                    onChange={e => {
                      const f = e.target.files?.[0]
                      if (f) onUpdate({ ...flowState, step: 3, uploadFile: f })
                    }} />
                </button>
              )}
            </>
          )}
        </div>
      </div>
    )
  }

  // ── STEP 3: Senha → revelar ────────────────────────────────────────────────
  if (flowState.step === 3) {
    const isCreating = !!flowState.novaCred || !!flowState.uploadFile

    // Revelação ativa
    if (flowState.revealed) {
      const remaining = Math.max(0, Math.ceil((flowState.revealed.expiresAt - Date.now()) / 1000))
      const pct = (remaining / 30) * 100
      return (
        <div className="flex flex-col h-full">
          <div className="flex items-center gap-2 px-4 pt-3 pb-2 border-b border-black/[0.06] dark:border-white/[0.06]">
            <button onClick={() => onUpdate({ ...flowState, revealed: undefined, step: 2 })}
              className="text-primary text-[15px] flex items-center gap-1">
              <ChevronRight className="w-4 h-4 rotate-180" /> Voltar
            </button>
            <span className="flex-1 text-center text-[14px] font-semibold">{flowState.cred?.tipo_equipamento}</span>
          </div>
          <div className="flex-1 px-4 py-6 space-y-4">
            {/* Timer */}
            <div className="flex items-center gap-3">
              <div className="flex-1 h-1.5 bg-amber-200 dark:bg-amber-500/20 rounded-full overflow-hidden">
                <div className="h-full bg-amber-500 rounded-full transition-all duration-1000" style={{ width: `${pct}%` }} />
              </div>
              <span className="text-[13px] text-amber-600 dark:text-amber-400 font-semibold flex-shrink-0">{remaining}s</span>
            </div>
            {/* Conteúdo revelado */}
            <div className="bg-slate-800 dark:bg-slate-700 rounded-2xl p-4 font-mono text-[14px] text-green-400 whitespace-pre-wrap break-all select-all">
              {flowState.revealed.text}
            </div>
            <p className="text-[12px] text-amber-600 dark:text-amber-400 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5" /> Some em {remaining}s · Não faça screenshots
            </p>
          </div>
        </div>
      )
    }

    // Bloqueado
    if (flowState.locked) {
      return (
        <div className="flex flex-col h-full items-center justify-center px-8 text-center gap-4">
          <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center">
            <Lock className="w-8 h-8 text-destructive" />
          </div>
          <p className="text-[17px] font-semibold text-foreground">Acesso bloqueado</p>
          <p className="text-[14px] text-muted-foreground">3 tentativas incorretas. Acesso bloqueado por 10 minutos. Administrador notificado.</p>
          <button onClick={onClose} className={indigo}>Fechar</button>
        </div>
      )
    }

    // Formulário nova credencial
    if (isCreating && flowState.novaCred) {
      const nc = flowState.novaCred
      return (
        <div className="flex flex-col h-full">
          <div className="flex items-center gap-2 px-4 pt-3 pb-2 border-b border-black/[0.06] dark:border-white/[0.06]">
            <button onClick={() => onUpdate({ ...flowState, step: 2, novaCred: undefined })}
              className="text-primary text-[15px] flex items-center gap-1">
              <ChevronRight className="w-4 h-4 rotate-180" /> Credenciais
            </button>
            <span className="flex-1 text-center text-[14px] font-semibold">Nova Credencial</span>
          </div>
          <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3" style={{ scrollbarWidth: "none" }}>
            {(["tipo", "login", "senha", "obs"] as const).map(field => (
              <div key={field} className="space-y-1">
                <label className="text-[12px] text-muted-foreground uppercase tracking-wide font-medium">
                  {field === "tipo" ? "Tipo de equipamento" : field === "login" ? "Login / usuário" : field === "senha" ? "Senha" : "Observações"}
                </label>
                <input
                  type={field === "senha" ? "password" : "text"}
                  value={nc[field]}
                  onChange={e => onUpdate({ ...flowState, novaCred: { ...nc, [field]: e.target.value } })}
                  placeholder={field === "tipo" ? "ex: Roteador Wi-Fi" : field === "login" ? "ex: admin" : field === "senha" ? "••••••••" : "Opcional"}
                  style={{ fontSize: "16px" }}
                  className="w-full h-12 px-4 rounded-xl bg-black/[0.05] dark:bg-white/[0.06] text-foreground placeholder:text-muted-foreground/50 outline-none focus:ring-2 focus:ring-indigo-500/40 font-mono"
                />
              </div>
            ))}
            <div className="space-y-1 pt-2">
              <label className="text-[12px] text-muted-foreground uppercase tracking-wide font-medium">Sua senha de acesso</label>
              <input
                type="password"
                value={senha}
                onChange={e => setSenha(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter" && senha && nc.tipo) salvarCredencial() }}
                placeholder="Confirme sua senha"
                style={{ fontSize: "16px" }}
                className="w-full h-12 px-4 rounded-xl bg-black/[0.05] dark:bg-white/[0.06] text-foreground placeholder:text-muted-foreground/50 outline-none focus:ring-2 focus:ring-indigo-500/40"
              />
            </div>
            {erroSenha && <p className="text-[13px] text-destructive">{erroSenha}</p>}
            <button onClick={salvarCredencial} disabled={!senha || !nc.tipo} className={`${indigo} disabled:opacity-40 disabled:cursor-not-allowed mt-2`}>
              <Check className="w-4 h-4" /> Salvar credencial
            </button>
          </div>
        </div>
      )
    }

    // Confirmar upload de documento
    if (isCreating && flowState.uploadFile) {
      const f = flowState.uploadFile
      const ext = f.name.split(".").pop()?.toLowerCase() ?? ""
      return (
        <div className="flex flex-col h-full items-center justify-center px-6 gap-6">
          <div className="w-16 h-16 rounded-full bg-indigo-500/15 flex items-center justify-center">
            {fileTypeIcon(ext)}
          </div>
          <div className="text-center">
            <p className="text-[17px] font-semibold text-foreground truncate max-w-[240px]">{f.name}</p>
            <p className="text-[14px] text-muted-foreground mt-1">{flowState.obra?.client_name}</p>
          </div>
          <div className="w-full space-y-3">
            <input
              type="password"
              value={senha}
              onChange={e => { setSenha(e.target.value); setErroSenha("") }}
              onKeyDown={e => { if (e.key === "Enter" && senha) salvarAnexo() }}
              autoFocus
              placeholder="Sua senha de acesso"
              style={{ fontSize: "16px" }}
              className="w-full h-12 px-4 rounded-xl bg-black/[0.05] dark:bg-white/[0.06] text-foreground placeholder:text-muted-foreground/50 outline-none focus:ring-2 focus:ring-indigo-500/40 font-mono text-center"
            />
            {erroSenha && <p className="text-[13px] text-destructive text-center">{erroSenha}</p>}
            <button onClick={salvarAnexo} disabled={!senha} className={`${indigo} disabled:opacity-40`}>
              <Upload className="w-4 h-4" /> Salvar documento
            </button>
            <button onClick={() => onUpdate({ ...flowState, step: 2, uploadFile: undefined })}
              className="w-full h-11 rounded-xl bg-black/[0.04] dark:bg-white/[0.06] text-muted-foreground text-[15px] active:opacity-70">
              Cancelar
            </button>
          </div>
        </div>
      )
    }

    // Prompt de senha para revelar
    return (
      <div className="flex flex-col h-full items-center justify-center px-6 gap-6">
        <div className="w-16 h-16 rounded-full bg-indigo-500/15 flex items-center justify-center">
          <Lock className="w-8 h-8 text-indigo-500" />
        </div>
        <div className="text-center">
          <p className="text-[17px] font-semibold text-foreground">{flowState.cred?.tipo_equipamento ?? "Documento"}</p>
          <p className="text-[14px] text-muted-foreground mt-1">{flowState.obra?.client_name}</p>
        </div>
        <div className="w-full space-y-3">
          <input
            type="password"
            value={senha}
            onChange={e => setSenha(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && senha) verificarSenha() }}
            autoFocus
            placeholder="Sua senha de acesso"
            style={{ fontSize: "16px" }}
            className="w-full h-12 px-4 rounded-xl bg-black/[0.05] dark:bg-white/[0.06] text-foreground placeholder:text-muted-foreground/50 outline-none focus:ring-2 focus:ring-indigo-500/40 font-mono text-center"
          />
          {erroSenha && <p className="text-[13px] text-destructive text-center">{erroSenha}</p>}
          <button onClick={verificarSenha} disabled={!senha} className={`${indigo} disabled:opacity-40`}>
            <Lock className="w-4 h-4" /> Revelar
          </button>
          <button onClick={() => onUpdate({ ...flowState, step: 2 })}
            className="w-full h-11 rounded-xl bg-black/[0.04] dark:bg-white/[0.06] text-muted-foreground text-[15px] active:opacity-70">
            Cancelar
          </button>
        </div>
      </div>
    )
  }

  return null
}
