"use client"

import { createContext, useCallback, useContext, useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog"
import { AlertTriangle } from "lucide-react"

/**
 * Confirmação e aviso na cara do sistema, no lugar dos do navegador.
 *
 * O `confirm()` nativo abre uma caixa cinza do Chrome estampando o endereço do
 * servidor — `projeto-controllares-laqbr6xlr.vercel.app diz` —, que é o nome
 * interno do deploy e não diz nada a quem usa. Além de feio, ele mente sobre
 * onde a pessoa está: parece aviso do navegador, não do sistema.
 *
 * O nativo também trava a aba inteira enquanto está aberto. Este não: é um
 * modal comum, que respeita o tema e fecha no Esc.
 *
 * Uso:
 *   const confirmar = useConfirmar()
 *   if (!await confirmar({ titulo: "Apagar?", texto: "Não dá para desfazer." })) return
 */

export interface PedidoConfirmacao {
  titulo: string
  texto?: string
  /** Rótulo do botão que segue adiante. */
  confirmar?: string
  cancelar?: string
  /** Ação destrutiva pinta o botão de vermelho e mostra o triângulo. */
  perigo?: boolean
  /** Só avisa: um botão só, sem "cancelar". */
  apenasAviso?: boolean
}

type Resolver = (ok: boolean) => void

const Ctx = createContext<((p: PedidoConfirmacao) => Promise<boolean>) | null>(null)

export function ConfirmarProvider({ children }: { children: React.ReactNode }) {
  const [pedido, setPedido] = useState<PedidoConfirmacao | null>(null)
  const [resolver, setResolver] = useState<{ fn: Resolver } | null>(null)

  const pedir = useCallback((p: PedidoConfirmacao) => {
    setPedido(p)
    return new Promise<boolean>(resolve => setResolver({ fn: resolve }))
  }, [])

  function fechar(ok: boolean) {
    resolver?.fn(ok)
    setResolver(null)
    setPedido(null)
  }

  return (
    <Ctx.Provider value={pedir}>
      {children}
      <Dialog open={!!pedido} onOpenChange={o => { if (!o) fechar(false) }}>
        <DialogContent className="w-[calc(100vw-32px)] sm:max-w-md mx-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {pedido?.perigo && <AlertTriangle className="h-4 w-4 shrink-0 text-ios-red" />}
              {pedido?.titulo}
            </DialogTitle>
          </DialogHeader>

          {/* whitespace-pre-line: o texto às vezes é uma lista com uma linha por
              item (o teste de WhatsApp, por exemplo). Sem isso tudo vira um
              parágrafo corrido e o resultado de cada número se perde. */}
          {!!pedido?.texto && (
            <p className="whitespace-pre-line px-5 pb-1 text-[13px] leading-relaxed text-muted-foreground sm:px-6">
              {pedido.texto}
            </p>
          )}

          <DialogFooter className="gap-2">
            {!pedido?.apenasAviso && (
              <Button variant="outline" onClick={() => fechar(false)}>
                {pedido?.cancelar ?? "Cancelar"}
              </Button>
            )}
            <Button autoFocus
              variant={pedido?.perigo ? "destructive" : "default"}
              onClick={() => fechar(true)}>
              {pedido?.confirmar ?? (pedido?.apenasAviso ? "Entendi" : "Confirmar")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Ctx.Provider>
  )
}

/**
 * Devolve a função que abre o diálogo.
 *
 * Fora do provider ela cai no `confirm` do navegador em vez de quebrar a tela:
 * um componente montado num canto sem provider deve continuar perguntando, nem
 * que seja feio — deixar de perguntar é que seria grave numa ação destrutiva.
 */
export function useConfirmar() {
  const ctx = useContext(Ctx)
  return ctx ?? (async (p: PedidoConfirmacao) => {
    if (p.apenasAviso) { window.alert(`${p.titulo}\n\n${p.texto ?? ""}`.trim()); return true }
    return window.confirm(`${p.titulo}\n\n${p.texto ?? ""}`.trim())
  })
}
