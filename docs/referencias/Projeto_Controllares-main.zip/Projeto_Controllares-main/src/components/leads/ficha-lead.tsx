"use client"

/**
 * A ficha do cliente — o que se lê ao voltar nele três meses depois.
 *
 * A linha do tempo sozinha não respondia essa pergunta. Ela prova o que
 * aconteceu, em ordem, e é ótima para isso; mas quem reabre um lead parado não
 * quer ler quarenta anotações para descobrir que o cliente estava esperando a
 * obra sair do acabamento e que quem decide é a esposa. Precisa do ESTADO:
 * onde parou, o que ficou combinado, em que pé está a obra, quem são as
 * pessoas, o que ele quer.
 *
 * Por isso os dois convivem, e a divisão é proposital: o histórico não se
 * apaga porque é registro; a ficha se sobrescreve porque é o retrato de agora.
 */

import { useCallback, useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import {
  Flame, CalendarClock, Building, Ruler, Wallet, UserCheck, Swords, MapPin,
  Users, Plus, Trash2, Star, Phone, Mail, Save, Home, Layers, ArrowRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { showToast } from "@/components/ui/toast"
import { formatarTelefone } from "@/lib/documento"
import { CampoMascarado } from "@/components/ui/campo-mascarado"
import {
  PAPEIS_CONTATO, TEMPERATURAS, TIPOS_IMOVEL, ETAPAS_OBRA, SISTEMAS, rotulo,
} from "@/lib/lead-ficha"

export interface FichaValores {
  resumo: string | null
  proximo_passo: string | null
  proximo_passo_em: string | null
  temperatura: string | null
  tipo_imovel: string | null
  etapa_obra: string | null
  previsao_mudanca: string | null
  metragem: number | null
  ambientes_previstos: number | null
  sistemas: string[]
  orcamento_declarado: string | number | null
  decisor: string | null
  concorrentes: string | null
  endereco_obra: string | null
}

interface Contato {
  id: string; nome: string; papel: string
  telefone: string | null; email: string | null
  observacao: string | null; principal: boolean
}

const CONTATO_VAZIO = {
  nome: "", papel: "ARQUITETO", telefone: "", email: "", observacao: "", principal: false,
}

/** A data como o <input type="date"> quer: aaaa-mm-dd. */
const paraInput = (iso: string | null) => (iso ? new Date(iso).toISOString().slice(0, 10) : "")

const campoClasse =
  "flex h-11 w-full rounded-[16px] border border-border bg-background/60 px-3 text-[15px] text-foreground focus:outline-none"

function Secao({ titulo, children }: { titulo: string; children: React.ReactNode }) {
  return (
    <section className="space-y-2.5">
      <h4 className="px-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-fg">{titulo}</h4>
      {children}
    </section>
  )
}

/**
 * O que já foi montado para este cliente e ele ainda não levou.
 *
 * O cliente que gosta de tudo e fecha um sistema só é a regra, não a exceção.
 * Antes, o que ele não levava era apagado da proposta e o trabalho ia junto;
 * agora fica aqui, com os itens escolhidos na época, esperando ele voltar.
 *
 * Some quando não há nada guardado: seção vazia em ficha que já é longa só
 * empurra para baixo o que importa.
 */
/* Os três destinos de um sistema montado, na ordem em que se lê um cliente:
   o que ele levou, o que está na gaveta esperando a hora, e o que morreu. A
   conversa de retomada é diferente em cada um, e era isso que a lista única
   escondia. */
const GRUPOS_SISTEMA = [
  { status: "ACEITO", titulo: "Aceito", legenda: "Ele já levou", cor: "bg-ios-green" },
  { status: "GUARDADO", titulo: "Guardado", legenda: "Ainda não oferecido", cor: "bg-ios-orange" },
  { status: "RECUSADO", titulo: "Recusado", legenda: "Ele viu e não quis", cor: "bg-ios-red" },
] as const

function SistemasGuardados({ leadId }: { leadId: string }) {
  const router = useRouter()
  const [sistemas, setSistemas] = useState<{
    id: string; nome: string; status: string; itens: number; valorNaEpoca: number
    proposta: { id: string; numero: string } | null
    produtos: { nome: string; quantidade: number }[]
  }[]>([])
  const [aberto, setAberto] = useState<string | null>(null)

  useEffect(() => {
    let vivo = true
    fetch(`/api/leads/${leadId}/sistemas-guardados`, { cache: "no-store" })
      .then(r => r.ok ? r.json() : null)
      .then(j => { if (vivo && j?.sistemas) setSistemas(j.sistemas) })
      .catch(() => {})
    return () => { vivo = false }
  }, [leadId])

  if (sistemas.length === 0) return null

  return (
    <Secao titulo="Histórico de sistemas">
      <div className="space-y-4">
        {GRUPOS_SISTEMA.map(grupo => {
          const doGrupo = sistemas.filter(s => s.status === grupo.status)
          // Grupo vazio não vira título solto.
          if (!doGrupo.length) return null
          return (
            <div key={grupo.status} className="space-y-1.5">
              <div className="flex items-center gap-1.5 px-0.5">
                <span className={`h-1.5 w-1.5 flex-shrink-0 rounded-full ${grupo.cor}`} />
                <span className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-fg">
                  {grupo.titulo}
                </span>
                <span className="text-[11px] text-muted-fg/60">{doGrupo.length}</span>
              </div>
              {doGrupo.map(s => (
            <div key={s.id} className="rounded-[14px] border border-border bg-background/40 px-3 py-2.5">
              <button type="button" onClick={() => setAberto(a => a === s.id ? null : s.id)}
                className="flex w-full items-center gap-2 text-left">
                <span className="min-w-0 flex-1 truncate text-[14px] text-foreground">{s.nome}</span>
                <span className="flex-shrink-0 text-[11px] text-muted-fg">
                  {s.itens} {s.itens === 1 ? "item" : "itens"}
                </span>
              </button>
              <p className="mt-1 text-[11.5px] text-muted-fg">
                {grupo.legenda}
                {s.proposta && ` · ${s.proposta.numero}`}
                {" · "}
                {/* Valor da época, dito com todas as letras. Preço de catálogo
                    muda e campanha vence: repetir o número velho calado é o
                    jeito mais rápido de vender no prejuízo. */}
                <span title="Preço da época. O resgate recalcula pelo catálogo atual.">
                  valia {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(s.valorNaEpoca)} na época
                </span>
              </p>
              {aberto === s.id && (
                <>
                  {s.produtos.length > 0 && (
                    <ul className="mt-2 space-y-0.5 border-t border-border/60 pl-3.5 pt-2">
                      {s.produtos.map((pr, i) => (
                        <li key={i} className="truncate text-[12px] text-muted-fg">
                          {pr.quantidade}x {pr.nome}
                        </li>
                      ))}
                    </ul>
                  )}
                  {/* Qualquer um dos três (guardado, recusado ou já aceito)
                      pode virar ponto de partida de um orçamento novo — o
                      preço é recalculado pelo catálogo de hoje ao entrar lá,
                      não repete o valor congelado desta tela. */}
                  <button type="button"
                    onClick={() => router.push(
                      `/propostas/nova?lead=${leadId}&resgatarSistema=${s.id}`,
                    )}
                    className="mt-2 flex items-center gap-1 rounded-full bg-ios-blue/10 px-2.5 py-1 text-[11px] font-medium text-ios-blue active:opacity-70">
                    <ArrowRight className="h-3 w-3" /> Usar num orçamento novo
                  </button>
                </>
              )}
            </div>
              ))}
            </div>
          )
        })}
      </div>
    </Secao>
  )
}

export function FichaLead({
  leadId, valores, aoSalvar,
}: {
  leadId: string
  valores: FichaValores
  /** Devolve o lead atualizado para a lista de fora não ficar desatualizada. */
  aoSalvar?: () => void
}) {
  const [f, setF] = useState(() => ({
    resumo: valores.resumo ?? "",
    proximo_passo: valores.proximo_passo ?? "",
    proximo_passo_em: paraInput(valores.proximo_passo_em),
    temperatura: valores.temperatura ?? "",
    tipo_imovel: valores.tipo_imovel ?? "",
    etapa_obra: valores.etapa_obra ?? "",
    previsao_mudanca: paraInput(valores.previsao_mudanca),
    metragem: valores.metragem != null ? String(valores.metragem) : "",
    ambientes_previstos: valores.ambientes_previstos != null ? String(valores.ambientes_previstos) : "",
    sistemas: valores.sistemas ?? [],
    orcamento_declarado: valores.orcamento_declarado != null ? String(valores.orcamento_declarado) : "",
    decisor: valores.decisor ?? "",
    concorrentes: valores.concorrentes ?? "",
    endereco_obra: valores.endereco_obra ?? "",
  }))
  const [salvando, setSalvando] = useState(false)
  /* Null = campo fechado. String vazia é diferente de fechado: é o campo
     aberto e ainda em branco. */
  const [novoSistema, setNovoSistema] = useState<string | null>(null)
  const [sujo, setSujo] = useState(false)

  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => {
    setF(prev => ({ ...prev, [k]: v }))
    setSujo(true)
  }

  async function salvar() {
    setSalvando(true)
    try {
      const r = await fetch(`/api/leads/${leadId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...f,
          /* Vazio vira nulo aqui e não no servidor: "" numa data quebraria o
             new Date(), e num número viraria NaN silencioso. */
          proximo_passo_em: f.proximo_passo_em || null,
          previsao_mudanca: f.previsao_mudanca || null,
          metragem: f.metragem || null,
          ambientes_previstos: f.ambientes_previstos || null,
          orcamento_declarado: f.orcamento_declarado || null,
        }),
      })
      if (!r.ok) {
        const j = await r.json().catch(() => ({}))
        showToast(j.error || "Não deu para salvar a ficha.", { variant: "error" })
        return
      }
      setSujo(false)
      showToast("Ficha salva.", { variant: "success" })
      aoSalvar?.()
    } finally { setSalvando(false) }
  }

  // ── Pessoas ───────────────────────────────────────────────────────────────
  const [contatos, setContatos] = useState<Contato[]>([])
  const [novo, setNovo] = useState<typeof CONTATO_VAZIO | null>(null)
  const [salvandoContato, setSalvandoContato] = useState(false)

  const carregarContatos = useCallback(async () => {
    const r = await fetch(`/api/leads/${leadId}/contatos`, { cache: "no-store" })
    if (r.ok) setContatos((await r.json()).contatos ?? [])
  }, [leadId])
  useEffect(() => { carregarContatos() }, [carregarContatos])

  async function criarContato() {
    if (!novo?.nome.trim()) return
    setSalvandoContato(true)
    try {
      const r = await fetch(`/api/leads/${leadId}/contatos`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(novo),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { showToast(j.error || "Não deu para adicionar.", { variant: "error" }); return }
      setNovo(null)
      carregarContatos()
    } finally { setSalvandoContato(false) }
  }

  async function marcarPrincipal(c: Contato) {
    await fetch(`/api/leads/${leadId}/contatos/${c.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ principal: !c.principal }),
    })
    carregarContatos()
  }

  async function removerContato(c: Contato) {
    await fetch(`/api/leads/${leadId}/contatos/${c.id}`, { method: "DELETE" })
    setContatos(l => l.filter(x => x.id !== c.id))
  }

  const passoVencido =
    !!f.proximo_passo_em && new Date(f.proximo_passo_em) < new Date(new Date().toDateString())

  return (
    <div className="space-y-6">
      {/* ── Retomada ───────────────────────────────────────────────────────
          Primeiro bloco de propósito: é o que resolve a pergunta "por onde eu
          começo com esse cliente?" sem rolar a tela. */}
      <Secao titulo="Onde paramos">
        <textarea
          value={f.resumo} onChange={e => set("resumo", e.target.value)} rows={3}
          placeholder="Em duas linhas: o que ele quer, o que travou, o que ficou combinado."
          className="w-full resize-none rounded-[16px] border border-border bg-background/60 px-4 py-2.5 text-[15px] leading-relaxed text-foreground placeholder:text-muted-foreground focus:outline-none"
        />

        <div className="grid gap-2.5 sm:grid-cols-[1fr_auto]">
          <div className="space-y-1.5">
            <Label className="flex items-center gap-1.5"><CalendarClock className="h-3.5 w-3.5" /> Próximo passo</Label>
            <Input value={f.proximo_passo} onChange={e => set("proximo_passo", e.target.value)}
              placeholder="Ligar quando ele voltar da viagem, mandar orçamento do som..." />
          </div>
          <div className="space-y-1.5">
            <Label>Quando</Label>
            <input type="date" value={f.proximo_passo_em}
              onChange={e => set("proximo_passo_em", e.target.value)}
              className={`${campoClasse} ${passoVencido ? "border-ios-red/60 text-ios-red" : ""}`} />
          </div>
        </div>
        {passoVencido && (
          <p className="px-1 text-[11px] text-ios-red">Data já passou. O cliente está esperando.</p>
        )}

        <div className="space-y-1.5">
          <Label className="flex items-center gap-1.5"><Flame className="h-3.5 w-3.5" /> Temperatura</Label>
          <div className="flex flex-wrap gap-1.5">
            {TEMPERATURAS.map(t => (
              <button key={t.id} type="button"
                onClick={() => set("temperatura", f.temperatura === t.id ? "" : t.id)}
                title={t.nota}
                className={`flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[12px] font-medium transition-colors ${
                  f.temperatura === t.id
                    ? "border-transparent bg-surface-1 text-foreground shadow-sm"
                    : "border-hairline text-muted-fg hover:text-foreground"
                }`}>
                <span className={`h-2 w-2 rounded-full ${t.cor}`} /> {t.label}
              </button>
            ))}
          </div>
          {/* A etapa diz onde ele está no processo; a temperatura, para quem
              ligar primeiro hoje de manhã. São perguntas diferentes. */}
          <p className="px-1 text-[11px] text-muted-fg">
            {TEMPERATURAS.find(t => t.id === f.temperatura)?.nota ?? "Não é a etapa do funil. É o quanto ele está perto de decidir."}
          </p>
        </div>
      </Secao>

      {/* ── Projeto ────────────────────────────────────────────────────────── */}
      <Secao titulo="O projeto">
        <div className="grid gap-2.5 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label className="flex items-center gap-1.5"><Home className="h-3.5 w-3.5" /> Tipo de imóvel</Label>
            <select value={f.tipo_imovel} onChange={e => set("tipo_imovel", e.target.value)} className={campoClasse}>
              <option value="">Não informado</option>
              {TIPOS_IMOVEL.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label className="flex items-center gap-1.5"><Building className="h-3.5 w-3.5" /> Etapa da obra</Label>
            <select value={f.etapa_obra} onChange={e => set("etapa_obra", e.target.value)} className={campoClasse}>
              <option value="">Não informado</option>
              {ETAPAS_OBRA.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}
            </select>
            {/* Ligar na etapa errada é perder a venda por tempo, não por preço. */}
            {f.etapa_obra && (
              <p className="px-1 text-[11px] text-ios-orange">
                {ETAPAS_OBRA.find(e => e.id === f.etapa_obra)?.nota}
              </p>
            )}
          </div>
        </div>

        <div className="grid gap-2.5 sm:grid-cols-3">
          <div className="space-y-1.5">
            <Label className="flex items-center gap-1.5"><Ruler className="h-3.5 w-3.5" /> Metragem</Label>
            <Input type="number" min="0" value={f.metragem}
              onChange={e => set("metragem", e.target.value)} placeholder="m²" />
          </div>
          <div className="space-y-1.5">
            <Label className="flex items-center gap-1.5"><Layers className="h-3.5 w-3.5" /> Ambientes</Label>
            <Input type="number" min="0" value={f.ambientes_previstos}
              onChange={e => set("ambientes_previstos", e.target.value)} placeholder="quantos" />
          </div>
          <div className="space-y-1.5">
            <Label>Mudança prevista</Label>
            <input type="date" value={f.previsao_mudanca}
              onChange={e => set("previsao_mudanca", e.target.value)} className={campoClasse} />
          </div>
        </div>

        <div className="space-y-1.5">
          <Label>Sistemas de interesse</Label>
          <div className="flex flex-wrap gap-1.5">
            {/* A lista fixa mais o que a empresa acrescentou. Sistema novo
                aparece na conversa antes de virar item de menu, e o campo tem
                que caber a informação nova em vez de descartá-la. */}
            {[
              ...SISTEMAS.map(s => ({ id: s.id, label: s.label })),
              ...f.sistemas
                .filter(id => !SISTEMAS.some(s => s.id === id))
                .map(id => ({ id, label: id })),
            ].map(s => {
              const ativo = f.sistemas.includes(s.id)
              return (
                <button key={s.id} type="button"
                  onClick={() => set("sistemas", ativo ? f.sistemas.filter(x => x !== s.id) : [...f.sistemas, s.id])}
                  className={`rounded-full border px-3 py-1.5 text-[12px] font-medium transition-colors ${
                    ativo
                      ? "border-transparent bg-ios-blue/15 text-ios-blue"
                      : "border-hairline text-muted-fg hover:text-foreground"
                  }`}>
                  {s.label}
                </button>
              )
            })}

            {novoSistema === null ? (
              <button type="button" onClick={() => setNovoSistema("")}
                className="rounded-full border border-dashed border-hairline px-3 py-1.5 text-[12px] text-muted-fg hover:text-foreground">
                + outro
              </button>
            ) : (
              <input autoFocus value={novoSistema}
                onChange={e => setNovoSistema(e.target.value)}
                onBlur={() => {
                  const v = novoSistema.trim()
                  if (v && !f.sistemas.includes(v)) set("sistemas", [...f.sistemas, v])
                  setNovoSistema(null)
                }}
                onKeyDown={e => {
                  if (e.key === "Enter") e.currentTarget.blur()
                  if (e.key === "Escape") setNovoSistema(null)
                }}
                placeholder="Ex: Aspiração central"
                className="w-40 rounded-full border border-ios-blue bg-transparent px-3 py-1.5 text-[12px] text-foreground outline-none" />
            )}
          </div>
          {/* Quase nunca é um só, e o que ficou de fora é a próxima venda. */}
          <p className="px-1 text-[11px] text-muted-fg">
            O que ficou de fora hoje é a conversa do ano que vem.
          </p>
        </div>

        <div className="space-y-1.5">
          <Label className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" /> Endereço da obra</Label>
          <Input value={f.endereco_obra} onChange={e => set("endereco_obra", e.target.value)}
            placeholder="Onde é o projeto, não é o endereço de faturamento" />
        </div>
      </Secao>

      {/* ── O que ficou guardado ───────────────────────────────────────────── */}
      <SistemasGuardados leadId={leadId} />

      {/* ── Negociação ─────────────────────────────────────────────────────── */}
      <Secao titulo="A negociação">
        <div className="grid gap-2.5 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label className="flex items-center gap-1.5"><Wallet className="h-3.5 w-3.5" /> Orçamento que ele declarou</Label>
            <Input type="number" min="0" value={f.orcamento_declarado}
              onChange={e => set("orcamento_declarado", e.target.value)} placeholder="R$" />
            {/* Guardar os dois é o que revela depois que a empresa vinha
                propondo o dobro do que o cliente tinha em mente. */}
            <p className="px-1 text-[11px] text-muted-fg">O que ELE disse, não o que estimamos.</p>
          </div>
          <div className="space-y-1.5">
            <Label className="flex items-center gap-1.5"><UserCheck className="h-3.5 w-3.5" /> Quem decide</Label>
            <Input value={f.decisor} onChange={e => set("decisor", e.target.value)}
              placeholder="A esposa, o arquiteto, o sócio..." />
          </div>
        </div>
        <div className="space-y-1.5">
          <Label className="flex items-center gap-1.5"><Swords className="h-3.5 w-3.5" /> Com quem mais está falando</Label>
          <Input value={f.concorrentes} onChange={e => set("concorrentes", e.target.value)}
            placeholder="Concorrentes consultados, o que ofereceram" />
        </div>
      </Secao>

      {/* Salvar fica junto do conteúdo e aparece quando há o que salvar: botão
          permanente e sempre ativo não diz se o que está na tela já está no
          banco, que é a dúvida de quem digitou e saiu. */}
      <div className="sticky bottom-0 -mx-1 flex items-center gap-2 bg-surface-1/90 px-1 py-2 backdrop-blur">
        <Button size="sm" onClick={salvar} disabled={salvando || !sujo}>
          <Save className="mr-1 h-3.5 w-3.5" />
          {salvando ? "Salvando..." : sujo ? "Salvar ficha" : "Ficha salva"}
        </Button>
        {sujo && <span className="text-[11px] text-ios-orange">Há mudanças não salvas.</span>}
      </div>

      {/* ── Pessoas ────────────────────────────────────────────────────────── */}
      <Secao titulo="Pessoas do projeto">
        {contatos.length === 0 && !novo && (
          <p className="px-1 text-[12px] text-muted-fg">
            Ninguém além do contato principal. Arquiteto, cônjuge e mestre de obra entram aqui —
            é o que evita ligar para a pessoa errada meses depois.
          </p>
        )}

        <div className="space-y-1.5">
          {contatos.map(c => (
            <div key={c.id} className="group flex items-start gap-2.5 rounded-[16px] border border-hairline bg-surface-2/30 px-3 py-2.5">
              <button onClick={() => marcarPrincipal(c)}
                title={c.principal ? "É o contato principal" : "Tornar principal"}
                className={`mt-0.5 flex-shrink-0 rounded-lg p-1 transition-colors ${
                  c.principal ? "text-ios-yellow" : "text-muted-foreground/30 hover:text-muted-fg"
                }`}>
                <Star className={`h-3.5 w-3.5 ${c.principal ? "fill-current" : ""}`} />
              </button>

              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                  <span className="text-[14px] font-medium text-foreground">{c.nome}</span>
                  <span className="rounded-full bg-surface-2 px-1.5 py-0.5 text-[10px] uppercase tracking-wide text-muted-fg">
                    {rotulo(PAPEIS_CONTATO, c.papel)}
                  </span>
                </div>
                <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[12px] text-muted-fg">
                  {c.telefone && (
                    <a href={`https://wa.me/55${c.telefone.replace(/\D/g, "")}`} target="_blank" rel="noreferrer"
                      className="flex items-center gap-1 hover:text-ios-blue">
                      <Phone className="h-3 w-3" />{formatarTelefone(c.telefone)}
                    </a>
                  )}
                  {c.email && (
                    <a href={`mailto:${c.email}`} className="flex min-w-0 items-center gap-1 hover:text-ios-blue">
                      <Mail className="h-3 w-3 flex-shrink-0" /><span className="truncate">{c.email}</span>
                    </a>
                  )}
                </div>
                {c.observacao && (
                  <p className="mt-1 text-[12px] italic text-muted-foreground/70">{c.observacao}</p>
                )}
              </div>

              <button onClick={() => removerContato(c)}
                className="flex-shrink-0 rounded-lg p-1.5 text-muted-foreground/40 opacity-0 transition-opacity hover:text-ios-red group-hover:opacity-100">
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>

        {novo ? (
          <div className="space-y-2 rounded-[16px] border border-border bg-background/40 p-3">
            <div className="grid gap-2 sm:grid-cols-2">
              <Input autoFocus value={novo.nome} placeholder="Nome"
                onChange={e => setNovo(n => n && { ...n, nome: e.target.value })} />
              <select value={novo.papel} className={campoClasse}
                onChange={e => setNovo(n => n && { ...n, papel: e.target.value })}>
                {PAPEIS_CONTATO.map(p => <option key={p.id} value={p.id}>{p.label}</option>)}
              </select>
              <CampoMascarado mascara="telefone" value={novo.telefone} placeholder="Telefone"
                onValorChange={v => setNovo(n => n && { ...n, telefone: v })} />
              <Input value={novo.email} placeholder="E-mail"
                onChange={e => setNovo(n => n && { ...n, email: e.target.value })} />
            </div>
            <Input value={novo.observacao} placeholder="Só atende depois das 18h, é quem decide sobre som..."
              onChange={e => setNovo(n => n && { ...n, observacao: e.target.value })} />
            <label className="flex cursor-pointer items-center gap-2 px-1">
              <input type="checkbox" checked={novo.principal} className="h-4 w-4 accent-primary"
                onChange={e => setNovo(n => n && { ...n, principal: e.target.checked })} />
              <span className="text-[12px] text-muted-fg">É com essa pessoa que se fala por padrão</span>
            </label>
            <div className="flex gap-2">
              <Button size="sm" onClick={criarContato} disabled={salvandoContato || !novo.nome.trim()}>
                {salvandoContato ? "Salvando..." : "Adicionar"}
              </Button>
              <Button size="sm" variant="secondary" onClick={() => setNovo(null)}>Cancelar</Button>
            </div>
          </div>
        ) : (
          <Button size="sm" variant="secondary" onClick={() => setNovo({ ...CONTATO_VAZIO })}>
            <Plus className="mr-1 h-3.5 w-3.5" /> <Users className="mr-1 h-3.5 w-3.5" /> Adicionar pessoa
          </Button>
        )}
      </Secao>
    </div>
  )
}

export default FichaLead
