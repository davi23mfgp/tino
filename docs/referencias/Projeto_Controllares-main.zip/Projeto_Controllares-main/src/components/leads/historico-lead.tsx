"use client"

import { useCallback, useEffect, useState } from "react"
import {
  History, Send, Pencil, Trash2, Check, X, Lock, ArrowRight, Sparkles, MessageSquare,
  Phone, MessageCircle, MapPin, Mail, Users, StickyNote,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { showToast } from "@/components/ui/toast"
import { rotuloEtapa } from "@/lib/etapas-lead"

/**
 * A linha do tempo do cliente — a mesma no menu de Leads e no de Propostas.
 *
 * É o que se lê antes de voltar a um cliente que sumiu há seis meses: o que ele
 * pediu, o que travou, quanto ele achou caro. Fora daqui essa memória vive na
 * cabeça de quem atendeu, e vai embora com a pessoa.
 *
 * ANOTAÇÃO NÃO SE APAGA, EMPILHA. Corrigir e excluir são do Admin, e a correção
 * fica marcada na própria linha — registro que qualquer um reescreve não serve
 * para conferir nada. Erro de digitação se resolve escrevendo de novo.
 */

/* Por onde o contato aconteceu.

   "Falei com ele" não diz se foi uma ligação de dez minutos ou uma mensagem
   que ele nunca respondeu — e é essa diferença que decide como retomar. São
   seis, e não uma lista aberta: canal digitado à mão vira "zap", "Whats" e
   "whatsapp" no dia em que alguém for contar. */
const CANAIS = [
  { id: "NOTA",     label: "Anotação", Icone: StickyNote,    cor: "text-muted-fg" },
  { id: "LIGACAO",  label: "Ligação",  Icone: Phone,         cor: "text-ios-green" },
  { id: "WHATSAPP", label: "WhatsApp", Icone: MessageCircle, cor: "text-ios-teal" },
  { id: "VISITA",   label: "Visita",   Icone: MapPin,        cor: "text-ios-purple" },
  { id: "EMAIL",    label: "E-mail",   Icone: Mail,          cor: "text-ios-blue" },
  { id: "REUNIAO",  label: "Reunião",  Icone: Users,         cor: "text-ios-orange" },
] as const

interface Linha {
  id: string
  etapa: string
  tipo: "NOTA" | "ETAPA" | "SISTEMA" | string
  canal: string | null
  de: string | null
  para: string | null
  texto: string
  autor: string
  editadoPor: string | null
  editadoEm: string | null
  createdAt: string
  origem: "lead" | "atual"
}

/** "Hoje", "Ontem" ou a data por extenso — o cabeçalho de cada bloco do dia. */
function rotuloDia(iso: string) {
  const d = new Date(iso)
  const hoje = new Date()
  const ontem = new Date(); ontem.setDate(hoje.getDate() - 1)
  const mesmoDia = (a: Date, b: Date) => a.toDateString() === b.toDateString()
  if (mesmoDia(d, hoje)) return "Hoje"
  if (mesmoDia(d, ontem)) return "Ontem"
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" })
}

const hora = (iso: string) =>
  new Date(iso).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })

/** Iniciais para o avatar — dois caracteres, sem preposição no meio. */
function iniciais(nome: string) {
  const partes = nome.trim().split(/\s+/).filter(p => p.length > 2)
  if (partes.length === 0) return nome.slice(0, 2).toUpperCase()
  return ((partes[0]?.[0] ?? "") + (partes.length > 1 ? partes[partes.length - 1][0] : "")).toUpperCase()
}

/* Cor por etapa, igual à do quadro. O mesmo roxo do "Qualificado" na coluna
   aparece no ponto da linha do tempo — quem lê não precisa reaprender o código
   de cores em cada tela. */
const COR_ETAPA: Record<string, string> = {
  NOVO: "bg-ios-blue", CONTATADO: "bg-ios-teal", QUALIFICADO: "bg-ios-purple",
  ELABORANDO_PROPOSTA: "bg-ios-yellow", PROPOSTA_ENVIADA: "bg-ios-orange",
  GANHO: "bg-ios-green", PERDIDO: "bg-ios-red",
}

export function HistoricoLead({
  leadId, proposalId, podeEscrever = true, titulo = "Histórico",
}: {
  leadId?: string | null
  proposalId?: string | null
  podeEscrever?: boolean
  titulo?: string
}) {
  const [linhas, setLinhas] = useState<Linha[]>([])
  const [podeGerenciar, setPodeGerenciar] = useState(false)
  const [carregando, setCarregando] = useState(true)
  const [texto, setTexto] = useState("")
  const [canal, setCanal] = useState<string>("NOTA")
  const [enviando, setEnviando] = useState(false)
  const [editando, setEditando] = useState<{ id: string; texto: string } | null>(null)
  const [excluindo, setExcluindo] = useState<string | null>(null)

  const chave = leadId ? `leadId=${leadId}` : proposalId ? `proposalId=${proposalId}` : ""

  const carregar = useCallback(async () => {
    if (!chave) { setCarregando(false); return }
    try {
      const r = await fetch(`/api/notas?${chave}`, { cache: "no-store" })
      if (r.ok) {
        const j = await r.json()
        setLinhas(j.notas ?? [])
        setPodeGerenciar(!!j.podeGerenciar)
      }
    } finally { setCarregando(false) }
  }, [chave])

  useEffect(() => { setCarregando(true); carregar() }, [carregar])

  async function registrar() {
    const t = texto.trim()
    if (!t || enviando) return
    setEnviando(true)
    try {
      const r = await fetch("/api/notas", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          leadId: leadId ?? null, proposalId: leadId ? null : proposalId, texto: t, canal,
        }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { showToast(j.error || "Não deu para registrar.", { variant: "error" }); return }
      setTexto("")
      setCanal("NOTA")
      setLinhas(l => [j, ...l])
    } finally { setEnviando(false) }
  }

  async function salvarEdicao() {
    if (!editando) return
    const t = editando.texto.trim()
    if (!t) return
    const r = await fetch(`/api/notas/${editando.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ texto: t }),
    })
    const j = await r.json().catch(() => ({}))
    if (!r.ok) { showToast(j.error || "Não deu para corrigir.", { variant: "error" }); return }
    setEditando(null)
    carregar()
    showToast("Anotação corrigida, a versão anterior fica registrada.", { variant: "success" })
  }

  async function excluir(id: string) {
    const r = await fetch(`/api/notas/${id}`, { method: "DELETE" })
    const j = await r.json().catch(() => ({}))
    if (!r.ok) { showToast(j.error || "Não deu para excluir.", { variant: "error" }); return }
    setExcluindo(null)
    setLinhas(l => l.filter(x => x.id !== id))
  }

  /* Agrupado por dia: uma pilha corrida de trinta anotações não mostra ritmo —
     é o "três coisas na terça e nada por duas semanas" que conta a história. */
  const dias: { rotulo: string; itens: Linha[] }[] = []
  for (const l of linhas) {
    const r = rotuloDia(l.createdAt)
    const ultimo = dias[dias.length - 1]
    if (ultimo && ultimo.rotulo === r) ultimo.itens.push(l)
    else dias.push({ rotulo: r, itens: [l] })
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between gap-2">
        <h3 className="flex items-center gap-2 text-[15px] font-semibold text-foreground">
          <History className="h-4 w-4 text-ios-blue" /> {titulo}
        </h3>
        <span className="flex items-center gap-1 text-[11px] text-muted-fg">
          <Lock className="h-3 w-3" /> Não se apaga
        </span>
      </div>

      {/* Escrever. Fica no topo porque é o que se faz ao abrir: anotar o que
          acabou de acontecer na conversa. */}
      {podeEscrever && (
        <div className="rounded-[18px] border border-hairline bg-surface-2/40 p-2.5">
          <textarea
            value={texto}
            onChange={e => setTexto(e.target.value)}
            onKeyDown={e => { if ((e.metaKey || e.ctrlKey) && e.key === "Enter") registrar() }}
            rows={2}
            placeholder="O que aconteceu? Pedido, objeção, prazo, próximo passo…"
            className="w-full resize-none bg-transparent px-2 py-1.5 text-[14px] leading-relaxed text-foreground placeholder:text-muted-foreground focus:outline-none"
          />
          <div className="flex flex-wrap items-center gap-1.5 px-1 pb-1">
            {CANAIS.map(c => (
              <button key={c.id} type="button" onClick={() => setCanal(c.id)}
                className={`flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors ${
                  canal === c.id
                    ? "border-transparent bg-surface-1 text-foreground shadow-sm"
                    : "border-hairline text-muted-fg hover:text-foreground"
                }`}>
                <c.Icone className={`h-3 w-3 ${canal === c.id ? c.cor : ""}`} /> {c.label}
              </button>
            ))}
          </div>
          <div className="flex items-center justify-between gap-2 px-1 pt-1">
            <span className="text-[11px] text-muted-fg">
              Fica com a etapa e a data de agora. ⌘/Ctrl + Enter registra.
            </span>
            <Button size="sm" onClick={registrar} disabled={enviando || !texto.trim()}>
              <Send className="mr-1 h-3.5 w-3.5" />
              {enviando ? "Registrando..." : "Registrar"}
            </Button>
          </div>
        </div>
      )}

      {carregando ? (
        <div className="space-y-2">
          {[0, 1, 2].map(i => <div key={i} className="h-14 animate-pulse rounded-[18px] bg-white/[0.05]" />)}
        </div>
      ) : linhas.length === 0 ? (
        <div className="rounded-[18px] border border-dashed border-hairline px-4 py-8 text-center">
          <MessageSquare className="mx-auto mb-2 h-5 w-5 text-muted-foreground/40" />
          <p className="text-[13px] text-muted-fg">Nada registrado ainda.</p>
          <p className="mt-0.5 text-[11px] text-muted-foreground/60">
            O que for escrito aqui é o que vai estar disponível quando alguém voltar a esse cliente.
          </p>
        </div>
      ) : (
        <div className="max-h-[46vh] space-y-4 overflow-y-auto pr-1">
          {dias.map(dia => (
            <div key={dia.rotulo} className="space-y-1.5">
              <p className="sticky top-0 z-10 bg-surface-1/80 py-1 text-[11px] font-medium uppercase tracking-wide text-muted-foreground/70 backdrop-blur">
                {dia.rotulo}
              </p>

              <div className="relative space-y-1.5 pl-5">
                {/* O trilho. Uma linha só, atrás dos pontos: é ela que faz a
                    sequência parecer uma história e não uma lista. */}
                <span className="absolute bottom-2 left-[7px] top-2 w-px bg-hairline" aria-hidden />

                {dia.itens.map(l => {
                  const eMovimento = l.tipo === "ETAPA"
                  const eSistema = l.tipo === "SISTEMA"
                  const cor = COR_ETAPA[l.para ?? l.etapa] ?? "bg-muted-foreground/40"

                  return (
                    <div key={l.id} className="group relative">
                      <span className={`absolute -left-5 top-3 h-[7px] w-[7px] rounded-full ring-2 ring-background ${cor}`} aria-hidden />

                      <div className={`rounded-[16px] border border-hairline px-3 py-2.5 transition-colors ${
                        eMovimento || eSistema ? "bg-surface-2/30" : "bg-surface-1"
                      }`}>
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex min-w-0 flex-1 items-start gap-2">
                            {/* O canal ocupa o lugar do avatar quando existe:
                                bater o olho e ver que foram três WhatsApps sem
                                resposta vale mais do que ver as iniciais de
                                quem escreveu, que estão logo abaixo. */}
                            {!eMovimento && !eSistema && (() => {
                              const c = CANAIS.find(x => x.id === (l.canal ?? "NOTA")) ?? CANAIS[0]
                              return (
                                <span title={c.label}
                                  className="mt-0.5 flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-surface-2 text-[10px] font-semibold text-muted-fg">
                                  {l.canal && l.canal !== "NOTA"
                                    ? <c.Icone className={`h-3 w-3 ${c.cor}`} />
                                    : iniciais(l.autor)}
                                </span>
                              )
                            })()}
                            {eMovimento && <ArrowRight className="mt-1 h-3.5 w-3.5 flex-shrink-0 text-muted-fg" />}
                            {eSistema && <Sparkles className="mt-1 h-3.5 w-3.5 flex-shrink-0 text-muted-fg" />}

                            <div className="min-w-0 flex-1">
                              {editando?.id === l.id ? (
                                <div className="space-y-2">
                                  <textarea
                                    autoFocus rows={3} value={editando.texto}
                                    onChange={e => setEditando(v => v && { ...v, texto: e.target.value })}
                                    className="w-full resize-none rounded-[12px] border border-border bg-background/60 px-3 py-2 text-[14px] text-foreground focus:outline-none"
                                  />
                                  <div className="flex gap-2">
                                    <Button size="sm" onClick={salvarEdicao} disabled={!editando.texto.trim()}>
                                      <Check className="mr-1 h-3.5 w-3.5" /> Salvar correção
                                    </Button>
                                    <Button size="sm" variant="secondary" onClick={() => setEditando(null)}>
                                      <X className="mr-1 h-3.5 w-3.5" /> Cancelar
                                    </Button>
                                  </div>
                                </div>
                              ) : (
                                <p className={`whitespace-pre-wrap break-words text-[14px] leading-relaxed ${
                                  eMovimento || eSistema ? "text-muted-fg" : "text-foreground"
                                }`}>
                                  {l.texto}
                                </p>
                              )}

                              <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-muted-foreground/70">
                                <span>{hora(l.createdAt)}</span>
                                <span>·</span>
                                <span>{l.autor}</span>
                                {l.canal && l.canal !== "NOTA" && (
                                  <>
                                    <span>·</span>
                                    <span className="font-medium text-foreground/70">
                                      {CANAIS.find(x => x.id === l.canal)?.label ?? l.canal}
                                    </span>
                                  </>
                                )}
                                {!eMovimento && (
                                  <>
                                    <span>·</span>
                                    <span className="rounded-full bg-surface-2 px-1.5 py-0.5">{rotuloEtapa(l.etapa)}</span>
                                  </>
                                )}
                                {/* Veio do lead e está sendo lida na proposta:
                                    quem abre a proposta precisa saber que aquilo
                                    foi dito antes, na conversa. */}
                                {l.origem === "lead" && (
                                  <span className="rounded-full bg-ios-blue/10 px-1.5 py-0.5 text-ios-blue">do lead</span>
                                )}
                                {l.editadoEm && (
                                  <span className="rounded-full bg-ios-orange/10 px-1.5 py-0.5 text-ios-orange">
                                    corrigida por {l.editadoPor} em {new Date(l.editadoEm).toLocaleDateString("pt-BR")}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Corrigir e excluir só aparecem para o Admin, e a
                              API recusa de novo, para quem tentar por fora. */}
                          {podeGerenciar && editando?.id !== l.id && (
                            <div className="flex flex-shrink-0 items-center gap-0.5 opacity-0 transition-opacity group-hover:opacity-100 focus-within:opacity-100">
                              {l.tipo === "NOTA" && (
                                <button onClick={() => setEditando({ id: l.id, texto: l.texto })}
                                  title="Corrigir (fica registrado)"
                                  className="rounded-lg p-1.5 text-muted-foreground/60 hover:text-foreground">
                                  <Pencil className="h-3.5 w-3.5" />
                                </button>
                              )}
                              <button onClick={() => setExcluindo(l.id)} title="Excluir"
                                className="rounded-lg p-1.5 text-muted-foreground/60 hover:text-ios-red">
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          )}
                        </div>

                        {/* Confirmação no lugar da linha, sem abrir outra janela
                            por cima do histórico que se está lendo. */}
                        {excluindo === l.id && (
                          <div className="mt-2 flex flex-wrap items-center gap-2 rounded-[12px] bg-ios-red/[0.07] px-3 py-2">
                            <span className="text-[12px] text-foreground">Excluir esta linha do histórico?</span>
                            <div className="ml-auto flex gap-2">
                              <Button size="sm" variant="secondary" onClick={() => setExcluindo(null)}>Cancelar</Button>
                              <Button size="sm" variant="destructive" onClick={() => excluir(l.id)}>Excluir</Button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default HistoricoLead
