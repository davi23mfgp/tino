"use client"

import { useCallback, useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Mic, X, RefreshCw, AlertCircle, FileText, ChevronRight, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useConfirmar } from "@/components/confirmar"

/**
 * Gaveta das reuniões gravadas, aberta pelo botão em Propostas.
 *
 * Não existe tela própria no menu: a reunião não é algo que se gerencia, é o
 * meio pelo qual a proposta aparece. Mas precisa haver **um** lugar para olhar,
 * senão uma gravação que chegou e não produziu item nenhum simplesmente
 * desaparece — e o vendedor só descobre dias depois, procurando uma proposta
 * que nunca existiu.
 */

interface Pendencia { trecho: string; minuto: string; motivo: string }

interface Reuniao {
  id: string
  titulo: string | null
  gravada_em: string | null
  duracao_seg: number | null
  status: "RECEBIDA" | "PROCESSADA" | "SEM_ITENS" | "FALHOU"
  erro: string | null
  pendencias: Pendencia[] | null
  createdAt: string
  transcricao_apagada_em: string | null
  proposal: {
    id: string; numero: string; status: string
    _count: { items: number; environments: number }
  } | null
}

const duracao = (s: number | null) =>
  !s ? "" : s >= 60 ? `${Math.round(s / 60)} min` : `${s}s`

const quando = (r: Reuniao) => {
  const d = new Date(r.gravada_em ?? r.createdAt)
  const hoje = new Date()
  const mesmoDia = d.toDateString() === hoje.toDateString()
  return mesmoDia
    ? `hoje, ${d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}`
    : d.toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })
}

export function GavetaReunioes({
  aberta, aoFechar, aoMudar,
}: { aberta: boolean; aoFechar: () => void; aoMudar?: () => void }) {
  const router = useRouter()
  const confirmar = useConfirmar()
  const [reunioes, setReunioes] = useState<Reuniao[] | null>(null)
  const [processando, setProcessando] = useState<string | null>(null)
  const [apagando, setApagando] = useState<string | null>(null)
  const [buscando, setBuscando] = useState(false)
  const [erro, setErro] = useState("")
  const [expandida, setExpandida] = useState<string | null>(null)

  const carregar = useCallback(async () => {
    try {
      const r = await fetch("/api/reunioes", { cache: "no-store" })
      if (!r.ok) { setErro("Não foi possível carregar."); return }
      setReunioes((await r.json()).reunioes ?? [])
    } catch { setErro("Falha de conexão.") }
  }, [])

  useEffect(() => { if (aberta) carregar() }, [aberta, carregar])

  async function buscarAgora() {
    setBuscando(true); setErro("")
    try {
      const r = await fetch("/api/integracoes/plaud/sync", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ forcar: true }),
      })
      const j = await r.json()
      if (j.erro) setErro(j.erro)
      await carregar()
      aoMudar?.()
    } catch { setErro("Falha ao buscar.") }
    finally { setBuscando(false) }
  }

  async function processar(id: string) {
    setProcessando(id); setErro("")
    try {
      const r = await fetch(`/api/reunioes/${id}/processar`, { method: "POST" })
      const j = await r.json()
      if (!r.ok) { setErro(j.error ?? "Falha ao processar."); return }
      if (j.status === "SEM_ITENS") {
        setErro("Nenhum item reconhecido nesta conversa. Veja o que ficou pendente.")
      }
      await carregar()
      aoMudar?.()
    } catch { setErro("Falha de conexão.") }
    finally { setProcessando(null) }
  }

  /**
   * Apaga o que ficou guardado aqui desta gravação.
   *
   * Quando a reunião já virou proposta, some só o texto: o registro é o que
   * explica de onde aquela proposta veio, e a proposta em si não muda — os
   * itens dela são cópia, não referência. Quando não virou nada, some tudo.
   */
  async function apagar(r: Reuniao) {
    const virouProposta = !!r.proposal
    const aviso = virouProposta
      ? "Apagar a transcrição desta reunião? O texto da conversa some e não volta."
        + "\n\nA proposta gerada continua igual, e o registro da reunião fica no histórico."
      : "Apagar esta reunião? O texto e o registro somem e não voltam."
    if (!await confirmar({ titulo: `${aviso}\n\nNo Plaud a gravação continua — apagar lá é pelo aplicativo.`, perigo: true })) return

    setApagando(r.id); setErro("")
    try {
      const resp = await fetch(`/api/reunioes/${r.id}${virouProposta ? "" : "?tudo=1"}`,
        { method: "DELETE" })
      const j = await resp.json().catch(() => ({}))
      if (!resp.ok) { setErro(j.error ?? "Não foi possível apagar."); return }
      await carregar()
      aoMudar?.()
    } catch { setErro("Falha de conexão.") }
    finally { setApagando(null) }
  }

  if (!aberta) return null

  return (
    <>
      <div className="fixed inset-0 z-40 bg-black/40" onClick={aoFechar} />
      <aside className="fixed right-0 top-0 z-50 flex h-full w-full max-w-md flex-col border-l border-border bg-background shadow-2xl">
        <header className="flex items-center justify-between border-b border-border px-5 py-4">
          <h2 className="flex items-center gap-2 text-[15px] font-medium text-foreground">
            <Mic className="h-4 w-4 text-ios-blue" /> Reuniões
          </h2>
          <div className="flex items-center gap-1.5">
            <Button variant="outline" size="sm" className="h-8 text-xs"
              disabled={buscando} onClick={buscarAgora}>
              {buscando ? "Buscando..." : "Buscar"}
            </Button>
            <button onClick={aoFechar} className="rounded-lg p-1.5 text-muted-foreground hover:text-foreground">
              <X className="h-4 w-4" />
            </button>
          </div>
        </header>

        {erro && <p className="border-b border-border px-5 py-2.5 text-[12px] text-ios-red">{erro}</p>}

        <div className="flex-1 overflow-y-auto p-4">
          {!reunioes ? (
            <p className="py-10 text-center text-[13px] text-muted-foreground">Carregando...</p>
          ) : !reunioes.length ? (
            <div className="py-12 text-center">
              <Mic className="mx-auto mb-3 h-8 w-8 text-muted-foreground/40" strokeWidth={1.5} />
              <p className="text-[13px] text-muted-foreground">Nenhuma reunião ainda.</p>
              <p className="mx-auto mt-1.5 max-w-[15rem] text-[12px] leading-relaxed text-muted-foreground/70">
                Grave pelo Plaud e encerre. A transcrição leva alguns minutos para ficar pronta.
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {reunioes.map(r => (
                <div key={r.id} className="rounded-xl border border-border bg-surface-1 p-3.5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-[13px] font-medium text-foreground">{quando(r)}</p>
                      <p className="text-[12px] text-muted-foreground">
                        {[r.titulo, duracao(r.duracao_seg)].filter(Boolean).join(" · ")}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-1.5">
                      {r.status === "SEM_ITENS" && (
                        <AlertCircle className="h-4 w-4 text-ios-orange" />
                      )}
                      {/* Discreto: apagar é exceção, não o que se faz aqui todo
                          dia. Some quando o texto já foi apagado — não há mais
                          o que apagar, e um botão morto convida a clicar. */}
                      {!r.transcricao_apagada_em && (
                        <button
                          onClick={() => apagar(r)} disabled={apagando === r.id}
                          title={r.proposal ? "Apagar a transcrição" : "Apagar esta reunião"}
                          className="rounded-lg p-1 text-muted-foreground/60 hover:text-ios-red disabled:opacity-40">
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Dito, e não deduzido: transcrição apagada e reunião que
                      chegou sem texto ficariam iguais na tela. */}
                  {r.transcricao_apagada_em && (
                    <p className="mt-1.5 text-[11px] text-muted-foreground/70">
                      Transcrição apagada em{" "}
                      {new Date(r.transcricao_apagada_em).toLocaleDateString("pt-BR")}.
                    </p>
                  )}

                  {/* Virou proposta: o caminho para ela é o que interessa aqui. */}
                  {r.proposal ? (
                    <button
                      onClick={() => { router.push(`/propostas/${r.proposal!.id}`); aoFechar() }}
                      className="mt-2.5 flex w-full items-center justify-between rounded-lg bg-foreground/[0.04] px-3 py-2 text-left hover:bg-foreground/[0.07]">
                      <span className="flex items-center gap-2 text-[13px] text-foreground">
                        <FileText className="h-3.5 w-3.5 text-ios-blue" />
                        {r.proposal.numero}
                        <span className="text-[12px] text-muted-foreground">
                          {r.proposal._count.items} itens · {r.proposal._count.environments} ambientes
                        </span>
                      </span>
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    </button>
                  ) : r.status === "SEM_ITENS" ? (
                    <p className="mt-2 text-[12px] leading-relaxed text-ios-orange">
                      Nenhum item reconhecido. A conversa pode não ter escopo definido.
                    </p>
                  ) : r.status === "FALHOU" ? (
                    <p className="mt-2 text-[12px] text-ios-red">{r.erro ?? "Falha ao processar."}</p>
                  ) : r.transcricao_apagada_em ? (
                    /* Sem texto não há o que ler. O botão sumir explica melhor
                       que um erro depois do clique. */
                    <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground">
                      Sem a transcrição não dá para montar a proposta. A gravação
                      ainda está no Plaud, se precisar buscar de novo.
                    </p>
                  ) : (
                    <Button size="sm" className="mt-2.5 h-8 w-full text-xs"
                      disabled={processando === r.id} onClick={() => processar(r.id)}>
                      {processando === r.id
                        ? <><RefreshCw className="mr-1.5 h-3.5 w-3.5 animate-spin" /> Lendo a conversa...</>
                        : "Montar proposta"}
                    </Button>
                  )}

                  {/* O que foi pedido e não deu para especificar. É o que evita
                      a pessoa reouvir a gravação inteira atrás de um detalhe. */}
                  {!!r.pendencias?.length && (
                    <div className="mt-2.5">
                      <button
                        onClick={() => setExpandida(expandida === r.id ? null : r.id)}
                        className="text-[12px] text-ios-orange hover:underline">
                        Faltou definir ({r.pendencias.length})
                      </button>
                      {expandida === r.id && (
                        <div className="mt-2 space-y-1.5">
                          {r.pendencias.map((p, i) => (
                            <div key={i} className="rounded-lg bg-ios-orange/[0.08] px-2.5 py-2">
                              <p className="text-[12px] leading-snug text-foreground/85">
                                <span className="text-muted-foreground">[{p.minuto}]</span> “{p.trecho}”
                              </p>
                              <p className="mt-0.5 text-[11px] text-ios-orange">{p.motivo}</p>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </aside>
    </>
  )
}
