"use client"

import { useEffect, useState } from "react"
import { RefreshCw } from "lucide-react"

export function UpdatePrompt() {
  const [show, setShow] = useState(false)
  const [worker, setWorker] = useState<ServiceWorker | null>(null)

  useEffect(() => {
    if (!("serviceWorker" in navigator)) return

    const handleUpdate = (reg: ServiceWorkerRegistration) => {
      if (!reg.waiting) return
      setWorker(reg.waiting)
      setShow(true)
    }

    navigator.serviceWorker.getRegistration().then(reg => {
      if (!reg) return
      if (reg.waiting) { setWorker(reg.waiting); setShow(true) }
      reg.addEventListener("updatefound", () => {
        const sw = reg.installing
        if (!sw) return
        sw.addEventListener("statechange", () => {
          if (sw.state === "installed" && navigator.serviceWorker.controller) {
            handleUpdate(reg)
          }
        })
      })
    })

    // Detecta troca de SW ativo e recarrega automaticamente
    let refreshing = false
    navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (!refreshing) { refreshing = true; window.location.reload() }
    })
  }, [])

  const reload = () => {
    if (worker) worker.postMessage("SKIP_WAITING")
  }

  if (!show) return null

  return (
    <div className="fixed bottom-20 md:bottom-6 inset-x-4 md:inset-x-auto md:right-6 md:left-auto z-[300] max-w-sm">
      <div className="bg-card border border-border rounded-2xl shadow-[0_8px_32px_rgba(0,0,0,0.2)] p-4 flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
          <RefreshCw className="w-4 h-4 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[13px] font-semibold text-foreground leading-tight">
            Atualização disponível
          </p>
          <p className="text-[12px] text-muted-foreground mt-0.5">
            Nova versão do app pronta
          </p>
        </div>
        <button
          onClick={reload}
          className="flex-shrink-0 h-8 px-3 rounded-lg bg-primary text-primary-foreground text-[13px] font-semibold active:opacity-80 transition-opacity"
        >
          Recarregar
        </button>
      </div>
    </div>
  )
}
