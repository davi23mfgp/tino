"use client"

import type { ElementType, ReactNode } from "react"

/**
 * Bloco de conteúdo com título: um cartão de vidro com cabeçalho discreto.
 *
 * As listas vinham soltas na página, sem nada dizendo onde uma termina e a
 * outra começa. Dentro de um bloco nomeado, "Desempenho" e "Meus chamados"
 * param de se misturar quando a tela rola.
 */
export function Bloco({ titulo, acao, children }: {
  titulo: string
  acao?: ReactNode
  children: ReactNode
}) {
  return (
    <section className="ios-card p-4 sm:p-5">
      <div className="mb-3 flex items-center justify-between gap-3">
        <h2 className="text-[15px] font-semibold text-foreground">{titulo}</h2>
        {acao}
      </div>
      {children}
    </section>
  )
}

/**
 * Linha de lista com barra de progresso: nome, contexto, número à direita,
 * etiqueta de estado e o quanto já andou.
 *
 * O mesmo desenho serve para campanha e obra porque a pergunta é a mesma —
 * "quanto disso já passou?". A barra responde antes de ler o texto.
 */
export function LinhaProgresso({
  titulo, contexto, destaque, etiqueta, progresso, onClick, acoes,
}: {
  titulo: string
  contexto?: string
  /** Número da direita: leads, percentual, valor. */
  destaque?: string
  etiqueta?: string
  /** 0 a 100. Ausente esconde a barra — nem toda linha tem duração. */
  progresso?: number
  onClick?: () => void
  acoes?: ReactNode
}) {
  const barra = progresso != null ? Math.max(0, Math.min(100, progresso)) : null
  const Cerca = onClick ? "button" : "div"
  return (
    <Cerca
      {...(onClick ? { onClick, type: "button" as const } : {})}
      className={`group w-full rounded-2xl bg-foreground/[0.03] p-3.5 text-left transition-colors ${
        onClick ? "hover:bg-foreground/[0.06]" : ""
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <p className="truncate text-[15px] font-medium text-foreground">{titulo}</p>
          {contexto && <p className="mt-0.5 truncate text-[12px] text-muted-foreground">{contexto}</p>}
        </div>
        <div className="flex shrink-0 flex-col items-end gap-1.5">
          {destaque && <span className="text-[13px] font-semibold tabular-nums text-foreground">{destaque}</span>}
          {etiqueta && (
            <span className="rounded-full bg-foreground/[0.08] px-2.5 py-0.5 text-[11px] font-medium text-muted-foreground">
              {etiqueta}
            </span>
          )}
          {acoes && (
            <div className="flex items-center gap-1 opacity-60 transition-opacity group-hover:opacity-100">
              {acoes}
            </div>
          )}
        </div>
      </div>
      {barra != null && (
        <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-foreground/[0.10]">
          <div className="h-full rounded-full bg-foreground transition-[width] duration-500"
            style={{ width: `${barra}%` }} />
        </div>
      )}
    </Cerca>
  )
}

/**
 * Cartão de grade: ícone em badge, número no canto, nome e uma linha de apoio.
 * Serve kit, parceiro e canal de atendimento — o formato é o mesmo, muda o que
 * está escrito.
 */
export function CartaoGrade({
  icone: Icone, canto, titulo, contexto, onClick, acoes,
}: {
  icone: ElementType
  /** Canto superior direito: preço, valor acumulado, estado. */
  canto?: ReactNode
  titulo: string
  contexto?: string
  onClick?: () => void
  acoes?: ReactNode
}) {
  const Cerca = onClick ? "button" : "div"
  return (
    <Cerca
      {...(onClick ? { onClick, type: "button" as const } : {})}
      className={`ios-card group flex w-full flex-col gap-3 p-4 text-left sm:p-5 ${
        onClick ? "ios-tap" : ""
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="grid size-11 shrink-0 place-items-center rounded-full bg-foreground/[0.08] ring-1 ring-inset ring-border">
          <Icone className="size-[18px] text-foreground" strokeWidth={1.8} />
        </div>
        {canto && <span className="text-[15px] font-semibold tabular-nums text-foreground">{canto}</span>}
      </div>
      <div className="min-w-0">
        <p className="truncate text-[15px] font-semibold text-foreground">{titulo}</p>
        {contexto && <p className="mt-0.5 truncate text-[12px] text-muted-foreground">{contexto}</p>}
      </div>
      {acoes && <div className="flex items-center gap-1 border-t border-border pt-3">{acoes}</div>}
    </Cerca>
  )
}
