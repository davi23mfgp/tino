"use client"

import { cn } from "@/lib/utils"

interface SegmentedProps<T extends string> {
  options: readonly T[]
  value: T
  onChange: (v: T) => void
  labels?: Partial<Record<T, string>>
  className?: string
}

/**
 * SegmentedControl — padrão Control.Deal.
 * Container surface-3 rounded-xl p-1; ativo surface-1 rounded-lg shadow-sm.
 */
export function Segmented<T extends string>({ options, value, onChange, labels, className }: SegmentedProps<T>) {
  return (
    <div className={cn("grid rounded-xl bg-surface-3 p-1", className)}
      style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))` }}>
      {options.map(opt => (
        <button
          key={opt}
          type="button"
          onClick={() => onChange(opt)}
          className={cn(
            "py-1.5 rounded-lg text-[13px] font-medium transition-all duration-150",
            value === opt
              ? "bg-surface-1 text-foreground shadow-sm shadow-black/20"
              : "text-muted-fg",
          )}
        >
          {labels?.[opt] ?? opt}
        </button>
      ))}
    </div>
  )
}
