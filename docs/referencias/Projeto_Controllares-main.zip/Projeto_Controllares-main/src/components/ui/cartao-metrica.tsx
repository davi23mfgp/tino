import type { ElementType } from "react"
import Link from "next/link"
import { ArrowUpRight } from "lucide-react"

/**
 * Número em destaque no topo de uma tela: ícone em badge sólido, rótulo,
 * valor grande e uma linha de apoio.
 *
 * Vivia dentro do Dashboard. Saiu para cá quando a mesma faixa passou a abrir
 * outras telas — duas cópias divergem na primeira vez que alguém ajusta o
 * tamanho da fonte em uma delas.
 *
 * O valor aceita texto porque nem toda métrica é contagem: "R$ 18k",
 * "9,4%" e "Residencial" ocupam o mesmo lugar de um "6".
 */
export function CartaoMetrica({
  icone: Icone, rotulo, valor, nota, href,
}: {
  icone: ElementType
  rotulo: string
  valor: string | number
  /** Comparação, período, total — o que o número sozinho não conta. */
  nota?: string
  href?: string
}) {
  const conteudo = (
    <div className="ios-card ios-tap group relative overflow-hidden p-3 sm:p-3.5">
      {/* Halo desfocado no canto: é o que dá profundidade ao vidro. */}
      <div className="pointer-events-none absolute -right-8 -top-10 size-24 rounded-full bg-foreground/[0.06] blur-2xl" />
      <div className="flex items-start justify-between gap-2">
        <div className="grid size-8 shrink-0 place-items-center rounded-xl bg-foreground sm:size-9">
          <Icone className="size-4 text-background" strokeWidth={2.2} />
        </div>
        {href && (
          <ArrowUpRight className="size-4 shrink-0 text-muted-foreground transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
        )}
      </div>
      <p className="mt-2.5 truncate text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground sm:mt-3">
        {rotulo}
      </p>
      <p className="mt-1 truncate text-[24px] font-semibold leading-none tracking-tight text-foreground sm:text-[28px]">
        {valor}
      </p>
      {/* Espaço reservado mesmo sem nota: sem isso os cartões da faixa ficam
          com alturas diferentes conforme quem tem comparação e quem não tem. */}
      <p className="mt-1.5 truncate text-[11px] text-muted-foreground">{nota ?? " "}</p>
    </div>
  )
  return href ? <Link href={href}>{conteudo}</Link> : conteudo
}

/** Faixa de métricas: duas colunas no celular, quatro no desktop. */
export function FaixaMetricas({ children }: { children: React.ReactNode }) {
  return <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">{children}</div>
}
