"use client"

import { Search } from "lucide-react"

/**
 * Busca à esquerda, filtros mutuamente exclusivos à direita, no mesmo cartão.
 *
 * Antes cada tela combinava campo de busca e filtro do seu jeito — uns em
 * dropdown, outros em abas, outros em chips soltos abaixo do título. Juntos na
 * mesma linha fica claro que os dois estreitam a MESMA lista: filtrar por
 * "Contrato" e digitar no campo se somam, não se substituem.
 */
export function BarraFiltros<T extends string>({
  busca, aoBuscar, placeholder = "Buscar...",
  opcoes, valor, aoTrocar,
}: {
  busca: string
  aoBuscar: (v: string) => void
  placeholder?: string
  /** Rótulo visível + valor. Contagem entra no rótulo quando ajuda a decidir. */
  opcoes: readonly { valor: T; rotulo: string }[]
  valor: T
  aoTrocar: (v: T) => void
}) {
  return (
    <div className="ios-card flex flex-col gap-3 p-2.5 sm:flex-row sm:items-center">
      <div className="relative min-w-0 flex-1">
        <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <input
          value={busca}
          onChange={e => aoBuscar(e.target.value)}
          placeholder={placeholder}
          className="h-10 w-full rounded-xl bg-foreground/[0.04] pl-10 pr-3 text-[14px] text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring/40"
        />
      </div>
      <div className="-mx-0.5 flex shrink-0 gap-1 overflow-x-auto px-0.5 no-scrollbar">
        {opcoes.map(o => (
          <button
            key={o.valor}
            type="button"
            onClick={() => aoTrocar(o.valor)}
            aria-pressed={valor === o.valor}
            className={`shrink-0 rounded-xl px-3.5 py-2 text-[13px] font-medium transition-colors ${
              valor === o.valor
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:bg-foreground/[0.06] hover:text-foreground"
            }`}
          >
            {o.rotulo}
          </button>
        ))}
      </div>
    </div>
  )
}
