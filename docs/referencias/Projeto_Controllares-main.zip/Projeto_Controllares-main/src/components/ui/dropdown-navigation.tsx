"use client"

import React, { useState } from "react"
import { motion, AnimatePresence } from "motion/react"
import { ChevronDown } from "lucide-react"

export type NavSubItem = {
  label: string
  description: string
  icon: React.ElementType
  onClick?: () => void
  href?: string
}

export type NavSubMenu = {
  title: string
  items: NavSubItem[]
}

export type NavItem = {
  id: number
  label: string
  subMenus?: NavSubMenu[]
  link?: string
  onClick?: () => void
  active?: boolean
}

type Props = {
  navItems: NavItem[]
  className?: string
}

export function DropdownNavigation({ navItems, className = "" }: Props) {
  const [openMenu, setOpenMenu] = useState<string | null>(null)
  const [isHover, setIsHover] = useState<number | null>(null)

  const handleHover = (menuLabel: string | null) => setOpenMenu(menuLabel)

  return (
    <div className={`relative ${className}`}>
      <ul className="relative flex items-center space-x-0">
        {navItems.map(navItem => (
          <li
            key={navItem.label}
            className="relative"
            onMouseEnter={() => handleHover(navItem.label)}
            onMouseLeave={() => handleHover(null)}
          >
            <button
              onClick={() => {
                if (navItem.onClick) navItem.onClick()
                else if (navItem.link) window.location.href = navItem.link
              }}
              className={`text-sm py-1.5 px-4 flex cursor-pointer group transition-colors duration-200 items-center justify-center gap-1 relative ${
                navItem.active
                  ? "text-foreground font-medium"
                  : "text-muted-foreground hover:text-foreground"
              }`}
              onMouseEnter={() => setIsHover(navItem.id)}
              onMouseLeave={() => setIsHover(null)}
            >
              <span>{navItem.label}</span>
              {navItem.subMenus && (
                <ChevronDown
                  className={`h-3.5 w-3.5 group-hover:rotate-180 duration-200 transition-transform ${
                    openMenu === navItem.label ? "rotate-180" : ""
                  }`}
                />
              )}
              {/* Active indicator */}
              {navItem.active && (
                <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-4/5 h-0.5 bg-primary rounded-full" />
              )}
              {/* Hover bg */}
              {(isHover === navItem.id || openMenu === navItem.label) && (
                <motion.div
                  layoutId="hover-bg"
                  className="absolute inset-0 size-full bg-primary/10"
                  style={{ borderRadius: 99 }}
                  transition={{ type: "spring", stiffness: 400, damping: 30 }}
                />
              )}
            </button>

            <AnimatePresence>
              {openMenu === navItem.label && navItem.subMenus && (
                <div className="w-auto absolute left-0 top-full pt-2 z-50">
                  <motion.div
                    className="bg-popover border border-border p-4 w-max shadow-apple-float"
                    style={{ borderRadius: 16 }}
                    layoutId="menu"
                    initial={{ opacity: 0, y: -8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
                  >
                    <div className="w-fit shrink-0 flex space-x-8 overflow-hidden">
                      {navItem.subMenus.map(sub => (
                        <motion.div layout className="w-full" key={sub.title}>
                          {sub.title && (
                            <h3 className="mb-3 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/60">
                              {sub.title}
                            </h3>
                          )}
                          <ul className="space-y-1">
                            {sub.items.map(item => {
                              const Icon = item.icon
                              const inner = (
                                <li key={item.label}>
                                  <button
                                    onClick={item.onClick}
                                    className="flex items-center space-x-3 group w-full text-left rounded-xl px-2 py-2 hover:bg-accent transition-colors"
                                  >
                                    <div className="border border-border text-foreground rounded-lg flex items-center justify-center size-8 shrink-0 group-hover:bg-background group-hover:text-foreground transition-colors">
                                      <Icon className="h-4 w-4 flex-none" />
                                    </div>
                                    <div className="leading-5 w-max">
                                      <p className="text-sm font-medium text-foreground shrink-0">
                                        {item.label}
                                      </p>
                                      {item.description && (
                                        <p className="text-xs text-muted-foreground shrink-0">
                                          {item.description}
                                        </p>
                                      )}
                                    </div>
                                  </button>
                                </li>
                              )
                              return inner
                            })}
                          </ul>
                        </motion.div>
                      ))}
                    </div>
                  </motion.div>
                </div>
              )}
            </AnimatePresence>
          </li>
        ))}
      </ul>
    </div>
  )
}
