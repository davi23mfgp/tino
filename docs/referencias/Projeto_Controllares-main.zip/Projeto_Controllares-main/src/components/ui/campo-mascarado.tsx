"use client"

import * as React from "react"
import { Input } from "@/components/ui/input"
import { MASCARAS, cursorDepois, soDigitos, type NomeMascara } from "@/lib/mascara"

export interface CampoMascaradoProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "value" | "onChange" | "type"> {
  /** Qual formato o campo usa: "telefone", "moeda", "mm", "porcentagem"... */
  mascara: NomeMascara
  /** O valor CRU: dígitos no telefone e no documento, número no dinheiro. */
  value: string | number | null | undefined
  /** Recebe o valor cru, nunca o texto com máscara. */
  onValorChange: (bruto: string) => void
  /**
   * "padrao" usa o <Input> do sistema. "proprio" renderiza um <input> nu, com
   * só a className que vier — para as telas que já tinham estilo próprio e não
   * devem mudar de aparência só porque ganharam máscara.
   */
  estilo?: "padrao" | "proprio"
}

/**
 * Campo que se formata sozinho enquanto a pessoa digita.
 *
 *   <CampoMascarado mascara="telefone" value={form.telefone}
 *     onValorChange={v => setForm(f => ({ ...f, telefone: v }))} />
 *
 * O componente é controlado pelo valor CRU. Quem chama guarda "17988211987" e
 * a tela mostra "(17) 98821-1987" — o formulário nunca precisa desformatar
 * nada antes de salvar, que é onde esse tipo de campo costuma vazar bug.
 *
 * O cursor é reposicionado à mão depois que o React repinta. Sem isso, digitar
 * no meio de um telefone já preenchido joga o cursor para o fim a cada tecla, e
 * a pessoa acaba com o número embaralhado sem entender por quê.
 */
export const CampoMascarado = React.forwardRef<HTMLInputElement, CampoMascaradoProps>(
  ({ mascara, value, onValorChange, inputMode, estilo = "padrao", onBlur, ...props }, refExterna) => {
    const m = MASCARAS[mascara]
    const refInterna = React.useRef<HTMLInputElement | null>(null)
    /* Onde o cursor deve parar depois do próximo repaint. null = não mexer,
       que é o caso quando o valor mudou por fora (carregou do banco). */
    const alvoCursor = React.useRef<number | null>(null)

    const juntarRef = React.useCallback((no: HTMLInputElement | null) => {
      refInterna.current = no
      if (typeof refExterna === "function") refExterna(no)
      else if (refExterna) (refExterna as React.MutableRefObject<HTMLInputElement | null>).current = no
    }, [refExterna])

    /* Enquanto a pessoa digita, o texto na tela pode não ser o mesmo que
       exibir(bruto) devolveria. O caso claro é a vírgula: em "12," o bruto
       ainda é 12, e exibir(12) devolve "12 mm" — a vírgula sumiria embaixo do
       dedo. O rascunho segura o texto digitado até o valor mudar por fora. */
    const [rascunho, setRascunho] = React.useState<string | null>(null)
    const texto = rascunho ?? m.exibir(value)

    React.useEffect(() => {
      // Valor trocado por fora (carregou do banco, formulário limpou): o
      // rascunho está velho e precisa sair da frente.
      if (rascunho !== null && m.aoDigitar(rascunho).bruto !== String(value ?? "")) {
        setRascunho(null)
      }
    }, [value, rascunho, m])

    React.useLayoutEffect(() => {
      const no = refInterna.current
      if (!no || alvoCursor.current === null) return
      const pos = alvoCursor.current
      alvoCursor.current = null
      no.setSelectionRange(pos, pos)
    })

    function aoMudar(e: React.ChangeEvent<HTMLInputElement>) {
      const digitado = e.target.value
      const posicao = e.target.selectionStart ?? digitado.length
      const { texto: novoTexto, bruto } = m.aoDigitar(digitado)

      alvoCursor.current = m.cursor === "fim"
        ? novoTexto.length
        : m.cursor === "manter"
          // Medida: o texto é o que foi digitado, sem enfeite. O cursor fica
          // onde a pessoa estava, inclusive logo depois da vírgula.
          ? Math.min(posicao, novoTexto.length)
          : cursorDepois(novoTexto, soDigitos(digitado.slice(0, posicao)).length)

      setRascunho(novoTexto)
      onValorChange(bruto)
    }

    function aoSair(e: React.FocusEvent<HTMLInputElement>) {
      // Saindo do campo o texto volta ao formato canônico: "12," vira "12 mm".
      setRascunho(null)
      onBlur?.(e)
    }

    const comuns = {
      ...props,
      ref: juntarRef,
      type: "text" as const,
      inputMode: inputMode ?? m.teclado,
      value: texto,
      onChange: aoMudar,
      onBlur: aoSair,
    }

    return estilo === "proprio" ? <input {...comuns} /> : <Input {...comuns} />
  }
)
CampoMascarado.displayName = "CampoMascarado"
