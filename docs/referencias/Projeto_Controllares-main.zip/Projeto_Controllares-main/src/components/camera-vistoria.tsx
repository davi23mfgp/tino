"use client"

import { useRef, useState, useCallback } from "react"
import { Camera, X, Check, RotateCcw, Upload, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Props {
  obraId: string
  ambienteNome?: string
  onSaved?: (url: string) => void
}

type Stage = "idle" | "preview" | "captured" | "uploading" | "done"

export function CameraVistoria({ obraId, ambienteNome, onSaved }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const streamRef = useRef<MediaStream | null>(null)

  const [stage, setStage] = useState<Stage>("idle")
  const [dataUrl, setDataUrl] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [savedUrl, setSavedUrl] = useState<string | null>(null)

  const startCamera = useCallback(async () => {
    setError(null)
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1920 }, height: { ideal: 1080 } },
        audio: false,
      })
      streamRef.current = stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        await videoRef.current.play()
      }
      setStage("preview")
    } catch {
      setError("Câmera não disponível. Verifique as permissões do navegador.")
    }
  }, [])

  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach(t => t.stop())
    streamRef.current = null
    setStage("idle")
    setDataUrl(null)
  }, [])

  const capture = useCallback(() => {
    const video = videoRef.current
    const canvas = canvasRef.current
    if (!video || !canvas) return
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    canvas.getContext("2d")?.drawImage(video, 0, 0)
    setDataUrl(canvas.toDataURL("image/jpeg", 0.85))
    streamRef.current?.getTracks().forEach(t => t.stop())
    setStage("captured")
  }, [])

  const retake = useCallback(async () => {
    setDataUrl(null)
    await startCamera()
  }, [startCamera])

  const upload = useCallback(async () => {
    if (!dataUrl) return
    setStage("uploading")
    try {
      // Converte dataUrl → Blob → FormData
      const res = await fetch(dataUrl)
      const blob = await res.blob()
      const form = new FormData()
      const timestamp = new Date().toISOString().replace(/[:.]/g, "-")
      form.append("file", blob, `vistoria-${obraId}-${timestamp}.jpg`)
      form.append("obraId", obraId)
      if (ambienteNome) form.append("ambiente", ambienteNome)

      const up = await fetch("/api/obras/vistoria-foto", { method: "POST", body: form })
      if (!up.ok) throw new Error("Falha no upload")
      const { url } = await up.json()
      setSavedUrl(url)
      setStage("done")
      onSaved?.(url)
    } catch {
      setError("Falha ao enviar a foto. Tente novamente.")
      setStage("captured")
    }
  }, [dataUrl, obraId, ambienteNome, onSaved])

  return (
    <div className="rounded-xl border border-slate-700 bg-slate-800/50 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-700">
        <div className="flex items-center gap-2 text-sm font-medium text-white">
          <Camera className="w-4 h-4 text-sky-400" />
          Foto de vistoria
          {ambienteNome && <span className="text-slate-400 font-normal">· {ambienteNome}</span>}
        </div>
        {stage !== "idle" && stage !== "done" && (
          <button onClick={stopCamera} className="text-slate-500 hover:text-white transition-colors">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Body */}
      <div className="p-4">
        {stage === "idle" && (
          <div className="flex flex-col items-center gap-3 py-4">
            {error && <p className="text-red-400 text-sm text-center">{error}</p>}
            <Button onClick={startCamera} className="bg-sky-600 hover:bg-sky-500 gap-2">
              <Camera className="w-4 h-4" /> Abrir câmera
            </Button>
            <p className="text-xs text-slate-500 text-center">
              Use a câmera traseira para registrar o estado do ambiente
            </p>
          </div>
        )}

        {(stage === "preview" || stage === "captured") && (
          <div className="space-y-3">
            {stage === "preview" && (
              <>
                <div className="relative rounded-lg overflow-hidden bg-black aspect-video">
                  <video ref={videoRef} autoPlay playsInline muted
                    className="w-full h-full object-cover" />
                  {/* Guia visual */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-3/4 h-3/4 border-2 border-white/30 rounded-lg" />
                  </div>
                </div>
                <Button onClick={capture} className="w-full bg-white text-slate-900 hover:bg-slate-100 gap-2 font-semibold">
                  <Camera className="w-5 h-5" /> Capturar foto
                </Button>
              </>
            )}

            {stage === "captured" && dataUrl && (
              <>
                <div className="rounded-lg overflow-hidden bg-black aspect-video">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={dataUrl} alt="Foto capturada" className="w-full h-full object-cover" />
                </div>
                {error && <p className="text-red-400 text-sm">{error}</p>}
                <div className="flex gap-2">
                  <Button variant="outline" onClick={retake} className="flex-1 border-slate-600 gap-2">
                    <RotateCcw className="w-4 h-4" /> Repetir
                  </Button>
                  <Button onClick={upload} className="flex-1 bg-green-600 hover:bg-green-500 gap-2">
                    <Upload className="w-4 h-4" /> Enviar
                  </Button>
                </div>
              </>
            )}
          </div>
        )}

        {stage === "uploading" && (
          <div className="flex flex-col items-center gap-2 py-6">
            <Loader2 className="w-8 h-8 animate-spin text-sky-400" />
            <p className="text-sm text-slate-400">Enviando foto…</p>
          </div>
        )}

        {stage === "done" && savedUrl && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-green-400 text-sm font-medium">
              <Check className="w-4 h-4" /> Foto salva com sucesso!
            </div>
            <div className="rounded-lg overflow-hidden aspect-video bg-black">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={savedUrl} alt="Vistoria" className="w-full h-full object-cover" />
            </div>
            <Button variant="outline" onClick={() => { setStage("idle"); setDataUrl(null); setSavedUrl(null) }}
              className="w-full border-slate-600 gap-2">
              <Camera className="w-4 h-4" /> Nova foto
            </Button>
          </div>
        )}
      </div>

      {/* Canvas oculto para captura */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  )
}
