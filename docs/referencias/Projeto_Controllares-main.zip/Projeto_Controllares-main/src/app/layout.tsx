import type { Metadata, Viewport } from "next"
import { Onest } from "next/font/google"
import "./globals.css"
import { ConfirmarProvider } from "@/components/confirmar"
import { ThemeProvider } from "@/components/theme-provider"
import { PwaRegister } from "@/components/pwa-register"
import { PwaInstallBanner } from "@/components/pwa-install-banner"
import { OfflineBanner } from "@/components/offline-banner"
import { UpdatePrompt } from "@/components/update-prompt"

const onest = Onest({
  subsets: ["latin"],
  variable: "--font-onest",
  display: "swap",
  // 300 entra para o rótulo fino do logotipo na tela de entrada.
  weight: ["300", "400", "500", "600", "700", "800"],
})

/* Base absoluta das URLs de metadados. Sem ela, canonical e Open Graph saem
   relativos, e o buscador trata cada caminho como página distinta — foi o que
   apareceu na auditoria como título e descrição duplicados. */
const BASE = process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL || "https://sistema.controllares.com.br"

export const metadata: Metadata = {
  metadataBase: new URL(BASE),
  title: {
    default: "Controllares",
    // Cada página completa o título em vez de repetir o mesmo em todas.
    template: "%s · Controllares",
  },
  description:
    "Sistema de gestão da Controllares: propostas, obras, catálogo, estoque e"
    + " financeiro para projetos de automação residencial e home cinema.",
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    siteName: "Controllares",
    locale: "pt_BR",
    url: BASE,
    title: "Controllares",
    description: "Propostas, obras, catálogo, estoque e financeiro em um só sistema.",
    images: [{ url: "/icons/icon-512.png", width: 512, height: 512, alt: "Controllares" }],
  },
  twitter: {
    card: "summary",
    title: "Controllares",
    description: "Propostas, obras, catálogo, estoque e financeiro em um só sistema.",
    images: ["/icons/icon-512.png"],
  },
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Controllares",
  },
  icons: {
    // Sem `icon` declarado o navegador procura /favicon.ico, não acha e mostra
    // o globo padrão. Apontar para o PNG que já existe resolve.
    icon: [
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    shortcut: [{ url: "/icons/icon-192.png" }],
    apple: [
      { url: "/icons/icon-192.png", sizes: "192x192" },
    ],
  },
}

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#fafafa" },
    { media: "(prefers-color-scheme: dark)",  color: "#000000" },
  ],
  width: "device-width",
  initialScale: 1,
  /* Sem `maximumScale` nem `userScalable: false`.
     Eles existiam para o app parecer nativo — o duplo toque não dá aquele zoom
     acidental. Mas travam o pinça-zoom, e quem precisa ampliar para ler fica
     sem saída; é barreira de acessibilidade, e a auditoria aponta as duas.
     O ganho estético não paga alguém não conseguir ler a tela. */
  viewportFit: "cover",
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <head>
        <link rel="apple-touch-icon" href="/icons/icon-192.png" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="Controllares" />
      </head>
      <body className={`${onest.variable} font-sans antialiased`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem={false}
          disableTransitionOnChange={false}
        >
          <OfflineBanner />
          {/* Confirmações e avisos do sistema, no lugar das caixas do navegador
              — que estampam o endereço do deploy e travam a aba inteira. */}
          <ConfirmarProvider>
            {children}
          </ConfirmarProvider>
          <UpdatePrompt />
          <PwaRegister />
          <PwaInstallBanner />
        </ThemeProvider>
      </body>
    </html>
  )
}
