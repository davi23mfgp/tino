"use client"

import { use, useEffect, useState } from "react"
import { DocumentoProposta } from "@/app/p/[token]/page"

/**
 * O documento da proposta pela porta de dentro, para imprimir ou salvar em PDF.
 *
 * Fica FORA do layout do sistema, como o link do cliente. A primeira versão
 * morava dentro do painel e escondia o menu na impressão por CSS; o navegador
 * não consegue paginar um bloco tirado do fluxo, então saía uma folha só, com
 * o documento cortado. Aqui não há menu para esconder, e a impressão é a mesma
 * do link público, que já funciona.
 *
 * Quem autentica é a sessão do sistema (a rota de dados recusa sem ela), e é
 * isso que permite imprimir sem o código que vai para o e-mail do cliente. A
 * área de decisão não aparece: aceitar continua sendo dele, no link dele.
 */
export default function DocumentoInternoPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const [token, setToken] = useState<string | null>(null)
  const [erro, setErro] = useState("")

  /* O token continua servindo para as imagens e os anexos, que saem pelas
     rotas do link. Quem abre aqui já está autenticado; o token é só o endereço
     do arquivo. */
  useEffect(() => {
    fetch(`/api/propostas/${id}`, { cache: "no-store" })
      .then(r => r.ok ? r.json() : null)
      .then(p => {
        if (p?.link_token) setToken(p.link_token)
        else setErro("Não consegui abrir este documento. Entre no sistema e tente de novo.")
      })
      .catch(() => setErro("Falha ao carregar o documento."))
  }, [id])

  if (erro) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-zinc-100 p-6">
        <p className="text-sm text-zinc-600">{erro}</p>
      </div>
    )
  }

  if (!token) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-zinc-100 p-6">
        <p className="text-sm text-zinc-500">Carregando documento...</p>
      </div>
    )
  }

  /* O documento ja traz o proprio botao de salvar em PDF, no fim da folha.
     Um segundo botao flutuante no canto so competia com ele. */
  return <DocumentoProposta token={token} fonte={`/api/propostas/${id}/documento`} interno />
}
