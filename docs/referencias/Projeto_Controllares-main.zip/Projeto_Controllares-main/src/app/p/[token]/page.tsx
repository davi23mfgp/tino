"use client"

import { useState, useEffect, useCallback, use, Fragment } from "react"
import { Package, Eye, CheckCircle2, XCircle, FileSearch, Printer, ShieldCheck, MessageSquareText, Mail, MapPin, Phone, Paperclip, Globe, Instagram, Check } from "lucide-react"
import { proxiedImg } from "@/lib/img"
import { sanitizeHtml } from "@/lib/sanitize"
import { type ServicoProposta } from "@/lib/servicos-proposta"
import { blocosDaProposta, blocosComEscolha, BLOCO_SERVICO, NOME_BLOCO_SERVICO } from "@/lib/blocos-proposta"
import { tituloCaso, nomeArquivoSeguro } from "@/lib/texto"
import { formatarTelefone } from "@/lib/documento"
import { brl, pct } from "@/lib/formato"

const fmtDate = (d: string) => new Date(d).toLocaleDateString("pt-BR")

interface Product { nome: string; sku: string; imagem_url?: string | null }
interface Category { id: string; nome: string; imagem_url?: string | null }
interface ProposalItem {
  id: string; quantidade: number; valor_unitario: number; valor_total: number
  product: Product | null; category: Category | null
  /* O nome como foi escrito na proposta. É o que aparece quando o item ainda
     não tem produto no catálogo — o escrito na visita — e também o que garante
     que a proposta enviada continue igual se o produto for renomeado depois. */
  nome_snapshot: string | null
}
interface Environment { id: string; nome: string; proposalItems: ProposalItem[] }
interface Installment { numero_parcela: number; valor: number; data_vencimento: string; status: string }
interface ExtraPage { titulo: string; conteudo_markdown: string; ordem: number; anexos?: { nome: string; url: string; ext: string }[] }
interface Proposal {
  id: string; numero: string; client_name: string; client_email: string | null; client_city?: string | null
  status: string; createdAt?: string
  valor_total: number; valor_servico: number; data_expiracao: string | null
  /* Cada serviço com o que ele cobre. Antes vinha só o total somado, e a tela
     tinha de adivinhar de quem era o quê. */
  servicos_detalhe?: ServicoProposta[] | null
  payment_methods?: string | null; anos_garantia?: number | null; dias_garantia?: number | null; desconto_aplicado?: number | null
  valor_entrada?: number | null
  formas_oferecidas?: string | null
  /* O que o cliente escolheu, quando já escolheu. Sem isto o documento caía no
     palpite de "à vista" para toda proposta sem parcelas geradas. */
  forma_pagamento?: string | null
  parcelas_forma?: number | null
  /* Quem fechou a condição. "CLIENTE" é o que permite devolver a escolha dele
     marcada quando a proposta volta revisada. */
  pagamento_definido_por?: string | null
  personalizado_recado?: string | null
  desconto_campanha?: number | null
  aplicar_desconto_campanha?: boolean
  exibir_valor_unitario?: boolean
  observacoes?: string | null
  /* O que o cliente escreveu ao pedir ajuste ou recusar. Sai no documento:
     quem imprime a proposta em revisão precisa ler o pedido junto dela. */
  mensagem_cliente?: string | null
  mensagem_cliente_em?: string | null
  environments: Environment[]; installments: Installment[]; extraPages: ExtraPage[]
  vendedor: { nome: string; email: string; telefone?: string | null }
  company: {
    nome_empresa: string; logo_url?: string | null; logo_proposta_url?: string | null; endereco_base?: string | null; cnpj_cpf?: string | null
    email_contato?: string | null; telefone_contato?: string | null
    site?: string | null; instagram?: string | null
  }
}

/** Desconto concedido no pagamento à vista. */
const DESCONTO_AVISTA = 5

type FormaPag = "CARTAO" | "AVISTA" | "OBRA" | "PERSONALIZADO"
const FORMAS: { id: FormaPag; label: string; desc: string; maxParcelas: number }[] = [
  { id: "CARTAO", label: "Cartão de crédito", desc: "Em até 6x", maxParcelas: 6 },
  { id: "AVISTA", label: "À vista", desc: `${DESCONTO_AVISTA}% de desconto`, maxParcelas: 1 },
  { id: "OBRA", label: "Parcelado na obra", desc: "A combinar com nossa equipe", maxParcelas: 0 },
]

const IMG_EXT = ["png", "jpg", "jpeg", "webp", "gif", "avif", "svg"]

function parseMeta(obs: string | null | undefined): { cor: string; confidencial: boolean } {
  const defaults = { cor: "#1f2937", confidencial: false }
  if (!obs) return defaults
  const match = obs.match(/\[META:({.*?})\]/)
  if (!match) return defaults
  try { return { ...defaults, ...JSON.parse(match[1]) } } catch { return defaults }
}

function daysRemaining(d: string | null) {
  if (!d) return null
  return Math.ceil((new Date(d).getTime() - Date.now()) / 86400000)
}

/** Agrupa por categoria (cada bloco vira um cartão) preservando a numeração contínua. */
function buildGroups(environments: Environment[]) {
  // Agrupa por AMBIENTE: é o ambiente que fica em destaque no cabeçalho do
  // bloco. A categoria de cada item aparece dentro da própria linha, entre o
  // nome e o SKU — por isso não precisa de coluna nem de rótulo duplicado.
  const porAmbiente = new Map<string, { envId: string; label: string; rows: { item: ProposalItem }[] }>()

  for (const env of environments) {
    const label = env.nome?.trim() || "Sem ambiente"
    if (!porAmbiente.has(env.id)) porAmbiente.set(env.id, { envId: env.id, label, rows: [] })
    for (const item of env.proposalItems) {
      porAmbiente.get(env.id)!.rows.push({ item })
    }
  }

  let n = 0
  return [...porAmbiente.values()]
    .filter(g => g.rows.length > 0)
    .map(g => ({
      /* O id vai junto do rótulo: dois ambientes podem se chamar igual, e é
         pelo id que a escolha do cliente volta para o servidor. */
      envId: g.envId,
      label: g.label,
      subtotal: g.rows.reduce((s, r) => s + Number(r.item.valor_total), 0),
      /* Numeracao reinicia em cada ambiente: o cliente le "Quarto 1, 2" e
         "Cozinha 1, 2", nao uma sequencia corrida que nao diz nada sobre o
         tamanho de cada bloco. */
      rows: g.rows.map((r, i) => ({ ...r, indice: i + 1 })),
    }))
}

/**
 * A marca de escolhido do bloco. Mesmo desenho no escopo e no celular.
 *
 * Círculo, não quadrado, e fino: é o desenho que o iOS usa para escolher vários
 * itens de uma lista. O quadrado com borda cheia tinha peso de caixa de
 * formulário e puxava o olho antes do nome do sistema, que é o que o cliente
 * está lendo.
 *
 * Desmarcado quase não existe — um traço cinza claro, só o bastante para dizer
 * que ali se escolhe. Marcado é preenchido e ganha o traço branco. Quem carrega
 * o estado é o bloco inteiro (anel e fundo); esta marca confirma, não anuncia.
 */
function Marca({ marcado }: { marcado: boolean }) {
  return (
    <span aria-hidden className={`marca-escolha flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-full border transition-all duration-200 ${
      marcado ? "border-zinc-900 bg-zinc-900" : "border-zinc-300/90 bg-transparent"
    }`}>
      {marcado && <Check className="h-2.5 w-2.5 text-white" strokeWidth={2.75} />}
    </span>
  )
}

/** Larguras fixas compartilhadas: mantêm as colunas alinhadas entre os cartões. */
function Cols({ comUnitario }: { comUnitario: boolean }) {
  return (
    <colgroup>
      <col className="w-12" />
      {/* Coluna própria para a miniatura. Antes ela ficava dentro da célula de
          descrição e empurrava o texto ~52px para a direita, então o título
          "Descrição" não batia com o nome do produto. */}
      <col className="w-16" />
      <col />
      {comUnitario && <col className="w-32" />}
      <col className="w-14" />
      {comUnitario && <col className="w-36" />}
    </colgroup>
  )
}

export default function PublicProposalPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = use(params)
  return <DocumentoProposta token={token} />
}

/**
 * O documento da proposta, um só para dois caminhos.
 *
 * No link do cliente ele busca em `/api/p/[token]` e traz a área de decisão.
 * Na via interna de impressão (`interno`), busca por `fonte`, que é uma rota
 * autenticada por sessão, e a decisão não aparece: quem responde é o cliente,
 * no link dele. O desenho do papel é o mesmo nos dois, e é por isso que os
 * dois usam este componente em vez de cada um ter a sua cópia.
 */
export function DocumentoProposta({ token, fonte, interno = false }: {
  /** Serve para imagens e anexos, que continuam saindo pelas rotas do link. */
  token: string
  /** De onde vêm os dados. Sem isto, o próprio link do cliente. */
  fonte?: string
  interno?: boolean
}) {
  const [proposal, setProposal] = useState<Proposal | null>(null)
  const [loading, setLoading] = useState(true)
  const [notFound, setNotFound] = useState(false)
  const [expired, setExpired] = useState(false)
  /* Portão de acesso: sem sessão, a página mostra o pedido de código em vez do
     documento. O link deixou de ser a credencial inteira. */
  const [precisaCodigo, setPrecisaCodigo] = useState(false)
  const [selected, setSelected] = useState<"ACEITA" | "EM_REVISAO" | "RECUSADA" | null>(null)
  /* Escolha de pagamento do cliente. Vai junto com o aceite e vira a condição
     registrada — o time não redigita nada no faturamento. */
  const [emailConfirma, setEmailConfirma] = useState("")
  const [erroAcao, setErroAcao] = useState("")
  const [formaEscolhida, setFormaEscolhida] = useState<FormaPag | null>(null)
  const [parcelasEscolhidas, setParcelasEscolhidas] = useState(1)
  const [entradaCliente, setEntradaCliente] = useState("")
  const [propostaCliente, setPropostaCliente] = useState("")
  const [motivo, setMotivo] = useState("")
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState<null | "ACEITA" | "EM_REVISAO" | "RECUSADA">(null)
  /* Quais sistemas ele quer levar. Começa com todos marcados: a proposta foi
     montada inteira, desmarcar é o gesto de quem quer adiar uma parte. O que
     sair daqui vira GUARDADO no histórico dele, não some. */
  const [sistemasEscolhidos, setSistemasEscolhidos] = useState<string[] | null>(null)
  /* No rascunho a área de decisão não existe, e é ali que a equipe confere o
     documento antes de mandar. Isto mostra a tela que o cliente vai ver, com
     os botões travados: conferir é uma coisa, responder é outra. */
  const [espiarComoCliente, setEspiarComoCliente] = useState(false)

  const carregar = useCallback(() => {
    setLoading(true)
    fetch(fonte ?? `/api/p/${token}`, { cache: "no-store" })
      .then(async r => {
        if (r.status === 410) { setExpired(true); setLoading(false); return null }
        // 401 é o portão, não erro: a proposta existe e espera o código.
        if (r.status === 401) { setPrecisaCodigo(true); setLoading(false); return null }
        if (!r.ok) { setNotFound(true); setLoading(false); return null }
        return r.json()
      })
      .then(d => {
        if (d) { setProposal(d.proposal); setPrecisaCodigo(false) }
        setLoading(false)
      })
      .catch(() => { setNotFound(true); setLoading(false) })
  }, [token, fonte])

  useEffect(() => { carregar() }, [carregar])

  /* A proposta volta revisada com a escolha anterior já marcada.
     Antes o cliente reabria o link e encontrava o bloco de pagamento em
     branco: tinha de dizer cartão, parcelas e entrada de novo, como se nunca
     tivesse dito. Vem marcado, e ele troca se quiser. */
  useEffect(() => {
    if (!proposal || proposal.pagamento_definido_por !== "CLIENTE") return
    const forma = (proposal.forma_pagamento ?? "").toUpperCase()
    if (!forma) return
    setFormaEscolhida(f => f ?? (forma as FormaPag))
    if (proposal.parcelas_forma) setParcelasEscolhidas(proposal.parcelas_forma)
    if (proposal.valor_entrada) setEntradaCliente(String(proposal.valor_entrada))
  }, [proposal])

  /* Nome do arquivo ao salvar em PDF. O navegador usa o <title> da página como
     sugestão, então é ele que precisa carregar o nome do cliente — não há API
     para definir o nome no window.print(). */
  useEffect(() => {
    if (!proposal) return
    const anterior = document.title
    document.title = `${proposal.numero}_${nomeArquivoSeguro(tituloCaso(proposal.client_name))}`
    return () => { document.title = anterior }
  }, [proposal])

  /* `sistemas` só vai quando o cliente desmarcou alguma coisa: mandar a lista
     inteira toda vez faria o servidor reescrever valor e parcelas sem motivo. */
  /* `sistemas` são ids de Environment; o bloco de projeto e instalação não é
     um deles, e vai no `semServico` quando o cliente o deixa de fora. */
  async function handleAcao(
    acao: "ACEITA" | "EM_REVISAO" | "RECUSADA",
    sistemas?: string[],
    semServico?: boolean,
  ) {
    setSubmitting(true)
    setErroAcao("")
    const resposta = await fetch(`/api/p/${token}/acao`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        acao,
        motivo: motivo.trim() || undefined,
        ...(sistemas?.length ? { sistemas } : {}),
        ...(semServico ? { semServico: true } : {}),
        // Só no aceite: a condição escolhida pelo cliente.
        ...(acao === "ACEITA" ? { emailConfirmacao: emailConfirma.trim() } : {}),
        ...(acao === "ACEITA" && formaEscolhida ? {
          pagamento: {
            forma: formaEscolhida,
            parcelas: formaEscolhida === "CARTAO" ? parcelasEscolhidas : 1,
            entrada: formaEscolhida === "AVISTA" ? 0 : Number(entradaCliente) || 0,
          },
        } : {}),
      }),
    })
    const j = await resposta.json().catch(() => ({}))
    setSubmitting(false)
    if (!resposta.ok) { setErroAcao(j.error || "Não foi possível registrar."); return }
    setErroAcao("")
    setSubmitted(acao)
  }

  if (loading) return (
    <Shell>
      <div className="flex min-h-[60vh] flex-col items-center justify-center gap-3">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-zinc-300 border-t-zinc-800" />
        <p className="text-sm text-zinc-500">Carregando proposta</p>
      </div>
    </Shell>
  )

  if (expired) return (
    <Shell>
      <div className="mx-auto flex min-h-[60vh] max-w-sm flex-col items-center justify-center px-6 text-center">
        <FileSearch className="mb-4 h-10 w-10 text-amber-500" strokeWidth={1.5} />
        <h1 className="text-lg font-semibold text-zinc-900">Este link expirou</h1>
        <p className="mt-2 text-sm leading-relaxed text-zinc-500">
          O prazo de validade da proposta terminou. Peça um link novo ao seu consultor.
        </p>
      </div>
    </Shell>
  )

  if (precisaCodigo) return <PortaoAcesso token={token} aoLiberar={carregar} />

  if (notFound || !proposal) return (
    <Shell>
      <div className="mx-auto flex min-h-[60vh] max-w-sm flex-col items-center justify-center px-6 text-center">
        <FileSearch className="mb-4 h-10 w-10 text-zinc-400" strokeWidth={1.5} />
        <h1 className="text-lg font-semibold text-zinc-900">Proposta não encontrada</h1>
        <p className="mt-2 text-sm leading-relaxed text-zinc-500">
          Este link pode ter sido removido. Confira o endereço com o seu consultor.
        </p>
      </div>
    </Shell>
  )

  const days = daysRemaining(proposal.data_expiracao)
  const gruposBase = buildGroups(proposal.environments)
  // Anexo vai pelo servidor: a Blob Store é privada e a URL crua não abre
  // no navegador do cliente.
  const anexoUrl = (url: string) =>
    url.startsWith("data:") || url.startsWith("/")
      ? url
      : `/api/p/${token}/anexo?url=${encodeURIComponent(url)}`
  const emailContato = proposal.company.email_contato || proposal.vendedor.email
  const produtosTotal = proposal.environments.reduce((s, e) => s + e.proposalItems.reduce((ss, i) => ss + Number(i.valor_total), 0), 0)
  const valorServico = Number(proposal.valor_servico || 0)

  /* Projeto e instalação virou BLOCO, ao lado dos sistemas.

     Antes ele era um valor solto no rodapé ("composição do valor"), rateado
     por ambiente para o bloco não mentir. Só que é assim que ele é vendido e
     é assim que o cliente decide sobre ele: com nome, preço à frente e a
     possibilidade de ficar de fora. O rateio continua existindo, mas só para
     saber quanto de serviço sai junto quando um sistema não é levado — a regra
     mora em `servicos-proposta`/`blocos-proposta`, compartilhada com o
     contrato e o pedido do Olist. */
  const itensParaServico = proposal.environments.flatMap(e =>
    e.proposalItems.map(i => ({
      environmentId: e.id,
      categoryId: i.category?.id ?? null,
      valor_total: Number(i.valor_total),
    })))

  const detalheServicos = Array.isArray(proposal.servicos_detalhe) ? proposal.servicos_detalhe : []
  /* Proposta antiga não guardava a composição: o total vira um serviço só, da
     proposta inteira. Melhor um bloco declarado que um rodapé sem dono. */
  const servicos: ServicoProposta[] = detalheServicos.length
    ? detalheServicos
    : valorServico > 0 ? [{ nome: NOME_BLOCO_SERVICO, tipo: "fixo", valor: valorServico }] : []

  const grupos = gruposBase
  const blocos = blocosDaProposta(
    proposal.environments.map(e => ({ id: e.id, nome: e.nome })),
    itensParaServico,
    servicos,
    valorServico,
  )
  const blocoDeServico = blocos.find(b => b.servico) ?? null
  const desconto = proposal.desconto_aplicado ? Number(proposal.desconto_aplicado) : 0
  const totalBruto = produtosTotal + valorServico
  const totalFinal = desconto > 0 ? totalBruto * (1 - desconto / 100) : totalBruto

  /* A escolha do cliente COMEÇA VAZIA.

     Começava com tudo marcado, e a primeira coisa que ele via era o total
     cheio — o valor da proposta inteira anunciado antes de ele escolher
     qualquer coisa. A conta agora se monta junto com ele: marca um bloco,
     aparece uma linha; marca outro, o total sobe. O documento acima continua
     mostrando a proposta inteira, o que muda é o que segue adiante. */
  /* Com um bloco só não há escolha a fazer — a lista de marcar nem aparece —,
     então ele já entra marcado: exigir um clique que não existe travaria o
     aceite. */
  const escolhidos = sistemasEscolhidos ?? (blocos.length > 1 ? [] : blocos.map(b => b.id))
  const parcial = escolhidos.length > 0 && escolhidos.length < blocos.length
  const alternarBloco = (id: string) => setSistemasEscolhidos(
    escolhidos.includes(id) ? escolhidos.filter(x => x !== id) : [...escolhidos, id])
  /* Os blocos com o valor que a escolha deixou: tirar um sistema tira também o
     serviço que era dele, e o bloco de projeto encolhe na hora. */
  const blocosEscolhidos = blocosComEscolha(blocos, servicos, itensParaServico, escolhidos)
    .filter(b => escolhidos.includes(b.id))
  /* O valor do que ele marcou. É esta a base do simulador de pagamento logo
     abaixo: marcar dois de três sistemas e ver a parcela do valor cheio seria
     mostrar um número que não existe. */
  const totalDosSistemas = (() => {
    const bruto = blocosEscolhidos.reduce((s, b) => s + b.valor, 0)
    return desconto > 0 ? bruto * (1 - desconto / 100) : bruto
  })()
  const entrada = Number(proposal.valor_entrada || 0)
  // Só entra se estiver ligado nas opções avançadas.
  const descontoCampanha = proposal.aplicar_desconto_campanha === false
    ? 0
    : Number(proposal.desconto_campanha || 0)
  // Valor unitário oculto por padrão: o cliente compara item a item e perde a
  // visão do conjunto. Quem monta a proposta liga caso a caso.
  /* Preço por item. Desligado, o cliente vê o que está incluído e o total
     geral — sem preço linha a linha. Governa unitário E total da linha:
     mostrar só o total entrega a mesma informação, basta dividir pela
     quantidade. */
  const mostrarPrecoItem = proposal.exibir_valor_unitario === true

  const formasOferecidas: FormaPag[] = (() => {
    try {
      const l = JSON.parse(proposal.formas_oferecidas || "[]")
      return Array.isArray(l) && l.length ? l : ["CARTAO", "AVISTA", "OBRA"]
    } catch { return ["CARTAO", "AVISTA", "OBRA"] }
  })()

  const parcelas = proposal.installments
  const primeira = parcelas[0]
  const iguais = parcelas.length > 1 && parcelas.every(p => Math.abs(Number(p.valor) - Number(primeira.valor)) < 0.01)
  /* Resumo da condição de pagamento.
   *
   * Sem parcelas geradas NÃO significa à vista. Quando a única forma oferecida
   * é "parcelado na obra", o valor ainda vai ser combinado com a equipe — e
   * escrever "Pagamento à vista" ali contradiz o que foi negociado, no
   * documento que o cliente lê e imprime.
   *
   * A ordem é: o que o cliente escolheu, depois o cronograma que existe, e só
   * então o que a empresa ofereceu. */
  const escolhida = (proposal.forma_pagamento ?? "").toUpperCase()
  const rotuloForma = (f: string) =>
    f === "OBRA" ? "Parcelado na obra, a combinar com nossa equipe"
      : f === "AVISTA" ? "Pagamento à vista"
        : f === "CARTAO" ? "Cartão de crédito"
          : f === "PERSONALIZADO" ? "Condição combinada" : ""

  const formaResumo =
    parcelas.length > 1
      ? (iguais ? `${parcelas.length}x de ${brl(Number(primeira.valor))}` : `${parcelas.length} parcelas`)
      : parcelas.length === 1 ? "Pagamento único"
        : escolhida ? rotuloForma(escolhida)
          // Nada escolhido e nenhum cronograma: vale o que foi oferecido.
          : formasOferecidas.length === 1 ? rotuloForma(formasOferecidas[0])
            : "A combinar"

  const paymentMethods: string[] = (() => {
    try { return JSON.parse(proposal.payment_methods || "[]") } catch { return [] }
  })()
  /* Formas que a empresa ofereceu nesta proposta. O cliente escolhe uma. */
  /* Marca dos documentos. Cai no logo do sistema só enquanto ninguém tiver
     definido o da proposta — depois disso, trocar o logo do sistema não mexe
     mais no que o cliente recebe. */
  const logoDocumento = proposal.company.logo_proposta_url || proposal.company.logo_url

  // Enquanto a proposta não foi enviada, o link é só para conferência.
  /* Rascunho e visualização interna mostram a mesma coisa: o documento como o
     cliente vê, sem as opções de resposta. Quem decide é quem recebeu o
     código — a equipe confere, não responde. */
  const ehPreVisualizacao = proposal.status === "RASCUNHO" && !espiarComoCliente

  /* Simulação da escolha do cliente. À vista aplica os 5% na hora; o restante
     divide o saldo depois da entrada. */
  const descontoAvista = formaEscolhida === "AVISTA" ? totalDosSistemas * (DESCONTO_AVISTA / 100) : 0
  const totalEscolhido = totalDosSistemas - descontoAvista
  const entradaNum = formaEscolhida === "AVISTA" ? 0 : Math.min(Number(entradaCliente) || 0, totalEscolhido)
  const saldoParcelar = Math.max(0, totalEscolhido - entradaNum)
  const nParcelas = formaEscolhida === "CARTAO" ? parcelasEscolhidas : 1
  const valorParcela = nParcelas > 0 ? saldoParcelar / nParcelas : 0
  /* Cronograma simulado: mensal a partir do mês que vem. As datas finais são
     confirmadas pela equipe. */
  const cronograma = formaEscolhida && formaEscolhida !== "OBRA"
    ? Array.from({ length: nParcelas }, (_, i) => {
        const d = new Date()
        d.setMonth(d.getMonth() + i + 1)
        return { n: i + 1, data: d, valor: valorParcela }
      })
    : []
  /* Proposta ainda em aberto: o cliente pode escolher. Depois de decidida
     (aceita, recusada, faturando) o bloco vira registro do que ficou. */
  const jaDecidiu = !["ENVIADA", "LIDA"].includes(proposal.status)
  const meta = parseMeta(proposal.observacoes)

  /* O bloco do escopo É o botão de escolha.

     Antes a escolha morava numa lista repetida lá embaixo, na área de decisão:
     o cliente lia o sistema no alto da folha e tinha que descer, achar o nome
     de novo e marcar — e subir outra vez para conferir o próximo. Agora ele
     marca no próprio bloco que acabou de ler, e a tabela "Sua seleção" se
     preenche embaixo, uma leitura só, de cima para baixo. */
  const podeEscolher = !interno && !submitted && !jaDecidiu && blocos.length > 1
  /* Conferindo a tela do cliente: os blocos aparecem do mesmo jeito, com o
     quadrinho, mas não respondem ao clique. */
  const escolhaTravada = espiarComoCliente
  const blocoSelecionavel = (podeEscolher || (espiarComoCliente && blocos.length > 1))

  return (
    <Shell accent={meta.cor} confidencial={meta.confidencial}>
      {meta.confidencial && <div className="confidencial-stamp">CONFIDENCIAL</div>}

      <div className="mx-auto w-full max-w-[920px] px-2.5 py-4 sm:px-6 sm:py-10 print:max-w-none print:p-0">
        <article className="doc-sheet overflow-hidden rounded-xl bg-white shadow-[0_1px_2px_rgba(16,18,24,.06),0_24px_60px_-24px_rgba(16,18,24,.28)] print:rounded-none print:shadow-none">

          {/* Cabeçalho: marca à esquerda, contato na faixa escura à direita */}
          <header className="relative bg-white">
            <div className="doc-band absolute right-0 top-0 hidden h-full w-[52%] bg-zinc-900 sm:block" />
            <div className="relative flex flex-col gap-6 px-6 py-7 sm:flex-row sm:items-center sm:gap-0 sm:px-0 sm:py-9">
              {/* A faixa escura ocupa 52% à direita: a marca centraliza nos 48%
                  brancos que sobram, em vez de encostar na borda. */}
              <div className="flex items-center justify-center py-1 sm:w-[48%]">
                {logoDocumento ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  /* Limita ALTURA e largura. Dimensionar só pela largura assume
                     logo horizontal (~2:1); com um logo quadrado o mesmo w-full
                     virava um bloco enorme, desproporcional ao cabeçalho. */
                  <img src={proxiedImg(logoDocumento, token)} alt={proposal.company.nome_empresa}
                    className="h-auto max-h-[92px] w-auto max-w-[260px] object-contain sm:max-h-[110px]" />
                ) : (
                  <span className="text-3xl font-extrabold tracking-tight text-zinc-900">
                    {proposal.company.nome_empresa}
                  </span>
                )}
              </div>
              {/* Ordem fixa: Nome Fantasia → CNPJ → Telefone → Site → Instagram.
                  Cada linha só aparece se estiver preenchida, para o bloco não
                  ficar com buracos em empresa sem site ou rede social. */}
              <div className="space-y-1 rounded-lg bg-zinc-900 px-5 py-4 text-[13px] text-zinc-300 sm:w-[52%] sm:bg-transparent sm:py-0 sm:pl-8 sm:pr-10 sm:text-right">
                <p className="text-[15px] font-semibold text-white">{proposal.company.nome_empresa}</p>
                {proposal.company.cnpj_cpf && (
                  <p className="text-zinc-400">CNPJ {proposal.company.cnpj_cpf}</p>
                )}
                {proposal.company.telefone_contato && (
                  <p className="flex items-center gap-2 sm:justify-end">
                    <Phone className="h-3.5 w-3.5 shrink-0 text-zinc-500" />
                    <span className="truncate">{formatarTelefone(proposal.company.telefone_contato)}</span>
                  </p>
                )}
                {proposal.company.site && (
                  <p className="flex items-center gap-2 sm:justify-end">
                    <Globe className="h-3.5 w-3.5 shrink-0 text-zinc-500" />
                    <span className="truncate">{proposal.company.site.replace(/^https?:\/\//, "")}</span>
                  </p>
                )}
                {proposal.company.instagram && (
                  <p className="flex items-center gap-2 sm:justify-end">
                    <Instagram className="h-3.5 w-3.5 shrink-0 text-zinc-500" />
                    <span className="truncate">
                      {proposal.company.instagram.startsWith("@") ? proposal.company.instagram : `@${proposal.company.instagram}`}
                    </span>
                  </p>
                )}
                <p className="flex items-center gap-2 pt-0.5 text-zinc-400 sm:justify-end">
                  <Mail className="h-3.5 w-3.5 shrink-0 text-zinc-500" />
                  <span className="truncate">{emailContato}</span>
                </p>
              </div>
            </div>
          </header>

          {/* Destinatário e metadados */}
          <section className="grid gap-8 border-t border-zinc-100 px-6 py-8 sm:grid-cols-[1fr_auto] sm:px-10">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-zinc-400">Proposta para</p>
              <h1 className="mt-2 text-2xl font-bold leading-tight text-zinc-900 sm:text-[28px]">{tituloCaso(proposal.client_name)}</h1>
              {proposal.client_email && <p className="text-sm text-zinc-500">{proposal.client_email}</p>}
            </div>
            <dl className="space-y-2 text-sm sm:min-w-[210px] sm:text-right">
              <div className="flex justify-between gap-6 sm:justify-end">
                <dt className="text-zinc-500">Número</dt>
                <dd className="font-semibold tabular-nums text-zinc-900">{proposal.numero}</dd>
              </div>
              {proposal.data_expiracao && (
                <div className="flex justify-between gap-6 sm:justify-end">
                  <dt className="text-zinc-500">Válida até</dt>
                  <dd className="font-semibold tabular-nums text-zinc-900">{fmtDate(proposal.data_expiracao)}</dd>
                </div>
              )}
              {days !== null && (
                <div className="pt-1 sm:flex sm:justify-end">
                  <span className={`inline-block rounded-md px-2.5 py-1 text-xs font-semibold ${
                    days < 0 ? "bg-red-50 text-red-700"
                      : days <= 3 ? "bg-amber-50 text-amber-700"
                        : "bg-emerald-50 text-emerald-700"
                  }`}>
                    {days < 0 ? "Prazo encerrado" : days === 0 ? "Último dia" : `${days} dias restantes`}
                  </span>
                </div>
              )}
              {/* Garantia em dias. Propostas antigas guardavam anos, converte
                  só na exibição, sem mexer no dado histórico. */}
              {(proposal.dias_garantia ?? (proposal.anos_garantia ? proposal.anos_garantia * 365 : 0)) > 0 && (
                <div className="pt-1 sm:flex sm:justify-end">
                  <span className="inline-flex items-center gap-1.5 rounded-md bg-zinc-100 px-2.5 py-1 text-xs font-semibold text-zinc-700">
                    <ShieldCheck className="h-3.5 w-3.5" />
                    {proposal.dias_garantia ?? (proposal.anos_garantia ?? 0) * 365} dias de garantia
                  </span>
                </div>
              )}
            </dl>
          </section>

          {/* Escopo */}
          <section className="px-6 sm:px-10">
            {/* Tabela a partir de sm. No celular ela virava rolagem lateral de
                660px, e o cliente lia a proposta arrastando de lado. Abaixo de
                sm entra a lista de cartões, logo depois deste bloco. */}
            <div className="doc-scroll hidden sm:block">
              <div className="doc-scroll-inner space-y-5">

                {/* Sem avoid-break no cartão: um card com muitos itens pode ser maior
                    que o espaço livre da página, e o navegador empurra o bloco inteiro
                    pra próxima folha, deixando a anterior com um vazio enorme. As
                    linhas de dentro (tr) já evitam quebrar sozinhas. */}
                {grupos.map(grupo => {
                  const marcado = escolhidos.includes(grupo.envId)
                  return (
                  <div key={tituloCaso(grupo.label)}
                    {...(blocoSelecionavel ? {
                      role: "button" as const,
                      tabIndex: escolhaTravada ? -1 : 0,
                      "aria-pressed": marcado,
                      onClick: () => { if (!escolhaTravada) alternarBloco(grupo.envId) },
                      onKeyDown: (e: React.KeyboardEvent) => {
                        if (escolhaTravada) return
                        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); alternarBloco(grupo.envId) }
                      },
                    } : {})}
                    className={blocoSelecionavel
                      ? `bloco-escolha rounded-2xl p-3 transition-colors ${escolhaTravada ? "cursor-default" : "cursor-pointer"} ${
                        marcado ? "bg-zinc-900/[0.04] ring-1 ring-zinc-900" : "ring-1 ring-zinc-200 hover:ring-zinc-400"
                      }`
                      : undefined}>
                    {/* Ambiente primeiro, em texto: é a âncora de leitura do
                        escopo. A barra escura logo abaixo segue sendo dos
                        rótulos das colunas — trocaram de lugar, não de forma. */}
                    {/* Valor do sistema no próprio bloco: é por bloco que o
                        cliente decide, e decidir sem o preço à frente obriga a
                        procurar o número em outro lugar da folha. */}
                    <div className="mb-3 flex items-center justify-between gap-4 px-1">
                      <p className="ambiente-titulo flex min-w-0 items-center gap-3 text-[17px] font-bold tracking-tight text-zinc-900">
                        {blocoSelecionavel && <Marca marcado={marcado} />}
                        <span className="min-w-0 truncate">{grupo.label}</span>
                      </p>
                      <span className="shrink-0 text-[15px] font-semibold tabular-nums text-zinc-900">
                        {brl(grupo.subtotal)}
                      </span>
                    </div>
                    <div className="doc-card overflow-hidden rounded-xl bg-white">
                      <table className="w-full table-fixed border-collapse text-sm">
                        <Cols comUnitario={mostrarPrecoItem} />
                        <thead>
                          <tr className="doc-ink text-left text-[11px] font-semibold uppercase tracking-[0.1em] text-zinc-300">
                            <th className="px-4 py-2.5 text-center">#</th>
                            <th aria-hidden className="py-2.5" />
                            <th className="py-2.5 pr-4">Descrição</th>
                            {mostrarPrecoItem && <th className="px-4 py-2.5 text-right">Valor unit.</th>}
                            <th className="px-4 py-2.5 text-center">Qtd</th>
                            {mostrarPrecoItem && <th className="px-4 py-2.5 text-right">Total</th>}
                          </tr>
                        </thead>
                        <tbody>
                          {grupo.rows.map(row => (
                            <tr key={row.item.id} className="avoid-break border-b border-zinc-100 last:border-0">
                              <td className="px-4 py-3.5 text-center tabular-nums text-zinc-400">{row.indice}</td>
                              <td className="py-3.5 align-middle">
                                {/* Sem foto do produto, usa a da categoria; sem
                                    nenhuma das duas, um lugar cinza do mesmo
                                    tamanho. A linha sem miniatura desalinha o
                                    bloco inteiro, e item escrito na visita
                                    ainda não tem foto de catálogo. */}
                                {(row.item.product?.imagem_url || row.item.category?.imagem_url) ? (
                                  // eslint-disable-next-line @next/next/no-img-element
                                  <img src={proxiedImg(row.item.product?.imagem_url || row.item.category?.imagem_url, token)} alt=""
                                    className="h-10 w-10 rounded-md border border-zinc-200 bg-white object-cover" />
                                ) : (
                                  <span className="flex h-10 w-10 items-center justify-center rounded-md border border-zinc-200 bg-zinc-50">
                                    <Package className="h-4 w-4 text-zinc-300" />
                                  </span>
                                )}
                              </td>
                              <td className="py-3.5 pr-4 align-middle">
                                <div className="min-w-0">
                                  <p className="font-medium text-zinc-900">{row.item.product?.nome || row.item.nome_snapshot || "Item"}</p>
                                  {row.item.category?.nome && (
                                    <p className="mt-0.5 text-[10px] uppercase tracking-wide text-zinc-400">{row.item.category.nome}</p>
                                  )}
                                  {row.item.product?.sku && (
                                    <p className="mt-0.5 font-mono text-[11px] text-zinc-400">{row.item.product.sku}</p>
                                  )}
                                </div>
                              </td>
                              {mostrarPrecoItem && (
                                <td className="px-4 py-3.5 text-right tabular-nums text-zinc-600">{brl(Number(row.item.valor_unitario))}</td>
                              )}
                              <td className="px-4 py-3.5 text-center tabular-nums text-zinc-600">{row.item.quantidade}</td>
                              {mostrarPrecoItem && (
                                <td className="px-4 py-3.5 text-right font-semibold tabular-nums text-zinc-900">{brl(Number(row.item.valor_total))}</td>
                              )}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                      {/* Sem preço por sistema aqui: o valor aparece uma vez
                          só, no fechamento (subtotal, projeto e instalação,
                          total). Repetir o preço de cada bloco puxava a
                          conversa pra comparar parte por parte. */}
                    </div>
                  </div>
                )})}

                {/* Projeto e instalação como bloco, não mais como linha solta
                    no rodapé. É um item da compra: tem nome, valor e o cliente
                    decide sobre ele junto com os sistemas. */}
                {blocoDeServico && (() => {
                  const marcado = escolhidos.includes(BLOCO_SERVICO)
                  return (
                  <div
                    {...(blocoSelecionavel ? {
                      role: "button" as const,
                      tabIndex: escolhaTravada ? -1 : 0,
                      "aria-pressed": marcado,
                      onClick: () => { if (!escolhaTravada) alternarBloco(BLOCO_SERVICO) },
                      onKeyDown: (e: React.KeyboardEvent) => {
                        if (escolhaTravada) return
                        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); alternarBloco(BLOCO_SERVICO) }
                      },
                    } : {})}
                    className={blocoSelecionavel
                      ? `bloco-escolha rounded-2xl p-3 transition-colors ${escolhaTravada ? "cursor-default" : "cursor-pointer"} ${
                        marcado ? "bg-zinc-900/[0.04] ring-1 ring-zinc-900" : "ring-1 ring-zinc-200 hover:ring-zinc-400"
                      }`
                      : undefined}>
                    <div className="mb-3 flex items-center justify-between gap-4 px-1">
                      <p className="ambiente-titulo flex min-w-0 items-center gap-3 text-[17px] font-bold tracking-tight text-zinc-900">
                        {blocoSelecionavel && <Marca marcado={marcado} />}
                        <span className="min-w-0 truncate">{blocoDeServico.nome}</span>
                      </p>
                      <span className="shrink-0 text-[15px] font-semibold tabular-nums text-zinc-900">
                        {brl(blocoDeServico.valor)}
                      </span>
                    </div>
                    {/* Mesma barra de rótulos dos sistemas: o bloco do projeto
                        é lido junto com eles, e uma lista sem cabeçalho no meio
                        de tabelas com cabeçalho parece outra coisa. */}
                    <div className="doc-card overflow-hidden rounded-xl bg-white">
                      <table className="w-full table-fixed border-collapse text-sm">
                        <colgroup>
                          <col className="w-12" />
                          <col />
                          {mostrarPrecoItem && <col className="w-36" />}
                        </colgroup>
                        <thead>
                          {/* Preço linha a linha só com o switch ligado, igual
                              aos itens: desligado, o cliente vê o que está
                              incluído e o valor do bloco. */}
                          <tr className="doc-ink text-left text-[11px] font-semibold uppercase tracking-[0.1em] text-zinc-300">
                            <th className="px-4 py-2.5 text-center">#</th>
                            <th className="py-2.5 pr-4">Descrição</th>
                            {mostrarPrecoItem && <th className="px-4 py-2.5 text-right">Valor</th>}
                          </tr>
                        </thead>
                        <tbody>
                          {(blocoDeServico.itens ?? []).map((sv, i) => (
                            <tr key={`${sv.nome}-${i}`} className="avoid-break border-b border-zinc-100 last:border-0">
                              <td className="px-4 py-3.5 text-center tabular-nums text-zinc-400">{i + 1}</td>
                              <td className="py-3.5 pr-4 font-medium text-zinc-900">{sv.nome}</td>
                              {mostrarPrecoItem && (
                                <td className="px-4 py-3.5 text-right font-semibold tabular-nums text-zinc-900">{brl(sv.valor)}</td>
                              )}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )})()}
              </div>
            </div>

            {/* Escopo no celular: cada ambiente é um cartão e cada item uma
                linha empilhada. Substitui a rolagem lateral da tabela — em
                390px o cliente lia a proposta arrastando de lado. */}
            <div className="escopo-cartoes space-y-5 sm:hidden">
              {grupos.map(grupo => {
                const marcado = escolhidos.includes(grupo.envId)
                return (
                <div key={`m-${grupo.label}`}
                  {...(blocoSelecionavel ? {
                    role: "button" as const,
                    tabIndex: escolhaTravada ? -1 : 0,
                    "aria-pressed": marcado,
                    onClick: () => { if (!escolhaTravada) alternarBloco(grupo.envId) },
                  } : {})}
                  className={blocoSelecionavel
                    ? `rounded-2xl p-2.5 ${marcado ? "bg-zinc-900/[0.04] ring-1 ring-zinc-900" : "ring-1 ring-zinc-200"}`
                    : undefined}>
                  <div className="mb-2 flex items-center justify-between gap-3 px-1">
                    <p className="flex min-w-0 items-center gap-2.5 text-[16px] font-bold tracking-tight text-zinc-900">
                      {blocoSelecionavel && <Marca marcado={marcado} />}
                      <span className="min-w-0 truncate">{tituloCaso(grupo.label)}</span>
                    </p>
                    <span className="shrink-0 text-[15px] font-semibold tabular-nums text-zinc-900">
                      {brl(grupo.subtotal)}
                    </span>
                  </div>
                  <div className="doc-card overflow-hidden rounded-xl bg-white">
                    {grupo.rows.map(row => (
                      <div key={row.item.id} className="avoid-break flex gap-3 border-b border-zinc-100 p-3.5 last:border-0">
                        <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-zinc-900 text-[11px] font-semibold tabular-nums text-white">
                          {row.indice}
                        </span>
                        {(row.item.product?.imagem_url || row.item.category?.imagem_url) ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={proxiedImg(row.item.product?.imagem_url || row.item.category?.imagem_url, token)} alt=""
                            className="h-12 w-12 shrink-0 rounded-lg border border-zinc-200 bg-white object-cover" />
                        ) : (
                          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg border border-zinc-200 bg-zinc-50">
                            <Package className="h-5 w-5 text-zinc-300" />
                          </span>
                        )}
                        <div className="min-w-0 flex-1">
                          <p className="text-[15px] font-semibold leading-tight text-zinc-900">
                            {row.item.product?.nome || row.item.nome_snapshot || "Item"}
                          </p>
                          {row.item.category?.nome && (
                            <p className="mt-0.5 text-[10px] uppercase tracking-wide text-zinc-400">
                              {row.item.category.nome}
                            </p>
                          )}
                          {row.item.product?.sku && (
                            <p className="mt-0.5 font-mono text-[11px] text-zinc-400">{row.item.product.sku}</p>
                          )}
                          <div className="mt-2 flex items-end justify-between gap-3">
                            <span className="text-[12px] text-zinc-500">
                              Qtd. {row.item.quantidade}
                              {mostrarPrecoItem && ` · ${brl(Number(row.item.valor_unitario))}`}
                            </span>
                            {mostrarPrecoItem && (
                              <span className="text-[15px] font-bold tabular-nums text-zinc-900">
                                {brl(Number(row.item.valor_total))}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                    {/* Sem preço por sistema: o valor fica só no fechamento. */}
                  </div>
                </div>
              )})}

              {blocoDeServico && (() => {
                const marcado = escolhidos.includes(BLOCO_SERVICO)
                return (
                <div
                  {...(blocoSelecionavel ? {
                    role: "button" as const,
                    tabIndex: escolhaTravada ? -1 : 0,
                    "aria-pressed": marcado,
                    onClick: () => { if (!escolhaTravada) alternarBloco(BLOCO_SERVICO) },
                  } : {})}
                  className={blocoSelecionavel
                    ? `rounded-2xl p-2.5 ${marcado ? "bg-zinc-900/[0.04] ring-1 ring-zinc-900" : "ring-1 ring-zinc-200"}`
                    : undefined}>
                  <div className="mb-2 flex items-center justify-between gap-3 px-1">
                    <p className="flex min-w-0 items-center gap-2.5 text-[16px] font-bold tracking-tight text-zinc-900">
                      {blocoSelecionavel && <Marca marcado={marcado} />}
                      <span className="min-w-0 truncate">{blocoDeServico.nome}</span>
                    </p>
                    <span className="shrink-0 text-[15px] font-semibold tabular-nums text-zinc-900">
                      {brl(blocoDeServico.valor)}
                    </span>
                  </div>
                  <div className="doc-card overflow-hidden rounded-xl bg-white">
                    <div className="doc-ink flex items-center justify-between px-3.5 py-2 text-[11px] font-semibold uppercase tracking-[0.1em] text-zinc-300">
                      <span>Descrição</span>
                      {mostrarPrecoItem && <span>Valor</span>}
                    </div>
                    {(blocoDeServico.itens ?? []).map((sv, i) => (
                      <div key={`m-${sv.nome}-${i}`}
                        className="avoid-break flex items-baseline justify-between gap-3 border-b border-zinc-100 px-3.5 py-3 text-sm last:border-0">
                        <span className="flex min-w-0 items-baseline gap-2.5">
                          <span className="shrink-0 tabular-nums text-zinc-400">{i + 1}</span>
                          <span className="min-w-0 font-medium text-zinc-900">{sv.nome}</span>
                        </span>
                        {mostrarPrecoItem && (
                          <span className="shrink-0 font-semibold tabular-nums text-zinc-900">{brl(sv.valor)}</span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )})()}
            </div>

            {/* Fechamento de valores.

                Só onde não há mais escolha a fazer: a via impressa, a proposta
                já decidida e a resposta enviada. Enquanto o cliente escolhe, o
                total é o da SELEÇÃO dele, e ele aparece uma vez só — na tabela
                de conferência, logo antes do aceite. Dois totais na mesma
                página, um deles do que ele não vai levar, é o que faz a conta
                parecer errada. */}
            {((interno || jaDecidiu || !!submitted) && !espiarComoCliente) && (
            <div className="mt-8 flex justify-end">
              <div className="w-full max-w-sm">
                <div className="space-y-2.5 text-sm">
                  {/* Fechamento por bloco: cada sistema e o projeto/instalação
                      com o seu valor, e o total embaixo. A linha única de
                      "composição do valor" saiu — ela escondia o projeto num
                      rodapé, e é sobre ele que o cliente também decide. */}
                  {blocos.map(b => (
                    <div key={`f-${b.id}`} className="flex justify-between gap-4">
                      <span className="min-w-0 truncate text-zinc-500">{tituloCaso(b.nome)}</span>
                      <span className="shrink-0 tabular-nums text-zinc-800">{brl(b.valor)}</span>
                    </div>
                  ))}
                  {/* Campanha e negociação aparecem separadas: o cliente enxerga
                      o que ganhou de promoção e o que ganhou na conversa. */}
                  {descontoCampanha > 0 && (
                    <div className="flex justify-between">
                      <span className="text-zinc-500">Desconto de campanha</span>
                      <span className="tabular-nums text-zinc-600">- {brl(descontoCampanha)}</span>
                    </div>
                  )}
                  {desconto > 0 && (
                    <div className="flex justify-between">
                      <span className="text-emerald-700">Desconto de {pct(desconto, 2)}</span>
                      <span className="tabular-nums text-emerald-700">- {brl(totalBruto * desconto / 100)}</span>
                    </div>
                  )}
                </div>
                <div className="doc-ink avoid-break mt-4 flex items-baseline justify-between rounded-lg px-5 py-4">
                  <span className="text-sm font-medium text-zinc-300">Total</span>
                  <span className="text-2xl font-bold tabular-nums text-white">{brl(totalFinal)}</span>
                </div>
              </div>
            </div>
            )}
          </section>

          {/* Só no papel: o que ele marcou, o total, a resposta e o recado.

              Tudo isso vive na área de decisão, que é `no-print` — imprimir a
              proposta dava o escopo e o preço cheio, sem dizer o que o cliente
              escolheu nem o que ele respondeu. Quem imprime para arquivar ou
              levar à reunião precisa exatamente disso. */}
          {(escolhidos.length > 0 || selected || submitted) && (
            <section className="so-print evitar-quebra px-6 pt-10 sm:px-10">
              <h2 className="text-[11px] font-semibold uppercase tracking-[0.14em] text-zinc-400">
                Escolha do cliente
              </h2>
              {escolhidos.length > 0 && (
                <div className="mt-3 overflow-hidden rounded-xl border border-zinc-200">
                  {blocosEscolhidos.map(b => (
                    <div key={`p-${b.id}`}
                      className="flex items-baseline justify-between gap-4 border-b border-zinc-100 px-4 py-2.5 text-sm last:border-0">
                      <span className="text-zinc-700">{tituloCaso(b.nome)}</span>
                      <span className="shrink-0 tabular-nums text-zinc-900">{brl(b.valor)}</span>
                    </div>
                  ))}
                  {desconto > 0 && (
                    <div className="flex items-baseline justify-between gap-4 border-t border-zinc-100 px-4 py-2.5 text-sm">
                      <span className="text-zinc-600">Desconto de {pct(desconto, 2)}</span>
                      <span className="shrink-0 tabular-nums text-zinc-600">
                        - {brl(blocosEscolhidos.reduce((t, b) => t + b.valor, 0) * desconto / 100)}
                      </span>
                    </div>
                  )}
                  <div className="doc-ink flex items-baseline justify-between gap-4 px-4 py-3">
                    <span className="text-sm font-medium text-zinc-300">Total</span>
                    <span className="text-lg font-bold tabular-nums text-white">{brl(totalDosSistemas)}</span>
                  </div>
                </div>
              )}

              {(submitted || selected) && (
                <p className="mt-3 text-sm text-zinc-700">
                  Resposta:{" "}
                  <span className="font-semibold text-zinc-900">
                    {(submitted ?? selected) === "ACEITA" ? "Proposta aceita"
                      : (submitted ?? selected) === "EM_REVISAO" ? "Revisão solicitada"
                        : "Não aceita"}
                  </span>
                  {formaEscolhida && (submitted ?? selected) === "ACEITA" && (
                    <> · {FORMAS.find(f => f.id === formaEscolhida)?.label}
                      {formaEscolhida === "CARTAO" && parcelasEscolhidas > 1 && ` em ${parcelasEscolhidas}x`}
                    </>
                  )}
                </p>
              )}
              {motivo.trim() && (
                <div className="mt-2 rounded-xl border border-zinc-200 px-4 py-3">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-zinc-400">Comentário</p>
                  <p className="mt-1 whitespace-pre-wrap text-[13px] leading-relaxed text-zinc-700">{motivo.trim()}</p>
                </div>
              )}
            </section>
          )}

          {/* Pagamento, o CLIENTE escolhe.
              Antes a proposta anunciava uma condição fechada e a equipe
              redigitava tudo no faturamento. Agora ele monta aqui, vê o
              cronograma na hora, e a escolha vai junto com o aceite. */}
          <section className="pagamento-bloco px-6 pt-12 sm:px-10">
            <h2 className="text-[11px] font-semibold uppercase tracking-[0.14em] text-zinc-400">Pagamento</h2>

            {jaDecidiu ? (
              <>
                <p className="mt-2 text-xl font-semibold tabular-nums text-zinc-900">{formaResumo}</p>
                {entrada > 0 && (
                  <p className="mt-1 text-sm text-zinc-500">
                    Entrada de {brl(entrada)} · saldo de {brl(Math.max(0, totalFinal - entrada))}
                  </p>
                )}
                {parcelas.length > 1 && (
                  <div className="mt-5 grid gap-x-12 sm:grid-cols-2">
                    {parcelas.map(inst => (
                      <div key={inst.numero_parcela}
                        className="avoid-break flex items-baseline justify-between border-b border-zinc-100 py-2.5 text-sm">
                        <span className="tabular-nums text-zinc-500">
                          <span className="inline-block w-7 text-zinc-400">{inst.numero_parcela}</span>
                          {fmtDate(inst.data_vencimento)}
                        </span>
                        <span className="font-medium tabular-nums text-zinc-900">{brl(Number(inst.valor))}</span>
                      </div>
                    ))}
                  </div>
                )}
              </>
            ) : (
              <>
                <p className="mt-1 text-sm text-zinc-500">Escolha como prefere pagar.</p>

                {/* Versão impressa das condições: os cartões abaixo são
                    interativos e não vão para o papel, mas o cliente precisa
                    ver o que está sendo oferecido — na folha e na conferência
                    antes do envio. */}
                <ul className="so-print mt-3 space-y-1.5">
                  {FORMAS.filter(f => formasOferecidas.includes(f.id)).map(f => (
                    <li key={f.id} className="flex items-baseline gap-2 text-[14px] text-zinc-700">
                      <span className="font-semibold text-zinc-900">{f.label}</span>
                      <span className="text-zinc-500">— {f.desc}</span>
                    </li>
                  ))}
                </ul>

                <div className="no-print mt-4 grid gap-3 sm:grid-cols-3">
                  {FORMAS.filter(f => formasOferecidas.includes(f.id)).map(f => {
                    const sel = formaEscolhida === f.id
                    return (
                      <button key={f.id} type="button"
                        /* Conferindo a tela do cliente: mostra, não escolhe. */
                        disabled={espiarComoCliente}
                        onClick={() => {
                          setFormaEscolhida(sel ? null : f.id)
                          if (f.id === "AVISTA") setEntradaCliente("")
                        }}
                        className={`rounded-xl border p-4 text-left transition-all ${
                          sel ? "border-zinc-900 bg-zinc-900 text-white" : "border-zinc-200 bg-white hover:border-zinc-400"
                        } ${espiarComoCliente ? "cursor-not-allowed opacity-60" : ""}`}>
                        <span className="block text-[15px] font-semibold leading-tight">{f.label}</span>
                        <span className={`mt-0.5 block text-[13px] ${sel ? "text-zinc-300" : "text-zinc-500"}`}>{f.desc}</span>
                      </button>
                    )
                  })}
                </div>

                {formaEscolhida === "CARTAO" && (
                  <div className="no-print mt-4 rounded-xl border border-zinc-200 bg-zinc-50 p-4">
                    <p className="text-sm font-semibold text-zinc-900">Em quantas vezes?</p>
                    <div className="mt-2.5 flex flex-wrap gap-2">
                      {[1, 2, 3, 4, 5, 6].map(n => (
                        <button key={n} type="button" disabled={espiarComoCliente}
                          onClick={() => setParcelasEscolhidas(n)}
                          className={`h-10 min-w-[52px] rounded-lg border px-3 text-sm font-semibold transition-colors ${
                            parcelasEscolhidas === n
                              ? "border-zinc-900 bg-zinc-900 text-white"
                              : "border-zinc-300 bg-white text-zinc-700 hover:border-zinc-400"
                          }`}>{n}x</button>
                      ))}
                    </div>
                  </div>
                )}

                {formaEscolhida && formaEscolhida !== "AVISTA" && (
                  <div className="no-print mt-3 rounded-xl border border-zinc-200 bg-zinc-50 p-4">
                    <label htmlFor="entrada-cliente" className="block text-sm font-semibold text-zinc-900">
                      Quer dar uma entrada? <span className="font-normal text-zinc-500">(opcional)</span>
                    </label>
                    <input id="entrada-cliente" type="number" min={0} step="0.01" inputMode="decimal"
                      value={entradaCliente} onChange={e => setEntradaCliente(e.target.value)}
                      disabled={espiarComoCliente}
                      placeholder="R$ 0,00"
                      className="mt-2 h-11 w-full rounded-lg border border-zinc-300 bg-white px-3.5 text-[16px] text-zinc-900 placeholder:text-zinc-400 focus:border-zinc-900 focus:outline-none sm:w-48" />
                  </div>
                )}

                {formaEscolhida === "AVISTA" && (
                  <div className="mt-4 rounded-xl border border-zinc-200 bg-zinc-50 p-4">
                    <div className="flex items-baseline justify-between text-sm">
                      <span className="text-zinc-500">Desconto à vista ({DESCONTO_AVISTA}%)</span>
                      <span className="tabular-nums text-zinc-600">- {brl(descontoAvista)}</span>
                    </div>
                    <div className="mt-2 flex items-baseline justify-between border-t border-zinc-200 pt-2">
                      <span className="text-sm font-medium text-zinc-700">Você paga</span>
                      <span className="text-xl font-bold tabular-nums text-zinc-900">{brl(totalEscolhido)}</span>
                    </div>
                  </div>
                )}


                {formaEscolhida === "OBRA" && (
                  <div className="mt-4 rounded-xl border border-zinc-200 bg-zinc-50 p-4 text-sm text-zinc-600">
                    As parcelas acompanham o andamento da obra e são combinadas com a nossa
                    equipe depois do aceite.
                  </div>
                )}

                {formaEscolhida === "CARTAO" && (
                  <div className="mt-4 rounded-xl border border-zinc-200 bg-zinc-50 p-4">
                    {entradaNum > 0 && (
                      <div className="mb-2 flex items-baseline justify-between border-b border-zinc-200 pb-2 text-sm">
                        <span className="text-zinc-500">Entrada</span>
                        <span className="font-semibold tabular-nums text-zinc-900">{brl(entradaNum)}</span>
                      </div>
                    )}
                    <div className="flex items-baseline justify-between">
                      <span className="text-sm font-medium text-zinc-700">{nParcelas}x de</span>
                      <span className="text-xl font-bold tabular-nums text-zinc-900">{brl(valorParcela)}</span>
                    </div>
                    {cronograma.length > 1 && (
                      <div className="mt-3 grid gap-x-10 border-t border-zinc-200 pt-3 sm:grid-cols-2">
                        {cronograma.map(c => (
                          <div key={c.n} className="flex items-baseline justify-between border-b border-zinc-100 py-2 text-sm last:border-0">
                            <span className="tabular-nums text-zinc-500">
                              <span className="inline-block w-6 text-zinc-400">{c.n}</span>
                              {c.data.toLocaleDateString("pt-BR")}
                            </span>
                            <span className="font-medium tabular-nums text-zinc-900">{brl(c.valor)}</span>
                          </div>
                        ))}
                      </div>
                    )}
                    <p className="mt-2 text-[12px] text-zinc-500">
                      Datas previstas, confirmadas pela nossa equipe após o aceite.
                    </p>
                  </div>
                )}
              </>
            )}
          </section>

          {/* Páginas anexas: texto e imagens no corpo, arquivos ao final */}
          {proposal.extraPages.map((page, i) => (
            <section key={i} className="print-break px-6 pt-10 sm:px-10">
              <h2 className="text-sm font-semibold text-zinc-900">{page.titulo}</h2>
              <div
                className="doc-prose mt-3 text-[15px] leading-relaxed text-zinc-700"
                dangerouslySetInnerHTML={{ __html: sanitizeHtml(page.conteudo_markdown) }}
              />
              {/* Estilo docs: imagem inteira, centralizada, com o nome como
                  legenda embaixo — não miniatura cortada em grade. */}
              {(page.anexos ?? []).length > 0 && (
                <div className="avoid-break mt-6 flex flex-col items-center gap-6">
                  {(page.anexos ?? []).map((a, j) => {
                    const ehImagem = IMG_EXT.includes(a.ext.toLowerCase())
                    return ehImagem ? (
                      <figure key={j} className="avoid-break w-full max-w-[480px] text-center">
                        <a href={anexoUrl(a.url)} target="_blank" rel="noreferrer" className="block">
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img src={proxiedImg(a.url, token)} alt={a.nome}
                            className="mx-auto max-h-[420px] w-full rounded-lg border border-zinc-200 object-contain" />
                        </a>

                      </figure>
                    ) : (
                      <a key={j} href={anexoUrl(a.url)} target="_blank" rel="noreferrer"
                        className="avoid-break flex w-full max-w-[480px] items-center gap-2.5 rounded-lg border border-zinc-200 px-4 py-3.5 text-sm text-zinc-700 transition-colors hover:border-zinc-400 hover:text-zinc-900">
                        <Paperclip className="h-4 w-4 shrink-0 text-zinc-400" />
                        <span className="min-w-0 flex-1 truncate text-center">{a.nome}</span>
                        <span className="shrink-0 font-mono text-[10px] uppercase text-zinc-400">{a.ext}</span>
                      </a>
                    )
                  })}
                </div>
              )}
            </section>
          ))}

          {/* Decisão. Some na via interna: ali o documento é para imprimir, e
              quem aceita é o cliente pelo link dele. */}
          {!interno && (
          <section className="no-print mt-12 border-t border-zinc-200 bg-zinc-50 px-6 py-8 sm:px-10">
            {ehPreVisualizacao ? (
              /* O link existe desde que a proposta é criada, e a equipe o abre
                 para conferir antes de enviar. Aceitar por aqui marcaria como
                 fechada uma proposta que o cliente nem recebeu. */
              <div className="mx-auto max-w-md text-center">
                <Eye className="mx-auto mb-3 h-9 w-9 text-zinc-400" strokeWidth={1.5} />
                <p className="text-lg font-semibold text-zinc-900">Pré-visualização</p>
                <p className="mt-1.5 text-sm leading-relaxed text-zinc-600">
                  É assim que o cliente vai ver a proposta. As opções de resposta
                  aparecem para ele depois do envio.
                </p>
                {/* Conferir a tela dele antes de mandar, sem sair da conta. */}
                <button type="button" onClick={() => setEspiarComoCliente(true)}
                  className="mt-4 inline-flex items-center gap-2 rounded-lg border border-zinc-300 bg-white px-4 py-2.5 text-sm font-medium text-zinc-800 transition-colors hover:border-zinc-400">
                  <Eye className="h-4 w-4" strokeWidth={1.75} /> Ver a tela do cliente
                </button>
              </div>
            ) : submitted ? (
              <div className="mx-auto max-w-md text-center">
                <CheckCircle2 className="mx-auto mb-3 h-10 w-10 text-emerald-600" strokeWidth={1.5} />
                <p className="text-lg font-semibold text-zinc-900">
                  {submitted === "ACEITA" ? "Proposta aceita" : submitted === "EM_REVISAO" ? "Revisão solicitada" : "Resposta registrada"}
                </p>
                <p className="mt-1.5 text-sm leading-relaxed text-zinc-600">
                  {submitted === "ACEITA"
                    ? "Enviamos a confirmação para o seu e-mail. Nossa equipe entra em contato para as tratativas finais."
                    : submitted === "EM_REVISAO"
                      ? "Vamos ajustar a proposta e reenviar o link atualizado."
                      : "Obrigado pelo retorno. Seu consultor foi avisado."}
                </p>
              </div>
            ) : (
              <div className="mx-auto max-w-2xl">
                {/* Espiando: é a tela do cliente, mas quem responde é ele. */}
                {espiarComoCliente && (
                  <div className="mb-5 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-amber-300 bg-amber-50 px-4 py-3">
                    <p className="text-[13px] text-amber-900">
                      Tela do cliente, só para conferir: os blocos são os mesmos que ele vê, mas
                      aqui não se escolhe nada. A resposta só vale partindo do acesso dele, com o
                      e-mail que recebeu a proposta e o código enviado para ele.
                    </p>
                    <button type="button" onClick={() => setEspiarComoCliente(false)}
                      className="text-[13px] font-medium text-amber-900 underline underline-offset-2">
                      Voltar à visão interna
                    </button>
                  </div>
                )}
                <h2 className="text-center text-lg font-semibold text-zinc-900">Sua decisão</h2>
                <p className="mt-1 text-center text-sm text-zinc-500">Escolha uma opção para seguirmos.</p>

                {/* Conferência do que ele marcou, antes do aceite: nome do
                    bloco, valor à frente e o total embaixo. É o mesmo resumo
                    que sai no e-mail e segue para o faturamento — ele confirma
                    lendo a conta, não confiando nela. */}
                <div className="mt-5 overflow-hidden rounded-lg border border-zinc-200 bg-white">
                    <p className="border-b border-zinc-100 px-4 py-2.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-zinc-400">
                      Sua seleção
                    </p>
                    {blocosEscolhidos.length === 0 && (
                      <p className="border-b border-zinc-100 px-4 py-3 text-sm text-zinc-500">
                        Toque nos blocos da proposta, acima, e o valor aparece aqui.
                      </p>
                    )}
                    {blocosEscolhidos.map(b => (
                      <div key={`sel-${b.id}`}
                        className="flex items-baseline justify-between gap-4 border-b border-zinc-100 px-4 py-2.5 text-sm">
                        <span className="min-w-0 truncate text-zinc-700">{tituloCaso(b.nome)}</span>
                        <span className="shrink-0 tabular-nums text-zinc-900">{brl(b.valor)}</span>
                      </div>
                    ))}
                    {desconto > 0 && (
                      <div className="flex items-baseline justify-between gap-4 border-b border-zinc-100 px-4 py-2.5 text-sm">
                        <span className="text-emerald-700">Desconto de {pct(desconto, 2)}</span>
                        <span className="shrink-0 tabular-nums text-emerald-700">
                          - {brl(blocosEscolhidos.reduce((t, b) => t + b.valor, 0) * desconto / 100)}
                        </span>
                      </div>
                    )}
                    <div className="flex items-baseline justify-between gap-4 bg-zinc-900 px-4 py-3">
                      <span className="text-sm font-medium text-zinc-300">Total</span>
                      <span className="text-lg font-bold tabular-nums text-white">{brl(totalDosSistemas)}</span>
                    </div>
                  </div>

                <div className="mt-5 grid gap-2.5 sm:grid-cols-3">
                  {([
                    { value: "ACEITA", label: "Aceitar proposta", Icon: CheckCircle2, sel: "border-emerald-600 bg-emerald-50 text-emerald-900", idle: "hover:border-emerald-400" },
                    { value: "EM_REVISAO", label: "Requisitar revisão", Icon: MessageSquareText, sel: "border-amber-600 bg-amber-50 text-amber-900", idle: "hover:border-amber-400" },
                    { value: "RECUSADA", label: "Não aceitar", Icon: XCircle, sel: "border-red-600 bg-red-50 text-red-900", idle: "hover:border-red-400" },
                  ] as const).map(opt => (
                    <button key={opt.value} type="button" onClick={() => setSelected(opt.value)}
                      disabled={espiarComoCliente}
                      aria-pressed={selected === opt.value}
                      className={`flex items-center gap-2.5 rounded-lg border bg-white px-4 py-3.5 text-left text-sm font-medium text-zinc-800 transition-colors active:scale-[0.99] ${
                        selected === opt.value ? opt.sel : `border-zinc-200 ${opt.idle}`
                      } ${espiarComoCliente ? "cursor-not-allowed opacity-60" : ""}`}>
                      <opt.Icon className="h-4 w-4 shrink-0" strokeWidth={1.75} />
                      <span>{opt.label}</span>
                    </button>
                  ))}
                </div>

                {(selected === "EM_REVISAO" || selected === "RECUSADA") && (
                  <div className="mt-4">
                    <label htmlFor="motivo" className="block text-sm font-medium text-zinc-800">
                      {selected === "EM_REVISAO" ? "O que devemos ajustar?" : "Pode nos contar o motivo?"}
                    </label>
                    <textarea id="motivo" rows={3} value={motivo} onChange={e => setMotivo(e.target.value)}
                      placeholder={selected === "EM_REVISAO" ? "Ex.: rever o prazo de instalação e o número de parcelas." : "Opcional, mas ajuda muito."}
                      className="mt-1.5 w-full rounded-lg border border-zinc-300 bg-white px-3.5 py-2.5 text-sm text-zinc-900 placeholder:text-zinc-400 focus:border-zinc-900 focus:outline-none focus:ring-1 focus:ring-zinc-900" />
                  </div>
                )}

                {/* Aceitar exige confirmar o e-mail que recebeu a proposta.
                    O link é um endereço só: basta repassá-lo para outra pessoa
                    decidir no lugar do cliente. Não é criptografia — é o
                    bastante para o aceite partir de quem recebeu, e deixa
                    registro de quem confirmou. */}
                {selected === "ACEITA" && (
                  <div className="mt-4">
                    <label htmlFor="email-confirma" className="block text-sm font-medium text-zinc-800">
                      Confirme o e-mail que recebeu esta proposta
                    </label>
                    <input id="email-confirma" type="email" value={emailConfirma}
                      onChange={e => setEmailConfirma(e.target.value)}
                      placeholder="seu@email.com.br"
                      className="mt-1.5 w-full rounded-lg border border-zinc-300 bg-white px-3.5 py-2.5 text-sm text-zinc-900 placeholder:text-zinc-400 focus:border-zinc-900 focus:outline-none focus:ring-1 focus:ring-zinc-900" />
                    <p className="mt-1.5 text-[12px] text-zinc-500">
                      Só quem recebeu a proposta pode aceitá-la.
                    </p>
                  </div>
                )}

                {erroAcao && (
                  <p className="mt-3 rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-700">
                    {erroAcao}
                  </p>
                )}

                {/* Botão desabilitado sem dizer por quê é um beco: a lista de
                    marcar saiu daqui, então o aviso aponta para onde ela está. */}
                {selected && selected !== "RECUSADA" && escolhidos.length === 0 && (
                  <p className="mt-3 text-[13px] text-red-700">
                    Marque pelo menos um bloco da proposta, acima, para seguir.
                  </p>
                )}

                {selected && (
                  <button type="button"
                    onClick={() => handleAcao(
                      selected,
                      parcial ? escolhidos.filter(id => id !== BLOCO_SERVICO) : undefined,
                      !!blocoDeServico && !escolhidos.includes(BLOCO_SERVICO),
                    )}
                    disabled={submitting
                      /* Conferindo a tela do cliente: responder é dele. */
                      || espiarComoCliente
                      || (selected === "ACEITA" && !emailConfirma.trim())
                      || (selected !== "RECUSADA" && escolhidos.length === 0)}
                    className="mt-4 w-full rounded-lg bg-zinc-900 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-zinc-800 disabled:opacity-50 active:scale-[0.995]">
                    {submitting ? "Enviando" : "Confirmar resposta"}
                  </button>
                )}
              </div>
            )}
          </section>
          )}

          {/* O pedido do cliente, escrito por ele ao responder.
              Ficava só no kanban: a proposta era impressa para revisar e o
              que precisava mudar não estava na folha. */}
          {proposal.mensagem_cliente?.trim() && (
            <section className="evitar-quebra px-6 pt-8 sm:px-10">
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-zinc-400">
                Pedido do cliente
              </p>
              <div className="mt-2 rounded-xl border border-zinc-200 bg-zinc-50/70 px-5 py-4">
                <p className="whitespace-pre-wrap text-[13px] leading-relaxed text-zinc-700">
                  {proposal.mensagem_cliente.trim()}
                </p>
                {proposal.mensagem_cliente_em && (
                  <p className="mt-2 text-[11px] text-zinc-400">
                    Recebido em {new Date(proposal.mensagem_cliente_em).toLocaleDateString("pt-BR", {
                      day: "2-digit", month: "2-digit", year: "numeric",
                    })}
                  </p>
                )}
              </div>
            </section>
          )}

          {/* Rodapé. Sem área de assinatura e sem mensagem de agradecimento:
              a resposta é dada pelos botões acima, então a linha para assinar
              não tinha função e o agradecimento competia com eles. */}
          <footer className="px-6 pb-10 pt-8 sm:px-10">
            {/* Quem atendeu, o cliente precisa saber com quem falar. */}
            <div className="rounded-xl border border-zinc-200 bg-zinc-50/70 px-5 py-4">
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-zinc-400">
                Proposta desenvolvida por
              </p>
              <p className="mt-1.5 text-[15px] font-semibold text-zinc-900">{proposal.vendedor.nome}</p>
              <div className="mt-1.5 flex flex-col gap-1 text-[13px] text-zinc-600">
                {proposal.vendedor.telefone && (
                  <span className="flex items-center gap-1.5">
                    <Phone className="h-3.5 w-3.5 shrink-0 text-zinc-400" />
                    {formatarTelefone(proposal.vendedor.telefone)}
                  </span>
                )}
                <span className="flex items-center gap-1.5 break-all">
                  <Mail className="h-3.5 w-3.5 shrink-0 text-zinc-400" />
                  {proposal.vendedor.email}
                </span>
              </div>
            </div>

            <div className="mt-8 flex flex-col items-center gap-3 border-t border-zinc-200 pt-6 text-center">
              {logoDocumento ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={proxiedImg(logoDocumento, token)} alt={proposal.company.nome_empresa}
                  className="h-auto max-h-[70px] w-auto max-w-[210px] object-contain" />
              ) : (
                <p className="text-sm font-semibold text-zinc-700">{proposal.company.nome_empresa}</p>
              )}

            </div>
          </footer>
        </article>

        <div className="no-print mt-5 flex justify-center">
          <button type="button" onClick={() => window.print()}
            className="inline-flex items-center gap-2 rounded-lg border border-zinc-300 bg-white px-4 py-2.5 text-sm font-medium text-zinc-700 transition-colors hover:border-zinc-400 hover:text-zinc-900">
            <Printer className="h-4 w-4" /> Salvar em PDF
          </button>
        </div>
      </div>
    </Shell>
  )
}

/** Casca do documento: fundo claro fixo, independente do tema do app. */
function Shell({ children, accent = "#1f2937", confidencial = false }: {
  children: React.ReactNode; accent?: string; confidencial?: boolean
}) {
  return (
    <>
      <style>{`
        :root { --doc-accent: ${accent}; }
        /* Sem isto, o "dark theme forçado" de navegador mobile (Chrome/
           Samsung Internet no Android) reprocessa a cor de blocos que JÁ são
           escuros de propósito (.doc-ink) e lava o contraste do texto claro
           por cima — o "Total" ficava cinza-fantasma em vez de branco. Opt-out
           explícito: este documento é sempre claro, o app tem tema escuro,
           são coisas diferentes. */
        html { color-scheme: light; }
        .doc-band { clip-path: polygon(9% 0, 100% 0, 100% 100%, 0 100%); }

        /* Blocos de tinta escura: precisam sair no papel, não só na tela. */
        .doc-ink {
          background-color: #18181b;
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }
        /* Sombra que separa cada categoria do escopo. */
        .doc-card {
          border: 1px solid #ececee;
          box-shadow: 0 1px 2px rgba(16,18,24,.05), 0 12px 28px -18px rgba(16,18,24,.35);
        }
        .avoid-break { break-inside: avoid; page-break-inside: avoid; }

        /* Desestimula copiar o documento inteiro para fora: selecionar e colar
           num e-mail é o caminho mais curto para o orçamento circular.

           Não é proteção — quem quiser copia pelo código-fonte, fotografa a
           tela ou imprime. Serve para que repassar não seja o gesto acidental
           de sempre. Campos de digitação ficam de fora, senão o cliente não
           consegue preencher o e-mail de confirmação. */
        .doc-guard { -webkit-user-select: none; user-select: none; }
        .doc-guard input, .doc-guard textarea { -webkit-user-select: text; user-select: text; }
        /* Na impressão a seleção volta: o PDF salvo precisa ter texto
           selecionável, e é o caminho legítimo para compartilhar. */
        @media print { .doc-guard { -webkit-user-select: auto; user-select: auto; } }
        /* Só no papel: na tela os cartões interativos já mostram as condições. */
        .so-print { display: none; }
        .doc-prose h2 { font-size: 1.15rem; font-weight: 700; color: #18181b; margin: 1.4em 0 .5em; }
        .doc-prose h3 { font-size: 1rem; font-weight: 600; color: #18181b; margin: 1.2em 0 .4em; }
        .doc-prose p { margin: .7em 0; }
        .doc-prose strong { color: #18181b; font-weight: 600; }
        .doc-prose ul { list-style: disc; padding-left: 1.3em; margin: .7em 0; }
        .doc-prose ol { list-style: decimal; padding-left: 1.3em; margin: .7em 0; }
        .doc-prose li { margin: .3em 0; }
        .doc-prose a { color: var(--doc-accent); text-decoration: underline; }
        .doc-prose img { border-radius: .5rem; border: 1px solid #e4e4e7; margin: 1em 0; max-width: 100%; height: auto; }
        .doc-prose blockquote { border-left: 3px solid #e4e4e7; padding-left: 1em; color: #52525b; margin: 1em 0; }
        ${confidencial ? `
        .confidencial-stamp {
          position: fixed; top: 50%; left: 50%;
          transform: translate(-50%,-50%) rotate(-28deg);
          font-size: 5rem; font-weight: 900; color: rgba(24,24,27,.05);
          letter-spacing: .3em; pointer-events: none; z-index: 40;
          white-space: nowrap; user-select: none;
        }` : ""}
        /* Margem generosa: 12mm deixava o conteúdo colado na borda da folha,
           enquanto no link a folha respira dentro do fundo cinza. 18mm nas
           laterais dá a mesma sensação no papel sem custar uma página a mais. */
        @page { size: A4; margin: 16mm 18mm; }
        @media print {
          /* Só os blocos de tinta pedem cor exata. Aplicar em "*" fazia o fundo
             escuro do app imprimir e virar uma moldura preta em volta da folha. */
          .doc-ink, .doc-band, .doc-card, img {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          html, body, .doc-shell, .doc-sheet, article, section, header, footer {
            background-color: #fff !important;
            -webkit-print-color-adjust: economy;
            print-color-adjust: economy;
          }
          .no-print, .confidencial-stamp, .marca-escolha { display: none !important; }
          /* O anel e o respiro do bloco clicável são interface: no papel eles
             viravam uma moldura solta em volta de cada sistema e, com o
             break-inside, empurravam meia folha em branco. */
          .bloco-escolha {
            box-shadow: none !important;
            background: transparent !important;
            padding: 0 !important;
          }
          .so-print { display: block !important; }
          /* No papel vale a tabela: a lista de cartões é só para tela estreita. */
          .doc-scroll { display: block !important; }
          .escopo-cartoes { display: none !important; }
          .doc-shell { min-height: 0 !important; }
          .doc-sheet {
            box-shadow: none !important;
            border-radius: 0 !important;
            max-width: none !important;
          }
          /* No papel a sombra some, e sem ela os blocos de ambiente ficavam
             colados um no outro. A borda cinza clara faz essa divisão. */
          .doc-card {
            box-shadow: none !important;
            border-color: #e4e4e7 !important;
          }
          /* Respiro entre um ambiente e o próximo, e o ambiente inteiro numa
             folha só. Um sistema de três itens saía partido ao meio pela
             borda da página, com o nome e uma linha numa folha e as outras
             duas na seguinte. O navegador ignora isto sozinho quando o bloco
             é mais alto que uma página, e aí parte como antes. */
          .doc-scroll-inner > div,
          .evitar-quebra { break-inside: avoid; page-break-inside: avoid; }
          .doc-scroll-inner > div { margin-bottom: 10mm; }
          /* O nome do ambiente não fica sozinho no pé da página com a tabela
             dele na folha seguinte. break-after: avoid empurra o título
             junto; as duas linhas seguintes vão com ele por orphans/widows,
             senão o título ganhava a companhia de uma linha só. */
          .ambiente-titulo {
            break-after: avoid; page-break-after: avoid;
            break-inside: avoid; page-break-inside: avoid;
          }
          /* overflow: hidden (o arredondado do cartão) impede o navegador de
             partir a tabela: em vez de continuar na próxima folha, ele joga o
             cartão inteiro pra frente e deixa meia página em branco. No papel
             não há canto arredondado a proteger. */
          .doc-card { overflow: visible !important; }
          table { orphans: 2; widows: 2; }
          tbody tr:first-child { break-before: avoid; page-break-before: avoid; }
          /* O resumo do pagamento não pode ficar órfão no fim da página, com
             as parcelas sozinhas na folha seguinte. */
          .pagamento-bloco { break-inside: avoid; page-break-inside: avoid; }
          /* A tabela rola no celular; no papel tem que caber inteira. */
          .doc-scroll { overflow: visible !important; margin: 0 !important; padding: 0 !important; }
          .doc-scroll-inner { min-width: 0 !important; }
          .print-break { break-before: page; page-break-before: always; }
          thead { display: table-header-group; }
          /* Só o que cabe numa página pede pra não quebrar. "section" estava
             aqui e a seção de escopo é maior que uma folha inteira: o navegador
             empurrava tudo pra próxima página e deixava a primeira em branco. */
          tr, img, figure { break-inside: avoid; page-break-inside: avoid; }
          .doc-prose img { max-height: 220mm; }
        }
      `}</style>
      <div className="doc-shell doc-guard min-h-[100dvh] bg-zinc-100 text-zinc-900">{children}</div>
    </>
  )
}

/**
 * Portão do link: pede o e-mail, manda um código, troca o código por acesso.
 *
 * Duas etapas na mesma tela porque são o mesmo gesto do ponto de vista de quem
 * abre — "provar que sou eu" — e uma navegação entre páginas só daria chance de
 * perder o código já digitado.
 */
function PortaoAcesso({ token, aoLiberar }: { token: string; aoLiberar: () => void }) {
  const [etapa, setEtapa] = useState<"email" | "codigo">("email")
  const [email, setEmail] = useState("")
  const [codigo, setCodigo] = useState("")
  const [erro, setErro] = useState("")
  const [aviso, setAviso] = useState("")
  const [enviando, setEnviando] = useState(false)

  async function chamar(corpo: Record<string, string>) {
    setEnviando(true); setErro("")
    try {
      const r = await fetch(`/api/p/${token}/acesso`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(corpo),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { setErro(j.error || "Não foi possível continuar."); return null }
      return j
    } catch {
      setErro("Falha de conexão. Tente de novo.")
      return null
    } finally { setEnviando(false) }
  }

  async function pedirCodigo() {
    const j = await chamar({ email })
    if (!j) return
    setAviso(j.aviso ?? "")
    setEtapa("codigo")
  }

  async function confirmar() {
    const j = await chamar({ codigo })
    if (j?.ok) aoLiberar()
  }

  /* Campo claro dito com todas as letras (fundo, texto e placeholder). Sem
     isso o controle herda o tema escuro de quem abre no celular e o e-mail
     digitado saía cinza sobre cinza. */
  const campo = "w-full rounded-xl border border-zinc-300 bg-white text-zinc-900 "
    + "placeholder:text-zinc-400 outline-none transition-colors "
    + "focus:border-zinc-900 focus:ring-2 focus:ring-zinc-900/10"

  return (
    <Shell>
      <div className="flex min-h-[100dvh] items-center justify-center px-5 py-12">
        <div className="w-full max-w-[400px] rounded-[28px] border border-zinc-200 bg-white p-8
                        shadow-[0_1px_2px_rgba(16,18,24,.04),0_24px_56px_-28px_rgba(16,18,24,.35)]">
          {/* Marca da casa: o cliente chegou por um e-mail e precisa reconhecer
              de quem é a tela antes de digitar o endereço dele. */}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/brand/logo-completo.png" alt="Controllares" className="mb-7 h-9 w-auto" />

          <div className="mb-5 inline-flex h-10 w-10 items-center justify-center rounded-full bg-zinc-100">
            <ShieldCheck className="h-5 w-5 text-zinc-500" strokeWidth={1.75} />
          </div>

          <h1 className="text-[22px] font-semibold tracking-tight text-zinc-900">
            {etapa === "email" ? "Confirme que é você" : "Digite o código"}
          </h1>
          <p className="mt-2 text-[14px] leading-relaxed text-zinc-500">
            {etapa === "email"
              ? "Esta proposta é confidencial. Informe o e-mail que a recebeu e enviaremos um código de acesso."
              : aviso || "Enviamos um código de 6 dígitos para o seu e-mail."}
          </p>

          {etapa === "email" ? (
            <input
              type="email" value={email} inputMode="email" autoComplete="email" autoFocus
              onChange={e => setEmail(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && email) pedirCodigo() }}
              placeholder="seu@email.com"
              className={`${campo} mt-6 h-12 px-4 text-[15px]`}
            />
          ) : (
            <input
              value={codigo} inputMode="numeric" autoComplete="one-time-code" maxLength={6} autoFocus
              onChange={e => setCodigo(e.target.value.replace(/\D/g, ""))}
              onKeyDown={e => { if (e.key === "Enter" && codigo.length === 6) confirmar() }}
              placeholder="000000"
              className={`${campo} mt-6 h-14 text-center font-mono text-[26px] font-semibold tracking-[.35em]`}
            />
          )}

          {erro && (
            <p className="mt-3 rounded-xl border border-red-200 bg-red-50 px-3.5 py-2.5 text-[13px] text-red-700">
              {erro}
            </p>
          )}

          <button
            onClick={etapa === "email" ? pedirCodigo : confirmar}
            disabled={enviando || (etapa === "email" ? !email : codigo.length !== 6)}
            className="mt-4 h-12 w-full rounded-xl bg-zinc-900 text-[15px] font-semibold text-white
                       transition-colors hover:bg-zinc-800 disabled:opacity-40 active:scale-[0.995]">
            {enviando ? "Aguarde..." : etapa === "email" ? "Enviar código" : "Abrir proposta"}
          </button>

          {etapa === "codigo" && (
            <button
              onClick={() => { setEtapa("email"); setCodigo(""); setErro("") }}
              className="mt-3 w-full text-[13px] text-zinc-500 underline underline-offset-2 hover:text-zinc-800">
              Usar outro e-mail
            </button>
          )}

          <p className="mt-7 border-t border-zinc-100 pt-5 text-[12px] leading-relaxed text-zinc-400">
            O código vale por 20 minutos. Encaminhar este link não dá acesso a mais
            ninguém, é preciso receber o código na caixa de e-mail do contratante.
          </p>
        </div>
      </div>
    </Shell>
  )
}
