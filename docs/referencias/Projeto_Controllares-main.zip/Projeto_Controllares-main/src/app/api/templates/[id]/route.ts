import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params

  const template = await prisma.proposalTemplate.findFirst({
    where: { id, companyId: session.companyId },
    include: { autor: { select: { nome: true, email: true } } }
  })

  if (!template) return NextResponse.json({ error: "Template não encontrado" }, { status: 404 })

  return NextResponse.json(template)
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const { nome } = await req.json()

  if (!nome?.trim()) return NextResponse.json({ error: "Nome é obrigatório" }, { status: 400 })

  const existing = await prisma.proposalTemplate.findFirst({
    where: { id, companyId: session.companyId }
  })
  if (!existing) return NextResponse.json({ error: "Template não encontrado" }, { status: 404 })

  const updated = await prisma.proposalTemplate.update({
    where: { id },
    data: { nome: nome.trim() },
    include: { autor: { select: { nome: true, email: true } } }
  })

  return NextResponse.json(updated)
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params

  const existing = await prisma.proposalTemplate.findFirst({
    where: { id, companyId: session.companyId }
  })
  if (!existing) return NextResponse.json({ error: "Template não encontrado" }, { status: 404 })

  await prisma.proposalTemplate.delete({ where: { id } })

  return NextResponse.json({ success: true })
}
