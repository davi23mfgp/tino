import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const templates = await prisma.proposalTemplate.findMany({
    where: { companyId: session.companyId },
    include: { autor: { select: { nome: true, email: true } } },
    orderBy: { createdAt: "desc" }
  })

  // Categorias presentes no template — badges pra ajudar a escolher qual reaproveitar.
  const todasCategoryIds = new Set<string>()
  for (const t of templates) {
    const estrutura = t.estrutura as { environments?: { proposalItems?: { categoryId?: string | null }[] }[] } | null
    for (const env of estrutura?.environments ?? []) {
      for (const item of env.proposalItems ?? []) {
        if (item.categoryId) todasCategoryIds.add(item.categoryId)
      }
    }
  }
  const categorias = todasCategoryIds.size
    ? await prisma.category.findMany({ where: { id: { in: [...todasCategoryIds] } }, select: { id: true, nome: true } })
    : []
  const catNome = new Map(categorias.map(c => [c.id, c.nome]))

  const templatesComCategorias = templates.map(t => {
    const estrutura = t.estrutura as { environments?: { proposalItems?: { categoryId?: string | null }[] }[] } | null
    const ids = new Set<string>()
    for (const env of estrutura?.environments ?? []) {
      for (const item of env.proposalItems ?? []) {
        if (item.categoryId) ids.add(item.categoryId)
      }
    }
    return { ...t, categorias: [...ids].map(id => catNome.get(id)).filter(Boolean) as string[] }
  })

  return NextResponse.json({ templates: templatesComCategorias })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Só Admin e Financeiro criam modelos." }, { status: 403 })
  }

  const body = await req.json()
  const { nome, estrutura, proposalId } = body

  if (!nome) return NextResponse.json({ error: "Nome é obrigatório" }, { status: 400 })

  let estruturaFinal = estrutura

  /* Modelo tirado de uma proposta que já existe.
   *
   * Leva a proposta inteira MENOS a identificação do cliente: nome, e-mail e
   * cidade ficam de fora de propósito — é o que faz dela um modelo e não uma
   * cópia.
   *
   * Tudo que é decisão comercial vem junto, porque é aí que está o trabalho:
   * os serviços com a composição inteira, o desconto, as formas de pagamento
   * oferecidas, a garantia. Antes a foto pegava só ambientes e itens, então
   * quem aplicava o modelo remontava a parte comercial na mão toda vez — e o
   * modelo servia para menos da metade do que tinha sido montado.
   *
   * Fica de fora também o que é vida da proposta original: número, status,
   * token do link, datas de abertura, contrato, Olist. Modelo é ponto de
   * partida, não histórico.
   */
  if (proposalId && !estrutura) {
    const proposal = await prisma.proposal.findFirst({
      where: { id: proposalId, companyId: session.companyId },
      include: {
        environments: { include: { proposalItems: true } },
        extraPages: true,
      }
    })
    if (proposal) {
      estruturaFinal = {
        project_type: proposal.project_type,
        environments: proposal.environments,
        extraPages: proposal.extraPages,

        // Serviços com nome, tipo, valor e sobre o que cada um incide.
        servicos_detalhe: proposal.servicos_detalhe ?? null,

        // Condições comerciais.
        desconto_aplicado: proposal.desconto_aplicado ?? null,
        condicoes_pagamento: proposal.condicoes_pagamento ?? null,
        formas_oferecidas: proposal.formas_oferecidas ?? null,
        payment_methods: proposal.payment_methods ?? null,
        personalizado_recado: proposal.personalizado_recado ?? null,
        dias_garantia: proposal.dias_garantia ?? null,
        exibir_valor_unitario: proposal.exibir_valor_unitario,
      }
    }
  }

  const template = await prisma.proposalTemplate.create({
    data: {
      nome,
      estrutura: estruturaFinal || {},
      companyId: session.companyId,
      createdBy: session.userId,
    }
  })

  return NextResponse.json(template, { status: 201 })
}
