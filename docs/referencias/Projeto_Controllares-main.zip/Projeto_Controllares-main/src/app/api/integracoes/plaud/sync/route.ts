import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { ehVendedorRestrito } from "@/lib/perfil"
import { sincronizarPlaud } from "@/lib/plaud-sync"

export const dynamic = "force-dynamic"
export const maxDuration = 60

/**
 * Busca gravações novas.
 *
 * POST com `{ forcar: true }` é o botão "buscar agora"; sem isso respeita o
 * intervalo mínimo, porque esta rota também é chamada quando alguém abre a tela
 * de propostas — e a tela abre muitas vezes por hora.
 *
 * Não é restrita ao Admin: quem grava a reunião é o vendedor, e esperar o Admin
 * mandar buscar anularia o ganho de tempo.
 */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (ehVendedorRestrito(session)) {
    return NextResponse.json({ error: "Sem acesso." }, { status: 403 })
  }

  const { forcar } = await req.json().catch(() => ({}))
  const r = await sincronizarPlaud(session.companyId, { forcar: !!forcar })

  if (r.novas > 0) {
    await prisma.aiAuditLog.create({
      data: {
        userId: session.userId, companyId: session.companyId, tipo_acesso: "CRIAR",
        descricao: `Plaud: ${r.novas} reunião(ões) baixada(s)`,
      },
    }).catch(() => {})
  }

  return NextResponse.json(r)
}
