import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { configurarWebhook, verificarWebhook, tokenDaEmpresa } from "@/lib/telegram"

/** GET /api/integracoes/telegram/grupos — grupos vistos pelo bot. */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const grupos = await prisma.telegramGrupo.findMany({
    where: { companyId: session.companyId, ativo: true },
    orderBy: { createdAt: "desc" },
    select: {
      id: true, chatId: true, titulo: true, automatico: true, createdAt: true,
      obra: { select: { id: true, client_name: true } },
    },
  })

  const company = await prisma.company.findUnique({
    where: { id: session.companyId },
    select: { telegram_bot_token: true },
  })

  return NextResponse.json({
    grupos,
    botConfigurado: !!company?.telegram_bot_token,
    webhookConfigurado: !!process.env.TELEGRAM_WEBHOOK_SECRET,
  })
}

/**
 * POST /api/integracoes/telegram/grupos — ações do Admin.
 *   { acao: "vincular", grupoId, obraId }  → liga o grupo a uma obra
 *   { acao: "desvincular", grupoId }
 *   { acao: "registrar_webhook" }          → aponta o bot para a nossa rota
 */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin configura os grupos." }, { status: 403 })
  }

  const body = await req.json().catch(() => ({}))
  const acao = String(body.acao ?? "")

  if (acao === "registrar_webhook") {
    const token = await tokenDaEmpresa(session.companyId)
    if (!token) {
      return NextResponse.json({ error: "Configure o token do bot antes." }, { status: 422 })
    }
    const segredo = process.env.TELEGRAM_WEBHOOK_SECRET
    if (!segredo) {
      return NextResponse.json(
        { error: "Falta TELEGRAM_WEBHOOK_SECRET no ambiente — é o que autentica o Telegram na nossa rota." },
        { status: 422 },
      )
    }
    /* O endereço sai de ONDE ESTA REQUISIÇÃO CHEGOU, não de APP_URL.

       APP_URL aponta para o domínio da Vercel, que responde 307 redirecionando
       para o domínio próprio — e o Telegram NÃO segue redirecionamento. O
       webhook ficava registrado num endereço que devolvia 307, nenhum update
       chegava, e quem mandava /start no bot não era vinculado a nada. O
       sintoma era "o Telegram não manda notificação".

       A origem da requisição é o domínio em que o Admin está navegando: por
       definição, um endereço que responde sem redirecionar. APP_URL continua
       valendo para os callbacks de OAuth, que estão registrados com ele. */
    const origem = new URL(req.url).origin
    const appUrl = origem.startsWith("https://") ? origem : process.env.APP_URL
    if (!appUrl?.startsWith("https://")) {
      return NextResponse.json(
        { error: "O Telegram só aceita webhook em HTTPS. Abra o sistema pelo domínio com HTTPS e tente de novo." },
        { status: 422 },
      )
    }

    const r = await configurarWebhook(token, `${appUrl}/api/integracoes/telegram/webhook`, segredo)
    if (!r.ok) return NextResponse.json({ error: `Telegram recusou: ${r.erro}` }, { status: 502 })

    /* Confere se o Telegram consegue MESMO entregar no endereço registrado.
       O setWebhook responde "ok" sem testar nada — foi assim que o 307 passou
       despercebido por semanas. Aqui uma chamada de teste força o erro a
       aparecer agora, com o motivo escrito, em vez de virar silêncio. */
    const info = await verificarWebhook(token)
    if (info.erro) {
      return NextResponse.json({
        error: `Webhook registrado em ${appUrl}, mas o Telegram não conseguiu entregar: ${info.erro}.`
          + " Confira se este domínio responde sem redirecionar.",
      }, { status: 502 })
    }

    return NextResponse.json({ ok: true, url: info.url })
  }

  const grupo = await prisma.telegramGrupo.findFirst({
    where: { id: String(body.grupoId ?? ""), companyId: session.companyId },
    select: { id: true, chatId: true, obraId: true },
  })
  if (!grupo) return NextResponse.json({ error: "Grupo não encontrado." }, { status: 404 })

  if (acao === "desvincular") {
    await prisma.$transaction(async tx => {
      if (grupo.obraId) {
        await tx.obra.update({ where: { id: grupo.obraId }, data: { telegram_chat_id: null } })
      }
      await tx.telegramGrupo.update({
        where: { id: grupo.id },
        data: { obraId: null, automatico: false },
      })
    })
    return NextResponse.json({ ok: true })
  }

  if (acao === "vincular") {
    const obra = await prisma.obra.findFirst({
      where: { id: String(body.obraId ?? ""), companyId: session.companyId },
      select: { id: true },
    })
    if (!obra) return NextResponse.json({ error: "Obra não encontrada." }, { status: 404 })

    await prisma.$transaction(async tx => {
      // Uma obra tem um grupo: solta o vínculo anterior para não ficarem dois
      // grupos mandando o mesmo conteúdo.
      await tx.telegramGrupo.updateMany({
        where: { companyId: session.companyId, obraId: obra.id },
        data: { obraId: null, automatico: false },
      })
      await tx.telegramGrupo.update({
        where: { id: grupo.id },
        data: { obraId: obra.id, automatico: false },
      })
      await tx.obra.update({ where: { id: obra.id }, data: { telegram_chat_id: grupo.chatId } })
    })
    return NextResponse.json({ ok: true })
  }

  return NextResponse.json({ error: "Ação inválida." }, { status: 400 })
}
