import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { ensureOlistToken, OLIST_API_BASE, OLIST_PATHS } from "@/lib/olist"
import { avaliarDuplicidade, type Candidato, type Veredito } from "@/lib/similaridade"

export const dynamic = "force-dynamic"

interface ProdutoOlist {
  id: string | number
  descricao?: string
  nome?: string
  codigo?: string
  sku?: string
}

/** Busca por um termo na API v3 (OAuth). */
async function buscarV3(token: string, termo: string): Promise<Candidato[]> {
  if (!termo.trim()) return []
  const url = `${OLIST_API_BASE}${OLIST_PATHS.produtos}?nome=${encodeURIComponent(termo.trim())}&limit=25`
  const r = await fetch(url, {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
    cache: "no-store",
  })
  if (!r.ok) return []
  const j = await r.json().catch(() => null)
  const lista: ProdutoOlist[] = Array.isArray(j) ? j : (j?.itens ?? j?.data ?? [])
  return lista.map(p => ({
    id: String(p.id),
    nome: p.descricao ?? p.nome ?? "",
    sku: p.codigo ?? p.sku ?? null,
  })).filter(c => c.nome)
}

/** Mesma busca pela v2, que usa só o token simples da empresa. */
async function buscarV2(token: string, termo: string): Promise<Candidato[]> {
  if (!termo.trim()) return []
  const form = new URLSearchParams()
  form.append("token", token)
  form.append("formato", "json")
  form.append("pesquisa", termo.trim())
  const r = await fetch("https://api.tiny.com.br/api2/produtos.pesquisa.php", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: form.toString(),
    signal: AbortSignal.timeout(20_000),
  }).catch(() => null)
  if (!r) return []
  const j = await r.json().catch(() => null) as
    { retorno?: { produtos?: { produto?: { id?: string; nome?: string; codigo?: string } }[] } } | null
  return (j?.retorno?.produtos ?? [])
    .map(x => ({
      id: String(x.produto?.id ?? ""),
      nome: x.produto?.nome ?? "",
      sku: x.produto?.codigo ?? null,
    }))
    .filter(c => c.nome)
}

/**
 * POST /api/integracoes/olist/produtos/verificar   { proposalId }
 *
 * Confere, item a item da proposta, se o produto já existe no Olist antes de
 * cadastrar. Cadastrar sem conferir enche o Olist do mesmo produto escrito de
 * jeitos diferentes, e depois o estoque fica dividido entre os clones.
 *
 * A rota NÃO cadastra nada: só classifica. Nome parecido volta como "parecido"
 * para uma pessoa decidir — "Módulo X-2" e "Módulo X-4" batem 96% de
 * semelhança e são produtos diferentes.
 */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Sem permissão para integrar com o Olist." }, { status: 403 })
  }

  const { proposalId } = await req.json().catch(() => ({}))
  if (!proposalId) return NextResponse.json({ error: "proposalId obrigatório" }, { status: 400 })

  const proposal = await prisma.proposal.findFirst({
    where: { id: proposalId, companyId: session.companyId },
    include: {
      environments: {
        include: { proposalItems: { include: { product: true, kit: true } } },
      },
    },
  })
  if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  /* Dois caminhos, porque a empresa pode ter só um configurado: v3 quando a
     integração foi autorizada por OAuth, v2 quando só existe o token simples —
     que é o mesmo por onde o pedido já é enviado. Exigir v3 aqui travava o
     envio inteiro com "Olist não conectado" em quem só preencheu o token. */
  const empresa = await prisma.company.findUnique({
    where: { id: session.companyId },
    select: { tiny_api_token: true },
  })
  let tokenV3: string | null = null
  try {
    tokenV3 = await ensureOlistToken(session.companyId)
  } catch {
    tokenV3 = null
  }
  const tokenV2 = empresa?.tiny_api_token ?? null

  if (!tokenV3 && !tokenV2) {
    return NextResponse.json(
      { error: "Olist não configurado. Preencha o token em Configurações → Integrações." },
      { status: 422 },
    )
  }

  // Produtos distintos da proposta (o mesmo item pode repetir em ambientes).
  const porSku = new Map<string, { nome: string; sku: string | null }>()
  for (const env of proposal.environments) {
    for (const item of env.proposalItems) {
      const nome = item.product?.nome ?? item.kit?.nome ?? item.nome_snapshot ?? ""
      const sku = item.product?.sku ?? item.sku_snapshot ?? null
      if (!nome) continue
      porSku.set(sku || nome, { nome, sku })
    }
  }

  const resultados: (Veredito & { nome: string; sku: string | null })[] = []
  for (const p of porSku.values()) {
    // Duas buscas: pelo código (identificador) e pelo nome. O Olist não tem
    // endpoint de "buscar exato", então filtramos do lado de cá.
    const buscar = (termo: string) =>
      tokenV3 ? buscarV3(tokenV3, termo) : buscarV2(tokenV2!, termo)
    const candidatos = [
      ...(p.sku ? await buscar(p.sku) : []),
      ...await buscar(p.nome),
    ]
    // Remove repetidos entre as duas buscas.
    const unicos = [...new Map(candidatos.map(c => [c.id, c])).values()]
    resultados.push({ ...avaliarDuplicidade(p, unicos), nome: p.nome, sku: p.sku })
  }

  return NextResponse.json({
    total: resultados.length,
    exatos: resultados.filter(r => r.tipo === "exato").length,
    parecidos: resultados.filter(r => r.tipo === "parecido"),
    novos: resultados.filter(r => r.tipo === "novo").length,
    itens: resultados,
  })
}
