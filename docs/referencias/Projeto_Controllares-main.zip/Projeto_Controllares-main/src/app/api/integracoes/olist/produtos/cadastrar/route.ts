import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { olistFetch, OLIST_PATHS } from "@/lib/olist"
import { chamarV2, ErroOlist, ehDuplicidade, pausa, INTERVALO_MS } from "@/lib/olist-v2"

export const dynamic = "force-dynamic"

/**
 * POST /api/integracoes/olist/produtos/cadastrar   { proposalId, skus?: string[] }
 *
 * Cria no Olist o que a proposta vende e ainda não existe lá.
 *
 * Duas coisas separam produto de serviço, e o Olist as guarda em cadastros
 * diferentes: item com produto do catálogo vai para /produtos; item que veio
 * dos serviços pré-definidos da categoria (sem productId) vai para /servicos.
 * Misturar os dois faz instalação virar item de estoque, com saldo a repor.
 *
 * Dois caminhos de API, porque a empresa pode ter só um conectado:
 *  — v3 (OAuth), quando a integração foi autorizada em Configurações;
 *  — v2 (token simples), o mesmo caminho por onde o pedido já é enviado.
 * A primeira versão exigia v3 e falhava com "Olist não conectado" mesmo com o
 * pedido chegando lá pela v2 — que é o caso de quem só preencheu o token.
 */
interface Achado { codigo?: string; sku?: string }
interface Item {
  codigo: string; nome: string; servico: boolean; produto?: ProdutoCatalogo
  /* Preço que vai para o Olist. Sai do catálogo; quando o catálogo está
     zerado, sai do valor combinado NESTA proposta. */
  preco: number
}
type ProdutoCatalogo = {
  sku: string; nome: string; marca: string | null; unidade: string | null
  gtin: string | null; ncm: string | null; cest: string | null; origem: string | null
  preco_venda: unknown; preco_custo: unknown; descricao: string | null
  peso_kg: number | null; garantia_dias: number | null; estoque_qtd: number | null
}

const num = (v: unknown) => Number(v ?? 0)

/* ── API v2: um POST form-urlencoded por recurso ───────────────────────────
   Serviço não tem endpoint próprio na v2: entra em produto.incluir com
   tipo "S", que é como o Olist representa serviço nesse cadastro. */
async function incluirV2(token: string, item: Item): Promise<void> {
  const p = item.produto
  const corpo = {
    produtos: [{
      produto: {
        sequencia: 1,
        codigo: item.codigo,
        nome: item.nome,
        tipo: item.servico ? "S" : "P",
        situacao: "A",
        unidade: p?.unidade || (item.servico ? "SV" : "UN"),
        preco: item.preco,
        ...(p ? { preco_custo: num(p.preco_custo) } : {}),
        ...(p?.ncm ? { ncm: p.ncm } : {}),
        ...(p?.cest ? { cest: p.cest } : {}),
        /* Origem é OBRIGATÓRIA no cadastro — sem ela a API responde
           "A origem do produto deve ser informada" e nada entra. O catálogo
           daqui quase nunca tem esse campo, então o padrão é 0 (nacional),
           que é o caso da esmagadora maioria. Quem importa direto corrige no
           cadastro do produto e o valor passa a vir daqui. */
        origem: p?.origem || "0",
        ...(p?.gtin ? { gtin: p.gtin } : {}),
        ...(p?.marca ? { marca: p.marca } : {}),
        ...(p?.descricao ? { descricao_complementar: p.descricao } : {}),
        ...(p?.garantia_dias ? { garantia: `${p.garantia_dias} dias` } : {}),
        ...(p?.peso_kg != null ? { peso_liquido: p.peso_kg, peso_bruto: p.peso_kg } : {}),
      },
    }],
  }

  /* Passou a usar o cliente compartilhado da v2: ele já lê as duas formas em
     que a API aninha mensagem de erro e marca bloqueio por excesso de acessos,
     que é o que a versão local desta rota não distinguia. */
  await chamarV2(token, "produto.incluir.php", { produto: JSON.stringify(corpo) })
}

/** Já existe lá? Consulta pelo código nos dois cadastros conforme o tipo. */
async function existeV2(token: string, codigo: string): Promise<boolean> {
  const ret = await chamarV2(token, "produtos.pesquisa.php", { pesquisa: codigo })
    .catch(() => null)
  const lista = (ret?.produtos ?? []) as { produto?: { codigo?: string } }[]
  return lista.some(x => x.produto?.codigo === codigo)
}

/* ── API v3 ────────────────────────────────────────────────────────────── */
async function existeV3(companyId: string, item: Item): Promise<boolean> {
  const caminho = item.servico ? "/servicos" : OLIST_PATHS.produtos
  const r = await olistFetch<unknown>(
    companyId, `${caminho}?codigo=${encodeURIComponent(item.codigo)}&limit=5`,
  ).catch(() => null)
  const lista: Achado[] = Array.isArray(r)
    ? r
    : ((r as { itens?: Achado[] })?.itens ?? [])
  return lista.some(x => String(x.codigo ?? x.sku ?? "") === item.codigo)
}

async function incluirV3(companyId: string, item: Item): Promise<void> {
  const p = item.produto

  if (item.servico) {
    await olistFetch(companyId, "/servicos", {
      method: "POST",
      body: JSON.stringify({
        nome: item.nome,
        codigo: item.codigo,
        preco: item.preco,
        unidade: p?.unidade || "SV",
        situacao: "A",
        tipoItemSped: "09",           // 09 = Serviços
      }),
    })
    return
  }

  /* Corpo conforme CriarProdutoRequestModel: `tipo` e `descricao` obrigatórios.
     Preço e custo vão dentro de `precos`; ncm, gtin, origem e CEST ficam na
     raiz (`tributacao` só aceita IPI); `marca` espera { id } de marca já
     cadastrada, por isso o nome dela vai no complemento da descrição. */
  const complemento = [p?.marca ? `Marca: ${p.marca}` : null, p?.descricao]
    .filter(Boolean).join("\n")

  await olistFetch(companyId, OLIST_PATHS.produtos, {
    method: "POST",
    body: JSON.stringify({
      tipo: "S",
      descricao: item.nome,
      sku: item.codigo,
      unidade: p?.unidade || "UN",
      precos: { preco: item.preco, precoCusto: num(p?.preco_custo) },
      ...(complemento ? { descricaoComplementar: complemento } : {}),
      ...(p?.gtin ? { gtin: p.gtin } : {}),
      ...(p?.ncm ? { ncm: p.ncm } : {}),
      ...(p?.cest ? { codigoEspecificadorSubstituicaoTributaria: p.cest } : {}),
      // Mesma regra da v2: origem é exigida, e 0 = nacional é o padrão.
      origem: Number(p?.origem ?? 0),
      ...(p?.garantia_dias ? { garantia: `${p.garantia_dias} dias` } : {}),
      ...(p?.peso_kg != null ? { dimensoes: { pesoLiquido: p.peso_kg, pesoBruto: p.peso_kg } } : {}),
      // Sem saldo de abertura o produto nasce zerado e o primeiro pedido já
      // sai com estoque negativo.
      ...(p?.estoque_qtd != null ? { estoque: { inicial: p.estoque_qtd } } : {}),
    }),
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Sem permissão para integrar com o Olist." }, { status: 403 })
  }

  const { proposalId, skus } = await req.json().catch(() => ({}))
  if (!proposalId) return NextResponse.json({ error: "proposalId obrigatório" }, { status: 400 })
  const filtro: Set<string> | null = Array.isArray(skus) && skus.length ? new Set(skus.map(String)) : null

  const [proposal, empresa] = await Promise.all([
    prisma.proposal.findFirst({
      where: { id: proposalId, companyId: session.companyId },
      include: { environments: { include: { proposalItems: { include: { product: true } } } } },
    }),
    prisma.company.findUnique({
      where: { id: session.companyId },
      select: { tiny_api_token: true, olist_access_token: true },
    }),
  ])
  if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  const usarV3 = !!empresa?.olist_access_token
  const tokenV2 = empresa?.tiny_api_token
  if (!usarV3 && !tokenV2) {
    return NextResponse.json(
      { error: "Olist não configurado. Preencha o token em Configurações → Integrações ou conecte pelo OAuth." },
      { status: 422 },
    )
  }

  /* Um item pode repetir em vários ambientes — cadastra uma vez só. Serviço
     pré-definido não tem produto no catálogo: o código sai do nome, porque o
     Olist exige um identificador e não vale repetir o de outro item. */
  const itens = new Map<string, Item>()
  for (const env of proposal.environments) {
    for (const it of env.proposalItems) {
      const p = it.product
      const servico = !p

      /* PREÇO: catálogo primeiro, proposta como segunda fonte.

         O Olist recusa produto sem preço — "O preço do produto deve ser
         informado" —, e o catálogo tem mais de mil itens com preço de venda
         zerado, porque foram importados com custo e markup em branco. O envio
         morria no meio, depois de já ter cadastrado metade dos itens.

         O valor combinado na proposta não é chute: é o preço pelo qual aquele
         produto está sendo vendido, aprovado pelo cliente. Usar ele é mais
         verdadeiro que mandar zero, e o cadastro no Olist nasce com um número
         que alguém pode corrigir depois. */
      const precoCatalogo = Number(p?.preco_venda ?? 0)
      const preco = precoCatalogo > 0 ? precoCatalogo : Number(it.valor_unitario ?? 0)
      const nome = p?.nome ?? it.nome_snapshot ?? ""
      if (!nome) continue
      const codigo = p?.sku
        ?? it.sku_snapshot
        ?? `SRV-${nome.toUpperCase().normalize("NFD").replace(/[^A-Z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 24)}`
      if (filtro && !filtro.has(codigo)) continue
      itens.set(codigo, { codigo, nome, servico, produto: p ?? undefined, preco })
    }
  }
  if (!itens.size) return NextResponse.json({ criados: [], jaExistiam: [], falhas: [] })

  /* Sem preço em lugar nenhum, o Olist recusa e o envio para no meio — com
     parte dos produtos já cadastrada. Barrar aqui, ANTES da primeira chamada,
     devolve a lista inteira do que falta de uma vez, em vez de um erro por
     vez a cada tentativa. */
  const semPreco = [...itens.values()].filter(i => !(i.preco > 0))
  if (semPreco.length) {
    return NextResponse.json({
      error: `Sem preço para enviar ao Olist: ${semPreco.map(i => `${i.codigo} (${i.nome})`).join(", ")}.`
        + " Preencha o preço de venda no catálogo ou o valor na proposta.",
      semPreco: semPreco.map(i => ({ sku: i.codigo, nome: i.nome })),
    }, { status: 422 })
  }

  const criados: string[] = []
  const jaExistiam: string[] = []
  const falhas: { sku: string; erro: string }[] = []

  /* Respiro entre as chamadas, e só na v2: a API responde "API Bloqueada -
     Excedido o número de acessos" quando elas saem em rajada. Esta rota
     disparava duas por item (procura + cadastro) sem pausa nenhuma, e numa
     proposta grande os últimos itens batiam no teto — era o que fazia dois ou
     três produtos falharem no fim de um envio que ia bem até ali.

     Bloqueio não é defeito do registro: espera mais e tenta de novo uma vez,
     em vez de contar como falha um produto que nem chegou a ser avaliado. */
  const comEspera = async <T>(fn: () => Promise<T>): Promise<T> => {
    if (usarV3) return fn()
    await pausa(INTERVALO_MS)
    try {
      return await fn()
    } catch (e) {
      if (e instanceof ErroOlist && e.bloqueio) {
        await pausa(INTERVALO_MS * 5)
        return fn()
      }
      throw e
    }
  }

  for (const item of itens.values()) {
    try {
      /* Confere antes de criar. A verificação de duplicidade roda na tela, mas
         entre uma coisa e outra alguém pode ter cadastrado — e código repetido
         no Olist vira erro, não atualização. */
      const existe = usarV3
        ? await existeV3(session.companyId, item)
        : await comEspera(() => existeV2(tokenV2!, item.codigo))
      if (existe) { jaExistiam.push(item.codigo); continue }

      if (usarV3) await incluirV3(session.companyId, item)
      else await comEspera(() => incluirV2(tokenV2!, item))
      criados.push(item.codigo)
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Falha desconhecida"
      // "Registro em duplicidade" é o produto já estar lá — o efeito desejado.
      if (ehDuplicidade(msg)) { jaExistiam.push(item.codigo); continue }
      falhas.push({ sku: item.codigo, erro: msg })
    }
  }

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "CRIAR",
      descricao: `Olist (${usarV3 ? "v3" : "v2"}): ${criados.length} item(ns) cadastrado(s) da proposta ${proposal.numero}`
        + (falhas.length ? ` — ${falhas.length} falha(s)` : ""),
    },
  }).catch(() => {})

  return NextResponse.json({ criados, jaExistiam, falhas, via: usarV3 ? "v3" : "v2" })
}
