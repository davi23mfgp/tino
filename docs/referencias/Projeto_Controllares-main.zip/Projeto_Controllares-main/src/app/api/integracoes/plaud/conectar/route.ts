import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { temAlgumPerfil } from "@/lib/perfil"
import { guardarToken, obterConta } from "@/lib/plaud"

export const dynamic = "force-dynamic"

/**
 * Conecta a conta do Plaud a partir do token que o CLI oficial gerou.
 *
 * Não é OAuth aqui porque não pode ser: a plataforma que lê as gravações
 * pessoais não emite credencial para aplicações de terceiros — a aplicação
 * registrada é a do próprio CLI. Então o Admin roda `plaud login` uma vez, na
 * máquina dele, e traz o token para cá.
 *
 * Depois disso o CLI sai de cena: o token é um Bearer comum, e quem chama a API
 * passa a ser o servidor. É isso que tira a integração de um computador só.
 */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin conecta o Plaud." }, { status: 403 })
  }

  const corpo = await req.json().catch(() => ({}))

  /* Aceita o arquivo inteiro colado ou só os campos. O Admin vai copiar de
     `~/.plaud/tokens.json`, e exigir que ele recorte o JSON só criaria erro. */
  let bruto: Record<string, unknown> = corpo
  if (typeof corpo.tokens === "string") {
    try { bruto = JSON.parse(corpo.tokens) } catch {
      return NextResponse.json({ error: "O texto colado não é um JSON válido." }, { status: 400 })
    }
  }

  const access = String(bruto.access_token ?? "")
  const refresh = bruto.refresh_token ? String(bruto.refresh_token) : undefined
  const expira = Number(bruto.expires_at ?? 0) || undefined

  if (!access.startsWith("ey")) {
    return NextResponse.json({
      error: "Não achei o access_token. Cole o conteúdo de ~/.plaud/tokens.json,"
        + " gerado por `plaud login`.",
    }, { status: 400 })
  }

  /* Confere contra a API antes de guardar: token vencido ou de outra conta
     guardado sem teste vira falha silenciosa no primeiro cron, longe daqui. */
  let conta
  try {
    conta = await obterConta(access)
  } catch {
    return NextResponse.json({
      error: "O Plaud recusou este token. Rode `plaud login` de novo e cole o arquivo novo.",
    }, { status: 422 })
  }

  await guardarToken(session.companyId, {
    access_token: access, refresh_token: refresh, expires_at: expira,
  })

  return NextResponse.json({ ok: true, conta: { email: conta.email, nome: conta.nickname } })
}
