import { NextRequest, NextResponse } from "next/server"
import { exchangeOlistCode } from "@/lib/olist"

/**
 * GET /api/integracoes/olist/callback
 * Recebe o "code" do Olist, troca por tokens e salva na empresa (state = companyId).
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const code = searchParams.get("code")
  const companyId = searchParams.get("state")
  const error = searchParams.get("error")
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000"

  if (error || !code || !companyId) {
    return NextResponse.redirect(`${appUrl}/configuracoes?olist=erro`)
  }

  try {
    await exchangeOlistCode(code, companyId)
    return NextResponse.redirect(`${appUrl}/configuracoes?olist=conectado`)
  } catch {
    return NextResponse.redirect(`${appUrl}/configuracoes?olist=token-erro`)
  }
}
