import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"

export const dynamic = "force-dynamic"
export const maxDuration = 60

/**
 * Espelha o saldo de estoque daqui no Olist.
 *
 * A direção é uma só: Controllares manda, Olist recebe. Quem conta o material no
 * canteiro e registra entrada e saída é este sistema — o Olist guarda a cópia,
 * para o dia em que for preciso emitir nota ou conferir histórico.
 *
 * Ler o saldo de volta seria o caminho para os dois se sobrescreverem: o
 * Olist baixa estoque sozinho ao faturar um pedido, e essa baixa voltaria para
 * cá desfazendo a contagem de quem esteve na obra. Por isso a rota só escreve.
 *
 * O lançamento é do tipo "B" (balanço): define o saldo absoluto, não soma nem
 * subtrai. Uma reexecução deixa o mesmo número — pode rodar quantas vezes for.
 */
const API = "https://api.tiny.com.br/api2"

async function chamarV2(token: string, endpoint: string, extra: Record<string, string> = {}) {
  const form = new URLSearchParams({ token, formato: "json", ...extra })
  const r = await fetch(`${API}/${endpoint}`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: form.toString(),
    signal: AbortSignal.timeout(20_000),
  })
  const bruto = await r.text()
  try { return JSON.parse(bruto).retorno as Record<string, unknown> }
  catch { throw new Error(`Olist respondeu algo que não é JSON: ${bruto.slice(0, 150)}`) }
}

/** Mapa código → id do Olist. O lançamento de estoque exige o id, não o SKU. */
async function idsPorCodigo(token: string): Promise<Map<string, string>> {
  const mapa = new Map<string, string>()
  let pagina = 1
  let paginas = 1
  do {
    const ret = await chamarV2(token, "produtos.pesquisa.php", { pagina: String(pagina) })
    const lista = (ret?.produtos ?? []) as { produto?: { id?: string; codigo?: string } }[]
    for (const x of lista) {
      if (x.produto?.codigo && x.produto.id) mapa.set(x.produto.codigo, String(x.produto.id))
    }
    paginas = Number(ret?.numero_paginas ?? 1) || 1
    pagina++
  } while (pagina <= paginas && pagina <= 50)
  return mapa
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Sem permissão para integrar com o Olist." }, { status: 403 })
  }

  const empresa = await prisma.company.findUnique({
    where: { id: session.companyId },
    select: { tiny_api_token: true },
  })
  const token = empresa?.tiny_api_token
  if (!token) {
    return NextResponse.json(
      { error: "Preencha o token do Olist em Configurações → Integrações." }, { status: 422 })
  }

  const { skus } = await req.json().catch(() => ({}))
  const filtro: string[] | null = Array.isArray(skus) && skus.length ? skus.map(String) : null

  /* Só produtos com saldo controlado. Item sem contagem (estoque_qtd nulo) não
     é "zero" — é desconhecido, e mandar 0 zeraria um saldo correto lá. */
  const produtos = await prisma.catalogProduct.findMany({
    where: {
      companyId: session.companyId,
      status: "ATIVO",
      estoque_qtd: { not: null },
      ...(filtro ? { sku: { in: filtro } } : {}),
    },
    select: { sku: true, estoque_qtd: true },
    orderBy: { sku: "asc" },
  })
  if (!produtos.length) {
    return NextResponse.json({ enviados: [], semCadastro: [], falhas: [], total: 0 })
  }

  const ids = await idsPorCodigo(token)

  const enviados: { sku: string; saldo: number }[] = []
  const semCadastro: string[] = []
  const falhas: { sku: string; erro: string }[] = []

  for (const p of produtos) {
    const id = ids.get(p.sku)
    if (!id) {
      // Produto que ainda não foi espelhado: some do relatório de estoque, mas
      // não é erro — a tela de catálogo é quem resolve isso.
      semCadastro.push(p.sku)
      continue
    }
    try {
      const ret = await chamarV2(token, "produto.atualizar.estoque.php", {
        estoque: JSON.stringify({
          estoque: {
            idProduto: id,
            tipo: "B",
            quantidade: String(p.estoque_qtd ?? 0),
            observacoes: "Saldo espelhado do Controllares",
          },
        }),
      })
      if (ret?.status !== "OK") {
        const reg = ret?.registros as { registro?: { erros?: unknown[] } } | undefined
        const msgs = (reg?.registro?.erros ?? []).map(e =>
          typeof e === "string" ? e : String((e as { erro?: string })?.erro ?? ""))
        throw new Error(msgs.filter(Boolean).join(", ") || "erro sem detalhe")
      }
      enviados.push({ sku: p.sku, saldo: p.estoque_qtd ?? 0 })
    } catch (e) {
      falhas.push({ sku: p.sku, erro: e instanceof Error ? e.message : "falha desconhecida" })
    }
  }

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "EDITAR",
      descricao: `Olist: saldo de ${enviados.length} produto(s) espelhado`
        + (falhas.length ? ` — ${falhas.length} falha(s)` : ""),
    },
  }).catch(() => {})

  return NextResponse.json({ enviados, semCadastro, falhas, total: produtos.length })
}
