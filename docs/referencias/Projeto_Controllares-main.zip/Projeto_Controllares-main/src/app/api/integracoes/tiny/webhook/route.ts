import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

/**
 * POST /api/integracoes/tiny/webhook  (Bloco 2)
 * Callback do Tiny: quando o pedido é faturado, o Tiny chama esta rota.
 * Rota PÚBLICA (o Tiny não tem sessão). Identifica a proposta pelo
 * numero_pedido_ecommerce (= proposal.numero), registra no Debugger de
 * Webhooks e notifica o responsável. Sempre responde 200 para o Tiny não
 * reenfileirar indefinidamente.
 */
export async function POST(req: NextRequest) {
  // Segredo compartilhado na URL (?s=…) ou header. Sem ele, qualquer pessoa
  // na internet escreveria na nossa tabela de logs e sondaria quais números de
  // proposta existem. Enquanto TINY_WEBHOOK_SECRET não estiver definida a rota
  // segue aberta, para não derrubar uma integração já configurada — mas o
  // certo é definir.
  const segredo = process.env.TINY_WEBHOOK_SECRET
  if (segredo) {
    const enviado = new URL(req.url).searchParams.get("s") ?? req.headers.get("x-webhook-secret")
    if (enviado !== segredo) {
      return NextResponse.json({ ok: false }, { status: 401 })
    }
  }

  let raw: unknown = null
  try {
    raw = await req.json()
  } catch {
    // Tiny pode mandar form-urlencoded
    const txt = await req.text().catch(() => "")
    try { raw = JSON.parse(new URLSearchParams(txt).get("dados") ?? "{}") } catch { raw = { _raw: txt } }
  }

  const dados = (raw as Record<string, unknown>) ?? {}
  const pedido = (dados.pedido ?? dados) as Record<string, unknown>
  const numero = String(pedido.numero_pedido_ecommerce ?? pedido.numeroEcommerce ?? pedido.numero ?? "").trim()
  const situacao = String(pedido.situacao ?? pedido.status ?? "").toLowerCase()

  // Sem número não dá para casar — só registra e sai.
  if (!numero) {
    return NextResponse.json({ ok: true, matched: false })
  }

  const proposal = await prisma.proposal.findFirst({
    where: { numero },
    select: { id: true, companyId: true, numero: true, client_name: true, vendedorId: true },
  })

  if (!proposal) {
    return NextResponse.json({ ok: true, matched: false })
  }

  const faturado = /fatur|atendid|aprovad/.test(situacao)

  // Registra no Debugger de Webhooks (payload recebido + status)
  await prisma.webhookDebugLog.create({
    data: {
      companyId: proposal.companyId,
      endpoint: "tiny/webhook-retorno",
      payload_json: { numero, situacao, pedido } as object,
      http_status: 200,
      response_body: faturado ? "Pedido faturado no Tiny" : `Situação recebida: ${situacao || "—"}`,
      reenviado: false,
    },
  }).catch(() => {})

  // Notificação interna (mesmo padrão da gaveta de notificações)
  await prisma.webhookDebugLog.create({
    data: {
      companyId: proposal.companyId,
      endpoint: "internal/notificacao",
      payload_json: {
        numero: proposal.numero,
        client_name: `${faturado ? "Faturada no Tiny" : "Retorno do Tiny"}: ${proposal.client_name}`,
        para: proposal.vendedorId,
      },
      reenviado: false,
    },
  }).catch(() => {})

  return NextResponse.json({ ok: true, matched: true, faturado })
}
