import { NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { temAlgumPerfil } from "@/lib/perfil";
import { syncOlist } from "@/lib/olist-sync"

/**
 * POST /api/integracoes/olist/sync
 * Dispara a sincronização manual com o Olist. Acesso: ADMIN e FINANCEIRO.
 */
export async function POST() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
  }

  const resultado = await syncOlist(session.companyId)
  return NextResponse.json({ success: true, resultado })
}
