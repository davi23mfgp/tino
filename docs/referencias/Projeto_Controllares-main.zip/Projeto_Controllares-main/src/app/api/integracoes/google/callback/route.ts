import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

/**
 * GET /api/integracoes/google/callback
 * Recebe o código OAuth2 do Google, troca por tokens e salva no usuário.
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const code = searchParams.get("code")
  const state = searchParams.get("state") // userId
  const error = searchParams.get("error")

  // MESMA origem usada no auth (o redirect_uri precisa bater exatamente).
  // Fixo via APP_URL — não deriva do domínio de preview do Vercel.
  const appUrl = process.env.APP_URL || new URL(req.url).origin

  if (error || !code || !state) {
    return NextResponse.redirect(`${appUrl}/configuracoes?google=erro`)
  }

  // Busca credenciais do Google via empresa do usuário
  const user = await prisma.user.findUnique({
    where: { id: state },
    include: { company: { select: { google_client_id: true, google_client_secret: true } } },
  })

  const clientId = user?.company.google_client_id || process.env.GOOGLE_CLIENT_ID
  const clientSecret = user?.company.google_client_secret || process.env.GOOGLE_CLIENT_SECRET
  if (!clientId || !clientSecret) {
    return NextResponse.redirect(`${appUrl}/configuracoes?google=sem-credenciais`)
  }

  const redirectUri = `${appUrl}/api/integracoes/google/callback`

  // Troca code por tokens
  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      code,
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: redirectUri,
      grant_type: "authorization_code",
    }).toString(),
  })

  if (!tokenRes.ok) {
    return NextResponse.redirect(`${appUrl}/configuracoes?google=token-erro`)
  }

  const tokens = await tokenRes.json()

  // Salva tokens no usuário
  const expiry = tokens.expires_in
    ? new Date(Date.now() + tokens.expires_in * 1000)
    : null

  await prisma.user.update({
    where: { id: state },
    data: {
      google_access_token: tokens.access_token,
      google_refresh_token: tokens.refresh_token ?? undefined,
      google_token_expiry: expiry,
    },
  })

  return NextResponse.redirect(`${appUrl}/configuracoes?google=conectado`)
}
