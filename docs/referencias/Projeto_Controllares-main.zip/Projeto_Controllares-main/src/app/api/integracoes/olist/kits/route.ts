import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { chamarV2, tokenDaEmpresa, pausa, INTERVALO_MS, ErroOlist, ehDuplicidade, codigoServico } from "@/lib/olist-v2"

export const dynamic = "force-dynamic"
export const maxDuration = 60

/**
 * Espelha os kits daqui no Olist.
 *
 * Só produto simples subia. O kit é o que o vendedor de fato oferece — um
 * pacote com preço próprio — e no Olist não existia: quem faturava precisava
 * montar o pacote à mão a cada pedido.
 *
 * No Olist um kit é um produto com `classe_produto: "K"` e uma lista de
 * componentes por `id_produto`. Só CRIA, nunca altera nem exclui: kit já
 * cadastrado lá pode estar amarrado a pedido e histórico que não é nosso.
 */

/** Mapa código → id de tudo que está no Olist. O kit referencia por id. */
async function idsPorCodigo(token: string): Promise<Map<string, number>> {
  const mapa = new Map<string, number>()
  let pagina = 1
  let paginas = 1
  do {
    const ret = await chamarV2(token, "produtos.pesquisa.php", { pagina: String(pagina) })
    if (ret.vazio) break
    const lista = (ret.produtos ?? []) as { produto?: { codigo?: string; id?: string } }[]
    for (const x of lista) {
      if (x.produto?.codigo && x.produto.id) mapa.set(x.produto.codigo, Number(x.produto.id))
    }
    paginas = Number(ret.numero_paginas ?? 1) || 1
    pagina++
    if (pagina <= paginas) await pausa(INTERVALO_MS)
  } while (pagina <= paginas && pagina <= 50)
  return mapa
}

/** Código do kit no Olist. Mesmo formato do serviço: estável entre envios. */
const codigoKit = (nome: string) => codigoServico(nome).replace(/^SERV-/, "KIT-")

async function carregarKits(companyId: string) {
  return prisma.kit.findMany({
    where: { companyId },
    select: {
      id: true, nome: true, descricao: true, desconto: true,
      items: {
        select: {
          quantidade: true, desconto_unitario: true,
          product: { select: { sku: true, nome: true, preco_venda: true } },
        },
      },
    },
    orderBy: { nome: "asc" },
  })
}

/** Preço do kit: soma dos componentes menos os descontos cadastrados. */
function precoDoKit(kit: Awaited<ReturnType<typeof carregarKits>>[number]) {
  const bruto = kit.items.reduce((s, i) =>
    s + (Number(i.product?.preco_venda ?? 0) - Number(i.desconto_unitario ?? 0)) * i.quantidade, 0)
  return Math.max(0, bruto - Number(kit.desconto ?? 0))
}

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Sem permissão para integrar com o Olist." }, { status: 403 })
  }
  const token = await tokenDaEmpresa(session.companyId)
  if (!token) {
    return NextResponse.json(
      { error: "Preencha o token do Olist em Configurações → Integrações." }, { status: 422 })
  }

  const kits = await carregarKits(session.companyId)
  const mapa = await idsPorCodigo(token)
  const faltando = kits.filter(k => !mapa.has(codigoKit(k.nome)))

  /* Componente que não está no Olist impede o kit: o pacote referencia por id,
     e id de produto inexistente não existe. Vale avisar antes de tentar. */
  const semComponentes = faltando.filter(k =>
    k.items.some(i => !i.product?.sku || !mapa.has(i.product.sku)))

  return NextResponse.json({
    nossos: kits.length,
    faltando: faltando.length,
    bloqueados: semComponentes.length,
    aviso: semComponentes.length
      ? "Envie o catálogo primeiro: alguns kits têm componentes que ainda não existem no Olist."
      : null,
    amostra: faltando.slice(0, 10).map(k => k.nome),
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin sincroniza kits." }, { status: 403 })
  }
  const token = await tokenDaEmpresa(session.companyId)
  if (!token) {
    return NextResponse.json(
      { error: "Preencha o token do Olist em Configurações → Integrações." }, { status: 422 })
  }

  const { lote = 10 } = await req.json().catch(() => ({}))

  const kits = await carregarKits(session.companyId)
  const mapa = await idsPorCodigo(token)
  const faltando = kits.filter(k => !mapa.has(codigoKit(k.nome)))
  const daVez = faltando.slice(0, Math.min(Number(lote) || 10, 20))

  const criados: string[] = []
  const falhas: { kit: string; erro: string }[] = []
  let bloqueado = false

  for (const [i, kit] of daVez.entries()) {
    if (i > 0) await pausa(INTERVALO_MS)

    const componentes = kit.items
      .filter(it => it.product?.sku && mapa.has(it.product.sku))
      .map(it => ({ item: { id_produto: mapa.get(it.product!.sku)!, quantidade: it.quantidade } }))

    if (componentes.length !== kit.items.length) {
      falhas.push({
        kit: kit.nome,
        erro: "há componentes fora do Olist — envie o catálogo antes",
      })
      continue
    }
    if (!componentes.length) {
      falhas.push({ kit: kit.nome, erro: "kit sem itens" })
      continue
    }

    try {
      await chamarV2(token, "produto.incluir.php", {
        produto: JSON.stringify({
          produtos: [{
            produto: {
              sequencia: 1,
              codigo: codigoKit(kit.nome),
              nome: kit.nome,
              tipo: "P",
              situacao: "A",
              unidade: "UN",
              preco: Number(precoDoKit(kit).toFixed(2)) || 1,
              origem: "0",
              classe_produto: "K",
              ...(kit.descricao ? { descricao_complementar: kit.descricao } : {}),
              kit: componentes,
            },
          }],
        }),
      })
      criados.push(kit.nome)
    } catch (e) {
      const msg = e instanceof ErroOlist ? e.message : "falha desconhecida"
      // Duplicidade é estar lá — o efeito desejado, não uma falha.
      if (ehDuplicidade(msg)) { criados.push(kit.nome); continue }
      falhas.push({ kit: kit.nome, erro: msg })
      if (e instanceof ErroOlist && e.bloqueio) { bloqueado = true; break }
    }
  }

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "CRIAR",
      descricao: `Olist: ${criados.length} kit(s) enviados`
        + (falhas.length ? ` — ${falhas.length} falha(s)` : ""),
    },
  }).catch(() => {})

  return NextResponse.json({
    criados, falhas, bloqueado,
    restantes: Math.max(0, faltando.length - criados.length),
  })
}
