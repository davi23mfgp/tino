import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { soDigitos, formatarDocumento } from "@/lib/documento"
import { chamarV2, ErroOlist, ehDuplicidade, codigoServico, situacaoContribuinte, pausa, INTERVALO_MS } from "@/lib/olist-v2"
import { valorDoServico } from "@/lib/servicos-proposta"

/**
 * POST /api/integracoes/tiny/sincronizar
 * Body: { proposalId: string }
 * Envia a proposta como pedido de venda no Tiny ERP.
 */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { proposalId } = await req.json()
  if (!proposalId) return NextResponse.json({ error: "proposalId obrigatório" }, { status: 400 })

  // Busca token da empresa
  const company = await prisma.company.findUnique({
    where: { id: session.companyId },
    select: { tiny_api_token: true, nome_empresa: true },
  })
  if (!company?.tiny_api_token) {
    return NextResponse.json({ error: "Token Tiny não configurado. Configure em Configurações → Integrações." }, { status: 422 })
  }

  // Busca proposta com itens
  const proposal = await prisma.proposal.findFirst({
    where: { id: proposalId, companyId: session.companyId },
    include: {
      environments: {
        include: {
          proposalItems: {
            include: { product: true, kit: true },
          },
        },
      },
      installments: true,
      vendedor: { select: { nome: true } },
    },
  })
  if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  if (proposal.olist_enviado_em) {
    return NextResponse.json({
      error: `Esta proposta já foi enviada ao Olist`
        + (proposal.olist_pedido_numero ? ` (pedido ${proposal.olist_pedido_numero})` : "")
        + ` em ${proposal.olist_enviado_em.toLocaleDateString("pt-BR")}.`,
      jaEnviado: true,
    }, { status: 409 })
  }

  /* Item escrito na proposta e ainda sem cadastro não pode ir ao Olist.

     O pedido lá referencia produto por código. Um item avulso tem nome e preço,
     mas não tem SKU — entraria como linha solta, sem cadastro, sem estoque e
     sem aparecer em relatório nenhum. Barrar aqui é a última porta antes de o
     problema virar pedido de compra. */
  const semCadastro = proposal.environments
    .flatMap(env => env.proposalItems)
    .filter(it => it.avulso && !it.avulso_resolvido_em)

  if (semCadastro.length) {
    const nomes = semCadastro.map(i => i.nome_snapshot ?? "sem nome").slice(0, 5).join(", ")
    return NextResponse.json({
      error: `Cadastre no catálogo antes de enviar ao Olist: ${nomes}`
        + (semCadastro.length > 5 ? ` e mais ${semCadastro.length - 5}.` : "."),
      itensAvulsos: semCadastro.length,
    }, { status: 422 })
  }

  /* Itens do pedido, AGRUPADOS pelo código.

     O escopo da proposta separa por ambiente: o mesmo sensor na sala e no
     quarto vira duas linhas. Mandadas assim, o Olist marca "Itens repetidos"
     no pedido e alguém precisa consolidar à mão antes de faturar. Aqui a
     quantidade é somada por código — o ambiente é organização nossa, não do
     pedido de venda. */
  const porCodigo = new Map<string, { item: Record<string, unknown> }>()
  for (const env of proposal.environments) {
    for (const item of env.proposalItems) {
      const p = item.product
      const codigo = p?.sku ?? item.kit?.id ?? item.sku_snapshot ?? "SEM-COD"
      const existente = porCodigo.get(codigo)
      if (existente) {
        existente.item.quantidade = Number(existente.item.quantidade) + item.quantidade
        continue
      }
      porCodigo.set(codigo, {
        item: {
          codigo,
          descricao: p?.nome ?? item.kit?.nome ?? item.nome_snapshot ?? "Item",
          unidade: p?.unidade || "UN",
          quantidade: item.quantidade,
          valor_unitario: item.valor_unitario,
          // Fiscal: só vai o que estiver preenchido no cadastro do produto.
          // Campo em branco no Olist significa que falta preencher no catálogo.
          ...(p?.ncm ? { ncm: p.ncm } : {}),
          ...(p?.cest ? { cest: p.cest } : {}),
          ...(p?.origem ? { origem: p.origem } : {}),
          ...(p?.gtin ? { gtin: p.gtin } : {}),
          ...(p?.cst_icms ? { cst: p.cst_icms } : {}),
          ...(p?.aliquota_icms != null ? { aliquota_icms: p.aliquota_icms } : {}),
          ...(p?.aliquota_ipi != null ? { aliquota_ipi: p.aliquota_ipi } : {}),
          ...(p?.cst_pis ? { cst_pis: p.cst_pis } : {}),
          ...(p?.aliquota_pis != null ? { aliquota_pis: p.aliquota_pis } : {}),
          ...(p?.cst_cofins ? { cst_cofins: p.cst_cofins } : {}),
          ...(p?.aliquota_cofins != null ? { aliquota_cofins: p.aliquota_cofins } : {}),
          ...(p?.peso_kg != null ? { peso_bruto: p.peso_kg, peso_liquido: p.peso_kg } : {}),
        },
      })
    }
  }
  const itensProdutos = [...porCodigo.values()]

  const subtotalProdutos = itensProdutos.reduce(
    (s, i) => s + Number(i.item.quantidade) * Number(i.item.valor_unitario), 0)

  /* Serviços como itens do pedido.

     Instalação, taxa administrativa e os serviços avulsos não têm SKU: vivem
     num Json da proposta. Iam de fora, e o Olist recebia só a mercadoria — o
     pedido fechava com valor menor que o aceito pelo cliente, e a diferença
     ainda era interpretada como desconto. Aqui viram linhas de serviço, com
     código estável para não duplicar cadastro a cada proposta. */
  /* A base do percentual sai de `servicos-proposta`, a mesma usada na proposta
     do cliente e no contrato. Calculada aqui de novo sobre o total, uma
     instalação de 15% cadastrada em Som Ambiente cobrava 15% da automação
     junto — e o pedido do Olist saía maior que o documento assinado. */
  const itensParaServico = proposal.environments.flatMap(env =>
    env.proposalItems.map(it => ({
      environmentId: env.id,
      categoryId: it.categoryId ?? it.product?.categoryId ?? null,
      valor_total: Number(it.valor_total),
    })))

  type ServicoJson = {
    nome?: string; tipo?: string; valor?: string
    environmentId?: string | null; categoryId?: string | null
  }
  const avulsos = Array.isArray(proposal.servicos_detalhe)
    ? (proposal.servicos_detalhe as unknown as ServicoJson[])
    : []

  const servicos = avulsos
    .filter(x => x?.nome)
    .map(x => ({
      nome: String(x.nome),
      valor: Number(valorDoServico(x, itensParaServico).toFixed(2)),
    }))
    .filter(x => x.valor > 0)

  /* Instalação e taxa administrativa entram no total da proposta mas não são
     persistidas linha a linha — só o total sobrevive ao salvamento. O que
     sobra depois de produtos e serviços nomeados é exatamente elas, e vai numa
     linha única. Sem isso o pedido fechava abaixo do valor aceito. */
  const somaServicos = servicos.reduce((t, x) => t + x.valor, 0)
  const residuo = Number((Number(proposal.valor_total ?? 0) - subtotalProdutos - somaServicos).toFixed(2))
  if (residuo > 0.01) {
    servicos.push({ nome: "Instalação e projeto", valor: residuo })
  }

  const itensServicos = servicos.map(x => ({
    item: {
      codigo: codigoServico(x.nome),
      descricao: x.nome,
      unidade: "UN",
      quantidade: 1,
      valor_unitario: x.valor,
    },
  }))

  const itens = [...itensProdutos, ...itensServicos]

  const valorTotal = itens.reduce(
    (s, i) => s + Number(i.item.quantidade) * Number(i.item.valor_unitario), 0)

  /* Forma de pagamento: sai de `forma_pagamento`, a escolha que o cliente
     confirmou no link — não de `payment_methods`, o campo antigo que deixou de
     ser preenchido quando o aceite passou a definir a condição.

     `forma_pagamento` do Olist é uma lista fechada, não texto livre: mandar
     "À vista" fazia o campo chegar vazio e o pedido ficar sem forma nenhuma.
     Estes são os valores que a v2 aceita. Parcelado na obra e condição
     personalizada não têm equivalente e caem em "multiplas", que é como o
     próprio Olist marca pagamento em mais de uma etapa. */
  const FORMA_OLIST: Record<string, string> = {
    CARTAO: "cartao_credito",
    AVISTA: "dinheiro",
    OBRA: "multiplas",
    PERSONALIZADO: "multiplas",
    // Formas escolhidas parcela a parcela na condição personalizada.
    PIX: "pix",
    BOLETO: "boleto",
    TRANSFERENCIA: "deposito",
    DINHEIRO: "dinheiro",
    CHEQUE: "cheque",
  }
  const formaPagamento = proposal.forma_pagamento
    ? FORMA_OLIST[proposal.forma_pagamento] ?? "multiplas"
    : ""

  /* Parcelas do Olist: data em pt-BR e valor numérico.

     Quando o financeiro ainda não gerou o cronograma, monta um a partir da
     condição aceita — número de parcelas, entrada e total. Sem isso um aceite
     em 6x chegava lá como pagamento único, e alguém teria de redigitar. */
  const totalPedido = valorTotal
  const entrada = Number(proposal.valor_entrada ?? 0)
  const nParcelas = Math.max(1, proposal.parcelas_forma ?? 1)

  /* Rede de segurança para cronograma antigo.

     A marca `entrada` só passou a ser gravada depois que a entrada virou linha
     própria — as propostas salvas antes disso têm a entrada como primeira
     parcela, sem marca nenhuma, e o pedido saía no Olist como sete parcelas
     iguais. Quando a proposta declara uma entrada e a primeira linha bate com
     ela em valor, é entrada: reconhecer aqui evita ter que reeditar à mão todo
     cronograma já salvo. */
  const marcada = proposal.installments.some(i => i.entrada)
  const primeira = proposal.installments.slice()
    .sort((a, b) => a.numero_parcela - b.numero_parcela)[0]
  const entradaPorValor = !marcada
    && Number(proposal.valor_entrada ?? 0) > 0
    && !!primeira
    && Math.abs(Number(primeira.valor) - Number(proposal.valor_entrada)) < 0.02

  const cronograma = proposal.installments.length
    ? proposal.installments
        .slice()
        .sort((a, b) => a.numero_parcela - b.numero_parcela)
        .map(p => ({
          numero: p.numero_parcela,
          total: proposal.installments.length,
          data: new Date(p.data_vencimento),
          valor: Number(p.valor),
          entrada: p.entrada || (entradaPorValor && p.id === primeira?.id),
          forma: p.forma,
        }))
    : (() => {
        /* A entrada é uma parcela À PARTE, não um acréscimo na primeira.

           Antes a entrada era somada dentro da parcela 1 e o pedido chegava no
           Olist com "6x" onde a primeira valia entrada + 1/6 — o cliente
           combinou entrada mais seis, e o financeiro via seis. Agora a entrada
           vai como parcela própria, vencendo hoje, e o restante divide entre as
           parcelas combinadas: entrada + 6x vira sete linhas.

           O centavo que sobra da divisão vai na última. Sem isso a soma das
           parcelas fechava um ou dois centavos abaixo do total do pedido. */
        const restante = Math.max(0, totalPedido - entrada)
        const temEntrada = entrada > 0
        const total = nParcelas + (temEntrada ? 1 : 0)
        const base = Math.floor((restante / nParcelas) * 100) / 100
        const sobra = Number((restante - base * nParcelas).toFixed(2))

        const linhas: { numero: number; total: number; data: Date; valor: number
                        entrada: boolean; forma: string | null }[] = []
        if (temEntrada) {
          linhas.push({
            numero: 1, total, data: new Date(),
            valor: Number(entrada.toFixed(2)), entrada: true, forma: null,
          })
        }
        for (let i = 0; i < nParcelas; i++) {
          const venc = new Date()
          // Com entrada hoje, a primeira parcela cai no mês seguinte.
          venc.setMonth(venc.getMonth() + i + (temEntrada ? 1 : 0))
          const ultima = i === nParcelas - 1
          linhas.push({
            numero: linhas.length + 1,
            total,
            data: venc,
            valor: Number((ultima ? base + sobra : base).toFixed(2)),
            entrada: false,
            forma: null,
          })
        }
        return linhas
      })()

  /* O desconto não ia junto: o Olist recebia a soma dos itens como total e o
     valor fechado com o cliente ficava só na proposta. A diferença entre os
     dois É o desconto. */
  const descontoReais = Math.max(0, valorTotal - Number(proposal.valor_total ?? valorTotal))

  /* A numeração ignora a entrada: num "entrada + 6x", as parcelas são 1/6 a
     6/6, não 2/7 a 7/7. Contar a entrada como parcela é o mesmo engano que já
     inflava a primeira — some no valor, aparece no rótulo. */
  const totalParcelas = cronograma.filter(p => !p.entrada).length
  let ordemParcela = 0

  const parcelas = cronograma.map(p => ({
    parcela: {
      dias: Math.max(0, Math.round((p.data.getTime() - Date.now()) / 86_400_000)),
      data: p.data.toLocaleDateString("pt-BR"),
      valor: p.valor,
      obs: p.entrada ? "Entrada" : `Parcela ${++ordemParcela}/${totalParcelas}`,
      /* A forma sai da PARCELA quando ela tem uma. Na condição personalizada
         cada mês pode ter a sua — entrada no Pix, duas no cartão, o resto em
         boleto —, e mandar a forma geral em todas apagava justamente o que foi
         combinado. Sem forma na parcela, vale a da proposta. */
      ...((p.forma && FORMA_OLIST[p.forma]) || formaPagamento
        ? { forma_pagamento: (p.forma && FORMA_OLIST[p.forma]) || formaPagamento }
        : {}),
    },
  }))

  // O nome vai dentro de `cliente`, não na raiz do pedido — na raiz a API
  // ignora e responde "O campo nome do cliente deve ser informado".
  const nomeCliente = proposal.client_name?.trim()
  if (!nomeCliente) {
    return NextResponse.json(
      { error: "A proposta está sem nome de cliente. Preencha antes de enviar." },
      { status: 422 },
    )
  }

  /* Cliente: vai o cadastro de faturamento, não o que foi digitado na
     correria da proposta. É o dado conferido para a nota — documento, endereço
     e e-mail. Sem ele o contato entrava no Olist só com o nome, e alguém
     precisava completar à mão antes de faturar.

     tipo_pessoa sai do tamanho do documento: 11 dígitos = física, 14 =
     jurídica. Fixar "F" fazia CNPJ entrar como pessoa física. */
  const doc = soDigitos(proposal.fat_documento)
  const cliente: Record<string, unknown> = {
    nome: proposal.fat_razao_social?.trim() || nomeCliente,
    tipo_pessoa: doc.length === 14 ? "J" : "F",
    ...(doc ? { cpf_cnpj: formatarDocumento(doc) } : {}),
    ...(proposal.fat_email || proposal.client_email
      ? { email: proposal.fat_email || proposal.client_email } : {}),
    ...(proposal.fat_logradouro ? { endereco: proposal.fat_logradouro } : {}),
    ...(proposal.fat_numero ? { numero: proposal.fat_numero } : {}),
    ...(proposal.fat_complemento ? { complemento: proposal.fat_complemento } : {}),
    ...(proposal.fat_bairro ? { bairro: proposal.fat_bairro } : {}),
    ...(proposal.fat_cep ? { cep: proposal.fat_cep } : {}),
    ...(proposal.fat_cidade || proposal.client_city
      ? { cidade: proposal.fat_cidade || proposal.client_city } : {}),
    ...(proposal.fat_uf ? { uf: proposal.fat_uf } : {}),
    ...(proposal.fat_ie ? { ie: proposal.fat_ie } : {}),
  }

  /* Vendedor: o Olist só aceita nome de vendedor JÁ cadastrado lá, e recusa o
     pedido inteiro com "Vendedor não localizado" quando não encontra. Não dá
     para criar pela API — `vendedor.incluir` não existe, e incluir contato com
     tipo "Vendedor" grava como "Outro".

     Então consultamos antes: existindo, o pedido vai com o responsável; não
     existindo, vai sem — melhor um pedido sem vendedor do que nenhum pedido.
     Para o campo ser preenchido, basta marcar a pessoa como Vendedor no Olist
     uma vez (Cadastros → Vendedores). */
  const nomeVendedor = proposal.vendedor?.nome?.trim() ?? ""
  let vendedorNoOlist = ""
  if (nomeVendedor) {
    try {
      const f = new URLSearchParams({
        token: company.tiny_api_token, formato: "json", pesquisa: nomeVendedor,
      })
      const rv = await fetch("https://api.tiny.com.br/api2/vendedores.pesquisa.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: f.toString(),
        signal: AbortSignal.timeout(15_000),
      })
      const jv = await rv.json().catch(() => null) as
        { retorno?: { vendedores?: { vendedor?: { nome?: string } }[] } } | null
      const achado = (jv?.retorno?.vendedores ?? [])
        .map(x => x.vendedor?.nome ?? "")
        .find(n => n.toLowerCase() === nomeVendedor.toLowerCase())
      vendedorNoOlist = achado ?? ""
    } catch { vendedorNoOlist = "" }
  }

  /* Serviço precisa existir no Olist antes do pedido: item com código que lá
     não tem entra sem cadastro e não aparece em relatório nem em nota. Cria
     uma vez por código — nas propostas seguintes a pesquisa já encontra. */
  const avisos: string[] = []

  /* Cadastro do cliente no Olist, antes do pedido.

     `contribuinte` não é campo do cliente DENTRO do pedido — só do contato. Sem
     o contato cadastrado, o enquadramento de ICMS nunca chegava, e a nota saía
     com o destinatário sem enquadramento (que o SEFAZ rejeita em operação
     interestadual).

     Só cria quando não encontra pelo documento: o Olist aceita dois contatos
     com o mesmo CNPJ sem reclamar, e a duplicata quebra o histórico do cliente. */
  if (doc) {
    try {
      const busca = await chamarV2(company.tiny_api_token, "contatos.pesquisa.php", { cpf_cnpj: doc })
      const existe = !busca.vazio && ((busca.contatos ?? []) as unknown[]).length > 0
      if (!existe) {
        await pausa(INTERVALO_MS)
        await chamarV2(company.tiny_api_token, "contato.incluir.php", {
          contato: JSON.stringify({
            contatos: [{
              contato: {
                sequencia: 1,
                ...cliente,
                situacao: "A",
                tipos_contato: [{ tipo: "Cliente" }],
                contribuinte: situacaoContribuinte(proposal.fat_documento, proposal.fat_ie),
              },
            }],
          }),
        })
      }
    } catch (e) {
      /* IE inválida derruba o cadastro inteiro com "A Inscrição Estadual do
         contato é inválida". Não vale perder o pedido por isso: tenta de novo
         sem a inscrição e avisa quem enviou. */
      const msg = e instanceof ErroOlist ? e.message : ""
      if (/inscri..o estadual/i.test(msg)) {
        avisos.push(
          `A inscrição estadual "${proposal.fat_ie}" foi recusada pelo Olist.`
          + ` O cliente foi cadastrado sem ela — corrija em Cadastros → Contatos.`)
        const { ie: _ie, ...semIe } = cliente as Record<string, unknown>
        await pausa(INTERVALO_MS)
        await chamarV2(company.tiny_api_token, "contato.incluir.php", {
          contato: JSON.stringify({
            contatos: [{
              contato: {
                sequencia: 1, ...semIe, situacao: "A",
                tipos_contato: [{ tipo: "Cliente" }],
                contribuinte: situacaoContribuinte(proposal.fat_documento, null),
              },
            }],
          }),
        }).catch(() => {})
      } else {
        avisos.push(`Não foi possível cadastrar o cliente no Olist: ${msg || "falha desconhecida"}`)
      }
    }
    await pausa(INTERVALO_MS)
  }

  for (const [i, sv] of servicos.entries()) {
    const codigo = codigoServico(sv.nome)
    try {
      if (i > 0) await pausa(INTERVALO_MS)
      const busca = await chamarV2(company.tiny_api_token, "produtos.pesquisa.php", { pesquisa: codigo })
      const achou = ((busca.produtos ?? []) as { produto?: { codigo?: string } }[])
        .some(x => x.produto?.codigo === codigo)
      if (achou) continue

      await pausa(INTERVALO_MS)
      await chamarV2(company.tiny_api_token, "produto.incluir.php", {
        produto: JSON.stringify({
          produtos: [{
            produto: {
              sequencia: 1,
              codigo,
              nome: sv.nome,
              tipo: "S",           // serviço, não mercadoria
              situacao: "A",
              unidade: "UN",
              preco: sv.valor,
              origem: "0",
            },
          }],
        }),
      })
    } catch (e) {
      /* Falhar aqui não impede o pedido: o item vai com o código mesmo assim.
         O aviso volta para quem enviou, que decide se cadastra à mão. */
      const msg = e instanceof ErroOlist ? e.message : "não foi possível cadastrar"
      // Duplicidade é o serviço já existir lá, que é o que a checagem buscava.
      if (!ehDuplicidade(msg)) avisos.push(`Serviço "${sv.nome}": ${msg}`)
    }
  }

  const pedido = {
    pedido: {
      data_pedido: new Date().toLocaleDateString("pt-BR"),
      data_prevista: proposal.data_expiracao
        ? new Date(proposal.data_expiracao).toLocaleDateString("pt-BR")
        : "",
      numero_pedido_ecommerce: proposal.numero,
      cliente,
      valor: valorTotal,
      // Nome do vendedor: a comissão e o relatório de performance do Olist se
      // apoiam nele. Sem isso todo pedido aparecia sem responsável.
      ...(vendedorNoOlist ? { nome_vendedor: vendedorNoOlist } : {}),
      /* Desconto acordado, em reais. O Olist aceita "10%" ou um valor; mandar
         valor evita divergência de arredondamento com o total que já enviamos.
         Sai da diferença entre a soma dos itens e o total fechado da proposta,
         que é onde o desconto de fato ficou. */
      ...(descontoReais > 0 ? { desconto: descontoReais.toFixed(2) } : {}),
      obs: [
        `Proposta ${proposal.numero}`,
        nomeVendedor ? `Responsável: ${nomeVendedor}` : null,
        proposal.project_type,
        proposal.mensagem_cliente,
      ].filter(Boolean).join(" | ").slice(0, 500),
      situacao: "Em Andamento",
      // Sem isto o pedido chegava no Olist com "Forma de recebimento: Múltiplas"
      // e a lista de parcelas vazia.
      ...(formaPagamento ? { forma_pagamento: formaPagamento } : {}),
      ...(parcelas.length ? { parcelas } : {}),
      itens,
    },
  }

  const formData = new URLSearchParams()
  formData.append("token", company.tiny_api_token)
  formData.append("formato", "json")
  formData.append("pedido", JSON.stringify(pedido))

  try {
    const tinyRes = await fetch("https://api.tiny.com.br/api2/pedido.incluir.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: formData.toString(),
    })

    // A resposta nem sempre é JSON (token inválido devolve HTML/texto).
    const bruto = await tinyRes.text()
    let tinyData: { retorno?: Record<string, unknown> } | null = null
    try { tinyData = JSON.parse(bruto) } catch { /* mantém o texto cru abaixo */ }

    if (!tinyData) {
      return NextResponse.json(
        { error: `Tiny respondeu algo que não é JSON (HTTP ${tinyRes.status}): ${bruto.slice(0, 200)}` },
        { status: 502 },
      )
    }

    if (tinyData?.retorno?.status !== "OK") {
      // O erro vem em formatos diferentes conforme a falha; "Erro desconhecido"
      // aparecia porque só um deles era lido.
      const r = tinyData?.retorno as Record<string, unknown> | undefined
      const listas = [
        r?.erros,
        (r?.registros as { registro?: { erros?: unknown } })?.registro?.erros,
      ]
      const mensagens: string[] = []
      for (const lista of listas) {
        if (!Array.isArray(lista)) continue
        for (const e of lista) {
          const txt = typeof e === "string" ? e : (e as { erro?: string })?.erro
          if (txt) mensagens.push(String(txt))
        }
      }
      if (!mensagens.length && r?.erro) mensagens.push(String(r.erro))
      if (!mensagens.length && r?.codigo_erro) {
        mensagens.push(`código ${r.codigo_erro}${r.status_processamento ? ` (processamento ${r.status_processamento})` : ""}`)
      }
      const erros = mensagens.length
        ? mensagens.join(", ")
        // Sem mensagem reconhecida: devolve o corpo cru em vez de esconder a causa.
        : `resposta sem detalhe — ${JSON.stringify(tinyData).slice(0, 300)}`
      // Registra a falha no debugger de webhooks também
      await prisma.webhookDebugLog.create({
        data: {
          companyId: session.companyId,
          endpoint: "tiny/pedido.incluir",
          payload_json: JSON.parse(JSON.stringify({ proposalId, numero: proposal.numero, pedido })),
          http_status: tinyRes.status,
          response_body: JSON.stringify(tinyData).slice(0, 4000),
          reenviado: false,
        },
      }).catch(() => {})
      return NextResponse.json({ error: `Tiny API: ${erros}` }, { status: 422 })
    }

    const numeroPedido =
      (tinyData?.retorno?.registros as { registro?: { numero_pedido?: string } } | undefined)
        ?.registro?.numero_pedido ?? ""

    // Move para "Em Faturamento" e registra o envio, que é o que impede a
    // segunda tentativa de criar um pedido duplicado lá.
    await prisma.proposal.update({
      where: { id: proposal.id },
      data: {
        status: "EM_FATURAMENTO",
        olist_enviado_em: new Date(),
        olist_pedido_numero: numeroPedido || null,
      },
    })

    // Log no debugger de webhooks (envio + resposta + status HTTP)
    await prisma.webhookDebugLog.create({
      data: {
        companyId: session.companyId,
        endpoint: "tiny/pedido.incluir",
        payload_json: JSON.parse(JSON.stringify({ proposalId, numero: proposal.numero, numeroPedido, pedido })),
        http_status: tinyRes.status,
        response_body: JSON.stringify(tinyData).slice(0, 4000),
        reenviado: false,
      },
    })

    /* Vendedor sem cadastro no Olist não derruba o pedido, mas some do
       relatório de comissão — quem enviou precisa saber para cadastrar. */
    if (nomeVendedor && !vendedorNoOlist) {
      avisos.push(
        `O vendedor "${nomeVendedor}" não está cadastrado no Olist e o pedido foi`
        + ` sem responsável. Cadastre em Cadastros → Vendedores e os próximos já vão com ele.`)
    }

    return NextResponse.json({ success: true, numeroPedido, avisos })
  } catch (err) {
    console.error("Erro ao chamar Tiny API:", err)
    return NextResponse.json({ error: "Falha na comunicação com Tiny API" }, { status: 500 })
  }
}
