import { NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { enviarWhatsAppEmLote, whatsappConfigurado, type DestinoWhatsApp } from "@/lib/whatsapp"

/**
 * POST /api/integracoes/whatsapp/testar
 *
 * Manda a mensagem de teste para TODOS os destinos e devolve o resultado de
 * cada um. Testar só o número principal escondia justamente o problema comum:
 * no CallMeBot a apikey é amarrada ao aparelho, e um número sem apikey — ou que
 * nunca mandou a frase de autorização ao robô — é recusado em silêncio. Com o
 * teste antigo, a tela dizia "enviado" e uma pessoa continuava sem receber
 * nada, sem ninguém saber qual.
 */
export async function POST() {
  const session = await getSession()
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Sem permissão" }, { status: 403 })
  }

  const c = await prisma.company.findUnique({
    where: { id: session.companyId },
    select: {
      whatsapp_numero: true, whatsapp_apikey: true, whatsapp_extras: true,
      notificar_equipe_whatsapp: true,
      evolution_url: true, evolution_instance: true, evolution_apikey: true,
      nome_empresa: true,
    },
  })
  if (!whatsappConfigurado(c)) {
    return NextResponse.json(
      { error: "Informe o número com DDI e a apikey do CallMeBot (ou preencha a Evolution API) antes de testar." },
      { status: 422 },
    )
  }

  const temEvolution = !!(c!.evolution_url && c!.evolution_instance && c!.evolution_apikey)

  /* Mesma lista que recebe as notificações de verdade: número da empresa,
     extras cadastrados e a equipe com WhatsApp no perfil. Testar uma lista
     diferente da real não prova nada. */
  const destinos: DestinoWhatsApp[] = []

  if (c!.whatsapp_numero) {
    destinos.push({
      rotulo: "Número da empresa",
      numero: c!.whatsapp_numero,
      apikey: c!.whatsapp_apikey,
    })
  }

  try {
    const extras = JSON.parse(c!.whatsapp_extras ?? "[]") as
      { numero: string; apikey?: string; nome?: string }[]
    for (const e of Array.isArray(extras) ? extras : []) {
      destinos.push({ rotulo: e.nome?.trim() || "Número extra", numero: e.numero, apikey: e.apikey })
    }
  } catch { /* lista inválida: os demais destinos continuam sendo testados */ }

  /* Respeita a mesma chave da notificação real. Testar uma lista maior que a
     de verdade faria a tela provar um comportamento que não acontece. */
  const equipe = c!.notificar_equipe_whatsapp ? await prisma.user.findMany({
    where: {
      companyId: session.companyId,
      notificar_whatsapp: true,
      whatsapp_numero: { not: null },
    },
    select: { nome: true, whatsapp_numero: true, whatsapp_apikey: true },
  }) : []
  for (const u of equipe) {
    destinos.push({ rotulo: u.nome ?? "Equipe", numero: u.whatsapp_numero!, apikey: u.whatsapp_apikey })
  }

  const texto = `✅ Teste de WhatsApp — ${c!.nome_empresa ?? "Controllares"}.`

  /* Mesma função que dispara as notificações de verdade: um destino por vez,
     cada um com a apikey dele. Testar por um caminho diferente do real era o
     que fazia a tela dizer "enviado" enquanto ninguém recebia. */
  const resultados = await enviarWhatsAppEmLote(c, texto, destinos)

  const enviados = resultados.filter(r => r.ok).length
  return NextResponse.json({
    ok: enviados > 0,
    enviados,
    total: resultados.length,
    resultados,
    ...(temEvolution ? {} : {
      dica: "No CallMeBot cada número precisa autorizar o robô uma vez"
        + " (mandar “I allow callmebot to send me messages” para +34 623 78 95 95)"
        + " e usar a apikey que ele responde. A chave de um número não entrega no outro.",
    }),
  })
}