import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

interface Agendamento {
  id?: string
  titulo: string
  data: string        // ISO date string
  hora_inicio?: string // HH:MM
  hora_fim?: string    // HH:MM
  equipe?: string
  local?: string
  google_event_id?: string
}

async function refreshToken(userId: string, clientId: string, clientSecret: string, refreshToken: string) {
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
      grant_type: "refresh_token",
    }).toString(),
  })
  if (!res.ok) return null
  const data = await res.json()
  const expiry = new Date(Date.now() + (data.expires_in ?? 3600) * 1000)
  await prisma.user.update({
    where: { id: userId },
    data: { google_access_token: data.access_token, google_token_expiry: expiry },
  })
  return data.access_token as string
}

/**
 * POST /api/integracoes/google/sync-obra/[id]
 * Sincroniza os agendamentos da obra para o Google Calendar do usuário logado.
 */
export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id: obraId } = await params

  const [user, obra] = await Promise.all([
    prisma.user.findUnique({
      where: { id: session.userId },
      include: { company: { select: { google_client_id: true, google_client_secret: true } } },
    }),
    prisma.obra.findFirst({
      where: { id: obraId, companyId: session.companyId },
      select: { agendamentos: true, client_name: true, address: true },
    }),
  ])

  if (!user) return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  if (!user.google_access_token) {
    return NextResponse.json({ error: "Google Calendar não conectado. Conecte em Configurações → Integrações." }, { status: 422 })
  }

  const agendamentos = (obra.agendamentos as Agendamento[] | null) ?? []
  if (agendamentos.length === 0) {
    return NextResponse.json({ success: true, sincronizados: 0, msg: "Nenhum agendamento para sincronizar." })
  }

  // Garante token válido (client da empresa ou global do app)
  const gClientId = user.company.google_client_id || process.env.GOOGLE_CLIENT_ID
  const gClientSecret = user.company.google_client_secret || process.env.GOOGLE_CLIENT_SECRET
  let accessToken = user.google_access_token
  const tokenExpired = user.google_token_expiry && user.google_token_expiry < new Date()
  if (tokenExpired && user.google_refresh_token && gClientId && gClientSecret) {
    const refreshed = await refreshToken(
      user.id,
      gClientId,
      gClientSecret,
      user.google_refresh_token
    )
    if (!refreshed) return NextResponse.json({ error: "Token Google expirado. Reconecte em Configurações." }, { status: 422 })
    accessToken = refreshed
  }

  let sincronizados = 0
  const updatedAgendamentos = [...agendamentos]

  for (let i = 0; i < updatedAgendamentos.length; i++) {
    const ag = updatedAgendamentos[i]
    const startDate = ag.data?.slice(0, 10)
    if (!startDate) continue

    const startDateTime = ag.hora_inicio
      ? `${startDate}T${ag.hora_inicio}:00`
      : startDate
    const endDateTime = ag.hora_fim
      ? `${startDate}T${ag.hora_fim}:00`
      : ag.hora_inicio
      ? `${startDate}T${ag.hora_inicio.replace(/(\d+):(\d+)/, (_, h, m) => `${String(Number(h)+1).padStart(2,'0')}:${m}`)}:00`
      : startDate

    const isAllDay = !ag.hora_inicio

    const event = {
      summary: `[Obra] ${ag.titulo} — ${obra.client_name}`,
      location: ag.local ?? obra.address ?? "",
      description: ag.equipe ? `Equipe: ${ag.equipe}` : "",
      ...(isAllDay
        ? { start: { date: startDate }, end: { date: startDate } }
        : { start: { dateTime: startDateTime, timeZone: "America/Sao_Paulo" }, end: { dateTime: endDateTime, timeZone: "America/Sao_Paulo" } }
      ),
    }

    try {
      let res
      if (ag.google_event_id) {
        // Atualiza evento existente
        res = await fetch(
          `https://www.googleapis.com/calendar/v3/calendars/primary/events/${ag.google_event_id}`,
          {
            method: "PUT",
            headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
            body: JSON.stringify(event),
          }
        )
        if (res.status === 404) {
          // Evento deletado no Google — recriar
          res = await fetch("https://www.googleapis.com/calendar/v3/calendars/primary/events", {
            method: "POST",
            headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
            body: JSON.stringify(event),
          })
        }
      } else {
        // Cria novo evento
        res = await fetch("https://www.googleapis.com/calendar/v3/calendars/primary/events", {
          method: "POST",
          headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
          body: JSON.stringify(event),
        })
      }

      if (res.ok) {
        const data = await res.json()
        updatedAgendamentos[i] = { ...ag, google_event_id: data.id }
        sincronizados++
      }
    } catch {
      // Continua para o próximo
    }
  }

  // Salva google_event_ids de volta na obra
  await prisma.obra.update({
    where: { id: obraId },
    data: { agendamentos: updatedAgendamentos as unknown as import("@prisma/client").Prisma.InputJsonValue },
  })

  return NextResponse.json({ success: true, sincronizados, total: agendamentos.length })
}

/**
 * DELETE /api/integracoes/google/sync-obra/[id]
 * Desconecta Google Calendar do usuário (remove tokens).
 */
export async function DELETE(_req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  await prisma.user.update({
    where: { id: session.userId },
    data: { google_access_token: null, google_refresh_token: null, google_token_expiry: null },
  })

  return NextResponse.json({ success: true })
}
