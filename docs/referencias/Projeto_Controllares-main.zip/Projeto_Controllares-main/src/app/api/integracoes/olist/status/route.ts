import { NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * GET /api/integracoes/olist/status — diz se a empresa tem o Olist conectado.
 * DELETE /api/integracoes/olist/status — desconecta (limpa tokens). Só ADMIN.
 */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const company = await prisma.company.findUnique({
    where: { id: session.companyId },
    select: { olist_access_token: true, olist_token_expiry: true },
  })

  return NextResponse.json({
    conectado: !!company?.olist_access_token,
    expirado: company?.olist_token_expiry ? company.olist_token_expiry < new Date() : false,
  })
}

export async function DELETE() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (session.role !== "ADMIN") {
    return NextResponse.json({ error: "Apenas ADMIN" }, { status: 403 })
  }
  await prisma.company.update({
    where: { id: session.companyId },
    data: { olist_access_token: null, olist_refresh_token: null, olist_token_expiry: null },
  })
  return NextResponse.json({ success: true })
}
