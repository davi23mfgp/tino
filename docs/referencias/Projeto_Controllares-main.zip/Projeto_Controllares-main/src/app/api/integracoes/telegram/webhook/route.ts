import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { casarObraPorTitulo, enviarMensagem, baixarArquivo, tokenDaEmpresa } from "@/lib/telegram"
import { put } from "@vercel/blob"

export const dynamic = "force-dynamic"

/**
 * POST /api/integracoes/telegram/webhook
 *
 * Recebe os updates do bot. O que interessa é `my_chat_member`: dispara quando
 * o bot é adicionado ou removido de um grupo. Ao ser adicionado, o grupo é
 * registrado e, se o título casar com uma obra, o vínculo é feito na hora —
 * é isso que substitui o copia-e-cola do chat_id.
 *
 * Rota pública por definição (quem chama é o Telegram), então a autenticação é
 * o header secreto configurado no setWebhook. Sem ele, qualquer um poderia
 * forjar um vínculo de grupo.
 */
export async function POST(req: NextRequest) {
  const segredo = process.env.TELEGRAM_WEBHOOK_SECRET
  if (!segredo) {
    return NextResponse.json({ error: "Webhook não configurado" }, { status: 503 })
  }
  if (req.headers.get("x-telegram-bot-api-secret-token") !== segredo) {
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  }

  const update = await req.json().catch(() => null)
  if (!update) return NextResponse.json({ ok: true })

  if (update.message) {
    /* Conversa privada: é onde a pessoa liga o Telegram dela à conta.

       O aviso individual precisa do chat_id, e chat_id não se digita — pedir
       para alguém descobrir um número interno do Telegram é garantir que
       ninguém ative. Aqui o bot recebe /start com um código de uso único e
       fecha o vínculo sozinho. */
    const chat = update.message.chat as { id: number; type?: string } | undefined
    if (chat?.type === "private") {
      await vincularConversaPrivada(update.message)
      return NextResponse.json({ ok: true })
    }
    // Arquivo mandado no grupo → entra no repositório da obra vinculada.
    await receberArquivoDoGrupo(update.message)
    return NextResponse.json({ ok: true })
  }

  const membro = update.my_chat_member
  if (!membro?.chat) return NextResponse.json({ ok: true })

  const chat = membro.chat as { id: number; title?: string; type?: string }
  const status: string = membro.new_chat_member?.status ?? ""

  // Só grupos interessam; conversa privada com o bot não vira grupo de obra.
  if (!["group", "supergroup"].includes(chat.type ?? "")) {
    return NextResponse.json({ ok: true })
  }

  const chatId = String(chat.id)
  const titulo = chat.title?.trim() || `Grupo ${chatId}`

  // Bot removido/saiu: marca inativo em vez de apagar, para não perder o
  // histórico de qual grupo já esteve ligado a qual obra.
  if (["left", "kicked"].includes(status)) {
    await prisma.telegramGrupo.updateMany({
      where: { chatId },
      data: { ativo: false },
    })
    return NextResponse.json({ ok: true })
  }

  if (!["member", "administrator"].includes(status)) {
    return NextResponse.json({ ok: true })
  }

  // De qual empresa é este bot? O update não diz — descobrimos pelo token que
  // recebeu o webhook. Como cada empresa tem seu token, casamos pelo id do bot.
  const botId = String(membro.new_chat_member?.user?.id ?? "")
  const empresas = await prisma.company.findMany({
    where: { telegram_bot_token: { not: null } },
    select: { id: true, telegram_bot_token: true },
  })
  const empresa = empresas.find(e => (e.telegram_bot_token ?? "").split(":")[0] === botId)
  if (!empresa) return NextResponse.json({ ok: true })

  const obraId = await casarObraPorTitulo(empresa.id, titulo)

  const grupo = await prisma.telegramGrupo.upsert({
    where: { companyId_chatId: { companyId: empresa.id, chatId } },
    create: {
      companyId: empresa.id, chatId, titulo,
      obraId, automatico: !!obraId, ativo: true,
    },
    update: { titulo, ativo: true, ...(obraId ? { obraId, automatico: true } : {}) },
    select: { id: true, obraId: true },
  })

  // Espelha no campo da obra, que é o que o envio de mensagem já usa.
  if (grupo.obraId) {
    await prisma.obra.update({
      where: { id: grupo.obraId },
      data: { telegram_chat_id: chatId },
    }).catch(() => {})
  }

  // Confirma no próprio grupo: quem adicionou o bot vê na hora se funcionou.
  const token = empresa.telegram_bot_token!
  const obra = grupo.obraId
    ? await prisma.obra.findUnique({ where: { id: grupo.obraId }, select: { client_name: true } })
    : null

  await enviarMensagem(
    token,
    chatId,
    obra
      ? `Conectado à obra "${obra.client_name}". As atualizações do sistema chegam aqui.`
      : `Conectado. Este grupo ainda não está ligado a nenhuma obra — faça o vínculo no sistema, em Obras.`,
  )

  return NextResponse.json({ ok: true })
}

interface AnexoObra { nome: string; url: string; ext: string; origem?: string; em?: string }

/**
 * Arquivo mandado no grupo entra no repositório da obra.
 *
 * É o caminho de volta do fluxo: o técnico fotografa/manda o PDF no grupo, e o
 * arquivo aparece nos anexos da obra sem ninguém precisar reenviar pelo site.
 * Só grava quando o grupo está vinculado a uma obra — sem vínculo não há onde
 * guardar, e adivinhar seria pior.
 */
async function receberArquivoDoGrupo(message: Record<string, unknown>) {
  const chat = message.chat as { id: number; type?: string } | undefined
  if (!chat || !["group", "supergroup"].includes(chat.type ?? "")) return

  const grupo = await prisma.telegramGrupo.findFirst({
    where: { chatId: String(chat.id), ativo: true, obraId: { not: null } },
    select: { obraId: true, companyId: true },
  })
  if (!grupo?.obraId) return

  // Documento, ou a maior resolução quando é foto.
  const doc = message.document as { file_id: string; file_name?: string; mime_type?: string } | undefined
  const fotos = message.photo as { file_id: string; width: number }[] | undefined
  const maiorFoto = fotos?.slice().sort((a, b) => b.width - a.width)[0]

  const fileId = doc?.file_id ?? maiorFoto?.file_id
  if (!fileId) return

  const token = await tokenDaEmpresa(grupo.companyId)
  if (!token) return

  const baixado = await baixarArquivo(token, fileId)
  if (!baixado.ok) return

  const nome = doc?.file_name || baixado.nome
  const ext = (nome.split(".").pop() || "bin").toLowerCase()

  const blobToken =
    process.env.BLOB_READ_WRITE_TOKEN ||
    Object.entries(process.env).find(([k]) => k.endsWith("_READ_WRITE_TOKEN"))?.[1]
  if (!blobToken) return

  let url: string
  try {
    const caminho = `${grupo.companyId}/telegram/${Date.now()}-${nome.replace(/[^a-zA-Z0-9._-]/g, "_")}`
    // A Store pode estar em qualquer um dos dois modos; tenta público e cai
    // para privado, como no upload do site.
    let blob
    try {
      blob = await put(caminho, baixado.blob, { access: "public", token: blobToken, addRandomSuffix: true })
    } catch (e) {
      const m = e instanceof Error ? e.message : ""
      if (!/private access|public access on a private store/i.test(m)) throw e
      blob = await put(caminho, baixado.blob, { access: "private", token: blobToken, addRandomSuffix: true })
    }
    url = blob.url
  } catch {
    return
  }

  const obra = await prisma.obra.findUnique({
    where: { id: grupo.obraId },
    select: { anexos: true },
  })
  const atuais = Array.isArray(obra?.anexos) ? (obra.anexos as unknown as AnexoObra[]) : []

  const remetente = (message.from as { first_name?: string } | undefined)?.first_name ?? "Telegram"
  await prisma.obra.update({
    where: { id: grupo.obraId },
    data: {
      anexos: [
        ...atuais,
        { nome, url, ext, origem: `Telegram · ${remetente}`, em: new Date().toISOString() },
      ] as never,
    },
  })

  await enviarMensagem(token, String(chat.id), `Arquivo "${nome}" guardado nos anexos da obra.`)
}


/**
 * /start <codigo> na conversa privada liga aquele Telegram a um usuário.
 *
 * O código é sorteado, vale uma vez e expira. Vincular pelo id do usuário
 * seria mais simples e abriria a porta para alguém com o link receber os
 * avisos de outra pessoa.
 */
async function vincularConversaPrivada(message: Record<string, unknown>) {
  const chat = message.chat as { id: number } | undefined
  const texto = (message.text ?? "").toString().trim()
  const de = message.from as { username?: string; first_name?: string } | undefined
  if (!chat) return

  const chatId = String(chat.id)
  const token = await (async () => {
    const c = await prisma.company.findFirst({
      where: { telegram_bot_token: { not: null } },
      select: { telegram_bot_token: true },
    })
    return c?.telegram_bot_token ?? null
  })()

  const codigo = texto.startsWith("/start") ? texto.slice(6).trim() : ""
  if (!codigo) {
    if (token) {
      await enviarMensagem(token, chatId,
        "Para receber os avisos das propostas, abra o seu perfil no sistema e"
        + " use o botão Conectar Telegram. Ele gera o link certo.")
    }
    return
  }

  const usuario = await prisma.user.findFirst({
    where: { telegram_link_code: codigo },
    select: { id: true, nome: true, companyId: true, telegram_link_expira: true },
  })
  /* Código vencido não vira vínculo silencioso: quem tentou precisa saber que
     tem de gerar outro, senão fica esperando um aviso que nunca chega. */
  const vencido = !usuario?.telegram_link_expira
    || usuario.telegram_link_expira.getTime() < Date.now()
  if (!usuario || vencido) {
    if (token) {
      await enviarMensagem(token, chatId,
        "Este link expirou. Gere outro no seu perfil, em Conectar Telegram.")
    }
    return
  }

  await prisma.user.update({
    where: { id: usuario.id },
    data: {
      telegram_chat_id: chatId,
      telegram_username: de?.username ?? de?.first_name ?? null,
      // Uso único: o código morre aqui.
      telegram_link_code: null,
      telegram_link_expira: null,
    },
  })

  const tokenDaConta = await tokenDaEmpresa(usuario.companyId)
  if (tokenDaConta) {
    await enviarMensagem(tokenDaConta, chatId,
      `Pronto, ${usuario.nome ?? ""}. Os avisos das propostas chegam por aqui.`)
  }
}
