import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { conectarDrive } from "@/lib/google-drive"

export const dynamic = "force-dynamic"

/**
 * Volta do consentimento do Google e guarda o acesso ao Drive.
 *
 * Não exige sessão: quem chama é o Google, não o navegador logado. A empresa
 * vem no `state`, e é por isso que ele precisa ser um id que já existe — o
 * valor é conferido contra o banco antes de qualquer gravação.
 */
export async function GET(req: NextRequest) {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"
  const destino = (estado: string) => NextResponse.redirect(`${appUrl}/configuracoes?drive=${estado}`)

  const { searchParams } = new URL(req.url)
  const code = searchParams.get("code")
  const companyId = searchParams.get("state")
  // Recusou o consentimento na tela do Google: não é erro, é uma decisão.
  if (searchParams.get("error")) return destino("cancelado")
  if (!code || !companyId) return destino("erro")

  const empresa = await prisma.company.findUnique({
    where: { id: companyId },
    select: { nome_empresa: true, google_client_id: true, google_client_secret: true },
  })
  if (!empresa) return destino("erro")

  const clientId = empresa.google_client_id || process.env.GOOGLE_CLIENT_ID
  const clientSecret = empresa.google_client_secret || process.env.GOOGLE_CLIENT_SECRET
  if (!clientId || !clientSecret) return destino("sem-credencial")

  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      code,
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: `${appUrl}/api/integracoes/google/drive/callback`,
      grant_type: "authorization_code",
    }),
  })
  if (!r.ok) return destino("token-erro")

  const tokens = await r.json() as { access_token?: string; refresh_token?: string }
  /* Sem refresh token o acesso morre em uma hora e o cron da madrugada nunca
     funciona. Acontece quando a conta já autorizou antes e o Google reaproveita
     o consentimento — daí o prompt=consent no pedido. */
  if (!tokens.refresh_token || !tokens.access_token) return destino("sem-refresh")

  const pasta = await conectarDrive(
    companyId, tokens.refresh_token, tokens.access_token, empresa.nome_empresa ?? "Controllares",
  )
  return destino(pasta ? "ok" : "pasta-erro")
}
