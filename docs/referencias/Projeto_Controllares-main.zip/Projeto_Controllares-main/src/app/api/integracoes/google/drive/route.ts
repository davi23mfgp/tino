import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { ESCOPO_DRIVE, desconectarDrive, enviarParaDrive, limparNoDrive } from "@/lib/google-drive"

export const dynamic = "force-dynamic"

/**
 * Conexão do Google Drive da empresa.
 *
 * GET    — estado da conexão, para a tela de Integrações.
 * POST   — devolve a URL de autorização do Google.
 * DELETE — esquece o acesso (os arquivos já enviados ficam no Drive).
 *
 * Só Admin: o Drive conectado aqui recebe a base inteira da empresa.
 */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const empresa = await prisma.company.findUnique({
    where: { id: session.companyId },
    select: {
      drive_refresh_token: true, drive_pasta_nome: true,
      drive_conectado_em: true, drive_ultimo_envio: true,
    },
  })

  return NextResponse.json({
    conectado: !!empresa?.drive_refresh_token,
    pasta: empresa?.drive_pasta_nome ?? null,
    conectadoEm: empresa?.drive_conectado_em ?? null,
    ultimoEnvio: empresa?.drive_ultimo_envio ?? null,
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin conecta o Drive." }, { status: 403 })
  }

  const { acao } = await req.json().catch(() => ({ acao: "autorizar" }))

  /* Enviar agora: prova que a conexão funciona sem esperar a madrugada. Quem
     acabou de conectar precisa ver o arquivo aparecer no Drive. */
  if (acao === "testar") {
    const envio = await enviarParaDrive(
      session.companyId,
      `${new Date().toISOString().slice(0, 10)}-teste-conexao.json`,
      JSON.stringify({ teste: true, em: new Date().toISOString() }, null, 2),
    )
    if ("erro" in envio) return NextResponse.json({ error: envio.erro }, { status: 400 })
    return NextResponse.json({ ok: true, url: envio.url })
  }

  if (acao === "limpar") {
    return NextResponse.json({ ok: true, apagados: await limparNoDrive(session.companyId, 30) })
  }

  const empresa = await prisma.company.findUnique({
    where: { id: session.companyId },
    select: { google_client_id: true },
  })
  const clientId = empresa?.google_client_id || process.env.GOOGLE_CLIENT_ID
  if (!clientId) {
    return NextResponse.json({
      error: "Falta o Client ID do Google. Configure em Integrações antes de conectar.",
    }, { status: 400 })
  }

  const appUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"
  const url = new URL("https://accounts.google.com/o/oauth2/v2/auth")
  url.searchParams.set("client_id", clientId)
  url.searchParams.set("redirect_uri", `${appUrl}/api/integracoes/google/drive/callback`)
  url.searchParams.set("response_type", "code")
  url.searchParams.set("scope", ESCOPO_DRIVE)
  /* `consent` + `offline`: sem os dois o Google devolve refresh token só na
     primeira autorização da conta, e a segunda conexão fica sem token para o
     cron usar — falhando de madrugada, quando ninguém vê. */
  url.searchParams.set("access_type", "offline")
  url.searchParams.set("prompt", "consent")
  url.searchParams.set("state", session.companyId)

  return NextResponse.json({ url: url.toString() })
}

export async function DELETE() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin desconecta o Drive." }, { status: 403 })
  }
  await desconectarDrive(session.companyId)
  return NextResponse.json({ ok: true })
}
