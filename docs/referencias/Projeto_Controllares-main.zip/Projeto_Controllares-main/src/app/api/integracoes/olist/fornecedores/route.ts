import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { chamarV2, tokenDaEmpresa, pausa, INTERVALO_MS, ErroOlist, ehDuplicidade } from "@/lib/olist-v2"

export const dynamic = "force-dynamic"
export const maxDuration = 60

/**
 * Espelha os fornecedores daqui no Olist, como contatos do tipo Fornecedor.
 *
 * O catálogo já sobe com a marca no produto, mas a marca é texto solto: não dá
 * para lançar uma compra nem uma conta a pagar contra ela. O fornecedor
 * precisa existir como contato para o Olist amarrar entrada de nota e
 * pagamento ao mesmo cadastro.
 *
 * Só CRIA. Um fornecedor já cadastrado lá pode ter histórico de compra, e
 * sobrescrever dados por engano estraga o que não é nosso.
 */

/** Nomes de fornecedor já cadastrados no Olist, em minúsculas para comparar. */
async function fornecedoresNoOlist(token: string): Promise<Set<string>> {
  const nomes = new Set<string>()
  let pagina = 1
  let paginas = 1
  do {
    const ret = await chamarV2(token, "contatos.pesquisa.php", { pagina: String(pagina) })
    if (ret.vazio) break
    const lista = (ret.contatos ?? []) as { contato?: { nome?: string } }[]
    for (const x of lista) if (x.contato?.nome) nomes.add(x.contato.nome.trim().toLowerCase())
    paginas = Number(ret.numero_paginas ?? 1) || 1
    pagina++
    if (pagina <= paginas) await pausa(INTERVALO_MS)
  } while (pagina <= paginas && pagina <= 50)
  return nomes
}

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Sem permissão para integrar com o Olist." }, { status: 403 })
  }
  const token = await tokenDaEmpresa(session.companyId)
  if (!token) {
    return NextResponse.json(
      { error: "Preencha o token do Olist em Configurações → Integrações." }, { status: 422 })
  }

  const nossos = await prisma.supplier.findMany({
    where: { companyId: session.companyId },
    select: { nome: true },
  })
  const la = await fornecedoresNoOlist(token)
  const faltando = nossos.filter(f => !la.has(f.nome.trim().toLowerCase()))

  return NextResponse.json({
    nossos: nossos.length,
    noOlist: la.size,
    faltando: faltando.length,
    amostra: faltando.slice(0, 10).map(f => f.nome),
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin sincroniza fornecedores." }, { status: 403 })
  }
  const token = await tokenDaEmpresa(session.companyId)
  if (!token) {
    return NextResponse.json(
      { error: "Preencha o token do Olist em Configurações → Integrações." }, { status: 422 })
  }

  const { lote = 20 } = await req.json().catch(() => ({}))

  const nossos = await prisma.supplier.findMany({
    where: { companyId: session.companyId },
    select: { nome: true, prefixo: true },
    orderBy: { nome: "asc" },
  })
  const la = await fornecedoresNoOlist(token)
  const faltando = nossos.filter(f => !la.has(f.nome.trim().toLowerCase()))
  const daVez = faltando.slice(0, Math.min(Number(lote) || 20, 30))

  const criados: string[] = []
  const falhas: { nome: string; erro: string }[] = []
  let bloqueado = false

  for (const [i, f] of daVez.entries()) {
    if (i > 0) await pausa(INTERVALO_MS)
    try {
      await chamarV2(token, "contato.incluir.php", {
        contato: JSON.stringify({
          contatos: [{
            contato: {
              sequencia: 1,
              nome: f.nome,
              /* O prefixo do SKU é o código do fornecedor aqui dentro. Levar
                 junto deixa os dois lados com a mesma chave de conferência. */
              codigo: f.prefixo,
              /* Fornecedor daqui é sempre empresa; sem documento o Olist aceita
                 e o cadastro fica pendente de completar lá, que é melhor que
                 não existir. */
              tipo_pessoa: "J",
              situacao: "A",
              tipos_contato: [{ tipo: "Fornecedor" }],
            },
          }],
        }),
      })
      criados.push(f.nome)
    } catch (e) {
      const msg = e instanceof ErroOlist ? e.message : "falha desconhecida"
      // Duplicidade é estar lá — o efeito desejado, não uma falha.
      if (ehDuplicidade(msg)) { criados.push(f.nome); continue }
      falhas.push({ nome: f.nome, erro: msg })
      if (e instanceof ErroOlist && e.bloqueio) { bloqueado = true; break }
    }
  }

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "CRIAR",
      descricao: `Olist: ${criados.length} fornecedor(es) enviados`
        + (falhas.length ? ` — ${falhas.length} falha(s)` : ""),
    },
  }).catch(() => {})

  return NextResponse.json({
    criados, falhas, bloqueado,
    restantes: Math.max(0, faltando.length - criados.length),
  })
}
