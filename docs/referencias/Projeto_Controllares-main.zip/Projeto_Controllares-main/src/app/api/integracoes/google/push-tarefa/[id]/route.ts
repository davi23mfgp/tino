import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

async function getValidToken(userId: string, clientId: string, clientSecret: string, accessToken: string, refreshToken: string | null, expiry: Date | null): Promise<string | null> {
  if (!expiry || expiry > new Date()) return accessToken
  if (!refreshToken) return null
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ client_id: clientId, client_secret: clientSecret, refresh_token: refreshToken, grant_type: "refresh_token" }).toString(),
  })
  if (!res.ok) return null
  const data = await res.json()
  const newExpiry = new Date(Date.now() + (data.expires_in ?? 3600) * 1000)
  await prisma.user.update({ where: { id: userId }, data: { google_access_token: data.access_token, google_token_expiry: newExpiry } })
  return data.access_token as string
}

function addHour(hhmm: string): string {
  const [h, m] = hhmm.split(":").map(Number)
  return `${String((h + 1) % 24).padStart(2, "0")}:${String(m).padStart(2, "0")}`
}

/**
 * POST /api/integracoes/google/push-tarefa/[id]
 * Cria (ou atualiza) um evento no Google Calendar a partir de uma tarefa do ERP.
 */
export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params

  const [user, tarefa] = await Promise.all([
    prisma.user.findUnique({
      where: { id: session.userId },
      include: { company: { select: { google_client_id: true, google_client_secret: true } } },
    }),
    prisma.tarefa.findFirst({
      where: { id, companyId: session.companyId },
      include: { obra: { select: { client_name: true, address: true } } },
    }),
  ])

  if (!user) return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
  if (!tarefa) return NextResponse.json({ error: "Tarefa não encontrada" }, { status: 404 })
  if (!tarefa.dataVenc) return NextResponse.json({ error: "Defina um prazo (data) na tarefa antes de enviar ao Google." }, { status: 422 })

  if (!user.google_access_token) {
    return NextResponse.json({ error: "Google Calendar não conectado. Conecte em Configurações → Integrações." }, { status: 422 })
  }
  const clientId = user.company.google_client_id
  const clientSecret = user.company.google_client_secret
  if (!clientId || !clientSecret) {
    return NextResponse.json({ error: "Credenciais do Google não configuradas." }, { status: 422 })
  }

  const token = await getValidToken(user.id, clientId, clientSecret, user.google_access_token, user.google_refresh_token, user.google_token_expiry)
  if (!token) return NextResponse.json({ error: "Token Google expirado. Reconecte em Configurações." }, { status: 422 })

  const dia = tarefa.dataVenc.toISOString().slice(0, 10)
  const isAllDay = !tarefa.horaInicio

  const startDateTime = tarefa.horaInicio ? `${dia}T${tarefa.horaInicio}:00` : dia
  const endDateTime = tarefa.horaFim
    ? `${dia}T${tarefa.horaFim}:00`
    : tarefa.horaInicio
    ? `${dia}T${addHour(tarefa.horaInicio)}:00`
    : dia

  const descParts: string[] = []
  if (tarefa.descricao) descParts.push(tarefa.descricao)
  if (tarefa.obra) descParts.push(`Obra: ${tarefa.obra.client_name}`)
  descParts.push("— enviado do Controllares ERP")

  // Mapeia categoria ERP → colorId Google Calendar
  // 1=Lavanda 2=Sálvia 3=Uva 4=Flamingo 5=Banana 6=Tangerina 7=Pavão 8=Grafite 9=Mirtilo 10=Manjericão 11=Tomate
  // Cores alinhadas com as pills da Agenda do site:
  // Geral=cinza, Admin=roxo, Financeiro=verde, Operacional=laranja, Comercial=azul, Engenharia=violeta
  const colorMap: Record<string, string> = {
    GERAL: "8",         // Grafite (cinza)
    ADMIN: "3",         // Uva (roxo)
    FINANCEIRO: "2",    // Sálvia (verde)
    OPERACIONAL: "6",   // Tangerina (laranja)
    COMERCIAL: "7",     // Pavão (azul)
    ENGENHARIA: "1",    // Lavanda (violeta)
  }
  const colorId = colorMap[tarefa.categoria] ?? "8"

  const event = {
    summary: tarefa.obra ? `[${tarefa.categoria}] ${tarefa.titulo} — ${tarefa.obra.client_name}` : `[${tarefa.categoria}] ${tarefa.titulo}`,
    location: tarefa.obra?.address ?? "",
    description: descParts.join("\n"),
    colorId,
    ...(isAllDay
      ? { start: { date: dia }, end: { date: dia } }
      : { start: { dateTime: startDateTime, timeZone: "America/Sao_Paulo" }, end: { dateTime: endDateTime, timeZone: "America/Sao_Paulo" } }),
  }

  const base = "https://www.googleapis.com/calendar/v3/calendars/primary/events"
  let res: Response
  if (tarefa.google_event_id) {
    res = await fetch(`${base}/${tarefa.google_event_id}`, {
      method: "PUT",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify(event),
    })
    if (res.status === 404) {
      // foi apagado no Google → recria
      res = await fetch(base, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify(event),
      })
    }
  } else {
    res = await fetch(base, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify(event),
    })
  }

  if (!res.ok) {
    const errBody = await res.json().catch(() => ({}))
    console.error("[push-tarefa] Google Calendar error:", res.status, JSON.stringify(errBody))
    const msg = (errBody?.error?.message as string) || "Falha ao enviar para o Google Calendar."
    return NextResponse.json({ error: msg }, { status: 502 })
  }

  const data = await res.json()
  await prisma.tarefa.update({ where: { id }, data: { google_event_id: data.id } })

  return NextResponse.json({ success: true, google_event_id: data.id, link: data.htmlLink })
}

/**
 * DELETE /api/integracoes/google/push-tarefa/[id]
 * Remove o evento espelhado no Google Calendar (mantém a tarefa no ERP).
 */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const [user, tarefa] = await Promise.all([
    prisma.user.findUnique({
      where: { id: session.userId },
      include: { company: { select: { google_client_id: true, google_client_secret: true } } },
    }),
    prisma.tarefa.findFirst({ where: { id, companyId: session.companyId } }),
  ])

  if (!tarefa?.google_event_id || !user?.google_access_token) {
    return NextResponse.json({ success: true })
  }
  const clientId = user.company.google_client_id
  const clientSecret = user.company.google_client_secret
  if (clientId && clientSecret) {
    const token = await getValidToken(user.id, clientId, clientSecret, user.google_access_token, user.google_refresh_token, user.google_token_expiry)
    if (token) {
      await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events/${tarefa.google_event_id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      }).catch(() => {})
    }
  }
  await prisma.tarefa.update({ where: { id }, data: { google_event_id: null } })
  return NextResponse.json({ success: true })
}
