import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

const SCOPES = "https://www.googleapis.com/auth/calendar.events"

/**
 * GET /api/integracoes/google/auth
 * Gera a URL de autorização OAuth2 do Google e redireciona o usuário.
 */
export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const company = await prisma.company.findUnique({
    where: { id: session.companyId },
    select: { google_client_id: true },
  })

  // Usa o client da empresa; se vazio, cai no client global do app (mesmo do login).
  const clientId = company?.google_client_id || process.env.GOOGLE_CLIENT_ID
  if (!clientId) {
    return NextResponse.json(
      { error: "Client ID do Google não configurado. Vá em Configurações → Integrações." },
      { status: 422 }
    )
  }

  // Redirect_uri FIXO (APP_URL) — nunca deriva da origem da requisição.
  // Vercel troca o domínio de preview a cada deploy; usar req.url quebrava
  // o OAuth porque o Google só aceita o redirect_uri whitelistado no Console.
  const appUrl = process.env.APP_URL || new URL(req.url).origin
  const redirectUri = `${appUrl}/api/integracoes/google/callback`

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: SCOPES,
    access_type: "offline",
    prompt: "consent",
    state: session.userId, // passa userId no state para recuperar no callback
  })

  return NextResponse.redirect(
    `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`
  )
}
