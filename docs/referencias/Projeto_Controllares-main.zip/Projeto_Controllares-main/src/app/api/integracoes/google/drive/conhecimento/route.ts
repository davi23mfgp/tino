import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { listarPastas } from "@/lib/google-drive"
import { sincronizarConhecimento } from "@/lib/ai/conhecimento-drive"

export const dynamic = "force-dynamic"
/* Indexar uma pasta com muitos manuais leva minutos: baixar, extrair texto e
   vetorizar cada um. O limite padrão da Vercel cortaria no meio, deixando parte
   dos documentos indexada e parte não. */
export const maxDuration = 300

/**
 * Pasta do Drive que alimenta a base de conhecimento do CORE.
 *
 * GET   — pastas disponíveis e qual está escolhida.
 * PUT   — escolhe a pasta.
 * POST  — sincroniza agora.
 */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const empresa = await prisma.company.findUnique({
    where: { id: session.companyId },
    select: {
      drive_refresh_token: true, drive_conhecimento_id: true,
      drive_conhecimento_nome: true, drive_conhecimento_sync: true,
    },
  })

  const [documentos, pastas] = await Promise.all([
    prisma.knowledgeDoc.count({ where: { companyId: session.companyId, drive_file_id: { not: null } } }),
    empresa?.drive_refresh_token ? listarPastas(session.companyId) : Promise.resolve([]),
  ])

  return NextResponse.json({
    conectado: !!empresa?.drive_refresh_token,
    pastaId: empresa?.drive_conhecimento_id ?? null,
    pastaNome: empresa?.drive_conhecimento_nome ?? null,
    ultimaSync: empresa?.drive_conhecimento_sync ?? null,
    documentos,
    pastas,
  })
}

export async function PUT(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin escolhe a pasta." }, { status: 403 })
  }

  const { pastaId, pastaNome } = await req.json().catch(() => ({}))
  await prisma.company.update({
    where: { id: session.companyId },
    data: {
      drive_conhecimento_id: pastaId || null,
      drive_conhecimento_nome: pastaNome || null,
    },
  })
  return NextResponse.json({ ok: true })
}

export async function POST() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin sincroniza." }, { status: 403 })
  }

  const r = await sincronizarConhecimento(session.companyId)
  return NextResponse.json(r)
}
