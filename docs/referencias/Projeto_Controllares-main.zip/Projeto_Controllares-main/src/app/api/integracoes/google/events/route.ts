import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export interface GoogleEvent {
  id: string
  titulo: string
  data: string        // YYYY-MM-DD
  horaInicio: string | null
  horaFim: string | null
  local: string | null
  descricao: string | null
  link: string | null
  colorId: string | null  // colorId do Google Calendar (1-11)
}

async function getValidToken(userId: string, clientId: string, clientSecret: string, accessToken: string, refreshToken: string | null, expiry: Date | null): Promise<string | null> {
  if (!expiry || expiry > new Date()) return accessToken
  if (!refreshToken) return null
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ client_id: clientId, client_secret: clientSecret, refresh_token: refreshToken, grant_type: "refresh_token" }).toString(),
  })
  if (!res.ok) return null
  const data = await res.json()
  const newExpiry = new Date(Date.now() + (data.expires_in ?? 3600) * 1000)
  await prisma.user.update({ where: { id: userId }, data: { google_access_token: data.access_token, google_token_expiry: newExpiry } })
  return data.access_token as string
}

/**
 * GET /api/integracoes/google/events?start=YYYY-MM-DD&end=YYYY-MM-DD
 * Busca eventos do Google Calendar do usuário logado para o intervalo.
 */
export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const start = searchParams.get("start") // YYYY-MM-DD
  const end = searchParams.get("end")     // YYYY-MM-DD

  if (!start || !end) return NextResponse.json({ error: "Parâmetros start e end obrigatórios" }, { status: 400 })

  const user = await prisma.user.findUnique({
    where: { id: session.userId },
    include: { company: { select: { google_client_id: true, google_client_secret: true } } },
  })

  if (!user?.google_access_token) {
    return NextResponse.json({ eventos: [], conectado: false })
  }

  const clientId = user.company.google_client_id || process.env.GOOGLE_CLIENT_ID
  const clientSecret = user.company.google_client_secret || process.env.GOOGLE_CLIENT_SECRET
  if (!clientId || !clientSecret) return NextResponse.json({ eventos: [], conectado: false })

  const token = await getValidToken(user.id, clientId, clientSecret, user.google_access_token, user.google_refresh_token, user.google_token_expiry)
  if (!token) return NextResponse.json({ eventos: [], conectado: false, tokenExpirado: true })

  const timeMin = `${start}T00:00:00-03:00`
  const timeMax = `${end}T23:59:59-03:00`

  const res = await fetch(
    `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${encodeURIComponent(timeMin)}&timeMax=${encodeURIComponent(timeMax)}&singleEvents=true&orderBy=startTime&maxResults=250`,
    { headers: { Authorization: `Bearer ${token}` } }
  )

  if (!res.ok) return NextResponse.json({ eventos: [], erro: "Falha ao buscar eventos do Google" })

  const data = await res.json()
  const eventos: GoogleEvent[] = (data.items ?? []).map((item: Record<string, unknown>) => {
    const start = item.start as Record<string, string> | undefined
    const end = item.end as Record<string, string> | undefined
    const isAllDay = !!start?.date && !start?.dateTime
    const dataStr: string = isAllDay ? (start?.date ?? "") : ((start?.dateTime ?? "") as string).slice(0, 10)
    const horaInicio = isAllDay ? null : ((start?.dateTime ?? "") as string).slice(11, 16)
    const horaFim = isAllDay ? null : ((end?.dateTime ?? "") as string).slice(11, 16)
    return {
      id: item.id as string,
      titulo: (item.summary as string) ?? "(sem título)",
      data: dataStr,
      horaInicio,
      horaFim,
      local: (item.location as string | null) ?? null,
      descricao: (item.description as string | null) ?? null,
      link: (item.htmlLink as string | null) ?? null,
      colorId: (item.colorId as string | null) ?? null,
    }
  })

  return NextResponse.json({ eventos, conectado: true })
}
