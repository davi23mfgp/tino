import { NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { desconectar } from "@/lib/plaud"

export const dynamic = "force-dynamic"

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin vê a conexão do Plaud." }, { status: 403 })
  }

  const [c, reunioes] = await Promise.all([
    prisma.company.findUnique({
      where: { id: session.companyId },
      select: { plaud_access_token: true, plaud_token_expiry: true, plaud_ultimo_sync: true },
    }),
    prisma.reuniao.count({ where: { companyId: session.companyId } }),
  ])

  return NextResponse.json({
    conectado: !!c?.plaud_access_token,
    expiraEm: c?.plaud_token_expiry ?? null,
    ultimoSync: c?.plaud_ultimo_sync ?? null,
    reunioes,
  })
}

/** Desconectar revoga também do lado do Plaud, não só apaga daqui. */
export async function DELETE() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin desconecta o Plaud." }, { status: 403 })
  }
  await desconectar(session.companyId)
  return NextResponse.json({ ok: true })
}
