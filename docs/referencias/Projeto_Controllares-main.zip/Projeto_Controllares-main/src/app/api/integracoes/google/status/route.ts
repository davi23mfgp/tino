import { NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * GET /api/integracoes/google/status
 * Retorna se o usuário logado tem Google Calendar conectado.
 */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const user = await prisma.user.findUnique({
    where: { id: session.userId },
    select: { google_access_token: true, google_token_expiry: true },
  })

  const conectado = !!user?.google_access_token
  const expirado = user?.google_token_expiry ? user.google_token_expiry < new Date() : false

  return NextResponse.json({ conectado, expirado })
}
