import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { ehDuplicidade } from "@/lib/olist-v2"

export const dynamic = "force-dynamic"
export const maxDuration = 60

/**
 * Espelha o catálogo daqui no Olist.
 *
 * GET  — quantos produtos existem de cada lado e quais faltam lá.
 * POST — cria no Olist os que faltam, em lotes.
 *
 * Só CRIA. Nunca altera nem exclui nada que já esteja no Olist: um produto
 * cadastrado lá pode estar amarrado a pedido, nota e saldo de estoque, e
 * sobrescrever preço ou situação por engano estraga histórico que não é nosso.
 * A regra é o SKU — existe lá, pula; não existe, cria.
 *
 * Roda em lotes porque a v2 aceita um produto por requisição e o catálogo tem
 * centenas: uma requisição só estouraria o tempo da função. O front chama de
 * novo até `restantes` chegar a zero.
 */
const API = "https://api.tiny.com.br/api2"

/* A v2 limita chamadas por minuto e responde "API Bloqueada - Excedido o
   número de acessos" quando o lote dispara sem respiro. Uma pausa entre as
   inclusões mantém o ritmo abaixo do teto: com ~1s por produto, 25 por lote
   cabem folgados nos 60s da função. */
const pausa = (ms: number) => new Promise(r => setTimeout(r, ms))
const INTERVALO_MS = 1_100

async function chamarV2(token: string, endpoint: string, extra: Record<string, string> = {}) {
  const form = new URLSearchParams({ token, formato: "json", ...extra })
  const r = await fetch(`${API}/${endpoint}`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: form.toString(),
    signal: AbortSignal.timeout(20_000),
  })
  const bruto = await r.text()
  try { return JSON.parse(bruto).retorno as Record<string, unknown> }
  catch { throw new Error(`Olist respondeu algo que não é JSON: ${bruto.slice(0, 150)}`) }
}

/** Todos os códigos já cadastrados no Olist, percorrendo as páginas. */
async function codigosNoOlist(token: string): Promise<Set<string>> {
  const codigos = new Set<string>()
  let pagina = 1
  let paginas = 1
  do {
    const ret = await chamarV2(token, "produtos.pesquisa.php", { pagina: String(pagina) })
    // "A consulta não retornou registros" é resposta de catálogo vazio, não falha.
    const lista = (ret?.produtos ?? []) as { produto?: { codigo?: string } }[]
    for (const x of lista) if (x.produto?.codigo) codigos.add(x.produto.codigo)
    paginas = Number(ret?.numero_paginas ?? 1) || 1
    pagina++
  } while (pagina <= paginas && pagina <= 50)   // trava de segurança
  return codigos
}

/**
 * Estrutura (produto composto) só com componentes que o Olist já conhece.
 *
 * Ele recusa a estrutura inteira quando um item não existe lá, e a recusa
 * derruba o produto principal junto. Estrutura vazia também é recusada, então
 * quando nada sobra o campo simplesmente não vai.
 */
type ComComponentes = {
  componentes?: { quantidade: number; componente: { sku: string; nome: string } | null }[]
}
function estruturaDe(p: ComComponentes, laNoOlist: Set<string>) {
  const itens = (p.componentes ?? [])
    .filter(c => c.componente?.sku && laNoOlist.has(c.componente.sku))
    .map(c => ({
      item: {
        codigo: c.componente!.sku,
        descricao: c.componente!.nome,
        quantidade: c.quantidade,
      },
    }))
  return itens.length ? { estrutura: itens } : {}
}

async function empresaComToken(companyId: string) {
  const c = await prisma.company.findUnique({
    where: { id: companyId },
    select: { tiny_api_token: true },
  })
  return c?.tiny_api_token ?? null
}

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Sem permissão para integrar com o Olist." }, { status: 403 })
  }
  const token = await empresaComToken(session.companyId)
  if (!token) {
    return NextResponse.json(
      { error: "Preencha o token do Olist em Configurações → Integrações." }, { status: 422 })
  }

  const nossos = await prisma.catalogProduct.findMany({
    where: { companyId: session.companyId, status: "ATIVO" },
    select: { sku: true },
  })
  const laNoOlist = await codigosNoOlist(token)
  const faltando = nossos.filter(p => p.sku && !laNoOlist.has(p.sku))

  return NextResponse.json({
    nossos: nossos.length,
    noOlist: laNoOlist.size,
    faltando: faltando.length,
    amostra: faltando.slice(0, 10).map(p => p.sku),
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin sincroniza o catálogo." }, { status: 403 })
  }
  const token = await empresaComToken(session.companyId)
  if (!token) {
    return NextResponse.json(
      { error: "Preencha o token do Olist em Configurações → Integrações." }, { status: 422 })
  }

  // Lote pequeno: cada produto é uma requisição, e a função tem 60s.
  const { lote = 20 } = await req.json().catch(() => ({}))

  const nossos = await prisma.catalogProduct.findMany({
    where: { companyId: session.companyId, status: "ATIVO" },
    select: {
      sku: true, nome: true, marca: true, unidade: true, gtin: true, ncm: true,
      cest: true, origem: true, preco_venda: true, preco_custo: true,
      descricao: true, peso_kg: true, garantia_dias: true, estoque_qtd: true,
      imagem_url: true, largura_mm: true, altura_mm: true, profundidade_mm: true,
      estoque_minimo: true,
      category: { select: { nome: true } },
      componentes: { select: { quantidade: true, componente: { select: { sku: true, nome: true } } } },
    },
    orderBy: { sku: "asc" },
  })
  const laNoOlist = await codigosNoOlist(token)
  const faltando = nossos.filter(p => p.sku && !laNoOlist.has(p.sku))
  const daVez = faltando.slice(0, Math.min(Number(lote) || 20, 30))

  const criados: string[] = []
  const falhas: { sku: string; erro: string }[] = []

  for (const [i, p] of daVez.entries()) {
    if (i > 0) await pausa(INTERVALO_MS)
    try {
      const ret = await chamarV2(token, "produto.incluir.php", {
        produto: JSON.stringify({
          produtos: [{
            produto: {
              sequencia: 1,
              codigo: p.sku,
              nome: p.nome,
              tipo: "P",
              situacao: "A",
              unidade: p.unidade || "UN",
              preco: Number(p.preco_venda ?? 0),
              preco_custo: Number(p.preco_custo ?? 0),
              // Obrigatória: sem ela a resposta é "A origem do produto deve
              // ser informada". 0 = nacional.
              origem: p.origem || "0",
              ...(p.ncm ? { ncm: p.ncm } : {}),
              ...(p.cest ? { cest: p.cest } : {}),
              ...(p.gtin ? { gtin: p.gtin } : {}),
              ...(p.marca ? { marca: p.marca } : {}),
              ...(p.descricao ? { descricao_complementar: p.descricao } : {}),
              ...(p.garantia_dias ? { garantia: `${p.garantia_dias} dias` } : {}),
              ...(p.peso_kg != null ? { peso_liquido: p.peso_kg, peso_bruto: p.peso_kg } : {}),
              /* Ficha técnica: medidas, categoria e foto. Iam de fora e o
                 produto chegava no Olist sem nada além de nome e preço — o que
                 obriga a consultar o catálogo daqui na hora de embalar. */
              ...(p.largura_mm ? { largura_embalagem: p.largura_mm / 10 } : {}),
              ...(p.altura_mm ? { altura_embalagem: p.altura_mm / 10 } : {}),
              ...(p.profundidade_mm ? { comprimento_embalagem: p.profundidade_mm / 10 } : {}),
              ...(p.estoque_minimo != null ? { estoque_minimo: p.estoque_minimo } : {}),
              ...(p.category?.nome ? { categoria: p.category.nome } : {}),
              /* A foto vai por URL: a v2 baixa da origem. Só entra endereço
                 público — link interno o Olist não alcança. */
              ...(p.imagem_url && /^https?:\/\//i.test(p.imagem_url)
                ? { imagens_externas: [{ imagem_externa: { url: p.imagem_url } }] } : {}),
              /* Produto composto vira estrutura no Olist. Só entra componente
                 que já exista lá — o Olist recusa estrutura com item que ele
                 não conhece, e derrubaria o produto principal junto. */
              ...(estruturaDe(p, laNoOlist)),
            },
          }],
        }),
      })
      if (ret?.status !== "OK") {
        const reg = (ret?.registros as { registro?: { erros?: unknown[] } }[] | undefined)
        const msgs: string[] = []
        for (const lista of [ret?.erros, reg?.[0]?.registro?.erros]) {
          if (!Array.isArray(lista)) continue
          for (const e of lista) msgs.push(typeof e === "string" ? e : String((e as { erro?: string })?.erro ?? ""))
        }
        const erro = msgs.filter(Boolean).join(", ") || "erro sem detalhe"
        /* Bloqueio por excesso de acesso não é falha do produto: insistir nos
           seguintes só aprofunda o bloqueio. Interrompe o lote e devolve o que
           sobrou, para o front chamar de novo depois. */
        if (/bloquead|excedido/i.test(erro)) {
          falhas.push({ sku: p.sku, erro: `${erro} — o envio continua no próximo lote.` })
          break
        }
        /* Duplicidade é o produto já estar lá. A conferência por SKU roda antes
           do lote, mas uma criação em paralelo (ou um SKU repetido no próprio
           catálogo) escapa dela. O efeito é o desejado — segue como criado. */
        if (ehDuplicidade(erro)) { criados.push(p.sku); continue }
        throw new Error(erro)
      }
      criados.push(p.sku)
    } catch (e) {
      falhas.push({ sku: p.sku, erro: e instanceof Error ? e.message : "falha desconhecida" })
    }
  }

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "CRIAR",
      descricao: `Olist: ${criados.length} produto(s) do catálogo enviados`
        + (falhas.length ? ` — ${falhas.length} falha(s)` : ""),
    },
  }).catch(() => {})

  /* Restantes conta o que REALMENTE entrou, não o tamanho do lote: quando o
     bloqueio interrompe no meio, os que sobraram precisam voltar na conta. */
  const bloqueado = falhas.some(f => /bloquead|excedido/i.test(f.erro))
  return NextResponse.json({
    criados,
    falhas,
    bloqueado,
    restantes: Math.max(0, faltando.length - criados.length),
  })
}
