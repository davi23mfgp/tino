import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { formatarDocumento } from "@/lib/documento"
import { chamarV2, tokenDaEmpresa, tipoPessoa, ErroOlist } from "@/lib/olist-v2"

export const dynamic = "force-dynamic"

/**
 * POST /api/integracoes/olist/contratos — Body: { proposalId }
 *
 * Manda ao Olist o contrato de uma proposta já assinada.
 *
 * O contrato vivia só aqui. Como o Olist é a cópia de segurança do que a
 * empresa fechou, um contrato que existe apenas neste banco é justamente o
 * documento que ninguém recupera se este banco sumir.
 *
 * Vai depois de assinado, não ao gerar: contrato gerado ainda muda, e o Olist
 * não é rascunho.
 */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Só Admin e Financeiro enviam contratos." }, { status: 403 })
  }

  const { proposalId } = await req.json().catch(() => ({}))
  if (!proposalId) return NextResponse.json({ error: "proposalId obrigatório" }, { status: 400 })

  const token = await tokenDaEmpresa(session.companyId)
  if (!token) {
    return NextResponse.json(
      { error: "Preencha o token do Olist em Configurações → Integrações." }, { status: 422 })
  }

  const proposal = await prisma.proposal.findFirst({
    where: { id: proposalId, companyId: session.companyId },
    include: {
      installments: { orderBy: { numero_parcela: "asc" } },
      vendedor: { select: { nome: true } },
    },
  })
  if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  if (!proposal.contrato_assinado_em) {
    return NextResponse.json(
      { error: "Marque o contrato como assinado antes de enviar ao Olist." }, { status: 422 })
  }
  if (proposal.olist_contrato_em) {
    return NextResponse.json({
      error: `Este contrato já foi enviado ao Olist em `
        + `${proposal.olist_contrato_em.toLocaleDateString("pt-BR")}.`,
      jaEnviado: true,
    }, { status: 409 })
  }

  const doc = (proposal.fat_documento ?? "").replace(/\D/g, "")

  /* Dia de vencimento e periodicidade: o Olist modela contrato como cobrança
     recorrente e exige os dois. Sem parcelas geradas, cai no dia de hoje e uma
     única cobrança — o que o contrato de obra é de fato. */
  const primeira = proposal.installments[0]
  const diaVencimento = primeira
    ? new Date(primeira.data_vencimento).getDate()
    : new Date().getDate()
  const nParcelas = proposal.installments.length || Math.max(1, proposal.parcelas_forma ?? 1)

  const contrato = {
    contrato: {
      data: (proposal.contrato_assinado_em ?? new Date()).toLocaleDateString("pt-BR"),
      descricao: `Proposta ${proposal.numero}`
        + (proposal.project_type ? ` — ${proposal.project_type}` : ""),
      cliente: {
        nome: proposal.fat_razao_social?.trim() || proposal.client_name || "",
        tipo_pessoa: tipoPessoa(proposal.fat_documento),
        ...(doc ? { cpf_cnpj: formatarDocumento(doc) } : {}),
        ...(proposal.fat_ie ? { ie: proposal.fat_ie } : {}),
        ...(proposal.fat_email || proposal.client_email
          ? { email: proposal.fat_email || proposal.client_email } : {}),
        ...(proposal.fat_logradouro ? { endereco: proposal.fat_logradouro } : {}),
        ...(proposal.fat_numero ? { numero: proposal.fat_numero } : {}),
        ...(proposal.fat_complemento ? { complemento: proposal.fat_complemento } : {}),
        ...(proposal.fat_bairro ? { bairro: proposal.fat_bairro } : {}),
        ...(proposal.fat_cep ? { cep: proposal.fat_cep } : {}),
        ...(proposal.fat_cidade ? { cidade: proposal.fat_cidade } : {}),
        ...(proposal.fat_uf ? { uf: proposal.fat_uf } : {}),
        /* Não atualiza o cadastro que já existe lá: o contato pode ter sido
           corrigido no Olist depois do pedido, e o dado de lá é o conferido. */
        atualizar_cliente: "N",
      },
      dia_vencimento: diaVencimento,
      valor: Number(Number(proposal.valor_total ?? 0).toFixed(2)),
      /* Mês de referência do vencimento. A documentação diz "M"; a API recusa
         com "O Mês de referência do vencimento do contrato não está entre os
         valores permitidos" e aceita "P" (mês posterior) — confirmado contra a
         API, não deduzido da documentação. */
      vencimento: "P",
      periodicidade: 1,
      nro_parcelas: nParcelas,
      // O contrato de obra não emite nota por si: quem emite é o pedido.
      emite_nota: "N",
      ...(proposal.vendedor?.nome ? { nome_vendedor: proposal.vendedor.nome } : {}),
      obs: [
        `Controllares — proposta ${proposal.numero}`,
        proposal.olist_pedido_numero ? `Pedido ${proposal.olist_pedido_numero}` : null,
        `Assinado em ${proposal.contrato_assinado_em.toLocaleDateString("pt-BR")}`,
      ].filter(Boolean).join(" | ").slice(0, 500),
    },
  }

  try {
    const ret = await chamarV2(token, "contrato.incluir.php", {
      contrato: JSON.stringify(contrato),
    })
    const numero = (ret.registros as { registro?: { id?: string; numero?: string } }[] | undefined)
      ?.[0]?.registro
    const idContrato = String(numero?.id ?? numero?.numero ?? "")

    await prisma.proposal.update({
      where: { id: proposal.id },
      data: { olist_contrato_em: new Date(), olist_contrato_numero: idContrato || null },
    })

    await prisma.aiAuditLog.create({
      data: {
        userId: session.userId, companyId: session.companyId, tipo_acesso: "CRIAR",
        descricao: `Olist: contrato da proposta ${proposal.numero} enviado`
          + (idContrato ? ` (id ${idContrato})` : ""),
      },
    }).catch(() => {})

    return NextResponse.json({ ok: true, idContrato })
  } catch (e) {
    const msg = e instanceof ErroOlist ? e.message : "falha na comunicação com o Olist"
    return NextResponse.json({ error: `Olist: ${msg}` }, { status: 422 })
  }
}
