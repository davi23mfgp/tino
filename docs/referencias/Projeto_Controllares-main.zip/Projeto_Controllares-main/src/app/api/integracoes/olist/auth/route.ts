import { NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { buildOlistAuthUrl } from "@/lib/olist"

/**
 * GET /api/integracoes/olist/auth
 * Inicia o fluxo OAuth2 do Olist (API V3). Só ADMIN conecta a conta da empresa.
 */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (session.role !== "ADMIN") {
    return NextResponse.json({ error: "Apenas ADMIN pode conectar o Olist" }, { status: 403 })
  }
  try {
    // state = companyId para recuperar no callback
    return NextResponse.redirect(buildOlistAuthUrl(session.companyId))
  } catch (e) {
    const msg = e instanceof Error ? e.message : "erro"
    const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000"
    return NextResponse.redirect(`${appUrl}/configuracoes?olist=erro&msg=${encodeURIComponent(msg)}`)
  }
}
