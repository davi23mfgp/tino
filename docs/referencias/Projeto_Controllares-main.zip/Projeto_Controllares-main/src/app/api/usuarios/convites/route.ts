import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { randomBytes } from "crypto"
import { enviarEmail } from "@/lib/email"
import { emailConvite } from "@/lib/email-templates"

const ROLES_VALIDAS = ["ADMIN", "VENDEDOR", "RESPONSAVEL_TECNICO", "ENGENHEIRO_PROJETOS", "INSTALADOR", "FINANCEIRO"]

/** GET /api/usuarios/convites — lista convites pendentes (ADMIN). */
export async function GET() {
  const session = await getSession()
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Não autorizado" }, { status: 403 })
  }
  // Pendentes válidos + aceitos (aceito aparece para poder REVOGAR o acesso)
  const invites = await prisma.invite.findMany({
    where: {
      companyId: session.companyId,
      OR: [{ usedAt: null, expiresAt: { gt: new Date() } }, { usedAt: { not: null } }],
    },
    orderBy: { createdAt: "desc" },
    select: { id: true, email: true, role: true, token: true, expiresAt: true, createdAt: true, usedAt: true },
  })
  return NextResponse.json({ invites })
}

/**
 * POST /api/usuarios/convites — cria convite { email, role } (ADMIN).
 * Retorna o link; se RESEND_API_KEY existir, também envia por e-mail.
 */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Não autorizado" }, { status: 403 })
  }

  // `nome` é opcional: só personaliza a saudação do e-mail.
  const { email, role, nome } = await req.json().catch(() => ({}))
  if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
    return NextResponse.json({ error: "E-mail inválido." }, { status: 400 })
  }
  if (!ROLES_VALIDAS.includes(role)) {
    return NextResponse.json({ error: "Categoria inválida." }, { status: 400 })
  }

  const emailLower = String(email).toLowerCase()
  const jaExiste = await prisma.user.findUnique({ where: { email: emailLower } })
  if (jaExiste) {
    return NextResponse.json({ error: "Já existe um usuário com esse e-mail." }, { status: 409 })
  }

  // Reaproveita convite pendente do mesmo e-mail (renova token/validade)
  const token = randomBytes(24).toString("hex")
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 dias
  const pendente = await prisma.invite.findFirst({
    where: { companyId: session.companyId, email: emailLower, usedAt: null },
  })
  const invite = pendente
    ? await prisma.invite.update({ where: { id: pendente.id }, data: { token, role, expiresAt } })
    : await prisma.invite.create({
        data: { email: emailLower, role, token, companyId: session.companyId, expiresAt },
      })

  const appUrl = process.env.APP_URL || "http://localhost:3000"
  const link = `${appUrl}/convite/${invite.token}`

  // Envio por e-mail (opcional — precisa de RESEND_API_KEY e domínio verificado)
  let emailEnviado = false
  if (process.env.RESEND_API_KEY) {
    try {
      const company = await prisma.company.findUnique({
        where: { id: session.companyId },
        select: { nome_empresa: true, email_contato: true },
      })
      // Quem convida assina o e-mail.
      const convidou = await prisma.user.findUnique({
        where: { id: session.userId }, select: { nome: true, role: true },
      })
      const { subject, html } = emailConvite({
        nomeColaborador: nome ?? null,
        perfil: role,
        link,
        empresa: company?.nome_empresa ?? "Controllares",
        remetenteNome: convidou?.nome ?? null,
        remetenteCargo: convidou?.role === "ADMIN" ? "Administrador" : null,
        emailContato: company?.email_contato ?? null,
        site: process.env.APP_URL?.replace(/^https?:\/\//, "") ?? null,
      })
      emailEnviado = await enviarEmail({ to: [emailLower], subject, html })
    } catch { /* sem e-mail — ADMIN copia o link */ }
  }

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "CRIAR",
      descricao: `Convite criado para ${emailLower} (${role})`,
    },
  }).catch(() => {})

  return NextResponse.json({ invite: { id: invite.id, email: invite.email, role: invite.role }, link, emailEnviado })
}
