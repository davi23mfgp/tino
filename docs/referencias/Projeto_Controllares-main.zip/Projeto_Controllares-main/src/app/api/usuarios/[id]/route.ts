import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import bcrypt from "bcryptjs"
import { rebaixarOutrosAdmins, registrarRebaixamento, type AdminRebaixado } from "@/lib/admin-unico"

const ROLES_VALIDOS = [
  "ADMIN", "VENDEDOR", "FINANCEIRO",
  "RESPONSAVEL_TECNICO", "INSTALADOR", "ENGENHEIRO_PROJETOS",
]

/**
 * PATCH /api/usuarios/[id] — edita nome, role ou senha de um usuário (só ADMIN)
 * DELETE /api/usuarios/[id] — remove usuário (só ADMIN, não pode remover a si mesmo)
 */
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (session.role !== "ADMIN") return NextResponse.json({ error: "Sem permissão" }, { status: 403 })

  const { id } = await params
  const body = await req.json()

  const user = await prisma.user.findFirst({ where: { id, companyId: session.companyId } })
  if (!user) return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })

  if (body.role && !ROLES_VALIDOS.includes(body.role)) {
    return NextResponse.json({ error: "Role inválido" }, { status: 400 })
  }
  // Perfis adicionais (multi-perfil): valida e remove o principal da lista de extras
  let rolesExtras: string[] | undefined
  if (Array.isArray(body.roles)) {
    if (body.roles.some((r: string) => !ROLES_VALIDOS.includes(r))) {
      return NextResponse.json({ error: "Perfil adicional inválido" }, { status: 400 })
    }
    const principal = body.role ?? user.role
    rolesExtras = [...new Set(body.roles as string[])].filter(r => r !== principal)
  }
  // ADMIN não pode desativar a si mesmo (trancaria a empresa para fora)
  if (body.status === "DESATIVADO" && id === session.userId) {
    return NextResponse.json({ error: "Você não pode desativar a própria conta." }, { status: 400 })
  }

  const updated = await prisma.user.update({
    where: { id },
    data: {
      ...(body.nome !== undefined && { nome: body.nome }),
      ...(body.role !== undefined && { role: body.role }),
      ...(rolesExtras !== undefined && { roles: rolesExtras as never }),
      ...(body.status !== undefined && ["ATIVO", "PENDENTE", "DESATIVADO"].includes(body.status) && { status: body.status }),
      ...(body.must_change_password !== undefined && { must_change_password: !!body.must_change_password }),
      ...(body.senha ? { senha: await bcrypt.hash(body.senha, 12) } : {}),
    },
    select: { id: true, nome: true, email: true, role: true, roles: true, status: true, createdAt: true },
  })

  // Um ADMIN ativo por empresa. Só troca de acesso — nenhuma proposta ou obra
  // é apagada, porque o conteúdo é da empresa e não de quem administra.
  let rebaixados: AdminRebaixado[] = []
  const virouAdmin = updated.role === "ADMIN" || updated.roles.includes("ADMIN")
  if (virouAdmin) {
    rebaixados = await rebaixarOutrosAdmins(session.companyId, updated.id)
    await registrarRebaixamento(session.companyId, session.userId, rebaixados)
  }

  if (body.status === "DESATIVADO") {
    await prisma.aiAuditLog.create({
      data: {
        userId: session.userId, companyId: session.companyId, tipo_acesso: "DADOS",
        descricao: `Desativou o usuário ${user.email}`,
      },
    }).catch(() => {})
  }

  return NextResponse.json({ ...updated, rebaixados })
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (session.role !== "ADMIN") return NextResponse.json({ error: "Sem permissão" }, { status: 403 })

  const { id } = await params

  if (id === session.userId) {
    return NextResponse.json({ error: "Você não pode remover a si mesmo" }, { status: 400 })
  }

  const user = await prisma.user.findFirst({ where: { id, companyId: session.companyId } })
  if (!user) return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })

  await prisma.user.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
