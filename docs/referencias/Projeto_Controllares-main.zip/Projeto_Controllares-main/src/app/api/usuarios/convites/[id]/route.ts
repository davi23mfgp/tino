import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * DELETE /api/usuarios/convites/[id] — revoga convite (ADMIN).
 * Se o convite JÁ foi aceito, também DESATIVA a conta criada por ele —
 * revogar significa derrubar o acesso, não só matar o link.
 */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Não autorizado" }, { status: 403 })
  }
  const { id } = await params
  const invite = await prisma.invite.findFirst({ where: { id, companyId: session.companyId } })
  if (!invite) return NextResponse.json({ error: "Convite não encontrado" }, { status: 404 })

  let contaDesativada = false
  if (invite.usedAt) {
    const user = await prisma.user.findFirst({
      where: { email: invite.email, companyId: session.companyId, NOT: { id: session.userId } },
    })
    if (user) {
      await prisma.user.update({ where: { id: user.id }, data: { status: "DESATIVADO" } })
      contaDesativada = true
      await prisma.aiAuditLog.create({
        data: {
          userId: session.userId, companyId: session.companyId, tipo_acesso: "DADOS",
          descricao: `Revogou convite e desativou ${invite.email}`,
        },
      }).catch(() => {})
    }
  }

  await prisma.invite.delete({ where: { id } })
  return NextResponse.json({ ok: true, contaDesativada })
}
