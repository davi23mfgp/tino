import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import bcrypt from "bcryptjs"
import { rebaixarOutrosAdmins, registrarRebaixamento, type AdminRebaixado } from "@/lib/admin-unico"

const ROLES_VALIDOS = [
  "ADMIN", "VENDEDOR", "FINANCEIRO",
  "RESPONSAVEL_TECNICO", "INSTALADOR", "ENGENHEIRO_PROJETOS",
]

/**
 * GET  /api/usuarios — lista usuários da empresa (para dropdowns e gestão)
 * POST /api/usuarios — cria novo usuário (só ADMIN)
 */
export async function GET(_req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const users = await prisma.user.findMany({
    where: { companyId: session.companyId },
    select: { id: true, nome: true, email: true, role: true, status: true, createdAt: true },
    orderBy: { nome: "asc" },
  })

  return NextResponse.json({ users })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (session.role !== "ADMIN") return NextResponse.json({ error: "Sem permissão" }, { status: 403 })

  const { nome, email, senha, role } = await req.json()

  if (!nome?.trim() || !email?.trim() || !senha?.trim()) {
    return NextResponse.json({ error: "Nome, e-mail e senha são obrigatórios" }, { status: 400 })
  }
  if (role && !ROLES_VALIDOS.includes(role)) {
    return NextResponse.json({ error: "Role inválido" }, { status: 400 })
  }

  const existing = await prisma.user.findUnique({ where: { email: email.toLowerCase() } })
  if (existing) return NextResponse.json({ error: "E-mail já cadastrado" }, { status: 409 })

  const hash = await bcrypt.hash(senha, 12)

  const user = await prisma.user.create({
    data: {
      nome: nome.trim(),
      email: email.toLowerCase().trim(),
      senha: hash,
      role: role || "VENDEDOR",
      companyId: session.companyId,
    },
    select: { id: true, nome: true, email: true, role: true, roles: true, status: true, createdAt: true },
  })

  // Um ADMIN ativo por empresa: quem era admin antes perde só o acesso
  // administrativo. Nenhum dado da empresa é tocado.
  let rebaixados: AdminRebaixado[] = []
  if (user.role === "ADMIN") {
    rebaixados = await rebaixarOutrosAdmins(session.companyId, user.id)
    await registrarRebaixamento(session.companyId, session.userId, rebaixados)
  }

  return NextResponse.json({ ...user, rebaixados }, { status: 201 })
}
