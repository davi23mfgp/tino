import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const q = req.nextUrl.searchParams.get("q")?.trim() ?? ""
  if (q.length < 2) return NextResponse.json({ results: [] })

  const companyId = session.companyId
  const like = { contains: q, mode: "insensitive" as const }

  const [propostas, parceiros, obras] = await Promise.all([
    prisma.proposal.findMany({
      where: { companyId, OR: [{ client_name: like }, { numero: like }] },
      select: { id: true, numero: true, client_name: true, status: true },
      take: 5,
    }),
    prisma.partnerStakeholder.findMany({
      where: { companyId, name: like },
      select: { id: true, name: true, type: true },
      take: 4,
    }).catch(() => [] as { id: string; name: string; type: string }[]),
    prisma.obra.findMany({
      where: { companyId, client_name: like },
      select: { id: true, client_name: true },
      take: 4,
    }).catch(() => [] as { id: string; client_name: string }[]),
  ])

  const results = [
    ...propostas.map(p => ({ type: "proposta", id: p.id, label: p.client_name, sub: `Proposta ${p.numero}`, href: `/propostas/${p.id}` })),
    ...parceiros.map(p => ({ type: "parceiro", id: p.id, label: p.name, sub: String(p.type), href: `/parceiros/${p.id}` })),
    ...obras.map(o => ({ type: "obra", id: o.id, label: o.client_name, sub: "Obra", href: `/obras/${o.id}` })),
  ]

  return NextResponse.json({ results })
}
