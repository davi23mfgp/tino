import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { ehVendedorRestrito } from "@/lib/perfil"
import { podeBaixarPreco } from "@/lib/piso-preco"

/** PATCH /api/propostas/[id]/items/[itemId] — atualiza quantidade e/ou valor_unitario de um item */
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string; itemId: string }> }
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id, itemId } = await params

  // Verifica que a proposta pertence à empresa (e ao vendedor, se restrito)
  const where: Record<string, unknown> = { id, companyId: session.companyId }
  if (ehVendedorRestrito(session)) where.vendedorId = session.userId
  const proposal = await prisma.proposal.findFirst({
    where,
    select: { id: true, status: true, valor_servico: true, desconto_aplicado: true },
  })
  if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  // Mesma trava de outras rotas: proposta aceita é somente-leitura, só Admin mexe.
  // CONCLUIDA entra na trava: faturamento fechado é registro, não rascunho.
  if (["ACEITA", "EM_FATURAMENTO", "EM_CONTRATO", "CONCLUIDA"].includes(proposal.status) && session.role !== "ADMIN") {
    return NextResponse.json({ error: "Proposta aceita é somente leitura. Fale com o Admin." }, { status: 403 })
  }

  const item = await prisma.proposalItem.findFirst({
    where: { id: itemId, proposalId: id },
  })
  if (!item) return NextResponse.json({ error: "Item não encontrado" }, { status: 404 })

  const body = await req.json()
  const quantidade = body.quantidade !== undefined ? Number(body.quantidade) : item.quantidade
  const valor_unitario = body.valor_unitario !== undefined ? Number(body.valor_unitario) : Number(item.valor_unitario)

  /* Preço só sobe, exceto para o Admin.
     Aqui o piso é direto: o item já existe, então o valor que ele tem agora é
     "o valor que já estava". Não precisa consultar o catálogo. */
  if (!podeBaixarPreco(session) && valor_unitario < Number(item.valor_unitario) - 0.005) {
    return NextResponse.json({
      error: `O preço não pode ficar abaixo de ${Number(item.valor_unitario)
        .toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}.`
        + " Você pode aumentar, mas só o Admin reduz.",
    }, { status: 403 })
  }

  const valor_total = quantidade * valor_unitario

  const updated = await prisma.proposalItem.update({
    where: { id: itemId },
    data: { quantidade, valor_unitario, valor_total },
  })

  // Recalcula total da proposta — precisa aplicar o desconto, senão dessincroniza
  // (mesmo bug do POST/PUT: total salvo tem que refletir desconto_aplicado).
  const allItems = await prisma.proposalItem.findMany({ where: { proposalId: id } })
  const subtotal = allItems.reduce((s, i) => s + Number(i.valor_total), 0)
  const descontoPct = proposal.desconto_aplicado ? Number(proposal.desconto_aplicado) : 0
  const valor_total_proposta = (subtotal + Number(proposal.valor_servico ?? 0)) * (1 - descontoPct / 100)
  await prisma.proposal.update({
    where: { id },
    data: { valor_total: valor_total_proposta },
  })

  return NextResponse.json(updated)
}
