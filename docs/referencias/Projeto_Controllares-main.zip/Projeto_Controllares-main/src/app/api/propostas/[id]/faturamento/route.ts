import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { soDigitos, tipoDocumento } from "@/lib/documento"
import { espelharFaturamentoNoLead } from "@/lib/faturamento-lead"

export const dynamic = "force-dynamic"

const TEXTO = [
  "fat_razao_social", "fat_email", "fat_ie",
  "fat_cep", "fat_logradouro", "fat_numero", "fat_complemento", "fat_bairro", "fat_cidade", "fat_uf",
  "obra_cep", "obra_logradouro", "obra_numero", "obra_complemento", "obra_bairro", "obra_cidade", "obra_uf",
] as const

/**
 * PATCH /api/propostas/[id]/faturamento
 *
 * Dados cadastrais usados na nota. Rota separada da PATCH geral porque não é
 * alteração comercial: acontece com a proposta já aceita e não gera versão no
 * histórico — o que mudaria seria o cadastro, não a negociação.
 */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  /* Vendedor também preenche: é ele quem está com o cliente na hora de pedir
     CNPJ e endereço, e travar isso fazia o dado esperar o Financeiro abrir a
     proposta. São dados cadastrais, não condição comercial — quem fecha valor
     e forma de pagamento continua sendo Admin e Financeiro. */
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO", "VENDEDOR"])) {
    return NextResponse.json({ error: "Sem permissão para editar dados de faturamento." }, { status: 403 })
  }

  const { id } = await params
  const body = await req.json().catch(() => ({}))

  const proposal = await prisma.proposal.findFirst({
    where: { id, companyId: session.companyId },
    select: { id: true, leadId: true },
  })
  if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  // Documento é o que a Receita valida — errado aqui vira nota recusada lá.
  const documento = soDigitos(body.fat_documento)
  if (documento && tipoDocumento(documento) === "INVALIDO") {
    return NextResponse.json({ error: "CPF/CNPJ inválido." }, { status: 422 })
  }

  const dados: Record<string, unknown> = { fat_documento: documento || null }
  for (const campo of TEXTO) {
    if (body[campo] !== undefined) {
      dados[campo] = String(body[campo] ?? "").trim() || null
    }
  }
  if (body.fat_nascimento !== undefined) {
    dados.fat_nascimento = body.fat_nascimento ? new Date(body.fat_nascimento) : null
  }
  // CEP guardado só com dígitos: a máscara é coisa de tela.
  for (const c of ["fat_cep", "obra_cep"]) {
    if (dados[c]) dados[c] = soDigitos(String(dados[c])) || null
  }

  const updated = await prisma.proposal.update({ where: { id }, data: dados })

  /* O que foi preenchido aqui volta para a ficha do cliente no funil, quando
     está completo. Sem isso o dado ficava preso nesta proposta e o mesmo
     cliente era interrogado de novo no negócio seguinte. */
  await espelharFaturamentoNoLead(
    session, proposal.leadId, updated, "dados salvos na proposta", updated.numero,
  )

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "EDITAR",
      descricao: `Dados de faturamento da proposta ${updated.numero} atualizados.`,
    },
  }).catch(() => {})

  return NextResponse.json({ ok: true })
}
