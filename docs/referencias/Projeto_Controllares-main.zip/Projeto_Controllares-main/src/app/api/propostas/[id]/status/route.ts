import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { faturamentoCompleto, faltaNoFaturamento } from "@/lib/faturamento"
import { leadSegueProposta } from "@/lib/lead-segue-proposta"
import { temAlgumPerfil, ehVendedorRestrito } from "@/lib/perfil";
import { onProposalAccepted } from "@/lib/obra-service"
import { notificarProposta, type EventoProposta } from "@/lib/notificar-proposta"
import { enviarEmail } from "@/lib/email"
import { emailProposta } from "@/lib/email-templates"

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const body = await req.json()
  const { status, motivo_perda } = body

  const validStatuses = ["RASCUNHO", "ENVIADA", "LIDA", "EM_REVISAO", "ACEITA", "EM_FATURAMENTO", "EM_CONTRATO", "CONCLUIDA", "CANCELADA", "PROPOSTA_PERDIDA"]
  if (!status || !validStatuses.includes(status)) {
    return NextResponse.json({ error: "Status inválido" }, { status: 400 })
  }

  const where: Record<string, unknown> = { id, companyId: session.companyId }
  if (ehVendedorRestrito(session)) where.vendedorId = session.userId

  const existing = await prisma.proposal.findFirst({ where })
  if (!existing) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  /* Contrato entra logo depois do aceite: o cliente aceita, o contrato é
     redigido e assinado, e só então se fatura. */
  if (status === "EM_CONTRATO" && !["ACEITA", "EM_FATURAMENTO"].includes(existing.status)) {
    return NextResponse.json(
      { error: "O contrato vem depois do aceite do cliente." },
      { status: 422 },
    )
  }

  /* Entrar na etapa de contrato exige o cadastro fiscal completo.

     A trava existia só na hora de GERAR o documento. Com ela lá, a proposta
     entrava na coluna Contrato e ficava parada — a pessoa clicava em gerar,
     tomava o erro, e só então descobria que faltava CPF ou endereço. Aqui o
     aviso chega no momento em que a decisão é tomada, com a lista do que
     falta, e a coluna Contrato passa a significar "pronto para assinar". */
  if (status === "EM_CONTRATO") {
    const cadastro = await prisma.proposal.findUnique({
      where: { id },
      select: {
        fat_razao_social: true, fat_documento: true, fat_ie: true, fat_email: true,
        fat_nascimento: true, fat_cep: true, fat_logradouro: true, fat_numero: true,
        fat_complemento: true, fat_bairro: true, fat_cidade: true, fat_uf: true,
      },
    })
    if (cadastro && !faturamentoCompleto(cadastro)) {
      return NextResponse.json({
        error: `Complete o cadastro do cliente antes do contrato. Falta: ${faltaNoFaturamento(cadastro).join(", ")}.`,
        faturamentoIncompleto: true,
      }, { status: 422 })
    }
  }

  /* Faturar: item escrito na hora precisa virar produto de verdade antes.

     O vendedor descreve na visita o que ainda não está cadastrado e segue —
     parar a proposta no meio para cadastrar produto é o que faz a venda
     esfriar. E enviar para leitura também não exige: até o aceite, o item é
     texto numa proposta, e o cliente não precisa de SKU para decidir.

     O faturamento é onde isso muda. Dali em diante o item vira pedido no Olist,
     entra no estoque e é comprado — e nada disso encontra o que comprar sem
     cadastro. Travar aqui, e não na conclusão, também evita descobrir a
     pendência já com o contrato assinado. */
  if (status === "EM_FATURAMENTO") {
    /* Faturar exige contrato assinado. Antes o faturamento vinha antes do
       contrato, e a nota podia sair de uma proposta que o cliente nunca
       assinou. */
    if (existing.status === "EM_CONTRATO" && !existing.contrato_assinado_em) {
      return NextResponse.json(
        { error: "Registre a assinatura do contrato antes de faturar." },
        { status: 422 },
      )
    }
    const pendentes = await prisma.proposalItem.findMany({
      where: { proposalId: id, avulso: true, avulso_resolvido_em: null },
      select: { nome_snapshot: true },
      take: 10,
    })
    if (pendentes.length) {
      const nomes = pendentes.map(p => p.nome_snapshot ?? "sem nome").join(", ")
      return NextResponse.json({
        error: `Cadastre no catálogo ${pendentes.length === 1 ? "o item escrito" : "os itens escritos"}`
          + ` na proposta antes de faturar: ${nomes}.`,
        itensAvulsos: pendentes.length,
      }, { status: 422 })
    }
  }

  /* Concluir: só depois do contrato e com a condição de pagamento definida.
     Sem isso a proposta sairia do fluxo sem contrato assinado e sem ninguém
     ter registrado como o cliente vai pagar. */
  if (status === "CONCLUIDA") {
    if (!["EM_FATURAMENTO", "EM_CONTRATO"].includes(existing.status)) {
      return NextResponse.json(
        { error: "Passe pelo Contrato e pelo Faturamento antes de concluir." },
        { status: 422 },
      )
    }
    /* Estar na coluna Contrato não significa que existe contrato: até aqui
       bastava arrastar o card. Concluir sem documento assinado é o que faz a
       obra começar sem respaldo. */
    if (!existing.contrato_gerado_em) {
      return NextResponse.json(
        { error: "Gere o contrato antes de concluir." },
        { status: 422 },
      )
    }
    if (!existing.contrato_assinado_em) {
      return NextResponse.json(
        { error: "Marque o contrato como assinado antes de concluir." },
        { status: 422 },
      )
    }
    if (!existing.forma_pagamento) {
      return NextResponse.json(
        { error: "Defina a condição de pagamento antes de concluir o faturamento." },
        { status: 422 },
      )
    }

  }

  // Proposta Perdida: só antes de "Aceita"; exige motivo.
  if (status === "PROPOSTA_PERDIDA") {
    if (["ACEITA", "EM_FATURAMENTO", "EM_CONTRATO", "CONCLUIDA"].includes(existing.status)) {
      return NextResponse.json({ error: "Proposta já aceita não pode virar perdida" }, { status: 400 })
    }
    if (!motivo_perda || !String(motivo_perda).trim()) {
      return NextResponse.json({ error: "Informe o motivo da perda" }, { status: 400 })
    }
    const upd = await prisma.proposal.update({
      where: { id }, data: { status, motivo_perda: String(motivo_perda).trim() },
    })
    await notificarProposta("PROPOSTA_PERDIDA", upd, { extra: `Motivo: ${String(motivo_perda).trim().slice(0, 200)}` })
    return NextResponse.json(upd)
  }

  // CAMINHO 2 (admin): se a mudança for para ACEITA, dispara o crossover central
  // em vez de só trocar o status. Idempotente: não duplica obra. A obra também
  // não é criada aqui — é aberta à mão no Operacional.
  // Só ADMIN — senão o próprio vendedor poderia "auto-aceitar" a proposta
  // (criar obra + parcelas) sem o cliente ter de fato aceitado no link público.
  if (status === "ACEITA") {
    if (!temAlgumPerfil(session, ["ADMIN"])) {
      return NextResponse.json({ error: "Só o Admin pode aceitar manualmente uma proposta." }, { status: 403 })
    }
    const result = await onProposalAccepted(id, session.userId)
    if (!result.ok) {
      return NextResponse.json({ error: result.message }, { status: 500 })
    }
    const updated = await prisma.proposal.findUnique({ where: { id } })
    await leadSegueProposta(id, "ACEITA", session.nome ?? "Sistema")
    if (updated) await notificarProposta("ACEITA", updated, { extra: "Aceite registrado pelo Admin." })
    return NextResponse.json({ ...updated, crossover: result })
  }

  const reenvio = status === "ENVIADA" && status !== existing.status
  /* O pedido de ajuste morre no reenvio. Ele descreve a versao anterior: sair
     junto com a proposta corrigida faria o cliente ler "quero desconto" no
     documento que ja traz o desconto. */
  const updated = await prisma.proposal.update({
    where: { id },
    data: reenvio
      ? { status, mensagem_cliente: null, mensagem_cliente_em: null }
      : { status }
  })

  /* O cartão do cliente no funil acompanha. Sem isto ele parava em "Proposta
     Enviada" para sempre, porque mover dependia de alguém lembrar de arrastar
     — e um funil que precisa de manutenção manual vira retrato de um mês
     atrás. */
  await leadSegueProposta(id, status, session.nome ?? "Sistema")

  // Todo movimento de status avisa — antes só o aceite pelo link gerava sinal.
  // RASCUNHO fica de fora: voltar pra rascunho é ajuste interno, não evento.
  const eventoPorStatus: Record<string, EventoProposta> = {
    ENVIADA: "ENVIADA",
    LIDA: "LIDA",
    EM_REVISAO: "REVISAO_SOLICITADA",
    EM_FATURAMENTO: "EM_FATURAMENTO",
    EM_CONTRATO: "EM_CONTRATO",
    CANCELADA: "CANCELADA",
  }
  const evento = eventoPorStatus[status]
  if (evento && status !== existing.status) {
    await notificarProposta(evento, updated)
  }

  // Ao ENVIAR, a proposta vai por e-mail para o cliente. Antes o vendedor tinha
  // de copiar o link e mandar na mão.
  let emailCliente: "enviado" | "sem_email" | "falhou" | "nao_configurado" = "sem_email"
  if (reenvio) {
    if (!updated.client_email?.trim()) {
      emailCliente = "sem_email"
    } else if (!process.env.RESEND_API_KEY) {
      emailCliente = "nao_configurado"
    } else {
      const empresa = await prisma.company.findUnique({
        where: { id: session.companyId },
        select: { nome_empresa: true, email_contato: true },
      })
      const vendedor = await prisma.user.findUnique({
        where: { id: updated.vendedorId },
        select: { nome: true, email: true, telefone: true },
      })
      // APP_URL, nunca a origem da requisição: com URL de preview da Vercel o
      // cliente cairia numa tela de login em vez da proposta.
      const base = (process.env.APP_URL || process.env.NEXT_PUBLIC_APP_URL || "").replace(/\/+$/, "")
      const { subject, html } = emailProposta({
        nomeCliente: updated.client_name,
        numero: updated.numero,
        valorTotal: Number(updated.valor_total),
        validade: updated.data_expiracao,
        link: `${base}/p/${updated.link_token}`,
        empresa: empresa?.nome_empresa ?? "Controllares",
        consultor: vendedor ?? null,
      })
      const ok = await enviarEmail({ to: [updated.client_email.trim()], subject, html })
      emailCliente = ok ? "enviado" : "falhou"
    }
  }

  return NextResponse.json({ ...updated, emailCliente })
}
