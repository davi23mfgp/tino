import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { ehVendedorRestrito, temAlgumPerfil } from "@/lib/perfil"

export const dynamic = "force-dynamic"

/**
 * Itens escritos na proposta que ainda não existem no catálogo.
 *
 * GET   — quais são e o que falta.
 * POST  — cadastra o item como produto de verdade, com SKU.
 * PATCH — liga a um produto que já existe (o item era duplicata de outro nome).
 *
 * Um dos dois é obrigatório antes de faturar: dali em diante o item vira pedido
 * no Olist, entra no estoque e é comprado, e nada disso encontra o que comprar
 * sem cadastro.
 */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (ehVendedorRestrito(session)) return NextResponse.json({ error: "Sem acesso." }, { status: 403 })

  const { id } = await params
  const itens = await prisma.proposalItem.findMany({
    where: { proposalId: id, avulso: true, proposal: { companyId: session.companyId } },
    select: {
      id: true, nome_snapshot: true, avulso_marca: true, avulso_unidade: true,
      avulso_categoria: true, quantidade: true, valor_unitario: true,
      avulso_resolvido_em: true, productId: true, sku_snapshot: true,
      environment: { select: { nome: true } },
    },
    orderBy: { createdAt: "asc" },
  })

  /* Fornecedores e categorias vão junto: o formulário de cadastro precisa dos
     dois, e uma chamada a menos importa numa tela que abre no meio do
     faturamento. */
  const [fornecedores, categorias] = await Promise.all([
    prisma.supplier.findMany({
      where: { companyId: session.companyId },
      select: { id: true, nome: true, prefixo: true },
      orderBy: { nome: "asc" },
    }),
    prisma.category.findMany({
      where: { companyId: session.companyId },
      select: { id: true, nome: true },
      orderBy: { nome: "asc" },
    }),
  ])

  return NextResponse.json({
    itens,
    pendentes: itens.filter(i => !i.avulso_resolvido_em).length,
    fornecedores,
    categorias,
  })
}

/** Próximo SKU livre do fornecedor, no mesmo formato do cadastro manual. */
async function proximoSku(companyId: string, prefixo: string): Promise<string> {
  const usados = await prisma.catalogProduct.findMany({
    where: { companyId, sku: { startsWith: `${prefixo}-` } },
    select: { sku: true },
  })
  /* O maior número usado, não a contagem: com um produto excluído no meio, a
     contagem devolveria um SKU que já existe e o insert falharia. */
  const maior = usados.reduce((m, p) => {
    const n = Number(p.sku.split("-").pop())
    return Number.isFinite(n) && n > m ? n : m
  }, 0)
  return `${prefixo}-${String(maior + 1).padStart(3, "0")}`
}

/**
 * Cadastra o item avulso como produto do catálogo.
 *
 * O preço de venda vem do que foi combinado com o cliente — é o número que ele
 * aceitou. O custo é pedido aqui, e é obrigatório: este é o momento em que
 * alguém do faturamento tem a nota do fornecedor à mão. Deixar para depois
 * produziria produto com margem de 100% em todo relatório até alguém reparar.
 *
 * O estoque inicial é a quantidade da proposta. O produto entrou no catálogo
 * porque foi comprado para esta obra — é essa quantidade que existe de fato.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO", "VENDEDOR"])) {
    return NextResponse.json({ error: "Sem acesso." }, { status: 403 })
  }

  const { id } = await params
  const { itemId, supplierId, categoryId, precoCusto, marca, unidade, nome, ncm, impostoSt } =
    await req.json().catch(() => ({}))
  if (!itemId) return NextResponse.json({ error: "itemId é obrigatório." }, { status: 400 })

  const custo = Number(precoCusto)
  if (!Number.isFinite(custo) || custo <= 0) {
    return NextResponse.json({
      error: "Informe o preço de custo. É agora que a nota do fornecedor está à mão —"
        + " sem ele o produto entra com margem inteira em todo relatório.",
    }, { status: 400 })
  }

  const item = await prisma.proposalItem.findFirst({
    where: { id: itemId, proposalId: id, avulso: true, proposal: { companyId: session.companyId } },
    select: {
      id: true, nome_snapshot: true, avulso_marca: true, avulso_unidade: true,
      valor_unitario: true, quantidade: true, avulso_resolvido_em: true,
    },
  })
  if (!item) return NextResponse.json({ error: "Item não encontrado." }, { status: 404 })
  if (item.avulso_resolvido_em) {
    return NextResponse.json({ error: "Este item já foi cadastrado." }, { status: 409 })
  }
  if (!item.nome_snapshot?.trim()) {
    return NextResponse.json({ error: "O item está sem nome." }, { status: 422 })
  }

  /* SKU sai do prefixo do fornecedor, nunca digitado. É o código que o Olist e
     o estoque usam para achar o produto: deixar alguém inventar um quebraria a
     convenção do catálogo e abriria porta para código repetido. */
  if (!supplierId) {
    return NextResponse.json({ error: "Escolha o fornecedor — é dele que sai o SKU." }, { status: 400 })
  }
  const forn = await prisma.supplier.findFirst({
    where: { id: supplierId, companyId: session.companyId },
    select: { prefixo: true },
  })
  if (!forn) return NextResponse.json({ error: "Fornecedor não encontrado." }, { status: 404 })
  const sku = await proximoSku(session.companyId, forn.prefixo)

  const preco = Number(item.valor_unitario)

  const produto = await prisma.$transaction(async tx => {
    const p = await tx.catalogProduct.create({
      data: {
        companyId: session.companyId,
        sku,
        /* O nome pode ser corrigido no cadastro: na visita se escreve
           "projetor 4k", e o catálogo precisa do modelo de verdade. O que foi
           combinado com o cliente não muda — fica no item da proposta. */
        nome: String(nome ?? "").trim() || item.nome_snapshot!.trim(),
        /* Marca e unidade vêm deste formulário, não da visita: lá só se
           escreve nome, quantidade e valor, para não parar a conversa. */
        marca: String(marca ?? "").trim() || item.avulso_marca?.trim() || "—",
        unidade: String(unidade ?? "").trim() || item.avulso_unidade?.trim() || "UN",
        preco_venda: preco,
        preco_custo: custo,
        /* Estoque inicial: a quantidade que está na proposta. O produto só
           existe no catálogo porque foi comprado para esta obra, então é essa
           a quantidade que há de fato. */
        estoque_qtd: item.quantidade,
        /* NCM e ST entram aqui porque é aqui que alguém tem a nota do
           fornecedor à mão. Sem NCM a nota é recusada, e descobrir isso na
           emissão custa mais que preencher agora. */
        ...(String(ncm ?? "").trim() ? { ncm: String(ncm).trim() } : {}),
        ...(Number(impostoSt) > 0 ? { imposto_st: Number(impostoSt) } : {}),
        ...(supplierId ? { supplierId } : {}),
        ...(categoryId ? { categoryId } : {}),
        status: "ATIVO",
      },
      select: { id: true, sku: true, nome: true },
    })

    /* O item da proposta passa a apontar para o produto, mas preço, quantidade
       e nome ficam como estão: é o que o cliente aceitou, e reescrever aqui
       faria a proposta impressa deixar de bater com a enviada. */
    await tx.proposalItem.update({
      where: { id: item.id },
      data: {
        productId: p.id,
        sku_snapshot: p.sku,
        ...(categoryId ? { categoryId } : {}),
        avulso_resolvido_em: new Date(),
      },
    })

    return p
  })

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "CRIAR",
      descricao: `Item escrito na proposta virou o produto ${produto.sku} — ${produto.nome}`,
    },
  }).catch(() => {})

  return NextResponse.json({ ok: true, produto })
}

/**
 * Liga o item a um produto que já existe.
 *
 * Serve para quando o vendedor escreveu algo que já estava cadastrado com outro
 * nome. Cadastrar de novo criaria duplicata no catálogo e no Olist.
 */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (ehVendedorRestrito(session)) return NextResponse.json({ error: "Sem acesso." }, { status: 403 })

  const { id } = await params
  const { itemId, productId } = await req.json().catch(() => ({}))
  if (!itemId || !productId) {
    return NextResponse.json({ error: "itemId e productId são obrigatórios." }, { status: 400 })
  }

  // Confere os dois lados contra a empresa da sessão.
  const [item, produto] = await Promise.all([
    prisma.proposalItem.findFirst({
      where: { id: itemId, proposalId: id, avulso: true, proposal: { companyId: session.companyId } },
      select: { id: true, nome_snapshot: true },
    }),
    prisma.catalogProduct.findFirst({
      where: { id: productId, companyId: session.companyId },
      select: { id: true, sku: true, categoryId: true },
    }),
  ])
  if (!item) return NextResponse.json({ error: "Item não encontrado." }, { status: 404 })
  if (!produto) return NextResponse.json({ error: "Produto não encontrado." }, { status: 404 })

  await prisma.proposalItem.update({
    where: { id: item.id },
    data: {
      productId: produto.id,
      sku_snapshot: produto.sku,
      categoryId: produto.categoryId,
      avulso_resolvido_em: new Date(),
    },
  })

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "EDITAR",
      descricao: `Item "${item.nome_snapshot}" ligado ao produto ${produto.sku}`,
    },
  }).catch(() => {})

  return NextResponse.json({ ok: true, sku: produto.sku })
}
