import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { gerarCronograma, type Parcela } from "@/lib/parcelas"

export const dynamic = "force-dynamic"

/**
 * Cronograma de parcelas da proposta.
 *
 * GET  — o que está gravado; se ainda não houver nada, uma PRÉVIA calculada a
 *        partir da condição aceita (não grava). É o que faz a tela mostrar as
 *        datas antes de alguém confirmar.
 * PUT  — grava o cronograma editado, substituindo o anterior.
 *
 * Rota separada da PATCH geral da proposta de propósito: mexer em parcela não
 * é alteração de escopo e não deve gerar versão no histórico comercial.
 */

interface Corpo {
  parcelas?: Parcela[]
  /** Guardados junto porque a tela permite ajustá-los ao montar o cronograma. */
  valor_entrada?: number | null
  parcelas_forma?: number | null
}

async function carregar(id: string, companyId: string) {
  return prisma.proposal.findFirst({
    where: { id, companyId },
    select: {
      id: true, status: true, valor_total: true, valor_entrada: true,
      forma_pagamento: true, parcelas_forma: true,
      installments: { orderBy: { numero_parcela: "asc" } },
    },
  })
}

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params

  const p = await carregar(id, session.companyId)
  if (!p) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  const total = Number(p.valor_total ?? 0)

  if (p.installments.length) {
    return NextResponse.json({
      previa: false,
      total,
      parcelas: p.installments.map(i => ({
        numero: i.numero_parcela,
        entrada: i.entrada,
        valor: Number(i.valor),
        vencimento: i.data_vencimento.toISOString().slice(0, 10),
        forma: i.forma,
        status: i.status,
      })),
    })
  }

  /* Prévia: calculada, não gravada. Gravar no GET faria abrir a proposta criar
     parcelas que ninguém confirmou — e elas passariam a aparecer no financeiro
     como contas a receber de uma condição ainda em negociação. */
  return NextResponse.json({
    previa: true,
    total,
    parcelas: gerarCronograma({
      total,
      entrada: Number(p.valor_entrada ?? 0),
      parcelas: p.parcelas_forma ?? 1,
      formaPadrao: p.forma_pagamento,
    }),
  })
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO", "VENDEDOR"])) {
    return NextResponse.json({ error: "Sem permissão para editar o pagamento." }, { status: 403 })
  }

  const { id } = await params
  const body = (await req.json().catch(() => ({}))) as Corpo
  const linhas = Array.isArray(body.parcelas) ? body.parcelas : []
  if (!linhas.length) {
    return NextResponse.json({ error: "Informe ao menos uma parcela." }, { status: 422 })
  }

  const p = await carregar(id, session.companyId)
  if (!p) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  for (const l of linhas) {
    if (!(Number(l.valor) > 0)) {
      return NextResponse.json({ error: "Toda parcela precisa de um valor maior que zero." }, { status: 422 })
    }
    if (Number.isNaN(Date.parse(`${l.vencimento}T12:00:00`))) {
      return NextResponse.json({ error: "Há parcela sem data de vencimento válida." }, { status: 422 })
    }
  }

  /* A soma tem que fechar com o total da proposta. Um centavo de diferença
     vira saldo em aberto no financeiro de uma venda quitada, e ninguém acha a
     origem depois. A tolerância é de um centavo, que é o arredondamento. */
  const total = Number(p.valor_total ?? 0)
  const soma = linhas.reduce((s, l) => s + Number(l.valor), 0)
  if (Math.abs(soma - total) > 0.01) {
    return NextResponse.json({
      error: `A soma das parcelas (${soma.toFixed(2)}) não fecha com o total da proposta (${total.toFixed(2)}).`,
    }, { status: 422 })
  }

  /* Parcela com baixa registrada não é reescrita: o dinheiro já entrou, e
     regerar por cima apagaria o vínculo com o lançamento financeiro. */
  const pagas = await prisma.installment.count({
    where: { proposalId: id, status: { not: "PENDENTE" } },
  })
  if (pagas > 0) {
    return NextResponse.json({
      error: `Esta proposta já tem ${pagas} parcela(s) com baixa registrada. Ajuste pelo Financeiro.`,
    }, { status: 409 })
  }

  const entradaTotal = linhas.filter(l => l.entrada).reduce((s, l) => s + Number(l.valor), 0)
  const nParcelas = linhas.filter(l => !l.entrada).length

  await prisma.$transaction(async tx => {
    await tx.installment.deleteMany({ where: { proposalId: id } })
    await tx.installment.createMany({
      data: linhas.map((l, i) => ({
        proposalId: id,
        numero_parcela: i + 1,
        valor: Number(l.valor),
        // Meio-dia evita que o fuso empurre o vencimento para o dia anterior.
        data_vencimento: new Date(`${l.vencimento}T12:00:00`),
        entrada: !!l.entrada,
        forma: l.forma || null,
      })),
    })
    await tx.proposal.update({
      where: { id },
      data: {
        valor_entrada: entradaTotal || null,
        parcelas_forma: nParcelas || 1,
        pagamento_definido_em: new Date(),
        pagamento_definido_por: "EQUIPE",
      },
    })
  })

  return NextResponse.json({ ok: true, parcelas: linhas.length })
}
