import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"

export const dynamic = "force-dynamic"

/**
 * POST /api/propostas/[id]/contrato/assinar — registra que o contrato voltou
 * assinado.
 *
 * É a marca que libera a conclusão. Fica separada da troca de status porque
 * são duas afirmações diferentes: "o contrato foi assinado" é um fato sobre o
 * documento; "a proposta está concluída" é o fim do fluxo comercial. Juntar as
 * duas num clique só fazia a segunda acontecer sem que ninguém confirmasse a
 * primeira.
 *
 * Não desfaz: dizer que um contrato assinado deixou de estar assinado não é
 * correção de digitação, é mudança do que aconteceu. Se foi engano, o caminho
 * é gerar de novo.
 */
export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Só Admin e Financeiro confirmam assinatura." }, { status: 403 })
  }

  const { id } = await params
  const proposal = await prisma.proposal.findFirst({
    where: { id, companyId: session.companyId },
    select: { id: true, numero: true, contrato_gerado_em: true, contrato_assinado_em: true },
  })
  if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  if (!proposal.contrato_gerado_em) {
    return NextResponse.json({ error: "Gere o contrato antes de marcar como assinado." }, { status: 422 })
  }
  if (proposal.contrato_assinado_em) {
    // Idempotente: dois cliques não viram dois registros nem erro na tela.
    return NextResponse.json({ ok: true, em: proposal.contrato_assinado_em })
  }

  const em = new Date()
  await prisma.proposal.update({ where: { id }, data: { contrato_assinado_em: em } })

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "EDITAR",
      descricao: `Contrato da proposta ${proposal.numero} confirmado como assinado`,
    },
  }).catch(() => {})

  return NextResponse.json({ ok: true, em })
}
