import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil, ehVendedorRestrito } from "@/lib/perfil";

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params

  const where: Record<string, unknown> = { id, companyId: session.companyId }
  if (ehVendedorRestrito(session)) where.vendedorId = session.userId

  const proposal = await prisma.proposal.findFirst({ where })
  if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  const versions = await prisma.proposalVersion.findMany({
    where: { proposalId: id },
    orderBy: { numero_versao: "desc" }
  })

  return NextResponse.json({ versions })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const body = await req.json()
  const { versionId } = body

  if (!versionId) return NextResponse.json({ error: "versionId é obrigatório" }, { status: 400 })

  const where: Record<string, unknown> = { id, companyId: session.companyId }
  if (ehVendedorRestrito(session)) where.vendedorId = session.userId

  const proposal = await prisma.proposal.findFirst({
    where,
    include: { environments: { include: { proposalItems: true } }, installments: true, extraPages: true },
  })
  if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })
  if (!["RASCUNHO", "EM_REVISAO"].includes(proposal.status)) {
    return NextResponse.json({ error: "Só é possível restaurar versões em RASCUNHO ou EM_REVISAO." }, { status: 422 })
  }

  const version = await prisma.proposalVersion.findFirst({
    where: { id: versionId, proposalId: id }
  })
  if (!version) return NextResponse.json({ error: "Versão não encontrada" }, { status: 404 })

  // O snapshot é o registro completo (environments/proposalItems/installments/
  // extraPages) capturado no momento do PUT/PATCH — necessário pra restaurar
  // de verdade, não só os campos de contato (bug anterior).
  const snapshot = version.snapshot_json as unknown as {
    client_name: string; client_email: string | null; client_city: string | null
    project_type: string; data_expiracao: string | null
    valor_servico: number | string; desconto_aplicado: number | string | null
    anos_garantia: number | null; payment_methods: string | null
    environments?: Array<{
      nome: string
      proposalItems?: Array<{
        productId: string | null; kitId: string | null; categoryId: string | null
        nome_snapshot: string | null; sku_snapshot: string | null
        quantidade: number; markup_especifico: number | string | null
        desconto_unitario: number | string | null
        valor_unitario: number | string; valor_total: number | string; is_aditivo: boolean
      }>
    }>
    installments?: Array<{ numero_parcela: number; valor: number | string; data_vencimento: string }>
    extraPages?: Array<{ titulo: string; conteudo_markdown: string; ordem: number; anexos?: unknown }>
  }

  const restored = await prisma.$transaction(async tx => {
    // Snapshot do estado ATUAL antes de restaurar (permite desfazer a restauração)
    const lastVersion = await tx.proposalVersion.findFirst({ where: { proposalId: id }, orderBy: { numero_versao: "desc" } })
    await tx.proposalVersion.create({
      data: {
        proposalId: id,
        numero_versao: (lastVersion?.numero_versao || 0) + 1,
        motivo_alteracao: `Antes de restaurar versão ${version.numero_versao}`,
        valor_historico: proposal.valor_total,
        snapshot_json: JSON.parse(JSON.stringify(proposal)),
      }
    })

    // Recria ambientes/itens/parcelas/páginas a partir do snapshot
    await tx.proposalItem.deleteMany({ where: { proposalId: id } })
    await tx.environment.deleteMany({ where: { proposalId: id } })
    await tx.installment.deleteMany({ where: { proposalId: id } })
    await tx.extraPage.deleteMany({ where: { proposalId: id } })

    for (const env of snapshot.environments ?? []) {
      const createdEnv = await tx.environment.create({ data: { nome: env.nome, proposalId: id, companyId: session.companyId } })
      if (env.proposalItems?.length) {
        await tx.proposalItem.createMany({
          data: env.proposalItems.map(it => ({
            proposalId: id, environmentId: createdEnv.id,
            productId: it.productId, kitId: it.kitId, categoryId: it.categoryId,
            nome_snapshot: it.nome_snapshot, sku_snapshot: it.sku_snapshot,
            quantidade: it.quantidade,
            markup_especifico: it.markup_especifico == null ? null : Number(it.markup_especifico),
            desconto_unitario: it.desconto_unitario == null ? null : Number(it.desconto_unitario),
            valor_unitario: Number(it.valor_unitario), valor_total: Number(it.valor_total),
            is_aditivo: !!it.is_aditivo,
          })),
        })
      }
    }
    if (snapshot.installments?.length) {
      await tx.installment.createMany({
        data: snapshot.installments.map(inst => ({
          proposalId: id, numero_parcela: inst.numero_parcela,
          valor: Number(inst.valor), data_vencimento: new Date(inst.data_vencimento),
        })),
      })
    }
    if (snapshot.extraPages?.length) {
      await tx.extraPage.createMany({
        data: snapshot.extraPages.map(pg => ({
          proposalId: id, titulo: pg.titulo, conteudo_markdown: pg.conteudo_markdown,
          anexos: Array.isArray(pg.anexos) ? (pg.anexos as object[]) : undefined,
          ordem: pg.ordem || 0,
        })),
      })
    }

    return tx.proposal.update({
      where: { id },
      data: {
        client_name: snapshot.client_name,
        client_email: snapshot.client_email,
        client_city: snapshot.client_city,
        project_type: snapshot.project_type as never,
        data_expiracao: snapshot.data_expiracao ? new Date(snapshot.data_expiracao) : null,
        valor_servico: Number(snapshot.valor_servico ?? 0),
        desconto_aplicado: snapshot.desconto_aplicado == null ? null : Number(snapshot.desconto_aplicado),
        anos_garantia: snapshot.anos_garantia,
        payment_methods: snapshot.payment_methods,
        valor_total: version.valor_historico,
      },
    })
  })

  return NextResponse.json({ success: true, proposal: restored })
}
