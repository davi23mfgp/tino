import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { montarContrato } from "@/lib/contrato"
import { faturamentoCompleto, faltaNoFaturamento } from "@/lib/faturamento"
import { espelharFaturamentoNoLead } from "@/lib/faturamento-lead"

export const dynamic = "force-dynamic"

/** GET /api/propostas/[id]/contrato?modeloId=... — contrato para imprimir. */
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return new NextResponse("Não autorizado", { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return new NextResponse("Sem permissão para gerar contratos.", { status: 403 })
  }

  const { id } = await params
  const modeloId = new URL(req.url).searchParams.get("modeloId")
  if (!modeloId) return new NextResponse("Escolha um modelo de contrato.", { status: 400 })

  /* Contrato não sai com cadastro pela metade.

     Ele é assinado e vira a base da nota: nome divergente, CPF errado ou
     endereço faltando aparecem depois — na hora de faturar, com o cliente
     esperando —, e aí a correção pede um aditivo. A trava é aqui, no servidor,
     e não só no botão: a URL do contrato é conhecida e abrir direto era o
     caminho que restava para o documento sair incompleto. */
  const cadastro = await prisma.proposal.findFirst({
    where: { id, companyId: session.companyId },
    select: {
      leadId: true,
      fat_razao_social: true, fat_documento: true, fat_ie: true, fat_email: true,
      fat_nascimento: true, fat_cep: true, fat_logradouro: true, fat_numero: true,
      fat_complemento: true, fat_bairro: true, fat_cidade: true, fat_uf: true,
    },
  })
  if (!cadastro) return new NextResponse("Proposta não encontrada", { status: 404 })
  if (!faturamentoCompleto(cadastro)) {
    return new NextResponse(
      `Complete os dados de faturamento antes de gerar o contrato. Falta: ${faltaNoFaturamento(cadastro).join(", ")}.`,
      { status: 422 },
    )
  }

  const html = await montarContrato(id, session.companyId, modeloId)
  if (!html) return new NextResponse("Proposta ou modelo não encontrado", { status: 404 })

  // Marca a geração: é o que permite bloquear a conclusão sem contrato.
  await prisma.proposal.update({
    where: { id },
    data: { contrato_gerado_em: new Date(), contrato_modelo_id: modeloId },
  }).catch(() => {})

  /* O contrato é o momento em que o cadastro deixa de ser rascunho: os dados
     foram conferidos por quem assina. É aqui, então, que eles voltam para a
     ficha do cliente no funil — e o próximo negócio dessa mesma pessoa começa
     com tudo preenchido em vez de pedir CPF e endereço outra vez. */
  await espelharFaturamentoNoLead(session, cadastro.leadId, cadastro, "contrato gerado")

  /* Nunca do cache.

     O contrato é gerado a cada chamada a partir do modelo e da proposta do
     momento. Sem estes cabeçalhos o navegador servia a versão anterior da
     mesma URL, e quem corrigia uma cláusula ou o valor via o documento velho —
     só um Ctrl+Shift+R mostrava o certo, que é pedir para a pessoa desconfiar
     de um documento que ela tem motivo para achar correto. */
  return new NextResponse(html, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
      Pragma: "no-cache",
      Expires: "0",
    },
  })
}
