import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { enviarEmail } from "@/lib/email"
import { emailContrato } from "@/lib/email-templates"

export const dynamic = "force-dynamic"

/**
 * POST /api/propostas/[id]/contrato/enviar — manda o contrato ao cliente.
 *
 * O contrato ia por fora: alguém salvava o PDF e anexava no próprio e-mail.
 * Fora do sistema, ninguém sabe se foi enviado nem quando — e é a informação
 * que falta quando o cliente demora a assinar.
 *
 * O corpo do e-mail não repete o contrato: leva o essencial e o anexo em PDF
 * fica a cargo de quem envia, porque a geração é feita no navegador (Ctrl+P).
 * O que importa registrar aqui é a data do envio.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Só Admin e Financeiro enviam contratos." }, { status: 403 })
  }

  const { id } = await params
  const { email } = await req.json().catch(() => ({}))

  const proposal = await prisma.proposal.findFirst({
    where: { id, companyId: session.companyId },
    include: {
      company: { select: { nome_empresa: true } },
      vendedor: { select: { nome: true, email: true } },
    },
  })
  if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  if (!proposal.contrato_gerado_em) {
    return NextResponse.json(
      { error: "Gere o contrato antes de enviar." }, { status: 422 })
  }

  /* Destino: o e-mail do cadastro de faturamento tem prioridade sobre o da
     proposta — é o conferido para a nota. O campo do corpo permite corrigir
     na hora, sem voltar para editar a proposta. */
  const destino = String(email || "").trim() || proposal.fat_email || proposal.client_email
  if (!destino) {
    return NextResponse.json(
      { error: "Sem e-mail do cliente. Informe um endereço para enviar." }, { status: 422 })
  }

  /* O e-mail levava só texto: o cliente recebia "segue o contrato" e não tinha
     o contrato. Agora vai o link, que abre o documento pelo mesmo token da
     proposta — quem tem o link já vê valores e escopo. */
  const base = (process.env.APP_URL || process.env.NEXT_PUBLIC_APP_URL || "").replace(/\/+$/, "")
  const linkContrato = proposal.link_token ? `${base}/api/p/${proposal.link_token}/contrato` : null

  const { subject, html } = emailContrato({
    nomeCliente: proposal.client_name,
    numero: proposal.numero,
    empresa: proposal.company.nome_empresa,
    link: linkContrato,
    consultor: proposal.vendedor
      ? { nome: proposal.vendedor.nome, email: proposal.vendedor.email }
      : null,
  })

  const ok = await enviarEmail({ to: [destino], subject, html })

  if (!ok) {
    return NextResponse.json(
      { error: "O envio falhou. Confira a configuração de e-mail em Integrações." },
      { status: 502 },
    )
  }

  await prisma.proposal.update({
    where: { id },
    data: { contrato_enviado_em: new Date() },
  })

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "EDITAR",
      descricao: `Contrato da proposta ${proposal.numero} enviado para ${destino}`,
    },
  }).catch(() => {})

  return NextResponse.json({ ok: true, destino })
}
