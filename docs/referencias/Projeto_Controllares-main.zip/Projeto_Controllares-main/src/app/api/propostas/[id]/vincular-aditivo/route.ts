import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { ehVendedorRestrito } from "@/lib/perfil"

/**
 * POST /api/propostas/[id]/vincular-aditivo
 * Body: { obraId: string }
 *
 * Vincula esta proposta como ADITIVO de uma obra existente:
 *   1. Garante que a proposta e a obra são da mesma empresa.
 *   2. Garante que a proposta não é a origem de outra obra (para não confundir contratos).
 *   3. Seta proposal.obraId → registra o vínculo.
 *   4. Marca todos os ProposalItem desta proposta com is_aditivo = true.
 *
 * Para desvincular, envie { obraId: null }.
 */
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const { obraId } = await req.json()

  // Valida proposta (vendedor restrito só mexe nas próprias)
  const where: Record<string, unknown> = { id, companyId: session.companyId }
  if (ehVendedorRestrito(session)) where.vendedorId = session.userId
  const proposal = await prisma.proposal.findFirst({
    where,
    include: { obraOrigem: { select: { id: true } } },
  })
  if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  // Não permite vincular uma proposta que já gerou sua própria obra (seria confundir contratos)
  if (proposal.obraOrigem && obraId) {
    return NextResponse.json(
      { error: "Esta proposta já gerou uma obra própria e não pode ser vinculada como aditivo." },
      { status: 400 }
    )
  }

  // Valida obra (se não for desvinculação)
  if (obraId) {
    const obra = await prisma.obra.findFirst({ where: { id: obraId, companyId: session.companyId } })
    if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })
  }

  // Vincula/desvincula usando uma transação
  await prisma.$transaction(async (tx) => {
    // Atualiza o obraId na proposta
    await tx.proposal.update({
      where: { id },
      data: { obraId: obraId ?? null },
    })

    // Marca/desmarca os itens como aditivo
    await tx.proposalItem.updateMany({
      where: { proposalId: id },
      data: { is_aditivo: obraId ? true : false },
    })
  })

  return NextResponse.json({ success: true })
}
