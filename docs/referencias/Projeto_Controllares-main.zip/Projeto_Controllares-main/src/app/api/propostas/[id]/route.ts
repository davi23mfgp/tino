import { NextRequest, NextResponse } from "next/server"

import { remapearAmbientes, valorDoServico, type ItemParaServico, type ServicoProposta } from "@/lib/servicos-proposta"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil, ehVendedorRestrito } from "@/lib/perfil";
import { violacaoDePiso } from "@/lib/piso-preco"
import { presetsDaCategoria, reprecificar, lerPresetsDaProposta, type ServicoDeCategoria } from "@/lib/servicos-categoria"
import { tituloCaso } from "@/lib/texto"

/* Nunca servir do cache: o status muda no kanban e a tela de detalhe precisa
   ver a mudança na hora, não uma cópia guardada. */
export const dynamic = "force-dynamic"

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params

  const where: Record<string, unknown> = { id, companyId: session.companyId }
  if (ehVendedorRestrito(session)) where.vendedorId = session.userId

  const proposal = await prisma.proposal.findFirst({
    where,
    include: {
      vendedor: { select: { id: true, nome: true, email: true } },
      environments: {
        include: {
          proposalItems: {
            include: {
              product: true,
              kit: true,
              category: true,
            }
          }
        }
      },
      installments: { orderBy: { numero_parcela: "asc" } },
      extraPages: { orderBy: { ordem: "asc" } },
      versions: { orderBy: { numero_versao: "desc" } },
      // Obra que este proposta GEROU (crossover Fase 5)
      obraOrigem: { select: { id: true, client_name: true } },
      // Obra à qual esta proposta está vinculada como ADITIVO
      obra: { select: { id: true, client_name: true, etapa: true } },
    }
  })

  if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  return NextResponse.json(proposal, {
    headers: { "Cache-Control": "no-store, max-age=0" },
  })
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const body = await req.json()

  const where: Record<string, unknown> = { id, companyId: session.companyId }
  if (ehVendedorRestrito(session)) where.vendedorId = session.userId

  const existing = await prisma.proposal.findFirst({
    where,
    include: {
      environments: { include: { proposalItems: true } },
      installments: true,
      extraPages: true,
    }
  })
  if (!existing) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  // Lock comercial: a partir de ACEITA a proposta é somente-leitura.
  //
  // Exceção: a CONDIÇÃO DE PAGAMENTO é definida justamente nessa fase — o time
  // acerta com o cliente e registra antes de mandar ao Olist. Se o corpo mexe
  // só nesses campos, Financeiro também pode.
  const CAMPOS_FATURAMENTO = new Set(["forma_pagamento", "parcelas_forma", "valor_entrada", "motivo_alteracao"])
  const soPagamento = Object.keys(body).every(k => CAMPOS_FATURAMENTO.has(k))
  const podeNoLock = session.role === "ADMIN" || (soPagamento && temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"]))

  /* "Parcelado na obra" é acordo caso a caso, fora da tabela padrão: quem fecha
     o número de parcelas é o Admin. Financeiro pode mexer nas outras formas. */
  const mexeNoPagamento = ["forma_pagamento", "parcelas_forma", "valor_entrada"].some(k => k in body)
  if (mexeNoPagamento && ["OBRA", "PERSONALIZADO"].includes(existing.forma_pagamento ?? "") && session.role !== "ADMIN") {
    return NextResponse.json(
      { error: "Condição na obra ou personalizada é fechada pelo Admin." },
      { status: 403 },
    )
  }
  if (["ACEITA", "EM_FATURAMENTO", "EM_CONTRATO", "CONCLUIDA"].includes(existing.status) && !podeNoLock) {
    return NextResponse.json({ error: "Proposta aceita é somente leitura. Fale com o Admin." }, { status: 403 })
  }

  // Create version snapshot before update
  const lastVersion = await prisma.proposalVersion.findFirst({
    where: { proposalId: id },
    orderBy: { numero_versao: "desc" }
  })
  const nextVersion = (lastVersion?.numero_versao || 0) + 1

  await prisma.proposalVersion.create({
    data: {
      proposalId: id,
      numero_versao: nextVersion,
      motivo_alteracao: body.motivo_alteracao || "Atualização manual",
      valor_historico: existing.valor_total,
      snapshot_json: JSON.parse(JSON.stringify(existing)),
    }
  })

  const {
    client_name, client_email, client_city, project_type,
    data_expiracao, status, valor_total, motivo_alteracao: _m,
    desconto_aplicado, credito_st, valor_servico, anos_garantia, valor_entrada,
    forma_pagamento, parcelas_forma, exibir_valor_unitario, aplicar_desconto_campanha,
    dias_garantia, servicos_detalhe, servicos_categoria,
  } = body

  // Se desconto ou valor_servico mudam, o valor_total salvo precisa ser
  // recalculado a partir dos itens já persistidos — senão o total fica
  // dessincronizado do que as parcelas e o cliente veem (bug histórico).
  const podeFinanceiro = temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])

  /* Serviço da categoria personalizado NESTA proposta.

     O preço do item nasce com o serviço da categoria dentro, então mudar a taxa
     aqui é reescrever o preço de cada item daquela categoria: desfaz o que
     estava embutido e embute o novo, na conta inversa exata. Feito no servidor
     porque é dinheiro — a tela manda a intenção, quem reescreve preço e total é
     um lugar só.

     Sem a coluna no banco, não acontece: gravar o preço novo sem guardar a taxa
     que o gerou deixaria a proposta dizendo que cobrou o que está no cadastro,
     e a volta ao preço limpo daria errado na próxima edição. */
  let itensReprecificados = false
  if (podeFinanceiro && Array.isArray(servicos_categoria)) {
    const depois = lerPresetsDaProposta(servicos_categoria)
    const antes = lerPresetsDaProposta(existing.servicos_categoria)
    const itens = existing.environments.flatMap(e => e.proposalItems)
    const catIds = [...new Set(itens.map(i => i.categoryId).filter((c): c is string => !!c))]
    /* Proposta que não guardou o que embutiu: o cadastro da categoria é o que
       embutiu o preço dela, e é a melhor leitura que existe. */
    const cadastros = catIds.length
      ? await prisma.category.findMany({ where: { id: { in: catIds } }, select: { id: true, servicos: true } })
      : []

    for (const item of itens) {
      if (!item.categoryId) continue
      const doCadastro = (cadastros.find(c => c.id === item.categoryId)?.servicos ?? null) as ServicoDeCategoria[] | null
      const unitario = Number(item.valor_unitario)
      const novo = Number(reprecificar(
        unitario,
        presetsDaCategoria(item.categoryId, antes, doCadastro),
        presetsDaCategoria(item.categoryId, depois, doCadastro),
      ).toFixed(2))
      // Um centavo de folga: percentual sobre centavos não fecha exato, e
      // gravar por causa do arredondamento sujaria o histórico de versões.
      if (!Number.isFinite(novo) || novo < 0 || Math.abs(novo - unitario) < 0.005) continue
      await prisma.proposalItem.update({
        where: { id: item.id },
        data: { valor_unitario: novo, valor_total: novo * item.quantidade },
      })
      itensReprecificados = true
    }
  }
  const mudaDesconto = podeFinanceiro && desconto_aplicado !== undefined
  const mudaServico = podeFinanceiro && valor_servico !== undefined
  let valorTotalRecalculado: number | undefined
  if (mudaDesconto || mudaServico || itensReprecificados) {
    /* Só sistema ATIVO entra na conta — o guardado continua gravado, com os
       itens, para poder ser resgatado depois, mas não cobra. */
    /* Depois de reprecificar, os itens em memória são a versão velha: o total
       tem de ser somado do que ficou gravado, ou ele nasce contando o preço que
       acabou de deixar de existir. */
    const ambientes = itensReprecificados
      ? await prisma.environment.findMany({
        where: { proposalId: id },
        select: { status: true, proposalItems: { select: { valor_total: true } } },
      })
      : existing.environments
    const subtotalItens = ambientes
      .filter(env => (env.status ?? "ATIVO") === "ATIVO")
      .reduce((s, env) => s + env.proposalItems.reduce((ss, it) => ss + Number(it.valor_total), 0), 0)
    const servicoFinal = mudaServico ? Number(valor_servico) : Number(existing.valor_servico)
    const descontoFinal = mudaDesconto ? Number(desconto_aplicado) || 0 : Number(existing.desconto_aplicado ?? 0)
    valorTotalRecalculado = (subtotalItens + servicoFinal) * (1 - descontoFinal / 100)
  }

  const updated = await prisma.proposal.update({
    where: { id },
    data: {
      ...(client_name !== undefined && { client_name: tituloCaso(client_name) }),
      ...(client_email !== undefined && { client_email }),
      ...(client_city !== undefined && { client_city }),
      ...(project_type !== undefined && { project_type }),
      ...(data_expiracao !== undefined && { data_expiracao: new Date(data_expiracao) }),
      ...(status !== undefined && { status }),
      ...(valorTotalRecalculado !== undefined ? { valor_total: valorTotalRecalculado } : (valor_total !== undefined && { valor_total })),
      ...(mudaDesconto && { desconto_aplicado }),
      ...(podeFinanceiro && credito_st !== undefined && { credito_st: Number(credito_st) }),
      ...(mudaServico && { valor_servico }),
      ...(itensReprecificados || (podeFinanceiro && Array.isArray(servicos_categoria))
        ? { servicos_categoria: lerPresetsDaProposta(servicos_categoria) as object[] }
        : {}),
      /* A composição chegava aqui e era descartada: o total do serviço gravava,
         a lista que o explica não, e quem reabrisse as opções avançadas via o
         número sem as linhas de onde ele saiu. */
      ...(podeFinanceiro && servicos_detalhe !== undefined && { servicos_detalhe: servicos_detalhe ?? undefined }),
      ...(podeFinanceiro && anos_garantia !== undefined && { anos_garantia }),
      ...(podeFinanceiro && dias_garantia !== undefined && { dias_garantia: dias_garantia ? Number(dias_garantia) : null }),
      ...(podeFinanceiro && valor_entrada !== undefined && { valor_entrada: valor_entrada ? Number(valor_entrada) : null }),
      // Condição definida no faturamento, depois do acerto com o cliente.
      ...(podeFinanceiro && forma_pagamento !== undefined && { forma_pagamento: forma_pagamento || null }),
      ...(podeFinanceiro && parcelas_forma !== undefined && { parcelas_forma: parcelas_forma ? Number(parcelas_forma) : null }),
      ...(exibir_valor_unitario !== undefined && { exibir_valor_unitario: exibir_valor_unitario === true }),
      ...(aplicar_desconto_campanha !== undefined && { aplicar_desconto_campanha: aplicar_desconto_campanha !== false }),
    }
  })

  return NextResponse.json(updated)
}


/**
 * PUT /api/propostas/[id]
 * Substituição completa de um rascunho (ambientes, itens, parcelas, páginas extras).
 * Só permitido para propostas em RASCUNHO ou EM_REVISAO.
 */
export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const body = await req.json()

  const where: Record<string, unknown> = { id, companyId: session.companyId }
  if (ehVendedorRestrito(session)) where.vendedorId = session.userId

  const existing = await prisma.proposal.findFirst({
    where,
    // Snapshot precisa do conteúdo inteiro — senão "restaurar versão" não tem
    // como trazer os ambientes/itens/parcelas de volta (bug: faltava o include).
    include: { environments: { include: { proposalItems: true } }, installments: true, extraPages: true },
  })
  if (!existing) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })
  if (!["RASCUNHO", "EM_REVISAO"].includes(existing.status)) {
    return NextResponse.json({ error: "Só é possível editar propostas em RASCUNHO ou EM_REVISAO." }, { status: 422 })
  }

  const { client_name, client_email, client_city, project_type, data_expiracao,
          environments, valor_servico: valorServicoBruto, installments, extraPages,
          payment_methods, anos_garantia, desconto_aplicado, valor_entrada,
          exibir_valor_unitario, condicoes_pagamento, desconto_campanha,
          formas_oferecidas, personalizado_recado, servicos_detalhe,
          servicos_categoria: servicosCategoriaDoEditor, dias_garantia } = body

  /* Preço só sobe, exceto para o Admin.
     Vem ANTES do snapshot de versão de propósito: gravação recusada não pode
     deixar rastro. Se checasse depois, cada tentativa barrada criaria uma
     versão idêntica à anterior e encheria o histórico de ruído. */
  const recebidos = (environments || []).flatMap((env: { items?: unknown[] }) => env.items ?? [])
  const violacao = await violacaoDePiso(
    session.companyId, session,
    recebidos as Parameters<typeof violacaoDePiso>[2],
    existing.environments.flatMap(e => e.proposalItems),
  )
  if (violacao) return NextResponse.json({ error: violacao }, { status: 403 })

  // Snapshot de versão antes de sobrescrever
  const lastVersion = await prisma.proposalVersion.findFirst({ where: { proposalId: id }, orderBy: { numero_versao: "desc" } })
  await prisma.proposalVersion.create({
    data: {
      proposalId: id,
      numero_versao: (lastVersion?.numero_versao || 0) + 1,
      motivo_alteracao: "Edição manual do rascunho",
      valor_historico: existing.valor_total,
      snapshot_json: JSON.parse(JSON.stringify(existing)),
    }
  })

  // Recalcula total. Mesma regra do POST: só ATIVO soma.
  let subtotal = 0
  for (const env of (environments || [])) {
    if ((env.status ?? "ATIVO") !== "ATIVO") continue
    for (const item of (env.items || [])) subtotal += Number(item.valor_total || 0)
  }
  const valor_servico = Number(valorServicoBruto || 0)
  // Mesmo fix do POST: desconto precisa refletir no valor_total salvo.
  const descontoPct = desconto_aplicado ? Number(desconto_aplicado) : 0
  const valor_total = (subtotal + valor_servico) * (1 - descontoPct / 100)

  const updated = await prisma.$transaction(async tx => {
    // Remove tudo dependente
    await tx.proposalItem.deleteMany({ where: { proposalId: id } })
    await tx.environment.deleteMany({ where: { proposalId: id } })
    await tx.installment.deleteMany({ where: { proposalId: id } })
    await tx.extraPage.deleteMany({ where: { proposalId: id } })

    // Atualiza campos da proposta
    const p = await tx.proposal.update({
      where: { id },
      data: {
        client_name: client_name ? tituloCaso(client_name) : existing.client_name,
        client_email: client_email || null,
        client_city: client_city || null,
        project_type: project_type || existing.project_type,
        data_expiracao: data_expiracao ? new Date(data_expiracao) : null,
        valor_total, valor_servico,
        payment_methods: payment_methods ? JSON.stringify(payment_methods) : null,
        anos_garantia: anos_garantia ? Number(anos_garantia) : null,
        valor_entrada: valor_entrada ? Number(valor_entrada) : null,
        exibir_valor_unitario: exibir_valor_unitario === true,
        condicoes_pagamento: condicoes_pagamento ?? null,
        desconto_campanha: desconto_campanha ? Number(desconto_campanha) : null,
        formas_oferecidas: formas_oferecidas ?? null,
        personalizado_recado: personalizado_recado?.trim() || null,
        servicos_detalhe: servicos_detalhe ?? undefined,
        /* Os itens são recriados com o preço que o editor mandou, já com o
           serviço da categoria dentro. O retrato acompanha, ou a próxima edição
           desfaria o embutido pela taxa errada. */
        ...(Array.isArray(servicosCategoriaDoEditor)
          ? { servicos_categoria: lerPresetsDaProposta(servicosCategoriaDoEditor) as object[] }
          : {}),
        dias_garantia: dias_garantia ? Number(dias_garantia) : null,
        desconto_aplicado: desconto_aplicado ? Number(desconto_aplicado) : null,
      }
    })

    /* Recria ambientes e itens.

       Os ids mudam a cada salvamento, porque os ambientes são apagados e
       criados de novo. O serviço preso a um sistema guarda o id que o navegador
       deu — e sem o de-para abaixo ele fica apontando para um ambiente que não
       existe mais. */
    const deParaAmbiente = new Map<string, string>()
    const itensParaServico: ItemParaServico[] = []

    for (const env of (environments || [])) {
      const createdEnv = await tx.environment.create({
        data: {
          nome: env.nome,
          status: ["ATIVO", "GUARDADO", "RECUSADO"].includes(env.status) ? env.status : "ATIVO",
          proposalId: id,
          companyId: session.companyId,
        }
      })
      if (env.id) deParaAmbiente.set(String(env.id), createdEnv.id)
      /* Só ambiente ATIVO entra na base do serviço: guardado não cobra, então
         também não engorda o percentual. */
      if ((env.status ?? "ATIVO") === "ATIVO") {
        for (const it of (env.items ?? [])) {
          itensParaServico.push({
            environmentId: createdEnv.id,
            categoryId: it.categoryId || null,
            valor_total: Number(it.valor_total || 0),
          })
        }
      }
      if (env.items?.length) {
        await tx.proposalItem.createMany({
          data: env.items.map((item: {
            productId?: string; kitId?: string; categoryId?: string
            nome_snapshot?: string; sku_snapshot?: string
            quantidade: number; markup_especifico?: number; desconto_unitario?: number
            valor_unitario: number; valor_total: number; is_aditivo?: boolean
          }) => ({
            proposalId: id, environmentId: createdEnv.id,
            productId: item.productId || null, kitId: item.kitId || null,
            categoryId: item.categoryId || null,
            nome_snapshot: item.nome_snapshot || null, sku_snapshot: item.sku_snapshot || null,
            quantidade: item.quantidade || 1,
            markup_especifico: item.markup_especifico || null,
            desconto_unitario: item.desconto_unitario || null,
            valor_unitario: item.valor_unitario || 0,
            valor_total: item.valor_total || 0,
            is_aditivo: item.is_aditivo || false,
          }))
        })
      }
    }

    /* Com os ambientes já criados, o serviço aponta para os ids do banco — e
       aí o valor é recalculado aqui, pela mesma função que a proposta do
       cliente, o contrato e o pedido do Olist usam. O número do navegador
       deixa de ser a fonte.

       Só recalcula quando a composição veio: salvamento de uma versão antiga
       da tela manda o total sem a lista, e recalcular daria zero — apagaria
       serviço que o cliente está pagando. */
    const listaServicos = Array.isArray(servicos_detalhe)
      ? remapearAmbientes(servicos_detalhe as ServicoProposta[], deParaAmbiente)
      : null

    if (listaServicos?.length) {
      const servicoCalculado = Number(
        listaServicos.reduce((t, sv) => t + valorDoServico(sv, itensParaServico), 0).toFixed(2))
      await tx.proposal.update({
        where: { id },
        data: {
          servicos_detalhe: listaServicos as object[],
          valor_servico: servicoCalculado,
          valor_total: (subtotal + servicoCalculado) * (1 - descontoPct / 100),
        },
      })
    } else if (listaServicos) {
      await tx.proposal.update({
        where: { id },
        data: { servicos_detalhe: listaServicos as object[] },
      })
    }

    // Recria parcelas
    if (installments?.length) {
      await tx.installment.createMany({
        /* `entrada` e `forma` vêm junto.

           Sem isso, a entrada era gravada como uma parcela comum: o pedido no
           Olist saía com sete parcelas iguais em vez de entrada mais seis, e a
           condição personalizada perdia a forma de cada mês. A marca existe no
           banco desde que a entrada virou linha própria — faltava esta rota
           passá-la adiante. */
        data: installments.map((inst: {
          numero_parcela: number; valor: number; data_vencimento: string
          entrada?: boolean; forma?: string | null
        }) => ({
          proposalId: id, numero_parcela: inst.numero_parcela,
          valor: inst.valor, data_vencimento: new Date(inst.data_vencimento),
          entrada: inst.entrada === true,
          forma: inst.forma || null,
        }))
      })
    }

    // Recria páginas extras
    if (extraPages?.length) {
      await tx.extraPage.createMany({
        data: extraPages.map((pg: { titulo: string; conteudo_markdown: string; ordem: number; anexos?: unknown[] }) => ({
          proposalId: id, titulo: pg.titulo,
          conteudo_markdown: pg.conteudo_markdown,
          anexos: Array.isArray(pg.anexos) ? (pg.anexos as object[]) : undefined,
          ordem: pg.ordem,
        }))
      })
    }

    return p
  })

  return NextResponse.json(updated)
}

/**
 * DELETE /api/propostas/[id]
 * Padrão: cancela (soft delete), preservando histórico.
 * `?definitivo=1`: apaga de verdade — só ADMIN, e nunca se a proposta já
 * virou obra (apagar quebraria o vínculo do contrato).
 */
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const definitivo = new URL(req.url).searchParams.get("definitivo") === "1"

  const where: Record<string, unknown> = { id, companyId: session.companyId }
  if (ehVendedorRestrito(session)) where.vendedorId = session.userId

  const existing = await prisma.proposal.findFirst({
    where,
    include: { obraOrigem: { select: { id: true } } },
  })
  if (!existing) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  if (definitivo) {
    if (!temAlgumPerfil(session, ["ADMIN"])) {
      return NextResponse.json({ error: "Só o Admin pode excluir uma proposta definitivamente." }, { status: 403 })
    }
    if (existing.obraOrigem) {
      return NextResponse.json(
        { error: "Esta proposta já gerou uma obra. Exclua a obra antes, ou apenas cancele a proposta." },
        { status: 409 },
      )
    }
    // Auditoria ANTES de apagar: depois do delete não sobra de onde tirar os
    // dados, e sem esse registro uma exclusão em massa fica invisível.
    await prisma.aiAuditLog.create({
      data: {
        userId: session.userId, companyId: session.companyId, tipo_acesso: "EXCLUIR",
        descricao: `Excluiu definitivamente a proposta ${existing.numero} (${existing.client_name}). Valor: ${existing.valor_total ?? "—"}.`,
      },
    }).catch(() => {})

    // Os filhos caem por cascade no schema; a proposta sai inteira.
    await prisma.proposal.delete({ where: { id } })
    return NextResponse.json({ success: true, excluida: true })
  }

  // Soft delete: set status to CANCELADA
  const updated = await prisma.proposal.update({
    where: { id },
    data: { status: "CANCELADA" }
  })

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "EDITAR",
      descricao: `Cancelou a proposta ${existing.numero} (${existing.client_name}).`,
    },
  }).catch(() => {})

  return NextResponse.json(updated)
}
