import { NextRequest, NextResponse } from "next/server"
import { lerPresetsDaProposta } from "@/lib/servicos-categoria"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { leadSegueProposta } from "@/lib/lead-segue-proposta"
import { temAlgumPerfil, ehVendedorRestrito } from "@/lib/perfil";
import { generateSecureToken } from "@/lib/crypto"
import { tituloCaso } from "@/lib/texto"
import { violacaoDePiso } from "@/lib/piso-preco"
import { remapearAmbientes, valorDoServico, type ItemParaServico, type ServicoProposta } from "@/lib/servicos-proposta"

/* Kanban lê esta rota a cada poucos segundos: nada de cache. */
export const dynamic = "force-dynamic"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const status = searchParams.get("status")
  const search = searchParams.get("search")
  const semObra = searchParams.get("semObra")

  const where: Record<string, unknown> = { companyId: session.companyId }
  if (ehVendedorRestrito(session)) where.vendedorId = session.userId
  if (status) where.status = status
  if (semObra === "1") where.obraId = null
  if (search) {
    where.OR = [
      { client_name: { contains: search, mode: "insensitive" as const } },
      { numero: { contains: search, mode: "insensitive" as const } },
    ]
  }

  const proposals = await prisma.proposal.findMany({
    where,
    include: {
      vendedor: { select: { nome: true, email: true } },
    },
    orderBy: { createdAt: "desc" }
  })

  return NextResponse.json({ proposals })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const body = await req.json()
  const {
    leadId,
    leadProjetoId,
    client_name,
    client_email,
    client_city,
    project_type,
    data_expiracao,
    vendedorId,
    environments,
    valor_servico: valorServicoBruto,
    installments,
    extraPages,
    observacoes,
    payment_methods,
    anos_garantia,
    desconto_aplicado,
    valor_entrada,
    exibir_valor_unitario,
    condicoes_pagamento,
    desconto_campanha,
    formas_oferecidas,
    personalizado_recado,
    servicos_detalhe,
    servicos_categoria,
    dias_garantia,
  } = body

  if (!client_name) return NextResponse.json({ error: "Nome do cliente é obrigatório" }, { status: 400 })

  /* Normaliza o nome na gravação, não só na exibição: ele sai daqui para a
     proposta impressa, o e-mail, o contrato e o pedido no Olist. Corrigir em
     cada uma dessas telas é como "davi pereira" chega ao cliente. */
  const nomeCliente = tituloCaso(client_name)

  // RBAC: VENDEDOR can only create for themselves
  const finalVendedorId = session.role === "ADMIN" && vendedorId ? vendedorId : session.userId

  /* Número da proposta: PROP-AAAA-NNN.
     Vem do MAIOR número já usado, não da contagem. Contagem quebra assim que
     alguém exclui uma proposta: com 13 criadas e 1 excluída, count+1 devolve
     013, que já existe, e o insert falha com violação de chave única. */
  const year = new Date().getFullYear()
  const ultima = await prisma.proposal.findFirst({
    where: { companyId: session.companyId, numero: { startsWith: `PROP-${year}-` } },
    orderBy: { numero: "desc" },
    select: { numero: true },
  })
  const ultimoSeq = ultima ? Number(ultima.numero.split("-").pop()) || 0 : 0
  const numero = `PROP-${year}-${String(ultimoSeq + 1).padStart(3, "0")}`

  /* O projeto precisa ser de um lead DESTA empresa.
     O id chega pela URL da tela, que é editável por quem quiser: sem conferir
     aqui, uma proposta poderia se pendurar no projeto de outra empresa e
     vazar o nome dele de volta na listagem. Id inválido vira nulo em vez de
     erro — a proposta em si continua legítima. */
  let projetoValido: string | null = null
  if (leadProjetoId) {
    const projeto = await prisma.leadProjeto.findFirst({
      where: { id: String(leadProjetoId), lead: { companyId: session.companyId } },
      select: { id: true },
    })
    projetoValido = projeto?.id ?? null
  }

  /* Preço só sobe, exceto para o Admin. Numa proposta nova não há "valor que já
     estava", então o piso é o preço do catálogo com a campanha vigente — que é
     exatamente o que a tela põe no item ao adicioná-lo. */
  const violacao = await violacaoDePiso(
    session.companyId, session,
    (environments || []).flatMap((env: { items?: unknown[] }) => env.items ?? []),
  )
  if (violacao) return NextResponse.json({ error: violacao }, { status: 403 })

  /* Só sistema ATIVO entra na conta.
     GUARDADO e RECUSADO continuam gravados com seus itens — é isso que
     permite resgatá-los meses depois — mas cobrar por eles faria a proposta
     pedir dinheiro por algo que o cliente disse que não queria. */
  const entraNaConta = (env: { status?: string }) => (env.status ?? "ATIVO") === "ATIVO"

  // Calculate total + média ponderada do Crédito ICMS-ST pelos produtos
  let subtotalProdutos = 0
  let stPonderadoNum = 0   // soma de (valor_total * imposto_st)
  let stPonderadoDen = 0   // soma de valor_total dos itens com produto
  const allProductIds: string[] = []
  if (environments) {
    for (const env of environments) {
      if (!entraNaConta(env)) continue
      for (const item of (env.items || [])) {
        subtotalProdutos += Number(item.valor_total || 0)
        if (item.productId) allProductIds.push(item.productId)
      }
    }
  }
  // Busca imposto_st dos produtos para calcular média ponderada
  if (allProductIds.length > 0) {
    const produtos = await prisma.catalogProduct.findMany({
      where: { id: { in: allProductIds }, companyId: session.companyId },
      select: { id: true, imposto_st: true },
    })
    const stMap = new Map(produtos.map(p => [p.id, p.imposto_st ?? 0]))
    for (const env of (environments || [])) {
      if (!entraNaConta(env)) continue
      for (const item of (env.items || [])) {
        if (!item.productId) continue
        const st = stMap.get(item.productId) ?? 0
        const vt = Number(item.valor_total || 0)
        stPonderadoNum += st * vt
        stPonderadoDen += vt
      }
    }
  }
  // Média ponderada arredondada a 2 casas — 0 se não houver produtos com ST
  const credito_st_auto = stPonderadoDen > 0 ? Math.round((stPonderadoNum / stPonderadoDen) * 100) / 100 : 0

  const valor_servico = Number(valorServicoBruto || 0)
  // Desconto sobre o total precisa refletir no valor_total salvo — senão o
  // kanban, os relatórios e o financeiro mostram o valor cheio (bruto).
  const descontoPct = desconto_aplicado ? Number(desconto_aplicado) : 0
  const valor_total = (subtotalProdutos + valor_servico) * (1 - descontoPct / 100)

  /* Cliente que já é lead começa com o cadastro dele.

     Os dados de faturamento existiam só dentro de cada proposta: o cliente
     voltava para a segunda obra e alguém pedia CPF, CEP e endereço outra vez —
     dados que a empresa já tinha, conferidos, num contrato assinado. E
     redigitado, o endereço voltava diferente do que estava no contrato.

     Copiados, e não lidos por relação: a proposta é o retrato do que foi
     combinado. Se o cliente mudar de endereço no ano que vem, o documento
     assinado não pode mudar junto. */
  let doLead: Record<string, unknown> = {}
  if (leadId) {
    const lead = await prisma.lead.findFirst({
      where: { id: String(leadId), companyId: session.companyId },
      select: {
        fat_razao_social: true, fat_documento: true, fat_ie: true, fat_email: true,
        fat_nascimento: true, fat_cep: true, fat_logradouro: true, fat_numero: true,
        fat_complemento: true, fat_bairro: true, fat_cidade: true, fat_uf: true,
      },
    })
    if (lead) doLead = Object.fromEntries(Object.entries(lead).filter(([, v]) => v != null))
  }

  const link_token = generateSecureToken()

  try {
  const proposal = await prisma.$transaction(async (tx) => {
    const p = await tx.proposal.create({
      data: {
        numero,
        client_name: nomeCliente,
        client_email,
        client_city,
        project_type: project_type || "RESIDENCIAL",
        data_expiracao: data_expiracao ? new Date(data_expiracao) : null,
        valor_total,
        valor_servico,
        link_token,
        vendedorId: finalVendedorId,
        companyId: session.companyId,
        payment_methods: payment_methods ? JSON.stringify(payment_methods) : null,
        anos_garantia: anos_garantia ? Number(anos_garantia) : null,
        desconto_aplicado: desconto_aplicado ? Number(desconto_aplicado) : null,
        valor_entrada: valor_entrada ? Number(valor_entrada) : null,
        exibir_valor_unitario: exibir_valor_unitario === true,
        condicoes_pagamento: condicoes_pagamento ?? null,
        desconto_campanha: desconto_campanha ? Number(desconto_campanha) : null,
        formas_oferecidas: formas_oferecidas ?? null,
        personalizado_recado: personalizado_recado?.trim() || null,
        servicos_detalhe: servicos_detalhe ?? undefined,
        /* O retrato do serviço de categoria que ENTROU no preço destes itens:
           é o que permite, depois, desfazer o embutido pela taxa certa. */
        servicos_categoria: Array.isArray(servicos_categoria)
          ? (lerPresetsDaProposta(servicos_categoria) as object[])
          : undefined,
        dias_garantia: dias_garantia ? Number(dias_garantia) : null,
        credito_st: credito_st_auto,
        /* O vínculo com o lead nasce aqui, junto da proposta. A tela ainda o
           anotava num segundo PATCH, que era o passo que se perdia quando a
           conexão caía entre uma chamada e outra — e a proposta ficava órfã do
           cliente que a originou. */
        leadId: leadId ? String(leadId) : null,
        /* Qual projeto do cliente esta proposta atende.
           Confere o vinculo em vez de confiar no id que veio do navegador:
           projeto de outra empresa nao pode se pendurar numa proposta desta. */
        leadProjetoId: projetoValido,
        ...doLead,
      }
    })

    /* O id que o navegador deu a cada sistema e o que o banco gerou.
       Sem este de-para, o serviço preso a um sistema fica apontando para um
       ambiente que não existe: baseDoServico não acha nada, o serviço vale
       R$ 0 na proposta do cliente, no contrato e no Olist, e o total continua
       cobrando o valor cheio. */
    const deParaAmbiente = new Map<string, string>()
    const itensParaServico: ItemParaServico[] = []

    if (environments?.length) {
      for (const env of environments) {
        const createdEnv = await tx.environment.create({
          data: {
            nome: env.nome,
            // Lista fechada: valor desconhecido vindo da tela vira ATIVO em
            // vez de gravar lixo que depois ninguém sabe interpretar.
            status: ["ATIVO", "GUARDADO", "RECUSADO"].includes(env.status) ? env.status : "ATIVO",
            proposalId: p.id,
            companyId: session.companyId,
          }
        })
        if (env.id) deParaAmbiente.set(String(env.id), createdEnv.id)
        /* Só ambiente ATIVO entra na base: guardado não cobra, então também
           não pode engordar o percentual de um serviço. */
        if ((env.status ?? "ATIVO") === "ATIVO") {
          for (const it of (env.items ?? [])) {
            itensParaServico.push({
              environmentId: createdEnv.id,
              categoryId: it.categoryId || null,
              valor_total: Number(it.valor_total || 0),
            })
          }
        }

        if (env.items?.length) {
          await tx.proposalItem.createMany({
            data: env.items.map((item: {
              productId?: string
              kitId?: string
              categoryId?: string
              nome_snapshot?: string
              sku_snapshot?: string
              quantidade: number
              markup_especifico?: number
              desconto_unitario?: number
              valor_unitario: number
              valor_total: number
              is_aditivo?: boolean
              avulso?: boolean
              avulso_marca?: string | null
              avulso_unidade?: string | null
              avulso_categoria?: string | null
            }) => ({
              proposalId: p.id,
              environmentId: createdEnv.id,
              productId: item.productId || null,
              kitId: item.kitId || null,
              categoryId: item.categoryId || null,
              nome_snapshot: item.nome_snapshot || null,
              sku_snapshot: item.sku_snapshot || null,
              quantidade: item.quantidade || 1,
              markup_especifico: item.markup_especifico || null,
              desconto_unitario: item.desconto_unitario || null,
              valor_unitario: item.valor_unitario || 0,
              valor_total: item.valor_total || 0,
              is_aditivo: item.is_aditivo || false,
            // Item escrito direto na proposta, ainda sem produto no catálogo.
            // `avulso` é o que trava a conclusão até alguém vincular.
            avulso: item.avulso === true,
            avulso_marca: item.avulso_marca || null,
            avulso_unidade: item.avulso_unidade || null,
            avulso_categoria: item.avulso_categoria || null,
            }))
          })
        }
      }
    }

    /* Agora que os ambientes existem, o serviço passa a apontar para os ids do
       banco — e, com o vínculo certo, o valor do serviço é recalculado AQUI.

       Antes o servidor gravava o número que o navegador mandou. Bastava uma aba
       aberta desde antes de uma mudança de regra para salvar um total que não
       correspondia a nada. Agora a conta sai da mesma função que a proposta do
       cliente, o contrato e o pedido do Olist usam.

       Só recalcula quando a composição veio: proposta salva por versão antiga
       da tela manda o total sem a lista, e recalcular daria zero — apagaria um
       serviço que o cliente está pagando. */
    const listaServicos = Array.isArray(servicos_detalhe)
      ? remapearAmbientes(servicos_detalhe as ServicoProposta[], deParaAmbiente)
      : null

    if (listaServicos?.length) {
      const servicoCalculado = Number(
        listaServicos.reduce((t, sv) => t + valorDoServico(sv, itensParaServico), 0).toFixed(2))
      const totalCalculado = (subtotalProdutos + servicoCalculado) * (1 - descontoPct / 100)

      await tx.proposal.update({
        where: { id: p.id },
        data: {
          servicos_detalhe: listaServicos as object[],
          valor_servico: servicoCalculado,
          valor_total: totalCalculado,
        },
      })
    } else if (listaServicos) {
      // Lista veio vazia: não há serviço, e isso é uma informação, não um erro.
      await tx.proposal.update({
        where: { id: p.id },
        data: { servicos_detalhe: listaServicos as object[] },
      })
    }

    if (installments?.length) {
      await tx.installment.createMany({
        /* `entrada` e `forma` vêm junto.

           Sem isso, a entrada era gravada como uma parcela comum: o pedido no
           Olist saía com sete parcelas iguais em vez de entrada mais seis, e a
           condição personalizada perdia a forma de cada mês. A marca existe no
           banco desde que a entrada virou linha própria — faltava esta rota
           passá-la adiante. */
        data: installments.map((inst: {
          numero_parcela: number; valor: number; data_vencimento: string
          entrada?: boolean; forma?: string | null
        }) => ({
          proposalId: p.id,
          numero_parcela: inst.numero_parcela,
          valor: inst.valor,
          data_vencimento: new Date(inst.data_vencimento),
          entrada: inst.entrada === true,
          forma: inst.forma || null,
        }))
      })
    }

    if (extraPages?.length) {
      await tx.extraPage.createMany({
        data: extraPages.map((ep: { titulo: string; conteudo_markdown: string; ordem: number; anexos?: unknown[] }) => ({
          proposalId: p.id,
          titulo: ep.titulo,
          conteudo_markdown: ep.conteudo_markdown,
          anexos: Array.isArray(ep.anexos) ? (ep.anexos as object[]) : undefined,
          ordem: ep.ordem || 0,
        }))
      })
    }

    return p
  })

  /* O lead entra em "Criação de Proposta" venha o caminho que vier.

     Antes isso só acontecia pelo botão "Proposta" no cartão do funil. Quem ia
     direto em Nova Proposta e escolhia o cliente pela sugestão do campo criava
     o rascunho e o cartão ficava parado em Qualificado — dois caminhos para a
     mesma coisa, e só um deles mexia no funil. Aqui a regra é a mesma do resto
     do ciclo: quem manda no lead é o estado da proposta. */
  if (leadId) {
    await leadSegueProposta(proposal.id, proposal.status, session.nome ?? "Sistema")
  }

  return NextResponse.json(proposal, { status: 201 })
  } catch (e: unknown) {
    console.error("[POST /api/propostas]", e)
    /* Colisão de número: duas pessoas criando ao mesmo tempo pegam o mesmo
       sequencial entre a leitura e o insert. Em vez de mostrar erro de banco
       para quem só clicou em salvar, avisa para tentar de novo — o próximo
       cálculo já pega o número seguinte. */
    const msg = e instanceof Error ? e.message : "Erro interno"
    if (msg.includes("Unique constraint") && msg.includes("numero")) {
      return NextResponse.json(
        { error: "Outra proposta foi criada ao mesmo tempo. Clique em salvar novamente." },
        { status: 409 },
      )
    }
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}
