import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { ehVendedorRestrito } from "@/lib/perfil"
import { DOCUMENTO_PROPOSTA_INCLUDE } from "@/lib/documento-proposta"

export const dynamic = "force-dynamic"

/**
 * GET /api/propostas/[id]/documento — o mesmo documento do link do cliente,
 * pela porta de dentro.
 *
 * O link público passou a exigir o código que vai para o e-mail do cliente,
 * inclusive para quem está logado. Isso é o que impede alguém responder no
 * lugar dele, mas levava junto a impressão: a equipe precisa do documento em
 * PDF para anexar num e-mail ou guardar, e não tem (nem deve ter) o código.
 *
 * Aqui quem autentica é a sessão do sistema, e a proposta é escopada pela
 * empresa. Não marca leitura nem avisa "cliente visualizou": conferência
 * interna inflava o contador e disparava a notificação errada. Proposta
 * vencida também abre: o prazo vale para o cliente decidir, não para a equipe
 * reler o que mandou.
 */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const where: Record<string, unknown> = { id, companyId: session.companyId }
  // Vendedor restrito vê o documento das propostas dele, como no resto da tela.
  if (ehVendedorRestrito(session)) where.vendedorId = session.userId

  const proposal = await prisma.proposal.findFirst({
    where,
    include: DOCUMENTO_PROPOSTA_INCLUDE,
  })
  if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  return NextResponse.json({ proposal })
}
