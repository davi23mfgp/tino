import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const tipo = searchParams.get("tipo") ?? "todos"

  const where: Record<string, unknown> = { companyId: session.companyId }
  if (session.role !== "ADMIN") where.userId = session.userId
  if (tipo !== "todos") where.tipo = tipo

  const itens = await prisma.suporteItem.findMany({
    where,
    include: { user: { select: { nome: true } } },
    orderBy: { createdAt: "desc" },
  })

  return NextResponse.json(itens)
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { tipo, titulo, descricao } = await req.json().catch(() => ({}))
  if (!tipo || !titulo) return NextResponse.json({ error: "tipo e titulo obrigatórios" }, { status: 400 })

  const item = await prisma.suporteItem.create({
    data: {
      companyId: session.companyId,
      userId: session.userId,
      tipo,
      titulo: titulo.trim(),
      descricao: descricao?.trim() ?? "",
      status: "ABERTO",
    },
  })
  return NextResponse.json(item, { status: 201 })
}

export async function PATCH(req: NextRequest) {
  const session = await getSession()
  if (!session || session.role !== "ADMIN")
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id, status, resposta } = await req.json().catch(() => ({}))
  if (!id) return NextResponse.json({ error: "id obrigatório" }, { status: 400 })

  const item = await prisma.suporteItem.update({
    where: { id },
    data: {
      ...(status ? { status } : {}),
      ...(resposta !== undefined ? { resposta } : {}),
    },
  })
  return NextResponse.json(item)
}

export async function DELETE(req: NextRequest) {
  const session = await getSession()
  if (!session || session.role !== "ADMIN")
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const id = searchParams.get("id")
  if (!id) return NextResponse.json({ error: "id obrigatório" }, { status: 400 })

  await prisma.suporteItem.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
