import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export const dynamic = "force-dynamic"

/**
 * Anotações sobre o cliente, presas à etapa em que foram escritas.
 *
 * GET  /api/notas?leadId=…  ou  ?proposalId=…
 * POST /api/notas           { leadId | proposalId, etapa, texto }
 *
 * Anotação não se edita nem se apaga, empilha. O campo único de observações
 * que existia antes se sobrescrevia: a cada visita alguém apagava o que
 * estava lá, e o histórico da negociação virava a última frase digitada.
 *
 * A etapa é gravada pelo servidor a partir do estado ATUAL do lead ou da
 * proposta, não do que a tela mandar. Etapa vinda do cliente seria escolha de
 * quem escreve, e aí a análise "o que se escreveu na visita" deixaria de
 * significar alguma coisa.
 */
export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const url = new URL(req.url)
  const leadId = url.searchParams.get("leadId")
  const proposalId = url.searchParams.get("proposalId")
  if (!leadId && !proposalId) {
    return NextResponse.json({ error: "Informe leadId ou proposalId" }, { status: 400 })
  }

  /* Quando a proposta nasceu de um lead, as anotações da conversa vêm junto:
     quem abre a proposta precisa ler o que foi levantado na visita, senão
     pergunta de novo ao cliente o que ele já respondeu. */
  let leadDaProposta: string | null = null
  if (proposalId) {
    const p = await prisma.proposal.findFirst({
      where: { id: proposalId, companyId: session.companyId },
      select: { leadId: true },
    })
    leadDaProposta = p?.leadId ?? null
  }

  const notas = await prisma.nota.findMany({
    where: {
      companyId: session.companyId,
      OR: [
        ...(leadId ? [{ leadId }] : []),
        ...(proposalId ? [{ proposalId }] : []),
        ...(leadDaProposta ? [{ leadId: leadDaProposta }] : []),
      ],
    },
    orderBy: { createdAt: "desc" },
    include: { autor: { select: { nome: true } } },
  })

  return NextResponse.json({
    /* Quem pode corrigir e apagar vai junto da lista: sem isto a tela teria de
       perguntar o papel em outra chamada só para decidir se desenha o botão —
       e desenhar para todo mundo, deixando a API recusar depois, é prometer
       uma ação que não existe. A checagem de verdade continua no servidor. */
    podeGerenciar: session.role === "ADMIN",
    notas: notas.map(n => ({
      id: n.id,
      etapa: n.etapa,
      tipo: n.tipo,
      canal: n.canal,
      de: n.de,
      para: n.para,
      texto: n.texto,
      /* O nome congelado na escrita ganha do vínculo: é ele que sobrevive à
         saída da pessoa da empresa. O vínculo fica como reserva para as notas
         antigas, escritas antes de o campo existir. */
      autor: n.autorNome ?? n.autor?.nome ?? "—",
      editadoPor: n.editadoPor,
      editadoEm: n.editadoEm,
      createdAt: n.createdAt,
      // Marca a que veio do lead para a tela poder dizer de onde ela é.
      origem: n.leadId && proposalId && n.proposalId !== proposalId ? "lead" : "atual",
    })),
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const body = await req.json().catch(() => ({}))
  const texto = (body.texto ?? "").toString().trim()
  if (!texto) return NextResponse.json({ error: "Escreva alguma coisa." }, { status: 400 })

  const leadId: string | null = body.leadId || null
  const proposalId: string | null = body.proposalId || null
  if (!leadId === !proposalId) {
    return NextResponse.json({ error: "Informe leadId OU proposalId." }, { status: 400 })
  }

  /* A etapa vem do banco, não do corpo da requisição. */
  let etapa = ""
  if (leadId) {
    const l = await prisma.lead.findFirst({
      where: { id: leadId, companyId: session.companyId }, select: { status: true },
    })
    if (!l) return NextResponse.json({ error: "Lead não encontrado" }, { status: 404 })
    etapa = l.status
  } else {
    const p = await prisma.proposal.findFirst({
      where: { id: proposalId!, companyId: session.companyId }, select: { status: true },
    })
    if (!p) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })
    etapa = p.status
  }

  /* Canal validado contra a lista: texto livre aqui viraria "zap", "Whats" e
     "whatsapp" como três canais diferentes no dia em que alguém for contar. */
  const CANAIS = ["LIGACAO", "WHATSAPP", "VISITA", "EMAIL", "REUNIAO", "NOTA"]
  const canal = CANAIS.includes(body.canal) ? body.canal : "NOTA"

  const nota = await prisma.nota.create({
    data: {
      companyId: session.companyId, leadId, proposalId, etapa, texto,
      tipo: "NOTA", canal, autorId: session.userId, autorNome: session.nome,
    },
    include: { autor: { select: { nome: true } } },
  })

  return NextResponse.json({
    id: nota.id, etapa: nota.etapa, tipo: nota.tipo, canal: nota.canal,
    de: null, para: null, texto: nota.texto,
    autor: nota.autorNome ?? nota.autor?.nome ?? "—",
    editadoPor: null, editadoEm: null,
    createdAt: nota.createdAt, origem: "atual",
  }, { status: 201 })
}
