import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export const dynamic = "force-dynamic"

/**
 * Correção e exclusão de uma linha do histórico — só do Admin.
 *
 * PATCH  /api/notas/[id]  { texto }
 * DELETE /api/notas/[id]
 *
 * O histórico é o que se consulta antes de voltar a um cliente meses depois, e
 * só vale se ninguém puder reescrever o passado para se proteger. Por isso o
 * vendedor escreve e não apaga: erro de digitação se corrige com outra
 * anotação. Quando a correção precisa mesmo acontecer — nome trocado, dado do
 * cliente errado —, ela passa pelo Admin E FICA REGISTRADA: o texto anterior é
 * guardado no próprio registro, com quem mexeu e quando.
 *
 * Mudança de etapa não se corrige por aqui. Ela é o retrato do que o funil fez;
 * editar o texto de uma faria a linha do tempo contar um movimento que não
 * aconteceu. Apagar, o Admin ainda pode.
 */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (session.role !== "ADMIN") {
    return NextResponse.json({ error: "Só o Admin corrige o histórico." }, { status: 403 })
  }

  const { id } = await params
  const nota = await prisma.nota.findFirst({ where: { id, companyId: session.companyId } })
  if (!nota) return NextResponse.json({ error: "Anotação não encontrada" }, { status: 404 })
  if (nota.tipo !== "NOTA") {
    return NextResponse.json({ error: "Movimento do funil não se edita." }, { status: 400 })
  }

  const body = await req.json().catch(() => ({}))
  const texto = (body.texto ?? "").toString().trim()
  if (!texto) return NextResponse.json({ error: "Escreva alguma coisa." }, { status: 400 })
  if (texto === nota.texto) return NextResponse.json({ ok: true })

  const atualizada = await prisma.nota.update({
    where: { id },
    data: {
      texto,
      /* Só a PRIMEIRA versão é guardada. Sobrescrever a cada correção deixaria
         só a penúltima, que não é nem o original nem o atual — não serve para
         conferir nada. */
      texto_anterior: nota.texto_anterior ?? nota.texto,
      editadoPor: session.nome,
      editadoEm: new Date(),
    },
  })

  return NextResponse.json({
    id: atualizada.id, texto: atualizada.texto,
    editadoPor: atualizada.editadoPor, editadoEm: atualizada.editadoEm,
  })
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (session.role !== "ADMIN") {
    return NextResponse.json({ error: "Só o Admin exclui do histórico." }, { status: 403 })
  }

  const { id } = await params
  const nota = await prisma.nota.findFirst({ where: { id, companyId: session.companyId } })
  if (!nota) return NextResponse.json({ error: "Anotação não encontrada" }, { status: 404 })

  await prisma.nota.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
