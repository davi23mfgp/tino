import { NextRequest, NextResponse } from "next/server"
import bcrypt from "bcryptjs"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

const ROLES_COM_COFRE = ["ADMIN", "RESPONSAVEL_TECNICO", "INSTALADOR", "ENGENHEIRO_PROJETOS", "VENDEDOR", "FINANCEIRO"]

export async function GET() {
  const session = await getSession()
  if (!session || session.role !== "ADMIN") return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const company = await prisma.company.findUnique({
    where: { id: session.companyId },
    select: { vault_passwords: true },
  })

  const vp = (company?.vault_passwords ?? {}) as Record<string, string>
  const configured = ROLES_COM_COFRE.reduce((acc, role) => {
    acc[role] = !!vp[role]
    return acc
  }, {} as Record<string, boolean>)

  return NextResponse.json({ configured })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session || session.role !== "ADMIN") return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { role, senha } = await req.json().catch(() => ({}))
  if (!role || !ROLES_COM_COFRE.includes(role)) return NextResponse.json({ error: "Perfil inválido" }, { status: 400 })
  if (!senha || senha.length < 4) return NextResponse.json({ error: "Senha mínima de 4 caracteres" }, { status: 400 })

  const company = await prisma.company.findUnique({
    where: { id: session.companyId },
    select: { vault_passwords: true },
  })

  const vp = ((company?.vault_passwords ?? {}) as Record<string, string>)
  vp[role] = await bcrypt.hash(senha, 10)

  await prisma.company.update({
    where: { id: session.companyId },
    data: { vault_passwords: vp },
  })

  return NextResponse.json({ ok: true })
}
