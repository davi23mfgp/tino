import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * GET  /api/empresa — retorna as configurações da empresa do usuário logado
 * PATCH /api/empresa — atualiza configurações (só ADMIN)
 *
 * Campos de integração (pluga, contaazul) são armazenados mas só serão
 * utilizados na Fase 8. Por ora, o front-end só salva/lê os valores.
 */
export async function GET(_req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const company = await prisma.company.findUnique({
    where: { id: session.companyId },
    select: {
      id: true,
      nome_empresa: true,
      cnpj_cpf: true,
      logo_url: true,
      logo_proposta_url: true,
      endereco_base: true,
      email_contato: true,
      telefone_contato: true,
      desconto_maximo: true,
      pluga_api_token: true,
      contaazul_client_id: true,
      contaazul_client_secret: true,
      tiny_api_token: true,
      google_client_id: true,
      whatsapp_extras: true,
      notificar_equipe_whatsapp: true,
      integracoes_ativas: true,
      canal_avisos: true,
      google_client_secret: true,
      telegram_bot_token: true,
      whatsapp_numero: true,
      whatsapp_apikey: true,
      evolution_url: true,
      evolution_instance: true,
      evolution_apikey: true,
      texto_padrao_proposta: true,
    },
  })

  if (!company) return NextResponse.json({ error: "Empresa não encontrada" }, { status: 404 })
  return NextResponse.json(company)
}

export async function PATCH(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (session.role !== "ADMIN") return NextResponse.json({ error: "Sem permissão" }, { status: 403 })

  const body = await req.json()

  const updated = await prisma.company.update({
    where: { id: session.companyId },
    data: {
      ...(body.nome_empresa !== undefined && { nome_empresa: body.nome_empresa }),
      ...(body.cnpj_cpf !== undefined && { cnpj_cpf: body.cnpj_cpf }),
      ...(body.logo_url !== undefined && { logo_url: body.logo_url || null }),
      /* Campo separado do logo do sistema: trocar a marca da barra lateral não
         pode mexer no que o cliente recebe na proposta e no contrato. */
      ...(body.logo_proposta_url !== undefined && { logo_proposta_url: body.logo_proposta_url || null }),
      ...(body.endereco_base !== undefined && { endereco_base: body.endereco_base || null }),
      ...(body.email_contato !== undefined && { email_contato: body.email_contato || null }),
      ...(body.telefone_contato !== undefined && { telefone_contato: body.telefone_contato || null }),
      ...(body.desconto_maximo !== undefined && { desconto_maximo: Number(body.desconto_maximo) || 0 }),
      ...(body.pluga_api_token !== undefined && { pluga_api_token: body.pluga_api_token || null }),
      ...(body.contaazul_client_id !== undefined && { contaazul_client_id: body.contaazul_client_id || null }),
      ...(body.contaazul_client_secret !== undefined && { contaazul_client_secret: body.contaazul_client_secret || null }),
      ...(body.tiny_api_token !== undefined && { tiny_api_token: body.tiny_api_token || null }),
      ...(body.google_client_id !== undefined && { google_client_id: body.google_client_id || null }),
      ...(body.whatsapp_extras !== undefined && { whatsapp_extras: body.whatsapp_extras || null }),
      /* Booleano: `|| null` apagaria o desligamento, porque false é falsy.
         Aqui o que vale é a presença do campo no corpo, não o valor. */
      ...(body.notificar_equipe_whatsapp !== undefined
        && { notificar_equipe_whatsapp: !!body.notificar_equipe_whatsapp }),
      ...(body.integracoes_ativas !== undefined && { integracoes_ativas: body.integracoes_ativas || null }),
      ...(["TELEGRAM", "WHATSAPP", "AMBOS"].includes(body.canal_avisos)
        && { canal_avisos: body.canal_avisos }),
      ...(body.google_client_secret !== undefined && { google_client_secret: body.google_client_secret || null }),
      ...(body.telegram_bot_token !== undefined && { telegram_bot_token: body.telegram_bot_token || null }),
      ...(body.whatsapp_numero !== undefined && { whatsapp_numero: body.whatsapp_numero || null }),
      ...(body.whatsapp_apikey !== undefined && { whatsapp_apikey: body.whatsapp_apikey || null }),
      ...(body.evolution_url !== undefined && { evolution_url: body.evolution_url?.trim().replace(/\/+$/, "") || null }),
      ...(body.evolution_instance !== undefined && { evolution_instance: body.evolution_instance?.trim() || null }),
      ...(body.evolution_apikey !== undefined && { evolution_apikey: body.evolution_apikey || null }),
      ...(body.texto_padrao_proposta !== undefined && { texto_padrao_proposta: body.texto_padrao_proposta || null }),
    },
    select: {
      id: true, nome_empresa: true, cnpj_cpf: true, logo_url: true, logo_proposta_url: true,
      endereco_base: true, email_contato: true, telefone_contato: true, desconto_maximo: true,
      pluga_api_token: true, contaazul_client_id: true, contaazul_client_secret: true,
      tiny_api_token: true, google_client_id: true, google_client_secret: true,
      telegram_bot_token: true, whatsapp_numero: true, whatsapp_apikey: true,
      evolution_url: true, evolution_instance: true, evolution_apikey: true,
      whatsapp_extras: true, notificar_equipe_whatsapp: true, integracoes_ativas: true,
      canal_avisos: true,
      texto_padrao_proposta: true,
    },
  })

  return NextResponse.json(updated)
}
