import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { lerBackup } from "@/lib/backup"

/** GET /api/backups/[id] — baixa o JSON do snapshot (ADMIN). */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin acessa os backups." }, { status: 403 })
  }

  const { id } = await params
  const conteudo = await lerBackup(id, session.companyId)
  if (!conteudo) return NextResponse.json({ error: "Backup não encontrado ou ilegível." }, { status: 404 })

  return new NextResponse(JSON.stringify(conteudo, null, 2), {
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Disposition": `attachment; filename="backup-${id}.json"`,
    },
  })
}

interface PropostaBackup {
  id: string; numero: string; client_name: string
  environments?: { nome: string; proposalItems?: Record<string, unknown>[] }[]
  installments?: Record<string, unknown>[]
  extraPages?: Record<string, unknown>[]
  versions?: unknown
  [k: string]: unknown
}

/**
 * POST /api/backups/[id] — restaura do snapshot (ADMIN).
 *
 * Restauração é sempre ADITIVA: recria apenas o que não existe mais.
 * Nada que está no banco hoje é sobrescrito ou apagado — senão restaurar um
 * backup antigo destruiria tudo que foi feito depois dele.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin restaura backup." }, { status: 403 })
  }

  const { id } = await params
  const conteudo = await lerBackup(id, session.companyId)
  if (!conteudo) return NextResponse.json({ error: "Backup não encontrado ou ilegível." }, { status: 404 })

  const propostas = (conteudo.propostas ?? []) as PropostaBackup[]
  if (!Array.isArray(propostas)) {
    return NextResponse.json({ error: "Backup em formato inesperado." }, { status: 422 })
  }

  // Só recria o que sumiu: compara pelos ids que ainda existem.
  const existentes = new Set(
    (await prisma.proposal.findMany({
      where: { companyId: session.companyId },
      select: { id: true },
    })).map(p => p.id)
  )
  const faltando = propostas.filter(p => !existentes.has(p.id))

  let restauradas = 0
  const falhas: string[] = []

  for (const p of faltando) {
    const { environments, installments, extraPages, versions: _v, ...campos } = p
    void _v
    try {
      await prisma.$transaction(async tx => {
        await tx.proposal.create({
          data: { ...campos, obraId: null, companyId: session.companyId } as never,
        })
        for (const env of environments ?? []) {
          const criado = await tx.environment.create({
            data: { nome: env.nome, proposalId: p.id, companyId: session.companyId },
          })
          if (env.proposalItems?.length) {
            await tx.proposalItem.createMany({
              data: env.proposalItems.map(it => ({ ...it, id: undefined, proposalId: p.id, environmentId: criado.id })) as never,
            })
          }
        }
        if (installments?.length) {
          await tx.installment.createMany({
            data: installments.map(i => ({ ...i, id: undefined, proposalId: p.id })) as never,
          })
        }
        if (extraPages?.length) {
          await tx.extraPage.createMany({
            data: extraPages.map(e => ({ ...e, id: undefined, proposalId: p.id })) as never,
          })
        }
      })
      restauradas++
    } catch (e) {
      falhas.push(`${p.numero}: ${e instanceof Error ? e.message : "erro"}`)
    }
  }

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "CRIAR",
      descricao: `Restaurou backup ${id}: ${restauradas} proposta(s) recriada(s), ${falhas.length} falha(s). Nada existente foi sobrescrito.`,
    },
  }).catch(() => {})

  return NextResponse.json({
    restauradas,
    jaExistiam: propostas.length - faltando.length,
    falhas,
  })
}
