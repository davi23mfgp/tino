import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { gerarBackup, limparBackupsAntigos } from "@/lib/backup"

/** GET /api/backups — lista os snapshots da empresa (ADMIN). */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin acessa os backups." }, { status: 403 })
  }

  const backups = await prisma.backupSnapshot.findMany({
    where: { companyId: session.companyId },
    orderBy: { createdAt: "desc" },
    take: 60,
    // `dados` fica de fora: a lista não precisa carregar o backup inteiro.
    select: { id: true, origem: true, resumo: true, tamanho_bytes: true, erro: true, createdAt: true, arquivo_url: true },
  })

  return NextResponse.json({
    backups: backups.map(b => ({ ...b, arquivo_url: undefined, temArquivo: !!b.arquivo_url })),
  })
}

/** POST /api/backups — gera um snapshot agora (ADMIN). */
export async function POST(_req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin gera backup." }, { status: 403 })
  }

  const snap = await gerarBackup(session.companyId, "MANUAL")
  await limparBackupsAntigos(session.companyId, 30)
  return NextResponse.json({ backup: snap }, { status: 201 })
}
