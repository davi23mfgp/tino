import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/** PATCH /api/fornecedores/[id] — edita nome/prefixo do fornecedor. */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const existing = await prisma.supplier.findFirst({ where: { id, companyId: session.companyId } })
  if (!existing) return NextResponse.json({ error: "Fornecedor não encontrado" }, { status: 404 })

  const body = await req.json()
  const data: { nome?: string; prefixo?: string } = {}
  if (typeof body.nome === "string" && body.nome.trim()) data.nome = body.nome.trim()
  if (typeof body.prefixo === "string" && body.prefixo.trim()) {
    data.prefixo = body.prefixo.trim().toUpperCase().replace(/[^A-Z0-9]/g, "")
  }

  const novoPrefixo = data.prefixo
  const prefixoMudou = !!novoPrefixo && novoPrefixo !== existing.prefixo
  const novoNome = data.nome
  const nomeMudou = !!novoNome && novoNome !== existing.nome

  // ── Recalcula os SKUs dos produtos deste fornecedor ao trocar o prefixo ──
  // Mantém a numeração (ex.: ZZTE-001 -> HM-001), evitando colisões.
  let skusAtualizados = 0
  if (prefixoMudou || nomeMudou) {
    const produtos = await prisma.catalogProduct.findMany({
      where: { supplierId: id, companyId: session.companyId },
      select: { id: true, sku: true },
    })

    if (prefixoMudou) {
      // SKUs já usados na empresa por produtos de OUTROS fornecedores (evita colisão).
      const outros = await prisma.catalogProduct.findMany({
        where: { companyId: session.companyId, NOT: { supplierId: id } },
        select: { sku: true },
      })
      const ocupados = new Set(outros.map(p => p.sku))
      const reOld = new RegExp(`^${existing.prefixo}-(\\d+)$`)

      const updates: { id: string; sku: string }[] = []
      for (const p of produtos) {
        const m = p.sku.match(reOld)
        if (!m) continue // SKU não segue o prefixo antigo (manual) → não mexe
        const numStr = m[1]
        let novoSku = `${novoPrefixo}-${numStr}`
        // Se o número exato colidir com outro fornecedor, procura o próximo livre.
        if (ocupados.has(novoSku)) {
          let n = parseInt(numStr, 10)
          do { n++; novoSku = `${novoPrefixo}-${String(n).padStart(numStr.length, "0")}` } while (ocupados.has(novoSku))
        }
        ocupados.add(novoSku)
        updates.push({ id: p.id, sku: novoSku })
      }

      // Two-phase para evitar colisão temporária com o UNIQUE(companyId, sku):
      // 1) move todos para um sku temporário único; 2) aplica o final.
      await prisma.$transaction([
        ...updates.map((u, i) =>
          prisma.catalogProduct.update({ where: { id: u.id }, data: { sku: `__tmp_${id}_${i}__` } })
        ),
        ...updates.map(u =>
          prisma.catalogProduct.update({ where: { id: u.id }, data: { sku: u.sku } })
        ),
      ])
      skusAtualizados = updates.length
    }

    // Nome mudou → atualiza a marca dos produtos deste fornecedor.
    if (nomeMudou) {
      await prisma.catalogProduct.updateMany({
        where: { supplierId: id, companyId: session.companyId },
        data: { marca: novoNome },
      })
    }
  }

  const updated = await prisma.supplier.update({
    where: { id },
    data,
    include: { _count: { select: { products: true } } },
  })

  return NextResponse.json({ ...updated, skusAtualizados })
}

/**
 * DELETE /api/fornecedores/[id] — remove o fornecedor.
 * Os produtos vinculados NÃO são apagados (supplierId vira null por onDelete: SetNull).
 */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const existing = await prisma.supplier.findFirst({ where: { id, companyId: session.companyId } })
  if (!existing) return NextResponse.json({ error: "Fornecedor não encontrado" }, { status: 404 })

  await prisma.supplier.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
