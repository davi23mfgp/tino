import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/** Gera um prefixo de SKU a partir do nome (ex: "Control4" -> "CTRL"). */
function gerarPrefixo(nome: string): string {
  const limpo = nome.toUpperCase().replace(/[^A-Z0-9]/g, "")
  return (limpo.slice(0, 4) || "FORN")
}

/** GET /api/fornecedores — lista fornecedores com contagem de produtos. */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const fornecedores = await prisma.supplier.findMany({
    where: { companyId: session.companyId },
    orderBy: { nome: "asc" },
    include: { _count: { select: { products: true } } },
  })

  return NextResponse.json({ fornecedores })
}

/** POST /api/fornecedores — cria um fornecedor. */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const body = await req.json()
  const nome: string = (body.nome ?? "").trim()
  if (!nome) return NextResponse.json({ error: "Nome do fornecedor é obrigatório" }, { status: 400 })

  let prefixo: string = (body.prefixo ?? "").trim().toUpperCase().replace(/[^A-Z0-9]/g, "")
  if (!prefixo) prefixo = gerarPrefixo(nome)

  const fornecedor = await prisma.supplier.create({
    data: { nome, prefixo, companyId: session.companyId },
    include: { _count: { select: { products: true } } },
  })

  return NextResponse.json(fornecedor, { status: 201 })
}
