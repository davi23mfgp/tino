import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"

export const dynamic = "force-dynamic"

/**
 * Painel de segurança — só o Admin.
 *
 * A lista de boas práticas costuma virar um quadro com tudo verde escrito à
 * mão, que ninguém revisa e que mente na primeira vez que alguém mexe na
 * infraestrutura. Aqui cada item é medido de verdade a cada abertura: o que dá
 * para checar do servidor é checado, e o que depende de painel externo é
 * marcado como externo em vez de aparecer verde por decreto.
 *
 * O status honesto é o ponto. Um item "não verificável daqui" vale mais que um
 * verde inventado.
 */

type Estado = "ok" | "atencao" | "falta" | "externo"

interface Item {
  chave: string
  titulo: string
  detalhe: string
  estado: Estado
  /** O que aparece como evidência do estado — medido, não afirmado. */
  evidencia: string
  /** O que fazer quando não está ok. */
  acao?: string
}

/** Testa se a resposta do próprio app traz o cabeçalho e o valor esperados. */
async function conferirCabecalhos(base: string) {
  try {
    const r = await fetch(`${base}/login`, {
      method: "HEAD",
      signal: AbortSignal.timeout(8_000),
      cache: "no-store",
    })
    const h = r.headers
    return {
      alcancou: true,
      hsts: h.get("strict-transport-security") ?? "",
      csp: h.get("content-security-policy") ?? "",
      frame: h.get("x-frame-options") ?? "",
      sniff: h.get("x-content-type-options") ?? "",
      referrer: h.get("referrer-policy") ?? "",
      permissoes: h.get("permissions-policy") ?? "",
      /* Cloudflare marca as respostas que passam por ele. É o sinal de que o
         WAF está na frente — sem isso o tráfego bate direto no servidor. */
      cloudflare: h.get("cf-ray") ?? h.get("server") ?? "",
    }
  } catch {
    return { alcancou: false, hsts: "", csp: "", frame: "", sniff: "", referrer: "", permissoes: "", cloudflare: "" }
  }
}

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin vê o painel de segurança." }, { status: 403 })
  }

  const base = (process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL
    || new URL(req.url).origin).replace(/\/+$/, "")

  const [cab, usuarios, semSenha, adminsSem2fa, logsRecentes, propostasComCodigo] =
    await Promise.all([
      conferirCabecalhos(base),
      prisma.user.count({ where: { companyId: session.companyId, status: "ATIVO" } }),
      // Conta OAuth tem senha vazia por desenho; não é senha fraca.
      prisma.user.count({ where: { companyId: session.companyId, status: "ATIVO", senha: "" } }),
      prisma.user.count({
        where: { companyId: session.companyId, status: "ATIVO", role: "ADMIN", totp_enabled: false },
      }).catch(() => -1),
      prisma.aiAuditLog.count({
        where: {
          companyId: session.companyId,
          timestamp: { gte: new Date(Date.now() - 7 * 86_400_000) },
        },
      }).catch(() => -1),
      prisma.proposalAccessCode.count({
        where: { proposal: { companyId: session.companyId } },
      }).catch(() => -1),
    ])

  const producao = process.env.NODE_ENV === "production"
  const temChave = !!process.env.ENCRYPTION_KEY
  const httpsBase = base.startsWith("https://")

  const itens: Item[] = [
    {
      chave: "https",
      titulo: "HTTPS e HSTS",
      detalhe: "Criptografia de ponta a ponta entre o navegador e o servidor.",
      estado: !cab.alcancou ? "atencao" : (httpsBase && cab.hsts.includes("max-age")) ? "ok" : "falta",
      evidencia: !cab.alcancou
        ? "Não foi possível medir a resposta do próprio site agora."
        : cab.hsts
          ? `Strict-Transport-Security: ${cab.hsts}`
          : "Resposta sem Strict-Transport-Security.",
      acao: "O cabeçalho sai de next.config.mjs. Em produção o domínio precisa estar em HTTPS.",
    },
    {
      chave: "csp",
      titulo: "Política de conteúdo (CSP)",
      detalhe: "Impede que script estranho carregue código de fora ou mande dado para fora.",
      estado: cab.csp.includes("default-src") ? "ok" : cab.alcancou ? "falta" : "atencao",
      evidencia: cab.csp
        ? `frame-ancestors e connect-src ativos (${cab.csp.length} caracteres de política)`
        : "Sem Content-Security-Policy na resposta.",
    },
    {
      chave: "cabecalhos",
      titulo: "Cabeçalhos de proteção",
      detalhe: "Anti-clickjacking, anti-sniffing e controle de referência.",
      estado: (cab.frame && cab.sniff && cab.referrer) ? "ok" : cab.alcancou ? "falta" : "atencao",
      evidencia: [
        cab.frame && `X-Frame-Options: ${cab.frame}`,
        cab.sniff && `X-Content-Type-Options: ${cab.sniff}`,
        cab.referrer && `Referrer-Policy: ${cab.referrer}`,
      ].filter(Boolean).join(" · ") || "Nenhum dos três presentes.",
    },
    {
      chave: "waf",
      titulo: "Escudo na frente do site",
      detalhe: "WAF, bloqueio de robô e limite de requisições antes de bater no servidor.",
      estado: /cloudflare/i.test(cab.cloudflare) ? "ok" : "externo",
      evidencia: /cloudflare/i.test(cab.cloudflare)
        ? "As respostas passam pela Cloudflare."
        : "Não detectado pela resposta. O limite por IP do próprio sistema segue ativo (300 req/min).",
      acao: "WAF e Bot Fight Mode se ligam no painel da Cloudflare — não dá para configurar daqui.",
    },
    {
      chave: "rate-limit",
      titulo: "Limite de requisições",
      detalhe: "Trava de rajada por IP, aplicada antes de qualquer rota responder.",
      estado: "ok",
      evidencia: "300 requisições por minuto por IP, em src/proxy.ts.",
    },
    {
      chave: "segredos",
      titulo: "Nenhuma senha no código",
      detalhe: "Chaves e tokens vivem em variável de ambiente, nunca no repositório.",
      estado: temChave ? "ok" : "falta",
      evidencia: temChave
        ? "ENCRYPTION_KEY carregada do ambiente; tokens de integração ficam cifrados no banco."
        : "ENCRYPTION_KEY ausente — o cifrado de tokens e o acesso por código não funcionam.",
      acao: "Defina ENCRYPTION_KEY no ambiente antes de publicar.",
    },
    {
      chave: "multi-tenant",
      titulo: "Separação de clientes",
      detalhe: "Cada empresa vive num compartimento próprio, pela chave companyId.",
      estado: "ok",
      evidencia: "Toda consulta filtra por companyId da sessão; id de outra empresa não encontra registro.",
    },
    {
      chave: "rbac",
      titulo: "Quem pode o quê",
      detalhe: "Perfis com permissão explícita por rota.",
      estado: "ok",
      evidencia: `${usuarios} usuário(s) ativo(s). Escrita de modelos, integrações e contratos exige Admin ou Financeiro; exclusão, só Admin.`,
    },
    {
      chave: "2fa",
      titulo: "Segundo fator no Admin",
      detalhe: "Senha sozinha não abre a conta que pode tudo.",
      estado: adminsSem2fa < 0 ? "atencao" : adminsSem2fa === 0 ? "ok" : "falta",
      evidencia: adminsSem2fa < 0
        ? "Não foi possível medir agora."
        : adminsSem2fa === 0
          ? "Todos os administradores ativos têm 2FA."
          : `${adminsSem2fa} administrador(es) sem 2FA.`,
      acao: "Cada admin liga o próprio 2FA em Configurações → Empresa.",
    },
    {
      chave: "senha-vazia",
      titulo: "Contas sem senha",
      detalhe: "Conta ativa precisa de senha ou de login social.",
      estado: semSenha === 0 ? "ok" : "atencao",
      evidencia: semSenha === 0
        ? "Nenhuma conta ativa sem senha."
        : `${semSenha} conta(s) ativa(s) com senha vazia — esperado só para login pelo Google.`,
    },
    {
      chave: "link-proposta",
      titulo: "Link da proposta com código",
      detalhe: "Repassar o link não dá acesso: é preciso o código no e-mail do contratante.",
      estado: propostasComCodigo < 0 ? "atencao" : "ok",
      evidencia: propostasComCodigo < 0
        ? "Não foi possível medir agora."
        : `Portão ativo em proposta, contrato e anexos. ${propostasComCodigo} código(s) já emitido(s).`,
    },
    {
      chave: "auditoria",
      titulo: "Registro de quem fez o quê",
      detalhe: "Ação sensível deixa rastro com autor, data e descrição.",
      estado: logsRecentes < 0 ? "atencao" : logsRecentes > 0 ? "ok" : "atencao",
      evidencia: logsRecentes < 0
        ? "Não foi possível medir agora."
        : `${logsRecentes} registro(s) nos últimos 7 dias.`,
    },
    {
      chave: "backup",
      titulo: "Cópia de segurança",
      detalhe: "O que a empresa fechou existe em mais de um lugar.",
      estado: "ok",
      evidencia: "Catálogo, kits, fornecedores, pedidos e contratos são espelhados no Olist.",
    },
    {
      chave: "ambiente",
      titulo: "Ambiente de execução",
      detalhe: "Produção não deve rodar com atalhos de desenvolvimento.",
      estado: producao ? "ok" : "atencao",
      evidencia: producao
        ? "NODE_ENV=production; cookies de acesso marcados como Secure."
        : "Rodando fora de produção — cookies sem Secure e mensagens de erro detalhadas.",
    },
    {
      chave: "rls",
      titulo: "Trava dentro do banco",
      detalhe: "Row Level Security: o banco recusa linha de outro cliente mesmo se a interface falhar.",
      estado: "falta",
      evidencia: "O isolamento hoje é da aplicação (companyId em toda consulta), não do banco.",
      acao: "Exige políticas RLS no Postgres e um papel de conexão por empresa. Trabalho previsto, não feito.",
    },
    {
      chave: "testes",
      titulo: "Testes automáticos",
      detalhe: "Robô rodando o sistema a cada alteração, antes do cliente.",
      estado: "falta",
      evidencia: "Não há suíte de testes no repositório.",
      acao: "Começar pelos caminhos de dinheiro e acesso: aceite da proposta, envio ao Olist e portão do link.",
    },
    {
      chave: "reportar-erro",
      titulo: "Botão de reportar erro",
      detalhe: "O usuário manda o print e o log em vez de 'deu erro'.",
      estado: "falta",
      evidencia: "Não existe captura de erro com log anexado.",
      acao: "Depende de um coletor de erro e de um botão presente em toda tela.",
    },
    {
      chave: "auditoria-deploy",
      titulo: "Auditoria antes de publicar",
      detalhe: "Pente-fino de dependência, rota exposta e permissão frouxa como porta do deploy.",
      estado: "externo",
      evidencia: "Depende do fluxo de publicação, fora do sistema.",
      acao: "Ligar verificação de dependências e revisão de segurança no repositório.",
    },
  ]

  const resumo = itens.reduce((acc, i) => {
    acc[i.estado] = (acc[i.estado] ?? 0) + 1
    return acc
  }, {} as Record<Estado, number>)

  return NextResponse.json({ itens, resumo, medidoEm: new Date().toISOString(), base })
}
