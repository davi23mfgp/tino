import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { soDigitos } from "@/lib/documento"

export const dynamic = "force-dynamic"

/**
 * GET /api/clientes — quem já é cliente, e não mais um contato do funil.
 *
 * Cliente NÃO é uma tabela nova. É o mesmo lead, visto por outro ângulo: o que
 * já tem cadastro conferido (CPF ou CNPJ vindo de uma proposta) ou negócio
 * ganho. Duplicar a pessoa numa tabela "clientes" criaria dois cadastros da
 * mesma empresa que divergem no dia em que alguém corrige o endereço num só —
 * e aí ninguém sabe qual dos dois foi para o contrato.
 *
 * O que a lista responde é o que se pergunta na carteira: quem são, quanto já
 * fecharam, e há quanto tempo ninguém fala com eles.
 */
export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const busca = (new URL(req.url).searchParams.get("busca") ?? "").trim()
  const digitos = soDigitos(busca)

  const leads = await prisma.lead.findMany({
    where: {
      companyId: session.companyId,
      /* Cadastro conferido OU negócio fechado. Só "ganho" deixaria de fora o
         cliente antigo que já comprou e cujo cadastro veio de um contrato; só
         "tem documento" deixaria de fora quem fechou e ainda não faturou. */
      OR: [{ fat_documento: { not: null } }, { status: "GANHO" }],
      ...(busca ? {
        AND: [{
          OR: [
            { nome: { contains: busca, mode: "insensitive" as const } },
            { fat_razao_social: { contains: busca, mode: "insensitive" as const } },
            { email: { contains: busca, mode: "insensitive" as const } },
            { fat_email: { contains: busca, mode: "insensitive" as const } },
            { fat_cidade: { contains: busca, mode: "insensitive" as const } },
            /* Documento e telefone se buscam por dígito: quem digita
               "348.386" não acha nada contra um campo que guarda só números. */
            ...(digitos ? [
              { telefone: { contains: digitos } },
              { fat_documento: { contains: digitos } },
            ] : []),
          ],
        }],
      } : {}),
    },
    orderBy: { updatedAt: "desc" },
    include: {
      partner: { select: { id: true, name: true } },
      propostas: {
        orderBy: { createdAt: "desc" },
        select: { id: true, numero: true, status: true, valor_total: true, createdAt: true },
      },
      /* A última linha do histórico responde "há quanto tempo ninguém fala com
         esse cliente" — a pergunta que faz a carteira render, e que nenhuma
         data de cadastro responde. */
      notas: {
        orderBy: { createdAt: "desc" },
        take: 1,
        select: { createdAt: true },
      },
    },
  })

  /* Fechado é o que virou dinheiro: proposta aceita, em faturamento, em
     contrato ou concluída. Somar rascunho e recusada faria a carteira parecer
     três vezes maior do que é. */
  const FECHADAS = ["ACEITA", "EM_FATURAMENTO", "EM_CONTRATO", "CONCLUIDA"]

  const clientes = leads.map(l => {
    const fechadas = l.propostas.filter(p => FECHADAS.includes(p.status))
    return {
      id: l.id,
      nome: l.fat_razao_social || l.nome,
      nome_funil: l.nome,
      documento: l.fat_documento,
      tipo: l.fat_documento ? (l.fat_documento.length > 11 ? "PJ" : "PF") : null,
      telefone: l.telefone,
      email: l.fat_email || l.email,
      cidade: l.fat_cidade,
      uf: l.fat_uf,
      /* O endereço inteiro vai na lista, e não numa segunda rota: são poucos
         campos, e é o que se copia para o WhatsApp do instalador. Uma chamada
         a mais por clique custaria mais do que os bytes. */
      ie: l.fat_ie,
      nascimento: l.fat_nascimento,
      cep: l.fat_cep,
      logradouro: l.fat_logradouro,
      numero: l.fat_numero,
      complemento: l.fat_complemento,
      bairro: l.fat_bairro,
      origem_proposta: l.fat_origem_proposta,
      observacoes: l.observacoes,
      /* A ficha vai junto: Clientes e Leads olham o mesmo cadastro, e quem
         abre a ficha de um cliente antigo precisa das mesmas respostas — em
         que pé ficou a obra, quem decide, o que ficou de fora do escopo. */
      ficha: {
        resumo: l.resumo,
        proximo_passo: l.proximo_passo,
        proximo_passo_em: l.proximo_passo_em,
        temperatura: l.temperatura,
        tipo_imovel: l.tipo_imovel,
        etapa_obra: l.etapa_obra,
        previsao_mudanca: l.previsao_mudanca,
        metragem: l.metragem,
        ambientes_previstos: l.ambientes_previstos,
        sistemas: l.sistemas,
        orcamento_declarado: l.orcamento_declarado ? Number(l.orcamento_declarado) : null,
        decisor: l.decisor,
        concorrentes: l.concorrentes,
        endereco_obra: l.endereco_obra,
      },
      lista_propostas: l.propostas.map(p => ({
        id: p.id, numero: p.numero, status: p.status,
        valor_total: Number(p.valor_total), createdAt: p.createdAt,
      })),
      origem: l.origem,
      parceiro: l.partner?.name ?? null,
      status: l.status,
      cadastro_completo: !!l.fat_documento && !!l.fat_cep && !!l.fat_logradouro,
      confirmado_em: l.fat_confirmado_em,
      propostas: l.propostas.length,
      propostas_fechadas: fechadas.length,
      valor_fechado: fechadas.reduce((s, p) => s + Number(p.valor_total), 0),
      ultima_proposta: l.propostas[0] ?? null,
      ultimo_contato: l.notas[0]?.createdAt ?? null,
      criado_em: l.createdAt,
    }
  })

  return NextResponse.json({ clientes })
}
