import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { notificarProposta } from "@/lib/notificar-proposta"
import { temSessao } from "@/lib/acesso-proposta"
import { DOCUMENTO_PROPOSTA_INCLUDE } from "@/lib/documento-proposta"

export async function GET(req: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params

  const proposal = await prisma.proposal.findUnique({
    where: { link_token: token },
    include: DOCUMENTO_PROPOSTA_INCLUDE,
  })

  if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  const now = new Date()

  // Link expirado? Bloqueia o acesso do cliente (o vendedor pode renovar a data).
  if (proposal.data_expiracao && new Date(proposal.data_expiracao) < now) {
    return NextResponse.json({ expired: true, numero: proposal.numero }, { status: 410 })
  }

  /* Portão de acesso. O link sozinho não abre mais a proposta: é preciso ter
     provado, com o código enviado por e-mail, que se é o destinatário.

     A pré-visualização (RASCUNHO) fica de fora — é a equipe conferindo antes
     de mandar, e ali o link ainda não saiu da empresa.

     Responde 401 sem nenhum dado da proposta. Devolver número ou nome do
     cliente já entregaria informação a quem só tem o link. */
  /* Estar logado no sistema não abre o link. Antes a equipe entrava sem
     código, numa visão interna sem a área de decisão, e o efeito era não
     conseguir conferir a tela que o cliente realmente vê.

     O código já resolve o que a visão interna tentava resolver: quem quiser
     responder no lugar do cliente precisa do código que foi para o e-mail
     dele. Então o link é um só, com o mesmo portão para todo mundo. */
  if (proposal.status !== "RASCUNHO" && !(await temSessao(token))) {
    return NextResponse.json({ precisaCodigo: true }, { status: 401 })
  }

  const isFirstOpen = !proposal.opened_at

  // Rastreia abertura: primeira vez seta opened_at, sempre atualiza last_opened_at e open_count
  await prisma.proposal.update({
    where: { id: proposal.id },
    data: {
      ...(isFirstOpen ? { opened_at: now } : {}),
      last_opened_at: now,
      open_count: { increment: 1 },
      ...(proposal.status === "ENVIADA" ? { status: "LIDA" } : {}),
    },
  })

  // Notifica em TODA abertura (não deduplica) — auditoria com IP/user-agent.
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "—"
  const ua = req.headers.get("user-agent") || "—"
  await notificarProposta("VISUALIZADA", proposal, {
    detalhe: { ip, user_agent: ua.slice(0, 200), abertura: proposal.open_count + 1 },
  })

  if (proposal.status === "ENVIADA") proposal.status = "LIDA"

  return NextResponse.json({ proposal })
}
