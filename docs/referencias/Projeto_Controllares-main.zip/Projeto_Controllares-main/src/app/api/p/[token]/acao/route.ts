import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { leadSegueProposta } from "@/lib/lead-segue-proposta"
import { onProposalAccepted } from "@/lib/obra-service"
import { notificarProposta } from "@/lib/notificar-proposta"
import { enviarEmail } from "@/lib/email"
import { emailAceite, emailRevisao, emailRecusa } from "@/lib/email-templates"
import { aplicarEscolhaDeSistemas } from "@/lib/escolha-sistemas"

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params
  const body = await req.json()
  const { acao, motivo, pagamento, emailConfirmacao, sistemas, semServico } = body as {
    acao: "ACEITA" | "EM_REVISAO" | "RECUSADA" | "LIDA"
    motivo?: string
    /** Condição escolhida pelo cliente no aceite. */
    pagamento?: { forma?: string; parcelas?: number; entrada?: number; observacao?: string }
    /** E-mail que recebeu a proposta — confirma que o aceite parte do cliente. */
    emailConfirmacao?: string
    /** Sistemas que o cliente quer levar. O resto vira GUARDADO. */
    sistemas?: string[]
    /** Ele dispensou o bloco de projeto e instalação. */
    semServico?: boolean
  }

  if (!["ACEITA", "EM_REVISAO", "RECUSADA", "LIDA"].includes(acao)) {
    return NextResponse.json({ error: "Ação inválida" }, { status: 400 })
  }

  const proposal = await prisma.proposal.findUnique({
    where: { link_token: token },
  })

  if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  // Link expirado: mesma trava do GET — não deixa aceitar/reabrir proposta vencida.
  if (proposal.data_expiracao && new Date(proposal.data_expiracao) < new Date()) {
    return NextResponse.json({ error: "Este link expirou. Peça um novo ao vendedor." }, { status: 410 })
  }

  /* RASCUNHO é pré-visualização: o link existe desde que a proposta é criada,
     e a equipe o abre para conferir antes de enviar. Aceitar por ali marcaria
     como fechada uma proposta que o cliente nem recebeu. */
  if (proposal.status === "RASCUNHO") {
    return NextResponse.json(
      { error: "Esta proposta ainda não foi enviada. É apenas uma pré-visualização." },
      { status: 409 },
    )
  }

  // Proposta já decidida (aceita/faturando/cancelada/perdida) é somente leitura —
  // sem isso o cliente poderia "reabrir" (ex.: EM_REVISAO) uma proposta já aceita.
  if (["ACEITA", "EM_FATURAMENTO", "EM_CONTRATO", "CANCELADA", "PROPOSTA_PERDIDA"].includes(proposal.status)) {
    return NextResponse.json({ error: "Esta proposta já foi decidida e não pode ser alterada." }, { status: 409 })
  }

  /* Aceitar exige confirmar o e-mail que recebeu a proposta. O link é um
     endereço só, e basta repassá-lo para outra pessoa decidir no lugar do
     cliente. Conferir o e-mail não é criptografia — é o bastante para que o
     aceite parta de quem recebeu, e deixa registro de quem confirmou. */
  if (acao === "ACEITA") {
    const cadastrados = [proposal.fat_email, proposal.client_email]
      .map(e => (e ?? "").trim().toLowerCase())
      .filter(Boolean)
    const informado = String(emailConfirmacao ?? "").trim().toLowerCase()
    if (cadastrados.length && !cadastrados.includes(informado)) {
      return NextResponse.json(
        { error: "Confirme o e-mail que recebeu esta proposta para aceitar." },
        { status: 403 },
      )
    }
  }

  if (acao === "ACEITA") {
    /* Registra a condição que o CLIENTE montou antes de disparar o crossover.
       É ela que segue para o faturamento — sem isso a equipe redigitava tudo
       de novo, com risco de divergir do que foi combinado.

       "Parcelado na obra" fica sem parcelas de propósito: o número é acertado
       com o Admin depois. */
    await gravarPagamento(proposal, pagamento)

    /* O que ele escolheu levar. Roda ANTES do crossover: é o valor novo que
       vai virar parcela, conta a receber e, depois, obra. */
    const escolha = await aplicarEscolhaDeSistemas(
      prisma,
      proposal.id,
      sistemas,
      pagamento?.forma === "AVISTA"
        ? Math.max(5, Number(proposal.desconto_aplicado ?? 0))
        : Number(proposal.desconto_aplicado ?? 0),
      !semServico,
    )

    // CAMINHO 1 (cliente): dispara o crossover central.
    // Ele cuida do status ACEITA, do financeiro e dos logs. A obra NÃO é
    // aberta aqui: quem decide quando ela começa é o time, no Operacional.
    const result = await onProposalAccepted(proposal.id, null)
    if (!result.ok) {
      return NextResponse.json({ error: result.message }, { status: 500 })
    }
    await notificarProposta("ACEITA", proposal, {
      extra: escolha
        ? `Aceite feito pelo cliente no link. Ele levou ${escolha.sobraram} `
          + `sistema(s); ${escolha.guardados} ficaram guardados na ficha dele.`
        : "Aceite feito pelo cliente no link.",
    })

    /* Confirmação para o cliente. Sem ela ele clica em "Aceitar" e não recebe
       nada — fica sem comprovante de que a decisão chegou, e o silêncio depois
       de fechar é onde nasce a desconfiança. Falha de e-mail não desfaz o
       aceite: o negócio já está registrado. */
    const destino = (proposal.fat_email || proposal.client_email || "").trim()
    if (destino) {
      const empresa = await prisma.company.findUnique({
        where: { id: proposal.companyId },
        select: { nome_empresa: true },
      })
      const vendedor = await prisma.user.findUnique({
        where: { id: proposal.vendedorId },
        select: { nome: true, email: true },
      })
      /* O que ele fechou, para o e-mail dizer de que é o comprovante. Vem do
         banco depois da escolha: com seleção parcial só os ATIVO sobraram, e o
         valor já foi refeito. */
      const fechado = await prisma.proposal.findUnique({
        where: { id: proposal.id },
        select: {
          valor_total: true,
          environments: { where: { status: "ATIVO" }, select: { nome: true } },
        },
      })
      const base = (process.env.APP_URL || process.env.NEXT_PUBLIC_APP_URL || "").replace(/\/+$/, "")

      const { subject, html } = emailAceite({
        sistemas: fechado?.environments.map(e => e.nome?.trim() || "Sistema") ?? [],
        total: fechado ? Number(fechado.valor_total) : null,
        link: base && proposal.link_token ? `${base}/p/${proposal.link_token}` : null,
        nomeCliente: proposal.client_name,
        numero: proposal.numero,
        empresa: empresa?.nome_empresa ?? "Controllares",
        consultor: vendedor,
      })
      await enviarEmail({ to: [destino], subject, html }).catch(() => false)
    }

    // O aceite pelo link é o evento que mais importa no funil, e era o que
    // menos mexia nele: a proposta virava ACEITA e o cartão ficava parado.
    await leadSegueProposta(proposal.id, "ACEITA", "Cliente")

    return NextResponse.json({ success: true, status: "ACEITA", crossover: result })
  }

  if (acao === "RECUSADA") {
    // Recusa do cliente vira PROPOSTA_PERDIDA, com o motivo que ele escreveu
    // (o kanban exige motivo_perda para essa coluna).
    await prisma.proposal.update({
      where: { id: proposal.id },
      data: {
        status: "PROPOSTA_PERDIDA",
        motivo_perda: motivo?.trim() ? motivo.trim().slice(0, 500) : "Recusada pelo cliente no link público",
        ...(motivo?.trim() && { mensagem_cliente: motivo.trim().slice(0, 2000), mensagem_cliente_em: new Date() }),
      },
    })
    // Recusa é o único caminho de volta que significa alguma coisa: o negócio
    // não aconteceu, e o cartão precisa sair do funil ativo.
    await leadSegueProposta(proposal.id, "PROPOSTA_PERDIDA", "Cliente")
    await notificarProposta("PROPOSTA_PERDIDA", proposal, {
      extra: motivo?.trim() ? `Motivo: ${motivo.trim().slice(0, 200)}` : "Recusada pelo cliente no link.",
      detalhe: { motivo: motivo || null },
    })

    /* Um "não" também merece resposta. Sem isto o contato terminava no
       silêncio, como se a decisão dele não tivesse chegado, e é justamente o
       cliente que pode voltar na próxima obra. */
    await responderCliente(proposal, "RECUSADA", { mensagem: motivo })

    return NextResponse.json({ success: true, status: "PROPOSTA_PERDIDA" })
  }

  /* Revisão também respeita a escolha: pedir ajuste em dois dos quatro
     sistemas não deve manter os outros dois no documento que volta. Eles vão
     para o histórico do cliente, de onde saem se ele mudar de ideia. */
  const escolhaRevisao = acao === "EM_REVISAO"
    ? await aplicarEscolhaDeSistemas(
      prisma, proposal.id, sistemas, Number(proposal.desconto_aplicado ?? 0), !semServico)
    : null

  /* A forma que ele marcou fica gravada mesmo quando pede ajuste. Antes só o
     aceite guardava: a proposta voltava revisada e o cliente tinha de escolher
     cartão, parcelas e entrada de novo, do zero, como se nunca tivesse dito. */
  if (acao === "EM_REVISAO") await gravarPagamento(proposal, pagamento)

  // Demais ações (revisão / mais tempo) seguem o fluxo simples.
  // A mensagem do cliente é GRAVADA: antes ela era descartada e o vendedor via
  // "Em Revisão" no kanban sem nenhuma pista do que precisava mudar.
  await prisma.proposal.update({
    where: { id: proposal.id },
    data: {
      status: acao,
      ...(motivo?.trim() && { mensagem_cliente: motivo.trim().slice(0, 2000), mensagem_cliente_em: new Date() }),
    },
  })

  // Antes a revisão só gerava log interno e nenhum aviso saía no WhatsApp.
  await notificarProposta(acao === "EM_REVISAO" ? "REVISAO_SOLICITADA" : "LIDA", proposal, {
    ...(escolhaRevisao && {
      extra: `Ele quer seguir com ${escolhaRevisao.sobraram} sistema(s); `
        + `${escolhaRevisao.guardados} ficaram guardados na ficha dele.`,
    }),
  })

  /* O cliente pedia ajuste e não recebia nada: ficava sem saber se o pedido
     saiu do navegador, e a espera pela proposta nova começava no escuro.
     LIDA é abertura automática, não resposta dele, então não manda nada. */
  if (acao === "EM_REVISAO") {
    await responderCliente(proposal, "EM_REVISAO", {
      mensagem: motivo,
      guardados: escolhaRevisao?.guardados ?? 0,
    })
  }

  return NextResponse.json({ success: true, status: acao })
}

/**
 * Resposta ao cliente depois que ele decide.
 *
 * Nunca derruba a decisão: o que vale já está gravado, e falhar o e-mail não
 * pode desfazer um aceite nem uma recusa.
 */
async function responderCliente(
  proposal: { id: string; companyId: string; vendedorId: string; numero: string; client_name: string; fat_email: string | null; client_email: string | null },
  tipo: "EM_REVISAO" | "RECUSADA",
  extra: { mensagem?: string | null; guardados?: number },
) {
  try {
    const destino = (proposal.fat_email || proposal.client_email || "").trim()
    if (!destino) return

    const [empresa, vendedor, sistemasAtivos] = await Promise.all([
      prisma.company.findUnique({ where: { id: proposal.companyId }, select: { nome_empresa: true } }),
      prisma.user.findUnique({ where: { id: proposal.vendedorId }, select: { nome: true, email: true } }),
      tipo === "EM_REVISAO"
        ? prisma.environment.findMany({
            where: { proposalId: proposal.id, status: "ATIVO" },
            select: { nome: true },
          })
        : Promise.resolve([]),
    ])

    const args = {
      nomeCliente: proposal.client_name,
      numero: proposal.numero,
      empresa: empresa?.nome_empresa ?? "Controllares",
      consultor: vendedor,
      mensagem: extra.mensagem ?? null,
      // Só faz sentido listar o que será revisto quando ele escolheu parte.
      sistemas: extra.guardados ? sistemasAtivos.map(e => e.nome?.trim() || "Sistema") : [],
    }

    const { subject, html } = tipo === "EM_REVISAO" ? emailRevisao(args) : emailRecusa(args)
    await enviarEmail({ to: [destino], subject, html })
  } catch {
    /* Aviso é cortesia; a decisão do cliente já está registrada. */
  }
}

/**
 * Registra a condição que o CLIENTE montou.
 *
 * É ela que segue para o faturamento: sem isso a equipe redigitava tudo de
 * novo, com risco de divergir do que foi combinado. "Parcelado na obra" fica
 * sem parcelas de propósito, porque o número é acertado com o Admin depois.
 */
async function gravarPagamento(
  proposal: { id: string; desconto_aplicado: number | null },
  pagamento?: { forma?: string; parcelas?: number; entrada?: number; observacao?: string },
) {
  const FORMAS_VALIDAS = ["CARTAO", "AVISTA", "OBRA", "PERSONALIZADO"]
  if (!pagamento?.forma || !FORMAS_VALIDAS.includes(pagamento.forma)) return

  const parcelas = pagamento.forma === "CARTAO"
    ? Math.max(1, Math.min(6, Number(pagamento.parcelas) || 1))
    : 1
  const entrada = ["AVISTA", "PERSONALIZADO"].includes(pagamento.forma)
    ? 0
    : Math.max(0, Number(pagamento.entrada) || 0)

  await prisma.proposal.update({
    where: { id: proposal.id },
    data: {
      forma_pagamento: pagamento.forma,
      // OBRA e PERSONALIZADO ficam sem parcelas: o número sai do acordo.
      parcelas_forma: ["OBRA", "PERSONALIZADO"].includes(pagamento.forma) ? null : parcelas,
      valor_entrada: entrada > 0 ? entrada : null,
      pagamento_definido_em: new Date(),
      pagamento_definido_por: "CLIENTE",
      // A condição que o cliente escreveu entra na mensagem: é o que a equipe
      // precisa ler para negociar.
      ...(pagamento.observacao?.trim() && {
        mensagem_cliente: `Condição proposta pelo cliente: ${pagamento.observacao.trim().slice(0, 1500)}`,
        mensagem_cliente_em: new Date(),
      }),
      // À vista concede os 5%. Desconto negociado maior prevalece.
      ...(pagamento.forma === "AVISTA" && {
        desconto_aplicado: Math.max(5, Number(proposal.desconto_aplicado ?? 0)),
      }),
    },
  })
}
