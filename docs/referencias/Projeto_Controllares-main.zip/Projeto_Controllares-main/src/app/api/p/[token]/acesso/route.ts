import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { enviarEmail } from "@/lib/email"
import {
  emitirCodigo, conferirCodigo, abrirSessao, temSessao, emailsAutorizados,
} from "@/lib/acesso-proposta"
import { registrar, origem } from "@/lib/vigia"

export const dynamic = "force-dynamic"

/**
 * Portão do link público.
 *
 * GET  — o visitante já tem sessão? A página decide se mostra o documento ou o
 *        pedido de código.
 * POST — `{ email }` manda o código; `{ codigo }` troca o código pela sessão.
 *
 * Nenhuma resposta diz se um e-mail é ou não o do cliente: responder "esse não
 * é o e-mail" transforma o link num verificador de endereços, e quem tem o
 * link descobriria para quem ela foi enviada testando candidatos.
 */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params
  return NextResponse.json({ liberado: await temSessao(token) })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params
  const { email, codigo } = await req.json().catch(() => ({}))

  const proposal = await prisma.proposal.findUnique({
    where: { link_token: token },
    select: {
      id: true, numero: true, client_name: true, fat_email: true, client_email: true,
      status: true, data_expiracao: true,
      company: { select: { nome_empresa: true } },
    },
  })
  if (!proposal) return NextResponse.json({ error: "Link inválido." }, { status: 404 })

  if (proposal.data_expiracao && new Date(proposal.data_expiracao) < new Date()) {
    return NextResponse.json({ error: "Este link expirou. Peça um novo ao vendedor." }, { status: 410 })
  }

  /* ---- 2ª etapa: trocar o código pela sessão ---- */
  if (codigo) {
    const r = await conferirCodigo(proposal.id, String(codigo))
    if (!r.ok) {
      const o = origem(req)
      await registrar({
        tipo: "PROPOSTA_CODIGO_FALHA",
        descricao: `Código recusado no link da proposta ${proposal.numero}: ${r.erro}`,
        ip: o.ip, userAgent: o.userAgent, rota: "/api/p/[token]/acesso",
      })
      return NextResponse.json({ error: r.erro }, { status: 403 })
    }
    await abrirSessao(token)
    return NextResponse.json({ ok: true })
  }

  /* ---- 1ª etapa: mandar o código para o e-mail do contratante ---- */
  const informado = String(email ?? "").trim().toLowerCase()
  if (!informado) return NextResponse.json({ error: "Informe seu e-mail." }, { status: 400 })

  const autorizados = emailsAutorizados(proposal)

  /* Resposta idêntica para e-mail certo e errado. A diferença de mensagem — ou
     mesmo de tempo de resposta — diria a quem tem o link para quem a proposta
     foi mandada. */
  const respostaNeutra = NextResponse.json({
    enviado: true,
    aviso: "Se este for o e-mail que recebeu a proposta, o código chega em instantes.",
  })

  if (!autorizados.includes(informado)) return respostaNeutra

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null
  const { codigo: gerado, validadeMin } = await emitirCodigo(proposal.id, informado, ip)

  const html = `
    <div style="font-family:system-ui,-apple-system,Segoe UI,sans-serif;max-width:520px;margin:0 auto;color:#111">
      <p style="font-size:15px;line-height:1.6">Olá, ${proposal.client_name ?? ""}.</p>
      <p style="font-size:15px;line-height:1.6">
        Use o código abaixo para abrir a proposta <strong>${proposal.numero}</strong>.
      </p>
      <p style="font-size:34px;font-weight:700;letter-spacing:.22em;margin:26px 0;
                text-align:center;font-family:ui-monospace,monospace">${gerado}</p>
      <p style="font-size:13px;color:#555;line-height:1.6">
        O código vale por ${validadeMin} minutos e serve só para este acesso.
        Se não foi você que pediu, ignore este e-mail — sem o código ninguém abre a proposta.
      </p>
      <p style="font-size:13px;color:#555">${proposal.company.nome_empresa}</p>
    </div>`

  const ok = await enviarEmail({
    to: [informado],
    subject: `Código de acesso — proposta ${proposal.numero}`,
    html,
  })

  /* Falha de envio precisa aparecer: calar aqui deixaria o cliente esperando um
     e-mail que nunca sai, sem ninguém saber. Quem informou um endereço errado
     não chega nesta linha, então isso não vaza a lista de autorizados. */
  if (!ok) {
    return NextResponse.json(
      { error: "Não foi possível enviar o código agora. Tente de novo em instantes." },
      { status: 502 },
    )
  }

  return respostaNeutra
}
