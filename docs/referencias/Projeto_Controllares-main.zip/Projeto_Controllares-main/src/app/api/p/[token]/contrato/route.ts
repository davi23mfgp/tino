import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { temSessao } from "@/lib/acesso-proposta"

export const dynamic = "force-dynamic"

/**
 * GET /api/p/[token]/contrato — contrato pelo link público.
 *
 * O e-mail levava só um texto: o cliente recebia "segue o contrato" e não
 * tinha o contrato. Anexar PDF exigiria gerar o arquivo no servidor; o link
 * resolve com o que já existe.
 *
 * Autoriza pelo mesmo token da proposta — quem tem o link já vê valores e
 * escopo, então o contrato não expõe nada novo. Só abre depois de gerado:
 * antes disso não há documento a mostrar.
 */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params

  const proposal = await prisma.proposal.findUnique({
    where: { link_token: token },
    select: { id: true, companyId: true, contrato_gerado_em: true, contrato_modelo_id: true },
  })
  if (!proposal) return new NextResponse("Contrato não encontrado", { status: 404 })
  /* Mesmo portão da proposta. O contrato traz valores, condições e os dados de
     faturamento do cliente — abrir com o link solto o exporia a quem quer que
     tenha recebido o endereço encaminhado. */
  if (!(await temSessao(token))) {
    return new NextResponse(
      "Abra a proposta pelo link e confirme o código enviado ao seu e-mail para ver o contrato.",
      { status: 401 },
    )
  }

  if (!proposal.contrato_gerado_em || !proposal.contrato_modelo_id) {
    return new NextResponse("O contrato ainda não foi gerado.", { status: 404 })
  }

  /* Reaproveita a geração interna. A rota interna exige sessão, então a
     renderização mora numa função só, chamada pelos dois caminhos. */
  const { montarContrato } = await import("@/lib/contrato")
  const html = await montarContrato(proposal.id, proposal.companyId, proposal.contrato_modelo_id, {
    publico: true,
  })
  if (!html) return new NextResponse("Contrato não encontrado", { status: 404 })

  return new NextResponse(html, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      /* Sem isto o navegador guarda o contrato pela heurística dele: a URL não
         muda quando o modelo é reeditado, e reabrir a tela devolvia a versão
         antiga até um Ctrl+Shift+R. O contrato é montado na hora a cada
         chamada — cache aqui só atrasa o que já está pronto. */
      "Cache-Control": "no-store, no-cache, must-revalidate",
      Pragma: "no-cache",
      Expires: "0",
    },
  })
}