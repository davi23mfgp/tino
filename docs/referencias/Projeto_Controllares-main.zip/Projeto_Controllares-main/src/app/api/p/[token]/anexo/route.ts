import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { get } from "@vercel/blob"
import { temSessao } from "@/lib/acesso-proposta"

/**
 * GET /api/p/[token]/anexo?url=<url do arquivo>
 *
 * Entrega um anexo (PDF, DWG, planilha…) de uma página extra da proposta.
 *
 * A Blob Store é privada: a URL do arquivo não abre direto no navegador.
 * Quem autentica é o servidor, e o acesso é liberado por duas travas:
 *   1. o token da proposta precisa existir e estar dentro da validade;
 *   2. a URL pedida precisa ser um anexo DAQUELA proposta — não dá para usar
 *      esta rota como proxy genérico para qualquer arquivo do Blob.
 */
export async function GET(req: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params
  const url = new URL(req.url).searchParams.get("url")
  if (!url) return NextResponse.json({ error: "url obrigatória" }, { status: 400 })

  const proposal = await prisma.proposal.findUnique({
    where: { link_token: token },
    select: { status: true, data_expiracao: true, extraPages: { select: { anexos: true } } },
  })
  if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })

  if (proposal.data_expiracao && new Date(proposal.data_expiracao) < new Date()) {
    return NextResponse.json({ error: "Este link expirou." }, { status: 410 })
  }

  /* Terceira trava: quem pede o anexo precisa ter passado pelo código. Sem
     isso, o link solto continuaria entregando projeto, planta e orçamento
     anexados — os arquivos mais sensíveis da proposta. */
  if (proposal.status !== "RASCUNHO" && !(await temSessao(token))) {
    return NextResponse.json({ error: "Confirme o código enviado ao seu e-mail." }, { status: 401 })
  }

  // Só passa o que está declarado como anexo desta proposta.
  const permitidas = new Set<string>()
  for (const pg of proposal.extraPages) {
    const lista = Array.isArray(pg.anexos) ? pg.anexos : []
    for (const a of lista as { url?: string }[]) {
      if (a?.url) permitidas.add(a.url)
    }
  }
  if (!permitidas.has(url)) {
    return NextResponse.json({ error: "Arquivo não pertence a esta proposta" }, { status: 403 })
  }

  const nomeArquivo = decodeURIComponent(url.split("/").pop()?.split("?")[0] ?? "anexo")
  const token_blob =
    process.env.BLOB_READ_WRITE_TOKEN ||
    Object.entries(process.env).find(([k]) => k.endsWith("_READ_WRITE_TOKEN"))?.[1]

  // Numa Store pública o GET direto resolve. Blob privado devolve 403 e só sai
  // pelo get() do SDK — por isso ele fica como reserva, tentado apenas quando
  // o GET falha, em vez de encarecer todo download.
  async function viaBlobPrivado() {
    if (!token_blob || !/(^|\.)blob\.vercel-storage\.com$/i.test(new URL(url!).hostname)) return null
    try {
      const r = await get(url!, { access: "private", token: token_blob })
      if (r?.statusCode !== 200) return null
      return new NextResponse(r.stream as unknown as BodyInit, {
        headers: {
          "Content-Type": r.blob.contentType || "application/octet-stream",
          "Content-Disposition": `inline; filename="${nomeArquivo}"`,
          "Cache-Control": "private, max-age=3600",
        },
      })
    } catch {
      return null
    }
  }

  try {
    const upstream = await fetch(url, { signal: AbortSignal.timeout(15_000) })
    if (!upstream.ok) {
      const viaSdk = await viaBlobPrivado()
      if (viaSdk) return viaSdk
      return NextResponse.json({ error: `A origem respondeu ${upstream.status}` }, { status: 502 })
    }
    return new NextResponse(upstream.body, {
      headers: {
        "Content-Type": upstream.headers.get("content-type") ?? "application/octet-stream",
        "Content-Disposition": `inline; filename="${nomeArquivo}"`,
        "Cache-Control": "private, max-age=3600",
      },
    })
  } catch {
    const viaSdk = await viaBlobPrivado()
    if (viaSdk) return viaSdk
    return NextResponse.json({ error: "Falha ao buscar o arquivo" }, { status: 502 })
  }
}
