import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * Painel do DONO DO SITE (plataforma). Gate por e-mail em PLATFORM_OWNER_EMAIL
 * (lista separada por vírgula). Lista e autoriza empresas novas cujo ADMIN
 * está PENDENTE. Aprovar = liberar o acesso (status ATIVO). Recusar = apagar.
 */
async function ehDono(userId: string): Promise<boolean> {
  const owners = (process.env.PLATFORM_OWNER_EMAIL || "").split(",").map(s => s.trim().toLowerCase()).filter(Boolean)
  if (!owners.length) return false
  const me = await prisma.user.findUnique({ where: { id: userId }, select: { email: true } })
  return !!me && owners.includes(me.email.toLowerCase())
}

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!(await ehDono(session.userId))) return NextResponse.json({ error: "Acesso restrito ao dono do site" }, { status: 403 })

  const pendentes = await prisma.user.findMany({
    where: { role: "ADMIN", status: "PENDENTE" },
    orderBy: { createdAt: "asc" },
    select: { id: true, nome: true, email: true, createdAt: true, company: { select: { nome_empresa: true, cnpj_cpf: true } } },
  })
  return NextResponse.json({
    pendentes: pendentes.map(u => ({
      id: u.id, nome: u.nome, email: u.email, criadoEm: u.createdAt,
      empresa: u.company?.nome_empresa ?? "—", cnpj: u.company?.cnpj_cpf ?? "—",
    })),
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!(await ehDono(session.userId))) return NextResponse.json({ error: "Acesso restrito ao dono do site" }, { status: 403 })

  const { userId, acao } = await req.json().catch(() => ({}))
  if (!userId || !["APROVAR", "RECUSAR"].includes(acao)) {
    return NextResponse.json({ error: "Parâmetros inválidos" }, { status: 400 })
  }
  const alvo = await prisma.user.findFirst({ where: { id: userId, role: "ADMIN", status: "PENDENTE" }, select: { id: true, companyId: true } })
  if (!alvo) return NextResponse.json({ error: "Empresa pendente não encontrada" }, { status: 404 })

  if (acao === "APROVAR") {
    await prisma.user.update({ where: { id: alvo.id }, data: { status: "ATIVO" } })
  } else {
    // Recusar: remove o admin e a empresa recém-criada (sem dados ainda).
    await prisma.company.delete({ where: { id: alvo.companyId } }).catch(async () => {
      await prisma.user.delete({ where: { id: alvo.id } })
    })
  }
  return NextResponse.json({ ok: true })
}
