import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/** GET /api/descontos — fila de aprovação. ADMIN vê tudo; vendedor vê os seus. */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const pedidos = await prisma.discountApproval.findMany({
    where: {
      companyId: session.companyId,
      ...(session.role === "ADMIN" ? {} : { solicitanteId: session.userId }),
    },
    orderBy: { createdAt: "desc" },
    take: 100,
  })
  return NextResponse.json({ pedidos, isAdmin: session.role === "ADMIN" })
}

/**
 * POST /api/descontos — vendedor pede desconto acima do teto.
 * { valor_desconto, justificativa?, proposalId? }
 */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { valor_desconto, justificativa, proposalId } = await req.json().catch(() => ({}))
  const valor = Number(valor_desconto)
  if (!valor || valor <= 0) return NextResponse.json({ error: "Valor de desconto inválido." }, { status: 400 })

  const company = await prisma.company.findUnique({
    where: { id: session.companyId },
    select: { desconto_maximo: true },
  })
  const teto = company?.desconto_maximo ?? 0

  const pedido = await prisma.discountApproval.create({
    data: {
      companyId: session.companyId,
      proposalId: proposalId || null,
      solicitanteId: session.userId,
      solicitanteNome: session.nome,
      valor_desconto: valor,
      teto_permitido: teto,
      justificativa: justificativa?.trim() || null,
    },
  })

  // Notifica o ADMIN na gaveta de notificações
  await prisma.webhookDebugLog.create({
    data: {
      companyId: session.companyId,
      endpoint: "internal/desconto-solicitado",
      payload_json: { client_name: `${session.nome} pediu desconto de ${valor}`, numero: pedido.id.slice(0, 8) },
      reenviado: false,
    },
  }).catch(() => {})

  return NextResponse.json({ pedido }, { status: 201 })
}

/** PATCH /api/descontos — ADMIN decide. { id, acao: APROVAR | RECUSAR } */
export async function PATCH(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (session.role !== "ADMIN") return NextResponse.json({ error: "Só o Admin decide descontos" }, { status: 403 })

  const { id, acao } = await req.json().catch(() => ({}))
  if (!id || !["APROVAR", "RECUSAR"].includes(acao)) {
    return NextResponse.json({ error: "Dados inválidos." }, { status: 400 })
  }

  const pedido = await prisma.discountApproval.findFirst({ where: { id, companyId: session.companyId } })
  if (!pedido) return NextResponse.json({ error: "Pedido não encontrado" }, { status: 404 })

  const atualizado = await prisma.discountApproval.update({
    where: { id },
    data: {
      status: acao === "APROVAR" ? "APROVADO" : "RECUSADO",
      decididoPorNome: session.nome,
      decididoEm: new Date(),
    },
  })

  // Avisa o vendedor
  await prisma.webhookDebugLog.create({
    data: {
      companyId: session.companyId,
      endpoint: "internal/desconto-decidido",
      payload_json: { client_name: `Desconto de ${pedido.valor_desconto} ${acao === "APROVAR" ? "aprovado" : "recusado"} para ${pedido.solicitanteNome}`, numero: id.slice(0, 8) },
      reenviado: false,
    },
  }).catch(() => {})

  return NextResponse.json({ pedido: atualizado })
}
