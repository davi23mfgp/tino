import { NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export const dynamic = "force-dynamic"

/* Uma lista fixa de sugestões serve à casa de quem escreveu o código, não à
   empresa que usa. Aqui o atalho sai do que ESTA empresa mais nomeia: quem
   monta home cinema quer "Home Theater" e "Sala de Estar"; quem faz obra
   corporativa quer "Recepção" e "Sala de Reunião". */
const PADRAO = ["Sala de Estar", "Home Theater", "Cozinha", "Quarto", "Área Externa", "Escritório"]
const QUANTOS = 8

/**
 * GET /api/ambientes/frequentes — os nomes de ambiente mais usados.
 *
 * `?de=obra` conta os ambientes FÍSICOS da obra (Sala, Suíte 2). É outra lista
 * da dos sistemas vendidos na proposta (Automação, Som): misturar daria atalho
 * de sistema na hora de nomear cômodo.
 */
export async function GET(req: Request) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const deObra = new URL(req.url).searchParams.get("de") === "obra"

  const grupos = deObra
    ? await prisma.obraAmbiente.groupBy({
        by: ["nome"],
        where: { obra: { companyId: session.companyId } },
        _count: { nome: true },
        orderBy: { _count: { nome: "desc" } },
        take: QUANTOS * 3,
      })
    : await prisma.environment.groupBy({
        by: ["nome"],
        where: { companyId: session.companyId },
        _count: { nome: true },
        orderBy: { _count: { nome: "desc" } },
        take: QUANTOS * 3,
      })

  /* "Sala de estar" e "SALA DE ESTAR" são o mesmo atalho e competiriam entre
     si por uma vaga. O primeiro a aparecer é o mais usado, e é a grafia que
     fica — a contagem já vem ordenada. */
  const vistos = new Set<string>()
  const nomes: string[] = []
  for (const g of grupos) {
    const nome = g.nome.trim()
    const chave = nome.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase()
    if (!nome || vistos.has(chave)) continue
    vistos.add(chave)
    nomes.push(nome)
    if (nomes.length >= QUANTOS) break
  }

  /* Empresa nova não tem histórico, e um campo sem atalho nenhum é pior que um
     atalho genérico. Os padrões completam o que faltar. */
  for (const p of PADRAO) {
    if (nomes.length >= QUANTOS) break
    const chave = p.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase()
    if (!vistos.has(chave)) { vistos.add(chave); nomes.push(p) }
  }

  return NextResponse.json({ ambientes: nomes })
}
