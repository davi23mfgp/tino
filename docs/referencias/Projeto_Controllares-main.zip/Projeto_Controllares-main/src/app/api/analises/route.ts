import { NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * GET /api/analises — BI executivo da empresa inteira (só ADMIN).
 * Relatório minucioso para decisão: comercial, produtos, clientes, financeiro
 * (DRE + aging + inadimplência), manutenção, estoque, obras e time.
 * Tudo lido direto das tabelas operacionais (sem snapshot).
 */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (session.role !== "ADMIN") return NextResponse.json({ error: "Só o Admin acessa as análises" }, { status: 403 })

  const cid = session.companyId
  const agora = new Date()
  const num = (v: unknown) => Number(v ?? 0)
  const d30 = new Date(Date.now() - 30 * 864e5)
/**
 * Proposta ganha não é só a que está parada em ACEITA.
 *
 * O relatório inteiro filtrava por `status: "ACEITA"` literal. Só que a
 * proposta aceita não fica ali: no dia seguinte vira EM_CONTRATO, depois
 * EM_FATURAMENTO, depois CONCLUIDA. A cada passo do funil ela sumia da conta —
 * receita, DRE, top de clientes, curva ABC, produtos vendidos, tudo zerava
 * sozinho, e o relatório ficava mais pobre quanto melhor o mês tivesse sido.
 *
 * Ganha é qualquer estado depois do aceite. Uma vez ganha, sempre ganha.
 */
const GANHAS = ["ACEITA", "EM_CONTRATO", "EM_FATURAMENTO", "CONCLUIDA"] as const

/**
 * As propostas que geram recebível — a carteira.
 *
 * Diferente de GANHAS por uma linha: ACEITA fica de fora. Ganhar o negócio e ter
 * um título a receber são momentos distintos. O cliente aceita; só o contrato
 * fecha as datas. Antes disso as parcelas existem, mas com o vencimento que o
 * simulador propôs — e cobrar por data que ninguém combinou é o pior erro que
 * um relatório financeiro pode cometer.
 *
 * Vale para a_receber, atrasado, aging, inadimplência e recebido no mês.
 */
const EM_CARTEIRA = ["EM_CONTRATO", "EM_FATURAMENTO", "CONCLUIDA"] as const
const ehGanha = (s: string) => (GANHAS as readonly string[]).includes(s)

  const d180 = new Date(Date.now() - 180 * 864e5)
  const inicioMes = new Date(agora.getFullYear(), agora.getMonth(), 1)
  const ini12m = new Date(agora.getFullYear(), agora.getMonth() - 11, 1)

  const [
    funil, vendedores, topProdutosQtd, produtosInfo, itensAceitos,
    topClientes, propostasCliente, tickets, movimentos30, tarefas,
    tarefasAbertas, loginsSemana, parcelasAbertas, recebidoMes, perdidas,
    serie12m, obras,
  ] = await Promise.all([
    prisma.proposal.groupBy({ by: ["status"], where: { companyId: cid, createdAt: { gte: d180 } }, _count: true, _sum: { valor_total: true } }),
    prisma.proposal.groupBy({ by: ["vendedorId", "status"], where: { companyId: cid, createdAt: { gte: d180 } }, _count: true, _sum: { valor_total: true } }),
    prisma.proposalItem.groupBy({
      by: ["productId"],
      where: { proposal: { companyId: cid, status: { in: [...GANHAS] }, createdAt: { gte: d180 } }, productId: { not: null } },
      _sum: { quantidade: true, valor_total: true }, _count: true,
      orderBy: { _sum: { quantidade: "desc" } }, take: 15,
    }),
    prisma.catalogProduct.findMany({
      where: { companyId: cid },
      select: { id: true, nome: true, sku: true, preco_custo: true, preco_venda: true, estoque_qtd: true, estoque_minimo: true, status: true, category: { select: { nome: true } } },
    }),
    prisma.proposalItem.findMany({
      where: { proposal: { companyId: cid, status: { in: [...GANHAS] }, createdAt: { gte: d180 } } },
      select: { productId: true, categoryId: true, quantidade: true, valor_total: true, category: { select: { nome: true } } },
    }),
    prisma.proposal.groupBy({ by: ["client_name"], where: { companyId: cid, status: { in: [...GANHAS] }, createdAt: { gte: d180 } }, _sum: { valor_total: true }, _count: true, orderBy: { _sum: { valor_total: "desc" } }, take: 10 }),
    prisma.proposal.findMany({ where: { companyId: cid, status: { in: [...GANHAS] } }, select: { client_name: true, createdAt: true, valor_total: true } }),
    prisma.maintenanceTicket.findMany({ where: { companyId: cid }, select: { status: true, decisao_faturamento: true, itens_usados: true, obra: { select: { client_name: true } }, createdAt: true } }),
    prisma.stockMovement.groupBy({ by: ["tipo"], where: { companyId: cid, createdAt: { gte: d30 }, status: "APLICADO" }, _sum: { quantidade: true }, _count: true }),
    prisma.tarefa.findMany({ where: { companyId: cid, concluida: true }, select: { atribuido: { select: { nome: true } }, criador: { select: { nome: true } } } }),
    prisma.tarefa.findMany({ where: { companyId: cid, concluida: false }, select: { atribuido: { select: { nome: true } } } }),
    prisma.aiAuditLog.count({ where: { companyId: cid, tipo_acesso: "LOGIN", timestamp: { gte: new Date(Date.now() - 7 * 864e5) } } }),
    prisma.installment.findMany({ where: { proposal: { companyId: cid, status: { in: [...EM_CARTEIRA] } }, status: { not: "PAGO" } }, select: { valor: true, data_vencimento: true } }),
    prisma.installment.aggregate({ where: { proposal: { companyId: cid, status: { in: [...EM_CARTEIRA] } }, status: "PAGO", data_vencimento: { gte: inicioMes } }, _sum: { valor: true } }),
    prisma.proposal.findMany({ where: { companyId: cid, status: "PROPOSTA_PERDIDA" }, select: { motivo_perda: true, vendedor: { select: { nome: true } }, valor_total: true } }),
    prisma.proposal.findMany({ where: { companyId: cid, createdAt: { gte: ini12m } }, select: { createdAt: true, status: true, valor_total: true } }),
    prisma.obra.findMany({ where: { companyId: cid }, select: { etapa: true, physical_progress_percentage: true, previsao_finalizacao_instalacao: true, client_name: true } }),
  ])

  // ───────── Comercial ─────────
  const porStatus = Object.fromEntries(funil.map(p => [p.status, { qtd: p._count, valor: num(p._sum.valor_total) }]))
  const totalPropostas = funil.reduce((s, p) => s + p._count, 0)
  const aceitas = GANHAS.reduce((t, st) => t + (porStatus[st]?.qtd ?? 0), 0)
  const conversao = totalPropostas ? (aceitas / totalPropostas) * 100 : 0
  const valorAceito = GANHAS.reduce((t, st) => t + (porStatus[st]?.valor ?? 0), 0)
  const ticketMedio = aceitas ? valorAceito / aceitas : 0
  const pipelineAberto = funil.filter(p => ["ENVIADA", "LIDA", "EM_REVISAO"].includes(p.status)).reduce((s, p) => s + num(p._sum.valor_total), 0)

  const vendIds = [...new Set(vendedores.map(v => v.vendedorId))]
  const vendNomes = await prisma.user.findMany({ where: { id: { in: vendIds } }, select: { id: true, nome: true } })
  const nomeById = new Map(vendNomes.map(v => [v.id, v.nome]))
  const rankMap = new Map<string, { nome: string; total: number; aceitas: number; valor: number }>()
  for (const v of vendedores) {
    const r = rankMap.get(v.vendedorId) ?? { nome: nomeById.get(v.vendedorId) ?? "—", total: 0, aceitas: 0, valor: 0 }
    r.total += v._count
    if (ehGanha(v.status)) { r.aceitas += v._count; r.valor += num(v._sum.valor_total) }
    rankMap.set(v.vendedorId, r)
  }
  const rankingVendedores = [...rankMap.values()].map(r => ({
    ...r, conversao: r.total ? Math.round((r.aceitas / r.total) * 1000) / 10 : 0,
    ticket: r.aceitas ? Math.round(r.valor / r.aceitas) : 0,
  })).sort((a, b) => b.valor - a.valor)

  const motivos = new Map<string, { qtd: number; valor: number }>()
  for (const p of perdidas) {
    const m = p.motivo_perda || "Sem motivo informado"
    const r = motivos.get(m) ?? { qtd: 0, valor: 0 }
    r.qtd++; r.valor += num(p.valor_total); motivos.set(m, r)
  }
  const valorPerdido = perdidas.reduce((s, p) => s + num(p.valor_total), 0)

  // Série 12 meses (criadas, aceitas, valor aceito)
  const meses: { mes: string; criadas: number; aceitas: number; valor: number }[] = []
  for (let i = 0; i < 12; i++) {
    const d = new Date(agora.getFullYear(), agora.getMonth() - 11 + i, 1)
    meses.push({ mes: d.toLocaleDateString("pt-BR", { month: "short", year: "2-digit" }), criadas: 0, aceitas: 0, valor: 0 })
  }
  const idxMes = (d: Date) => (d.getFullYear() - ini12m.getFullYear()) * 12 + (d.getMonth() - ini12m.getMonth())
  for (const p of serie12m) {
    const i = idxMes(new Date(p.createdAt))
    if (i < 0 || i > 11) continue
    meses[i].criadas++
    if (ehGanha(p.status)) { meses[i].aceitas++; meses[i].valor += num(p.valor_total) }
  }

  // ───────── Produtos (qtd, faturamento, margem, ABC) ─────────
  const prodById = new Map(produtosInfo.map(p => [p.id, p]))
  const faturamentoPorProduto = new Map<string, { qtd: number; faturamento: number }>()
  const porCategoria = new Map<string, { qtd: number; faturamento: number }>()
  for (const it of itensAceitos) {
    const pid = it.productId
    if (pid) {
      const r = faturamentoPorProduto.get(pid) ?? { qtd: 0, faturamento: 0 }
      r.qtd += it.quantidade; r.faturamento += num(it.valor_total); faturamentoPorProduto.set(pid, r)
    }
    const cat = it.category?.nome ?? prodById.get(pid ?? "")?.category?.nome ?? "Sem categoria"
    const c = porCategoria.get(cat) ?? { qtd: 0, faturamento: 0 }
    c.qtd += it.quantidade; c.faturamento += num(it.valor_total); porCategoria.set(cat, c)
  }

  const maisVendidos = topProdutosQtd.map(t => {
    const p = t.productId ? prodById.get(t.productId) : null
    return { nome: p?.nome ?? "—", sku: p?.sku ?? "", categoria: p?.category?.nome ?? "—", qtd: t._sum.quantidade ?? 0, faturamento: num(t._sum.valor_total) }
  })
  const maiorFaturamento = [...faturamentoPorProduto.entries()]
    .map(([pid, r]) => ({ nome: prodById.get(pid)?.nome ?? "—", sku: prodById.get(pid)?.sku ?? "", ...r }))
    .sort((a, b) => b.faturamento - a.faturamento).slice(0, 10)

  // Curva ABC por faturamento acumulado
  const ordFat = [...maiorFaturamento].sort((a, b) => b.faturamento - a.faturamento)
  const totalFat = ordFat.reduce((s, p) => s + p.faturamento, 0) || 1
  let acc = 0
  const curvaABC = ordFat.map(p => {
    acc += p.faturamento
    const pct = (acc / totalFat) * 100
    return { nome: p.nome, faturamento: p.faturamento, classe: pct <= 80 ? "A" : pct <= 95 ? "B" : "C" }
  })

  // Margem por produto (catálogo: venda-custo) — top e piores
  const margens = produtosInfo.map(p => {
    const venda = num(p.preco_venda), custo = num(p.preco_custo)
    const margem = venda - custo
    const pct = venda ? (margem / venda) * 100 : 0
    return { nome: p.nome, sku: p.sku, margem, pct: Math.round(pct * 10) / 10 }
  })
  const margemTop = [...margens].sort((a, b) => b.pct - a.pct).slice(0, 8)
  const margemBaixa = [...margens].filter(m => m.pct < 15).sort((a, b) => a.pct - b.pct).slice(0, 8)

  // Produtos parados (nunca vendidos no período)
  const vendidosIds = new Set(itensAceitos.map(i => i.productId).filter(Boolean))
  const parados = produtosInfo.filter(p => p.status === "ATIVO" && !vendidosIds.has(p.id)).map(p => ({ nome: p.nome, sku: p.sku })).slice(0, 12)

  const categoriasRanking = [...porCategoria.entries()].map(([nome, r]) => ({ nome, ...r })).sort((a, b) => b.faturamento - a.faturamento).slice(0, 10)

  // ───────── Clientes (novos vs recorrentes, ticket) ─────────
  const porCliente = new Map<string, { compras: number; valor: number; primeira: Date }>()
  for (const p of propostasCliente) {
    const r = porCliente.get(p.client_name) ?? { compras: 0, valor: 0, primeira: new Date(p.createdAt) }
    r.compras++; r.valor += num(p.valor_total)
    if (new Date(p.createdAt) < r.primeira) r.primeira = new Date(p.createdAt)
    porCliente.set(p.client_name, r)
  }
  const clientesArr = [...porCliente.values()]
  const recorrentes = clientesArr.filter(c => c.compras > 1).length
  const novos = clientesArr.filter(c => c.compras === 1).length
  const ticketPorCliente = clientesArr.length ? clientesArr.reduce((s, c) => s + c.valor, 0) / clientesArr.length : 0

  // ───────── Financeiro (DRE, aging, inadimplência) ─────────
  const hoje = new Date()
  let aReceber = 0, atrasado = 0
  const aging = { d0_30: 0, d31_60: 0, d61_90: 0, d90mais: 0 }
  for (const i of parcelasAbertas) {
    const v = num(i.valor); aReceber += v
    const venc = new Date(i.data_vencimento)
    const diasAtraso = Math.floor((hoje.getTime() - venc.getTime()) / 864e5)
    if (diasAtraso > 0) {
      atrasado += v
      if (diasAtraso <= 30) aging.d0_30 += v
      else if (diasAtraso <= 60) aging.d31_60 += v
      else if (diasAtraso <= 90) aging.d61_90 += v
      else aging.d90mais += v
    }
  }
  const inadimplencia = aReceber ? Math.round((atrasado / aReceber) * 1000) / 10 : 0

  // DRE simplificado: receita aceita vs custo estimado dos itens vendidos
  let custoEstimado = 0
  for (const it of itensAceitos) {
    const p = it.productId ? prodById.get(it.productId) : null
    if (p) custoEstimado += num(p.preco_custo) * it.quantidade
  }
  const margemBruta = valorAceito - custoEstimado
  const margemBrutaPct = valorAceito ? Math.round((margemBruta / valorAceito) * 1000) / 10 : 0

  // ───────── Manutenção (valor faturado vs custeado) ─────────
  const ticketsPorStatus: Record<string, number> = {}
  const chamadosPorObra = new Map<string, number>()
  let faturados = 0, custeados = 0, valorFaturado = 0, valorCusteado = 0
  const valorItens = (arr: unknown): number => {
    if (!Array.isArray(arr)) return 0
    return (arr as { valor_total?: number }[]).reduce((s, i) => s + num(i.valor_total), 0)
  }
  for (const t of tickets) {
    ticketsPorStatus[t.status] = (ticketsPorStatus[t.status] ?? 0) + 1
    const obra = t.obra?.client_name ?? "—"
    chamadosPorObra.set(obra, (chamadosPorObra.get(obra) ?? 0) + 1)
    if (t.decisao_faturamento === "FATURAR") { faturados++; valorFaturado += valorItens(t.itens_usados) }
    if (t.decisao_faturamento === "CUSTEADO") { custeados++; valorCusteado += valorItens(t.itens_usados) }
  }
  const obrasMaisChamados = [...chamadosPorObra.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([obra, qtd]) => ({ obra, qtd }))
  const decididos = faturados + custeados
  const taxaFaturamento = decididos ? Math.round((faturados / decididos) * 1000) / 10 : 0

  // ───────── Estoque (valor imobilizado, ruptura) ─────────
  let valorEstoqueCusto = 0, valorEstoqueVenda = 0
  const estoquePorCategoria = new Map<string, number>()
  const abaixoMinimo: { nome: string; sku: string; saldo: number; minimo: number }[] = []
  for (const p of produtosInfo) {
    const qtd = p.estoque_qtd ?? 0
    if (qtd > 0) {
      valorEstoqueCusto += num(p.preco_custo) * qtd
      valorEstoqueVenda += num(p.preco_venda) * qtd
      const cat = p.category?.nome ?? "Sem categoria"
      estoquePorCategoria.set(cat, (estoquePorCategoria.get(cat) ?? 0) + num(p.preco_custo) * qtd)
    }
    if (p.status === "ATIVO" && p.estoque_minimo != null && p.estoque_qtd != null && p.estoque_qtd <= p.estoque_minimo) {
      abaixoMinimo.push({ nome: p.nome, sku: p.sku, saldo: p.estoque_qtd, minimo: p.estoque_minimo })
    }
  }
  const estoqueCategorias = [...estoquePorCategoria.entries()].map(([nome, valor]) => ({ nome, valor })).sort((a, b) => b.valor - a.valor).slice(0, 8)

  // ───────── Obras (etapas, atrasadas, progresso) ─────────
  const obrasPorEtapa = new Map<string, number>()
  let obrasAtrasadas = 0, somaProgresso = 0
  const listaAtrasadas: { obra: string; dias: number }[] = []
  for (const o of obras) {
    const et = o.etapa ?? "—"
    obrasPorEtapa.set(et, (obrasPorEtapa.get(et) ?? 0) + 1)
    somaProgresso += o.physical_progress_percentage
    if (o.previsao_finalizacao_instalacao && o.physical_progress_percentage < 100) {
      const prev = new Date(o.previsao_finalizacao_instalacao)
      if (prev < hoje) {
        obrasAtrasadas++
        listaAtrasadas.push({ obra: o.client_name, dias: Math.floor((hoje.getTime() - prev.getTime()) / 864e5) })
      }
    }
  }
  const progressoMedio = obras.length ? Math.round(somaProgresso / obras.length) : 0

  // ───────── Time ─────────
  const tarefasPor = new Map<string, number>()
  for (const t of tarefas) {
    const nome = t.atribuido?.nome ?? t.criador?.nome ?? "—"
    tarefasPor.set(nome, (tarefasPor.get(nome) ?? 0) + 1)
  }
  const cargaAberta = new Map<string, number>()
  for (const t of tarefasAbertas) {
    const nome = t.atribuido?.nome ?? "Sem responsável"
    cargaAberta.set(nome, (cargaAberta.get(nome) ?? 0) + 1)
  }

  return NextResponse.json({
    periodo_dias: 180,
    comercial: {
      funil: ["RASCUNHO", "ENVIADA", "LIDA", "EM_REVISAO", "ACEITA", "EM_CONTRATO", "EM_FATURAMENTO", "CONCLUIDA", "PROPOSTA_PERDIDA", "CANCELADA"].filter(s => porStatus[s]).map(s => ({ status: s, ...porStatus[s] })),
      total_propostas: totalPropostas, aceitas, conversao: Math.round(conversao * 10) / 10,
      ticket_medio: ticketMedio, valor_aceito: valorAceito, pipeline_aberto: pipelineAberto,
      ranking_vendedores: rankingVendedores,
      motivos_perda: [...motivos.entries()].map(([motivo, r]) => ({ motivo, ...r })).sort((a, b) => b.qtd - a.qtd),
      valor_perdido: valorPerdido,
      serie_mensal: meses,
    },
    produtos: {
      mais_vendidos: maisVendidos, maior_faturamento: maiorFaturamento,
      categorias: categoriasRanking, curva_abc: curvaABC,
      margem_top: margemTop, margem_baixa: margemBaixa, parados,
    },
    clientes: {
      top: topClientes.map(c => ({ nome: c.client_name, valor: num(c._sum.valor_total), propostas: c._count })),
      novos, recorrentes, total: clientesArr.length, ticket_medio: ticketPorCliente,
    },
    financeiro: {
      a_receber: aReceber, atrasado, recebido_mes: num(recebidoMes._sum.valor),
      inadimplencia, aging,
      dre: { receita: valorAceito, custo: custoEstimado, margem_bruta: margemBruta, margem_pct: margemBrutaPct },
    },
    manutencao: {
      por_status: ticketsPorStatus, total: tickets.length, obras_mais_chamados: obrasMaisChamados,
      faturados, custeados, valor_faturado: valorFaturado, valor_custeado: valorCusteado, taxa_faturamento: taxaFaturamento,
    },
    estoque: {
      valor_custo: valorEstoqueCusto, valor_venda: valorEstoqueVenda,
      movimentos_30d: movimentos30.map(m => ({ tipo: m.tipo, qtd: m._sum.quantidade ?? 0, lancamentos: m._count })),
      abaixo_minimo: abaixoMinimo.slice(0, 15), categorias: estoqueCategorias,
    },
    obras: {
      por_etapa: [...obrasPorEtapa.entries()].map(([etapa, qtd]) => ({ etapa, qtd })),
      atrasadas: obrasAtrasadas, lista_atrasadas: listaAtrasadas.sort((a, b) => b.dias - a.dias).slice(0, 8),
      progresso_medio: progressoMedio, total: obras.length,
    },
    time: {
      tarefas_concluidas: [...tarefasPor.entries()].map(([nome, qtd]) => ({ nome, qtd })).sort((a, b) => b.qtd - a.qtd).slice(0, 8),
      carga_aberta: [...cargaAberta.entries()].map(([nome, qtd]) => ({ nome, qtd })).sort((a, b) => b.qtd - a.qtd).slice(0, 8),
      logins_semana: loginsSemana,
    },
  })
}
