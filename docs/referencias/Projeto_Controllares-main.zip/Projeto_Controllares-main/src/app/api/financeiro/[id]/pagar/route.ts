import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil, ehVendedorRestrito } from "@/lib/perfil";

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (ehVendedorRestrito(session)) return NextResponse.json({ error: "Acesso negado" }, { status: 403 })

  const { id } = await params

  const installment = await prisma.installment.findUnique({
    where: { id },
    include: { proposal: { select: { companyId: true } } }
  })

  if (!installment) return NextResponse.json({ error: "Parcela não encontrada" }, { status: 404 })
  if (installment.proposal.companyId !== session.companyId) {
    return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
  }

  const updated = await prisma.installment.update({
    where: { id },
    data: { status: "PAGO" }
  })

  const existingTxn = await prisma.financialTransaction.findFirst({
    where: { installmentId: id }
  })
  if (existingTxn) {
    await prisma.financialTransaction.update({
      where: { id: existingTxn.id },
      data: { status: "RECEBIDO" }
    })
  } else {
    await prisma.financialTransaction.create({
      data: {
        installmentId: id,
        proposalId: installment.proposalId,
        companyId: session.companyId,
        valor: installment.valor,
        status: "RECEBIDO",
      }
    })
  }

  return NextResponse.json({ installment: updated })
}
