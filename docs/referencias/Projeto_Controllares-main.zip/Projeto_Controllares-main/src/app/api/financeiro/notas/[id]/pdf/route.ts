import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { temAlgumPerfil } from "@/lib/perfil";
import { olistFetchBinary, OLIST_PATHS } from "@/lib/olist"

/**
 * GET /api/financeiro/notas/[id]/pdf — baixa o PDF/DANFE da NF via Olist.
 */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
  }

  const { id } = await params
  try {
    const { buffer, contentType } = await olistFetchBinary(session.companyId, OLIST_PATHS.pdfNota(id))
    return new NextResponse(buffer, {
      headers: {
        "Content-Type": contentType.includes("pdf") ? contentType : "application/pdf",
        "Content-Disposition": `attachment; filename="danfe-${id}.pdf"`,
      },
    })
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "erro" }, { status: 502 })
  }
}
