import { NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil, ehVendedorRestrito } from "@/lib/perfil";
import type { ContaReceberNorm, ContaPagarNorm, NotaNorm } from "@/lib/olist-sync"

/**
 * GET /api/financeiro/olist
 * Dados completos do painel financeiro: cards de resumo, contas a receber
 * (parcelas internas), contas a pagar e notas (cache do Olist), status de
 * sincronização por tipo e série do fluxo de caixa projetado.
 * Acesso: ADMIN e FINANCEIRO.
 */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
  }

  const company = await prisma.company.findUnique({
    where: { id: session.companyId },
    select: {
      olist_access_token: true,
      olist_cache_pagar: true,
      olist_cache_notas: true,
      olist_cache_receber: true,
    },
  })

  const olistConectado = !!company?.olist_access_token
  const contasPagar = (company?.olist_cache_pagar as unknown as ContaPagarNorm[]) ?? []
  const notas = (company?.olist_cache_notas as unknown as NotaNorm[]) ?? []
  const olistReceber = (company?.olist_cache_receber as unknown as ContaReceberNorm[]) ?? []

  // ---- Contas a receber = parcelas das propostas ACEITAS (fonte interna) ----
  const installments = await prisma.installment.findMany({
    where: { proposal: { companyId: session.companyId, status: "ACEITA" } },
    include: {
      proposal: { select: { numero: true, client_name: true, vendedor: { select: { nome: true } } } },
    },
    orderBy: { data_vencimento: "asc" },
  })

  const now = new Date()
  const mesAtual = now.toISOString().slice(0, 7)

  const contasReceber = installments.map(inst => {
    const statusEfetivo =
      inst.status === "PENDENTE" && new Date(inst.data_vencimento) < now
        ? "ATRASADO"
        : inst.status
    // tenta casar com status no Olist pela descrição/numero (best-effort)
    const noOlist = olistReceber.find(o =>
      o.descricao?.includes(inst.proposal.numero)
    )
    return {
      id: inst.id,
      cliente: inst.proposal.client_name,
      proposta: inst.proposal.numero,
      vendedor: inst.proposal.vendedor?.nome ?? "—",
      numero_parcela: inst.numero_parcela,
      valor: Number(inst.valor),
      vencimento: inst.data_vencimento.toISOString(),
      statusInterno: statusEfetivo,
      statusOlist: noOlist?.situacao ?? null,
    }
  })

  // ---- Cards ----
  const totalAReceber = contasReceber
    .filter(c => c.statusInterno !== "PAGO")
    .reduce((s, c) => s + c.valor, 0)

  const totalRecebidoMes = contasReceber
    .filter(c => c.statusInterno === "PAGO" && c.vencimento.slice(0, 7) === mesAtual)
    .reduce((s, c) => s + c.valor, 0)

  const totalAPagarMes = contasPagar
    .filter(c => (c.vencimento ?? "").slice(0, 7) === mesAtual && c.situacao !== "pago")
    .reduce((s, c) => s + c.valor, 0)

  const saldoProjetado = totalAReceber - contasPagar
    .filter(c => c.situacao !== "pago")
    .reduce((s, c) => s + c.valor, 0)

  const nfEmitidasMes = notas.filter(
    n => (n.dataEmissao ?? "").slice(0, 7) === mesAtual && n.situacao.includes("autoriz")
  ).length

  const nfPendentes = notas.filter(
    n => n.situacao.includes("pendente") || n.situacao.includes("rascunho")
  ).length

  // ---- Fluxo de caixa projetado (90 dias, agrupado por dia) ----
  const fluxo = buildFluxo(contasReceber, contasPagar, now)

  // ---- Status de sincronização por tipo ----
  const syncLogs = await prisma.olistSyncLog.findMany({
    where: { companyId: session.companyId },
    orderBy: { ultima_sync_em: "desc" },
    take: 30,
  })
  const syncStatus: Record<string, { status: string; em: string; erro: string | null }> = {}
  for (const tipo of ["CONTAS_RECEBER", "CONTAS_PAGAR", "NOTAS_FISCAIS"]) {
    const ultimo = syncLogs.find(l => l.tipo === tipo)
    if (ultimo) {
      syncStatus[tipo] = {
        status: ultimo.status,
        em: ultimo.ultima_sync_em.toISOString(),
        erro: ultimo.detalhes_erro,
      }
    }
  }

  return NextResponse.json({
    olistConectado,
    cards: {
      totalAReceber,
      totalRecebidoMes,
      totalAPagarMes,
      saldoProjetado,
      nfEmitidasMes,
      nfPendentes,
    },
    contasReceber,
    contasPagar,
    notas,
    fluxo,
    syncStatus,
  })
}

interface CRMini { valor: number; vencimento: string; statusInterno: string }
function buildFluxo(
  receber: CRMini[],
  pagar: ContaPagarNorm[],
  now: Date
) {
  // série diária de 90 dias: { dia, entradas, saidas }
  const dias: { dia: string; entradas: number; saidas: number }[] = []
  const base = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const idx = new Map<string, number>()
  for (let i = 0; i <= 90; i++) {
    const d = new Date(base.getTime() + i * 86400000).toISOString().slice(0, 10)
    idx.set(d, dias.length)
    dias.push({ dia: d, entradas: 0, saidas: 0 })
  }
  for (const c of receber) {
    if (c.statusInterno === "PAGO") continue
    const d = c.vencimento.slice(0, 10)
    const i = idx.get(d)
    if (i != null) dias[i].entradas += c.valor
  }
  for (const c of pagar) {
    if (c.situacao === "pago" || !c.vencimento) continue
    const d = c.vencimento.slice(0, 10)
    const i = idx.get(d)
    if (i != null) dias[i].saidas += c.valor
  }
  return dias
}
