import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil, ehVendedorRestrito } from "@/lib/perfil";
import { olistFetch, OLIST_PATHS } from "@/lib/olist"
import { syncOlist } from "@/lib/olist-sync"

/**
 * POST /api/financeiro/notas/[id]/cancelar
 * Cancela uma NF-e via Olist. AÇÃO IRREVERSÍVEL — exige body { confirmar: true }.
 * Acesso: ADMIN e FINANCEIRO.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
  }

  const { id } = await params
  const body = await req.json().catch(() => ({}))
  if (body?.confirmar !== true) {
    return NextResponse.json({ error: "Confirmação obrigatória para cancelar NF" }, { status: 400 })
  }

  try {
    const resp = await olistFetch(session.companyId, OLIST_PATHS.cancelarNota(id), { method: "POST" })
    await prisma.webhookDebugLog.create({
      data: { companyId: session.companyId, endpoint: "olist/nota/cancelar", response_body: `NF ${id} cancelada`, reenviado: false },
    })
    await syncOlist(session.companyId)
    return NextResponse.json({ success: true, resp })
  } catch (e) {
    const erro = e instanceof Error ? e.message : "erro"
    await prisma.webhookDebugLog.create({
      data: { companyId: session.companyId, endpoint: "olist/nota/cancelar", response_body: erro.slice(0, 500), reenviado: false },
    })
    return NextResponse.json({ error: erro }, { status: 502 })
  }
}
