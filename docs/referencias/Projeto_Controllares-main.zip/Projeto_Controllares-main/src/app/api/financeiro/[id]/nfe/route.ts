import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil, ehVendedorRestrito } from "@/lib/perfil";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (ehVendedorRestrito(session)) return NextResponse.json({ error: "Acesso negado" }, { status: 403 })

  const { id } = await params

  const installment = await prisma.installment.findUnique({
    where: { id },
    include: {
      proposal: { select: { id: true, numero: true, client_name: true, companyId: true } }
    }
  })

  if (!installment) return NextResponse.json({ error: "Parcela não encontrada" }, { status: 404 })
  if (installment.proposal.companyId !== session.companyId) {
    return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
  }

  const existingTxn = await prisma.financialTransaction.findFirst({
    where: { installmentId: id }
  })
  let txn
  if (existingTxn) {
    txn = await prisma.financialTransaction.update({
      where: { id: existingTxn.id },
      data: { nota_fiscal_status: "PENDENTE_ENVIO" }
    })
  } else {
    txn = await prisma.financialTransaction.create({
      data: {
        installmentId: id,
        proposalId: installment.proposalId,
        companyId: session.companyId,
        valor: installment.valor,
        status: "PENDENTE",
        nota_fiscal_status: "PENDENTE_ENVIO",
      }
    })
  }

  await prisma.webhookDebugLog.create({
    data: {
      endpoint: "webhook/contaazul/emitir-nfe",
      payload_json: {
        installmentId: id,
        proposalNumero: installment.proposal.numero,
        valor: Number(installment.valor),
        client_name: installment.proposal.client_name,
      },
      http_status: 0,
      response_body: "// FASE 8: chamada real à API do ContaAzul seria feita aqui",
      reenviado: false,
      companyId: session.companyId,
    }
  })

  return NextResponse.json({ success: true, nota_fiscal_status: txn.nota_fiscal_status })
}
