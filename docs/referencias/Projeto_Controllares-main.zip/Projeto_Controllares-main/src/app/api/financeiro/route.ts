import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil, ehVendedorRestrito } from "@/lib/perfil";

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (ehVendedorRestrito(session)) return NextResponse.json({ error: "Acesso negado" }, { status: 403 })

  /* Todo status a partir do aceite, não só ACEITA.
     A proposta não fica em ACEITA: ela avança para faturamento, contrato e
     conclusão. Com o filtro preso em ACEITA, as parcelas sumiam do financeiro
     exatamente quando o dinheiro começava a ser cobrado — a tela ficava vazia
     justamente nas propostas que mais importam. Recusada e cancelada seguem de
     fora: não há o que receber. */
  const APOS_ACEITE = ["ACEITA", "EM_FATURAMENTO", "EM_CONTRATO", "CONCLUIDA"] as const

  const installments = await prisma.installment.findMany({
    where: {
      proposal: {
        companyId: session.companyId,
        status: { in: [...APOS_ACEITE] },
      }
    },
    include: {
      proposal: {
        select: { numero: true, client_name: true, valor_total: true }
      },
      financialTxns: { orderBy: { createdAt: "desc" }, take: 1 },
    },
    orderBy: { data_vencimento: "asc" }
  })

  const now = new Date()
  const enriched = installments.map(inst => ({
    ...inst,
    statusEfetivo: inst.status === "PENDENTE" && new Date(inst.data_vencimento) < now
      ? "ATRASADO"
      : inst.status
  }))

  const totalAReceber = enriched.filter(i => i.statusEfetivo !== "PAGO").reduce((s, i) => s + Number(i.valor), 0)
  const totalRecebido = enriched.filter(i => i.status === "PAGO").reduce((s, i) => s + Number(i.valor), 0)
  const totalAtrasado = enriched.filter(i => i.statusEfetivo === "ATRASADO").reduce((s, i) => s + Number(i.valor), 0)

  return NextResponse.json({ installments: enriched, summary: { totalAReceber, totalRecebido, totalAtrasado } })
}
