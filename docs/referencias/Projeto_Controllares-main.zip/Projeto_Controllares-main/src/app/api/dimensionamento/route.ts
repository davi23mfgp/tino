import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const search = searchParams.get("search") || ""
  const marca = searchParams.get("marca") || ""
  const categoryId = searchParams.get("categoryId") || ""
  const ids = searchParams.get("ids") || ""
  const page = parseInt(searchParams.get("page") || "1")
  const limit = parseInt(searchParams.get("limit") || "20")
  const skip = (page - 1) * limit

  // Busca por IDs específicos (ex.: sincronizar itens de uma proposta) —
  // ignora paginação/filtros, devolve exatamente os produtos pedidos.
  if (ids) {
    const idList = ids.split(",").map(s => s.trim()).filter(Boolean)
    const produtos = await prisma.catalogProduct.findMany({
      where: { companyId: session.companyId, id: { in: idList } },
      select: {
        id: true, nome: true, marca: true, sku: true, status: true,
        peso_kg: true, medidas_raw: true, imagem_url: true,
        largura_mm: true, altura_mm: true, profundidade_mm: true, volume_cm3: true,
        tipo_dimensao: true, outros_descricao: true, outros_formato: true, outros_formato_custom: true, outros_instalacao: true, outros_instalacao_custom: true,
        category: { select: { id: true, nome: true } },
      },
    })
    return NextResponse.json({ products: produtos, total: produtos.length, pages: 1, marcas: [] })
  }

  const where: Record<string, unknown> = { companyId: session.companyId }
  if (search) {
    where.OR = [
      { nome: { contains: search, mode: "insensitive" } },
      { marca: { contains: search, mode: "insensitive" } },
    ]
  }
  if (marca) where.marca = { equals: marca, mode: "insensitive" }
  if (categoryId) where.categoryId = categoryId

  const [products, total] = await Promise.all([
    prisma.catalogProduct.findMany({
      where, skip, take: limit,
      orderBy: { nome: "asc" },
      select: {
        id: true, nome: true, marca: true, sku: true, status: true,
        peso_kg: true, medidas_raw: true, imagem_url: true,
        largura_mm: true, altura_mm: true, profundidade_mm: true, volume_cm3: true,
        tipo_dimensao: true, outros_descricao: true, outros_formato: true, outros_formato_custom: true, outros_instalacao: true, outros_instalacao_custom: true,
        category: { select: { id: true, nome: true } },
      },
    }),
    prisma.catalogProduct.count({ where }),
  ])

  // Lista de marcas únicas para filtro
  const marcas = await prisma.catalogProduct.findMany({
    where: { companyId: session.companyId },
    select: { marca: true },
    distinct: ["marca"],
    orderBy: { marca: "asc" },
  })

  return NextResponse.json({
    products,
    total,
    pages: Math.ceil(total / limit),
    marcas: marcas.map(m => m.marca).filter(Boolean),
  })
}

export async function PATCH(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const body = await req.json()
  const { id } = body
  if (!id) return NextResponse.json({ error: "ID obrigatório" }, { status: 400 })

  const existing = await prisma.catalogProduct.findFirst({
    where: { id, companyId: session.companyId },
  })
  if (!existing) return NextResponse.json({ error: "Produto não encontrado" }, { status: 404 })

  // Parcial: só sobrescreve o que veio no body (evita apagar peso/medidas
  // ao salvar só o tipo de dimensionamento, ou vice-versa).
  const data: Record<string, unknown> = {}
  if ("peso_kg" in body) data.peso_kg = body.peso_kg ?? null
  if ("largura_mm" in body) data.largura_mm = body.largura_mm ?? null
  if ("altura_mm" in body) data.altura_mm = body.altura_mm ?? null
  if ("profundidade_mm" in body) data.profundidade_mm = body.profundidade_mm ?? null
  if ("medidas_raw" in body) data.medidas_raw = body.medidas_raw || null
  if ("tipo_dimensao" in body) data.tipo_dimensao = body.tipo_dimensao || null
  if ("outros_descricao" in body) data.outros_descricao = body.outros_descricao || null
  if ("outros_formato" in body) data.outros_formato = body.outros_formato || null
  if ("outros_formato_custom" in body) data.outros_formato_custom = body.outros_formato_custom || null
  if ("outros_instalacao" in body) data.outros_instalacao = body.outros_instalacao || null
  if ("outros_instalacao_custom" in body) data.outros_instalacao_custom = body.outros_instalacao_custom || null

  const largura_mm = "largura_mm" in body ? body.largura_mm : existing.largura_mm
  const altura_mm = "altura_mm" in body ? body.altura_mm : existing.altura_mm
  const profundidade_mm = "profundidade_mm" in body ? body.profundidade_mm : existing.profundidade_mm
  if (largura_mm && altura_mm && profundidade_mm) {
    data.volume_cm3 = Math.round(((largura_mm * altura_mm * profundidade_mm) / 1000) * 100) / 100
  } else if ("largura_mm" in body || "altura_mm" in body || "profundidade_mm" in body) {
    data.volume_cm3 = null
  }

  const updated = await prisma.catalogProduct.update({ where: { id }, data })

  return NextResponse.json({ product: updated })
}
