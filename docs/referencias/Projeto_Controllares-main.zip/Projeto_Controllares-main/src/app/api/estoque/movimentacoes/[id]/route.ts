import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { temAlgumPerfil } from "@/lib/perfil"
import { prisma } from "@/lib/prisma"

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession(); if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 }); if (session.role !== "ADMIN") return NextResponse.json({ error: "Somente ADMIN pode aprovar" }, { status: 403 })
  const { id } = await params; const { acao } = await req.json(); if (!["APROVAR", "RECUSAR"].includes(acao)) return NextResponse.json({ error: "Ação inválida" }, { status: 400 })
  const m = await prisma.stockMovement.findFirst({ where: { id, companyId: session.companyId, status: "PENDENTE" } }); if (!m) return NextResponse.json({ error: "Movimentação pendente não encontrada" }, { status: 404 })
  await prisma.$transaction(async tx => {
    if (acao === "APROVAR") {
      const product = await tx.catalogProduct.findUnique({ where: { id: m.productId }, select: { estoque_qtd: true } })
      const atual = product?.estoque_qtd ?? 0
      if (m.tipo === "SAIDA") {
        if (atual < m.quantidade) throw new Error("Saldo insuficiente para aprovar a saída")
        await tx.catalogProduct.update({ where: { id: m.productId }, data: { estoque_qtd: atual - m.quantidade } })
      } else await tx.catalogProduct.update({ where: { id: m.productId }, data: { estoque_qtd: m.saldo_novo ?? 0 } })
    }
    await tx.stockMovement.update({ where: { id }, data: { status: acao === "APROVAR" ? "APLICADO" : "RECUSADO", aprovadoPorNome: session.nome } })
  })
  return NextResponse.json({ ok: true })
}
