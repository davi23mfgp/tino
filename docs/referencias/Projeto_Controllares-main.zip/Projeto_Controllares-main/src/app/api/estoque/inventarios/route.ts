import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { temAlgumPerfil } from "@/lib/perfil"
import { prisma } from "@/lib/prisma"

export async function GET() { const s = await getSession(); if (!s) return NextResponse.json({ error: "Não autorizado" }, { status: 401 }); if (!temAlgumPerfil(s, ["ADMIN", "FINANCEIRO", "RESPONSAVEL_TECNICO"])) return NextResponse.json({ error: "Sem acesso ao estoque." }, { status: 403 }); return NextResponse.json({ inventories: await prisma.stockInventory.findMany({ where: { companyId: s.companyId }, include: { _count: { select: { items: true } } }, orderBy: { createdAt: "desc" } }) }) }
export async function POST(req: NextRequest) { const s = await getSession(); if (!s) return NextResponse.json({ error: "Não autorizado" }, { status: 401 }); if (!temAlgumPerfil(s, ["ADMIN", "FINANCEIRO", "RESPONSAVEL_TECNICO"])) return NextResponse.json({ error: "Sem acesso ao estoque." }, { status: 403 }); const { nome, tipo } = await req.json(); const inventory = await prisma.stockInventory.create({ data: { companyId: s.companyId, nome: String(nome || "Inventário").trim() || "Inventário", tipo: tipo === "INICIAL" ? "INICIAL" : "PERIODICA", criadoPorId: s.userId, criadoPorNome: s.nome } }); return NextResponse.json(inventory, { status: 201 }) }
