import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { temAlgumPerfil } from "@/lib/perfil"
import { prisma } from "@/lib/prisma"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  /* Estoque é custo e saldo — informação de compra, não de campo. O instalador
     trabalha pela ordem de serviço, e o menu escondido não fecha a rota: quem
     souber a URL entra. */
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO", "RESPONSAVEL_TECNICO"])) {
    return NextResponse.json({ error: "Sem acesso ao estoque." }, { status: 403 })
  }

  const p = new URL(req.url).searchParams; const search = p.get("search") || ""
  const where = { companyId: session.companyId, ...(p.get("categoryId") ? { categoryId: p.get("categoryId")! } : {}), ...(p.get("supplierId") ? { supplierId: p.get("supplierId")! } : {}), ...(search ? { OR: [{ sku: { contains: search, mode: "insensitive" as const } }, { nome: { contains: search, mode: "insensitive" as const } }, { nome_cliente: { contains: search, mode: "insensitive" as const } }] } : {}) }
  const [products, movements, categories, suppliers] = await Promise.all([
    prisma.catalogProduct.findMany({ where, orderBy: { nome: "asc" }, select: { id: true, sku: true, nome: true, nome_cliente: true, imagem_url: true, estoque_qtd: true, estoque_minimo: true, category: { select: { nome: true } }, supplier: { select: { nome: true } } } }),
    prisma.stockMovement.findMany({ where: { companyId: session.companyId }, orderBy: { createdAt: "desc" }, take: 100, include: { product: { select: { sku: true, nome: true } } } }),
    prisma.category.findMany({ where: { companyId: session.companyId }, select: { id: true, nome: true }, orderBy: { nome: "asc" } }),
    prisma.supplier.findMany({ where: { companyId: session.companyId }, select: { id: true, nome: true }, orderBy: { nome: "asc" } }),
  ])
  return NextResponse.json({ products, movements, categories, suppliers })
}

export async function POST(req: NextRequest) {
  const session = await getSession(); if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  /* Estoque é custo e saldo — informação de compra, não de campo. O instalador
     trabalha pela ordem de serviço, e o menu escondido não fecha a rota: quem
     souber a URL entra. */
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO", "RESPONSAVEL_TECNICO"])) {
    return NextResponse.json({ error: "Sem acesso ao estoque." }, { status: 403 })
  }

  const { productId, tipo, quantidade, motivo, origem } = await req.json()
  if (!productId || !["ENTRADA", "SAIDA"].includes(tipo) || !Number.isInteger(quantidade) || quantidade <= 0 || !String(motivo || "").trim()) return NextResponse.json({ error: "Item, tipo, quantidade e motivo são obrigatórios" }, { status: 400 })
  const product = await prisma.catalogProduct.findFirst({ where: { id: productId, companyId: session.companyId } }); if (!product) return NextResponse.json({ error: "Produto não encontrado" }, { status: 404 })
  const atual = product.estoque_qtd ?? 0; if (tipo === "SAIDA" && quantidade > atual) return NextResponse.json({ error: "Saldo insuficiente" }, { status: 409 })
  const saldo = tipo === "ENTRADA" ? atual + quantidade : atual - quantidade
  const movement = await prisma.$transaction(async tx => { await tx.catalogProduct.update({ where: { id: productId }, data: { estoque_qtd: saldo } }); return tx.stockMovement.create({ data: { companyId: session.companyId, productId, tipo, quantidade, motivo: motivo.trim(), origem: origem?.trim() || null, criadoPorId: session.userId, criadoPorNome: session.nome } }) })
  return NextResponse.json({ movement, saldo }, { status: 201 })
}
