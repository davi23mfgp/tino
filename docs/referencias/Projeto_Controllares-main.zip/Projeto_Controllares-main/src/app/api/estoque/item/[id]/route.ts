import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { temAlgumPerfil } from "@/lib/perfil"
import { prisma } from "@/lib/prisma"

/**
 * GET /api/estoque/item/[id] — ficha + histórico do produto (para a etiqueta/QR).
 * Movimentações (com obra de origem), saldo atual, obras vinculadas.
 */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  /* Estoque é custo e saldo — informação de compra, não de campo. O instalador
     trabalha pela ordem de serviço, e o menu escondido não fecha a rota: quem
     souber a URL entra. */
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO", "RESPONSAVEL_TECNICO"])) {
    return NextResponse.json({ error: "Sem acesso ao estoque." }, { status: 403 })
  }

  const { id } = await params

  const product = await prisma.catalogProduct.findFirst({
    where: { id, companyId: session.companyId },
    select: {
      id: true, sku: true, nome: true, nome_cliente: true, marca: true, imagem_url: true,
      estoque_qtd: true, estoque_minimo: true, preco_venda: true,
      category: { select: { nome: true } }, supplier: { select: { nome: true } },
    },
  })
  if (!product) return NextResponse.json({ error: "Produto não encontrado" }, { status: 404 })

  const movimentos = await prisma.stockMovement.findMany({
    where: { productId: id, companyId: session.companyId },
    orderBy: { createdAt: "desc" }, take: 100,
    select: { id: true, tipo: true, quantidade: true, motivo: true, origem: true, status: true, criadoPorNome: true, aprovadoPorNome: true, createdAt: true },
  })

  // Resolve nomes de obra a partir de origem "obra:<id>"
  const obraIds = [...new Set(movimentos.map(m => m.origem?.match(/^obra:(.+)$/)?.[1]).filter(Boolean) as string[])]
  const obras = obraIds.length
    ? await prisma.obra.findMany({ where: { id: { in: obraIds }, companyId: session.companyId }, select: { id: true, client_name: true } })
    : []
  const obraNome = new Map(obras.map(o => [o.id, o.client_name]))

  return NextResponse.json({
    product,
    movimentos: movimentos.map(m => {
      const obraId = m.origem?.match(/^obra:(.+)$/)?.[1]
      return {
        ...m,
        obra: obraId ? (obraNome.get(obraId) ?? "Obra") : null,
        chamado: m.origem?.startsWith("chamado:") ? m.origem.slice(8) : null,
      }
    }),
    obras_vinculadas: [...obraNome.values()],
  })
}
