import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { temAlgumPerfil } from "@/lib/perfil"
import { prisma } from "@/lib/prisma"
import QRCode from "qrcode"

/**
 * GET /api/estoque/item/[id]/etiqueta — folha imprimível com o QR do item.
 *
 * A etiqueta antiga trazia só nome, SKU e o QR. Quem estava no canteiro com a
 * caixa na mão ainda precisava abrir o sistema para saber de que obra era
 * aquilo, quanto tinha entrado e qual a especificação. Agora sai tudo impresso:
 * obra vinculada, saldo, entrada, movimentações e ficha técnica. O QR continua
 * apontando para a ficha viva, onde fica o histórico completo.
 */
const esc = (v: unknown) =>
  String(v ?? "").replace(/[&<>"']/g, c =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!))

const data = (d: Date) => d.toLocaleDateString("pt-BR")

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return new NextResponse("Não autorizado", { status: 401 })
  /* Mesma regra do resto do estoque, em rota que responde texto. */
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO", "RESPONSAVEL_TECNICO"])) {
    return new NextResponse("Sem acesso ao estoque.", { status: 403 })
  }

  const { id } = await params

  const p = await prisma.catalogProduct.findFirst({
    where: { id, companyId: session.companyId },
    select: {
      sku: true, nome: true, marca: true, unidade: true, gtin: true, ncm: true,
      estoque_qtd: true, especificacoes: true, descricao: true,
      peso_kg: true, medidas_raw: true, garantia_dias: true,
    },
  })
  if (!p) return new NextResponse("Produto não encontrado", { status: 404 })

  const movs = await prisma.stockMovement.findMany({
    where: { companyId: session.companyId, productId: id, status: "APLICADO" },
    orderBy: { createdAt: "desc" },
    take: 12,
    select: { tipo: true, quantidade: true, motivo: true, origem: true, createdAt: true, criadoPorNome: true },
  })

  /* Obra do item: vem da movimentação mais recente marcada com "obra:<id>".
     É o vínculo que existe hoje — não há campo de obra no produto, porque o
     mesmo SKU circula entre várias obras. */
  const comObra = movs.find(m => m.origem?.startsWith("obra:"))
  const obra = comObra
    ? await prisma.obra.findFirst({
        where: { id: comObra.origem!.slice(5), companyId: session.companyId },
        select: { numero: true, client_name: true, address: true },
      })
    : null

  const entradas = movs.filter(m => m.tipo === "ENTRADA")
  const primeiraEntrada = entradas[entradas.length - 1] ?? null

  const appUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL || "http://localhost:3000"
  const qr = await QRCode.toDataURL(`${appUrl}/estoque/item/${id}`, { margin: 1, width: 260 })

  const ficha: [string, unknown][] = [
    ["Marca", p.marca],
    ["Unidade", p.unidade],
    ["GTIN", p.gtin],
    ["NCM", p.ncm],
    ["Peso", p.peso_kg ? `${p.peso_kg} kg` : null],
    ["Medidas", p.medidas_raw],
    ["Garantia", p.garantia_dias ? `${p.garantia_dias} dias` : null],
  ]
  const fichaPreenchida = ficha.filter(([, v]) => v)

  const especificacao = [p.especificacoes, p.descricao].filter(Boolean).join("\n\n")

  const linhas = movs.map(m => `<tr>
      <td>${data(m.createdAt)}</td>
      <td class="${m.tipo === "ENTRADA" ? "ent" : "sai"}">${esc(m.tipo)}</td>
      <td class="num">${m.quantidade}</td>
      <td>${esc(m.motivo)}</td>
      <td>${esc(m.criadoPorNome)}</td>
    </tr>`).join("")

  const html = `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"/>
  <title>Etiqueta ${esc(p.sku)}</title><style>
    *{box-sizing:border-box} body{font-family:Arial,Helvetica,sans-serif;margin:0;padding:20px;color:#111}
    .acoes{margin-bottom:14px}
    .acoes button{background:#111;color:#fff;border:0;padding:8px 16px;border-radius:6px;cursor:pointer}
    .folha{max-width:640px;border:1px solid #ccc;border-radius:12px;padding:18px}
    .topo{display:flex;gap:16px;align-items:flex-start;border-bottom:1px solid #eee;padding-bottom:14px}
    .topo img{width:130px;height:130px;flex:none}
    .topo b{display:block;font-size:17px;line-height:1.25}
    .sku{font-family:monospace;font-size:13px;color:#555;margin-top:3px}
    .saldo{margin-top:8px;font-size:13px}
    .saldo strong{font-size:20px}
    h3{font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:#666;margin:16px 0 6px}
    .obra{font-size:13px;line-height:1.5}
    .ficha{display:grid;grid-template-columns:repeat(2,1fr);gap:4px 16px;font-size:12px}
    .ficha span{color:#666}
    .espec{font-size:12px;line-height:1.5;white-space:pre-line}
    table{width:100%;border-collapse:collapse;font-size:11.5px}
    th{text-align:left;color:#666;font-weight:600;border-bottom:1px solid #ddd;padding:4px 6px}
    td{padding:4px 6px;border-bottom:1px solid #f2f2f2}
    td.num{text-align:right}
    .ent{color:#127c2f;font-weight:600}.sai{color:#b32020;font-weight:600}
    .vazio{font-size:12px;color:#888}
    @media print{.acoes{display:none} body{padding:0} .folha{border:0}}
  </style></head><body>
    <div class="acoes"><button onclick="window.print()">Imprimir</button></div>
    <div class="folha">
      <div class="topo">
        <img src="${qr}" alt="QR do item"/>
        <div>
          <b>${esc(p.nome)}</b>
          <div class="sku">${esc(p.sku)}</div>
          <div class="saldo">Saldo atual: <strong>${p.estoque_qtd ?? 0}</strong> ${esc(p.unidade ?? "un")}</div>
          ${primeiraEntrada
            ? `<div class="saldo">Entrada: ${data(primeiraEntrada.createdAt)} — ${primeiraEntrada.quantidade} ${esc(p.unidade ?? "un")}</div>`
            : ""}
        </div>
      </div>

      <h3>Obra</h3>
      ${obra
        ? `<div class="obra"><b>${esc(obra.client_name)}</b>${obra.numero ? ` — obra ${esc(obra.numero)}` : ""}${obra.address ? `<br/>${esc(obra.address)}` : ""}</div>`
        : `<div class="vazio">Item de estoque geral — nenhuma obra vinculada.</div>`}

      ${fichaPreenchida.length ? `<h3>Ficha técnica</h3><div class="ficha">
        ${fichaPreenchida.map(([k, v]) => `<div><span>${esc(k)}:</span> ${esc(v)}</div>`).join("")}
      </div>` : ""}

      ${especificacao ? `<h3>Especificação</h3><div class="espec">${esc(especificacao)}</div>` : ""}

      <h3>Histórico de entrada e saída</h3>
      ${movs.length
        ? `<table><thead><tr><th>Data</th><th>Tipo</th><th class="num">Qtd</th><th>Motivo</th><th>Responsável</th></tr></thead>
           <tbody>${linhas}</tbody></table>`
        : `<div class="vazio">Sem movimentações registradas.</div>`}
    </div>
  </body></html>`

  return new NextResponse(html, { headers: { "Content-Type": "text/html; charset=utf-8" } })
}
