import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { temAlgumPerfil } from "@/lib/perfil"
import { prisma } from "@/lib/prisma"

export async function GET(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  /* Estoque é custo e saldo — informação de compra, não de campo. O instalador
     trabalha pela ordem de serviço, e o menu escondido não fecha a rota: quem
     souber a URL entra. */
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO", "RESPONSAVEL_TECNICO"])) {
    return NextResponse.json({ error: "Sem acesso ao estoque." }, { status: 403 })
  }

  const { id } = await params
  const inventory = await prisma.stockInventory.findFirst({
    where: { id, companyId: session.companyId },
    include: { items: { include: { product: { select: { id: true, sku: true, nome: true, nome_cliente: true, category: { select: { nome: true } }, supplier: { select: { nome: true } } } } } } },
  })
  return inventory ? NextResponse.json(inventory) : NextResponse.json({ error: "Inventário não encontrado" }, { status: 404 })
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  /* Estoque é custo e saldo — informação de compra, não de campo. O instalador
     trabalha pela ordem de serviço, e o menu escondido não fecha a rota: quem
     souber a URL entra. */
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO", "RESPONSAVEL_TECNICO"])) {
    return NextResponse.json({ error: "Sem acesso ao estoque." }, { status: 403 })
  }

  const { id } = await params
  const { productId, quantidade, motivo } = await req.json()
  if (!productId || !Number.isInteger(quantidade) || quantidade < 0) return NextResponse.json({ error: "Quantidade inválida" }, { status: 400 })
  const [inventory, product] = await Promise.all([prisma.stockInventory.findFirst({ where: { id, companyId: session.companyId } }), prisma.catalogProduct.findFirst({ where: { id: productId, companyId: session.companyId } })])
  if (!inventory || !product) return NextResponse.json({ error: "Registro não encontrado" }, { status: 404 })
  if (inventory.status === "ABERTO") return NextResponse.json(await prisma.stockInventoryItem.upsert({ where: { inventoryId_productId: { inventoryId: id, productId } }, create: { inventoryId: id, productId, quantidade }, update: { quantidade } }))
  if (!String(motivo || "").trim()) return NextResponse.json({ error: "Ajuste após fechamento exige motivo" }, { status: 400 })
  const movement = await prisma.stockMovement.create({ data: { companyId: session.companyId, productId, tipo: "AJUSTE", quantidade: Math.abs((product.estoque_qtd ?? 0) - quantidade), saldo_novo: quantidade, motivo: motivo.trim(), origem: `inventario:${id}`, status: "PENDENTE", criadoPorId: session.userId, criadoPorNome: session.nome } })
  return NextResponse.json({ movement, pending: true }, { status: 201 })
}

/**
 * DELETE /api/estoque/inventarios/[id]?backup=1 — exclui inventário (só ADMIN).
 * Com backup=1, salva um snapshot JSON no log de auditoria antes de apagar —
 * dado de estoque não pode sumir sem rastro por acidente.
 */
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  /* Estoque é custo e saldo — informação de compra, não de campo. O instalador
     trabalha pela ordem de serviço, e o menu escondido não fecha a rota: quem
     souber a URL entra. */
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO", "RESPONSAVEL_TECNICO"])) {
    return NextResponse.json({ error: "Sem acesso ao estoque." }, { status: 403 })
  }

  if (session.role !== "ADMIN") return NextResponse.json({ error: "Só o Admin pode excluir inventários" }, { status: 403 })

  const { id } = await params
  const backup = new URL(req.url).searchParams.get("backup") === "1"

  const inventory = await prisma.stockInventory.findFirst({
    where: { id, companyId: session.companyId },
    include: { items: { include: { product: { select: { sku: true, nome: true } } } } },
  })
  if (!inventory) return NextResponse.json({ error: "Inventário não encontrado" }, { status: 404 })

  if (backup) {
    await prisma.webhookDebugLog.create({
      data: {
        companyId: session.companyId,
        endpoint: "internal/inventario-backup",
        payload_json: {
          nome: inventory.nome, status: inventory.status,
          criadoPorNome: inventory.criadoPorNome, createdAt: inventory.createdAt.toISOString(),
          itens: inventory.items.map(i => ({ sku: i.product.sku, nome: i.product.nome, quantidade: i.quantidade })),
        },
        response_body: `Backup do inventário "${inventory.nome}" antes da exclusão por ${session.nome}`,
        reenviado: false,
      },
    })
  }

  await prisma.stockInventory.delete({ where: { id } })

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "DADOS",
      descricao: `Excluiu inventário "${inventory.nome}" (${inventory.items.length} itens)${backup ? " com backup" : " SEM backup"}`,
    },
  }).catch(() => {})

  return NextResponse.json({ ok: true, backup })
}
