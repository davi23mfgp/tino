import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export const dynamic = "force-dynamic"

/**
 * Dados que a própria pessoa edita sobre si: telefone do rodapé da proposta e
 * o WhatsApp que recebe as notificações.
 *
 * Rota separada de /api/usuarios/[id], que é de ADMIN: aqui não há id no
 * caminho — o alvo é sempre `session.userId`. Assim ninguém edita o número de
 * outra pessoa, e Vendedor e Financeiro conseguem configurar o próprio aviso
 * sem depender do Admin.
 */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const user = await prisma.user.findUnique({
    where: { id: session.userId },
    select: {
      nome: true, email: true, telefone: true,
      whatsapp_numero: true, whatsapp_apikey: true, notificar_whatsapp: true,
      telegram_chat_id: true, telegram_username: true, notificar_telegram: true,
    },
  })
  if (!user) return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
  return NextResponse.json(user)
}

export async function PATCH(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const body = await req.json().catch(() => ({}))
  const texto = (v: unknown) => (typeof v === "string" ? v.trim() || null : null)

  // Guardado só com dígitos e DDI — a máscara é coisa de tela, e o CallMeBot
  // e a Evolution só aceitam o número cru.
  const numero = typeof body.whatsapp_numero === "string"
    ? body.whatsapp_numero.replace(/\D/g, "") || null
    : undefined
  if (numero && (numero.length < 12 || numero.length > 13)) {
    return NextResponse.json(
      { error: "Informe o número com DDI e DDD, ex.: +55 17 99999-9999." },
      { status: 422 },
    )
  }

  await prisma.user.update({
    where: { id: session.userId },
    data: {
      ...(body.telefone !== undefined && { telefone: texto(body.telefone) }),
      ...(numero !== undefined && { whatsapp_numero: numero }),
      ...(body.whatsapp_apikey !== undefined && { whatsapp_apikey: texto(body.whatsapp_apikey) }),
      ...(body.notificar_whatsapp !== undefined && { notificar_whatsapp: !!body.notificar_whatsapp }),
      ...(body.notificar_telegram !== undefined && { notificar_telegram: !!body.notificar_telegram }),
    },
  })

  return NextResponse.json({ ok: true })
}
