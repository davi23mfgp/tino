import { NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { randomBytes } from "node:crypto"

export const dynamic = "force-dynamic"

/**
 * POST /api/perfil/telegram — gera o link "Conectar Telegram".
 *
 * O aviso individual precisa do chat_id da conversa, e chat_id não se digita:
 * pedir para alguém descobrir um número interno do Telegram é garantir que
 * ninguém ative. Aqui sai um link t.me/<bot>?start=<codigo>; quem abre, o bot
 * registra pelo webhook.
 *
 * O código é sorteado e vale 15 minutos. Vincular pelo id do usuário seria
 * mais curto e deixaria qualquer um com o link receber os avisos de outra
 * pessoa.
 *
 * DELETE desliga: apaga o chat_id, e a conversa deixa de receber.
 */
const VALIDADE_MS = 15 * 60 * 1000

export async function POST() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const empresa = await prisma.company.findUnique({
    where: { id: session.companyId },
    select: { telegram_bot_token: true },
  })
  if (!empresa?.telegram_bot_token) {
    return NextResponse.json(
      { error: "A empresa ainda não configurou o bot do Telegram em Integrações." },
      { status: 422 },
    )
  }

  /* O nome de usuário do bot vem do próprio Telegram: guardá-lo à parte
     criaria um segundo lugar para errar quando o bot mudasse. */
  const me = await fetch(`https://api.telegram.org/bot${empresa.telegram_bot_token}/getMe`, {
    signal: AbortSignal.timeout(10_000),
  }).then(r => r.json()).catch(() => null)
  const usuarioDoBot = me?.result?.username
  if (!usuarioDoBot) {
    return NextResponse.json(
      { error: "Não foi possível falar com o bot. Confira o token em Integrações." },
      { status: 502 },
    )
  }

  const codigo = randomBytes(12).toString("base64url")
  await prisma.user.update({
    where: { id: session.userId },
    data: {
      telegram_link_code: codigo,
      telegram_link_expira: new Date(Date.now() + VALIDADE_MS),
    },
  })

  return NextResponse.json({
    url: `https://t.me/${usuarioDoBot}?start=${codigo}`,
    expira_em_minutos: VALIDADE_MS / 60_000,
  })
}

export async function DELETE() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  await prisma.user.update({
    where: { id: session.userId },
    data: { telegram_chat_id: null, telegram_username: null },
  })
  return NextResponse.json({ ok: true })
}
