import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * GET /api/leads/[id]/sistemas-guardados/[sistemaId] — um sistema do
 * histórico do lead (guardado, recusado ou já aceito numa proposta
 * anterior), com os produtos/kits por id — não só o nome — porque quem
 * resgata precisa recalcular o preço pelo catálogo de HOJE, nunca
 * ressuscitar o valor congelado da época sem avisar.
 */
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string; sistemaId: string }> },
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id, sistemaId } = await params

  const sistema = await prisma.environment.findFirst({
    where: { id: sistemaId, proposal: { leadId: id, companyId: session.companyId } },
    select: {
      id: true, nome: true, status: true,
      proposalItems: {
        select: {
          quantidade: true, valor_total: true, nome_snapshot: true, categoryId: true, is_aditivo: true,
          productId: true, kitId: true,
        },
      },
    },
  })
  if (!sistema) return NextResponse.json({ error: "Sistema não encontrado" }, { status: 404 })

  return NextResponse.json({
    nome: sistema.nome,
    itens: sistema.proposalItems.map(i => ({
      productId: i.productId, kitId: i.kitId, quantidade: i.quantidade,
      nome_snapshot: i.nome_snapshot, categoryId: i.categoryId, is_aditivo: i.is_aditivo,
      valorNaEpoca: Number(i.valor_total || 0),
    })),
  })
}
