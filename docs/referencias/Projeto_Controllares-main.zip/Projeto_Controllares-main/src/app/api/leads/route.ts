import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { tituloCaso } from "@/lib/texto"
import { STATUS_LEAD_VALIDOS } from "@/lib/etapas-lead"
import { registrarNoHistorico } from "@/lib/historico-lead"

const ORIGENS_VALIDAS = ["INDICACAO", "SITE", "PARCEIRO", "INSTAGRAM", "OUTRO"]

/** GET /api/leads — lista leads da empresa (funil). */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const leads = await prisma.lead.findMany({
    where: { companyId: session.companyId },
    orderBy: { updatedAt: "desc" },
    // O nome do parceiro vem junto: a tela mostra quem indicou, e sem isto
    // precisaria de uma segunda consulta só para traduzir o id.
    include: {
      partner: { select: { id: true, name: true } },
      /* Projetos vêm junto para o card do funil saber, sem uma requisição
         por cartão, se aquele cliente tem um negócio ou quatro. */
      projetos: {
        orderBy: [{ posicao: "asc" }, { createdAt: "asc" }],
        select: {
          id: true, nome: true, posicao: true, status: true,
          propostas: {
            select: { id: true, numero: true, status: true },
            orderBy: { createdAt: "desc" },
            take: 1,
          },
        },
      },
    },
  })
  return NextResponse.json({ leads })
}

/** POST /api/leads — cria lead. */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const body = await req.json().catch(() => ({}))
  const nome = tituloCaso((body.nome ?? "").toString())
  if (!nome) return NextResponse.json({ error: "Nome é obrigatório" }, { status: 400 })

  const lead = await prisma.lead.create({
    data: {
      companyId: session.companyId,
      nome,
      telefone: body.telefone?.toString().trim() || null,
      email: body.email?.toString().trim() || null,
      origem: ORIGENS_VALIDAS.includes(body.origem) ? body.origem : "OUTRO",
      /* Só faz sentido dentro de "Outro". Guardado junto de outra origem, ele
         sobreviveria a uma troca de escolha e passaria a descrever algo que
         não é mais verdade. */
      origem_detalhe: body.origem === "OUTRO"
        ? (body.origem_detalhe?.toString().trim() || null)
        : null,
      /* Só vale dentro de PARCEIRO. Guardado junto de outra origem, ele
         sobreviveria à troca de escolha e passaria a creditar uma indicação
         que não aconteceu. */
      partnerId: body.origem === "PARCEIRO" ? (body.partnerId || null) : null,
      valor_estimado: body.valor_estimado != null && body.valor_estimado !== "" ? Number(body.valor_estimado) : null,
      observacoes: body.observacoes?.toString().trim() || null,
      /* Um lead nasce em NOVO quando alguém o cadastra pelo menu Leads: é
         contato que chegou e ainda não virou nada. Mas o lead criado de dentro
         da tela de Nova Proposta já nasce em outro ponto do funil — a proposta
         dele está sendo escrita neste instante. Deixá-lo em NOVO fazia o cartão
         aparecer na primeira coluna enquanto o rascunho já existia, e alguém
         ainda ia ligar para "fazer o primeiro contato". */
      status: STATUS_LEAD_VALIDOS.includes(body.status) ? body.status : undefined,
      criadoPor: session.userId,
    },
  })

  /* O cadastro já nasce com histórico.

     Quem cria o lead é quem acabou de falar com o cliente — é ali, e só ali,
     que ainda se lembra da obra, do prazo e de quem indicou. Deixar para
     escrever depois é escrever nunca, e seis meses adiante o cadastro é um
     telefone sem nenhuma pista de por que aquela pessoa ligou.

     A linha de abertura entra sempre, mesmo sem texto: é ela que responde
     "quem cadastrou e quando" sem precisar de outra tabela de auditoria. */
  await registrarNoHistorico(session, {
    leadId: lead.id, etapa: lead.status, tipo: "SISTEMA",
    texto: `Lead cadastrado por ${session.nome}.`,
  })

  const historico = (body.historico ?? "").toString().trim()
  if (historico) {
    await registrarNoHistorico(session, {
      leadId: lead.id, etapa: lead.status, tipo: "NOTA", texto: historico,
    })
  }

  return NextResponse.json(lead, { status: 201 })
}
