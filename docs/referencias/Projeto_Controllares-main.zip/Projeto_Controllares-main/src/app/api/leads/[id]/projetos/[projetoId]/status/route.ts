import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { STATUS_LEAD_VALIDOS } from "@/lib/etapas-lead"
import { registrarNoHistorico } from "@/lib/historico-lead"

/**
 * PATCH /api/leads/[id]/projetos/[projetoId]/status — move o cartão de UM
 * projeto no funil, quando o lead tem 2+ projetos e cada um ganhou seu
 * próprio cartão (ver leads/page.tsx: itensQuadro). Não mexe em Lead.status —
 * esse continua espelhando o mais avançado entre TODAS as propostas do lead
 * (leadSegueProposta), independente de quantos cartões o funil mostra.
 */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string; projetoId: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id, projetoId } = await params
  const body = await req.json().catch(() => ({}))
  const status = String(body.status ?? "")
  if (!STATUS_LEAD_VALIDOS.includes(status)) {
    return NextResponse.json({ error: "Status inválido" }, { status: 400 })
  }
  if (status === "PERDIDO" && !String(body.motivo ?? "").trim()) {
    return NextResponse.json({ error: "Informe o motivo da perda" }, { status: 400 })
  }

  const projeto = await prisma.leadProjeto.findFirst({
    where: { id: projetoId, lead: { id, companyId: session.companyId } },
    select: { id: true, nome: true, status: true, leadId: true },
  })
  if (!projeto) return NextResponse.json({ error: "Projeto não encontrado" }, { status: 404 })

  const atualizado = await prisma.leadProjeto.update({
    where: { id: projetoId },
    data: { status },
    select: { id: true, nome: true, posicao: true, status: true },
  })

  await registrarNoHistorico(session, {
    leadId: projeto.leadId, etapa: status, tipo: "SISTEMA",
    texto: `Projeto "${projeto.nome}" movido de ${projeto.status} para ${status}${
      status === "PERDIDO" ? `. Motivo: ${String(body.motivo).trim()}` : ""
    }.`,
  })

  return NextResponse.json({ projeto: atualizado })
}
