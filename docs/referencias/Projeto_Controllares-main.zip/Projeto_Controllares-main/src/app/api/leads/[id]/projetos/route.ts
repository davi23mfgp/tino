import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * Projetos de um lead — os negócios independentes da mesma pessoa.
 *
 * A construtora com quatro apartamentos e o cliente com a casa e a praia são
 * um contato só e vários negócios. Antes, cada negócio virava um lead
 * repetido, e a contagem do funil passava a medir projetos em vez de pessoas.
 *
 * GET                       lista
 * POST   { nome }           cria
 * DELETE { projetoId }      apaga
 */

async function leadDaEmpresa(id: string, companyId: string) {
  return prisma.lead.findFirst({ where: { id, companyId }, select: { id: true } })
}

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!await leadDaEmpresa(id, session.companyId)) {
    return NextResponse.json({ error: "Lead não encontrado" }, { status: 404 })
  }

  const projetos = await prisma.leadProjeto.findMany({
    where: { leadId: id },
    orderBy: [{ posicao: "asc" }, { createdAt: "asc" }],
    include: {
      /* A proposta de cada projeto vem junto: é o que deixa o card do funil
         mostrar "este já tem proposta, este não" sem uma segunda consulta
         por projeto. */
      propostas: {
        select: { id: true, numero: true, status: true },
        orderBy: { createdAt: "desc" },
        take: 1,
      },
    },
  })

  return NextResponse.json({
    projetos: projetos.map(p => ({
      id: p.id,
      nome: p.nome,
      posicao: p.posicao,
      status: p.status,
      proposta: p.propostas[0] ?? null,
    })),
  })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!await leadDaEmpresa(id, session.companyId)) {
    return NextResponse.json({ error: "Lead não encontrado" }, { status: 404 })
  }

  const { nome } = await req.json()
  const texto = typeof nome === "string" ? nome.trim() : ""
  if (!texto) return NextResponse.json({ error: "Nome do projeto é obrigatório" }, { status: 400 })

  /* Entra no fim da lista. A ordem é escolha de quem vende (o principal
     primeiro), então o padrão é cronológico e o resto se ajusta depois. */
  const ultimo = await prisma.leadProjeto.findFirst({
    where: { leadId: id },
    orderBy: { posicao: "desc" },
    select: { posicao: true },
  })

  const projeto = await prisma.leadProjeto.create({
    data: { leadId: id, nome: texto, posicao: (ultimo?.posicao ?? -1) + 1 },
    select: { id: true, nome: true, posicao: true, status: true },
  })
  return NextResponse.json({ projeto: { ...projeto, proposta: null } }, { status: 201 })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!await leadDaEmpresa(id, session.companyId)) {
    return NextResponse.json({ error: "Lead não encontrado" }, { status: 404 })
  }

  const { projetoId } = await req.json()
  if (!projetoId) return NextResponse.json({ error: "projetoId é obrigatório" }, { status: 400 })

  /* Escopo pelo lead, não só pelo id: sem isto um id de projeto de outra
     empresa passaria, porque o vínculo com a empresa vem do lead. */
  const projeto = await prisma.leadProjeto.findFirst({
    where: { id: projetoId, leadId: id },
    select: { id: true, _count: { select: { propostas: true } } },
  })
  if (!projeto) return NextResponse.json({ error: "Projeto não encontrado" }, { status: 404 })

  /* Projeto com proposta não some por um clique.
     A proposta sobrevive (o vínculo é SetNull), mas ficaria órfã de contexto
     — e quem apagou não saberia que acabou de desligar um documento que pode
     já estar com o cliente. */
  if (projeto._count.propostas > 0) {
    return NextResponse.json(
      { error: "Este projeto já tem proposta. Apague ou desvincule a proposta antes." },
      { status: 409 },
    )
  }

  await prisma.leadProjeto.delete({ where: { id: projetoId } })
  return NextResponse.json({ ok: true })
}
