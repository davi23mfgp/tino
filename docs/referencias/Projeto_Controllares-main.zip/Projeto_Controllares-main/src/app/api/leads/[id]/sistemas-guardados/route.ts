import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { ProposalStatus } from "@prisma/client"

const STATUS_FECHADO: ProposalStatus[] = ["ACEITA", "EM_FATURAMENTO", "EM_CONTRATO", "CONCLUIDA"]

/**
 * Histórico de sistemas montados para este cliente, em qualquer proposta
 * dele — guardado, recusado ou já aceito. Qualquer um dos três pode ser
 * resgatado (ver /[sistemaId]) pra virar ponto de partida de um orçamento
 * novo:
 *
 *  - GUARDADO: "ainda não te ofereci isso" — montado, nunca chegou a sair.
 *  - RECUSADO: "você viu e não quis" — chegou ao cliente, ele disse não a
 *    ESTE sistema específico (dentro de uma proposta que seguiu com outros).
 *  - ATIVO numa proposta já fechada (ACEITA em diante): "você já levou
 *    isso" — útil de resgatar quando o mesmo cliente quer repetir o pacote
 *    numa obra nova, ou complementar depois.
 *
 * Não entra o ATIVO de uma proposta ainda em aberto (RASCUNHO/ENVIADA/...):
 * isso é o que está sendo montado ou decidido agora, não histórico.
 *
 * Os valores mostrados são os DA ÉPOCA e vêm marcados como tal. Preço de
 * catálogo muda, campanha vence — resgatar sempre repreça pelo catálogo
 * atual, nunca ressuscita um número velho calado.
 */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params

  const lead = await prisma.lead.findFirst({
    where: { id, companyId: session.companyId },
    select: { id: true },
  })
  if (!lead) return NextResponse.json({ error: "Lead não encontrado" }, { status: 404 })

  const sistemas = await prisma.environment.findMany({
    where: {
      proposal: { leadId: id },
      OR: [
        { status: { in: ["GUARDADO", "RECUSADO"] } },
        { status: "ATIVO", proposal: { status: { in: STATUS_FECHADO } } },
      ],
    },
    orderBy: { createdAt: "desc" },
    select: {
      id: true, nome: true, status: true, createdAt: true,
      proposal: { select: { id: true, numero: true, createdAt: true, status: true } },
      proposalItems: {
        select: {
          id: true, quantidade: true, valor_total: true, nome_snapshot: true,
          product: { select: { nome: true } },
          kit: { select: { nome: true } },
        },
      },
    },
  })

  return NextResponse.json({
    sistemas: sistemas.map(s => ({
      id: s.id,
      nome: s.nome,
      // "Aceito" pro vendedor: um ATIVO só chega aqui vindo de proposta fechada.
      status: s.status === "ATIVO" ? "ACEITO" : s.status,
      proposta: s.proposal ? { id: s.proposal.id, numero: s.proposal.numero } : null,
      criadoEm: s.createdAt,
      itens: s.proposalItems.length,
      /* Valor da época, explicitamente rotulado assim na tela. */
      valorNaEpoca: s.proposalItems.reduce((t, i) => t + Number(i.valor_total || 0), 0),
      produtos: s.proposalItems.map(i => ({
        nome: i.product?.nome || i.kit?.nome || i.nome_snapshot || "Item",
        quantidade: i.quantidade,
      })),
    })),
  })
}
