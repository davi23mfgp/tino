import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { registrarNoHistorico } from "@/lib/historico-lead"
import { STATUS_LEAD_VALIDOS, rotuloEtapa } from "@/lib/etapas-lead"
import {
  SISTEMAS_VALIDOS, TEMPERATURAS_VALIDAS, TIPOS_IMOVEL_VALIDOS, ETAPAS_OBRA_VALIDAS,
} from "@/lib/lead-ficha"

const STATUS_VALIDOS = STATUS_LEAD_VALIDOS
const ORIGENS_VALIDAS = ["INDICACAO", "SITE", "PARCEIRO", "INSTAGRAM", "OUTRO"]

/** PATCH /api/leads/[id] — atualiza campos/status do lead. */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const existing = await prisma.lead.findFirst({ where: { id, companyId: session.companyId } })
  if (!existing) return NextResponse.json({ error: "Lead não encontrado" }, { status: 404 })

  const body = await req.json().catch(() => ({}))
  const data: Record<string, unknown> = {}
  if (body.nome !== undefined) {
    const n = body.nome.toString().trim()
    if (!n) return NextResponse.json({ error: "Nome não pode ficar vazio" }, { status: 400 })
    data.nome = n
  }
  if (body.telefone !== undefined) data.telefone = body.telefone?.toString().trim() || null
  if (body.email !== undefined) data.email = body.email?.toString().trim() || null
  if (body.origem !== undefined && ORIGENS_VALIDAS.includes(body.origem)) {
    data.origem = body.origem
    // Trocar a origem apaga o detalhe: ele descrevia o "Outro" anterior.
    if (body.origem !== "OUTRO") data.origem_detalhe = null
  }
  if (body.origem_detalhe !== undefined && (body.origem ?? existing.origem) === "OUTRO") {
    data.origem_detalhe = body.origem_detalhe?.toString().trim() || null
  }
  if (body.origem !== undefined && body.origem !== "PARCEIRO") data.partnerId = null
  if (body.partnerId !== undefined && (body.origem ?? existing.origem) === "PARCEIRO") {
    data.partnerId = body.partnerId || null
  }
  if (body.status !== undefined && STATUS_VALIDOS.includes(body.status)) data.status = body.status
  if (body.valor_estimado !== undefined) data.valor_estimado = body.valor_estimado !== "" && body.valor_estimado != null ? Number(body.valor_estimado) : null
  if (body.observacoes !== undefined) data.observacoes = body.observacoes?.toString().trim() || null
  if (body.proposalId !== undefined) data.proposalId = body.proposalId || null

  /* Ficha do cliente: retomada e perfil do projeto.

     Texto livre passa direto; o que é escolha de lista é conferido contra a
     lista. Valor vindo da tela que vira coluna sem validação é o caminho para
     "casa", "Casa" e "CASA" convivendo no mesmo relatório. */
  const LISTAS: Record<string, string[]> = {
    temperatura: TEMPERATURAS_VALIDAS,
    tipo_imovel: TIPOS_IMOVEL_VALIDOS,
    etapa_obra: ETAPAS_OBRA_VALIDAS,
  }
  for (const [campo, validos] of Object.entries(LISTAS)) {
    if (body[campo] !== undefined) {
      data[campo] = validos.includes(body[campo]) ? body[campo] : null
    }
  }
  for (const campo of ["resumo", "proximo_passo", "decisor", "concorrentes", "endereco_obra"]) {
    if (body[campo] !== undefined) data[campo] = body[campo]?.toString().trim() || null
  }
  for (const campo of ["metragem", "ambientes_previstos"]) {
    if (body[campo] !== undefined) {
      const n = Number(body[campo])
      data[campo] = body[campo] === "" || body[campo] == null || !Number.isFinite(n) ? null : Math.round(n)
    }
  }
  if (body.orcamento_declarado !== undefined) {
    data.orcamento_declarado = body.orcamento_declarado !== "" && body.orcamento_declarado != null
      ? Number(body.orcamento_declarado) : null
  }
  for (const campo of ["proximo_passo_em", "previsao_mudanca"]) {
    if (body[campo] !== undefined) data[campo] = body[campo] ? new Date(body[campo]) : null
  }
  if (body.responsavelId !== undefined) data.responsavelId = body.responsavelId || null
  if (body.sistemas !== undefined) {
    data.sistemas = Array.isArray(body.sistemas)
      /* Aceita o que está na lista E o que a empresa escreveu à mão. Sistema
         novo aparece antes de virar item de menu — cerca elétrica saiu daqui,
         mas amanhã entra "aspiração central" —, e recusar o que não está na
         lista fixa faria o campo perder justamente a informação nova.
         O limite de tamanho existe para o campo não virar depósito de texto. */
      ? body.sistemas
          .map((x: unknown) => String(x).trim().slice(0, 40))
          .filter((x: string) => x.length > 0)
          .slice(0, 20)
      : []
  }

  const updated = await prisma.lead.update({ where: { id }, data })

  /* Mudou de fase: a linha do tempo registra sozinha.

     Quem move o card não vai parar para anotar "passou para proposta" — e é
     justamente essa sequência de datas que responde, meses depois, onde a
     negociação travou. Gravado aqui, e não na tela, o registro sobrevive ao
     arraste no celular, à confirmação no quadro e a qualquer outra porta que
     venha a existir para mover um lead. */
  if (data.status && data.status !== existing.status) {
    const motivo = (body.motivo ?? "").toString().trim()
    await registrarNoHistorico(session, {
      leadId: id,
      /* A etapa gravada é a de DESTINO: é onde a negociação passa a estar, e é
         por ela que a linha se agrupa ao ser lida. */
      etapa: String(data.status),
      tipo: "ETAPA",
      de: existing.status,
      para: String(data.status),
      texto: motivo
        ? `${rotuloEtapa(existing.status)} → ${rotuloEtapa(String(data.status))}: ${motivo}`
        : `${rotuloEtapa(existing.status)} → ${rotuloEtapa(String(data.status))}`,
    })
  }

  /* O combinado com o cliente vira linha do histórico.

     "Ligar dia 12, ele volta da viagem" some da tela assim que outra pessoa
     marca o próximo passo seguinte — e some justamente o que explicava por que
     o cliente ficou parado um mês. O campo diz o que fazer AGORA; o histórico
     guarda o que já foi combinado antes. */
  const passoNovo = (body.proximo_passo ?? "").toString().trim()
  if (
    body.proximo_passo !== undefined && passoNovo &&
    passoNovo !== (existing.proximo_passo ?? "")
  ) {
    const quando = data.proximo_passo_em instanceof Date
      ? ` (${data.proximo_passo_em.toLocaleDateString("pt-BR")})`
      : ""
    await registrarNoHistorico(session, {
      leadId: id, etapa: updated.status, tipo: "SISTEMA",
      texto: `Próximo passo definido: ${passoNovo}${quando}`,
    })
  }

  return NextResponse.json(updated)
}

/** DELETE /api/leads/[id] — remove o lead. */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  /* Excluir o lead leva o histórico junto (as anotações caem por cascata), e
     histórico que qualquer pessoa apaga não serve como registro. Por isso a
     porta é a mesma da correção: o Admin. Vendedor que desistiu do contato
     move para "Perdido" — o cadastro some do caminho e a conversa fica. */
  if (session.role !== "ADMIN") {
    return NextResponse.json(
      { error: "Só o Admin exclui um lead. Mova para \"Perdido\" para tirá-lo do funil." },
      { status: 403 },
    )
  }

  const { id } = await params
  const existing = await prisma.lead.findFirst({ where: { id, companyId: session.companyId } })
  if (!existing) return NextResponse.json({ error: "Lead não encontrado" }, { status: 404 })

  await prisma.lead.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
