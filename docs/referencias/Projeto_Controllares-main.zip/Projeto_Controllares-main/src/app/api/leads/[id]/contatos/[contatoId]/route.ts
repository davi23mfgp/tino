import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { PAPEIS_VALIDOS } from "@/lib/lead-ficha"

export const dynamic = "force-dynamic"

/**
 * PATCH  /api/leads/[id]/contatos/[contatoId]
 * DELETE /api/leads/[id]/contatos/[contatoId]
 *
 * Contato se corrige e se remove livremente — ao contrário do histórico. Um é
 * agenda: o telefone mudou, o arquiteto saiu do projeto, e manter o número
 * velho na tela só faz alguém ligar para ele. O outro é registro do que
 * aconteceu, e por isso não se reescreve.
 */
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string; contatoId: string }> },
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id, contatoId } = await params
  const existente = await prisma.leadContato.findFirst({
    where: { id: contatoId, leadId: id, companyId: session.companyId },
  })
  if (!existente) return NextResponse.json({ error: "Contato não encontrado" }, { status: 404 })

  const body = await req.json().catch(() => ({}))
  const data: Record<string, unknown> = {}

  if (body.nome !== undefined) {
    const n = body.nome.toString().trim()
    if (!n) return NextResponse.json({ error: "Nome não pode ficar vazio." }, { status: 400 })
    data.nome = n
  }
  if (body.papel !== undefined) data.papel = PAPEIS_VALIDOS.includes(body.papel) ? body.papel : "OUTRO"
  for (const campo of ["telefone", "email", "observacao"]) {
    if (body[campo] !== undefined) data[campo] = body[campo]?.toString().trim() || null
  }

  const contato = await prisma.$transaction(async tx => {
    if (body.principal === true) {
      await tx.leadContato.updateMany({
        where: { leadId: id, companyId: session.companyId },
        data: { principal: false },
      })
      data.principal = true
    } else if (body.principal === false) {
      data.principal = false
    }
    return tx.leadContato.update({ where: { id: contatoId }, data })
  })

  return NextResponse.json(contato)
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string; contatoId: string }> },
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id, contatoId } = await params
  const existente = await prisma.leadContato.findFirst({
    where: { id: contatoId, leadId: id, companyId: session.companyId },
    select: { id: true },
  })
  if (!existente) return NextResponse.json({ error: "Contato não encontrado" }, { status: 404 })

  await prisma.leadContato.delete({ where: { id: contatoId } })
  return NextResponse.json({ success: true })
}
