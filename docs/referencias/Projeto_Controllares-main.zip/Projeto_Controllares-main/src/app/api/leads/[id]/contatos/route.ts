import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { registrarNoHistorico } from "@/lib/historico-lead"
import { PAPEIS_VALIDOS } from "@/lib/lead-ficha"

export const dynamic = "force-dynamic"

/**
 * As pessoas em volta de um negócio.
 *
 * GET  /api/leads/[id]/contatos
 * POST /api/leads/[id]/contatos  { nome, papel, telefone, email, observacao }
 *
 * Um projeto residencial não tem "o cliente": tem quem paga, quem escolhe, o
 * arquiteto que especifica e o mestre de obra que abre a parede. Espremidos no
 * campo `telefone` do lead, três meses depois ninguém sabe qual número era o do
 * arquiteto — e alguém liga para o marido perguntando da altura da caixa.
 */
async function leadDaEmpresa(id: string, companyId: string) {
  return prisma.lead.findFirst({ where: { id, companyId }, select: { id: true, status: true } })
}

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const contatos = await prisma.leadContato.findMany({
    where: { leadId: id, companyId: session.companyId },
    /* O principal primeiro: é para ele que se liga, e procurá-lo no meio de
       uma lista alfabética é trabalho que a ordenação resolve de graça. */
    orderBy: [{ principal: "desc" }, { createdAt: "asc" }],
  })
  return NextResponse.json({ contatos })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const lead = await leadDaEmpresa(id, session.companyId)
  if (!lead) return NextResponse.json({ error: "Lead não encontrado" }, { status: 404 })

  const body = await req.json().catch(() => ({}))
  const nome = (body.nome ?? "").toString().trim()
  if (!nome) return NextResponse.json({ error: "Informe o nome." }, { status: 400 })

  const papel = PAPEIS_VALIDOS.includes(body.papel) ? body.papel : "OUTRO"
  const principal = body.principal === true

  const contato = await prisma.$transaction(async tx => {
    /* Principal é um só. Marcar o novo sem desmarcar o antigo deixaria dois
       "ligue para este", que é o mesmo que nenhum. */
    if (principal) {
      await tx.leadContato.updateMany({
        where: { leadId: id, companyId: session.companyId },
        data: { principal: false },
      })
    }
    return tx.leadContato.create({
      data: {
        companyId: session.companyId,
        leadId: id,
        nome,
        papel,
        telefone: body.telefone?.toString().trim() || null,
        email: body.email?.toString().trim() || null,
        observacao: body.observacao?.toString().trim() || null,
        principal,
      },
    })
  })

  await registrarNoHistorico(session, {
    leadId: id, etapa: lead.status, tipo: "SISTEMA",
    texto: `${nome} entrou na ficha como ${papel.replace(/_/g, " ").toLowerCase()}.`,
  })

  return NextResponse.json(contato, { status: 201 })
}
