import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { temSessaoSistema } from "@/lib/acesso-sistema"
import { anomalias, acessosDeLugarNovo } from "@/lib/vigia"

export const dynamic = "force-dynamic"

/**
 * O que o vigia viu.
 *
 * Exige as duas portas: perfil de Admin e a confirmação recente do segundo
 * fator. Uma sessão de Admin esquecida aberta numa máquina não abre esta tela.
 */
export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Área restrita ao Admin." }, { status: 403 })
  }
  if (!(await temSessaoSistema(session.userId))) {
    return NextResponse.json({ error: "Confirme o código do segundo fator.", precisaCodigo: true }, { status: 401 })
  }

  const desde = new Date(Date.now() - 7 * 86_400_000)

  const [achados, lugaresNovos, eventos, porTipo, contasEstranhas, bloqueios] = await Promise.all([
    anomalias(session.companyId),
    acessosDeLugarNovo(session.companyId),
    /* Linha do tempo: o que aconteceu, não só o resumo. Sem ela, o painel diz
       "houve 8 falhas" e quem vigia não tem como ver de onde vieram. */
    prisma.securityEvent.findMany({
      where: {
        createdAt: { gte: desde },
        OR: [{ companyId: session.companyId }, { companyId: null }],
      },
      orderBy: { createdAt: "desc" },
      take: 120,
      select: {
        id: true, tipo: true, gravidade: true, descricao: true,
        email: true, ip: true, rota: true, createdAt: true,
      },
    }),
    prisma.securityEvent.groupBy({
      by: ["tipo"],
      where: {
        createdAt: { gte: desde },
        OR: [{ companyId: session.companyId }, { companyId: null }],
      },
      _count: { tipo: true },
    }),
    /* Conta pendente é conta que pediu entrada e ninguém aprovou. Fica aqui
       porque é o caminho mais silencioso para alguém aparecer dentro da
       empresa sem que o Admin repare. */
    prisma.user.findMany({
      where: { companyId: session.companyId, status: { not: "ATIVO" } },
      select: { id: true, nome: true, email: true, role: true, status: true, createdAt: true },
      orderBy: { createdAt: "desc" },
      take: 20,
    }),
    // Travas de força bruta ainda em vigor.
    prisma.loginAttempt.findMany({
      where: { bloqueadoAte: { gte: new Date() } },
      select: { chave: true, tentativas: true, bloqueadoAte: true },
      take: 20,
    }),
  ])

  return NextResponse.json({
    anomalias: achados,
    lugaresNovos,
    eventos,
    resumo: Object.fromEntries(porTipo.map(t => [t.tipo, t._count.tipo])),
    contasEstranhas,
    bloqueios,
    medidoEm: new Date().toISOString(),
  })
}
