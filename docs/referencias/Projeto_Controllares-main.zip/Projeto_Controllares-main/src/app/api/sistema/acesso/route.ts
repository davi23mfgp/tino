import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { verificarCodigoTotp } from "@/lib/totp"
import {
  abrirSessaoSistema, fecharSessaoSistema, temSessaoSistema, VALIDADE_SESSAO_SISTEMA_MIN,
} from "@/lib/acesso-sistema"
import { registrar, origem } from "@/lib/vigia"

export const dynamic = "force-dynamic"

/**
 * Porta do painel Sistema.
 *
 * GET    — situação: se o Admin já confirmou o código e se tem 2FA configurado.
 * POST   — troca o código do aplicativo autenticador pela liberação.
 * DELETE — fecha a liberação (sair do painel sem esperar expirar).
 */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Área restrita ao Admin." }, { status: 403 })
  }

  const user = await prisma.user.findUnique({
    where: { id: session.userId },
    select: { totp_enabled: true },
  })

  return NextResponse.json({
    liberado: await temSessaoSistema(session.userId),
    // Sem 2FA configurado não há como abrir a porta — e isso precisa ficar claro
    // na tela, senão o Admin fica tentando um código que não existe.
    temSegundoFator: !!user?.totp_enabled,
    validadeMin: VALIDADE_SESSAO_SISTEMA_MIN,
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { ip, userAgent } = origem(req)

  if (!temAlgumPerfil(session, ["ADMIN"])) {
    /* Alguém sem perfil de Admin batendo aqui é exatamente o que o painel
       existe para mostrar. */
    await registrar({
      tipo: "SISTEMA_FALHA", gravidade: "alta",
      descricao: `${session.email} tentou abrir o painel Sistema sem ser Admin`,
      companyId: session.companyId, userId: session.userId, email: session.email,
      ip, userAgent, rota: "/api/sistema/acesso",
    })
    return NextResponse.json({ error: "Área restrita ao Admin." }, { status: 403 })
  }

  const { codigo } = await req.json().catch(() => ({}))
  const digitado = String(codigo ?? "").replace(/\D/g, "")

  const user = await prisma.user.findUnique({
    where: { id: session.userId },
    select: { totp_enabled: true, totp_secret: true },
  })

  if (!user?.totp_enabled || !user.totp_secret) {
    return NextResponse.json({
      error: "Ative o segundo fator na sua conta antes de abrir o painel Sistema.",
      faltaSegundoFator: true,
    }, { status: 428 })
  }

  if (digitado.length !== 6 || !(await verificarCodigoTotp(digitado, user.totp_secret))) {
    await registrar({
      tipo: "SISTEMA_FALHA", gravidade: "alta",
      descricao: `Código do segundo fator recusado ao abrir o painel Sistema (${session.email})`,
      companyId: session.companyId, userId: session.userId, email: session.email,
      ip, userAgent, rota: "/api/sistema/acesso",
    })
    return NextResponse.json({ error: "Código incorreto." }, { status: 403 })
  }

  await abrirSessaoSistema(session.userId)

  /* Entrada bem-sucedida também vira registro. O painel mostra tentativas de
     fora, mas quem abriu e quando é a informação que falta depois — sobretudo
     quando um técnico esteve na máquina. */
  await registrar({
    tipo: "SISTEMA_OK",
    descricao: `Painel Sistema aberto por ${session.email}`,
    companyId: session.companyId, userId: session.userId, email: session.email,
    ip, userAgent, rota: "/api/sistema/acesso",
  })

  return NextResponse.json({ ok: true, validadeMin: VALIDADE_SESSAO_SISTEMA_MIN })
}

export async function DELETE() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  await fecharSessaoSistema()
  return NextResponse.json({ ok: true })
}
