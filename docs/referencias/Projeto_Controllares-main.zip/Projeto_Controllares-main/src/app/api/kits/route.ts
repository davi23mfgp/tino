import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const kits = await prisma.kit.findMany({
    where: { companyId: session.companyId },
    include: {
      items: {
        include: {
          product: true
        }
      }
    },
    orderBy: { createdAt: "desc" }
  })

  return NextResponse.json({ kits })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const body = await req.json()
  const { nome, descricao, markup_global, desconto, items } = body

  if (!nome) return NextResponse.json({ error: "Nome é obrigatório" }, { status: 400 })

  const kit = await prisma.kit.create({
    data: {
      nome,
      descricao,
      markup_global: markup_global || null,
      desconto: desconto || null,
      companyId: session.companyId,
      items: items?.length ? {
        create: items.map((item: { productId: string; quantidade: number; markup_especifico?: number | null; desconto_unitario?: number | null }) => ({
          productId: item.productId,
          quantidade: item.quantidade || 1,
          markup_especifico: item.markup_especifico ?? null,
          desconto_unitario: item.desconto_unitario ?? null,
        }))
      } : undefined
    },
    include: {
      items: {
        include: { product: true }
      }
    }
  })

  return NextResponse.json(kit, { status: 201 })
}
