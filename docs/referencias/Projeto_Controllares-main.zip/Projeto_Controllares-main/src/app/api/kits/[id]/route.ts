import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params

  const kit = await prisma.kit.findFirst({
    where: { id, companyId: session.companyId },
    include: {
      items: {
        include: { product: true }
      }
    }
  })

  if (!kit) return NextResponse.json({ error: "Kit não encontrado" }, { status: 404 })

  return NextResponse.json(kit)
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const body = await req.json()
  const { nome, descricao, markup_global, desconto, items } = body

  const existing = await prisma.kit.findFirst({ where: { id, companyId: session.companyId } })
  if (!existing) return NextResponse.json({ error: "Kit não encontrado" }, { status: 404 })

  const kit = await prisma.$transaction(async (tx) => {
    if (items !== undefined) {
      await tx.kitItem.deleteMany({ where: { kitId: id } })
    }

    return tx.kit.update({
      where: { id },
      data: {
        ...(nome !== undefined && { nome }),
        ...(descricao !== undefined && { descricao }),
        ...(markup_global !== undefined && { markup_global }),
        ...(desconto !== undefined && { desconto }),
        ...(items !== undefined && {
          items: {
            create: items.map((item: { productId: string; quantidade: number }) => ({
              productId: item.productId,
              quantidade: item.quantidade || 1,
            }))
          }
        })
      },
      include: {
        items: { include: { product: true } }
      }
    })
  })

  return NextResponse.json(kit)
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params

  const existing = await prisma.kit.findFirst({ where: { id, companyId: session.companyId } })
  if (!existing) return NextResponse.json({ error: "Kit não encontrado" }, { status: 404 })

  await prisma.kit.delete({ where: { id } })

  return NextResponse.json({ success: true })
}
