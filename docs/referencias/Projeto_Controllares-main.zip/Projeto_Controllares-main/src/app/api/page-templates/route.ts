import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"

/**
 * Modelos de documento: páginas de anexo da proposta e minutas de contrato.
 *
 * Os dois vivem na mesma tabela porque o que muda entre eles é onde o texto é
 * consumido, não como é escrito. `tipo` separa: sem ele, o seletor de anexos da
 * proposta ofereceria minutas de contrato.
 */
const TIPOS = ["ANEXO", "CONTRATO"] as const
type Tipo = (typeof TIPOS)[number]

const normalizarTipo = (v: unknown): Tipo =>
  TIPOS.includes(String(v).toUpperCase() as Tipo) ? (String(v).toUpperCase() as Tipo) : "ANEXO"

/** GET /api/page-templates?tipo=CONTRATO — sem `tipo`, devolve todos. */
export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const pedido = new URL(req.url).searchParams.get("tipo")
  const templates = await prisma.pageTemplate.findMany({
    where: {
      companyId: session.companyId,
      ...(pedido ? { tipo: normalizarTipo(pedido) } : {}),
    },
    orderBy: { nome: "asc" },
    select: { id: true, nome: true, tipo: true, descricao: true, conteudo: true, updatedAt: true },
  })
  return NextResponse.json({ templates })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Só Admin e Financeiro editam modelos." }, { status: 403 })
  }
  const { nome, conteudo, tipo, descricao } = await req.json()
  if (!nome?.trim()) return NextResponse.json({ error: "Informe um nome" }, { status: 400 })
  const t = await prisma.pageTemplate.create({
    data: {
      companyId: session.companyId,
      nome: nome.trim(),
      tipo: normalizarTipo(tipo),
      descricao: descricao?.trim() || null,
      conteudo: conteudo || "",
    },
    select: { id: true, nome: true, tipo: true, descricao: true, conteudo: true, updatedAt: true },
  })
  return NextResponse.json(t, { status: 201 })
}

export async function PATCH(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Só Admin e Financeiro editam modelos." }, { status: 403 })
  }
  const { id, nome, conteudo, tipo, descricao } = await req.json()
  if (!id) return NextResponse.json({ error: "id obrigatório" }, { status: 400 })

  // updateMany com companyId no filtro: um id de outra empresa não encontra
  // nada em vez de atualizar o registro alheio.
  const r = await prisma.pageTemplate.updateMany({
    where: { id, companyId: session.companyId },
    data: {
      ...(nome !== undefined && { nome: String(nome).trim() }),
      ...(conteudo !== undefined && { conteudo: String(conteudo) }),
      ...(tipo !== undefined && { tipo: normalizarTipo(tipo) }),
      ...(descricao !== undefined && { descricao: String(descricao).trim() || null }),
    },
  })
  if (!r.count) return NextResponse.json({ error: "Modelo não encontrado" }, { status: 404 })
  return NextResponse.json({ ok: true })
}

export async function DELETE(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Só Admin e Financeiro editam modelos." }, { status: 403 })
  }
  const id = new URL(req.url).searchParams.get("id")
  if (!id) return NextResponse.json({ error: "id obrigatório" }, { status: 400 })
  await prisma.pageTemplate.deleteMany({ where: { id, companyId: session.companyId } })
  return NextResponse.json({ ok: true })
}
