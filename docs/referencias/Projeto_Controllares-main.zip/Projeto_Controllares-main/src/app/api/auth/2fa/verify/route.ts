import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { createToken, verifyToken } from "@/lib/auth"
import { verificarCodigoTotp } from "@/lib/totp"
import { minutosBloqueado, registrarFalha, limparFalhas } from "@/lib/trava-tentativas"
import { COOKIE_2FA, COOKIE_SESSAO, lerCookie2fa } from "@/lib/cookie-sessao"
import { registrar, origem } from "@/lib/vigia"

/**
 * Anti-brute-force do código TOTP, no BANCO.
 *
 * Antes ficava num Map em memória: em serverless cada instância tem o seu, e
 * some a qualquer momento. Como o código TOTP tem só 6 dígitos, isso era o
 * ponto mais frágil — quem já tivesse a senha conseguiria varrer os códigos.
 * A chave é o userId (não o IP), porque quem ataca troca de IP à vontade.
 */
const chave2fa = (userId: string) => `2fa:${userId}`

/**
 * POST /api/auth/2fa/verify — segunda etapa do login.
 * Exige o cookie 2FA legado (emitido após a senha correta) + { codigo }.
 */
export async function POST(req: NextRequest) {
  const pending = req.cookies && lerCookie2fa(req.cookies)
  if (!pending) return NextResponse.json({ error: "Sessão de 2FA expirada. Faça login novamente." }, { status: 401 })

  const payload = await verifyToken(pending)
  if (!payload || payload.role !== "2FA_PENDING") {
    return NextResponse.json({ error: "Sessão de 2FA inválida. Faça login novamente." }, { status: 401 })
  }

  const { codigo } = await req.json().catch(() => ({}))
  if (!codigo) return NextResponse.json({ error: "Código obrigatório." }, { status: 400 })

  const k = chave2fa(payload.userId)
  const bloqueio = await minutosBloqueado(k)
  if (bloqueio > 0) {
    return NextResponse.json({ error: `Muitas tentativas. Aguarde ${bloqueio} min.` }, { status: 429 })
  }

  const user = await prisma.user.findUnique({ where: { id: payload.userId } })
  if (!user?.totp_secret || !user.totp_enabled || user.status !== "ATIVO") {
    return NextResponse.json({ error: "2FA não disponível para esta conta." }, { status: 400 })
  }

  const { ip, userAgent } = origem(req)
  const ok = await verificarCodigoTotp(String(codigo), user.totp_secret)
  if (!ok) {
    await registrarFalha(k)
    /* Falha aqui é grave mesmo isolada: quem chega no segundo fator já passou
       pela senha, então a senha da conta pode estar comprometida. */
    await registrar({
      tipo: "2FA_FALHA", gravidade: "alta",
      descricao: `Código do segundo fator recusado no login (${user.email})`,
      companyId: user.companyId, userId: user.id, email: user.email,
      ip, userAgent, rota: "/api/auth/2fa/verify",
    })
    return NextResponse.json({ error: "Código inválido." }, { status: 401 })
  }
  await limparFalhas(k)
  await registrar({
    tipo: "2FA_OK", descricao: `Entrou com segundo fator (${user.email})`,
    companyId: user.companyId, userId: user.id, email: user.email,
    ip, userAgent, rota: "/api/auth/2fa/verify",
  })

  await prisma.aiAuditLog.create({
    data: {
      userId: user.id, companyId: user.companyId, tipo_acesso: "LOGIN",
      descricao: `Entrou no sistema com 2FA (${user.email})`,
    },
  }).catch(() => {})

  const token = await createToken({
    userId: user.id, email: user.email, nome: user.nome,
    role: user.role, roles: user.roles ?? [], companyId: user.companyId,
  })
  const res = NextResponse.json({ success: true, nome: user.nome, role: user.role })
  res.cookies.set(COOKIE_SESSAO, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 7,
    path: "/",
  })
  res.cookies.set(COOKIE_2FA, "", { expires: new Date(0), path: "/" })
  return res
}
