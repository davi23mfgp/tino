import { NextRequest, NextResponse } from "next/server";
import { randomBytes } from "crypto";

export async function GET(req: NextRequest) {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  if (!clientId) {
    return NextResponse.json({ error: "Google OAuth não configurado." }, { status: 503 });
  }

  // Redirect_uri FIXO (APP_URL) — Vercel muda o domínio de preview a cada
  // deploy, e o Google só aceita o redirect_uri whitelistado no Console.
  const appUrl = process.env.APP_URL || new URL(req.url).origin;
  const redirectUri = `${appUrl}/api/auth/google/callback`;

  // CSRF state token
  const state = randomBytes(16).toString("hex");

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: "openid email profile",
    access_type: "offline",
    prompt: "select_account",
    state,
  });

  const response = NextResponse.redirect(
    `https://accounts.google.com/o/oauth2/v2/auth?${params}`
  );

  // Armazena state em cookie httpOnly para validar no callback
  response.cookies.set("google_oauth_state", state, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 60 * 10, // 10 minutos
    path: "/",
  });

  return response;
}
