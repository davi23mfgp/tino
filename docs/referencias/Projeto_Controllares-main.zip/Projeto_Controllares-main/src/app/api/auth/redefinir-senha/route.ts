import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import bcrypt from "bcryptjs"
import crypto from "crypto"
import { avaliarSenha } from "@/lib/forca-senha"

export const dynamic = "force-dynamic"

const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex")

/**
 * GET /api/auth/redefinir-senha?token=…  → valida se o token ainda serve
 * (usado pela página só para mostrar o formulário ou a mensagem de expirado).
 */
export async function GET(req: NextRequest) {
  const token = new URL(req.url).searchParams.get("token") || ""
  if (!token) return NextResponse.json({ valido: false }, { status: 400 })

  const user = await prisma.user.findUnique({
    where: { reset_token_hash: sha256(token) },
    select: { reset_token_expiry: true },
  })
  const valido = !!user?.reset_token_expiry && user.reset_token_expiry > new Date()
  return NextResponse.json({ valido })
}

/**
 * POST /api/auth/redefinir-senha  { token, senha }
 *
 * Troca a senha se o token for válido e não expirado. Consome o token (uso
 * único) e limpa a trava de "esqueci a senha" da conta.
 */
export async function POST(req: NextRequest) {
  const { token, senha } = await req.json().catch(() => ({}))

  if (!token || typeof token !== "string") {
    return NextResponse.json({ error: "Link inválido." }, { status: 400 })
  }
  if (!senha || typeof senha !== "string" || senha.length < 8) {
    return NextResponse.json({ error: "A senha deve ter ao menos 8 caracteres." }, { status: 400 })
  }

  /* A força é conferida no servidor também. A barra na tela orienta, mas quem
     manda direto na API passaria por cima dela — e a senha fraca ficaria
     valendo de verdade. */
  if (!avaliarSenha(senha).aceitavel) {
    return NextResponse.json({
      error: "Senha muito fraca. Use pelo menos 10 caracteres e evite palavras"
        + " comuns, sequências do teclado ou o seu próprio nome.",
    }, { status: 400 })
  }

  const user = await prisma.user.findUnique({
    where: { reset_token_hash: sha256(token) },
    select: { id: true, companyId: true, email: true, reset_token_expiry: true },
  })
  if (!user || !user.reset_token_expiry || user.reset_token_expiry <= new Date()) {
    return NextResponse.json({ error: "Link expirado ou já usado. Peça um novo." }, { status: 400 })
  }

  await prisma.user.update({
    where: { id: user.id },
    data: {
      senha: await bcrypt.hash(senha, 12),
      must_change_password: false,
      reset_token_hash: null,
      reset_token_expiry: null,
    },
  })

  await prisma.aiAuditLog.create({
    data: {
      userId: user.id, companyId: user.companyId, tipo_acesso: "EDITAR",
      descricao: `Redefiniu a própria senha via link de recuperação (${user.email}).`,
    },
  }).catch(() => {})

  return NextResponse.json({ ok: true })
}
