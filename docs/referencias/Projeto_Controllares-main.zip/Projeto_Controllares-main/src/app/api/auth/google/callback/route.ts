import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createToken } from "@/lib/auth";
import { COOKIE_SESSAO } from "@/lib/cookie-sessao"

interface GoogleTokenResponse {
  access_token: string;
  id_token: string;
  error?: string;
}

interface GoogleUserInfo {
  sub: string;
  email: string;
  name: string;
  picture: string;
  email_verified: boolean;
}

const ROLE_REDIRECT: Record<string, string> = {
  ADMIN: "/dashboard",
  VENDEDOR: "/propostas",
  FINANCEIRO: "/financeiro",
  RESPONSAVEL_TECNICO: "/operacional",
  INSTALADOR: "/minha-area",
  ENGENHEIRO_PROJETOS: "/operacional",
};

export async function GET(req: NextRequest) {
  // MESMA origem usada no /api/auth/google (o redirect_uri precisa bater exatamente).
  // Fixo via APP_URL — não deriva do domínio de preview do Vercel.
  const appUrl = process.env.APP_URL || new URL(req.url).origin;
  const redirectUri = `${appUrl}/api/auth/google/callback`;

  const { searchParams } = new URL(req.url);
  const code = searchParams.get("code");
  const state = searchParams.get("state");
  const error = searchParams.get("error");

  // Usuário cancelou
  if (error) {
    return NextResponse.redirect(`${appUrl}/login?error=google_cancelled`);
  }

  if (!code || !state) {
    return NextResponse.redirect(`${appUrl}/login?error=google_invalid`);
  }

  // Valida CSRF state
  const storedState = req.cookies.get("google_oauth_state")?.value;
  if (!storedState || storedState !== state) {
    return NextResponse.redirect(`${appUrl}/login?error=google_state`);
  }

  try {
    // 1. Troca code por tokens
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: process.env.GOOGLE_CLIENT_ID!,
        client_secret: process.env.GOOGLE_CLIENT_SECRET!,
        redirect_uri: redirectUri,
        grant_type: "authorization_code",
      }),
    });

    const tokens: GoogleTokenResponse = await tokenRes.json();
    if (tokens.error || !tokens.access_token) {
      return NextResponse.redirect(`${appUrl}/login?error=google_token`);
    }

    // 2. Busca perfil do usuário
    const userInfoRes = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
      headers: { Authorization: `Bearer ${tokens.access_token}` },
    });
    const googleUser: GoogleUserInfo = await userInfoRes.json();

    if (!googleUser.email_verified) {
      return NextResponse.redirect(`${appUrl}/login?error=google_unverified`);
    }

    // 3. Busca usuário existente (por google_oauth_id ou email)
    let user = await prisma.user.findFirst({
      where: {
        OR: [
          { google_oauth_id: googleUser.sub },
          { email: googleUser.email.toLowerCase() },
        ],
      },
      include: { company: true },
    });

    if (user && user.status === "PENDENTE") {
      return NextResponse.redirect(`${appUrl}/login?error=pending`);
    }

    if (user) {
      // Atualiza dados Google se necessário
      await prisma.user.update({
        where: { id: user.id },
        data: {
          google_oauth_id: googleUser.sub,
          avatar_url: googleUser.picture,
        },
      });

      const token = await createToken({
        userId: user.id,
        email: user.email,
        nome: user.nome,
        role: user.role,
        roles: (user as { roles?: string[] }).roles ?? [],
        companyId: user.companyId,
      });

      await prisma.aiAuditLog.create({
        data: {
          userId: user.id, companyId: user.companyId, tipo_acesso: "LOGIN",
          descricao: `Entrou no sistema via Google (${user.email})`,
        },
      }).catch(() => {});

      const destino = ROLE_REDIRECT[user.role] ?? "/dashboard";
      const res = NextResponse.redirect(`${appUrl}${destino}`);
      res.cookies.set(COOKIE_SESSAO, token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 60 * 60 * 24 * 7,
        path: "/",
      });
      res.cookies.delete("google_oauth_state");
      return res;
    }

    // 4. Novo usuário — guarda dados Google em cookie temporário
    //    e redireciona para completar o cadastro (empresa + CNPJ)
    const pendingData = Buffer.from(
      JSON.stringify({
        sub: googleUser.sub,
        email: googleUser.email,
        nome: googleUser.name,
        avatar_url: googleUser.picture,
      })
    ).toString("base64");

    const res = NextResponse.redirect(`${appUrl}/cadastro/google`);
    res.cookies.set("google_pending", pendingData, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 30, // 30 minutos para completar
      path: "/",
    });
    res.cookies.delete("google_oauth_state");
    return res;
  } catch (err) {
    console.error("Google OAuth callback error:", err);
    return NextResponse.redirect(`${appUrl}/login?error=google_error`);
  }
}
