import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { createToken } from "@/lib/auth"
import bcrypt from "bcryptjs"
import { chaveTentativa, minutosBloqueado, registrarFalha, limparFalhas } from "@/lib/trava-tentativas"
import { COOKIE_SESSAO } from "@/lib/cookie-sessao"
import { avaliarSenha } from "@/lib/forca-senha"

/**
 * POST /api/auth/trocar-senha — { email, senha_atual, senha_nova }.
 * Usado no fluxo de troca forçada (must_change_password) direto da tela de login.
 * Valida a senha atual, grava a nova e já emite a sessão.
 */
export async function POST(req: NextRequest) {
  const { email, senha_atual, senha_nova } = await req.json().catch(() => ({}))

  if (!email || !senha_atual) {
    return NextResponse.json({ error: "Dados incompletos." }, { status: 400 })
  }
  if (!senha_nova || senha_nova.length < 8) {
    return NextResponse.json({ error: "Nova senha deve ter ao menos 8 caracteres." }, { status: 400 })
  }

  /* Esta rota é a da troca forçada — o Admin exigiu a redefinição justamente
     porque a senha anterior não servia. Aceitar outra fraca aqui esvaziaria a
     exigência. A conferência é no servidor porque a barra da tela orienta, mas
     quem chama a API direto passa por cima dela. */
  if (!avaliarSenha(senha_nova, { email }).aceitavel) {
    return NextResponse.json({
      error: "Senha muito fraca. Use pelo menos 10 caracteres e evite palavras"
        + " comuns, sequências do teclado ou o seu próprio nome.",
    }, { status: 400 })
  }

  if (senha_nova === senha_atual) {
    return NextResponse.json({ error: "A nova senha deve ser diferente da atual." }, { status: 400 })
  }

  // Mesma trava do login: esta rota também compara senha, então sem ela seria
  // um caminho alternativo de força bruta com o login trancado.
  const k = chaveTentativa(req, String(email), "trocar-senha")
  const bloqueio = await minutosBloqueado(k)
  if (bloqueio > 0) {
    return NextResponse.json({ error: `Muitas tentativas. Tente novamente em ${bloqueio} min.` }, { status: 429 })
  }

  const user = await prisma.user.findUnique({ where: { email: String(email).toLowerCase() } })
  if (!user || !(await bcrypt.compare(senha_atual, user.senha))) {
    await registrarFalha(k)
    return NextResponse.json({ error: "E-mail ou senha incorretos." }, { status: 401 })
  }
  await limparFalhas(k)
  if (user.status !== "ATIVO") {
    return NextResponse.json({ error: "Conta indisponível." }, { status: 403 })
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { senha: await bcrypt.hash(senha_nova, 12), must_change_password: false },
  })

  await prisma.aiAuditLog.create({
    data: {
      userId: user.id, companyId: user.companyId, tipo_acesso: "DADOS",
      descricao: `Trocou a senha (redefinição obrigatória) — ${user.email}`,
    },
  }).catch(() => {})

  // 2FA ativo? Ainda precisa do código — manda de volta ao fluxo de login.
  if (user.totp_enabled && user.totp_secret) {
    return NextResponse.json({ ok: true, twofaRequired: true })
  }

  const token = await createToken({
    userId: user.id, email: user.email, nome: user.nome,
    role: user.role, roles: user.roles ?? [], companyId: user.companyId,
  })
  const res = NextResponse.json({ success: true, nome: user.nome, role: user.role })
  res.cookies.set(COOKIE_SESSAO, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 7,
    path: "/",
  })
  return res
}
