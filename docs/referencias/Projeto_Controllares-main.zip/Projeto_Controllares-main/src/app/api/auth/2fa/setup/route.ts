import { NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { gerarSegredoTotp, uriTotp } from "@/lib/totp"
import QRCode from "qrcode"

/** GET /api/auth/2fa/setup — status do 2FA do usuário logado. */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const user = await prisma.user.findUnique({
    where: { id: session.userId }, select: { totp_enabled: true },
  })
  return NextResponse.json({ enabled: !!user?.totp_enabled, isAdmin: session.role === "ADMIN" })
}

/**
 * POST /api/auth/2fa/setup — gera segredo TOTP e QR code (ADMIN).
 * O segredo só é ativado após confirmação em /2fa/confirm.
 */
export async function POST() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (session.role !== "ADMIN") {
    return NextResponse.json({ error: "2FA disponível apenas para ADMIN." }, { status: 403 })
  }

  const secret = await gerarSegredoTotp()
  await prisma.user.update({
    where: { id: session.userId },
    data: { totp_secret: secret, totp_enabled: false },
  })

  const qr = await QRCode.toDataURL(uriTotp(session.email, secret))

  return NextResponse.json({ qr, secret })
}
