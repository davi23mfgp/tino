import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createToken } from "@/lib/auth";
import { enviarEmail } from "@/lib/email";
import { emailAguardandoAprovacao } from "@/lib/email-templates";
import { COOKIE_SESSAO } from "@/lib/cookie-sessao"

export async function POST(req: NextRequest) {
  const appUrl = new URL(req.url).origin;

  const pendingCookie = req.cookies.get("google_pending")?.value;
  if (!pendingCookie) {
    return NextResponse.json({ error: "Sessão expirada. Tente novamente." }, { status: 400 });
  }

  let googleData: { sub: string; email: string; nome: string; avatar_url: string };
  try {
    googleData = JSON.parse(Buffer.from(pendingCookie, "base64").toString("utf-8"));
  } catch {
    return NextResponse.json({ error: "Dados inválidos." }, { status: 400 });
  }

  const { nomeEmpresa, cnpjCpf } = await req.json();

  if (!nomeEmpresa?.trim() || !cnpjCpf?.trim()) {
    return NextResponse.json({ error: "Nome da empresa e CNPJ são obrigatórios." }, { status: 400 });
  }

  // Verifica duplicatas
  const emailExistente = await prisma.user.findUnique({ where: { email: googleData.email.toLowerCase() } });
  if (emailExistente) {
    return NextResponse.json({ error: "Este e-mail já está cadastrado." }, { status: 409 });
  }

  const cnpjExistente = await prisma.company.findUnique({ where: { cnpj_cpf: cnpjCpf } });
  if (cnpjExistente) {
    const emailLower = googleData.email.toLowerCase();

    // Convite pendente para este e-mail? Entra ATIVO direto com o perfil escolhido.
    const convite = await prisma.invite.findFirst({
      where: { companyId: cnpjExistente.id, email: emailLower, usedAt: null, expiresAt: { gt: new Date() } },
    });

    const user = await prisma.user.create({
      data: {
        nome: googleData.nome,
        email: emailLower,
        senha: "",
        role: convite?.role ?? "VENDEDOR",
        status: convite ? "ATIVO" : "PENDENTE",
        companyId: cnpjExistente.id,
        google_oauth_id: googleData.sub,
        avatar_url: googleData.avatar_url,
      },
    });

    if (convite) {
      await prisma.invite.update({ where: { id: convite.id }, data: { usedAt: new Date() } });
      const token = await createToken({
        userId: user.id, email: user.email, nome: user.nome,
        role: user.role, roles: user.roles ?? [], companyId: user.companyId,
      });
      const res = NextResponse.json({ success: true });
      res.cookies.set(COOKIE_SESSAO, token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 60 * 60 * 24 * 7,
        path: "/",
      });
      res.cookies.delete("google_pending");
      return res;
    }

    // Sem convite → PENDENTE + avisa os ADMINs por e-mail (Resend)
    const admins = await prisma.user.findMany({
      where: { companyId: cnpjExistente.id, role: "ADMIN", status: "ATIVO" },
      select: { email: true },
    });
    {
      const { subject, html } = emailAguardandoAprovacao({
        nomePessoa: googleData.nome,
        emailPessoa: emailLower,
        empresa: cnpjExistente.nome_empresa,
        link: `${process.env.APP_URL || appUrl}/configuracoes?tab=usuarios`,
        viaGoogle: true,
      });
      // await: sem ele o envio não sai em serverless (a função congela ao responder).
      await enviarEmail({ to: admins.map(a => a.email), subject, html }).catch(() => false);
    }

    const res = NextResponse.json({ success: true, pending: true, message: "Cadastro enviado! Aguarde a aprovação do administrador." });
    res.cookies.delete("google_pending");
    return res;
  }

  try {
    const company = await prisma.company.create({
      data: {
        nome_empresa: nomeEmpresa,
        cnpj_cpf: cnpjCpf,
        users: {
          create: {
            nome: googleData.nome,
            email: googleData.email.toLowerCase(),
            senha: "", // sem senha para usuários OAuth
            role: "ADMIN",
            google_oauth_id: googleData.sub,
            avatar_url: googleData.avatar_url,
          },
        },
      },
      include: { users: true },
    });

    const user = company.users[0];
    const token = await createToken({
      userId: user.id,
      email: user.email,
      nome: user.nome,
      role: user.role,
        roles: (user as { roles?: string[] }).roles ?? [],
      companyId: user.companyId,
    });

    const response = NextResponse.json({ success: true });
    response.cookies.set(COOKIE_SESSAO, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
      path: "/",
    });
    response.cookies.delete("google_pending");
    return response;
  } catch (err) {
    console.error("Erro ao criar empresa via Google:", err);
    return NextResponse.json({ error: "Erro ao criar empresa." }, { status: 500 });
  }
}
