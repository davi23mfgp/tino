import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createToken } from "@/lib/auth";
import bcrypt from "bcryptjs";
import { chaveTentativa, minutosBloqueado, registrarFalha, limparFalhas } from "@/lib/trava-tentativas";
import { COOKIE_2FA, COOKIE_SESSAO } from "@/lib/cookie-sessao"
import { registrar, origem } from "@/lib/vigia";

export async function POST(req: NextRequest) {
  try {
    const { email, senha } = await req.json();

    if (!email || !senha) {
      return NextResponse.json({ error: "E-mail e senha são obrigatórios." }, { status: 400 });
    }

    const k = chaveTentativa(req, email);
    const bloqueio = await minutosBloqueado(k);
    const { ip, userAgent } = origem(req);
    if (bloqueio > 0) {
      await registrar({
        tipo: "LOGIN_BLOQUEADO",
        descricao: `Login barrado por excesso de tentativas (${email})`,
        email, ip, userAgent, rota: "/api/auth/login",
      });
      return NextResponse.json({ error: `Muitas tentativas. Tente novamente em ${bloqueio} min.` }, { status: 429 });
    }

    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
      include: { company: true },
    });

    // Compara sempre, mesmo sem usuário: responder na hora quando o e-mail não
    // existe entrega ao atacante quais endereços estão cadastrados.
    const senhaCorreta = user
      ? await bcrypt.compare(senha, user.senha)
      : await bcrypt.compare(senha, "$2a$12$0000000000000000000000000000000000000000000000000000").catch(() => false);

    if (!user || !senhaCorreta) {
      await registrarFalha(k);
      /* Registra mesmo quando o e-mail não existe: é justamente a tentativa
         contra endereço inventado que revela varredura. */
      await registrar({
        tipo: "LOGIN_FALHA",
        descricao: user ? "Senha incorreta" : "Tentativa com e-mail não cadastrado",
        companyId: user?.companyId ?? null, userId: user?.id ?? null,
        email, ip, userAgent, rota: "/api/auth/login",
      });
      return NextResponse.json({ error: "E-mail ou senha incorretos." }, { status: 401 });
    }

    await limparFalhas(k);
    await registrar({
      tipo: "LOGIN_OK", descricao: `Entrou no sistema (${user.email})`,
      companyId: user.companyId, userId: user.id, email: user.email,
      ip, userAgent, rota: "/api/auth/login",
    });

    if (user.status === "PENDENTE") {
      return NextResponse.json(
        { error: "Seu cadastro aguarda aprovação do administrador da empresa." },
        { status: 403 }
      );
    }
    if (user.status === "DESATIVADO") {
      return NextResponse.json(
        { error: "Conta desativada. Fale com o administrador da empresa." },
        { status: 403 }
      );
    }

    // Troca forçada: senha atual ok, mas ADMIN exigiu redefinição.
    // Front mostra campos de nova senha e chama /api/auth/trocar-senha.
    if (user.must_change_password) {
      return NextResponse.json({ mustChangePassword: true });
    }

    // 2FA: senha ok, mas não emite sessão — cookie temporário (5 min) prova
    // que a senha já foi validada; /api/auth/2fa/verify troca código por sessão.
    if (user.totp_enabled && user.totp_secret) {
      const pending = await createToken({
        userId: user.id, email: user.email, nome: user.nome,
        role: "2FA_PENDING", companyId: user.companyId,
      });
      const resp = NextResponse.json({ twofa: true });
      resp.cookies.set(COOKIE_2FA, pending, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 60 * 5,
        path: "/",
      });
      return resp;
    }

    const token = await createToken({
      userId: user.id,
      email: user.email,
      nome: user.nome,
      role: user.role,
      roles: user.roles ?? [],
      companyId: user.companyId,
    });

    // Log de acesso (entrada) — visível em Suporte → Logs (ADMIN).
    // Precisa de await: em serverless a função congela assim que responde,
    // e um create() solto simplesmente não chega a gravar (por isso os logs
    // apareciam no localhost e não na Vercel).
    await prisma.aiAuditLog.create({
      data: {
        userId: user.id, companyId: user.companyId, tipo_acesso: "LOGIN",
        descricao: `Entrou no sistema (${user.email})`,
      },
    }).catch(() => {});

    const response = NextResponse.json({ success: true, nome: user.nome, role: user.role });
    response.cookies.set(COOKIE_SESSAO, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
      path: "/",
    });

    return response;
  } catch (error) {
    console.error("Erro no login:", error);
    return NextResponse.json({ error: "Erro interno do servidor." }, { status: 500 });
  }
}
