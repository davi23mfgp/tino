import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { verificarCodigoTotp } from "@/lib/totp"

/** POST /api/auth/2fa/disable — desativa o 2FA (exige código atual). */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { codigo } = await req.json().catch(() => ({}))
  const user = await prisma.user.findUnique({ where: { id: session.userId } })
  if (!user?.totp_enabled || !user.totp_secret) {
    return NextResponse.json({ error: "2FA não está ativo." }, { status: 400 })
  }

  const ok = await verificarCodigoTotp(String(codigo ?? ""), user.totp_secret)
  if (!ok) return NextResponse.json({ error: "Código inválido." }, { status: 401 })

  await prisma.user.update({
    where: { id: user.id },
    data: { totp_enabled: false, totp_secret: null },
  })

  await prisma.aiAuditLog.create({
    data: {
      userId: user.id, companyId: user.companyId, tipo_acesso: "DADOS",
      descricao: `2FA desativado (${user.email})`,
    },
  }).catch(() => {})

  return NextResponse.json({ ok: true })
}
