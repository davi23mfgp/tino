import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";
import { enviarEmail } from "@/lib/email";
import { emailAguardandoAprovacao } from "@/lib/email-templates";

export async function POST(req: NextRequest) {
  try {
    const { nomeEmpresa, cnpjCpf, nomeAdmin, email, senha } = await req.json();

    if (!nomeEmpresa || !cnpjCpf || !nomeAdmin || !email || !senha) {
      return NextResponse.json({ error: "Todos os campos são obrigatórios." }, { status: 400 });
    }

    const emailExistente = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
    });

    if (emailExistente) {
      return NextResponse.json({ error: "Este e-mail já está cadastrado." }, { status: 409 });
    }

    const cnpjExistente = await prisma.company.findUnique({
      where: { cnpj_cpf: cnpjCpf },
    });

    const senhaHash = await bcrypt.hash(senha, 12);

    // CNPJ já cadastrado → entra na empresa existente como PENDENTE
    // (o ADMIN aprova e escolhe o perfil em Configurações → Usuários).
    if (cnpjExistente) {
      await prisma.user.create({
        data: {
          nome: nomeAdmin,
          email: email.toLowerCase(),
          senha: senhaHash,
          role: "VENDEDOR",
          status: "PENDENTE",
          companyId: cnpjExistente.id,
        },
      });
      return NextResponse.json(
        { success: true, pending: true, message: "Cadastro enviado! Aguarde a aprovação do administrador da empresa." },
        { status: 201 }
      );
    }

    // Empresa nova: o ADMIN nasce PENDENTE e só entra após o DONO DO SITE
    // autorizar a empresa (login já bloqueia PENDENTE).
    const company = await prisma.company.create({
      data: {
        nome_empresa: nomeEmpresa,
        cnpj_cpf: cnpjCpf,
        users: {
          create: {
            nome: nomeAdmin,
            email: email.toLowerCase(),
            senha: senhaHash,
            role: "ADMIN",
            status: "PENDENTE",
          },
        },
      },
    });

    // Avisa o dono do site (se Resend + e-mail configurados).
    // Com await: em serverless a função congela assim que responde, e um
    // fetch solto simplesmente não chega a sair.
    const owners = (process.env.PLATFORM_OWNER_EMAIL || "").split(",").map(s => s.trim()).filter(Boolean);
    if (owners.length) {
      const { subject, html } = emailAguardandoAprovacao({
        nomePessoa: nomeAdmin,
        emailPessoa: email.toLowerCase(),
        empresa: nomeEmpresa,
        cnpjCpf,
        link: `${process.env.APP_URL || "http://localhost:3000"}/plataforma`,
      });
      await enviarEmail({ to: owners, subject, html }).catch(() => false);
    }

    return NextResponse.json(
      { success: true, pending: true, companyId: company.id, message: "Cadastro enviado! Aguarde a autorização do dono do site para acessar." },
      { status: 201 }
    );
  } catch (error) {
    console.error("Erro no cadastro:", error);
    return NextResponse.json({ error: "Erro interno do servidor." }, { status: 500 });
  }
}
