import { NextResponse } from "next/server";
import { getSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import { COOKIE_SESSAO } from "@/lib/cookie-sessao"

export async function POST() {
  // Log de acesso (saída) — visível em Suporte → Logs (ADMIN)
  const session = await getSession();
  if (session) {
    // await obrigatório: em serverless a função congela ao responder e o
    // create() solto não chega a gravar.
    await prisma.aiAuditLog.create({
      data: {
        userId: session.userId, companyId: session.companyId, tipo_acesso: "LOGOUT",
        descricao: `Saiu do sistema (${session.email})`,
      },
    }).catch(() => {});
  }

  const response = NextResponse.json({ success: true });
  response.cookies.set(COOKIE_SESSAO, "", {
    httpOnly: true,
    expires: new Date(0),
    path: "/",
  });
  return response;
}
