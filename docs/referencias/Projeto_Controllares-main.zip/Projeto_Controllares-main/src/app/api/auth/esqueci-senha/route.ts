import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { generateSecureToken } from "@/lib/crypto"
import { enviarEmail } from "@/lib/email"
import { emailRecuperacaoSenha } from "@/lib/email-templates"
import { chaveTentativa, minutosBloqueado, registrarFalha } from "@/lib/trava-tentativas"
import crypto from "crypto"

export const dynamic = "force-dynamic"

const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex")

/**
 * POST /api/auth/esqueci-senha  { email }
 *
 * Gera um token de redefinição válido por 1h e manda por e-mail o link.
 *
 * Segurança:
 * - Resposta é SEMPRE a mesma (sucesso), exista o e-mail ou não. Assim a rota
 *   não revela quais e-mails têm conta (enumeração).
 * - Guardamos só o HASH do token; o token em claro só vai no e-mail.
 * - Trava anti-abuso por IP+e-mail, para não virar disparador de spam.
 */
export async function POST(req: NextRequest) {
  const { email } = await req.json().catch(() => ({}))
  const resposta = NextResponse.json({
    ok: true,
    message: "Se este e-mail tiver conta, enviamos um link para redefinir a senha.",
  })

  if (!email || typeof email !== "string") return resposta

  const k = chaveTentativa(req, email, "esqueci-senha")
  if (await minutosBloqueado(k) > 0) return resposta // silencioso: não conta pro atacante
  await registrarFalha(k) // toda solicitação conta; 5 em 15 min trancam

  const user = await prisma.user.findUnique({
    where: { email: email.toLowerCase() },
    select: { id: true, nome: true, email: true, status: true, senha: true },
  })
  // Conta inexistente, inativa, ou só-OAuth (sem senha): nada a fazer, mas
  // responde igual.
  if (!user || user.status !== "ATIVO" || !user.senha) return resposta

  const token = generateSecureToken(32)
  await prisma.user.update({
    where: { id: user.id },
    data: {
      reset_token_hash: sha256(token),
      reset_token_expiry: new Date(Date.now() + 60 * 60 * 1000), // 1h
    },
  })

  const base = process.env.APP_URL || process.env.NEXT_PUBLIC_APP_URL || new URL(req.url).origin
  const link = `${base}/redefinir-senha?token=${token}`

  const { subject, html } = emailRecuperacaoSenha({ nome: user.nome, link })
  await enviarEmail({ to: [user.email], subject, html })

  return resposta
}
