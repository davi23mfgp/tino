import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { verificarCodigoTotp } from "@/lib/totp"

/**
 * POST /api/auth/2fa/confirm — valida o primeiro código e ativa o 2FA.
 * POST com { codigo }.
 */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { codigo } = await req.json().catch(() => ({}))
  if (!codigo) return NextResponse.json({ error: "Código obrigatório." }, { status: 400 })

  const user = await prisma.user.findUnique({ where: { id: session.userId } })
  if (!user?.totp_secret) {
    return NextResponse.json({ error: "Setup do 2FA não iniciado." }, { status: 400 })
  }

  const ok = await verificarCodigoTotp(String(codigo), user.totp_secret)
  if (!ok) return NextResponse.json({ error: "Código inválido." }, { status: 401 })

  await prisma.user.update({ where: { id: user.id }, data: { totp_enabled: true } })

  await prisma.aiAuditLog.create({
    data: {
      userId: user.id, companyId: user.companyId, tipo_acesso: "DADOS",
      descricao: `2FA ativado (${user.email})`,
    },
  }).catch(() => {})

  return NextResponse.json({ ok: true })
}
