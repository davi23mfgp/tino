import { NextRequest, NextResponse } from "next/server"
import { get } from "@vercel/blob"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * GET /api/img-proxy?url=<encoded image url>
 * Busca a imagem no servidor (contornando hotlink/CORS/referer) e a devolve.
 * Valida que o conteúdo é realmente uma imagem.
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const url = searchParams.get("url")

  if (!url) {
    return NextResponse.json({ error: "url obrigatória" }, { status: 400 })
  }

  // Quem está pedindo? Usuário logado, ou visitante de um link de proposta
  // válido. Sem uma das duas coisas a rota vira proxy aberto: qualquer pessoa
  // usaria nosso servidor (e o token do Blob) para buscar arquivo.
  const sessao = await getSession().catch(() => null)
  if (!sessao) {
    const token = searchParams.get("p")
    const proposta = token
      ? await prisma.proposal.findUnique({
          where: { link_token: token },
          select: { data_expiracao: true },
        })
      : null
    const expirada = proposta?.data_expiracao ? new Date(proposta.data_expiracao) < new Date() : false
    if (!proposta || expirada) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }
  }

  // Aceita apenas http/https e bloqueia alvos internos (anti-SSRF)
  let target: URL
  try {
    target = new URL(url)
    if (!["http:", "https:"].includes(target.protocol)) throw new Error("protocolo inválido")
    const h = target.hostname.toLowerCase()
    const isPrivate =
      h === "localhost" || h === "0.0.0.0" || h.endsWith(".local") || h.endsWith(".internal") ||
      /^127\./.test(h) || /^10\./.test(h) || /^192\.168\./.test(h) ||
      /^172\.(1[6-9]|2\d|3[01])\./.test(h) || /^169\.254\./.test(h) ||
      h === "::1" || h.startsWith("fd") || h.startsWith("fe80")
    if (isPrivate) throw new Error("host bloqueado")
  } catch {
    return NextResponse.json({ error: "url inválida" }, { status: 400 })
  }

  // Blob privado não sai por GET comum (403 mesmo com Authorization) — só pelo
  // get() do SDK. Numa Store pública o fetch normal resolve, então esse caminho
  // fica como reserva: é tentado só quando o GET direto falha, para não pagar a
  // ida extra em toda imagem. Quem busca é sempre o servidor; o token nunca
  // chega ao navegador.
  const ehBlobVercel = /(^|\.)blob\.vercel-storage\.com$/i.test(target.hostname)
  const blobToken =
    process.env.BLOB_READ_WRITE_TOKEN ||
    Object.entries(process.env).find(([k]) => k.endsWith("_READ_WRITE_TOKEN"))?.[1]

  async function viaBlobPrivado() {
    if (!ehBlobVercel || !blobToken) return null
    try {
      const r = await get(target.toString(), { access: "private", token: blobToken })
      if (r?.statusCode !== 200) return null
      return new NextResponse(r.stream as unknown as BodyInit, {
        status: 200,
        headers: {
          "Content-Type": r.blob.contentType || "application/octet-stream",
          "Cache-Control": "public, max-age=604800, immutable",
        },
      })
    } catch {
      return null
    }
  }

  try {
    const upstream = await fetch(target.toString(), {
      headers: {
        // Simula um navegador real para evitar bloqueio por hotlink
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
        Accept: "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
        Referer: `${target.protocol}//${target.host}/`,
        ...(ehBlobVercel && blobToken ? { Authorization: `Bearer ${blobToken}` } : {}),
      },
      // 10s de timeout via AbortSignal
      signal: AbortSignal.timeout(10000),
    })

    if (!upstream.ok) {
      // Store privada devolve 403 aqui: última chance pelo SDK.
      const viaSdk = await viaBlobPrivado()
      if (viaSdk) return viaSdk
      return NextResponse.json(
        { error: `A origem respondeu ${upstream.status}` },
        { status: 502 }
      )
    }

    const contentType = upstream.headers.get("content-type") ?? ""
    const imgExts = /\.(jpe?g|png|webp|gif|svg|avif|ico|bmp|tiff?)(\?.*)?$/i
    const buffer = await upstream.arrayBuffer()

    /* Decidir só pelo content-type rejeitava imagem boa: servidor mal
       configurado manda vazio, "text/plain" ou "binary/octet-stream", e o .webp
       do fornecedor caía aí. A assinatura do arquivo é o que não mente — os
       primeiros bytes dizem o formato real. */
    const b = new Uint8Array(buffer.slice(0, 12))
    const ehPNG  = b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47
    const ehJPEG = b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff
    const ehGIF  = b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46
    const ehBMP  = b[0] === 0x42 && b[1] === 0x4d
    // RIFF....WEBP  e  ....ftypavif
    const txt = (i: number, n: number) => String.fromCharCode(...b.slice(i, i + n))
    const ehWEBP = txt(0, 4) === "RIFF" && txt(8, 4) === "WEBP"
    const ehAVIF = txt(4, 4) === "ftyp" && txt(8, 3) === "avi"
    const assinaturaDeImagem = ehPNG || ehJPEG || ehGIF || ehBMP || ehWEBP || ehAVIF

    // SVG é texto: não tem assinatura binária, vale pelo tipo ou pela extensão.
    const ehSVG = contentType.includes("svg") || /\.svg(\?.*)?$/i.test(target.pathname)

    /* PDF (planta de projeto) só para quem está logado: as ferramentas de
       Projetos abrem a planta guardada na obra. Pelo link de proposta, não. */
    const ehPDF = !!sessao && txt(0, 4) === "%PDF"

    const aceita = contentType.startsWith("image/")
      || assinaturaDeImagem
      || ehSVG
      || ehPDF
      || imgExts.test(target.pathname)

    if (!aceita) {
      return NextResponse.json(
        { error: `O link não é uma imagem (tipo: ${contentType || "desconhecido"}). Use a URL direta do arquivo de imagem.` },
        { status: 415 }
      )
    }

    /* Devolve o tipo certo mesmo quando a origem erra: o navegador recusa
       renderizar "text/plain" como imagem. */
    const tipoFinal = contentType.startsWith("image/")
      ? contentType
      : ehPNG ? "image/png"
      : ehJPEG ? "image/jpeg"
      : ehGIF ? "image/gif"
      : ehWEBP ? "image/webp"
      : ehAVIF ? "image/avif"
      : ehBMP ? "image/bmp"
      : ehSVG ? "image/svg+xml"
      : ehPDF ? "application/pdf"
      : "application/octet-stream"

    return new NextResponse(buffer, {
      status: 200,
      headers: {
        "Content-Type": tipoFinal,
        // Cache por 7 dias no CDN/browser
        "Cache-Control": "public, max-age=604800, immutable",
      },
    })
  } catch {
    const viaSdk = await viaBlobPrivado()
    if (viaSdk) return viaSdk
    return NextResponse.json(
      { error: "Falha ao buscar a imagem na origem" },
      { status: 502 }
    )
  }
}
