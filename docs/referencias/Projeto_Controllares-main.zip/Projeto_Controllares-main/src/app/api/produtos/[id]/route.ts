import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const body = await req.json()

  const existing = await prisma.catalogProduct.findFirst({
    where: { id, companyId: session.companyId }
  })
  if (!existing) return NextResponse.json({ error: "Produto não encontrado" }, { status: 404 })

  const { sku, nome, nome_cliente, marca, preco_custo, markup_padrao, preco_venda, imagem_url, status, inativo_proposta, ncm, cest, origem, unidade, gtin, aliquota_ipi, cst_pis, aliquota_pis, cst_cofins, aliquota_cofins, cst_icms, aliquota_icms, categoryId, imposto_st, estoque_qtd, estoque_minimo, tipo_aplicacao, formato_medida, largura_mm, altura_mm, profundidade_mm, garantia_dias, especificacoes } = body

  // Se está mudando o SKU, garante que não colide com outro produto da empresa.
  let renomeados = 0
  if (sku !== undefined && sku !== existing.sku) {
    const clash = await prisma.catalogProduct.findFirst({
      where: { companyId: session.companyId, sku, NOT: { id } },
      select: { id: true },
    })
    if (clash) {
      return NextResponse.json({ error: `SKU "${sku}" já está em uso por outro produto.` }, { status: 409 })
    }

    // ── Propagação de prefixo ──
    // Se o SKU mudou de "VELHO-123" para "NOVO-123" (mesmo número) e o produto
    // tem fornecedor, entende-se que o usuário quer trocar o PREFIXO da marca:
    // atualiza o fornecedor e renomeia TODOS os produtos dele mantendo a numeração.
    const mOld = existing.sku.match(/^([A-Z0-9]+)-(\d+)$/i)
    const mNew = String(sku).match(/^([A-Z0-9]+)-(\d+)$/i)
    if (existing.supplierId && mOld && mNew && mOld[2] === mNew[2] && mOld[1].toUpperCase() !== mNew[1].toUpperCase()) {
      const velhoPrefixo = mOld[1].toUpperCase()
      const novoPrefixo = mNew[1].toUpperCase()

      const forn = await prisma.supplier.findFirst({
        where: { id: existing.supplierId, companyId: session.companyId },
      })
      if (forn && forn.prefixo === velhoPrefixo) {
        const irmaos = await prisma.catalogProduct.findMany({
          where: { supplierId: forn.id, companyId: session.companyId, NOT: { id } },
          select: { id: true, sku: true },
        })
        const outros = await prisma.catalogProduct.findMany({
          where: { companyId: session.companyId, NOT: { supplierId: forn.id } },
          select: { sku: true },
        })
        const ocupados = new Set(outros.map(p => p.sku))
        const reOld = new RegExp(`^${velhoPrefixo}-(\\d+)$`, "i")

        const updates: { id: string; sku: string }[] = []
        for (const p of irmaos) {
          const m = p.sku.match(reOld)
          if (!m) continue
          let novoSku = `${novoPrefixo}-${m[1]}`
          if (ocupados.has(novoSku)) {
            let n = parseInt(m[1], 10)
            do { n++; novoSku = `${novoPrefixo}-${String(n).padStart(m[1].length, "0")}` } while (ocupados.has(novoSku))
          }
          ocupados.add(novoSku)
          updates.push({ id: p.id, sku: novoSku })
        }

        await prisma.$transaction([
          prisma.supplier.update({ where: { id: forn.id }, data: { prefixo: novoPrefixo } }),
          ...updates.map((u, i) =>
            prisma.catalogProduct.update({ where: { id: u.id }, data: { sku: `__tmp_${forn.id}_${i}__` } })
          ),
          ...updates.map(u =>
            prisma.catalogProduct.update({ where: { id: u.id }, data: { sku: u.sku } })
          ),
        ])
        renomeados = updates.length
      }
    }
  }

  const updated = await prisma.catalogProduct.update({
    where: { id },
    data: {
      ...(sku !== undefined && { sku }),
      ...(nome !== undefined && { nome }),
      ...(nome_cliente !== undefined && { nome_cliente: nome_cliente || null }),
      ...(marca !== undefined && { marca }),
      ...(preco_custo !== undefined && { preco_custo }),
      ...(markup_padrao !== undefined && { markup_padrao }),
      ...(preco_venda !== undefined && { preco_venda }),
      ...(imposto_st !== undefined && { imposto_st: Number(imposto_st) || 0 }),
      ...(imagem_url !== undefined && { imagem_url }),
      ...(status !== undefined && { status }),
      ...(inativo_proposta !== undefined && { inativo_proposta: !!inativo_proposta }),
      ...(ncm !== undefined && { ncm: ncm || null }),
      ...(cest !== undefined && { cest: cest === '' ? null : cest }),
      ...(origem !== undefined && { origem: origem === '' ? null : origem }),
      ...(unidade !== undefined && { unidade: unidade === '' ? null : unidade }),
      ...(gtin !== undefined && { gtin: gtin === '' ? null : gtin }),
      ...(aliquota_ipi !== undefined && { aliquota_ipi: aliquota_ipi === '' ? null : aliquota_ipi }),
      ...(cst_pis !== undefined && { cst_pis: cst_pis === '' ? null : cst_pis }),
      ...(aliquota_pis !== undefined && { aliquota_pis: aliquota_pis === '' ? null : aliquota_pis }),
      ...(cst_cofins !== undefined && { cst_cofins: cst_cofins === '' ? null : cst_cofins }),
      ...(aliquota_cofins !== undefined && { aliquota_cofins: aliquota_cofins === '' ? null : aliquota_cofins }),
      ...(cst_icms !== undefined && { cst_icms: cst_icms === '' ? null : cst_icms }),
      ...(aliquota_icms !== undefined && { aliquota_icms: aliquota_icms === '' ? null : aliquota_icms }),
      ...(categoryId !== undefined && { categoryId: categoryId || null }),
      ...(estoque_qtd !== undefined && { estoque_qtd: estoque_qtd === null || estoque_qtd === "" ? null : Number(estoque_qtd) }),
      ...(estoque_minimo !== undefined && { estoque_minimo: estoque_minimo === null || estoque_minimo === "" ? null : Number(estoque_minimo) }),
      ...(tipo_aplicacao !== undefined && { tipo_aplicacao: tipo_aplicacao || null }),
      ...(formato_medida !== undefined && { formato_medida: formato_medida || null }),
      ...(largura_mm !== undefined && { largura_mm: largura_mm ?? null }),
      ...(altura_mm !== undefined && { altura_mm: altura_mm ?? null }),
      ...(profundidade_mm !== undefined && { profundidade_mm: profundidade_mm ?? null }),
      ...(garantia_dias !== undefined && { garantia_dias: garantia_dias === null || garantia_dias === "" ? null : Number(garantia_dias) }),
      ...(especificacoes !== undefined && { especificacoes: especificacoes || null }),
    },
    include: { category: { select: { id: true, nome: true } } },
  })

  // Alerta de estoque baixo: dispara quando a quantidade CRUZA o limite
  // (não repete a cada save abaixo do mínimo).
  const min = updated.estoque_minimo
  if (
    min != null && updated.estoque_qtd != null && updated.estoque_qtd <= min &&
    (existing.estoque_qtd == null || existing.estoque_qtd > min)
  ) {
    await prisma.webhookDebugLog.create({
      data: {
        companyId: session.companyId,
        endpoint: "internal/estoque-baixo",
        payload_json: { numero: updated.sku, client_name: `${updated.nome} — restam ${updated.estoque_qtd}` },
        reenviado: false,
      },
    }).catch(() => {})
  }

  return NextResponse.json({ ...updated, renomeados })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params

  const existing = await prisma.catalogProduct.findFirst({
    where: { id, companyId: session.companyId }
  })
  if (!existing) return NextResponse.json({ error: "Produto não encontrado" }, { status: 404 })

  await prisma.catalogProduct.delete({ where: { id } })

  return NextResponse.json({ success: true })
}
