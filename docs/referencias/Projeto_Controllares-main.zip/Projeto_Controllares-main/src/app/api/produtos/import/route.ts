import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/* A planilha importa o CADASTRO INTEIRO.

   Entravam seis colunas, e o resto — ficha técnica, medidas, fiscal, estoque,
   garantia — era digitado produto a produto depois. Com mais de mil itens isso
   é trabalho que não termina: quem já tem a informação na planilha do
   fornecedor precisa subir tudo de uma vez.

   Campo ausente na planilha fica NULO no cadastro. Nada é preenchido por
   dedução: NCM ou origem errados viram nota recusada, e medida chutada vira
   caixa que não fecha. */
interface LinhaImport {
  sku?: string
  nome?: string
  nome_cliente?: string
  marca?: string
  unidade?: string
  categoria?: string
  descricao?: string
  especificacoes?: string
  preco_custo?: number | string
  markup_padrao?: number | string
  preco_venda?: number | string
  imposto_st?: number | string
  desconto_padrao?: number | string
  ncm?: string
  cest?: string
  origem?: string
  gtin?: string
  cst_icms?: string
  aliquota_icms?: number | string
  aliquota_ipi?: number | string
  cst_pis?: string
  aliquota_pis?: number | string
  cst_cofins?: string
  aliquota_cofins?: number | string
  peso_kg?: number | string
  largura_mm?: number | string
  altura_mm?: number | string
  profundidade_mm?: number | string
  medidas_raw?: string
  ficha_fonte_url?: string
  tipo_aplicacao?: string
  formato_medida?: string
  garantia_dias?: number | string
  estoque_qtd?: number | string
  estoque_minimo?: number | string
  imagem_url?: string
}

/** Texto que não veio na planilha vira null, e não string vazia: o cadastro
    distingue "sem informação" de "informação em branco". */
const txt = (v: unknown): string | null => {
  const t = (v ?? "").toString().trim()
  return t || null
}

/** Número opcional: coluna vazia continua vazia, não vira zero. Zero em peso
    ou alíquota é uma afirmação — "não tem" — e não é o que a planilha disse. */
const numOpc = (v: unknown): number | null => {
  const t = (v ?? "").toString().trim()
  if (!t) return null
  const n = num(t)
  return Number.isFinite(n) ? n : null
}

const intOpc = (v: unknown): number | null => {
  const n = numOpc(v)
  return n == null ? null : Math.round(n)
}

function num(v: unknown): number {
  if (typeof v === "number") return v
  if (typeof v === "string") {
    // aceita "1.234,56" e "1234.56"
    const limpo = v.replace(/\s/g, "").replace(/\.(?=\d{3}(\D|$))/g, "").replace(",", ".")
    const n = parseFloat(limpo)
    return isNaN(n) ? 0 : n
  }
  return 0
}

/** Gera um prefixo de SKU a partir do nome (ex: "Control4" -> "CTRL"). */
function gerarPrefixo(nome: string): string {
  const limpo = nome.toUpperCase().replace(/[^A-Z0-9]/g, "")
  return limpo.slice(0, 4) || "FORN"
}

/**
 * POST /api/produtos/import
 * { supplierId?, linhas: [{ nome, marca?, preco_custo, markup_padrao?, preco_venda?, imagem_url?, sku? }] }
 *
 * Para cada linha, resolve o fornecedor pela MARCA:
 *  - se a marca casa com um fornecedor existente -> usa ele (e seu prefixo)
 *  - se a marca é nova -> cria o fornecedor automaticamente (nome=marca, prefixo derivado)
 *  - se não há marca -> usa o supplierId global (se enviado) ou prefixo genérico "SKU"
 * Gera SKUs sequenciais por prefixo, únicos na empresa, respeitando SKUs informados.
 */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const body = await req.json()
  const supplierIdGlobal: string | null = body.supplierId || null
  const linhas: LinhaImport[] = Array.isArray(body.linhas) ? body.linhas : []

  if (linhas.length === 0) return NextResponse.json({ error: "Nenhuma linha para importar" }, { status: 400 })

  // ── Fornecedores existentes (map por nome minúsculo) ──
  const fornecedores = await prisma.supplier.findMany({
    where: { companyId: session.companyId },
    select: { id: true, nome: true, prefixo: true },
  })
  const porNome = new Map<string, { id: string; prefixo: string }>()
  const prefixosUsados = new Set<string>()
  for (const f of fornecedores) {
    porNome.set(f.nome.toLowerCase(), { id: f.id, prefixo: f.prefixo })
    prefixosUsados.add(f.prefixo)
  }

  // Fornecedor global (quando a linha não tem marca)
  let globalPrefixo = "SKU"
  let globalMarca: string | null = null
  if (supplierIdGlobal) {
    const forn = fornecedores.find(f => f.id === supplierIdGlobal)
      ?? await prisma.supplier.findFirst({ where: { id: supplierIdGlobal, companyId: session.companyId }, select: { id: true, nome: true, prefixo: true } })
    if (!forn) return NextResponse.json({ error: "Fornecedor não encontrado" }, { status: 404 })
    globalPrefixo = forn.prefixo
    globalMarca = forn.nome
  }

  // ── SKUs já usados (unicidade global) ──
  const existentes = await prisma.catalogProduct.findMany({
    where: { companyId: session.companyId },
    select: { sku: true },
  })
  const usados = new Set(existentes.map(p => p.sku))

  // Contador por prefixo, inicializado pelo maior número já existente.
  const contadores = new Map<string, number>()
  function initContador(prefixo: string) {
    if (contadores.has(prefixo)) return
    let maior = 0
    const re = new RegExp(`^${prefixo}-(\\d+)$`)
    for (const s of usados) {
      const m = s.match(re)
      if (m) maior = Math.max(maior, parseInt(m[1], 10))
    }
    contadores.set(prefixo, maior)
  }
  function proximoSku(prefixo: string): string {
    initContador(prefixo)
    let n = (contadores.get(prefixo) ?? 0) + 1
    let sku = `${prefixo}-${String(n).padStart(3, "0")}`
    while (usados.has(sku)) {
      n++
      sku = `${prefixo}-${String(n).padStart(3, "0")}`
    }
    contadores.set(prefixo, n)
    usados.add(sku)
    return sku
  }

  // Gera um prefixo único entre os fornecedores (evita dois fornecedores com o mesmo).
  function prefixoUnico(base: string): string {
    let p = base
    let i = 2
    while (prefixosUsados.has(p)) {
      p = `${base}${i}`
      i++
    }
    prefixosUsados.add(p)
    return p
  }

  // Fornecedores a criar nesta importação (nome minúsculo -> dados)
  const novosFornecedores: { nome: string; prefixo: string }[] = []
  function resolverFornecedor(marca: string): { prefixo: string; marcaNome: string; novo: boolean } {
    const chave = marca.toLowerCase()
    const existente = porNome.get(chave)
    if (existente) return { prefixo: existente.prefixo, marcaNome: marca, novo: false }
    // cria novo
    const prefixo = prefixoUnico(gerarPrefixo(marca))
    porNome.set(chave, { id: "", prefixo }) // id preenchido depois
    novosFornecedores.push({ nome: marca, prefixo })
    return { prefixo, marcaNome: marca, novo: true }
  }

  // ── Monta os produtos ──
  interface ProdTmp {
    sku: string; nome: string; marca: string | null
    preco_custo: number; markup_padrao: number; preco_venda: number
    imagem_url: string | null; marcaChave: string | null
    companyId: string
    /* A linha crua segue junto: os campos de cadastro são copiados na hora de
       montar o `createMany`, um lugar só, em vez de repetir trinta atribuições
       aqui e lá. */
    linha: LinhaImport
  }
  const prods: ProdTmp[] = []
  const ajustadas: string[] = []
  const fornecedoresCriados = new Set<string>()

  for (const linha of linhas) {
    const nome = (linha.nome ?? "").toString().trim()
    if (!nome) continue

    const marca = (linha.marca ?? "").toString().trim()

    let prefixo: string
    let marcaNome: string | null
    let marcaChave: string | null = null
    if (marca) {
      const r = resolverFornecedor(marca)
      prefixo = r.prefixo
      marcaNome = r.marcaNome
      marcaChave = marca.toLowerCase()
      if (r.novo) fornecedoresCriados.add(marca)
    } else {
      prefixo = globalPrefixo
      marcaNome = globalMarca
    }

    // SKU: usa o informado se livre; senão gera pelo prefixo do fornecedor.
    let sku = (linha.sku ?? "").toString().trim()
    if (sku) {
      if (usados.has(sku)) {
        const novo = proximoSku(prefixo)
        ajustadas.push(`${nome}: SKU "${sku}" já existia → usado "${novo}"`)
        sku = novo
      } else {
        usados.add(sku)
      }
    } else {
      sku = proximoSku(prefixo)
    }

    const custo = num(linha.preco_custo)
    const markup = num(linha.markup_padrao)
    const venda = linha.preco_venda != null && linha.preco_venda !== ""
      ? num(linha.preco_venda)
      : custo * (1 + markup / 100)

    prods.push({
      sku, nome, marca: marcaNome,
      preco_custo: custo, markup_padrao: markup, preco_venda: venda,
      imagem_url: linha.imagem_url?.toString().trim() || null,
      marcaChave,
      companyId: session.companyId,
      linha,
    })
  }

  if (prods.length === 0) {
    return NextResponse.json({ error: "Nenhuma linha válida (faltou nome)." }, { status: 400 })
  }

  /* Categoria vem por NOME na planilha e vira id aqui. Categoria que não
     existe é ignorada em vez de criada: a lista de categorias organiza a
     proposta inteira, e deixar a planilha inventar categoria enche o sistema
     de "Rede", "REDE " e "Redes" que ninguém consegue mais juntar. */
  const categorias = await prisma.category.findMany({
    where: { companyId: session.companyId },
    select: { id: true, nome: true },
  })
  const semAcento = (t: string) =>
    t.normalize("NFD").replace(/[̀-ͯ]/g, "").trim().toLowerCase()
  const catPorNome = new Map(categorias.map(c => [semAcento(c.nome), c.id]))
  const categoriasDesconhecidas = new Set<string>()

  // ── Cria os novos fornecedores e mapeia nome->id ──
  for (const nf of novosFornecedores) {
    const criado = await prisma.supplier.create({
      data: { nome: nf.nome, prefixo: nf.prefixo, companyId: session.companyId },
      select: { id: true, nome: true },
    })
    porNome.set(criado.nome.toLowerCase(), { id: criado.id, prefixo: nf.prefixo })
  }

  // ── Cria os produtos, ligando ao supplier pela marca ──
  const data = prods.map(p => {
    const l = p.linha
    const nomeCat = txt(l.categoria)
    const categoryId = nomeCat ? catPorNome.get(semAcento(nomeCat)) ?? null : null
    if (nomeCat && !categoryId) categoriasDesconhecidas.add(nomeCat)

    /* Ficha só é dada por ENCONTRADA quando veio com fonte. Sem a URL de
       origem não há como conferir se a descrição é deste produto ou de um
       parecido — é a mesma regra do enriquecimento feito fora daqui. */
    const temFicha = !!(txt(l.especificacoes) && txt(l.ficha_fonte_url))

    return {
      sku: p.sku,
      nome: p.nome,
      nome_cliente: txt(l.nome_cliente),
      marca: p.marca,
      unidade: txt(l.unidade),
      descricao: txt(l.descricao),
      especificacoes: txt(l.especificacoes),
      preco_custo: p.preco_custo,
      markup_padrao: p.markup_padrao,
      preco_venda: p.preco_venda,
      ...(numOpc(l.imposto_st) != null && { imposto_st: numOpc(l.imposto_st)! }),
      ...(numOpc(l.desconto_padrao) != null && { desconto_padrao: numOpc(l.desconto_padrao)! }),
      ncm: txt(l.ncm),
      cest: txt(l.cest),
      origem: txt(l.origem),
      gtin: txt(l.gtin),
      cst_icms: txt(l.cst_icms),
      aliquota_icms: numOpc(l.aliquota_icms),
      aliquota_ipi: numOpc(l.aliquota_ipi),
      cst_pis: txt(l.cst_pis),
      aliquota_pis: numOpc(l.aliquota_pis),
      cst_cofins: txt(l.cst_cofins),
      aliquota_cofins: numOpc(l.aliquota_cofins),
      peso_kg: numOpc(l.peso_kg),
      largura_mm: numOpc(l.largura_mm),
      altura_mm: numOpc(l.altura_mm),
      profundidade_mm: numOpc(l.profundidade_mm),
      medidas_raw: txt(l.medidas_raw),
      ficha_fonte_url: txt(l.ficha_fonte_url),
      ficha_status: temFicha ? "ENCONTRADA" : "PENDENTE",
      ficha_buscada_em: temFicha ? new Date() : null,
      tipo_aplicacao: txt(l.tipo_aplicacao),
      formato_medida: txt(l.formato_medida),
      garantia_dias: intOpc(l.garantia_dias),
      estoque_qtd: intOpc(l.estoque_qtd),
      estoque_minimo: intOpc(l.estoque_minimo),
      imagem_url: p.imagem_url,
      categoryId,
      supplierId: p.marcaChave ? (porNome.get(p.marcaChave)?.id || null) : (supplierIdGlobal || null),
      companyId: p.companyId,
    }
  })

  await prisma.catalogProduct.createMany({ data })

  return NextResponse.json({
    criados: data.length,
    ignoradas: [] as string[],
    /* Categoria escrita diferente da cadastrada é silenciosa por natureza: o
       produto entra sem categoria e ninguém percebe até faltar na proposta. */
    ajustadas: [
      ...ajustadas,
      ...[...categoriasDesconhecidas].map(c =>
        `Categoria "${c}" não existe no sistema — os produtos dela entraram sem categoria.`),
    ],
    fornecedoresCriados: [...fornecedoresCriados],
  })
}
