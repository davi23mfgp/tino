import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * Componentes ocultos de um produto composto (Bloco 4).
 * GET    — lista os componentes vinculados ao produto [id].
 * POST   — { componenteId, quantidade } vincula um item como componente.
 * DELETE — ?componenteId= remove o vínculo.
 * O valor de venda do principal já cobre os componentes; internamente
 * (custo/estoque/relatório) cada componente aparece individualmente.
 */

async function donoDoProduto(id: string, companyId: string) {
  return prisma.catalogProduct.findFirst({ where: { id, companyId }, select: { id: true } })
}

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!(await donoDoProduto(id, session.companyId))) {
    return NextResponse.json({ error: "Produto não encontrado" }, { status: 404 })
  }

  const componentes = await prisma.productComponent.findMany({
    where: { produtoId: id },
    include: { componente: { select: { id: true, nome: true, sku: true, preco_custo: true, inativo_proposta: true } } },
  })

  const total_custo = componentes.reduce(
    (s, c) => s + Number(c.componente.preco_custo) * c.quantidade, 0
  )

  return NextResponse.json({
    componentes: componentes.map(c => ({
      id: c.id,
      componenteId: c.componenteId,
      quantidade: c.quantidade,
      nome: c.componente.nome,
      sku: c.componente.sku,
      preco_custo: Number(c.componente.preco_custo),
      inativo_proposta: c.componente.inativo_proposta,
    })),
    total_custo,
  })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!(await donoDoProduto(id, session.companyId))) {
    return NextResponse.json({ error: "Produto não encontrado" }, { status: 404 })
  }

  const { componenteId, quantidade } = await req.json()
  if (!componenteId) return NextResponse.json({ error: "Informe o componente" }, { status: 400 })
  if (componenteId === id) return NextResponse.json({ error: "Um produto não pode ser componente de si mesmo" }, { status: 400 })

  const comp = await prisma.catalogProduct.findFirst({ where: { id: componenteId, companyId: session.companyId }, select: { id: true } })
  if (!comp) return NextResponse.json({ error: "Componente não encontrado" }, { status: 404 })

  const criado = await prisma.productComponent.upsert({
    where: { produtoId_componenteId: { produtoId: id, componenteId } },
    update: { quantidade: Math.max(1, Number(quantidade) || 1) },
    create: { produtoId: id, componenteId, quantidade: Math.max(1, Number(quantidade) || 1) },
  })
  return NextResponse.json({ ok: true, id: criado.id }, { status: 201 })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!(await donoDoProduto(id, session.companyId))) {
    return NextResponse.json({ error: "Produto não encontrado" }, { status: 404 })
  }

  const componenteId = new URL(req.url).searchParams.get("componenteId")
  if (!componenteId) return NextResponse.json({ error: "componenteId obrigatório" }, { status: 400 })

  await prisma.productComponent.deleteMany({ where: { produtoId: id, componenteId } })
  return NextResponse.json({ ok: true })
}
