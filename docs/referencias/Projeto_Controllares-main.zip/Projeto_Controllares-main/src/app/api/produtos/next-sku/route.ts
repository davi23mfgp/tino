import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * GET /api/produtos/next-sku?supplierId=...
 * Retorna o próximo SKU sequencial e único para o fornecedor (ex: CTRL-001).
 */
export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const supplierId = searchParams.get("supplierId")
  if (!supplierId) return NextResponse.json({ error: "supplierId obrigatório" }, { status: 400 })

  const fornecedor = await prisma.supplier.findFirst({ where: { id: supplierId, companyId: session.companyId } })
  if (!fornecedor) return NextResponse.json({ error: "Fornecedor não encontrado" }, { status: 404 })

  const prefixo = fornecedor.prefixo

  // Busca todos os SKUs já usados com esse prefixo para achar o maior número.
  const produtos = await prisma.catalogProduct.findMany({
    where: { companyId: session.companyId, sku: { startsWith: `${prefixo}-` } },
    select: { sku: true },
  })

  let maior = 0
  for (const p of produtos) {
    const m = p.sku.match(new RegExp(`^${prefixo}-(\\d+)$`))
    if (m) maior = Math.max(maior, parseInt(m[1], 10))
  }

  // Garante unicidade mesmo se houver buracos/colisões.
  const usados = new Set(produtos.map(p => p.sku))
  let proximo = maior + 1
  let sku = `${prefixo}-${String(proximo).padStart(3, "0")}`
  while (usados.has(sku)) {
    proximo++
    sku = `${prefixo}-${String(proximo).padStart(3, "0")}`
  }

  return NextResponse.json({ sku, prefixo, marca: fornecedor.nome })
}
