import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const search = searchParams.get("search") || ""
  const page = parseInt(searchParams.get("page") || "1")
  const limit = parseInt(searchParams.get("limit") || "20")
  const categoryId = searchParams.get("categoryId") || ""
  const supplierId = searchParams.get("supplierId") || ""
  const nivel = searchParams.get("nivel") || ""
  const skip = (page - 1) * limit

  /* Ordenação no banco, não na página. Ordenar só o que já veio dava a
     impressão de estar ordenado: crescente por SKU mostrava o menor DA PÁGINA,
     não o menor do catálogo — e a página 2 recomeçava de outro ponto. */
  const COLUNAS = ["sku", "nome", "marca", "preco_venda", "createdAt"] as const
  const pedida = searchParams.get("sort") || ""
  const coluna = (COLUNAS as readonly string[]).includes(pedida) ? pedida : "createdAt"
  const direcao = searchParams.get("dir") === "desc" ? "desc" : "asc"
  const orderBy = coluna === "createdAt"
    ? { createdAt: "desc" as const }
    : { [coluna]: direcao } as Record<string, "asc" | "desc">

  // Filtro de disponibilidade (funciona sobre TODO o catálogo, não só a página)
  // Proposta = aparece na proposta (toggle Proposta ON). Geral = ativo no geral (toggle Geral ON).
  const nivelWhere =
    nivel === "INATIVO_GERAL" ? { status: "ATIVO" as const }          // "Geral": ativos no geral
      : nivel === "INATIVO_PROPOSTA" ? { inativo_proposta: false }     // "Proposta": disponíveis na proposta
      : nivel === "ATIVO" ? { status: "ATIVO" as const, inativo_proposta: false }
      : {}

  const where = {
    companyId: session.companyId,
    ...(categoryId ? { categoryId } : {}),
    ...(supplierId ? { supplierId } : {}),
    ...nivelWhere,
    ...(search ? {
      OR: [
        { nome: { contains: search, mode: "insensitive" as const } },
        { sku: { contains: search, mode: "insensitive" as const } },
        { marca: { contains: search, mode: "insensitive" as const } },
      ]
    } : {})
  }

  const [products, total, ativos] = await Promise.all([
    prisma.catalogProduct.findMany({
      where, skip, take: limit, orderBy,
      include: {
        category: { select: { id: true, nome: true } },
        supplier: { select: { id: true, nome: true } },
        componentes: { include: { componente: { select: { preco_custo: true, preco_venda: true } } } },
      },
    }),
    prisma.catalogProduct.count({ where }),
    /* Contagem de ativos do FILTRO INTEIRO, não da página.
       A tela do catálogo contava `products.filter(...)`, que é só a página
       carregada: com 100 itens por página aparecia "100 ativos" e "1195
       inativos" num catálogo onde 1294 estão ativos. Quem olhasse o painel
       concluiria que o catálogo tinha sido desativado. */
    prisma.catalogProduct.count({ where: { ...where, status: "ATIVO" } }),
  ])

  // Produto composto: soma custo/venda dos componentes ocultos para os cálculos internos.
  const enriched = products.map(p => {
    const custo_componentes = p.componentes.reduce((s, c) => s + Number(c.componente.preco_custo) * c.quantidade, 0)
    const venda_componentes = p.componentes.reduce((s, c) => s + Number(c.componente.preco_venda) * c.quantidade, 0)
    const { componentes: _c, ...rest } = p
    return { ...rest, custo_componentes, venda_componentes, tem_componentes: p.componentes.length > 0 }
  })

  return NextResponse.json({ products: enriched, total, ativos, pages: Math.ceil(total / limit) })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const body = await req.json()
  const { sku, nome, marca, preco_custo, markup_padrao, preco_venda, imagem_url, categoryId, supplierId, estoque_qtd, estoque_minimo, ncm, cest, origem, unidade, gtin, aliquota_ipi, cst_pis, aliquota_pis, cst_cofins, aliquota_cofins, cst_icms, aliquota_icms, tipo_aplicacao, formato_medida, largura_mm, altura_mm, profundidade_mm, garantia_dias, especificacoes } = body

  if (!sku || !nome || !preco_custo) {
    return NextResponse.json({ error: "SKU, nome e preço de custo são obrigatórios" }, { status: 400 })
  }

  // Se veio fornecedor e não veio marca, usa o nome do fornecedor como marca.
  let marcaFinal = marca
  if (supplierId && !marca) {
    const forn = await prisma.supplier.findFirst({ where: { id: supplierId, companyId: session.companyId } })
    if (forn) marcaFinal = forn.nome
  }

  // SKU duplicado? avisa de forma clara.
  const dup = await prisma.catalogProduct.findFirst({ where: { companyId: session.companyId, sku } })
  if (dup) return NextResponse.json({ error: `Já existe um produto com o SKU "${sku}".` }, { status: 409 })

  const product = await prisma.catalogProduct.create({
    data: {
      sku, nome, marca: marcaFinal,
      preco_custo,
      markup_padrao: markup_padrao || 0,
      preco_venda: preco_venda || preco_custo * (1 + (markup_padrao || 0) / 100),
      imagem_url,
      categoryId: categoryId || null,
      supplierId: supplierId || null,
      estoque_qtd: estoque_qtd != null && estoque_qtd !== "" ? Number(estoque_qtd) : null,
      estoque_minimo: estoque_minimo != null && estoque_minimo !== "" ? Number(estoque_minimo) : null,
      ncm: ncm || null,
      cest: cest === '' || cest === undefined ? null : cest,
      origem: origem === '' || origem === undefined ? null : origem,
      unidade: unidade === '' || unidade === undefined ? null : unidade,
      gtin: gtin === '' || gtin === undefined ? null : gtin,
      aliquota_ipi: aliquota_ipi === '' || aliquota_ipi === undefined ? null : aliquota_ipi,
      cst_pis: cst_pis === '' || cst_pis === undefined ? null : cst_pis,
      aliquota_pis: aliquota_pis === '' || aliquota_pis === undefined ? null : aliquota_pis,
      cst_cofins: cst_cofins === '' || cst_cofins === undefined ? null : cst_cofins,
      aliquota_cofins: aliquota_cofins === '' || aliquota_cofins === undefined ? null : aliquota_cofins,
      cst_icms: cst_icms === '' || cst_icms === undefined ? null : cst_icms,
      aliquota_icms: aliquota_icms === '' || aliquota_icms === undefined ? null : aliquota_icms,
      tipo_aplicacao: tipo_aplicacao || null,
      formato_medida: formato_medida || null,
      largura_mm: largura_mm ?? null,
      altura_mm: altura_mm ?? null,
      profundidade_mm: profundidade_mm ?? null,
      garantia_dias: garantia_dias != null && garantia_dias !== "" ? Number(garantia_dias) : null,
      especificacoes: especificacoes || null,
      companyId: session.companyId,
    },
    include: { category: { select: { id: true, nome: true } } },
  })

  return NextResponse.json(product, { status: 201 })
}
