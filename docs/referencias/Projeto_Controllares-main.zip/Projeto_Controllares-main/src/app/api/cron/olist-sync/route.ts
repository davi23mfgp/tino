import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { syncOlist } from "@/lib/olist-sync"

/**
 * GET /api/cron/olist-sync
 * Job de sincronização periódica (rode a cada 15 min por um agendador externo).
 * Protegido pelo header "Authorization: Bearer <CRON_SECRET>" do .env.
 * Sincroniza TODAS as empresas que têm o Olist conectado.
 */
export async function GET(req: NextRequest) {
  const secret = process.env.CRON_SECRET
  const auth = req.headers.get("authorization")
  if (!secret || auth !== `Bearer ${secret}`) {
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  }

  const empresas = await prisma.company.findMany({
    where: { olist_access_token: { not: null } },
    select: { id: true },
  })

  const resultados: Record<string, unknown> = {}
  for (const e of empresas) {
    try {
      resultados[e.id] = await syncOlist(e.id)
    } catch (err) {
      resultados[e.id] = { erro: err instanceof Error ? err.message : "erro" }
    }
  }

  return NextResponse.json({ success: true, empresas: empresas.length, resultados })
}
