import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { sincronizarPlaud } from "@/lib/plaud-sync"

export const dynamic = "force-dynamic"
export const maxDuration = 60

/**
 * Busca periódica das gravações.
 *
 * Existe porque o Plaud não avisa quando há gravação nova — não há webhook a
 * assinar. Roda para todas as empresas conectadas; quem nunca conectou é
 * ignorado sem custo.
 *
 * O intervalo curto não é desperdício: a proposta montada é o que o vendedor
 * quer ver logo depois de sair do cliente, e cada rodada custa uma listagem.
 */
export async function GET(req: NextRequest) {
  /* Cron da Vercel manda um segredo; sem ele, qualquer um dispararia a busca
     de todas as empresas de fora. */
  const esperado = process.env.CRON_SECRET
  if (esperado) {
    const auth = req.headers.get("authorization")
    if (auth !== `Bearer ${esperado}`) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }
  }

  const empresas = await prisma.company.findMany({
    where: { plaud_access_token: { not: null } },
    select: { id: true, nome_empresa: true },
  })

  const resultados: Record<string, unknown> = {}
  for (const e of empresas) {
    resultados[e.nome_empresa ?? e.id] = await sincronizarPlaud(e.id, { forcar: true })
  }

  return NextResponse.json({ empresas: empresas.length, resultados })
}
