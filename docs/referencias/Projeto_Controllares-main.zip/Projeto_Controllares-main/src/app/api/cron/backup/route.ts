import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { gerarBackup, limparBackupsAntigos } from "@/lib/backup"
import { sincronizarConhecimento } from "@/lib/ai/conhecimento-drive"

/**
 * GET /api/cron/backup — snapshot diário de todas as empresas.
 * Protegido pelo header "Authorization: Bearer <CRON_SECRET>".
 * Guarda os últimos 30 snapshots por empresa.
 */
export async function GET(req: NextRequest) {
  const secret = process.env.CRON_SECRET
  const auth = req.headers.get("authorization")
  if (!secret || auth !== `Bearer ${secret}`) {
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  }

  const empresas = await prisma.company.findMany({
    select: { id: true, nome_empresa: true, drive_conhecimento_id: true },
  })
  const resultados: { empresa: string; ok: boolean; detalhe: string }[] = []
  const conhecimento: { empresa: string; detalhe: string }[] = []

  for (const e of empresas) {
    try {
      const snap = await gerarBackup(e.id, "AUTO")
      const removidos = await limparBackupsAntigos(e.id, 30)
      resultados.push({
        empresa: e.nome_empresa,
        ok: !snap.erro,
        detalhe: snap.erro ?? `${Math.round(snap.tamanho_bytes / 1024)} KB, ${removidos} antigo(s) removido(s)`,
      })
    } catch (err) {
      // Uma empresa com problema não pode impedir o backup das outras.
      resultados.push({
        empresa: e.nome_empresa,
        ok: false,
        detalhe: err instanceof Error ? err.message : "falha desconhecida",
      })
    }
  }

  /* A base de conhecimento entra na mesma rotina do backup, e não num cron
     próprio: o plano permite poucas execuções agendadas, e as duas tarefas
     querem a mesma coisa — rodar uma vez por dia, de madrugada, sem ninguém
     olhando. Arquivo que não mudou no Drive é ignorado, então o custo de rodar
     junto é quase nada. */
  for (const e of empresas) {
    if (!e.drive_conhecimento_id) continue
    try {
      const s = await sincronizarConhecimento(e.id)
      conhecimento.push({
        empresa: e.nome_empresa,
        detalhe: `${s.indexados} novo(s), ${s.atualizados} atualizado(s),`
          + ` ${s.removidos} removido(s), ${s.erros.length} com erro`,
      })
    } catch (err) {
      conhecimento.push({
        empresa: e.nome_empresa,
        detalhe: err instanceof Error ? err.message : "falha na sincronização",
      })
    }
  }

  return NextResponse.json({
    executadoEm: new Date().toISOString(), resultados, conhecimento,
  })
}
