import { NextRequest, NextResponse } from "next/server"
import bcrypt from "bcryptjs"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * GET  /api/admin/senhas-core          → lista usuários com status das senhas CORE
 * PATCH /api/admin/senhas-core         → define/bloqueia senha de um usuário
 *   body: { userId, tipo, nova_senha?, bloqueada? }
 *   tipo = "operacional" | "financeiro"
 * Exclusivo para ADMIN.
 */

export async function GET() {
  const session = await getSession()
  if (!session || session.role !== "ADMIN") return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const users = await prisma.user.findMany({
    where: { companyId: session.companyId },
    select: {
      id: true, nome: true, email: true, role: true,
      senha_op_bloqueada: true, senha_fin_bloqueada: true,
      senha_op_hash: true,  // só para saber se foi definida (não revelar)
      senha_fin_hash: true,
    },
    orderBy: { nome: "asc" },
  })

  return NextResponse.json(users.map(u => ({
    id: u.id, nome: u.nome, email: u.email, role: u.role,
    op_definida: !!u.senha_op_hash,
    op_bloqueada: u.senha_op_bloqueada,
    fin_definida: !!u.senha_fin_hash,
    fin_bloqueada: u.senha_fin_bloqueada,
  })))
}

export async function PATCH(req: NextRequest) {
  const session = await getSession()
  if (!session || session.role !== "ADMIN") return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { userId, tipo, nova_senha, bloqueada } = await req.json().catch(() => ({}))
  if (!userId || !tipo || !["operacional", "financeiro"].includes(tipo)) {
    return NextResponse.json({ error: "userId e tipo (operacional|financeiro) são obrigatórios." }, { status: 400 })
  }

  // Garante que o usuário pertence à empresa do admin
  const user = await prisma.user.findFirst({ where: { id: userId, companyId: session.companyId } })
  if (!user) return NextResponse.json({ error: "Usuário não encontrado." }, { status: 404 })

  const update: Record<string, unknown> = {}

  if (nova_senha !== undefined && nova_senha !== "") {
    const hash = await bcrypt.hash(nova_senha, 12)
    if (tipo === "operacional") update.senha_op_hash = hash
    else update.senha_fin_hash = hash
  }

  if (bloqueada !== undefined) {
    if (tipo === "operacional") update.senha_op_bloqueada = Boolean(bloqueada)
    else update.senha_fin_bloqueada = Boolean(bloqueada)
  }

  if (Object.keys(update).length === 0) {
    return NextResponse.json({ error: "Nada para atualizar." }, { status: 400 })
  }

  await prisma.user.update({ where: { id: userId }, data: update })

  // Auditoria
  const acao = nova_senha ? "definiu senha" : (bloqueada ? "bloqueou" : "desbloqueou")
  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "ADMIN",
      descricao: `Admin ${session.nome} ${acao} senha ${tipo} do usuário ${user.nome}`.slice(0, 480),
    },
  })

  return NextResponse.json({ ok: true })
}
