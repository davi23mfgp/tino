import { NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * GET /api/admin/overview — visão geral de controle do ADMIN:
 * números de atividade, integrações da empresa e contas vinculadas por usuário.
 */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (session.role !== "ADMIN") return NextResponse.json({ error: "Sem permissão" }, { status: 403 })

  const cid = session.companyId
  const hoje = new Date(); hoje.setHours(0, 0, 0, 0)
  const semana = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)

  const [company, usuarios, loginsHoje, loginsSemana, cofreSemana, eventosSemana, ultimos] = await Promise.all([
    prisma.company.findUnique({
      where: { id: cid },
      select: {
        google_client_id: true, google_client_secret: true,
        telegram_bot_token: true, tiny_api_token: true,
        olist_access_token: true, vault_passwords: true,
      },
    }),
    prisma.user.findMany({
      where: { companyId: cid },
      orderBy: { createdAt: "asc" },
      select: {
        id: true, nome: true, email: true, role: true, status: true,
        totp_enabled: true, google_oauth_id: true, google_access_token: true,
        createdAt: true,
      },
    }),
    prisma.aiAuditLog.count({ where: { companyId: cid, tipo_acesso: "LOGIN", timestamp: { gte: hoje } } }),
    prisma.aiAuditLog.count({ where: { companyId: cid, tipo_acesso: "LOGIN", timestamp: { gte: semana } } }),
    prisma.aiAuditLog.count({ where: { companyId: cid, tipo_acesso: "CONFIDENCIAL", timestamp: { gte: semana } } }),
    prisma.aiAuditLog.count({ where: { companyId: cid, timestamp: { gte: semana } } }),
    prisma.aiAuditLog.findMany({
      where: { companyId: cid },
      orderBy: { timestamp: "desc" },
      take: 8,
      include: { user: { select: { nome: true } } },
    }),
  ])

  const vault = (company?.vault_passwords ?? {}) as Record<string, string>

  return NextResponse.json({
    numeros: {
      logins_hoje: loginsHoje,
      logins_semana: loginsSemana,
      cofre_semana: cofreSemana,
      eventos_semana: eventosSemana,
    },
    integracoes: {
      google_oauth: !!(company?.google_client_id && company?.google_client_secret),
      telegram: !!company?.telegram_bot_token,
      tiny: !!company?.tiny_api_token,
      // Precisa da chave E do remetente: só a chave manda do sandbox e falha
      // para qualquer destinatário que não seja o dono da conta.
      resend: !!(process.env.RESEND_API_KEY && process.env.RESEND_FROM),
      cofre_configurado: Object.keys(vault).length > 0,
    },
    usuarios: usuarios.map(u => ({
      id: u.id, nome: u.nome, email: u.email, role: u.role, status: u.status,
      twofa: u.totp_enabled,
      login_google: !!u.google_oauth_id,
      agenda_google: !!u.google_access_token,
      desde: u.createdAt.toISOString(),
    })),
    ultimos_eventos: ultimos.map(l => ({
      id: l.id, tipo: l.tipo_acesso, descricao: l.descricao,
      usuario: l.user?.nome ?? "—", timestamp: l.timestamp.toISOString(),
    })),
  })
}
