import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { put } from "@vercel/blob"
import { writeFile, mkdir } from "fs/promises"
import path from "path"

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const formData = await req.formData()
  const file = formData.get("file") as File | null
  if (!file) return NextResponse.json({ error: "Nenhum arquivo enviado" }, { status: 400 })

  // Allowlist de extensões (segurança: evita subir executáveis/HTML no Blob público)
  const EXT_OK = ["jpg","jpeg","png","webp","gif","avif","bmp","svg","heic","heif","pdf","dwg","dxf","xlsx","xls","csv","docx","doc","txt"]
  const EXT_VIDEO = ["mp4","mov","webm","m4v"]
  const ext = (file.name.split(".").pop() ?? "").toLowerCase()
  if (!EXT_OK.includes(ext) && !EXT_VIDEO.includes(ext)) {
    return NextResponse.json({ error: `Tipo de arquivo não permitido (.${ext}). Aceitos: imagens, vídeos, PDF, DWG, planilhas e documentos.` }, { status: 415 })
  }

  // Vídeos podem ser maiores (obra filmada no celular); demais arquivos 20 MB
  const maxMB = EXT_VIDEO.includes(ext) ? 100 : 20
  if (file.size > maxMB * 1024 * 1024) {
    return NextResponse.json({ error: `Arquivo maior que ${maxMB} MB` }, { status: 400 })
  }

  // `?inline=1`: devolve a imagem embutida (data URI) em vez de subir no Blob.
  // Usado pelo logo da empresa, que precisa abrir em todo lugar — link público
  // do cliente, PDF, e-mail — sem depender de token. A Blob Store desta conta é
  // privada, e URL privada não abre direto no navegador.
  const inline = new URL(req.url).searchParams.get("inline") === "1"
  if (inline && file.type.startsWith("image/") && file.size <= 800_000) {
    const base64 = Buffer.from(await file.arrayBuffer()).toString("base64")
    return NextResponse.json({ url: `data:${file.type};base64,${base64}`, nome: file.name })
  }
  if (inline && file.size > 800_000) {
    return NextResponse.json(
      { error: `Imagem de ${Math.round(file.size / 1024)} KB — para o logo, use um arquivo de até 800 KB.` },
      { status: 413 },
    )
  }

  const safeName = `${session.companyId}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`

  // Token do Blob: aceita o nome padrão OU qualquer *_READ_WRITE_TOKEN
  // (se a store foi conectada com prefixo customizado, ex: BLOB_READ_WRITE_TOKEN)
  const blobToken =
    process.env.BLOB_READ_WRITE_TOKEN ||
    Object.entries(process.env).find(([k]) => k.endsWith("_READ_WRITE_TOKEN"))?.[1]

  if (!blobToken && process.env.VERCEL) {
    // Na Vercel sem token = FS é read-only e vai falhar. Erro explícito em vez
    // de cair no branch local (que sempre falha em produção/preview).
    return NextResponse.json(
      { error: "Upload não configurado neste ambiente: falta BLOB_READ_WRITE_TOKEN. Se este é um deploy de Preview, marque a env var para o ambiente Preview também nas configurações da Vercel." },
      { status: 500 }
    )
  }

  // Produção (Vercel): usa Blob storage
  if (blobToken) {
    try {
      // A Store pode estar como pública ou privada, e o SDK recusa o valor
      // errado. Em vez de fixar um, tenta o outro quando a Store reclama —
      // assim o upload funciona sem depender de qual foi configurada.
      let blob
      try {
        blob = await put(safeName, file, { access: "public", token: blobToken, addRandomSuffix: true })
      } catch (e1) {
        const m1 = e1 instanceof Error ? e1.message : ""
        if (!/private access|public access on a private store/i.test(m1)) throw e1
        blob = await put(safeName, file, { access: "private", token: blobToken, addRandomSuffix: true })
      }
      return NextResponse.json({ url: blob.url, nome: file.name })
    } catch (e) {
      const msg = e instanceof Error ? e.message : "erro desconhecido"
      console.error("[upload] Blob falhou:", msg)
      return NextResponse.json({ error: `Falha no Blob: ${msg}` }, { status: 500 })
    }
  }

  // Dev local: salva em public/uploads/
  try {
    const bytes = await file.arrayBuffer()
    const dir = path.join(process.cwd(), "public", "uploads", session.companyId)
    await mkdir(dir, { recursive: true })
    const fileName = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`
    await writeFile(path.join(dir, fileName), Buffer.from(bytes))
    return NextResponse.json({ url: `/uploads/${session.companyId}/${fileName}`, nome: file.name })
  } catch (e) {
    const msg = e instanceof Error ? e.message : "erro desconhecido"
    console.error("[upload] Gravação local falhou:", msg)
    return NextResponse.json(
      { error: `Falha ao gravar: ${msg}. Configure BLOB_READ_WRITE_TOKEN na Vercel.` },
      { status: 500 }
    )
  }
}
