import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { dataLocal } from "@/lib/data-local"

/**
 * Campanhas de Desconto (Bloco 4).
 * GET  — lista campanhas da empresa (ADMIN vê todas; demais só as vigentes/ativas).
 * POST — ADMIN cria campanha.
 */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const campanhas = await prisma.discountCampaign.findMany({
    where: { companyId: session.companyId },
    orderBy: { createdAt: "desc" },
  })
  return NextResponse.json({ campanhas })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (session.role !== "ADMIN") return NextResponse.json({ error: "Só o Admin cria campanhas" }, { status: 403 })

  const b = await req.json()
  const { nome, inicio, fim, tipo, valor, produtoIds, categoriaIds, kitIds } = b
  if (!nome?.trim() || !inicio || !fim || valor == null) {
    return NextResponse.json({ error: "Nome, vigência e valor são obrigatórios" }, { status: 400 })
  }
  if (dataLocal(fim) < dataLocal(inicio)) {
    return NextResponse.json({ error: "Fim não pode ser antes do início" }, { status: 400 })
  }

  const criada = await prisma.discountCampaign.create({
    data: {
      companyId: session.companyId,
      nome: nome.trim(),
      inicio: dataLocal(inicio),
      fim: dataLocal(fim),
      tipo: tipo === "VALOR" ? "VALOR" : "PERCENTUAL",
      valor: Number(valor) || 0,
      produtoIds: Array.isArray(produtoIds) ? produtoIds : [],
      categoriaIds: Array.isArray(categoriaIds) ? categoriaIds : [],
      kitIds: Array.isArray(kitIds) ? kitIds : [],
    },
  })
  return NextResponse.json({ ok: true, id: criada.id }, { status: 201 })
}
