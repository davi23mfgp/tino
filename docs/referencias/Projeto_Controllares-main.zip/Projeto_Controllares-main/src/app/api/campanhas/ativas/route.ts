import { NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * GET /api/campanhas/ativas — campanhas vigentes agora (ativo + dentro da
 * vigência). Consumido pelo wizard para aplicar desconto automático.
 */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const agora = new Date()
  const campanhas = await prisma.discountCampaign.findMany({
    where: { companyId: session.companyId, ativo: true, inicio: { lte: agora }, fim: { gte: agora } },
    select: { id: true, nome: true, tipo: true, valor: true, produtoIds: true, categoriaIds: true, kitIds: true },
  })
  return NextResponse.json({ campanhas })
}
