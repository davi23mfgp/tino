import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { dataLocal } from "@/lib/data-local"

/** PATCH — ADMIN edita/ativa/desativa campanha. DELETE — ADMIN remove. */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || session.role !== "ADMIN") return NextResponse.json({ error: "Não autorizado" }, { status: 403 })
  const { id } = await params

  const existing = await prisma.discountCampaign.findFirst({ where: { id, companyId: session.companyId } })
  if (!existing) return NextResponse.json({ error: "Campanha não encontrada" }, { status: 404 })

  const b = await req.json()
  const updated = await prisma.discountCampaign.update({
    where: { id },
    data: {
      ...(b.nome !== undefined && { nome: String(b.nome).trim() }),
      ...(b.inicio !== undefined && { inicio: dataLocal(b.inicio) }),
      ...(b.fim !== undefined && { fim: dataLocal(b.fim) }),
      ...(b.tipo !== undefined && { tipo: b.tipo === "VALOR" ? "VALOR" : "PERCENTUAL" }),
      ...(b.valor !== undefined && { valor: Number(b.valor) || 0 }),
      ...(b.ativo !== undefined && { ativo: !!b.ativo }),
      ...(b.produtoIds !== undefined && { produtoIds: Array.isArray(b.produtoIds) ? b.produtoIds : [] }),
      ...(b.categoriaIds !== undefined && { categoriaIds: Array.isArray(b.categoriaIds) ? b.categoriaIds : [] }),
      ...(b.kitIds !== undefined && { kitIds: Array.isArray(b.kitIds) ? b.kitIds : [] }),
    },
  })
  return NextResponse.json({ ok: true, campanha: updated })
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || session.role !== "ADMIN") return NextResponse.json({ error: "Não autorizado" }, { status: 403 })
  const { id } = await params
  await prisma.discountCampaign.deleteMany({ where: { id, companyId: session.companyId } })
  return NextResponse.json({ ok: true })
}
