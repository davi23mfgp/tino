import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil, ehVendedorRestrito } from "@/lib/perfil";

/**
 * Proposta ganha é qualquer estado depois do aceite.
 *
 * Contar só ACEITA fazia o número de fechadas cair quando o negócio andava: a
 * proposta aceita vira EM_CONTRATO no dia seguinte e sumia do painel.
 */
const GANHAS = ["ACEITA", "EM_CONTRATO", "EM_FATURAMENTO", "CONCLUIDA"] as const

/**
 * As propostas que geram recebível.
 *
 * Não é a mesma lista de GANHAS, e a diferença é ACEITA. Ganhar o negócio e ter
 * um recebível são momentos distintos: o cliente aceita, e só depois o contrato
 * fecha as datas. Enquanto isso as parcelas existem no banco, mas as datas são
 * as que o simulador propôs — ninguém combinou nada.
 *
 * Cobrar por data que não foi acordada é o pior erro possível deste painel: uma
 * parcela "atrasada" de um cliente que nunca viu aquele vencimento.
 */
const EM_CARTEIRA = ["EM_CONTRATO", "EM_FATURAMENTO", "CONCLUIDA"] as const

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const now = new Date()
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)

  const baseWhere = { companyId: session.companyId } as Record<string, unknown>
  if (ehVendedorRestrito(session)) baseWhere.vendedorId = session.userId

  const [hoje, mes, fechadas, pendentes, allForPipeline] = await Promise.all([
    prisma.proposal.count({
      where: { ...baseWhere, createdAt: { gte: startOfToday } }
    }),
    prisma.proposal.count({
      where: { ...baseWhere, createdAt: { gte: startOfMonth } }
    }),
    prisma.proposal.count({
      where: { ...baseWhere, status: { in: [...GANHAS] }, createdAt: { gte: startOfMonth } }
    }),
    prisma.proposal.count({
      where: { ...baseWhere, status: { in: ["RASCUNHO", "ENVIADA"] } }
    }),
    prisma.proposal.groupBy({
      by: ["status"],
      where: baseWhere,
      _count: { id: true }
    }),
  ])

  const pipeline = allForPipeline.map(g => ({
    status: g.status,
    count: g._count.id,
  }))

  /* Faturamento dos últimos 6 meses, separado pelo que a parcela é hoje.
     
     A versão antiga somava toda parcela pela data de vencimento e devolvia um
     número só. Isso junta dinheiro que entrou com dinheiro que ainda não
     entrou — e com dinheiro que devia ter entrado e não entrou. O gráfico
     subia bonito para a direita porque o futuro inteiro estava lá dentro,
     contado como faturamento. Quem olhava não tinha como saber o que era caixa
     e o que era promessa.

     Três estados, que é o que a pessoa precisa distinguir:
       recebido   parcela baixada
       atrasado   vencida e não baixada
       a_receber  ainda não venceu */
  const sixMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 5, 1)
  const installments = await prisma.installment.findMany({
    where: {
      proposal: {
        companyId: session.companyId,
        /* Só proposta com contrato gera recebível.

           Antes o filtro era "tudo que não foi cancelado", e as parcelas de um
           RASCUNHO entravam no faturamento — o simulador grava as linhas assim
           que alguém monta a proposta. Um rascunho de R$ 39 mil aparecia como a
           receber, e uma parcela dele com data velha aparecia como ATRASADA:
           cobrança de um negócio que ninguém fechou.

           Restringir a proposta ganha não bastava: em ACEITA as datas ainda são
           as que o simulador propôs. Vencimento vira dívida quando foi
           combinado, e o que combina é o contrato. */
        status: { in: [...EM_CARTEIRA] },
      },
    },
    select: {
      valor: true, data_vencimento: true, status: true, numero_parcela: true,
      proposal: { select: { numero: true, client_name: true } },
    },
    orderBy: { data_vencimento: "asc" },
  })

  /* A carteira inteira, não uma janela de seis meses.

     O gráfico mensal mostrava seis colunas e cinco vinham vazias, porque o
     parcelamento desta empresa é longo e concentrado: um mês com tudo, o resto
     em branco. Barra sozinha num gráfico vazio não informa nada que três
     números não digam melhor, e ainda esconde o que interessa — quanto falta
     entrar, quanto já venceu, qual é a próxima.

     Recorte de seis meses também mentia por baixo: parcela de 2027 é dinheiro
     da empresa e sumia da conta. */
  const carteira = { recebido: 0, atrasado: 0, a_receber: 0 }
  const contagem = { recebido: 0, atrasado: 0, a_receber: 0 }
  let proximo: { data: string; valor: number; cliente: string } | null = null
  let maisAtrasada: { data: string; valor: number; cliente: string; dias: number } | null = null

  for (const inst of installments) {
    const d = new Date(inst.data_vencimento)
    const v = Number(inst.valor)
    if (inst.status === "PAGO") {
      carteira.recebido += v; contagem.recebido++
      continue
    }
    if (d < startOfToday) {
      carteira.atrasado += v; contagem.atrasado++
      /* A mais antiga, não a maior: é a que está há mais tempo sem resposta, e
         a que decide se isso é atraso de dias ou calote. */
      if (!maisAtrasada) {
        maisAtrasada = {
          data: d.toISOString(), valor: v,
          cliente: inst.proposal.client_name,
          dias: Math.floor((startOfToday.getTime() - d.getTime()) / 86400000),
        }
      }
    } else {
      carteira.a_receber += v; contagem.a_receber++
      if (!proximo) {
        proximo = { data: d.toISOString(), valor: v, cliente: inst.proposal.client_name }
      }
    }
  }

  const totalCarteira = carteira.recebido + carteira.atrasado + carteira.a_receber

  /* A série mensal continua existindo, mas só vale a pena desenhar quando há
     mais de um mês com movimento. Quem decide é a tela. */
  interface Mes { mes: string; ano: number; recebido: number; atrasado: number; a_receber: number }
  const byMonth = new Map<string, Mes>()
  const monthNames = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"]
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`
    byMonth.set(key, {
      mes: monthNames[d.getMonth()], ano: d.getFullYear(),
      recebido: 0, atrasado: 0, a_receber: 0,
    })
  }
  for (const inst of installments) {
    const d = new Date(inst.data_vencimento)
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`
    const alvo = byMonth.get(key)
    if (!alvo) continue
    const v = Number(inst.valor)
    if (inst.status === "PAGO") alvo.recebido += v
    else if (d < startOfToday) alvo.atrasado += v
    else alvo.a_receber += v
  }
  const faturamento = [...byMonth.values()]

  const financeiro = {
    ...carteira,
    total: totalCarteira,
    contagem,
    proximo,
    mais_atrasada: maisAtrasada,
  }

  return NextResponse.json({ hoje, mes, fechadas, pendentes, pipeline, faturamento, financeiro })
}
