import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * GET /api/manutencoes — lista os chamados de manutenção (Kanban 3).
 * POST /api/manutencoes — cria um novo chamado vinculado a uma obra.
 */
export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const obraId = searchParams.get("obraId")

  const tickets = await prisma.maintenanceTicket.findMany({
    where: {
      companyId: session.companyId,
      ...(obraId ? { obraId } : {}),
    },
    orderBy: { createdAt: "desc" },
    include: { obra: { select: { id: true, client_name: true, address: true } } },
  })

  // Preço dos itens usados: só o ADMIN vê (decide faturar/custear).
  type ItemUsado = { tipo?: string; productId: string; nome: string; sku: string; qtd: number; movimentoId?: string }
  const itemIds = [...new Set([
    ...tickets.map(t => t.item_catalogo_id).filter(Boolean) as string[],
    // Só produtos reais (serviço tem productId "svc-...", não existe no catálogo)
    ...tickets.flatMap(t => ((t.itens_usados as ItemUsado[] | null) ?? []).filter(i => i.tipo !== "servico" && !String(i.productId).startsWith("svc-")).map(i => i.productId)),
  ])]
  const itens = itemIds.length ? await prisma.catalogProduct.findMany({
    where: { id: { in: itemIds } },
    select: { id: true, nome: true, sku: true, preco_venda: true },
  }) : []
  const itemById = new Map(itens.map(i => [i.id, i]))

  const result = tickets.map(t => ({
    item_info: t.item_catalogo_id ? (() => {
      const i = itemById.get(t.item_catalogo_id)
      if (!i) return null
      return {
        nome: i.nome, sku: i.sku,
        ...(session.role === "ADMIN" ? { preco_venda: Number(i.preco_venda), valor_total: Number(i.preco_venda) * (t.quantidade_item || 1) } : {}),
      }
    })() : null,
    itens_usados: ((t.itens_usados as ItemUsado[] | null) ?? []).map(iu => ({
      tipo: iu.tipo ?? "produto", productId: iu.productId, nome: iu.nome, sku: iu.sku, qtd: iu.qtd,
      ...(session.role === "ADMIN" ? (() => {
        const p = itemById.get(iu.productId)
        return p ? { valor_total: Number(p.preco_venda) * iu.qtd } : {}
      })() : {}),
    })),
    valor_total_itens: session.role === "ADMIN"
      ? ((t.itens_usados as ItemUsado[] | null) ?? []).reduce((s, iu) => {
          const p = itemById.get(iu.productId)
          return s + (p ? Number(p.preco_venda) * iu.qtd : 0)
        }, 0)
      : null,
    id: t.id,
    titulo: t.titulo,
    descricao: t.descricao,
    status: t.status,
    registro_notas: t.registro_notas,
    checklist: t.checklist,
    anexos: t.anexos,
    item_catalogo_id: t.item_catalogo_id,
    item_servico: t.item_servico,
    quantidade_item: t.quantidade_item,
    decisao_faturamento: session.role === "ADMIN" ? t.decisao_faturamento : null,
    obraId: t.obraId,
    obra_nome: t.obra?.client_name ?? null,
    obra_cidade: t.obra?.address ?? null,
    createdAt: t.createdAt.toISOString(),
  }))

  return NextResponse.json({ tickets: result, total: result.length })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { obraId, titulo, descricao, checklist } = await req.json()

  if (!obraId || !titulo) {
    return NextResponse.json({ error: "Obra e título são obrigatórios" }, { status: 400 })
  }

  // Garante que a obra é da mesma empresa (multi-tenant)
  const obra = await prisma.obra.findFirst({ where: { id: obraId, companyId: session.companyId } })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const ticket = await prisma.maintenanceTicket.create({
    data: {
      obraId,
      titulo,
      descricao: descricao || null,
      checklist: checklist ?? [],
      status: "NOVA",
      companyId: session.companyId,
    },
  })

  return NextResponse.json(ticket, { status: 201 })
}
