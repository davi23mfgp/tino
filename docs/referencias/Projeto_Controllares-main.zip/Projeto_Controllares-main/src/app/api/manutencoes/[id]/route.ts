import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * PATCH /api/manutencoes/[id] — registro da manutenção (notas, checklist, anexos).
 * Parcial: só sobrescreve o que veio no body.
 */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const body = await req.json()

  const existing = await prisma.maintenanceTicket.findFirst({
    where: { id, companyId: session.companyId },
  })
  if (!existing) return NextResponse.json({ error: "Chamado não encontrado" }, { status: 404 })

  const data: Record<string, unknown> = {}
  if ("registro_notas" in body) data.registro_notas = body.registro_notas || null
  if ("checklist" in body) data.checklist = body.checklist ?? null
  if ("anexos" in body) data.anexos = body.anexos ?? null
  if ("titulo" in body && body.titulo) data.titulo = body.titulo
  if ("descricao" in body) data.descricao = body.descricao || null
  if ("item_catalogo_id" in body) data.item_catalogo_id = body.item_catalogo_id || null
  if ("item_servico" in body) data.item_servico = body.item_servico ?? null
  if ("quantidade_item" in body) data.quantidade_item = Math.max(1, Number(body.quantidade_item) || 1)
  // Aplica um movimento pendente (decrementa saldo + APLICADO). Autorização = decisão do ADMIN.
  async function aplicarMovimento(movId: string) {
    const mov = await prisma.stockMovement.findUnique({ where: { id: movId } })
    if (!mov || mov.status !== "PENDENTE") return
    await prisma.$transaction(async tx => {
      const prod = await tx.catalogProduct.findUnique({ where: { id: mov.productId }, select: { estoque_qtd: true } })
      const novoSaldo = Math.max(0, (prod?.estoque_qtd ?? 0) - mov.quantidade)
      await tx.catalogProduct.update({ where: { id: mov.productId }, data: { estoque_qtd: novoSaldo } })
      await tx.stockMovement.update({
        where: { id: mov.id },
        data: { status: "APLICADO", saldo_novo: novoSaldo, aprovadoPorNome: session!.nome },
      })
    })
  }

  if ("decisao_faturamento" in body && session.role === "ADMIN") {
    if (!["FATURAR", "CUSTEADO"].includes(body.decisao_faturamento)) return NextResponse.json({ error: "Decisão inválida" }, { status: 400 })
    data.decisao_faturamento = body.decisao_faturamento

    // Baixa todos os itens do chamado (multi) + legado de item único
    const lista = (existing.itens_usados as { movimentoId?: string }[] | null) ?? []
    for (const it of lista) if (it.movimentoId) await aplicarMovimento(it.movimentoId)
    if (existing.estoque_movimento_id) await aplicarMovimento(existing.estoque_movimento_id)
  }

  // Multi-itens: técnico manda a lista [{productId, nome, sku, qtd, movimentoId?}].
  // Item novo (sem movimentoId) ganha uma SAIDA PENDENTE; removidos têm o
  // movimento pendente cancelado (RECUSADO). Técnico nunca vê valores.
  if ("itens_usados" in body && Array.isArray(body.itens_usados)) {
    const anteriores = (existing.itens_usados as { productId: string; movimentoId?: string }[] | null) ?? []
    const novos: { tipo: "produto" | "servico"; productId: string; nome: string; sku: string; qtd: number; movimentoId?: string }[] = []

    for (const it of body.itens_usados) {
      if (!it?.productId) continue
      const qtd = Math.max(1, Number(it.qtd) || 1)
      // Serviço livre: não é catálogo, não mexe no estoque — só entra na lista.
      if (it.tipo === "servico" || String(it.productId).startsWith("svc-")) {
        novos.push({ tipo: "servico", productId: it.productId, nome: it.nome || "Serviço", sku: "", qtd })
        continue
      }
      const prev = anteriores.find(a => a.productId === it.productId)
      if (prev?.movimentoId) {
        novos.push({ tipo: "produto", productId: it.productId, nome: it.nome, sku: it.sku, qtd, movimentoId: prev.movimentoId })
        continue
      }
      const product = await prisma.catalogProduct.findFirst({ where: { id: it.productId, companyId: session.companyId } })
      if (!product) continue
      const movement = await prisma.stockMovement.create({ data: {
        companyId: session.companyId, productId: product.id, tipo: "SAIDA", quantidade: qtd,
        saldo_novo: Math.max(0, (product.estoque_qtd ?? 0) - qtd), motivo: `Uso em chamado: ${existing.titulo}`,
        origem: `chamado:${id}`, status: "PENDENTE", criadoPorId: session.userId, criadoPorNome: session.nome,
      } })
      novos.push({ tipo: "produto", productId: product.id, nome: product.nome, sku: product.sku, qtd, movimentoId: movement.id })
    }

    // Cancela pendentes de itens removidos da lista
    for (const a of anteriores) {
      if (a.movimentoId && !novos.some(n => n.productId === a.productId)) {
        await prisma.stockMovement.updateMany({
          where: { id: a.movimentoId, status: "PENDENTE" },
          data: { status: "RECUSADO", aprovadoPorNome: session.nome },
        })
      }
    }
    data.itens_usados = novos
  }
  if ("data_agendada" in body) data.data_agendada = body.data_agendada ? new Date(body.data_agendada) : null

  const updated = await prisma.maintenanceTicket.update({ where: { id }, data })
  return NextResponse.json(updated)
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const existing = await prisma.maintenanceTicket.findFirst({
    where: { id, companyId: session.companyId },
  })
  if (!existing) return NextResponse.json({ error: "Chamado não encontrado" }, { status: 404 })

  await prisma.maintenanceTicket.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
