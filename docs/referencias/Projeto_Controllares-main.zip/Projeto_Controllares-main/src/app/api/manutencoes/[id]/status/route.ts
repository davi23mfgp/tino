import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

const STATUS_VALIDOS = ["NOVA", "AGUARDANDO", "EM_ANDAMENTO", "EM_CONFERENCIA", "CONCLUIDA"] as const

/**
 * PATCH /api/manutencoes/[id]/status
 * Move o chamado no Kanban de Manutenções.
 */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const { status } = await req.json()

  if (!status || !STATUS_VALIDOS.includes(status)) {
    return NextResponse.json({ error: "Status inválido" }, { status: 400 })
  }

  const ticket = await prisma.maintenanceTicket.findFirst({
    where: { id, companyId: session.companyId },
  })
  if (!ticket) return NextResponse.json({ error: "Chamado não encontrado" }, { status: 404 })

  await prisma.maintenanceTicket.update({ where: { id }, data: { status } })

  return NextResponse.json({ success: true, status })
}
