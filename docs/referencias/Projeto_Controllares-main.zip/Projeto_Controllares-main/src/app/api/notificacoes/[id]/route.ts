import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export async function PATCH(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params

  const log = await prisma.webhookDebugLog.findFirst({
    where: { id, companyId: session.companyId }
  })
  if (!log) return NextResponse.json({ error: "Notificação não encontrada" }, { status: 404 })

  await prisma.webhookDebugLog.update({
    where: { id },
    data: { reenviado: true }
  })

  return NextResponse.json({ success: true })
}
