import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"

/* Rótulo bonito por endpoint — sem entrada aqui, a gaveta caía pro endpoint
   cru ("internal/proposta-enviada" em vez de "Proposta enviada"). Os títulos
   de proposta espelham os mesmos usados no Telegram (src/lib/notificar-
   proposta.ts, "mapa"), pra não existir duas versões do mesmo aviso. */
const ENDPOINT_LABELS: Record<string, string> = {
  "internal/proposta-visualizada": "Proposta visualizada",
  "internal/proposta-lida": "Proposta lida",
  "internal/proposta-enviada": "Proposta enviada",
  "internal/proposta-aceita": "Proposta aceita",
  "internal/revisao-solicitada": "Revisão solicitada",
  "internal/proposta-faturamento": "Proposta em faturamento",
  "internal/proposta-contrato": "Proposta em contrato",
  "internal/proposta-cancelada": "Proposta cancelada",
  "internal/proposta-perdida": "Proposta perdida",
  "internal/proposta-criada": "Proposta criada",
  "internal/obra-criada": "Obra criada",
  "internal/obra-aditivo": "Aditivo na obra",
  "internal/estoque-baixo": "Estoque baixo",
  "internal/desconto-solicitado": "Desconto solicitado",
  "internal/desconto-decidido": "Desconto decidido",
  "internal/inventario-backup": "Backup de inventário",
  "internal/notificacao": "Notificação",
  "webhook/pluga/proposta-aceita": "Proposta aceita",
  "webhook/contaazul/emitir-nfe": "NF-e preparada",
}

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  /**
   * Quem vê o quê.
   *
   * A gaveta listava tudo da empresa, filtrando só por companyId. Um técnico
   * abrindo o sino via aceite de proposta, nome de cliente e valor fechado —
   * informação comercial que a tela dele não mostra em nenhum outro lugar. O
   * Telegram, esse, já entregava certo: só Admin, Financeiro e o vendedor da
   * proposta. A gaveta é que estava aberta.
   *
   * A regra passa a ser a mesma dos dois lados. Quem não é do comercial nem do
   * financeiro só vê aviso de proposta que é dele.
   */
  const veTudoDeProposta = temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])

  const filtro = veTudoDeProposta
    ? { companyId: session.companyId }
    : {
        companyId: session.companyId,
        OR: [
          /* Aviso que não é de proposta segue visível: operação e obra são de
             todo mundo que trabalha nelas. Hoje só existem os de proposta, e
             esta linha é o que evita que o próximo módulo nasça invisível. */
          { NOT: { endpoint: { startsWith: "internal/proposta" } } },
          { payload_json: { path: ["vendedorId"], equals: session.userId } },
        ],
      }

  const { searchParams } = new URL(req.url)
  const limit = Math.min(parseInt(searchParams.get("limit") || "20"), 100)
  const page = Math.max(parseInt(searchParams.get("page") || "1"), 1)

  const logs = await prisma.webhookDebugLog.findMany({
    where: filtro,
    orderBy: { createdAt: "desc" },
    take: limit,
    skip: (page - 1) * limit,
  })

  const notifications = logs.map(log => ({
    id: log.id,
    endpoint: log.endpoint,
    label: ENDPOINT_LABELS[log.endpoint] ?? log.endpoint,
    payload_json: log.payload_json as Record<string, unknown> | null,
    reenviado: log.reenviado,
    createdAt: log.createdAt.toISOString(),
  }))

  const unreadCount = await prisma.webhookDebugLog.count({
    where: { ...filtro, reenviado: false },
  })

  return NextResponse.json({ notifications, unreadCount })
}

export async function PATCH(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  await prisma.webhookDebugLog.updateMany({
    where: { companyId: session.companyId, reenviado: false },
    data: { reenviado: true }
  })

  return NextResponse.json({ success: true })
}

export async function DELETE() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  await prisma.webhookDebugLog.deleteMany({
    where: { companyId: session.companyId }
  })

  return NextResponse.json({ success: true })
}
