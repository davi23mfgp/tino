import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { createToken } from "@/lib/auth"
import bcrypt from "bcryptjs"
import { rebaixarOutrosAdmins, registrarRebaixamento } from "@/lib/admin-unico"
import { COOKIE_SESSAO } from "@/lib/cookie-sessao"
import { avaliarSenha } from "@/lib/forca-senha"

/** GET /api/convite/[token] — valida o convite (público). */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params
  const invite = await prisma.invite.findUnique({
    where: { token },
    include: { company: { select: { nome_empresa: true, logo_url: true } } },
  })
  if (!invite || invite.usedAt || invite.expiresAt < new Date()) {
    return NextResponse.json({ error: "Convite inválido ou expirado." }, { status: 404 })
  }
  return NextResponse.json({
    email: invite.email,
    role: invite.role,
    empresa: invite.company.nome_empresa,
    logo_url: invite.company.logo_url,
  })
}

/**
 * POST /api/convite/[token] — aceita o convite: { nome, senha }.
 * Cria o usuário ATIVO com a role do convite e já loga (cookie de sessão).
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params
  const { nome, senha } = await req.json().catch(() => ({}))

  if (!nome?.trim()) return NextResponse.json({ error: "Nome é obrigatório." }, { status: 400 })
  if (!senha || senha.length < 8) {
    return NextResponse.json({ error: "Senha deve ter ao menos 8 caracteres." }, { status: 400 })
  }

  // Mesma regra do formulário, aplicada onde de fato conta.
  if (!avaliarSenha(senha, { nome }).aceitavel) {
    return NextResponse.json({
      error: "Senha muito fraca. Use pelo menos 10 caracteres e evite palavras"
        + " comuns, sequências do teclado ou o seu próprio nome.",
    }, { status: 400 })
  }

  const invite = await prisma.invite.findUnique({ where: { token } })
  if (!invite || invite.usedAt || invite.expiresAt < new Date()) {
    return NextResponse.json({ error: "Convite inválido ou expirado." }, { status: 404 })
  }

  const jaExiste = await prisma.user.findUnique({ where: { email: invite.email } })
  if (jaExiste) return NextResponse.json({ error: "E-mail já cadastrado." }, { status: 409 })

  const user = await prisma.user.create({
    data: {
      nome: nome.trim(),
      email: invite.email,
      senha: await bcrypt.hash(senha, 10),
      role: invite.role,
      status: "ATIVO",
      companyId: invite.companyId,
    },
  })
  await prisma.invite.update({ where: { id: invite.id }, data: { usedAt: new Date() } })

  // Convite com perfil ADMIN também respeita "um admin ativo por empresa".
  // Só o acesso muda: nada da empresa é apagado.
  if (user.role === "ADMIN") {
    const rebaixados = await rebaixarOutrosAdmins(user.companyId, user.id)
    await registrarRebaixamento(user.companyId, user.id, rebaixados)
  }

  await prisma.aiAuditLog.create({
    data: {
      userId: user.id, companyId: user.companyId, tipo_acesso: "LOGIN",
      descricao: `Entrou via convite (${user.email})`,
    },
  }).catch(() => {})

  const jwt = await createToken({
    userId: user.id, email: user.email, nome: user.nome,
    role: user.role, roles: user.roles ?? [], companyId: user.companyId,
  })
  const res = NextResponse.json({ ok: true })
  res.cookies.set(COOKIE_SESSAO, jwt, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 7,
    path: "/",
  })
  return res
}
