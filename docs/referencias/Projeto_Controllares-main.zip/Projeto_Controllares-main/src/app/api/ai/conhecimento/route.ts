import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"
import { indexarDocumento } from "@/lib/ai/rag"
import { extrairTexto, extensaoSuportada } from "@/lib/ai/extrair-texto"
import { embeddingsConfigurado } from "@/lib/ai/embeddings"

const ROLES_VALIDOS = [
  "ADMIN", "VENDEDOR", "FINANCEIRO",
  "RESPONSAVEL_TECNICO", "INSTALADOR", "ENGENHEIRO_PROJETOS",
]

/** GET /api/ai/conhecimento — lista os documentos da base (ADMIN). */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin gerencia a base de conhecimento." }, { status: 403 })
  }

  const docs = await prisma.knowledgeDoc.findMany({
    where: { companyId: session.companyId },
    orderBy: { createdAt: "desc" },
    select: {
      id: true, titulo: true, origem: true, fonte: true, roles: true, tags: true,
      status: true, erro: true, chars: true, createdAt: true,
      _count: { select: { chunks: true } },
    },
  })

  return NextResponse.json({
    docs: docs.map(d => ({ ...d, chunks: d._count.chunks, _count: undefined })),
    // A tela precisa saber se falta configurar a chave, senão o upload falha
    // sem explicação.
    embeddingsOk: embeddingsConfigurado(),
  })
}

/**
 * POST /api/ai/conhecimento — adiciona um documento à base (ADMIN).
 * Aceita `multipart/form-data` (arquivo) ou JSON com `{ titulo, texto }`.
 */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin alimenta a base de conhecimento." }, { status: 403 })
  }
  if (!embeddingsConfigurado()) {
    return NextResponse.json(
      { error: "Embeddings não configurados. Defina EMBED_API_KEY (ou AI_API_KEY) no ambiente." },
      { status: 422 },
    )
  }

  const tipoConteudo = req.headers.get("content-type") ?? ""
  let titulo = ""
  let texto = ""
  let fonte: string | null = null
  let origem: "UPLOAD" | "TEXTO" = "TEXTO"
  let roles: string[] = []
  let tags: string[] = []

  try {
    if (tipoConteudo.includes("multipart/form-data")) {
      const form = await req.formData()
      const arquivo = form.get("file") as File | null
      if (!arquivo) return NextResponse.json({ error: "Nenhum arquivo enviado." }, { status: 400 })

      const ext = (arquivo.name.split(".").pop() ?? "").toLowerCase()
      if (!extensaoSuportada(ext)) {
        return NextResponse.json(
          { error: `Formato .${ext} não suportado. Use PDF, TXT, MD ou CSV.` },
          { status: 415 },
        )
      }
      if (arquivo.size > 25 * 1024 * 1024) {
        return NextResponse.json({ error: "Arquivo maior que 25 MB." }, { status: 413 })
      }

      const extraido = await extrairTexto(arquivo)
      texto = extraido.texto
      titulo = String(form.get("titulo") || "").trim() || arquivo.name
      fonte = String(form.get("fonte") || "").trim() || arquivo.name
      origem = "UPLOAD"
      roles = String(form.get("roles") || "").split(",").map(s => s.trim()).filter(Boolean)
      tags = String(form.get("tags") || "").split(",").map(s => s.trim()).filter(Boolean)
    } else {
      const body = await req.json()
      titulo = String(body.titulo || "").trim()
      texto = String(body.texto || "")
      fonte = body.fonte ? String(body.fonte).trim() : null
      roles = Array.isArray(body.roles) ? body.roles.map(String) : []
      tags = Array.isArray(body.tags) ? body.tags.map(String) : []
    }
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Não foi possível ler o conteúdo." },
      { status: 400 },
    )
  }

  if (!titulo) return NextResponse.json({ error: "Informe um título." }, { status: 400 })
  if (texto.trim().length < 40) {
    return NextResponse.json({ error: "Conteúdo curto demais para virar conhecimento." }, { status: 400 })
  }
  if (roles.some(r => !ROLES_VALIDOS.includes(r))) {
    return NextResponse.json({ error: "Perfil inválido na restrição de acesso." }, { status: 400 })
  }

  const doc = await prisma.knowledgeDoc.create({
    data: {
      companyId: session.companyId,
      titulo, origem, fonte, roles, tags,
      status: "PENDENTE",
      criadoPor: session.userId,
    },
  })

  // Indexação é a parte cara (chama o provedor de embeddings). Se falhar, o
  // documento fica marcado com o erro em vez de sumir sem explicação.
  try {
    const { chunks } = await indexarDocumento(doc.id, texto)
    return NextResponse.json({ doc: { id: doc.id, titulo, chunks } }, { status: 201 })
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Falha ao indexar."
    await prisma.knowledgeDoc.update({
      where: { id: doc.id },
      data: { status: "ERRO", erro: msg.slice(0, 500) },
    })
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}
