import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { encrypt } from "@/lib/crypto"
import { validarSenhaCofreComTrava, cofreConfigurado, type AiUser } from "@/lib/ai/scope"

/**
 * POST /api/ai/create-record { password, tipo, payload }
 *
 * payload.kind = "credencial" | "tarefa" | "agendamento"
 * Cria o registro após validar a senha correta para o tipo.
 * Registra auditoria sem salvar a senha nem o conteúdo sensível.
 */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const u: AiUser = {
    userId: session.userId, role: session.role,
    companyId: session.companyId, nome: session.nome,
  }

  const { password: rawPassword, tipo = "padrao", payload } = await req.json().catch(() => ({}))
  const password = String(rawPassword ?? "").trim()
  if (!password || !payload?.kind) {
    return NextResponse.json({ ok: false, message: "Dados incompletos." })
  }

  // ---- Valida senha do cofre (mesmo mecanismo do verify-sensitive) ----
  if (!(await cofreConfigurado(u.companyId, u.role))) {
    return NextResponse.json({ ok: false, message: "Cofre não configurado para o seu perfil. O Admin define a senha em Configurações → Cofre." })
  }
  const tentativa = await validarSenhaCofreComTrava(u.userId, u.companyId, u.role, password)
  if (tentativa.bloqueadoMin > 0) {
    return NextResponse.json({ ok: false, message: `Muitas tentativas com a senha do cofre. Aguarde ${tentativa.bloqueadoMin} min.` })
  }
  if (!tentativa.ok) return NextResponse.json({ ok: false, message: "Senha incorreta — use a senha do COFRE (Configurações), não a sua senha de login." })

  // ---- Cria o registro ----
  try {
    if (payload.kind === "credencial") {
      // payload: { obraId, tipo_equipamento, ip, login, senha_equip, mac, observacoes }
      if (!payload.obraId || !payload.tipo_equipamento) {
        return NextResponse.json({ ok: false, message: "obraId e tipo_equipamento são obrigatórios para credencial." })
      }
      // Verifica que a obra pertence à empresa
      const obra = await prisma.obra.findFirst({ where: { id: payload.obraId, companyId: u.companyId } })
      if (!obra) return NextResponse.json({ ok: false, message: "Obra não encontrada." })

      await prisma.technicalCredential.create({
        data: {
          obraId: payload.obraId,
          tipo_equipamento: payload.tipo_equipamento,
          ip_criptografado: payload.ip ? encrypt(payload.ip) : null,
          login: payload.login ?? null,
          senha_criptografada: payload.senha_equip ? encrypt(payload.senha_equip) : null,
          mac_criptografado: payload.mac ? encrypt(payload.mac) : null,
          observacoes: payload.observacoes ?? null,
        },
      })

      await prisma.aiAuditLog.create({
        data: {
          userId: u.userId, companyId: u.companyId, tipo_acesso: "CRIAR",
          descricao: `Criou credencial "${payload.tipo_equipamento}" na obra ${obra.client_name}`.slice(0, 480),
          obraId: payload.obraId,
        },
      })
      return NextResponse.json({ ok: true, message: `✅ Credencial "${payload.tipo_equipamento}" criada na obra ${obra.client_name}.` })
    }

    if (payload.kind === "tarefa") {
      // payload: { titulo, descricao, obraId, dataVenc }
      if (!payload.titulo) return NextResponse.json({ ok: false, message: "Título da tarefa é obrigatório." })

      await prisma.tarefa.create({
        data: {
          titulo: payload.titulo,
          descricao: payload.descricao ?? null,
          obraId: payload.obraId ?? null,
          companyId: u.companyId,
          criadoPor: u.userId,
          atribuidoA: u.userId,
          dataVenc: payload.dataVenc ? new Date(payload.dataVenc) : null,
        },
      })
      await prisma.aiAuditLog.create({
        data: {
          userId: u.userId, companyId: u.companyId, tipo_acesso: "CRIAR",
          descricao: `Criou tarefa "${payload.titulo}"`.slice(0, 480),
        },
      })
      return NextResponse.json({ ok: true, message: `✅ Tarefa "${payload.titulo}" criada com sucesso.` })
    }

    if (payload.kind === "agendamento") {
      /* Agendamentos são JSON no campo Obra.agendamentos, e a forma canônica
         — a que a tela de obras grava e o sync do Google lê — é
         { titulo, data, hora_inicio, hora_fim }. O CORE gravava
         data_inicio/data_fim: o evento aparecia na obra mas o sync lia
         `ag.data` como undefined e nunca ia para o Google Calendar.
         Aceita as duas entradas e grava sempre a canônica. */
      const dataISO = String(payload.data ?? payload.data_inicio ?? "")
      if (!payload.titulo || !dataISO || !payload.obraId) {
        return NextResponse.json({ ok: false, message: "Título, data e obraId são obrigatórios para agendamento." })
      }
      const obra = await prisma.obra.findFirst({ where: { id: payload.obraId, companyId: u.companyId } })
      if (!obra) return NextResponse.json({ ok: false, message: "Obra não encontrada." })

      const agendamentos = (obra.agendamentos as Record<string, unknown>[] | null) ?? []
      /* Hora sai do fim do ISO quando vem junto ("2026-08-10T14:00"); sem hora,
         o sync trata como evento de dia inteiro. */
      const horaDe = (v: unknown) => {
        const m = String(v ?? "").match(/T(\d{2}:\d{2})/)
        return m ? m[1] : undefined
      }
      const novoAgendamento = {
        id: `ag_${Date.now()}`,
        titulo: payload.titulo,
        descricao: payload.descricao ?? null,
        data: dataISO.slice(0, 10),
        hora_inicio: payload.hora_inicio ?? horaDe(payload.data_inicio ?? payload.data),
        hora_fim: payload.hora_fim ?? horaDe(payload.data_fim),
        criadoPor: u.userId,
      }
      await prisma.obra.update({
        where: { id: payload.obraId },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        data: { agendamentos: [...agendamentos, novoAgendamento] as any },
      })
      await prisma.aiAuditLog.create({
        data: {
          userId: u.userId, companyId: u.companyId, tipo_acesso: "CRIAR",
          descricao: `Criou agendamento "${payload.titulo}" na obra ${obra.client_name}`.slice(0, 480),
          obraId: payload.obraId,
        },
      })
      return NextResponse.json({ ok: true, message: `✅ Agendamento "${payload.titulo}" criado na obra ${obra.client_name}.` })
    }

    return NextResponse.json({ ok: false, message: `Tipo "${payload.kind}" não suportado.` })
  } catch (e) {
    console.error("[create-record]", e)
    return NextResponse.json({ ok: false, message: "Erro ao salvar no banco." })
  }
}
