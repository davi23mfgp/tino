import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"

/** DELETE /api/ai/conhecimento/[id] — remove o documento e seus pedaços (ADMIN). */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin gerencia a base de conhecimento." }, { status: 403 })
  }

  const { id } = await params
  const doc = await prisma.knowledgeDoc.findFirst({
    where: { id, companyId: session.companyId },
    select: { id: true, titulo: true },
  })
  if (!doc) return NextResponse.json({ error: "Documento não encontrado" }, { status: 404 })

  // Os pedaços caem por cascade.
  await prisma.knowledgeDoc.delete({ where: { id } })

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "EXCLUIR",
      descricao: `Removeu da base de conhecimento: ${doc.titulo}`,
    },
  }).catch(() => {})

  return NextResponse.json({ success: true })
}

/** PATCH /api/ai/conhecimento/[id] — ajusta título, fonte, perfis e tags (ADMIN). */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin gerencia a base de conhecimento." }, { status: 403 })
  }

  const { id } = await params
  const body = await req.json().catch(() => ({}))

  const existe = await prisma.knowledgeDoc.findFirst({
    where: { id, companyId: session.companyId },
    select: { id: true },
  })
  if (!existe) return NextResponse.json({ error: "Documento não encontrado" }, { status: 404 })

  const atualizado = await prisma.knowledgeDoc.update({
    where: { id },
    data: {
      ...(body.titulo !== undefined && { titulo: String(body.titulo).trim() }),
      ...(body.fonte !== undefined && { fonte: String(body.fonte).trim() || null }),
      ...(Array.isArray(body.roles) && { roles: body.roles.map(String) }),
      ...(Array.isArray(body.tags) && { tags: body.tags.map(String) }),
    },
    select: { id: true, titulo: true, fonte: true, roles: true, tags: true },
  })

  return NextResponse.json({ doc: atualizado })
}
