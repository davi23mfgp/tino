import { NextRequest } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { checarRateLimit } from "@/lib/ai/rate-limit"
import { detectarIntent, detectarAcao, extrairNumeroProposta, ehSaudacao, gruposPorPerfil } from "@/lib/ai/intent"
import { montarContexto, buscarAnexos, type AiUser } from "@/lib/ai/scope"
import { buildSystemPrompt } from "@/lib/ai/prompt"
import { buscarConhecimento, formatarTrechos } from "@/lib/ai/rag"
import { responderDireto } from "@/lib/ai/respostas-diretas"
import { ehPerguntaTecnica, buscarNaWeb, formatarResultados } from "@/lib/ai/busca-web"
import { interpretarPedido } from "@/lib/ai/secretario"
import { streamAI, type ChatMsg } from "@/lib/ai/llm"

export const dynamic = "force-dynamic"

const enc = new TextEncoder()
function sse(obj: unknown) {
  return enc.encode(`data: ${JSON.stringify(obj)}\n\n`)
}
function oneShot(obj: unknown) {
  return new Response(
    new ReadableStream({
      start(c) { c.enqueue(sse(obj)); c.enqueue(sse({ type: "done" })); c.close() },
    }),
    { headers: SSE_HEADERS }
  )
}
const SSE_HEADERS = {
  "Content-Type": "text/event-stream",
  "Cache-Control": "no-cache, no-transform",
  Connection: "keep-alive",
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return new Response("Não autorizado", { status: 401 })

  const u: AiUser = {
    userId: session.userId, role: session.role, roles: session.roles ?? [],
    companyId: session.companyId, nome: session.nome,
  }

  const body = await req.json().catch(() => ({}))
  const message: string = (body.message ?? "").toString().slice(0, 2000)
  const history: ChatMsg[] = Array.isArray(body.history) ? body.history.slice(-10) : []
  if (!message.trim()) return new Response("Mensagem vazia", { status: 400 })

  // ---- SAUDAÇÃO/AJUDA pura: menu instantâneo por perfil (sem LLM) ----
  if (ehSaudacao(message)) {
    const grupos = gruposPorPerfil(u.role)
    const primeiro = u.nome.split(" ")[0]
    return oneShot({
      type: "text",
      delta: `Opa, ${primeiro}! Sou o CORE. Posso ajudar com: ${grupos.join(" · ")}.\nÉ só perguntar — ex.: "minhas obras", "propostas a vencer", "planta da casa X".`,
    })
  }

  // ---- RESPOSTA DIRETA: contagens e listas que o banco já sabe dar ----
  // Vem antes de qualquer chamada ao modelo: é exato (o modelo não erra conta
  // que não faz), instantâneo, e não consome cota — por isso fica ANTES do
  // rate limit. Só a pergunta que realmente aciona a IA é contabilizada.
  const direta = await responderDireto(u, message).catch(() => null)
  if (direta) {
    await prisma.aiAuditLog.create({
      data: {
        userId: u.userId, companyId: u.companyId, tipo_acesso: "DADOS",
        descricao: `Resposta direta: ${message}`.slice(0, 480),
      },
    }).catch(() => {})
    return oneShot({ type: "text", delta: direta.texto })
  }

  const intent = detectarIntent(message)

  // ---- Rate limit: conta só o que pode chegar ao modelo ----
  // Credencial, anexo e ação são resolvidos no servidor; contá-los gastaria a
  // franquia do usuário sem que nenhuma IA fosse chamada.
  if (intent === "DADOS") {
    const rl = await checarRateLimit(u.userId, u.companyId)
    if (!rl.permitido) {
      return oneShot({ type: "error", message: `Limite de mensagens atingido. Tente novamente em ${rl.restamMin} minutos.` })
    }
  }

  // ---- CONFIDENCIAL: abre o painel guiado de Credenciais (mesmo fluxo do
  // botão "Credenciais") — lista por obra e pede a senha do cofre ao revelar.
  // Mais confiável que casar o equipamento pelo texto da pergunta.
  if (intent === "CONFIDENCIAL") {
    return oneShot({
      type: "open_flow",
      flow: "credenciais",
      message: "🔒 Credenciais são protegidas. Escolha na lista — a senha do cofre é pedida ao revelar.",
    })
  }

  // ---- SECRETÁRIO: criar tarefa, agendar, concluir, anotar na obra ----
  // Interpretação determinística, não é o modelo que decide o que gravar. Se o
  // regex não entender, devolve null e vira conversa normal — falhar para
  // "não entendi" é seguro; gravar um agendamento inventado, não.
  const pedido = await interpretarPedido(u, message).catch(() => null)
  if (pedido) {
    return oneShot({
      type: "confirm_action",
      acao: pedido.acao,
      params: pedido.params,
      message: `${pedido.descricao}\n\nConfirma?`,
    })
  }

  // ---- AÇÃO: descreve e pede confirmação ----
  if (intent === "ACAO") {
    const { acao } = detectarAcao(message)
    if (acao) {
      const numero = extrairNumeroProposta(message)
      return oneShot({
        type: "confirm_action",
        acao,
        params: { numero },
        message: numero
          ? `Confirma ${acao === "emitir_nf" ? "emissão" : "cancelamento"} da NF da proposta #${numero}?`
          : `Confirma a ação "${acao}"?`,
      })
    }
  }

  // ---- ANEXO: busca arquivos permitidos e devolve botões ----
  if (intent === "ANEXO") {
    const anexos = await buscarAnexos(u, message)
    if (anexos.length > 0) {
      await prisma.aiAuditLog.create({
        data: {
          userId: u.userId, companyId: u.companyId, tipo_acesso: "ANEXO",
          descricao: `Solicitou anexos: ${anexos.map(a => a.nome).join(", ")}`.slice(0, 480),
        },
      })
      return oneShot({
        type: "attachments",
        message: anexos.length === 1 ? "Aqui está o arquivo:" : "Encontrei estes arquivos:",
        attachments: anexos,
      })
    }
    // sem anexos → cai para resposta normal explicando
  }

  // ---- DADOS: contexto filtrado + streaming da IA ----
  // Duas fontes complementares: `montarContexto` traz os DADOS do sistema
  // (obras, propostas, estoque) por consulta estruturada; `buscarConhecimento`
  // traz TRECHOS de documentos (manuais, normas, procedimentos) por
  // similaridade. A busca semântica falha em silêncio de propósito — sem ela o
  // CORE continua respondendo com os dados.
  // Terceira fonte: internet, só para pergunta técnica de equipamento
  // (amperagem de canal, tensão, protocolo). Não é buscador geral — a trava
  // está em `ehPerguntaTecnica`, e pergunta sobre dados da empresa nunca cai
  // aqui. Sem chave configurada, simplesmente não acontece.
  const [contexto, empresa, trechos] = await Promise.all([
    /* A pergunta de seguimento vai junto com a anterior.

       O contexto passou a ser escolhido pelo assunto da mensagem, e mensagem
       curta de seguimento não tem assunto: depois de "quantos leads eu tenho",
       um "a Libia" sozinho não fala de lead nenhum, e o CORE respondia sobre
       agenda. Colar a última pergunta do usuário devolve o assunto sem
       arrastar a conversa inteira. */
    montarContexto(u, [...history].reverse().find(h => h.role === "user")?.content
      ? `${[...history].reverse().find(h => h.role === "user")!.content} ${message}`
      : message),
    prisma.company.findUnique({ where: { id: u.companyId }, select: { nome_empresa: true } }),
    buscarConhecimento(u, message),
  ])

  /* A internet só entra quando a casa não respondeu.

     O manual que a empresa guardou vale mais que qualquer página: é o
     equipamento que ela instalou, na versão que ela tem. Antes as duas buscas
     rodavam juntas e o resultado da web ia para o fim do prompt — o modelo
     respondia pela internet mesmo tendo o manual em mãos, e ainda sem citar
     fonte nenhuma. */
  const web = trechos.length === 0 && ehPerguntaTecnica(message)
    ? await buscarNaWeb(message)
    : []

  // Para instaladores e responsáveis técnicos, lista as obras sob responsabilidade
  let obrasDesc = ""
  if (["INSTALADOR", "RESPONSAVEL_TECNICO"].includes(u.role)) {
    const obras = await prisma.obra.findMany({
      where: {
        companyId: u.companyId,
        OR: [
          { resp_tecnico_id: u.userId },
          { resp_comercial_id: u.userId },
        ],
      },
      select: { client_name: true, etapa: true },
      take: 10,
    })
    obrasDesc = obras.map(o => `${o.client_name} (${o.etapa ?? "—"})`).join(", ")
  }

  await prisma.aiAuditLog.create({
    data: {
      userId: u.userId, companyId: u.companyId, tipo_acesso: "DADOS",
      descricao: `Pergunta: ${message}`.slice(0, 480),
    },
  })

  /* A base da empresa vai por último de propósito: é a parte do prompt que o
     modelo lê mais perto da pergunta, e é dela que a resposta deve sair. */
  const contextoCompleto = [contexto, formatarResultados(web), formatarTrechos(trechos)]
    .filter(Boolean)
    .join("\n\n")
  const system = buildSystemPrompt(u, contextoCompleto, {
    nomeEmpresa: empresa?.nome_empresa || "a empresa",
    obrasDesc,
  })
  const messages: ChatMsg[] = [...history, { role: "user", content: message }]

  /* A resposta HTTP começa ANTES de o provedor responder.

     Antes o `await streamAI(...)` acontecia aqui fora, e enquanto ele não
     voltava o cliente não recebia byte nenhum. Isso passou a importar quando a
     chamada ganhou repetição no 429: o provedor manda esperar trinta segundos,
     o servidor espera calado, e o relógio de silêncio do chat — 45 s — dispara
     antes. Aparecia "O CORE parou de responder", e logo em seguida a resposta
     certa chegava. O usuário via um erro que não existia.

     Agora o canal abre na hora e manda um sinal de vida a cada dez segundos
     enquanto o provedor não responde. O relógio do cliente zera a cada sinal,
     que é o comportamento que ele já tinha para texto chegando. */
  const dec = new TextDecoder()
  const out = new ReadableStream<Uint8Array>({
    async start(controller) {
      let vivo = true
      const pulso = setInterval(() => {
        if (vivo) controller.enqueue(sse({ type: "aguardando" }))
      }, 10_000)

      let textStream: ReadableStream<Uint8Array>
      try {
        textStream = await streamAI(system, messages)
      } catch (e) {
        clearInterval(pulso); vivo = false
        controller.enqueue(sse({
          type: "error",
          message: e instanceof Error ? e.message : "Erro ao falar com a IA",
        }))
        controller.close()
        return
      }
      clearInterval(pulso); vivo = false

      const reader = textStream.getReader()
      try {
        for (;;) {
          const { done, value } = await reader.read()
          if (!done) {
            controller.enqueue(sse({ type: "text", delta: dec.decode(value) }))
            continue
          }
        /* As páginas consultadas vão junto do fim da resposta.

           O modelo cita [W1], [W2] no texto, mas o marcador sozinho não diz
           qual site é — e conferir a fonte é justamente o que separa uma
           especificação confiável de um número que a IA achou plausível. */
        if (web.length) {
          controller.enqueue(sse({
            type: "fontes",
            fontes: web
              .filter(f => f.url)
              .map((f, i) => ({ marcador: `W${i + 1}`, titulo: f.titulo, url: f.url })),
          }))
        }
          controller.enqueue(sse({ type: "done" }))
          controller.close()
          return
        }
      } catch (e) {
        /* Queda no meio da resposta precisa chegar a quem lê. Fechar em
           silêncio entregaria meia resposta como se fosse inteira. */
        controller.enqueue(sse({
          type: "error",
          message: e instanceof Error ? e.message : "A resposta foi interrompida.",
        }))
        controller.close()
      }
    },
  })

  return new Response(out, { headers: SSE_HEADERS })
}
