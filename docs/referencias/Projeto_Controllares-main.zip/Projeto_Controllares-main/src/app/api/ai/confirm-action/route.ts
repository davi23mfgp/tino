import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { olistFetch, OLIST_PATHS } from "@/lib/olist"
import { syncOlist, type NotaNorm } from "@/lib/olist-sync"
import { podeFinanceiro, type AiUser } from "@/lib/ai/scope"
import { executarAcaoSecretario, type TipoAcao } from "@/lib/ai/secretario"

/**
 * POST /api/ai/confirm-action  { acao, params }
 * Executa a ação SOMENTE após o usuário ter confirmado no chat.
 *
 * Ações:
 *  - emitir_nf, cancelar_nf   → exigem ADMIN/FINANCEIRO
 *  - criar_tarefa, agendar, concluir_tarefa, anotar_obra → secretário
 */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { acao, params } = await req.json().catch(() => ({}))

  if (acao === "emitir_nf" || acao === "cancelar_nf") {
    if (!podeFinanceiro(session.role)) {
      return NextResponse.json({ ok: false, message: "Você não tem permissão para emitir/cancelar NF." })
    }
    const numero: string | null = params?.numero ?? null
    if (!numero) {
      return NextResponse.json({ ok: false, message: "Não identifiquei o número. Use o painel Financeiro → Notas Fiscais." })
    }

    // Localiza a nota no cache do Olist pelo número
    const company = await prisma.company.findUnique({
      where: { id: session.companyId },
      select: { olist_cache_notas: true },
    })
    const notas = (company?.olist_cache_notas as unknown as NotaNorm[]) ?? []
    const nota = notas.find(n => n.numero === numero)
    if (!nota) {
      return NextResponse.json({ ok: false, message: `Não encontrei a NF nº ${numero} no Olist. Sincronize e tente pelo painel Financeiro.` })
    }

    try {
      const path = acao === "emitir_nf" ? OLIST_PATHS.emitirNota(nota.id) : OLIST_PATHS.cancelarNota(nota.id)
      await olistFetch(session.companyId, path, { method: "POST" })
      await prisma.webhookDebugLog.create({
        data: { companyId: session.companyId, endpoint: `ai/${acao}`, response_body: `NF ${numero} via assistente`, reenviado: false },
      })
      await syncOlist(session.companyId)
      return NextResponse.json({ ok: true, message: acao === "emitir_nf" ? `NF nº ${numero} emitida.` : `NF nº ${numero} cancelada.` })
    } catch (e) {
      return NextResponse.json({ ok: false, message: e instanceof Error ? e.message : "Erro na ação" })
    }
  }

  // ---- Ações de secretário: tarefa, agenda e nota na obra ----
  // Confirmação chega em outra requisição, então a permissão é revalidada
  // aqui dentro, não só quando a ação foi proposta.
  if (["criar_tarefa", "agendar", "concluir_tarefa", "anotar_obra"].includes(acao)) {
    const u: AiUser = {
      userId: session.userId, role: session.role, roles: session.roles ?? [],
      companyId: session.companyId, nome: session.nome,
    }
    const r = await executarAcaoSecretario(u, acao as TipoAcao, params ?? {})

    if (r.ok) {
      await prisma.aiAuditLog.create({
        data: {
          userId: session.userId, companyId: session.companyId, tipo_acesso: "CRIAR",
          descricao: `CORE executou "${acao}": ${r.message}`.slice(0, 480),
        },
      }).catch(() => {})
    }
    return NextResponse.json(r)
  }

  return NextResponse.json({ ok: false, message: "Ação não reconhecida." })
}
