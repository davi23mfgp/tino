import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { revelarCredencial, validarSenhaCofre, cofreConfigurado, type AiUser } from "@/lib/ai/scope"

/**
 * POST /api/ai/verify-sensitive  { query, password, tipo }
 *
 * A senha é a senha do COFRE configurada pelo Admin por perfil (vault_passwords na Company).
 * Não usa a senha de login do usuário.
 * 3 erros em sequência → bloqueia 10 min + notifica ADMIN.
 */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const u: AiUser = {
    userId: session.userId, role: session.role,
    companyId: session.companyId, nome: session.nome,
  }

  const { query, password: rawPassword, tipo = "padrao", soValida = false } = await req.json().catch(() => ({}))
  const password = String(rawPassword ?? "").trim() // espaço colado no mobile não pode invalidar
  if (!password) return NextResponse.json({ ok: false, message: "Senha obrigatória." })

  // ---- Bloqueio ativo? ----
  const rl = await prisma.aiRateLimit.findUnique({ where: { userId: u.userId } })
  if (rl?.bloqueado_ate && rl.bloqueado_ate > new Date()) {
    const min = Math.ceil((rl.bloqueado_ate.getTime() - Date.now()) / 60000)
    return NextResponse.json({ ok: false, locked: true, message: `Cofre bloqueado. Tente novamente em ${min} min.` })
  }

  if (!(await cofreConfigurado(u.companyId, u.role))) {
    return NextResponse.json({ ok: false, message: "Cofre não configurado para o seu perfil. O Admin define a senha em Configurações → Cofre." })
  }

  const senhaOk = await validarSenhaCofre(u.companyId, u.role, password)

  if (!senhaOk) {
    const tentativas = (rl?.tentativas_senha ?? 0) + 1
    if (tentativas >= 3) {
      const bloqueio = new Date(Date.now() + 10 * 60_000)
      await prisma.aiRateLimit.upsert({
        where: { userId: u.userId },
        create: { userId: u.userId, companyId: u.companyId, tentativas_senha: 0, bloqueado_ate: bloqueio },
        update: { tentativas_senha: 0, bloqueado_ate: bloqueio },
      })
      await prisma.webhookDebugLog.create({
        data: {
          companyId: u.companyId,
          endpoint: "ai/cofre-tentativas",
          response_body: `Usuário ${u.nome} teve 3 tentativas incorretas no CORE (tipo: ${tipo})`,
          reenviado: false,
        },
      })
      return NextResponse.json({ ok: false, locked: true, message: "Senha incorreta. Cofre bloqueado por 10 minutos." })
    }
    await prisma.aiRateLimit.upsert({
      where: { userId: u.userId },
      create: { userId: u.userId, companyId: u.companyId, tentativas_senha: tentativas },
      update: { tentativas_senha: tentativas },
    })
    return NextResponse.json({ ok: false, message: `Senha incorreta — use a senha do COFRE (definida pelo ADMIN em Configurações), não a sua senha de login. (${3 - tentativas} tentativa(s) restante(s))` })
  }

  // ---- Correta: zera tentativas ----
  await prisma.aiRateLimit.upsert({
    where: { userId: u.userId },
    create: { userId: u.userId, companyId: u.companyId, tentativas_senha: 0 },
    update: { tentativas_senha: 0 },
  })

  // ---- Só validar a senha (ex.: abrir anexo) — sem revelar credencial ----
  if (soValida) {
    await prisma.aiAuditLog.create({
      data: {
        userId: u.userId, companyId: u.companyId, tipo_acesso: "ANEXO",
        descricao: `Abriu documento sensível [${tipo}]`.slice(0, 480),
      },
    })
    return NextResponse.json({ ok: true, senhaOk: true })
  }

  // ---- Revela a credencial (RBAC controlado em scope.ts) ----
  const cred = await revelarCredencial(u, query ?? "")
  if (!cred.ok) {
    // Senha estava certa — o problema foi o MATCH. Lista o que existe para
    // o usuário tentar de novo pelo nome exato (em vez de re-pedir senha).
    const { filtroObras } = await import("@/lib/ai/scope")
    const where = filtroObras(u)
    let dica = ""
    if (where) {
      const obras = await prisma.obra.findMany({
        where, select: { client_name: true, credentials: { select: { tipo_equipamento: true } } }, take: 10,
      })
      const linhas = obras.filter(o => o.credentials.length)
        .map(o => `${o.client_name}: ${o.credentials.map(c => c.tipo_equipamento).join(", ")}`)
      if (linhas.length) dica = `\n\nCredenciais cadastradas no seu escopo:\n${linhas.join("\n")}\n\nTente pelo nome exato do equipamento.`
    }
    return NextResponse.json({ ok: false, senhaOk: true, message: `Senha correta, mas não encontrei essa credencial.${dica || "\n\nNenhuma credencial cadastrada no seu escopo."}` })
  }

  await prisma.aiAuditLog.create({
    data: {
      userId: u.userId, companyId: u.companyId, tipo_acesso: "CONFIDENCIAL",
      descricao: `Revelou credencial [${tipo}]: ${cred.descricao}`.slice(0, 480),
      obraId: cred.obraId ?? null,
    },
  })

  return NextResponse.json({ ok: true, content: cred.texto, expiresInSec: 30 })
}
