import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { temAlgumPerfil } from "@/lib/perfil"
import { prisma } from "@/lib/prisma"

/**
 * GET  /api/parceiros — lista todos os parceiros da empresa (com contagem de obras)
 * POST /api/parceiros — cadastra novo parceiro
 */
export async function GET(_req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  /* Parceiro é cadastro comercial: quem indica, quanto se paga de comissão e o
     contato de quem trouxe o negócio. Não é informação de campo, e o menu
     escondido não fecha a rota — quem souber a URL entra. */
  if (!temAlgumPerfil(session, ["ADMIN", "VENDEDOR", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Sem acesso a parceiros." }, { status: 403 })
  }


  const parceiros = await prisma.partnerStakeholder.findMany({
    where: { companyId: session.companyId },
    orderBy: { name: "asc" },
    include: {
      _count: { select: { workPartners: true } },
    },
  })

  return NextResponse.json({
    parceiros: parceiros.map(p => ({
      id: p.id,
      name: p.name,
      type: p.type,
      email: p.email,
      phone: p.phone,
      company_name: p.company_name,
      phone_responsavel: p.phone_responsavel,
      email_especificador: p.email_especificador,
      observacoes: p.observacoes,
      comissao_percentual: p.comissao_percentual ?? 0,
      total_obras: p._count.workPartners,
      createdAt: p.createdAt.toISOString(),
    })),
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  /* Parceiro é cadastro comercial: quem indica, quanto se paga de comissão e o
     contato de quem trouxe o negócio. Não é informação de campo, e o menu
     escondido não fecha a rota — quem souber a URL entra. */
  if (!temAlgumPerfil(session, ["ADMIN", "VENDEDOR", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Sem acesso a parceiros." }, { status: 403 })
  }


  const {
    name, type, email, phone, company_name,
    phone_responsavel, email_especificador, observacoes, comissao_percentual,
  } = await req.json()

  if (!name?.trim()) return NextResponse.json({ error: "Nome é obrigatório" }, { status: 400 })
  if (!type) return NextResponse.json({ error: "Tipo é obrigatório" }, { status: 400 })

  const parceiro = await prisma.partnerStakeholder.create({
    data: {
      companyId: session.companyId,
      name: name.trim(),
      type,
      email: email || null,
      phone: phone || null,
      company_name: company_name || null,
      phone_responsavel: phone_responsavel || null,
      email_especificador: email_especificador || null,
      observacoes: observacoes || null,
      comissao_percentual: comissao_percentual != null ? Number(comissao_percentual) : 0,
    },
  })

  return NextResponse.json(parceiro, { status: 201 })
}
