import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { temAlgumPerfil } from "@/lib/perfil"
import { prisma } from "@/lib/prisma"

/**
 * GET    /api/parceiros/[id] — detalhe + histórico de obras vinculadas
 * PATCH  /api/parceiros/[id] — edita parceiro
 * DELETE /api/parceiros/[id] — remove (só ADMIN)
 */
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  /* Parceiro é cadastro comercial: quem indica, quanto se paga de comissão e o
     contato de quem trouxe o negócio. Não é informação de campo, e o menu
     escondido não fecha a rota — quem souber a URL entra. */
  if (!temAlgumPerfil(session, ["ADMIN", "VENDEDOR", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Sem acesso a parceiros." }, { status: 403 })
  }


  const { id } = await params

  const parceiro = await prisma.partnerStakeholder.findFirst({
    where: { id, companyId: session.companyId },
    include: {
      workPartners: {
        include: {
          obra: {
            select: {
              id: true,
              client_name: true,
              etapa: true,
              cidade: true,
              logistics_status: true,
              createdAt: true,
            },
          },
        },
        orderBy: { obra: { createdAt: "desc" } },
      },
    },
  })

  if (!parceiro) return NextResponse.json({ error: "Parceiro não encontrado" }, { status: 404 })

  return NextResponse.json({
    ...parceiro,
    obras: parceiro.workPartners.map(wp => wp.obra),
    workPartners: undefined,
  })
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  /* Parceiro é cadastro comercial: quem indica, quanto se paga de comissão e o
     contato de quem trouxe o negócio. Não é informação de campo, e o menu
     escondido não fecha a rota — quem souber a URL entra. */
  if (!temAlgumPerfil(session, ["ADMIN", "VENDEDOR", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Sem acesso a parceiros." }, { status: 403 })
  }


  const { id } = await params
  const body = await req.json()

  const existing = await prisma.partnerStakeholder.findFirst({
    where: { id, companyId: session.companyId },
  })
  if (!existing) return NextResponse.json({ error: "Parceiro não encontrado" }, { status: 404 })

  const updated = await prisma.partnerStakeholder.update({
    where: { id },
    data: {
      ...(body.name !== undefined && { name: body.name }),
      ...(body.type !== undefined && { type: body.type }),
      ...(body.email !== undefined && { email: body.email || null }),
      ...(body.phone !== undefined && { phone: body.phone || null }),
      ...(body.company_name !== undefined && { company_name: body.company_name || null }),
      ...(body.phone_responsavel !== undefined && { phone_responsavel: body.phone_responsavel || null }),
      ...(body.email_especificador !== undefined && { email_especificador: body.email_especificador || null }),
      ...(body.observacoes !== undefined && { observacoes: body.observacoes || null }),
      ...(body.comissao_percentual !== undefined && { comissao_percentual: Number(body.comissao_percentual) || 0 }),
    },
  })

  return NextResponse.json(updated)
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  /* Parceiro é cadastro comercial: quem indica, quanto se paga de comissão e o
     contato de quem trouxe o negócio. Não é informação de campo, e o menu
     escondido não fecha a rota — quem souber a URL entra. */
  if (!temAlgumPerfil(session, ["ADMIN", "VENDEDOR", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Sem acesso a parceiros." }, { status: 403 })
  }

  if (session.role !== "ADMIN") return NextResponse.json({ error: "Sem permissão" }, { status: 403 })

  const { id } = await params

  const existing = await prisma.partnerStakeholder.findFirst({
    where: { id, companyId: session.companyId },
  })
  if (!existing) return NextResponse.json({ error: "Parceiro não encontrado" }, { status: 404 })

  await prisma.partnerStakeholder.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
