import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"

/**
 * GET /api/obras/[id] — dados completos de uma obra para o painel 360º.
 */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params

  const obra = await prisma.obra.findFirst({
    where: { id, companyId: session.companyId },
    include: {
      respTecnico: { select: { id: true, nome: true } },
      respComercial: { select: { id: true, nome: true } },
      // dias_garantia vem junto: a obra mostra quanto ainda resta de garantia.
      originProposal: { select: { id: true, numero: true, dias_garantia: true, anos_garantia: true } },
      proposals: { select: { id: true, numero: true, status: true, valor_total: true, createdAt: true } },
      environments: {
        include: {
          proposalItems: {
            select: {
              id: true, quantidade: true, is_aditivo: true,
              nome_snapshot: true, sku_snapshot: true,
              // Ambiente físico da obra ("Sala", "Suíte 2") — entidade, não texto.
              obraAmbienteId: true,
              product: { select: { nome: true, sku: true, imagem_url: true } },
              kit: { select: { nome: true } },
              category: { select: { nome: true } },
            },
          },
          _count: { select: { inspectionsMedia: true } },
        },
      },
    },
  })

  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  return NextResponse.json(obra)
}

// Campos editáveis pelo painel (lista branca — evita gravar lixo)
const CAMPOS_EDITAVEIS = [
  // "etapa" NÃO entra: espelha o kanban, só muda via PATCH /api/obras/[id]/etapa
  "client_name", "resp_tecnico_id", "tipo_projeto",
  "construtora", "previsao_inicio", "previsao_finalizacao_instalacao", "grupo_tipo",
  "colaboradores_ids", "compra_liberada",
  "capa_url", "foto_atual_url",
  "cep", "rua", "numero", "bairro", "cidade", "complemento", "ponto_referencia",
  "address", "latitude", "longitude",
  "acessos_externos", "relatorios_config", "agendamentos",
  "projetos_blueprints", "anexos", "anexos_projeto", "quadros", "dimensionamento", "consertos_lista", "notas",
  "checklist_tecnico",
  "telegram_chat_id",
  "posicoes_2d",
  "estudo_keypads", "estudo_infra",
] as const

/**
 * PATCH /api/obras/[id] — atualiza campos do painel da obra.
 */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const body = await req.json()

  const obra = await prisma.obra.findFirst({ where: { id, companyId: session.companyId } })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const data: Record<string, unknown> = {}
  for (const campo of CAMPOS_EDITAVEIS) {
    if (body[campo] !== undefined) {
      if (campo === "previsao_inicio") {
        data[campo] = body[campo] ? new Date(body[campo]) : null
      } else {
        data[campo] = body[campo]
      }
    }
  }

  const atualizada = await prisma.obra.update({ where: { id }, data })
  return NextResponse.json(atualizada)
}

/**
 * DELETE /api/obras/[id] — exclui a obra. Só ADMIN.
 *
 * Operação destrutiva e sem volta: leva junto ambientes, vistorias, quadros,
 * anexos e agendamentos por cascade. As propostas ligadas NÃO são apagadas —
 * apenas soltam o vínculo, para o histórico comercial continuar existindo.
 */
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin pode excluir uma obra." }, { status: 403 })
  }

  const { id } = await params
  const obra = await prisma.obra.findFirst({
    where: { id, companyId: session.companyId },
    select: { id: true, client_name: true },
  })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  await prisma.$transaction(async tx => {
    // Solta os vínculos antes: aditivos e a proposta de origem sobrevivem.
    await tx.proposal.updateMany({ where: { obraId: id }, data: { obraId: null } })
    await tx.obra.delete({ where: { id } })
  })

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "EXCLUIR",
      descricao: `Obra excluída: ${obra.client_name}`,
    },
  }).catch(() => {})

  return NextResponse.json({ success: true })
}
