import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { decrypt } from "@/lib/crypto"

/**
 * GET /api/obras/[id]/credenciais/[credId]/revelar
 * Descriptografa e devolve a senha em texto puro — só sob requisição explícita
 * (botão "revelar"). Valida multi-tenant antes.
 */
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string; credId: string }> }
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id, credId } = await params

  // Confirma que a obra é da empresa do usuário
  const obra = await prisma.obra.findFirst({ where: { id, companyId: session.companyId } })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const cred = await prisma.technicalCredential.findFirst({
    where: { id: credId, obraId: id },
  })
  if (!cred) return NextResponse.json({ error: "Credencial não encontrada" }, { status: 404 })

  try {
    return NextResponse.json({
      senha: cred.senha_criptografada ? decrypt(cred.senha_criptografada) : null,
      mac: cred.mac_criptografado ? decrypt(cred.mac_criptografado) : null,
      ip: cred.ip_criptografado ? decrypt(cred.ip_criptografado) : null,
    })
  } catch {
    return NextResponse.json({ error: "Falha ao descriptografar" }, { status: 500 })
  }
}
