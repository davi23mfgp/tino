import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * POST /api/obras/[id]/sync-ambientes
 * Liga os environments das propostas vinculadas a esta obra ao obraId.
 * Resolve casos onde o crossover rodou mas o link não foi gravado nos environments.
 */
export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (session.role !== "ADMIN") return NextResponse.json({ error: "Sem permissão" }, { status: 403 })

  const { id } = await params

  const obra = await prisma.obra.findFirst({
    where: { id, companyId: session.companyId },
    include: {
      proposals: { select: { id: true } },
      originProposal: { select: { id: true } },
    },
  })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  // Coleta todos os proposal IDs vinculados a esta obra
  const proposalIds = [
    ...(obra.originProposal ? [obra.originProposal.id] : []),
    ...obra.proposals.map((p) => p.id),
  ]

  if (proposalIds.length === 0) {
    return NextResponse.json({ synced: 0, message: "Obra sem propostas vinculadas" })
  }

  // Atualiza todos os environments dessas propostas para apontar para esta obra
  const result = await prisma.environment.updateMany({
    where: {
      proposalId: { in: proposalIds },
      obraId: null, // só os que ainda não estão ligados
    },
    data: { obraId: id },
  })

  return NextResponse.json({
    synced: result.count,
    message: result.count > 0
      ? `${result.count} ambiente(s) sincronizado(s) com sucesso.`
      : "Todos os ambientes já estavam sincronizados.",
  })
}
