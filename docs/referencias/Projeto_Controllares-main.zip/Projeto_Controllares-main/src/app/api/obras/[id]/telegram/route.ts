import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * POST /api/obras/[id]/telegram — { mensagem } → envia ao grupo da obra.
 * Requer Company.telegram_bot_token e Obra.telegram_chat_id configurados.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const { mensagem } = await req.json().catch(() => ({}))
  if (!mensagem?.trim()) return NextResponse.json({ error: "Mensagem vazia." }, { status: 400 })

  const [obra, company] = await Promise.all([
    prisma.obra.findFirst({
      where: { id, companyId: session.companyId },
      select: { client_name: true, telegram_chat_id: true },
    }),
    prisma.company.findUnique({
      where: { id: session.companyId },
      select: { telegram_bot_token: true },
    }),
  ])
  if (!obra) return NextResponse.json({ error: "Obra não encontrada." }, { status: 404 })
  if (!company?.telegram_bot_token) {
    return NextResponse.json({ error: "Bot do Telegram não configurado. Configurações → Integrações." }, { status: 422 })
  }
  if (!obra.telegram_chat_id) {
    return NextResponse.json({ error: "Esta obra não tem grupo do Telegram vinculado (chat_id). Configure no Resumo da obra." }, { status: 422 })
  }

  const r = await fetch(`https://api.telegram.org/bot${company.telegram_bot_token}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: obra.telegram_chat_id,
      text: `📋 ${obra.client_name}\n${mensagem.trim()}\n\n— ${session.nome} via Controllares`,
    }),
  })
  const j = await r.json().catch(() => ({}))
  if (!r.ok || !j.ok) {
    return NextResponse.json({ error: j.description || "Falha ao enviar no Telegram." }, { status: 502 })
  }

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "DADOS",
      descricao: `Telegram → ${obra.client_name}: ${String(mensagem).slice(0, 200)}`,
      obraId: id,
    },
  }).catch(() => {})

  return NextResponse.json({ ok: true })
}
