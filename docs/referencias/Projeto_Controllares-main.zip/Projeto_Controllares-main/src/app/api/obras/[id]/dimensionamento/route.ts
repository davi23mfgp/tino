import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSession } from '@/lib/session';
import { temAlgumPerfil } from '@/lib/perfil';

// GET /api/obras/[id]/dimensionamento
// Listar itens para dimensionamento agrupados por ambiente
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    const { id: obraId } = await params;

    // Obra precisa ser da empresa da sessão (multi-tenant)
    const obra = await prisma.obra.findFirst({
      where: { id: obraId, companyId: session.companyId },
      select: { id: true },
    });

    if (!obra) {
      return NextResponse.json(
        { error: 'Obra não encontrada' },
        { status: 404 }
      );
    }

    // Buscar itens já dimensionados
    const itensParaDimensionar = await prisma.obraItemDimensionamento.findMany({
      where: { obraId },
      orderBy: [{ ambiente: 'asc' }, { nome_item: 'asc' }],
    });

    /* Agrupa pelo ambiente FÍSICO da obra (obraAmbiente), não pelo "ambiente"
       da proposta — que hoje significa SISTEMA (automação, som, rede), a
       fatia que se vende.
       Só entra item já organizado: sem obraAmbienteId, ele nem aparece
       aqui. Isso é a trava de "obrigatório" prometida — quem monta o
       relatório de dimensionamento nunca trabalha em cima de lista
       desorganizada, porque a lista desorganizada nem chega até aqui.
       (A pendência aparece pra quem organiza, lá na aba Ambientes/Produtos
       e no card da obra no dashboard — não aqui, que é passo seguinte.) */
    const proposalItems = await prisma.proposalItem.findMany({
      where: { environment: { obraId }, obraAmbienteId: { not: null } },
      include: {
        obraAmbiente: true,
        product: true,
      },
      orderBy: [{ obraAmbiente: { nome: 'asc' } }, { nome_snapshot: 'asc' }],
    });

    // Agrupar por ambiente
    const ambienteMap = new Map<string, typeof proposalItems>();
    proposalItems.forEach((item) => {
      const ambienteName = item.obraAmbiente?.nome || 'Sem Ambiente';
      if (!ambienteMap.has(ambienteName)) {
        ambienteMap.set(ambienteName, []);
      }
      ambienteMap.get(ambienteName)!.push(item);
    });

    // Formatar resposta
    const dimensionamentoData = Array.from(ambienteMap).map(([ambiente, items]) => ({
      ambiente,
      itens: items.map((item) => {
        const jaAdicionado = itensParaDimensionar.find(
          (d) => d.proposalItemId === item.id
        );

        return {
          proposalItemId: item.id,
          nome_item: item.nome_snapshot || item.product?.nome || 'Item sem nome',
          sku: item.sku_snapshot || item.product?.sku || '',
          imagem_url: item.product?.imagem_url || null,
          quantidade: item.quantidade,
          // Dimensões do produto (catálogo)
          tipo_aplicacao: item.product?.tipo_aplicacao || null,
          formato_medida: item.product?.formato_medida || null,
          largura_mm: item.product?.largura_mm || null,
          altura_mm: item.product?.altura_mm || null,
          profundidade_mm: item.product?.profundidade_mm || null,
          especificacoes: item.product?.especificacoes || null,
          garantia_meses: item.product?.garantia_meses ?? null,
          // Se já foi dimensionado
          jaAdicionado: !!jaAdicionado,
          dimensionamento: jaAdicionado
            ? {
                id: jaAdicionado.id,
                valor_largura: jaAdicionado.valor_largura,
                valor_altura: jaAdicionado.valor_altura,
                valor_profundidade: jaAdicionado.valor_profundidade,
                valor_diametro: jaAdicionado.valor_diametro,
                formato_selecionado: jaAdicionado.formato_selecionado,
                incluir_relatorio: jaAdicionado.incluir_relatorio,
                notas_dimensionamento: jaAdicionado.notas_dimensionamento,
              }
            : null,
        };
      }),
    }));

    /* Quanto ainda falta organizar. O dimensionamento so trabalha em cima de
       item ja ligado a um ambiente fisico, entao produto solto nao aparece
       aqui — sumia sem explicacao, e quem media achava que a lista estava
       completa. Com o numero em maos a tela diz que falta organizar antes. */
    const semAmbiente = await prisma.proposalItem.count({
      where: { environment: { obraId }, obraAmbienteId: null },
    });

    return NextResponse.json({
      obraId,
      dimensionamento: dimensionamentoData,
      totalItens: proposalItems.length,
      semAmbiente,
    });
  } catch (error) {
    console.error('Erro ao buscar dimensionamento:', error);
    return NextResponse.json(
      { error: 'Erro ao buscar dimensionamento' },
      { status: 500 }
    );
  }
}

// POST /api/obras/[id]/dimensionamento
// Criar ou atualizar item de dimensionamento
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    const { id: obraId } = await params;
    const dono = await prisma.obra.findFirst({ where: { id: obraId, companyId: session.companyId }, select: { id: true } });
    if (!dono) return NextResponse.json({ error: 'Obra não encontrada' }, { status: 404 });
    const data = await request.json();

    const {
      proposalItemId,
      valor_largura,
      valor_altura,
      valor_profundidade,
      valor_diametro,
      formato_selecionado,
      incluir_relatorio,
      notas_dimensionamento,
      criado_por,
      gravarNoCatalogo,
    } = data;

    // Validações básicas
    if (!proposalItemId) {
      return NextResponse.json(
        { error: 'proposalItemId é obrigatório' },
        { status: 400 }
      );
    }

    // Buscar proposal item para pegar dados do produto
    const proposalItem = await prisma.proposalItem.findUnique({
      where: { id: proposalItemId },
      include: {
        product: true,
        obraAmbiente: true,
        proposal: true,
      },
    });

    if (!proposalItem) {
      return NextResponse.json(
        { error: 'ProposalItem não encontrado' },
        { status: 404 }
      );
    }

    // Verificar se já existe dimensionamento para este item
    const existente = await prisma.obraItemDimensionamento.findFirst({
      where: {
        obraId,
        proposalItemId,
      },
    });

    let resultado;

    if (existente) {
      // Atualizar
      resultado = await prisma.obraItemDimensionamento.update({
        where: { id: existente.id },
        data: {
          valor_largura,
          valor_altura,
          valor_profundidade,
          valor_diametro,
          formato_selecionado,
          incluir_relatorio,
          notas_dimensionamento,
        },
      });
    } else {
      // Criar
      resultado = await prisma.obraItemDimensionamento.create({
        data: {
          obraId,
          proposalItemId,
          productId: proposalItem.productId || 'unknown',
          nome_item: proposalItem.nome_snapshot || proposalItem.product?.nome || '',
          sku: proposalItem.sku_snapshot || proposalItem.product?.sku || '',
          ambiente: proposalItem.obraAmbiente?.nome || 'Sem Ambiente',
          tipo_aplicacao: proposalItem.product?.tipo_aplicacao || null,
          formato_medida: proposalItem.product?.formato_medida || null,
          largura_mm: proposalItem.product?.largura_mm || null,
          altura_mm: proposalItem.product?.altura_mm || null,
          profundidade_mm: proposalItem.product?.profundidade_mm || null,
          valor_largura,
          valor_altura,
          valor_profundidade,
          valor_diametro,
          formato_selecionado,
          incluir_relatorio: incluir_relatorio ?? true,
          notas_dimensionamento,
          criado_por,
        },
      });
    }

    /* A medida conferida na obra volta para o cadastro do produto.
       O cadastro vem do fornecedor e erra: quem mede o nicho na obra descobre
       o valor certo, corrigia na obra e a proxima obra recebia o errado de
       novo. Só o Admin grava, porque isto muda o catalogo inteiro, nao esta
       obra — e só quando ele pede, item por item. */
    if (gravarNoCatalogo && proposalItem.productId) {
      if (!temAlgumPerfil(session, ['ADMIN'])) {
        return NextResponse.json(
          { error: 'Só o Admin pode gravar a medida no catálogo.' },
          { status: 403 },
        );
      }
      /* A tela trabalha em cm e o cadastro guarda mm. */
      const mm = (v: unknown) => (v == null || v === '' ? null : Number(v) * 10);
      const circulo = formato_selecionado === 'Circulo' || formato_selecionado === 'Cilindro';
      const quadrado = formato_selecionado === 'Quadrado';
      await prisma.catalogProduct.update({
        where: { id: proposalItem.productId },
        data: {
          /* A obra chama de "Personalizado" o que o catálogo grava como "Outros". */
          formato_medida: formato_selecionado === 'Personalizado' ? 'Outros' : formato_selecionado || null,
          largura_mm: circulo ? mm(valor_diametro) : mm(valor_largura),
          altura_mm: circulo ? mm(valor_diametro) : quadrado ? mm(valor_largura) : mm(valor_altura),
          profundidade_mm: mm(valor_profundidade),
        },
      });
    }

    // Atualizar flag de dimensão_pronta no ProposalItem
    await prisma.proposalItem.update({
      where: { id: proposalItemId },
      data: { dimensao_pronta: true },
    });

    return NextResponse.json(resultado, { status: 201 });
  } catch (error) {
    console.error('Erro ao salvar dimensionamento:', error);
    return NextResponse.json(
      { error: 'Erro ao salvar dimensionamento' },
      { status: 500 }
    );
  }
}

// DELETE /api/obras/[id]/dimensionamento/[dimensionamentoId]
// Remover item de dimensionamento
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; dimensionamentoId?: string }> }
) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    const { id: obraId, dimensionamentoId } = await params;

    if (!dimensionamentoId) {
      return NextResponse.json(
        { error: 'dimensionamentoId é obrigatório' },
        { status: 400 }
      );
    }

    // Tenant: o registro precisa ser de obra da empresa da sessão
    const reg = await prisma.obraItemDimensionamento.findFirst({
      where: { id: dimensionamentoId, obraId, obra: { companyId: session.companyId } },
      select: { id: true },
    });
    if (!reg) return NextResponse.json({ error: 'Registro não encontrado' }, { status: 404 });

    await prisma.obraItemDimensionamento.delete({
      where: { id: dimensionamentoId },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Erro ao deletar dimensionamento:', error);
    return NextResponse.json(
      { error: 'Erro ao deletar dimensionamento' },
      { status: 500 }
    );
  }
}
