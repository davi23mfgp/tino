import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * Liga (ou desliga) um item da obra a um ambiente físico já criado.
 *
 * Antes era texto livre digitado por item — durou uma sessão. O pedido real
 * era o ambiente como entidade que se cria uma vez na obra (`/api/obras/[id]
 * /ambientes`) e se liga a vários produtos daqui.
 *
 * PATCH { itemId, obraAmbienteId } — obraAmbienteId null tira o item do
 * ambiente (volta pra fila de "sem ambiente").
 */
async function obraDaEmpresa(id: string, companyId: string) {
  return prisma.obra.findFirst({ where: { id, companyId }, select: { id: true } })
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!await obraDaEmpresa(id, session.companyId)) {
    return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })
  }

  const { itemId, obraAmbienteId } = await req.json()
  if (!itemId) return NextResponse.json({ error: "itemId é obrigatório" }, { status: 400 })

  /* O item precisa ser desta obra, não só existir.
     Sem esta checagem, um id de item de outra empresa passaria — o vínculo
     com a empresa vem do environment.obraId, o item sozinho não carrega
     companyId. */
  const item = await prisma.proposalItem.findFirst({
    where: { id: itemId, environment: { obraId: id } },
    select: { id: true },
  })
  if (!item) return NextResponse.json({ error: "Item não encontrado nesta obra" }, { status: 404 })

  if (obraAmbienteId) {
    const ambiente = await prisma.obraAmbiente.findFirst({
      where: { id: obraAmbienteId, obraId: id },
      select: { id: true },
    })
    if (!ambiente) return NextResponse.json({ error: "Ambiente não encontrado nesta obra" }, { status: 404 })
  }

  const atualizado = await prisma.proposalItem.update({
    where: { id: itemId },
    data: { obraAmbienteId: obraAmbienteId || null },
    select: { id: true, obraAmbienteId: true },
  })
  return NextResponse.json({ item: atualizado })
}
