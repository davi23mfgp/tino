import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

async function ambienteDaObra(obraId: string, ambienteId: string, companyId: string) {
  return prisma.obraAmbiente.findFirst({
    where: { id: ambienteId, obraId, obra: { companyId } },
    select: { id: true },
  })
}

/** PATCH { nome } — renomeia o ambiente. */
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string; ambienteId: string }> },
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id, ambienteId } = await params
  if (!await ambienteDaObra(id, ambienteId, session.companyId)) {
    return NextResponse.json({ error: "Ambiente não encontrado" }, { status: 404 })
  }

  const { nome } = await req.json()
  const texto = typeof nome === "string" ? nome.trim() : ""
  if (!texto) return NextResponse.json({ error: "Nome não pode ficar vazio" }, { status: 400 })

  const ambiente = await prisma.obraAmbiente.update({
    where: { id: ambienteId },
    data: { nome: texto },
    select: { id: true, nome: true },
  })
  return NextResponse.json({ ambiente })
}

/** DELETE — remove o ambiente. Os produtos NÃO somem: voltam pra fila de
 *  "sem ambiente" (FK é SetNull), porque apagar a organização não pode
 *  apagar o que já foi levantado da proposta. */
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string; ambienteId: string }> },
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id, ambienteId } = await params
  if (!await ambienteDaObra(id, ambienteId, session.companyId)) {
    return NextResponse.json({ error: "Ambiente não encontrado" }, { status: 404 })
  }

  await prisma.obraAmbiente.delete({ where: { id: ambienteId } })
  return NextResponse.json({ ok: true })
}
