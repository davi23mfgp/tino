import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * GET /api/obras/[id]/automacao/exportar?tipo=teclas|modulos|ir|rede|tudo
 * Exporta o quadro de automação em CSV (separador ";" + BOM p/ Excel pt-BR).
 */
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return new NextResponse("Não autorizado", { status: 401 })
  const { id } = await params

  const obra = await prisma.obra.findFirst({
    where: { id, companyId: session.companyId },
    select: { id: true, client_name: true },
  })
  if (!obra) return new NextResponse("Obra não encontrada", { status: 404 })

  const tipo = (new URL(req.url).searchParams.get("tipo") ?? "tudo").toLowerCase()

  // Escapa e evita injeção de fórmula no Excel.
  const cel = (v: unknown) => {
    const s = v == null ? "" : String(v)
    return `"${(/^[=+\-@]/.test(s) ? "'" + s : s).replace(/"/g, '""')}"`
  }
  const linha = (arr: unknown[]) => arr.map(cel).join(";")
  const bloco: string[] = []

  if (tipo === "teclas" || tipo === "tudo") {
    const keypads = await prisma.keypad.findMany({ where: { obraId: id }, orderBy: [{ ordem: "asc" }] })
    if (keypads.length) {
      if (tipo === "tudo") bloco.push("ESTUDO DE TECLAS")
      bloco.push(linha(["Setor", "Ambiente", "Keypad", "Acabamento", "Medida", "Teclas automação", "Compra pulsadores", "Ligar junto", "Circuitos", "Observação"]))
      for (const k of keypads) {
        bloco.push(linha([k.setor, k.ambiente, k.codigo.startsWith("—") ? "" : k.codigo, k.acabamento, k.medida,
          k.teclas_automacao, k.pulsadores_compra, k.ligar_junto, k.circuitos.join(" / "), k.observacao]))
      }
      if (tipo === "tudo") bloco.push("")
    }
  }

  // Módulos, IR e Rede saem da mesma tabela — o filtro decide quais tipos entram.
  if (["modulos", "ir", "rede", "tudo"].includes(tipo)) {
    const tiposDoBloco =
      tipo === "ir" ? ["IR"]
      : tipo === "rede" ? ["REDE"]
      : tipo === "modulos" ? ["RELAY", "DIMMER", null]
      : null // "tudo" não filtra

    const quadros = await prisma.automacaoQuadro.findMany({
      where: { obraId: id }, orderBy: { ordem: "asc" },
      include: { modulos: { orderBy: { ordem: "asc" }, include: { entradas: { orderBy: { ordem: "asc" } }, saidas: { orderBy: { ordem: "asc" } } } } },
    })

    const linhasModulos = quadros.flatMap(q =>
      q.modulos
        .filter(m => !tiposDoBloco || tiposDoBloco.includes(m.tipo))
        .map(m => ({ quadro: q.nome, m })))

    if (linhasModulos.length) {
      if (tipo === "tudo") bloco.push("MÓDULOS · IR · REDE")
      bloco.push(linha(["Quadro", "Pavimento", "Módulo", "Tipo", "Linha", "Nº", "Descrição / Keypads", "Equipamento", "Ambiente", "Circuito", "Grupo"]))
      for (const { quadro, m } of linhasModulos) {
        // Vocabulário por tipo: saída (carga), emissor (IR), porta (rede).
        const rotuloSaida = m.tipo === "IR" ? "Emissor" : m.tipo === "REDE" ? "Porta" : "Saída"
        for (const e of m.entradas) {
          bloco.push(linha([quadro, m.pavimento, m.nome, m.tipo, "Entrada", e.numero, e.keypads.join(" + "), "", "", "", e.grupo]))
        }
        for (const s of m.saidas) {
          bloco.push(linha([quadro, m.pavimento, m.nome, m.tipo, rotuloSaida, s.numero, s.descricao, s.tipo_carga, s.ambiente, s.circuito, s.grupo]))
        }
      }
      if (tipo === "tudo") bloco.push("")
    }
  }

  // Pontos avulsos são o formato antigo de IR/Rede: só sai se ainda houver dado.
  if (tipo === "ir" || tipo === "rede" || tipo === "tudo") {
    const filtro = tipo === "tudo" ? {} : { tipo: tipo === "ir" ? "IR" : "REDE" }
    const pontos = await prisma.automacaoPonto.findMany({
      where: { obraId: id, ...filtro }, orderBy: [{ tipo: "asc" }, { ordem: "asc" }],
    })
    if (pontos.length) {
      if (tipo === "tudo") bloco.push("IR / REDE (pontos avulsos)")
      bloco.push(linha(["Tipo", "Código", "Ambiente", "Setor", "Equipamento", "Descrição", "Porta/Saída", "IP", "Grupo", "Observação"]))
      for (const p of pontos) {
        bloco.push(linha([p.tipo, p.codigo, p.ambiente, p.setor, p.equipamento, p.descricao, p.porta, p.ip, p.grupo, p.observacao]))
      }
    }
  }

  const csv = "﻿" + (bloco.length ? bloco.join("\r\n") : "Sem dados para exportar.")
  const nome = `automacao-${obra.client_name.replace(/[^\w]+/g, "-").toLowerCase()}-${tipo}.csv`
  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${nome}"`,
    },
  })
}
