import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { writeFile, mkdir } from "fs/promises"
import path from "path"

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const formData = await req.formData()
  const file = formData.get("file") as File | null
  const obraId = formData.get("obraId") as string | null
  const ambiente = formData.get("ambiente") as string | null

  if (!file || !obraId) {
    return NextResponse.json({ error: "file e obraId obrigatórios" }, { status: 400 })
  }

  // Verifica acesso à obra
  const obra = await prisma.obra.findFirst({
    where: { id: obraId, companyId: session.companyId },
    select: { id: true },
  })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  // Salva o arquivo em /public/uploads/<companyId>/<obraId>/
  const bytes = await file.arrayBuffer()
  const buffer = Buffer.from(bytes)
  const dir = path.join(process.cwd(), "public", "uploads", session.companyId, obraId)
  await mkdir(dir, { recursive: true })

  const filename = file.name.replace(/[^a-z0-9.\-_]/gi, "_")
  await writeFile(path.join(dir, filename), buffer)

  const url = `/uploads/${session.companyId}/${obraId}/${filename}`

  // Registra no log de auditoria
  await prisma.webhookDebugLog.create({
    data: {
      companyId: session.companyId,
      endpoint: "vistoria-foto",
      response_body: JSON.stringify({ userId: session.userId, obraId, ambiente, url }),
      reenviado: false,
    },
  })

  return NextResponse.json({ ok: true, url })
}
