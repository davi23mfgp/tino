import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * Tarefas do cronograma/Gantt (tabela gantt_tasks).
 * Raias: CONSTRUTORA | EMPRESA | TERCEIROS
 * GET / POST { titulo, raia, data_inicio, data_fim } / DELETE { taskId }
 */
const RAIAS = ["CONSTRUTORA", "EMPRESA", "TERCEIROS"]

async function obraDaEmpresa(id: string, companyId: string) {
  return prisma.obra.findFirst({ where: { id, companyId } })
}

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!await obraDaEmpresa(id, session.companyId)) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const tasks = await prisma.ganttTask.findMany({
    where: { obraId: id },
    orderBy: { data_inicio: "asc" },
  })
  return NextResponse.json({ tasks: tasks.map(t => ({
    id: t.id, titulo: t.titulo, raia: t.raia,
    data_inicio: t.data_inicio.toISOString().split("T")[0],
    data_fim: t.data_fim.toISOString().split("T")[0],
  })) })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!await obraDaEmpresa(id, session.companyId)) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const { titulo, raia, data_inicio, data_fim } = await req.json()
  if (!titulo || !data_inicio || !data_fim) {
    return NextResponse.json({ error: "Título, início e fim são obrigatórios" }, { status: 400 })
  }
  const raiaFinal = RAIAS.includes(raia) ? raia : "EMPRESA"

  const t = await prisma.ganttTask.create({
    data: {
      obraId: id,
      titulo,
      raia: raiaFinal,
      data_inicio: new Date(data_inicio),
      data_fim: new Date(data_fim),
    },
  })
  return NextResponse.json({ id: t.id }, { status: 201 })
}

/** PATCH { taskId, titulo?, raia?, data_inicio?, data_fim? } — edita uma tarefa existente. */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!await obraDaEmpresa(id, session.companyId)) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const { taskId, titulo, raia, data_inicio, data_fim } = await req.json()
  if (!taskId) return NextResponse.json({ error: "taskId é obrigatório" }, { status: 400 })

  const existing = await prisma.ganttTask.findFirst({ where: { id: taskId, obraId: id } })
  if (!existing) return NextResponse.json({ error: "Tarefa não encontrada" }, { status: 404 })

  const data: Record<string, unknown> = {}
  if (typeof titulo === "string" && titulo.trim()) data.titulo = titulo.trim()
  if (RAIAS.includes(raia)) data.raia = raia
  if (data_inicio) data.data_inicio = new Date(data_inicio)
  if (data_fim) data.data_fim = new Date(data_fim)

  await prisma.ganttTask.update({ where: { id: taskId }, data })
  return NextResponse.json({ success: true })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!await obraDaEmpresa(id, session.companyId)) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const { taskId } = await req.json()
  await prisma.ganttTask.deleteMany({ where: { id: taskId, obraId: id } })
  return NextResponse.json({ success: true })
}
