import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { validarSenhaCofreComTrava, cofreConfigurado } from "@/lib/ai/scope"

/**
 * GET  /api/obras/[id]/anexos — lista anexos da obra
 * POST /api/obras/[id]/anexos — adiciona anexo (valida senha do cofre)
 */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const obra = await prisma.obra.findFirst({ where: { id, companyId: session.companyId } })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const anexos = (obra.anexos as Record<string, unknown>[] | null) ?? []
  return NextResponse.json({ anexos })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const { password, nome, url, ext, tamanho } = await req.json().catch(() => ({}))

  if (!password || !nome || !url) {
    return NextResponse.json({ ok: false, message: "Dados incompletos." }, { status: 400 })
  }

  // Sem cofre configurado o acesso é negado, mas com o motivo certo — antes
  // existia uma senha padrão no código, e negar sem explicar viraria suporte.
  if (!(await cofreConfigurado(session.companyId, session.role))) {
    return NextResponse.json({ ok: false, message: "Cofre não configurado para o seu perfil. O Admin define a senha em Configurações → Cofre." })
  }
  const tentativa = await validarSenhaCofreComTrava(session.userId, session.companyId, session.role, password)
  if (tentativa.bloqueadoMin > 0) {
    return NextResponse.json({ ok: false, message: `Muitas tentativas. Aguarde ${tentativa.bloqueadoMin} min.` })
  }
  if (!tentativa.ok) return NextResponse.json({ ok: false, message: "Senha incorreta." })

  const obra = await prisma.obra.findFirst({ where: { id, companyId: session.companyId } })
  if (!obra) return NextResponse.json({ ok: false, message: "Obra não encontrada." })

  const anexos = (obra.anexos as Record<string, unknown>[] | null) ?? []
  const novoAnexo = {
    id: `anx_${Date.now()}`,
    nome,
    url,
    ext: ext ?? nome.split(".").pop()?.toLowerCase() ?? "",
    tamanho: tamanho ?? null,
    createdAt: new Date().toISOString(),
  }

  await prisma.obra.update({
    where: { id },
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    data: { anexos: [...anexos, novoAnexo] as any },
  })

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId,
      companyId: session.companyId,
      tipo_acesso: "CRIAR",
      descricao: `Adicionou documento "${nome}" na obra ${obra.client_name}`.slice(0, 480),
      obraId: id,
    },
  })

  return NextResponse.json({ ok: true, anexo: novoAnexo })
}
