import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * Ambientes físicos da obra ("Sala", "Suíte 2", "Varanda") — criados aqui,
 * não digitados item a item. Cada produto sincronizado da proposta é ligado
 * a um destes.
 *
 * GET  — lista os ambientes com seus itens já atribuídos, mais a fila de
 *        produtos ainda sem ambiente.
 * POST { nome } — cria um ambiente novo.
 */

async function obraDaEmpresa(id: string, companyId: string) {
  return prisma.obra.findFirst({ where: { id, companyId }, select: { id: true } })
}

const ITEM_SELECT = {
  id: true, quantidade: true, is_aditivo: true,
  nome_snapshot: true,
  product: { select: { nome: true, sku: true, imagem_url: true } },
  kit: { select: { nome: true } },
} as const

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!await obraDaEmpresa(id, session.companyId)) {
    return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })
  }

  const [ambientes, semAmbiente] = await Promise.all([
    prisma.obraAmbiente.findMany({
      where: { obraId: id },
      orderBy: { createdAt: "asc" },
      select: { id: true, nome: true, createdAt: true, itens: { select: ITEM_SELECT } },
    }),
    prisma.proposalItem.findMany({
      where: { environment: { obraId: id }, obraAmbienteId: null },
      select: ITEM_SELECT,
    }),
  ])

  return NextResponse.json({ ambientes, semAmbiente })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!await obraDaEmpresa(id, session.companyId)) {
    return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })
  }

  const { nome } = await req.json()
  const texto = typeof nome === "string" ? nome.trim() : ""
  if (!texto) return NextResponse.json({ error: "Nome do ambiente é obrigatório" }, { status: 400 })

  const ambiente = await prisma.obraAmbiente.create({
    data: { obraId: id, nome: texto },
    select: { id: true, nome: true, createdAt: true },
  })
  return NextResponse.json({ ambiente: { ...ambiente, itens: [] } }, { status: 201 })
}
