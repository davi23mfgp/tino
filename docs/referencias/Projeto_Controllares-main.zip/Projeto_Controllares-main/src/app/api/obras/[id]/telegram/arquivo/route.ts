import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { enviarArquivo, tokenDaEmpresa } from "@/lib/telegram"
import { get } from "@vercel/blob"

/**
 * POST /api/obras/[id]/telegram/arquivo
 *
 * Manda um arquivo para o grupo da obra. Aceita duas formas:
 *   - multipart com `file`: upload direto da tela
 *   - JSON `{ url, nome }`: reenvia um anexo que já está no sistema
 *
 * No caso da URL, o arquivo é baixado aqui e reenviado como upload: a Blob
 * Store pode ser privada, e nesse caso o Telegram não conseguiria buscar
 * sozinho.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const obra = await prisma.obra.findFirst({
    where: { id, companyId: session.companyId },
    select: { client_name: true, telegram_chat_id: true },
  })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada." }, { status: 404 })
  if (!obra.telegram_chat_id) {
    return NextResponse.json(
      { error: "Esta obra não tem grupo vinculado. Adicione o bot ao grupo ou faça o vínculo em Integrações." },
      { status: 422 },
    )
  }

  const token = await tokenDaEmpresa(session.companyId)
  if (!token) {
    return NextResponse.json({ error: "Bot do Telegram não configurado." }, { status: 422 })
  }

  const tipo = req.headers.get("content-type") ?? ""
  let nome = "arquivo"
  let conteudo: Blob
  let legenda = ""

  try {
    if (tipo.includes("multipart/form-data")) {
      const form = await req.formData()
      const f = form.get("file") as File | null
      if (!f) return NextResponse.json({ error: "Nenhum arquivo enviado." }, { status: 400 })
      if (f.size > 45 * 1024 * 1024) {
        return NextResponse.json({ error: "O Telegram aceita até 50 MB por arquivo." }, { status: 413 })
      }
      nome = f.name
      conteudo = f
      legenda = String(form.get("legenda") || "")
    } else {
      const body = await req.json()
      const url = String(body.url || "")
      if (!url) return NextResponse.json({ error: "Informe o arquivo." }, { status: 400 })
      nome = String(body.nome || url.split("/").pop() || "arquivo")
      legenda = String(body.legenda || "")

      const blobToken =
        process.env.BLOB_READ_WRITE_TOKEN ||
        Object.entries(process.env).find(([k]) => k.endsWith("_READ_WRITE_TOKEN"))?.[1]

      let baixado: Blob | null = null
      const r = await fetch(url).catch(() => null)
      if (r?.ok) {
        baixado = await r.blob()
      } else if (blobToken && /(^|\.)blob\.vercel-storage\.com$/i.test(new URL(url).hostname)) {
        // Store privada: um GET comum devolve 403, só o get() do SDK entrega.
        const priv = await get(url, { access: "private", token: blobToken }).catch(() => null)
        if (priv?.statusCode === 200) baixado = await new Response(priv.stream).blob()
      }
      if (!baixado) return NextResponse.json({ error: "Não consegui baixar o arquivo." }, { status: 502 })
      conteudo = baixado
    }
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Falha ao preparar o arquivo." },
      { status: 400 },
    )
  }

  const r = await enviarArquivo(token, obra.telegram_chat_id, { nome, conteudo },
    `${obra.client_name}${legenda ? `\n${legenda}` : ""}\n— ${session.nome} via Controllares`)

  if (!r.ok) return NextResponse.json({ error: `Telegram: ${r.erro}` }, { status: 502 })

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "ANEXO",
      descricao: `Telegram → ${obra.client_name}: enviou "${nome}"`.slice(0, 480),
      obraId: id,
    },
  }).catch(() => {})

  return NextResponse.json({ ok: true })
}
