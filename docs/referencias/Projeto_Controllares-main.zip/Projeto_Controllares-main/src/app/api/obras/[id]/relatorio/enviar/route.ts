import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { enviarEmail } from "@/lib/email"
import { emailRelatorioObra, emailConteudoObra } from "@/lib/email-templates"

export const dynamic = "force-dynamic"

/**
 * POST /api/obras/[id]/relatorio/enviar — manda informação da obra por
 * e-mail, na hora, pro(s) endereço(s) informado(s).
 *
 * Mesmo padrão do contrato (/api/propostas/[id]/contrato/enviar): antes a
 * aba "Relatórios" só salvava a preferência e o envio de verdade nunca saiu
 * do papel — quem precisava mandar informação pra fora do sistema tirava
 * print e mandava por WhatsApp.
 *
 * Rota genérica de propósito — não é só "o relatório de andamento", é
 * qualquer conteúdo útil da obra que faça sentido compartilhar (o pedido foi
 * literal: "tudo que for informação útil que possa ser compartilhada"). Sem
 * `titulo`/`corpoHtml`, cai no resumo padrão de andamento (etapa + %); com
 * eles, manda o conteúdo que o chamador montou — é o que o Dimensionamento
 * usa, reaproveitando o mesmo HTML que já gera pro "Imprimir / PDF".
 *
 * { emails: string[], titulo?: string, corpoHtml?: string }
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const { emails, titulo, corpoHtml, anexo } = await req.json().catch(() => ({} as Record<string, unknown>))

  /* Anexo opcional (o Dimensionamento manda o relatório em PDF). Só PDF, até
     ~10 MB: e-mail maior que isso costuma ser barrado pelo provedor de quem recebe. */
  let attachments: { filename: string; content: string }[] | undefined
  if (anexo && typeof anexo === "object") {
    const { nome, base64 } = anexo as { nome?: unknown; base64?: unknown }
    if (typeof nome !== "string" || !/\.pdf$/i.test(nome) || typeof base64 !== "string" || !/^[A-Za-z0-9+/=]+$/.test(base64)) {
      return NextResponse.json({ error: "Anexo inválido." }, { status: 422 })
    }
    if (base64.length > 14_000_000) {
      return NextResponse.json({ error: "O PDF ficou grande demais para enviar por e-mail." }, { status: 413 })
    }
    attachments = [{ filename: nome.replace(/[\r\n"]/g, "").slice(0, 120), content: base64 }]
  }

  const destinos = Array.isArray(emails)
    ? [...new Set(emails.map((e: unknown) => String(e).trim().toLowerCase()).filter(Boolean))]
    : []
  if (destinos.length === 0) {
    return NextResponse.json({ error: "Informe ao menos um e-mail para enviar." }, { status: 422 })
  }

  const obra = await prisma.obra.findFirst({
    where: { id, companyId: session.companyId },
    include: {
      company: { select: { nome_empresa: true } },
      respTecnico: { select: { nome: true, email: true } },
    },
  })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const respTecnico = obra.respTecnico ? { nome: obra.respTecnico.nome, email: obra.respTecnico.email } : null

  const usarConteudoCustom = typeof titulo === "string" && titulo.trim()
    && ((typeof corpoHtml === "string" && corpoHtml.trim()) || attachments)
  const { subject, html } = usarConteudoCustom
    ? emailConteudoObra({
        titulo: titulo.trim(),
        clientName: obra.client_name,
        corpoHtml: typeof corpoHtml === "string" ? corpoHtml : "",
        emAnexo: !!attachments,
        empresa: obra.company.nome_empresa,
        respTecnico,
      })
    : emailRelatorioObra({
        clientName: obra.client_name,
        etapa: obra.etapa,
        progresso: obra.physical_progress_percentage,
        empresa: obra.company.nome_empresa,
        respTecnico,
      })

  const ok = await enviarEmail({ to: destinos, subject, html, attachments })
  if (!ok) {
    return NextResponse.json(
      { error: "O envio falhou. Confira a configuração de e-mail em Integrações." },
      { status: 502 },
    )
  }

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "EDITAR",
      descricao: `${usarConteudoCustom ? titulo!.trim() : "Relatório de andamento"} da obra ${obra.client_name} enviado para ${destinos.join(", ")}`,
    },
  }).catch(() => {})

  return NextResponse.json({ ok: true, destinos })
}
