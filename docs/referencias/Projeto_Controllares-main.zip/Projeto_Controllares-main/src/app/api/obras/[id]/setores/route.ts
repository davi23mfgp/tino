import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { chamarAI } from "@/lib/ai/llm"

const SETORES = ["SOCIAL", "ÍNTIMO", "SERVIÇO", "EXTERNO"]

/**
 * POST /api/obras/[id]/setores  { ambientes: string[] }
 *
 * Classifica o setor (social, íntimo, serviço, externo) de cada ambiente para
 * a planilha de keypads. É a única coisa que a IA faz no estudo: tarefa de
 * texto, curta, que ela acerta. O resultado passa por uma lista fechada —
 * qualquer coisa fora dos quatro setores é descartada.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  const obra = await prisma.obra.findFirst({ where: { id, companyId: session.companyId }, select: { id: true } })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const body = (await req.json().catch(() => ({}))) as { ambientes?: unknown }
  const ambientes = Array.isArray(body.ambientes)
    ? [...new Set(body.ambientes.map((a) => String(a).trim().toUpperCase()).filter(Boolean))].slice(0, 80)
    : []
  if (!ambientes.length) return NextResponse.json({ setores: {} })

  const system =
    "Você classifica ambientes de uma residência para um projeto de automação. " +
    "Responda SÓ com JSON, sem texto antes ou depois."
  const pedido =
    `Classifique cada ambiente em exatamente um destes setores: ${SETORES.join(", ")}.\n` +
    `Ambientes: ${JSON.stringify(ambientes)}\n` +
    `Formato: {"setores":{"NOME DO AMBIENTE":"SETOR"}}`

  try {
    const texto = await chamarAI([{ role: "user", content: pedido }], system)
    const json = texto.slice(texto.indexOf("{"), texto.lastIndexOf("}") + 1)
    const bruto = (JSON.parse(json) as { setores?: Record<string, string> }).setores ?? {}
    const setores: Record<string, string> = {}
    for (const a of ambientes) {
      const s = String(bruto[a] ?? "").toUpperCase().normalize("NFC")
      if (SETORES.includes(s)) setores[a] = s
    }
    return NextResponse.json({ setores })
  } catch (e) {
    const msg = e instanceof Error ? e.message : "erro"
    const limite = /429|rate|limit/i.test(msg)
    return NextResponse.json(
      { error: limite ? "A IA está no limite de uso agora; tente em 1 minuto." : "A IA não respondeu agora." },
      { status: limite ? 429 : 502 }
    )
  }
}
