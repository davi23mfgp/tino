import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * GET /api/obras/[id]/keypads-catalogo
 *
 * Keypads ativos do catálogo (categoria "Keypads") para o Estudo de keypads.
 * `daObra` marca os que já estão nas propostas desta obra — a tela mostra
 * esses primeiro, porque normalmente é o modelo que foi vendido.
 */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params

  const obra = await prisma.obra.findFirst({ where: { id, companyId: session.companyId }, select: { id: true } })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const produtos = await prisma.catalogProduct.findMany({
    where: { companyId: session.companyId, status: "ATIVO", category: { nome: "Keypads" } },
    select: { sku: true, marca: true, nome: true, nome_cliente: true, imagem_url: true },
    orderBy: [{ marca: "asc" }, { nome: "asc" }],
  })

  const itens = await prisma.proposalItem.findMany({
    where: {
      OR: [{ proposal: { obraId: id } }, { environment: { obraId: id } }],
      product: { category: { nome: "Keypads" } },
    },
    select: { product: { select: { sku: true } } },
  })
  const daObra = new Set(itens.map((i) => i.product?.sku).filter(Boolean))

  return NextResponse.json(
    produtos.map((p) => ({
      sku: p.sku,
      marca: p.marca ?? "",
      nome: p.nome,
      nomeCliente: p.nome_cliente ?? "",
      img: p.imagem_url ?? "",
      daObra: daObra.has(p.sku),
    }))
  )
}
