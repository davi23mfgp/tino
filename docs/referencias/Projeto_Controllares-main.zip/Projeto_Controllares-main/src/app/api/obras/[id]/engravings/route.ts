import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * Gravações a laser de keypads (tabela keypad_engravings).
 * GET / POST { environmentId?, descricao_botao, posicao } / DELETE { engravingId }
 */
async function obraDaEmpresa(id: string, companyId: string) {
  return prisma.obra.findFirst({ where: { id, companyId } })
}

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!await obraDaEmpresa(id, session.companyId)) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const engravings = await prisma.keypadEngraving.findMany({
    where: { obraId: id },
    orderBy: { posicao: "asc" },
    include: { environment: { select: { nome: true } } },
  })
  return NextResponse.json({ engravings: engravings.map(e => ({
    id: e.id, descricao_botao: e.descricao_botao, posicao: e.posicao,
    environment_nome: e.environment?.nome ?? null,
  })) })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!await obraDaEmpresa(id, session.companyId)) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const { environmentId, descricao_botao, posicao } = await req.json()
  if (!descricao_botao) return NextResponse.json({ error: "Descrição do botão é obrigatória" }, { status: 400 })

  const e = await prisma.keypadEngraving.create({
    data: {
      obraId: id,
      environmentId: environmentId || null,
      descricao_botao,
      posicao: Number(posicao) || 0,
    },
  })
  return NextResponse.json({ id: e.id }, { status: 201 })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!await obraDaEmpresa(id, session.companyId)) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const { engravingId } = await req.json()
  await prisma.keypadEngraving.deleteMany({ where: { id: engravingId, obraId: id } })
  return NextResponse.json({ success: true })
}
