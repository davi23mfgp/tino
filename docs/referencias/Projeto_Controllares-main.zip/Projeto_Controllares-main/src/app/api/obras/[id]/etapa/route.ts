import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

const ETAPAS_OBRA = [
  "Nova obra", "Ampliação", "Em projeto", "Em tubulações",
  "Em cabeamentos", "Em instalação", "Em programação", "Em entrega",
]

/**
 * PATCH /api/obras/[id]/etapa
 * Move a obra no Kanban de Obras/Instalações.
 * Atualiza Obra.etapa e registra a transição em ProjectStage.
 */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const { etapa } = await req.json()

  if (!etapa || !ETAPAS_OBRA.includes(etapa)) {
    return NextResponse.json({ error: "Etapa inválida" }, { status: 400 })
  }

  const obra = await prisma.obra.findFirst({ where: { id, companyId: session.companyId } })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  if (obra.etapa === etapa) return NextResponse.json({ success: true, unchanged: true })

  /* Check de instalação: é aqui que a garantia começa a correr.
     Grava só na primeira vez — se a obra voltar e entrar em instalação de novo,
     o prazo do cliente não pode reiniciar. */
  const iniciaGarantia = etapa === "Em instalação" && !obra.data_inicio_garantia

  await prisma.$transaction([
    prisma.obra.update({
      where: { id },
      data: { etapa, ...(iniciaGarantia && { data_inicio_garantia: new Date() }) },
    }),
    prisma.projectStage.create({
      data: {
        obraId: id,
        etapa_anterior: obra.etapa,
        etapa_nova: etapa,
        changed_by: session.userId,
      },
    }),
  ])

  return NextResponse.json({ success: true, etapa, garantiaIniciada: iniciaGarantia })
}
