import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

const ETAPAS_PROJETO = [
  "Novo projeto", "Croquis", "Desenho Técnico", "Em conferência", "Alterações",
]

/**
 * PATCH /api/obras/[id]/etapa-projeto
 * Move a obra no Kanban de Projetos/Engenharia.
 * Atualiza Obra.etapa_projeto e registra a transição em ProjectStage
 * (com prefixo "Projeto:" para distinguir do trilho da obra física).
 */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const { etapa_projeto } = await req.json()

  if (!etapa_projeto || !ETAPAS_PROJETO.includes(etapa_projeto)) {
    return NextResponse.json({ error: "Etapa de projeto inválida" }, { status: 400 })
  }

  const obra = await prisma.obra.findFirst({ where: { id, companyId: session.companyId } })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  if (obra.etapa_projeto === etapa_projeto) return NextResponse.json({ success: true, unchanged: true })

  await prisma.$transaction([
    prisma.obra.update({ where: { id }, data: { etapa_projeto } }),
    prisma.projectStage.create({
      data: {
        obraId: id,
        etapa_anterior: obra.etapa_projeto ? `Projeto: ${obra.etapa_projeto}` : null,
        etapa_nova: `Projeto: ${etapa_projeto}`,
        changed_by: session.userId,
      },
    }),
  ])

  return NextResponse.json({ success: true, etapa_projeto })
}
