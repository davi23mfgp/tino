import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { encrypt } from "@/lib/crypto"
import { validarSenhaCofreComTrava, cofreConfigurado } from "@/lib/ai/scope"

/**
 * GET  /api/obras/[id]/credenciais — lista credenciais (senha SEMPRE mascarada).
 * POST /api/obras/[id]/credenciais — cria credencial (senha criptografada at-rest).
 *
 * A senha em texto puro NUNCA sai daqui pelo GET. Para revelar, há a rota
 * dedicada /credenciais/[credId]/revelar.
 */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params

  // Garante que a obra é da empresa do usuário (multi-tenant)
  const obra = await prisma.obra.findFirst({ where: { id, companyId: session.companyId } })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const creds = await prisma.technicalCredential.findMany({
    where: { obraId: id },
    orderBy: { createdAt: "desc" },
  })

  // Devolve mascarado — campos confidenciais nunca saem em texto puro pelo GET
  const result = creds.map(c => ({
    id: c.id,
    tipo_equipamento: c.tipo_equipamento,
    login: c.login,
    observacoes: c.observacoes,
    anexo_url: c.anexo_url,
    tem_senha: !!c.senha_criptografada,
    tem_mac: !!c.mac_criptografado,
    tem_ip: !!c.ip_criptografado,
    createdAt: c.createdAt.toISOString(),
  }))

  return NextResponse.json({ credenciais: result })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const { tipo_equipamento, login, senha, mac, ip, anexo_url, observacoes, cofre_senha } = await req.json()

  // Só o tipo é obrigatório — nem todo dispositivo tem senha/login (câmeras, switches só têm MAC/IP)
  if (!tipo_equipamento) {
    return NextResponse.json({ error: "Tipo de equipamento é obrigatório" }, { status: 400 })
  }

  // Salvar credencial é operação sensível → exige senha do cofre.
  // Sem cofre configurado, nega com o motivo (não existe mais senha padrão).
  if (!(await cofreConfigurado(session.companyId, session.role))) {
    return NextResponse.json({ error: "Cofre não configurado para o seu perfil. O Admin define a senha em Configurações → Cofre.", ok: false }, { status: 403 })
  }
  const tentativa = await validarSenhaCofreComTrava(session.userId, session.companyId, session.role, cofre_senha ?? "")
  if (tentativa.bloqueadoMin > 0) {
    return NextResponse.json({ error: `Muitas tentativas. Aguarde ${tentativa.bloqueadoMin} min.`, ok: false }, { status: 429 })
  }
  if (!tentativa.ok) return NextResponse.json({ error: "Senha do cofre incorreta", ok: false }, { status: 403 })

  const obra = await prisma.obra.findFirst({ where: { id, companyId: session.companyId } })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  // Criptografa ANTES de gravar — senha, MAC e IP nunca em texto puro
  const cred = await prisma.technicalCredential.create({
    data: {
      obraId: id,
      tipo_equipamento,
      login: login || null,
      senha_criptografada: senha ? encrypt(String(senha)) : null,
      mac_criptografado: mac ? encrypt(String(mac)) : null,
      ip_criptografado: ip ? encrypt(String(ip)) : null,
      anexo_url: anexo_url || null,
      observacoes: observacoes || null,
    },
  })

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "CRIAR",
      descricao: `Criou credencial "${tipo_equipamento}" na obra ${obra.client_name}`.slice(0, 480),
      obraId: id,
    },
  }).catch(() => {})

  return NextResponse.json({ id: cred.id, success: true, ok: true }, { status: 201 })
}
