import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  const obra = await prisma.obra.findFirst({ where: { id, companyId: session.companyId } })
  if (!obra) return NextResponse.json({ error: "Não encontrado" }, { status: 404 })
  const consertos = Array.isArray(obra.consertos_lista) ? obra.consertos_lista : []
  return NextResponse.json({ consertos })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  const obra = await prisma.obra.findFirst({ where: { id, companyId: session.companyId } })
  if (!obra) return NextResponse.json({ error: "Não encontrado" }, { status: 404 })
  const body = await req.json()
  const { equipamento, problema } = body
  if (!equipamento?.trim()) return NextResponse.json({ error: "Equipamento obrigatório" }, { status: 400 })
  const existing = Array.isArray(obra.consertos_lista) ? (obra.consertos_lista as object[]) : []
  const novo = {
    id: crypto.randomUUID(),
    equipamento: equipamento.trim(),
    problema: problema?.trim() || "",
    status: "AGUARDANDO",
    createdAt: new Date().toISOString(),
  }
  await prisma.obra.update({ where: { id }, data: { consertos_lista: [...existing, novo] } })
  return NextResponse.json(novo, { status: 201 })
}
