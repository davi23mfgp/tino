import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * Vistorias da obra (tabela inspections_media).
 * GET    — lista fotos/vídeos
 * POST   — adiciona { environmentId?, tipo, url, descricao }
 * DELETE — remove { mediaId }
 *
 * O upload real de arquivos virá numa fase futura — por ora gravamos a URL.
 */
async function obraDaEmpresa(id: string, companyId: string) {
  return prisma.obra.findFirst({ where: { id, companyId } })
}

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!await obraDaEmpresa(id, session.companyId)) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const media = await prisma.inspectionMedia.findMany({
    where: { obraId: id },
    orderBy: { createdAt: "desc" },
    include: { environment: { select: { nome: true } } },
  })
  return NextResponse.json({ vistorias: media.map(m => ({
    id: m.id, tipo: m.tipo, url: m.url, descricao: m.descricao,
    environment_nome: m.environment?.nome ?? null,
    createdAt: m.createdAt.toISOString(),
  })) })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!await obraDaEmpresa(id, session.companyId)) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const { environmentId, tipo, url, descricao } = await req.json()
  if (!url) return NextResponse.json({ error: "URL é obrigatória" }, { status: 400 })

  const m = await prisma.inspectionMedia.create({
    data: {
      obraId: id,
      environmentId: environmentId || null,
      tipo: tipo === "VIDEO" ? "VIDEO" : "FOTO",
      url,
      descricao: descricao || null,
    },
  })
  return NextResponse.json({ id: m.id }, { status: 201 })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!await obraDaEmpresa(id, session.companyId)) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const { mediaId } = await req.json()
  await prisma.inspectionMedia.deleteMany({ where: { id: mediaId, obraId: id } })
  return NextResponse.json({ success: true })
}
