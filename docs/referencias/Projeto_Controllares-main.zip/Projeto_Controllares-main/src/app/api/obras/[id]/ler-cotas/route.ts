import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * POST /api/obras/[id]/ler-cotas  { img: "data:image/jpeg;base64,..." }
 *
 * Recebe uma folha com recortes numerados (1., 2., …), cada um com uma cota, e
 * devolve só os números: { l: { "1": 2.3, "2": null } }. Quem acha e mede as
 * cotas é o navegador; a IA só lê. Nos testes, pedir posição à IA dava valores
 * inventados — por isso ela nunca recebe nem devolve coordenada.
 *
 * Modelo de visão: AI_VISION_MODEL (padrão qwen/qwen3.8-27b) no mesmo endpoint
 * compatível com OpenAI de AI_BASE_URL / AI_API_KEY.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  const obra = await prisma.obra.findFirst({ where: { id, companyId: session.companyId }, select: { id: true } })
  if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })

  const { img } = (await req.json().catch(() => ({}))) as { img?: unknown }
  if (typeof img !== "string" || !/^data:image\/(jpeg|png);base64,/.test(img) || img.length > 4_000_000) {
    return NextResponse.json({ error: "Imagem inválida" }, { status: 400 })
  }
  const base = process.env.AI_BASE_URL, chave = process.env.AI_API_KEY
  if (!base || !chave) return NextResponse.json({ error: "IA de imagem não configurada" }, { status: 501 })

  const pedido =
    "Cada linha numerada (1., 2., ...) mostra um recorte com uma cota (medida em metros, ex.: 2.30). " +
    "Leia só o número da cota de cada recorte. Se não for uma cota (símbolo de nível, texto) ou não der para ler com certeza, use null. Não invente. " +
    'Responda SÓ JSON: {"l":{"1":2.30,"2":null}}'
  try {
    const r = await fetch(base.replace(/\/+$/, "") + "/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${chave}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.AI_VISION_MODEL || "qwen/qwen3.8-27b",
        temperature: 0,
        max_tokens: 600,
        response_format: { type: "json_object" },
        messages: [{ role: "user", content: [{ type: "text", text: pedido }, { type: "image_url", image_url: { url: img } }] }],
      }),
      signal: AbortSignal.timeout(45000),
    })
    const j = (await r.json().catch(() => ({}))) as { choices?: Array<{ message?: { content?: string } }>; error?: { message?: string } }
    if (!r.ok) {
      const limite = r.status === 429
      return NextResponse.json({ error: limite ? "A IA está no limite de uso agora; tente em 1 minuto." : "A IA não leu as cotas agora." }, { status: limite ? 429 : 502 })
    }
    const texto = j.choices?.[0]?.message?.content ?? "{}"
    const l = (JSON.parse(texto.slice(texto.indexOf("{"), texto.lastIndexOf("}") + 1)) as { l?: Record<string, unknown> }).l ?? {}
    // Só números plausíveis de cota passam
    const limpo: Record<string, number | null> = {}
    for (const [k, v] of Object.entries(l)) {
      const n = typeof v === "number" ? v : parseFloat(String(v ?? "").replace(",", "."))
      limpo[k] = Number.isFinite(n) && n > 0.05 && n < 100 ? n : null
    }
    return NextResponse.json({ l: limpo })
  } catch {
    return NextResponse.json({ error: "A IA não leu as cotas agora." }, { status: 502 })
  }
}
