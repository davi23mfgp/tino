import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { parseEstudoTeclas } from "@/lib/keypad-parser"
import { parseLigacaoModulos } from "@/lib/automacao-parser"

/** Confirma que a obra é da empresa do usuário (RBAC/tenant). */
async function donoDaObra(obraId: string, companyId: string) {
  return prisma.obra.findFirst({ where: { id: obraId, companyId }, select: { id: true } })
}

/**
 * GET /api/obras/[id]/automacao
 * Devolve tudo do quadro de automação: keypads (estudo de teclas),
 * quadros com módulos/entradas/saídas e os pontos de IR/Rede.
 */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!(await donoDaObra(id, session.companyId))) {
    return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })
  }

  const [keypads, quadros, pontos] = await Promise.all([
    prisma.keypad.findMany({ where: { obraId: id }, orderBy: [{ ordem: "asc" }, { codigo: "asc" }] }),
    prisma.automacaoQuadro.findMany({
      where: { obraId: id },
      orderBy: { ordem: "asc" },
      include: {
        modulos: {
          orderBy: { ordem: "asc" },
          include: {
            entradas: { orderBy: { ordem: "asc" } },
            saidas: { orderBy: { ordem: "asc" } },
          },
        },
      },
    }),
    prisma.automacaoPonto.findMany({ where: { obraId: id }, orderBy: [{ tipo: "asc" }, { ordem: "asc" }] }),
  ])

  // Resumo por ambiente (o que o time manda no grupo: pulsadores e entradas)
  const porAmbiente = new Map<string, { pulsadores: number; teclas: number; keypads: number }>()
  for (const k of keypads) {
    const amb = k.ambiente ?? "—"
    const r = porAmbiente.get(amb) ?? { pulsadores: 0, teclas: 0, keypads: 0 }
    r.pulsadores += k.pulsadores_compra ?? 0
    r.teclas += k.teclas_automacao ?? 0
    r.keypads += 1
    porAmbiente.set(amb, r)
  }

  return NextResponse.json({
    keypads, quadros, pontos,
    resumo: {
      total_keypads: keypads.length,
      total_pulsadores: keypads.reduce((s, k) => s + (k.pulsadores_compra ?? 0), 0),
      total_teclas: keypads.reduce((s, k) => s + (k.teclas_automacao ?? 0), 0),
      total_saidas: quadros.reduce((s, q) => s + q.modulos.reduce((m, mo) => m + mo.saidas.length, 0), 0),
      total_entradas: quadros.reduce((s, q) => s + q.modulos.reduce((m, mo) => m + mo.entradas.length, 0), 0),
      por_ambiente: [...porAmbiente.entries()].map(([ambiente, r]) => ({ ambiente, ...r })),
    },
  })
}

/**
 * POST /api/obras/[id]/automacao
 * Ações:
 *  - { acao: "importar_teclas", texto }   → cola do Excel (Estudo de Teclas)
 *  - { acao: "importar_modulos", texto, quadroNome? } → cola do texto de ligação
 *  - { acao: "salvar_keypad", keypad }    → cria/atualiza um keypad
 *  - { acao: "excluir_keypad", keypadId }
 *  - { acao: "salvar_ponto", ponto }      → IR/Rede
 *  - { acao: "excluir_ponto", pontoId }
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  const { id } = await params
  if (!(await donoDaObra(id, session.companyId))) {
    return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })
  }

  const body = await req.json().catch(() => ({}))
  const acao = String(body.acao ?? "")

  // ── Importar Estudo de Teclas (cola do Excel) ──
  if (acao === "importar_teclas") {
    const linhas = parseEstudoTeclas(String(body.texto ?? ""))
    if (linhas.length === 0) {
      return NextResponse.json({ error: "Não reconheci nenhuma linha. Cole incluindo o cabeçalho da planilha." }, { status: 422 })
    }
    // Substitui o estudo anterior (import é a fonte da verdade)
    if (body.substituir !== false) await prisma.keypad.deleteMany({ where: { obraId: id } })
    await prisma.keypad.createMany({
      data: linhas.map((k, i) => ({
        obraId: id,
        codigo: k.codigo ?? `—${i + 1}`, // linhas sem keypad (ex.: SENSOR) entram como item
        ambiente: k.ambiente, setor: k.setor,
        acabamento: k.acabamento, medida: k.medida,
        teclas_automacao: k.teclas_automacao, pulsadores_compra: k.pulsadores_compra,
        ligar_junto: k.ligar_junto, circuitos: k.circuitos,
        observacao: k.observacao, ordem: i,
      })),
    })
    return NextResponse.json({ ok: true, importados: linhas.length })
  }

  // ── Importar ligação de módulos (texto do grupo) ──
  if (acao === "importar_modulos") {
    const mods = parseLigacaoModulos(String(body.texto ?? ""))
    if (mods.length === 0) {
      return NextResponse.json({ error: "Não reconheci nenhum módulo. Confira o formato (M-03 / Entradas / Saidas)." }, { status: 422 })
    }
    const quadro = await prisma.automacaoQuadro.create({
      data: {
        obraId: id,
        nome: String(body.quadroNome ?? "").trim() || "Quadro de Automação",
        ordem: await prisma.automacaoQuadro.count({ where: { obraId: id } }),
      },
    })
    for (const [i, m] of mods.entries()) {
      await prisma.automacaoModulo.create({
        data: {
          quadroId: quadro.id, nome: m.nome, ordem: i,
          entradas: { create: m.entradas.map((e, j) => ({ numero: e.numero, keypads: e.keypads, ordem: j })) },
          saidas: { create: m.saidas.map((s, j) => ({ numero: s.numero, descricao: s.descricao, ordem: j })) },
        },
      })
    }
    return NextResponse.json({
      ok: true, quadroId: quadro.id, modulos: mods.length,
      entradas: mods.reduce((s, m) => s + m.entradas.length, 0),
      saidas: mods.reduce((s, m) => s + m.saidas.length, 0),
    })
  }

  // ── Keypad avulso ──
  if (acao === "salvar_keypad") {
    const k = body.keypad ?? {}
    if (!String(k.codigo ?? "").trim()) return NextResponse.json({ error: "Informe o código do keypad" }, { status: 400 })
    const dados = {
      ambiente: k.ambiente || null, setor: k.setor || null,
      acabamento: k.acabamento || null, medida: k.medida || null,
      teclas_automacao: k.teclas_automacao == null || k.teclas_automacao === "" ? null : Number(k.teclas_automacao),
      pulsadores_compra: k.pulsadores_compra == null || k.pulsadores_compra === "" ? null : Number(k.pulsadores_compra),
      ligar_junto: k.ligar_junto || null,
      circuitos: Array.isArray(k.circuitos) ? k.circuitos : [],
      observacao: k.observacao || null,
    }
    if (k.id) {
      const existe = await prisma.keypad.findFirst({ where: { id: k.id, obraId: id }, select: { id: true } })
      if (!existe) return NextResponse.json({ error: "Keypad não encontrado" }, { status: 404 })
      await prisma.keypad.update({ where: { id: k.id }, data: dados })
    } else {
      await prisma.keypad.create({
        data: { ...dados, obraId: id, codigo: String(k.codigo).trim().toUpperCase(), ordem: await prisma.keypad.count({ where: { obraId: id } }) },
      })
    }
    return NextResponse.json({ ok: true })
  }

  if (acao === "excluir_keypad") {
    await prisma.keypad.deleteMany({ where: { id: String(body.keypadId ?? ""), obraId: id } })
    return NextResponse.json({ ok: true })
  }

  // ── Ponto de IR / Rede ──
  if (acao === "salvar_ponto") {
    const p = body.ponto ?? {}
    const tipo = p.tipo === "IR" ? "IR" : "REDE"
    const dados = {
      tipo, codigo: p.codigo || null, ambiente: p.ambiente || null, setor: p.setor || null,
      equipamento: p.equipamento || null, descricao: p.descricao || null,
      porta: p.porta || null, ip: p.ip || null, observacao: p.observacao || null,
      // Rede nunca agrupa; IR pode compartilhar emissor.
      grupo: tipo === "IR" ? (p.grupo || null) : null,
    }
    if (p.id) {
      const existe = await prisma.automacaoPonto.findFirst({ where: { id: p.id, obraId: id }, select: { id: true } })
      if (!existe) return NextResponse.json({ error: "Ponto não encontrado" }, { status: 404 })
      await prisma.automacaoPonto.update({ where: { id: p.id }, data: dados })
    } else {
      await prisma.automacaoPonto.create({
        data: { ...dados, obraId: id, ordem: await prisma.automacaoPonto.count({ where: { obraId: id, tipo } }) },
      })
    }
    return NextResponse.json({ ok: true })
  }

  if (acao === "excluir_ponto") {
    await prisma.automacaoPonto.deleteMany({ where: { id: String(body.pontoId ?? ""), obraId: id } })
    return NextResponse.json({ ok: true })
  }

  // ── Criar módulo já com as linhas de entrada/saída em branco ──
  // Relay/Dimmer: entradas + saídas. IR: só "saídas" (as portas de IR).
  if (acao === "criar_modulo") {
    const m = body.modulo ?? {}
    const nome = String(m.nome ?? "").trim()
    if (!nome) return NextResponse.json({ error: "Informe o nome do módulo" }, { status: 400 })
    const tipo = ["RELAY", "DIMMER", "IR", "REDE"].includes(m.tipo) ? m.tipo : "RELAY"
    const qtdSaidas = Math.max(0, Math.min(64, Number(m.qtd_saidas) || 0))
    // IR (emissores) e REDE (portas do switch) só têm saídas — não recebem keypad.
    const semEntradas = tipo === "IR" || tipo === "REDE"
    const qtdEntradas = semEntradas ? 0 : Math.max(0, Math.min(64, Number(m.qtd_entradas) || 0))
    const pavimento = String(m.pavimento ?? "").trim() || null

    // Reaproveita o quadro do mesmo pavimento; senão cria um.
    let quadroId: string = String(m.quadroId ?? "")
    if (!quadroId) {
      const nomeQuadro = pavimento ? `Quadro ${pavimento}` : "Quadro de Automação"
      const existente = await prisma.automacaoQuadro.findFirst({ where: { obraId: id, nome: nomeQuadro }, select: { id: true } })
      quadroId = existente?.id ?? (await prisma.automacaoQuadro.create({
        data: { obraId: id, nome: nomeQuadro, ordem: await prisma.automacaoQuadro.count({ where: { obraId: id } }) },
      })).id
    }

    const pad = (n: number) => String(n).padStart(2, "0")
    const criado = await prisma.automacaoModulo.create({
      data: {
        quadroId, nome, tipo, pavimento,
        modelo: m.modelo || null,
        capacidade: m.capacidade == null || m.capacidade === "" ? null : Number(m.capacidade),
        ordem: await prisma.automacaoModulo.count({ where: { quadroId } }),
        entradas: { create: Array.from({ length: qtdEntradas }, (_, i) => ({ numero: pad(i + 1), keypads: [], ordem: i })) },
        saidas: { create: Array.from({ length: qtdSaidas }, (_, i) => ({ numero: pad(i + 1), descricao: "", ordem: i })) },
      },
    })
    return NextResponse.json({ ok: true, moduloId: criado.id, quadroId })
  }

  // ── Salvar as linhas editadas de um módulo (nome, grupo, keypads) ──
  if (acao === "salvar_linhas") {
    const modulo = await prisma.automacaoModulo.findFirst({
      where: { id: String(body.moduloId ?? ""), quadro: { obraId: id } }, select: { id: true },
    })
    if (!modulo) return NextResponse.json({ error: "Módulo não encontrado" }, { status: 404 })

    const saidas = Array.isArray(body.saidas) ? body.saidas : []
    for (const s of saidas) {
      if (!s?.id) continue
      await prisma.moduloSaida.updateMany({
        where: { id: String(s.id), moduloId: modulo.id },
        data: {
          descricao: String(s.descricao ?? ""),
          ambiente: s.ambiente || null,
          circuito: s.circuito || null,
          // Em IR/REDE a coluna guarda o equipamento (TV, Switch, AP…).
          tipo_carga: s.tipo_carga || null,
          grupo: s.grupo || null,
        },
      })
    }
    const entradas = Array.isArray(body.entradas) ? body.entradas : []
    for (const e of entradas) {
      if (!e?.id) continue
      await prisma.moduloEntrada.updateMany({
        where: { id: String(e.id), moduloId: modulo.id },
        data: {
          keypads: Array.isArray(e.keypads)
            ? e.keypads
            : String(e.keypads ?? "").split(/[;,+/]+/).map((x: string) => x.trim().toUpperCase()).filter(Boolean),
          grupo: e.grupo || null,
        },
      })
    }
    return NextResponse.json({ ok: true })
  }

  if (acao === "excluir_modulo") {
    const mod = await prisma.automacaoModulo.findFirst({
      where: { id: String(body.moduloId ?? ""), quadro: { obraId: id } }, select: { id: true },
    })
    if (mod) await prisma.automacaoModulo.delete({ where: { id: mod.id } })
    return NextResponse.json({ ok: true })
  }

  if (acao === "excluir_quadro") {
    await prisma.automacaoQuadro.deleteMany({ where: { id: String(body.quadroId ?? ""), obraId: id } })
    return NextResponse.json({ ok: true })
  }

  return NextResponse.json({ error: "Ação inválida" }, { status: 400 })
}
