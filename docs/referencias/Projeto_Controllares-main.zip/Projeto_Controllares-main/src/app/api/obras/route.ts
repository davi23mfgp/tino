import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { criarReservasEstoque } from "@/lib/obra-service"
import { temAlgumPerfil } from "@/lib/perfil"

/**
 * GET /api/obras
 * Listagem CRUA de obras — temporária, só para validar a Fase 5.
 * A tela bonita (painel 360º) vem na Fase 6.
 */
export async function GET(_req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  // RESPONSAVEL_TECNICO e INSTALADOR só veem as obras que lhes dizem respeito
  const whereExtra =
    session.role === "RESPONSAVEL_TECNICO"
      ? { resp_tecnico_id: session.userId }
      : session.role === "INSTALADOR"
      ? { colaboradores_ids: { has: session.userId } }
      : {}

  const obras = await prisma.obra.findMany({
    where: { companyId: session.companyId, ...whereExtra },
    orderBy: { createdAt: "desc" },
    include: {
      originProposal: { select: { numero: true } },
      respComercial: { select: { nome: true } },
      respTecnico: { select: { id: true, nome: true } },
      workPartners: {
        include: { partner: { select: { id: true, name: true, type: true, company_name: true } } },
      },
      environments: {
        include: {
          proposalItems: {
            include: {
              product: { select: { nome: true } },
              kit: { select: { nome: true } },
            },
          },
        },
      },
    },
  })

  // Achata para um formato simples de inspeção
  const result = obras.map(o => ({
    id: o.id,
    client_name: o.client_name,
    address: o.address,
    etapa: o.etapa,
    etapa_projeto: o.etapa_projeto,
    tipo_projeto: o.tipo_projeto,
    cidade: o.cidade ?? null,
    logistics_status: o.logistics_status,
    physical_progress_percentage: o.physical_progress_percentage,
    compra_liberada: o.compra_liberada,
    proposta_origem: o.originProposal?.numero ?? null,
    resp_comercial: o.respComercial?.nome ?? null,
    resp_tecnico: o.respTecnico?.nome ?? null,
    resp_tecnico_id: o.respTecnico?.id ?? null,
    checklist_tecnico: o.checklist_tecnico ?? null,
    parceiros: o.workPartners.map(wp => ({
      id: wp.partner.id,
      name: wp.partner.name,
      type: wp.partner.type,
      company_name: wp.partner.company_name,
    })),
    createdAt: o.createdAt.toISOString(),
    /* Pendência = tem produto sincronizado da proposta que ainda não foi
       ligado a um ambiente físico da obra (obraAmbienteId nulo). É a trava
       de "obrigatório" prometida: enquanto sobrar item assim, o card ganha
       o aviso no dashboard. */
    pendencia_ambiente: o.environments.some(env =>
      env.proposalItems.some(it => it.obraAmbienteId == null)),
    ambientes: o.environments.map(env => ({
      id: env.id,
      nome: env.nome,
      itens: env.proposalItems.map(it => ({
        nome: it.product?.nome ?? it.kit?.nome ?? "Item",
        quantidade: it.quantidade,
        is_aditivo: it.is_aditivo,
      })),
    })),
  }))

  return NextResponse.json({ obras: result, total: result.length })
}

/**
 * POST /api/obras — criação MANUAL de obra (Bloco 7).
 * Body: { client_name?, proposalId? }
 *  - proposalId opcional: vincula a proposta de origem e espelha os ambientes
 *    dela (se ainda não tiver obra). Não força status da proposta.
 *  - sem proposalId: cria obra em branco só com o nome do cliente.
 */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO", "RESPONSAVEL_TECNICO", "ENGENHEIRO_PROJETOS"])) {
    return NextResponse.json({ error: "Sem permissão para criar obra" }, { status: 403 })
  }

  const body = await req.json().catch(() => ({}))
  const { client_name, proposalId } = body as { client_name?: string; proposalId?: string }

  let proposal = null
  if (proposalId) {
    proposal = await prisma.proposal.findFirst({ where: { id: proposalId, companyId: session.companyId } })
    if (!proposal) return NextResponse.json({ error: "Proposta não encontrada" }, { status: 404 })
    if (proposal.obraId) return NextResponse.json({ error: "Essa proposta já está vinculada a uma obra." }, { status: 409 })
  }

  const nome = (client_name || proposal?.client_name || "").trim()
  if (!nome) return NextResponse.json({ error: "Informe o cliente ou vincule uma proposta." }, { status: 400 })

  const obra = await prisma.$transaction(async (tx) => {
    const nova = await tx.obra.create({
      data: {
        companyId: session.companyId,
        client_name: nome,
        address: proposal?.client_city ?? null,
        etapa: "Nova obra",
        physical_progress_percentage: 0,
        logistics_status: "AGUARDANDO_EQUIPAMENTOS",
        compra_liberada: false,
        resp_comercial_id: proposal?.vendedorId ?? session.userId,
        resp_tecnico_id: null,
        ...(proposal ? { originProposalId: proposal.id } : {}),
      },
    })
    if (proposal) {
      await tx.proposal.update({ where: { id: proposal.id }, data: { obraId: nova.id } })
      // espelha ambientes da proposta (mantém itens pendurados)
      await tx.environment.updateMany({ where: { proposalId: proposal.id }, data: { obraId: nova.id } })
      // reserva de estoque da venda (explode composto/kit em componentes)
      await criarReservasEstoque(tx, {
        proposalId: proposal.id, obraId: nova.id, companyId: session.companyId,
        criadoPorId: session.userId, criadoPorNome: session.nome,
      })
    }
    await tx.projectStage.create({
      data: { obraId: nova.id, etapa_anterior: null, etapa_nova: "Nova obra", changed_by: session.userId },
    })
    return nova
  })

  return NextResponse.json({ ok: true, id: obra.id }, { status: 201 })
}
