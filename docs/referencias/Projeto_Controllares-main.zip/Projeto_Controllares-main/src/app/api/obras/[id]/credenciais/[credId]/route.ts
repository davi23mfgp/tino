import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { encrypt } from "@/lib/crypto"

/**
 * PATCH  /api/obras/[id]/credenciais/[credId] — edita a credencial.
 * DELETE /api/obras/[id]/credenciais/[credId] — remove a credencial.
 *
 * Em PATCH, os campos confidenciais (senha/MAC/IP) só são re-criptografados
 * se vierem PREENCHIDOS. Se vierem vazios, o valor atual é mantido.
 * Para LIMPAR um campo confidencial, envie a string "__LIMPAR__".
 */
async function obraDaEmpresa(id: string, companyId: string) {
  return prisma.obra.findFirst({ where: { id, companyId } })
}

function tratarConfidencial(valor: unknown, atual: string | null): string | null {
  if (valor === undefined) return atual          // não enviado → mantém
  if (valor === "__LIMPAR__") return null         // pedido explícito de limpar
  if (valor === "" || valor === null) return atual // vazio → mantém
  return encrypt(String(valor))                   // novo valor → criptografa
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string; credId: string }> }
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id, credId } = await params
  if (!await obraDaEmpresa(id, session.companyId)) {
    return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })
  }

  const cred = await prisma.technicalCredential.findFirst({ where: { id: credId, obraId: id } })
  if (!cred) return NextResponse.json({ error: "Credencial não encontrada" }, { status: 404 })

  const body = await req.json()

  if (body.tipo_equipamento !== undefined && !String(body.tipo_equipamento).trim()) {
    return NextResponse.json({ error: "Tipo de equipamento é obrigatório" }, { status: 400 })
  }

  await prisma.technicalCredential.update({
    where: { id: credId },
    data: {
      ...(body.tipo_equipamento !== undefined && { tipo_equipamento: body.tipo_equipamento }),
      ...(body.login !== undefined && { login: body.login || null }),
      ...(body.anexo_url !== undefined && { anexo_url: body.anexo_url || null }),
      ...(body.observacoes !== undefined && { observacoes: body.observacoes || null }),
      senha_criptografada: tratarConfidencial(body.senha, cred.senha_criptografada),
      mac_criptografado: tratarConfidencial(body.mac, cred.mac_criptografado),
      ip_criptografado: tratarConfidencial(body.ip, cred.ip_criptografado),
    },
  })

  return NextResponse.json({ success: true })
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string; credId: string }> }
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id, credId } = await params
  if (!await obraDaEmpresa(id, session.companyId)) {
    return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })
  }

  await prisma.technicalCredential.deleteMany({ where: { id: credId, obraId: id } })
  return NextResponse.json({ success: true })
}
