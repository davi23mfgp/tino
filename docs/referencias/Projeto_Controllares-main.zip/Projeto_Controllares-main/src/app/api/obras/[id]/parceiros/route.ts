import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

/**
 * GET    /api/obras/[id]/parceiros — lista parceiros vinculados à obra
 * POST   /api/obras/[id]/parceiros — vincula um parceiro (body: { parceiro_id })
 * DELETE /api/obras/[id]/parceiros — desvincula um parceiro (body: { parceiro_id })
 */
async function obraDaEmpresa(id: string, companyId: string) {
  return prisma.obra.findFirst({ where: { id, companyId } })
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  if (!await obraDaEmpresa(id, session.companyId)) {
    return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })
  }

  const links = await prisma.workPartner.findMany({
    where: { workId: id },
    include: {
      partner: true,
    },
  })

  return NextResponse.json({ parceiros: links.map(l => l.partner) })
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const { parceiro_id } = await req.json()

  if (!await obraDaEmpresa(id, session.companyId)) {
    return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })
  }

  const parceiro = await prisma.partnerStakeholder.findFirst({
    where: { id: parceiro_id, companyId: session.companyId },
  })
  if (!parceiro) return NextResponse.json({ error: "Parceiro não encontrado" }, { status: 404 })

  // upsert para não duplicar
  await prisma.workPartner.upsert({
    where: { workId_partnerId: { workId: id, partnerId: parceiro_id } },
    create: { workId: id, partnerId: parceiro_id },
    update: {},
  })

  return NextResponse.json({ success: true })
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const { parceiro_id } = await req.json()

  if (!await obraDaEmpresa(id, session.companyId)) {
    return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })
  }

  await prisma.workPartner.deleteMany({
    where: { workId: id, partnerId: parceiro_id },
  })

  return NextResponse.json({ success: true })
}
