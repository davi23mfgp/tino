import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { listMessages, sendMessage } from "@/lib/wacrm"

export const dynamic = "force-dynamic"

/** GET /api/chat/conversations/[id]/messages — histórico da conversa. */
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const cursor = req.nextUrl.searchParams.get("cursor") ?? undefined
  try {
    const pagina = await listMessages(id, cursor)
    return NextResponse.json(pagina)
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Falha ao buscar mensagens no wacrm." },
      { status: 502 },
    )
  }
}

/** POST /api/chat/conversations/[id]/messages — manda mensagem pro contato
 *  da conversa. O corpo já traz o telefone (`to`) porque a API do wacrm
 *  manda pelo telefone, não pelo id interno da conversa. */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  await params // valida que a rota tem o id, mesmo sem usá-lo diretamente
  const body = await req.json().catch(() => ({} as Record<string, unknown>))
  const to = typeof body.to === "string" ? body.to.trim() : ""
  const text = typeof body.text === "string" ? body.text.trim() : ""
  if (!to || !text) {
    return NextResponse.json({ error: "Informe o telefone (to) e o texto." }, { status: 422 })
  }

  try {
    const resultado = await sendMessage({ to, type: "text", text })
    return NextResponse.json(resultado, { status: 201 })
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Falha ao enviar mensagem pelo wacrm." },
      { status: 502 },
    )
  }
}
