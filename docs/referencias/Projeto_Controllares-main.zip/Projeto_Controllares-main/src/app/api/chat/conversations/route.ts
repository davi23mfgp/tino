import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { listConversations } from "@/lib/wacrm"

export const dynamic = "force-dynamic"

/** GET /api/chat/conversations — lista as conversas do wacrm. Aberto a
 *  qualquer perfil logado: o chat não é restrito a um setor específico. */
export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const cursor = req.nextUrl.searchParams.get("cursor") ?? undefined
  try {
    const pagina = await listConversations({ cursor })
    return NextResponse.json(pagina)
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Falha ao buscar conversas no wacrm." },
      { status: 502 },
    )
  }
}
