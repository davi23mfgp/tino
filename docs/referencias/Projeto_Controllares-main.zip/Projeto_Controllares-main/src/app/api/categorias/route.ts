import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const withProducts = req.nextUrl.searchParams.get("withProducts") === "true"

  const categories = await prisma.category.findMany({
    where: { companyId: session.companyId },
    orderBy: { nome: "asc" },
    include: withProducts
      ? {
          products: {
            select: { id: true, sku: true, nome: true, status: true, imagem_url: true },
            orderBy: { nome: "asc" },
          },
          _count: { select: { products: true, proposalItems: true } },
        }
      : { _count: { select: { products: true, proposalItems: true } } },
  })

  return NextResponse.json({ categories })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { nome } = await req.json()
  if (!nome?.trim()) return NextResponse.json({ error: "Nome é obrigatório" }, { status: 400 })

  const category = await prisma.category.create({
    data: { nome: nome.trim(), companyId: session.companyId },
  })

  return NextResponse.json(category, { status: 201 })
}
