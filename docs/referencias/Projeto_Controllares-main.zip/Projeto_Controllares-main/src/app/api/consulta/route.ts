import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { soDigitos, validarCNPJ, type EnderecoCEP, type DadosCNPJ } from "@/lib/documento"

export const dynamic = "force-dynamic"

const BRASILAPI = "https://brasilapi.com.br/api"

/* A BrasilAPI responde 403 a requisição sem User-Agent, e o fetch do servidor
   não manda nenhum por padrão. O sintoma era pior que o erro: a busca de CNPJ
   simplesmente não preenchia nada, e nada na tela dizia por quê. */
const CABECALHOS = { "User-Agent": "Controllares-ERP (contato@controllares.com.br)" }

/**
 * GET /api/consulta?cep=15025000
 * GET /api/consulta?cnpj=14370179000183
 *
 * Consulta CEP e CNPJ na BrasilAPI. Passa pelo servidor em vez de o navegador
 * chamar direto por dois motivos: evita CORS e não expõe qual serviço usamos —
 * trocar de provedor depois não mexe no front.
 *
 * Exige sessão: é ferramenta interna, não endpoint aberto de consulta.
 */
export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const cep = soDigitos(searchParams.get("cep"))
  const cnpj = soDigitos(searchParams.get("cnpj"))

  try {
    if (cep) {
      if (cep.length !== 8) {
        return NextResponse.json({ error: "CEP deve ter 8 dígitos." }, { status: 400 })
      }
      // v2 tenta várias fontes; se uma estiver fora, ainda responde.
      const r = await fetch(`${BRASILAPI}/cep/v2/${cep}`,
        { headers: CABECALHOS, next: { revalidate: 86400 } })
      if (r.status === 404) return NextResponse.json({ error: "CEP não encontrado." }, { status: 404 })
      if (!r.ok) return NextResponse.json({ error: "Consulta de CEP indisponível." }, { status: 502 })
      const j = await r.json()
      const endereco: EnderecoCEP = {
        cep,
        logradouro: j.street ?? "",
        bairro: j.neighborhood ?? "",
        cidade: j.city ?? "",
        uf: j.state ?? "",
      }
      return NextResponse.json({ endereco })
    }

    if (cnpj) {
      if (!validarCNPJ(cnpj)) {
        return NextResponse.json({ error: "CNPJ inválido." }, { status: 400 })
      }
      const r = await fetch(`${BRASILAPI}/cnpj/v1/${cnpj}`,
        { headers: CABECALHOS, next: { revalidate: 86400 } })
      if (r.status === 404) return NextResponse.json({ error: "CNPJ não encontrado." }, { status: 404 })
      if (!r.ok) {
        return NextResponse.json(
          { error: `Consulta de CNPJ indisponível (erro ${r.status}).` }, { status: 502 })
      }
      const j = await r.json()
      const dados: DadosCNPJ = {
        razao_social: j.razao_social ?? "",
        nome_fantasia: j.nome_fantasia || null,
        email: j.email || null,
        cep: soDigitos(j.cep) || null,
        logradouro: [j.descricao_tipo_de_logradouro, j.logradouro].filter(Boolean).join(" ").trim() || null,
        numero: j.numero || null,
        complemento: j.complemento || null,
        bairro: j.bairro || null,
        cidade: j.municipio || null,
        uf: j.uf || null,
        situacao: j.descricao_situacao_cadastral || null,
        /* O telefone vem sem separador e com o DDD colado. Formatar aqui evita
           que cada tela invente o próprio jeito de exibir. */
        telefone: j.ddd_telefone_1
          ? String(j.ddd_telefone_1).replace(/^(\d{2})(\d{4,5})(\d{4})$/, "($1) $2-$3")
          : null,
        porte: j.porte || null,
        natureza_juridica: j.natureza_juridica || null,
        atividade: j.cnae_fiscal_descricao || null,
        simples: typeof j.opcao_pelo_simples === "boolean" ? j.opcao_pelo_simples : null,
        mei: typeof j.opcao_pelo_mei === "boolean" ? j.opcao_pelo_mei : null,
        abertura: j.data_inicio_atividade || null,
        /* Só os nomes. O quadro societário traz CPF parcial e data de entrada,
           que não têm uso no faturamento e não precisam trafegar. */
        socios: Array.isArray(j.qsa)
          ? j.qsa.map((s: { nome_socio?: string }) => s.nome_socio).filter(Boolean).slice(0, 5)
          : null,
      }
      return NextResponse.json({ dados })
    }

    return NextResponse.json({ error: "Informe cep ou cnpj." }, { status: 400 })
  } catch {
    // Serviço externo fora do ar não pode derrubar a tela: quem chama trata
    // e deixa a pessoa preencher na mão.
    return NextResponse.json({ error: "Não foi possível consultar agora." }, { status: 502 })
  }
}
