import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const body = await req.json()

  const existing = await prisma.tarefa.findFirst({ where: { id, companyId: session.companyId } })
  if (!existing) return NextResponse.json({ error: "Tarefa não encontrada" }, { status: 404 })

  // Não-admin só pode alterar tarefas próprias (atribuídas ou criadas por si)
  if (session.role !== "ADMIN" && existing.atribuidoA !== session.userId && existing.criadoPor !== session.userId) {
    return NextResponse.json({ error: "Sem permissão para alterar esta tarefa" }, { status: 403 })
  }

  /* A coluna final decide `concluida`. A conta é feita aqui, no servidor: a
     tela poderia mandar as duas coisas, mas aí bastaria uma requisição perdida
     para a tarefa aparecer em "Feito" e continuar contando como aberta. */
  let concluidaPelaColuna: boolean | undefined
  if (body.colunaId !== undefined && body.colunaId) {
    const col = await prisma.quadroColuna.findFirst({
      where: { id: body.colunaId, companyId: session.companyId },
      select: { final: true },
    })
    if (col) concluidaPelaColuna = col.final
  }

  const updated = await prisma.tarefa.update({
    where: { id },
    data: {
      ...(body.titulo !== undefined && { titulo: body.titulo.trim() }),
      ...(body.descricao !== undefined && { descricao: body.descricao?.trim() || null }),
      ...(body.prioridade !== undefined && { prioridade: body.prioridade }),
      ...(body.categoria !== undefined && { categoria: body.categoria }),
      ...(body.dataVenc !== undefined && { dataVenc: body.dataVenc ? new Date(body.dataVenc) : null }),
      ...(body.horaInicio !== undefined && { horaInicio: body.horaInicio || null }),
      ...(body.horaFim !== undefined && { horaFim: body.horaFim || null }),
      ...(body.concluida !== undefined && { concluida: Boolean(body.concluida) }),
      /* Arrastar no quadro é uma alteração como as outras, mas com um efeito
         extra: a coluna marcada como final ENCERRA a tarefa. Sem isso, quem
         arrasta para "Feito" ainda teria de marcar a caixinha em outro lugar —
         e metade das tarefas ficaria eternamente aberta no relatório. */
      ...(body.colunaId !== undefined && { colunaId: body.colunaId || null }),
      ...(concluidaPelaColuna !== undefined && { concluida: concluidaPelaColuna }),
      ...(body.ordem_coluna !== undefined && { ordem_coluna: Number(body.ordem_coluna) || 0 }),
      ...(body.atribuidoA !== undefined && { atribuidoA: body.atribuidoA || null }),
      ...(body.atribuido_role !== undefined && { atribuido_role: body.atribuido_role || null }),
      ...(body.checklist !== undefined && { checklist: body.checklist }),
    },
    include: {
      criador: { select: { id: true, nome: true } },
      atribuido: { select: { id: true, nome: true } },
      obra: { select: { id: true, client_name: true } },
    },
  })

  return NextResponse.json(updated)
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params

  const existing = await prisma.tarefa.findFirst({ where: { id, companyId: session.companyId } })
  if (!existing) return NextResponse.json({ error: "Tarefa não encontrada" }, { status: 404 })

  // Não-admin só pode excluir tarefas próprias (atribuídas ou criadas por si)
  if (session.role !== "ADMIN" && existing.atribuidoA !== session.userId && existing.criadoPor !== session.userId) {
    return NextResponse.json({ error: "Sem permissão para excluir esta tarefa" }, { status: 403 })
  }

  await prisma.tarefa.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
