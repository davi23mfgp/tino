import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

const CATEGORIAS_VALIDAS = ["GERAL", "ADMIN", "FINANCEIRO", "OPERACIONAL", "COMERCIAL", "ENGENHARIA"]
const ROLES_VALIDOS = ["ADMIN", "VENDEDOR", "FINANCEIRO", "RESPONSAVEL_TECNICO", "INSTALADOR", "ENGENHEIRO_PROJETOS", "OPERACIONAL", "COMERCIAL", "ENGENHARIA"]

// Mapeia role do usuário para os atribuido_role que ele deve enxergar
function rolesVisiveis(role: string): string[] {
  const mapa: Record<string, string[]> = {
    ADMIN: [],                                 // Admin vê tudo — sem filtro de role
    FINANCEIRO: ["FINANCEIRO"],
    VENDEDOR: ["COMERCIAL", "VENDEDOR"],
    RESPONSAVEL_TECNICO: ["OPERACIONAL", "RESPONSAVEL_TECNICO"],
    INSTALADOR: ["OPERACIONAL", "INSTALADOR"],
    ENGENHEIRO_PROJETOS: ["ENGENHARIA", "ENGENHEIRO_PROJETOS"],
  }
  return mapa[role] ?? [role]
}

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const concluida = searchParams.get("concluida")
  const categoria = searchParams.get("categoria")
  const obraId = searchParams.get("obraId")
  const atribuidoA = searchParams.get("atribuidoA")

  /* O QUADRO mostra o trabalho da empresa inteira.
     Um quadro que só exibe as próprias tarefas esconde justamente o que um
     quadro existe para mostrar: quem está com o quê. O filtro "só as minhas"
     fica na tela, do lado de quem olha, e não numa regra do servidor. */
  const quadro = searchParams.get("quadro") === "true"
  /* Tarefa do quadro X não aparece no quadro Y. Sem este filtro, todo quadro
     mostraria o trabalho de todos e a separação não separaria nada. */
  const quadroId = searchParams.get("quadroId")

  // Visibilidade:
  // ADMIN: vê todas (ou filtra por atribuidoA se passado)
  // Outros: veem as próprias (criadas ou atribuídas por id) + as enviadas para o seu role
  let visibilidade: object
  if (quadro || session.role === "ADMIN") {
    visibilidade = atribuidoA ? { atribuidoA } : {}
  } else {
    const roles = rolesVisiveis(session.role)
    visibilidade = {
      OR: [
        { atribuidoA: session.userId },
        { criadoPor: session.userId },
        ...(roles.length > 0 ? [{ atribuido_role: { in: roles } }] : []),
      ],
    }
  }

  const tarefas = await prisma.tarefa.findMany({
    where: {
      companyId: session.companyId,
      ...visibilidade,
      ...(concluida === "true" ? { concluida: true } : concluida === "false" ? { concluida: false } : {}),
      ...(categoria && CATEGORIAS_VALIDAS.includes(categoria) ? { categoria: categoria as never } : {}),
      ...(obraId ? { obraId } : {}),
      ...(quadroId ? { coluna: { quadroId } } : {}),
    },
    include: {
      criador: { select: { id: true, nome: true } },
      atribuido: { select: { id: true, nome: true } },
      obra: { select: { id: true, client_name: true } },
    },
    orderBy: quadro
      // No quadro manda a posição dentro da coluna; data importa na Agenda.
      ? [{ ordem_coluna: "asc" }, { createdAt: "desc" }]
      : [{ concluida: "asc" }, { dataVenc: "asc" }, { createdAt: "desc" }],
  })

  return NextResponse.json({ tarefas })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const body = await req.json()
  const { titulo, descricao, prioridade, categoria, dataVenc, horaInicio, horaFim, atribuidoA, atribuido_role, obraId } = body

  if (!titulo?.trim()) return NextResponse.json({ error: "Título é obrigatório" }, { status: 400 })

  if (obraId) {
    const obra = await prisma.obra.findFirst({ where: { id: obraId, companyId: session.companyId } })
    if (!obra) return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 })
  }

  const tarefa = await prisma.tarefa.create({
    data: {
      titulo: titulo.trim(),
      descricao: descricao?.trim() || null,
      prioridade: prioridade || "MEDIA",
      categoria: CATEGORIAS_VALIDAS.includes(categoria) ? categoria : (obraId ? "OPERACIONAL" : "GERAL"),
      dataVenc: dataVenc ? new Date(dataVenc) : null,
      horaInicio: horaInicio || null,
      horaFim: horaFim || null,
      companyId: session.companyId,
      criadoPor: session.userId,
      atribuidoA: atribuidoA || null,
      atribuido_role: (atribuido_role && ROLES_VALIDOS.includes(atribuido_role)) ? atribuido_role : null,
      obraId: obraId || null,
      /* Coluna vem quando a tarefa nasce no quadro. Criada na Agenda, fica
         nula e a tela do quadro a mostra na primeira coluna — não existe
         tarefa invisível por não ter passado por lá. */
      colunaId: body.colunaId || null,
    },
    include: {
      criador: { select: { id: true, nome: true } },
      atribuido: { select: { id: true, nome: true } },
      obra: { select: { id: true, client_name: true } },
    },
  })

  return NextResponse.json(tarefa, { status: 201 })
}
