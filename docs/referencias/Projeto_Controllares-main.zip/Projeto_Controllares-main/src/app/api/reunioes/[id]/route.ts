import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"

export const dynamic = "force-dynamic"

/**
 * Apagar a gravação guardada aqui.
 *
 * Transcrição é conversa gravada dentro da casa do cliente. Guardar para sempre
 * não é decisão do sistema, e quem gravou tem que poder desfazer.
 *
 * Dois alcances, porque são dois casos:
 *
 * - padrão: apaga só o texto. O registro da reunião fica — título, data e a
 *   proposta que ela gerou —, porque é o histórico de onde aquela proposta
 *   veio. A proposta não é afetada: os itens dela são cópia, não referência.
 *
 * - `?tudo=1`: apaga o registro inteiro. Só quando a reunião não virou
 *   proposta; se virou, some a explicação de uma proposta que continua
 *   existindo, e isso não se recupera.
 *
 * Apagar aqui não apaga no Plaud: a API deles não permite. Limpar o aparelho
 * continua sendo pelo aplicativo, e é dito na tela para ninguém achar que
 * apagou dos dois lados.
 */
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  /* Apagar é decisão de quem responde pela empresa, não de quem passa pela
     tela: o texto some para todo mundo e não volta. */
  if (!temAlgumPerfil(session, ["ADMIN", "FINANCEIRO"])) {
    return NextResponse.json({ error: "Só Admin ou Financeiro pode apagar." }, { status: 403 })
  }

  const { id } = await params
  const tudo = req.nextUrl.searchParams.get("tudo") === "1"

  const reuniao = await prisma.reuniao.findFirst({
    where: { id, companyId: session.companyId },
    select: { id: true, titulo: true, proposalId: true, transcricao_apagada_em: true },
  })
  if (!reuniao) return NextResponse.json({ error: "Reunião não encontrada." }, { status: 404 })

  if (tudo) {
    if (reuniao.proposalId) {
      return NextResponse.json({
        error: "Esta reunião virou proposta. Dá para apagar a transcrição,"
          + " mas o registro fica: é ele que explica de onde a proposta veio.",
      }, { status: 409 })
    }
    await prisma.reuniao.delete({ where: { id: reuniao.id } })
    await prisma.aiAuditLog.create({
      data: {
        userId: session.userId, companyId: session.companyId, tipo_acesso: "EXCLUIR",
        descricao: `Reunião apagada: ${reuniao.titulo ?? reuniao.id}`,
      },
    }).catch(() => {})
    return NextResponse.json({ ok: true, apagado: "reuniao" })
  }

  if (reuniao.transcricao_apagada_em) {
    return NextResponse.json({ error: "A transcrição já foi apagada." }, { status: 409 })
  }

  await prisma.reuniao.update({
    where: { id: reuniao.id },
    data: {
      /* String vazia, não null: a coluna é obrigatória, e a data ao lado é o
         que diz que ficou vazia porque alguém quis. */
      transcricao: "",
      transcricao_apagada_em: new Date(),
    },
  })

  await prisma.aiAuditLog.create({
    data: {
      userId: session.userId, companyId: session.companyId, tipo_acesso: "EXCLUIR",
      descricao: `Transcrição apagada: ${reuniao.titulo ?? reuniao.id}`,
    },
  }).catch(() => {})

  return NextResponse.json({ ok: true, apagado: "transcricao" })
}
