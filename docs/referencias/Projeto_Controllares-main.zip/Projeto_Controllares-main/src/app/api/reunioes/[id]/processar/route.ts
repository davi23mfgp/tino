import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { ehVendedorRestrito } from "@/lib/perfil"
import { processarReuniao } from "@/lib/plaud-proposta"

export const dynamic = "force-dynamic"
export const maxDuration = 60

/**
 * Transforma a reunião em proposta.
 *
 * Separado da busca de propósito: baixar a gravação é barato e automático, ler
 * a conversa custa chamada de modelo. Processar sozinho toda gravação que
 * aparece gastaria com reunião interna, teste de aparelho e conversa que não é
 * de venda.
 */
export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (ehVendedorRestrito(session)) return NextResponse.json({ error: "Sem acesso." }, { status: 403 })

  const { id } = await params

  // Confere a empresa antes de processar: id de outra empresa não abre nada.
  const existe = await prisma.reuniao.findFirst({
    where: { id, companyId: session.companyId },
    select: { id: true },
  })
  if (!existe) return NextResponse.json({ error: "Reunião não encontrada" }, { status: 404 })

  const r = await processarReuniao(id, session.userId)

  if (r.status === "PROCESSADA" && r.itens) {
    await prisma.aiAuditLog.create({
      data: {
        userId: session.userId, companyId: session.companyId, tipo_acesso: "CRIAR",
        descricao: `Reunião virou a proposta ${r.numero}: ${r.itens} item(ns)`
          + ` em ${r.ambientes} ambiente(s)`,
      },
    }).catch(() => {})
  }

  return NextResponse.json(r)
}
