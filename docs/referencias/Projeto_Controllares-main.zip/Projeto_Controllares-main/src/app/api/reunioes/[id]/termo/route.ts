import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { aprenderTermo } from "@/lib/plaud-vocabulario"

export const dynamic = "force-dynamic"

/**
 * Ensina ao sistema o que uma fala queria dizer.
 *
 * Toda vez que alguém resolve uma pendência escolhendo o produto — ou corrige
 * a grafia de uma marca que a transcrição comeu —, essa pessoa acabou de dar,
 * de graça, a resposta que o sistema não tinha. Jogar isso fora é o que fazia a
 * mesma reunião gerar a mesma pendência todo mês.
 *
 * Guardado uma vez, o termo vale para todas as reuniões seguintes da empresa.
 *
 * Corpo: { falado: string, productId?: string, correto?: string }
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { id } = await params
  const reuniao = await prisma.reuniao.findFirst({
    where: { id, companyId: session.companyId },
    select: { id: true },
  })
  if (!reuniao) return NextResponse.json({ error: "Reunião não encontrada" }, { status: 404 })

  const body = await req.json().catch(() => ({}))
  const falado = String(body?.falado ?? "").trim()
  if (!falado) return NextResponse.json({ error: "Falta a fala a ensinar." }, { status: 400 })

  const productId = body?.productId ? String(body.productId) : null
  const correto = body?.correto ? String(body.correto).trim().slice(0, 120) : null
  if (!productId && !correto) {
    return NextResponse.json({ error: "Escolha um produto ou informe a grafia certa." }, { status: 400 })
  }

  /* Produto de outra empresa não entra no vocabulário desta: o termo seria
     gravado apontando para algo que ninguém aqui consegue ver. */
  if (productId) {
    const existe = await prisma.catalogProduct.findFirst({
      where: { id: productId, companyId: session.companyId },
      select: { id: true },
    })
    if (!existe) return NextResponse.json({ error: "Produto não encontrado" }, { status: 404 })
  }

  await aprenderTermo(session.companyId, falado, { productId, correto })
  return NextResponse.json({ ok: true })
}
