import { NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { ehVendedorRestrito } from "@/lib/perfil"
import { sincronizarPlaud } from "@/lib/plaud-sync"

export const dynamic = "force-dynamic"

/**
 * Lista as reuniões e o que cada uma virou.
 *
 * Alimenta a gaveta aberta pelo botão em Propostas. Ela existe por causa da
 * falha silenciosa: sem um lugar para olhar, uma gravação que chegou e não
 * produziu item nenhum simplesmente desaparece, e o vendedor só descobre dias
 * depois procurando uma proposta que nunca existiu.
 *
 * A transcrição inteira não vai na lista — é conversa gravada na casa do
 * cliente, e não precisa trafegar para desenhar a linha.
 */
export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (ehVendedorRestrito(session)) return NextResponse.json({ error: "Sem acesso." }, { status: 403 })

  /* Abrir a lista puxa o que há de novo no Plaud.
   *
   * O cron roda uma vez por dia — é o teto do plano —, e esperar até o dia
   * seguinte pela gravação da visita da tarde não serve a ninguém. Aqui a
   * sincronização acontece no momento em que alguém demonstra interesse: abriu
   * a gaveta, é porque quer ver a reunião de agora.
   *
   * Sem `forcar`, então o intervalo mínimo de plaud-sync continua valendo e
   * abrir a tela dez vezes seguidas não vira dez chamadas à API.
   *
   * O await não bloqueia a lista por acidente: a sincronização grava as
   * reuniões novas antes da consulta abaixo, e é justamente isso que faz a
   * gravação recém-chegada aparecer já nesta abertura, e não só na seguinte.
   * Falha de rede do Plaud não pode derrubar a listagem do que já existe.
   */
  await sincronizarPlaud(session.companyId).catch(() => {})

  const reunioes = await prisma.reuniao.findMany({
    where: { companyId: session.companyId },
    orderBy: [{ gravada_em: "desc" }, { createdAt: "desc" }],
    take: 40,
    select: {
      id: true, titulo: true, gravada_em: true, duracao_seg: true,
      status: true, erro: true, pendencias: true, createdAt: true,
      transcricao_apagada_em: true,
      proposal: {
        select: {
          id: true, numero: true, status: true,
          _count: { select: { items: true, environments: true } },
        },
      },
    },
  })

  return NextResponse.json({ reunioes })
}
