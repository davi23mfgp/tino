import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"

export const dynamic = "force-dynamic"

/**
 * Quadros da empresa.
 *
 * Um quadro só obriga a misturar assuntos na mesma coluna — "A fazer" de quê? —
 * ou a criar vinte colunas. Separar por quadro é como as pessoas já pensam o
 * trabalho.
 *
 * GET    lista os quadros e adota as colunas soltas no primeiro
 * POST   cria quadro
 * PATCH  renomeia, troca o fundo, favorita, arquiva
 * DELETE arquiva (não apaga: o quadro leva as colunas e as colunas levam o
 *        vínculo das tarefas)
 */
const COLUNAS_PADRAO = [
  { nome: "A fazer", ordem: 0, final: false, cor: null as string | null },
  { nome: "Fazendo", ordem: 1, final: false, cor: "azul" as string | null },
  { nome: "Parado", ordem: 2, final: false, cor: "amarelo" as string | null },
  { nome: "Feito", ordem: 3, final: true, cor: "verde" as string | null },
]

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  let quadros = await prisma.quadro.findMany({
    where: { companyId: session.companyId, arquivado: false },
    orderBy: [{ favorito: "desc" }, { ordem: "asc" }, { createdAt: "asc" }],
  })

  if (!quadros.length) {
    /* Primeira visita: cria o quadro inicial e ADOTA as colunas que já existem
       soltas. Sem a adoção, quem já usava o quadro veria as tarefas sumirem
       para dentro de colunas invisíveis. */
    const criado = await prisma.quadro.create({
      data: { companyId: session.companyId, nome: "Quadro da equipe" },
    })

    const soltas = await prisma.quadroColuna.findMany({
      where: { companyId: session.companyId, quadroId: null },
      select: { id: true },
    })
    if (soltas.length) {
      await prisma.quadroColuna.updateMany({
        where: { id: { in: soltas.map(c => c.id) } },
        data: { quadroId: criado.id },
      })
    } else {
      await prisma.quadroColuna.createMany({
        data: COLUNAS_PADRAO.map(c => ({ ...c, companyId: session.companyId, quadroId: criado.id })),
      })
    }
    quadros = [criado]
  }

  return NextResponse.json({ quadros })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { nome, fundo } = await req.json().catch(() => ({}))
  const limpo = (nome ?? "").toString().trim()
  if (!limpo) return NextResponse.json({ error: "Dê um nome ao quadro." }, { status: 400 })

  const ultimo = await prisma.quadro.findFirst({
    where: { companyId: session.companyId },
    orderBy: { ordem: "desc" }, select: { ordem: true },
  })

  const quadro = await prisma.quadro.create({
    data: {
      companyId: session.companyId,
      nome: limpo,
      fundo: (fundo ?? "grafite").toString(),
      ordem: (ultimo?.ordem ?? -1) + 1,
    },
  })

  // Quadro novo nasce com colunas: quadro vazio com um botão não diz o que fazer.
  await prisma.quadroColuna.createMany({
    data: COLUNAS_PADRAO.map(c => ({ ...c, companyId: session.companyId, quadroId: quadro.id })),
  })

  return NextResponse.json(quadro, { status: 201 })
}

export async function PATCH(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const body = await req.json().catch(() => ({}))
  const id = (body.id ?? "").toString()
  const existe = await prisma.quadro.findFirst({
    where: { id, companyId: session.companyId }, select: { id: true },
  })
  if (!existe) return NextResponse.json({ error: "Quadro não encontrado" }, { status: 404 })

  const quadro = await prisma.quadro.update({
    where: { id },
    data: {
      ...(body.nome !== undefined && { nome: body.nome.toString().trim() || "Sem nome" }),
      ...(body.fundo !== undefined && { fundo: body.fundo.toString() }),
      ...(body.favorito !== undefined && { favorito: !!body.favorito }),
      ...(body.arquivado !== undefined && { arquivado: !!body.arquivado }),
      ...(body.ordem !== undefined && { ordem: Number(body.ordem) }),
    },
  })
  return NextResponse.json(quadro)
}

export async function DELETE(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const id = new URL(req.url).searchParams.get("id") ?? ""
  const quantos = await prisma.quadro.count({
    where: { companyId: session.companyId, arquivado: false },
  })
  if (quantos <= 1) {
    return NextResponse.json({ error: "Deixe pelo menos um quadro." }, { status: 422 })
  }

  const existe = await prisma.quadro.findFirst({
    where: { id, companyId: session.companyId }, select: { id: true },
  })
  if (!existe) return NextResponse.json({ error: "Quadro não encontrado" }, { status: 404 })

  /* Arquiva, não apaga. Apagar levaria as colunas por cascade e as tarefas
     perderiam o vínculo — uma semana de trabalho sumindo num clique. */
  await prisma.quadro.update({ where: { id }, data: { arquivado: true } })
  return NextResponse.json({ ok: true })
}
