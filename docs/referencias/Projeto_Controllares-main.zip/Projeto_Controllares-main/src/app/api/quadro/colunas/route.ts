import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"

export const dynamic = "force-dynamic"

/* Colunas de estreia. A empresa que nunca configurou nada abre o quadro
   funcionando — quadro vazio com um botão "criar coluna" é uma tela que não
   diz o que fazer, e o primeiro a abrir desiste. */
const PADRAO = [
  { nome: "A fazer", ordem: 0, final: false },
  { nome: "Fazendo", ordem: 1, final: false },
  { nome: "Parado", ordem: 2, final: false },
  { nome: "Feito", ordem: 3, final: true },
]

/** GET /api/quadro/colunas — cria as padrão na primeira visita. */
export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  /* As colunas pertencem a UM quadro. Sem o filtro, abrir o quadro comercial
     mostraria as colunas da obra junto e o quadro deixaria de separar nada. */
  const quadroId = new URL(req.url).searchParams.get("quadroId")

  let colunas = await prisma.quadroColuna.findMany({
    where: {
      companyId: session.companyId,
      arquivada: false,
      ...(quadroId ? { quadroId } : {}),
    },
    orderBy: { ordem: "asc" },
  })

  if (!colunas.length && quadroId) {
    await prisma.quadroColuna.createMany({
      data: PADRAO.map(c => ({ ...c, companyId: session.companyId, quadroId })),
    })
    colunas = await prisma.quadroColuna.findMany({
      where: { companyId: session.companyId, quadroId, arquivada: false },
      orderBy: { ordem: "asc" },
    })
  }

  return NextResponse.json({ colunas })
}

/** POST /api/quadro/colunas — nova coluna, no fim do quadro. */
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const { nome, quadroId } = await req.json().catch(() => ({}))
  const limpo = (nome ?? "").toString().trim()
  if (!limpo) return NextResponse.json({ error: "Dê um nome à coluna." }, { status: 400 })
  if (!quadroId) return NextResponse.json({ error: "Informe o quadro." }, { status: 400 })

  const ultima = await prisma.quadroColuna.findFirst({
    where: { companyId: session.companyId, quadroId },
    orderBy: { ordem: "desc" }, select: { ordem: true },
  })

  const coluna = await prisma.quadroColuna.create({
    data: { companyId: session.companyId, quadroId, nome: limpo, ordem: (ultima?.ordem ?? -1) + 1 },
  })
  return NextResponse.json(coluna, { status: 201 })
}

/** PATCH /api/quadro/colunas — renomeia, reordena ou marca a de encerramento. */
export async function PATCH(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  const body = await req.json().catch(() => ({}))
  const id = (body.id ?? "").toString()
  const existe = await prisma.quadroColuna.findFirst({
    where: { id, companyId: session.companyId }, select: { id: true },
  })
  if (!existe) return NextResponse.json({ error: "Coluna não encontrada" }, { status: 404 })

  /* Só uma coluna encerra o quadro. Duas marcadas fariam a tarefa contar como
     concluída em dois lugares e o relatório somar o mesmo trabalho duas vezes. */
  if (body.final === true) {
    const dona = await prisma.quadroColuna.findUnique({
      where: { id }, select: { quadroId: true },
    })
    await prisma.quadroColuna.updateMany({
      where: { companyId: session.companyId, quadroId: dona?.quadroId ?? null },
      data: { final: false },
    })
  }

  const coluna = await prisma.quadroColuna.update({
    where: { id },
    data: {
      ...(body.nome !== undefined && { nome: body.nome.toString().trim() || "Sem nome" }),
      ...(body.ordem !== undefined && { ordem: Number(body.ordem) }),
      ...(body.final !== undefined && { final: !!body.final }),
      ...(body.cor !== undefined && { cor: body.cor || null }),
      ...(body.recolhida !== undefined && { recolhida: !!body.recolhida }),
      ...(body.arquivada !== undefined && { arquivada: !!body.arquivada }),
    },
  })
  return NextResponse.json(coluna)
}

/** DELETE /api/quadro/colunas?id=… — as tarefas voltam para a primeira coluna. */
export async function DELETE(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin apaga coluna." }, { status: 403 })
  }

  const id = new URL(req.url).searchParams.get("id") ?? ""
  const alvo = await prisma.quadroColuna.findFirst({
    where: { id, companyId: session.companyId }, select: { quadroId: true },
  })
  const colunas = await prisma.quadroColuna.findMany({
    where: { companyId: session.companyId, quadroId: alvo?.quadroId ?? null, arquivada: false },
    orderBy: { ordem: "asc" },
  })
  if (colunas.length <= 1) {
    return NextResponse.json({ error: "O quadro precisa de pelo menos uma coluna." }, { status: 422 })
  }
  if (!colunas.some(c => c.id === id)) {
    return NextResponse.json({ error: "Coluna não encontrada" }, { status: 404 })
  }

  /* Apagar coluna não pode apagar trabalho: as tarefas vão para a primeira
     coluna restante, onde alguém as vê e decide. Sumir com elas seria a
     maneira mais rápida de perder uma semana de tarefas num clique. */
  const destino = colunas.find(c => c.id !== id)!
  await prisma.$transaction([
    prisma.tarefa.updateMany({ where: { colunaId: id }, data: { colunaId: destino.id } }),
    prisma.quadroColuna.delete({ where: { id } }),
  ])

  return NextResponse.json({ ok: true, movidasPara: destino.nome })
}
