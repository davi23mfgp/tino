import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/session"
import { prisma } from "@/lib/prisma"
import { temAlgumPerfil } from "@/lib/perfil"

export const dynamic = "force-dynamic"

/**
 * Perguntas frequentes por empresa.
 *
 * Era uma lista fixa no código: corrigir uma resposta exigia deploy, e toda
 * empresa herdava o texto escrito para a Controllares.
 *
 * Ler é liberado para qualquer pessoa logada — é ajuda, e esconder ajuda de
 * quem precisa dela não faz sentido. Escrever é só do Admin: FAQ que qualquer
 * um edita vira mural de recados.
 */

/* Semente da primeira leitura: sem ela a tela abriria vazia para quem já usava
   o sistema, e as respostas que existiam se perderiam. */
const SEMENTE: { pergunta: string; resposta: string }[] = [
  { pergunta: "Como crio uma proposta para apresentar ao cliente?", resposta: "Vá em Propostas → botão +. Preencha a identificação, monte o escopo por ambientes (adicione itens do catálogo por categoria), configure pagamento e revise. Use o Modo Cliente no passo de escopo para esconder custos internos durante a apresentação." },
  { pergunta: "Como importo meu catálogo em massa?", resposta: "Catálogo → Importar (CSV). Baixe o modelo, preencha nome, marca, preços e a URL da imagem. Marcas novas criam o fornecedor automaticamente e o SKU é gerado pelo prefixo da marca." },
  { pergunta: "Como funciona o cofre de credenciais (CORE)?", resposta: "Credenciais de equipamentos ficam criptografadas por obra. Para revelar é preciso a senha do cofre do seu perfil (padrão configurável pelo ADMIN). Revelações expiram em 30 segundos e todo acesso é auditado." },
  { pergunta: "Como conecto o Google Agenda?", resposta: "Configurações → Integrações → Conectar Google Calendar. Depois, dentro de uma obra com agendamentos, use Sincronizar para enviar os eventos ao seu calendário." },
  { pergunta: "O que acontece quando alguém se cadastra com o CNPJ da empresa?", resposta: "O cadastro entra como PENDENTE. O administrador aprova (escolhendo o perfil) ou recusa em Configurações → Usuários." },
  { pergunta: "Como gero o relatório de dimensionamento?", resposta: "Na obra → aba Dimensionamento → Gerar relatório. Para itens avulsos do catálogo, use a tela Dimensionamento: selecione os itens (ou sincronize com uma proposta) e clique em Gerar relatório." },
  { pergunta: "Como mudo uma proposta de fase?", resposta: "No kanban de Propostas, arraste o card para a nova coluna e confirme. No celular, use os botões de fase no próprio card." },
  { pergunta: "Esqueci a senha do cofre. E agora?", resposta: "Peça ao ADMIN: em Configurações é possível redefinir as senhas do cofre por perfil. Três tentativas erradas bloqueiam o cofre por 10 minutos e notificam o administrador." },
]

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })

  let itens = await prisma.faqItem.findMany({
    where: { companyId: session.companyId },
    orderBy: [{ ordem: "asc" }, { createdAt: "asc" }],
  })

  if (!itens.length) {
    await prisma.faqItem.createMany({
      data: SEMENTE.map((f, i) => ({ ...f, ordem: i, companyId: session.companyId })),
    }).catch(() => {})
    itens = await prisma.faqItem.findMany({
      where: { companyId: session.companyId },
      orderBy: [{ ordem: "asc" }, { createdAt: "asc" }],
    })
  }

  return NextResponse.json({ itens })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin edita o FAQ." }, { status: 403 })
  }

  const { pergunta, resposta } = await req.json().catch(() => ({}))
  if (!pergunta?.trim() || !resposta?.trim()) {
    return NextResponse.json({ error: "Preencha a pergunta e a resposta." }, { status: 400 })
  }

  // Entra no fim da lista: quem cria não deveria ter de escolher a posição.
  const ultimo = await prisma.faqItem.findFirst({
    where: { companyId: session.companyId },
    orderBy: { ordem: "desc" },
    select: { ordem: true },
  })

  const item = await prisma.faqItem.create({
    data: {
      companyId: session.companyId,
      pergunta: pergunta.trim(),
      resposta: resposta.trim(),
      ordem: (ultimo?.ordem ?? -1) + 1,
    },
  })
  return NextResponse.json(item, { status: 201 })
}

export async function PATCH(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin edita o FAQ." }, { status: 403 })
  }

  const { id, pergunta, resposta, ordem } = await req.json().catch(() => ({}))
  if (!id) return NextResponse.json({ error: "id obrigatório" }, { status: 400 })

  const r = await prisma.faqItem.updateMany({
    where: { id, companyId: session.companyId },
    data: {
      ...(pergunta !== undefined && { pergunta: String(pergunta).trim() }),
      ...(resposta !== undefined && { resposta: String(resposta).trim() }),
      ...(ordem !== undefined && { ordem: Number(ordem) || 0 }),
    },
  })
  if (!r.count) return NextResponse.json({ error: "Pergunta não encontrada" }, { status: 404 })
  return NextResponse.json({ ok: true })
}

export async function DELETE(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  if (!temAlgumPerfil(session, ["ADMIN"])) {
    return NextResponse.json({ error: "Só o Admin edita o FAQ." }, { status: 403 })
  }
  const id = new URL(req.url).searchParams.get("id")
  if (!id) return NextResponse.json({ error: "id obrigatório" }, { status: 400 })
  await prisma.faqItem.deleteMany({ where: { id, companyId: session.companyId } })
  return NextResponse.json({ ok: true })
}
