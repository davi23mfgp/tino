"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertCircle, Building2, Loader2 } from "lucide-react";

export default function CadastroGooglePage() {
  const router = useRouter();
  const [nomeEmpresa, setNomeEmpresa] = useState("");
  const [cnpjCpf, setCnpjCpf] = useState("");
  const [erro, setErro] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErro("");
    if (!nomeEmpresa.trim() || !cnpjCpf.trim()) {
      setErro("Preencha todos os campos.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/google/complete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nomeEmpresa, cnpjCpf }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErro(data.error || "Erro ao criar empresa.");
        return;
      }
      router.push("/dashboard");
      router.refresh();
    } catch {
      setErro("Erro de conexão. Tente novamente.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-5 relative">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-sm relative z-10">
        <div className="bg-card/80 backdrop-blur-xl border border-border/60 rounded-3xl p-8 shadow-apple-float">
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
              <Building2 className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-[22px] font-bold text-foreground tracking-tight">
              Quase lá
            </h1>
            <p className="text-[14px] text-muted-foreground mt-0.5 text-center">
              Sua conta Google foi verificada. Complete os dados da empresa.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label className="text-[14px] font-medium text-foreground">
                Nome da Empresa
              </Label>
              <Input
                value={nomeEmpresa}
                onChange={e => setNomeEmpresa(e.target.value)}
                placeholder="Ex: Controllares Automação"
                className="h-[48px] px-4 rounded-xl"
                autoFocus
              />
            </div>

            <div className="space-y-2">
              <Label className="text-[14px] font-medium text-foreground">
                CNPJ / CPF
              </Label>
              <Input
                value={cnpjCpf}
                onChange={e => setCnpjCpf(e.target.value)}
                placeholder="00.000.000/0001-00"
                className="h-[48px] px-4 rounded-xl"
              />
            </div>

            {erro && (
              <div className="flex items-center gap-2 text-destructive text-[13px] bg-destructive/8 border border-destructive/20 rounded-xl px-3 py-2.5">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{erro}</span>
              </div>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-[48px] text-[16px] mt-2"
            >
              {loading ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Criando empresa...</>
              ) : (
                "Entrar no Controllares"
              )}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
