"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ThemeToggle } from "@/components/theme-toggle";
import { ControlDealLogo } from "@/components/logo";
import { AlertCircle, CheckCircle2, Loader2 } from "lucide-react";

interface FormData {
  nomeEmpresa: string;
  cnpjCpf: string;
  nomeAdmin: string;
  email: string;
  senha: string;
  confirmarSenha: string;
}

interface Erros {
  [key: string]: string;
}

export default function CadastroPage() {
  const router = useRouter();
  const [form, setForm] = useState<FormData>({
    nomeEmpresa: "", cnpjCpf: "", nomeAdmin: "", email: "", senha: "", confirmarSenha: "",
  });
  const [erros, setErros] = useState<Erros>({});
  const [erroGeral, setErroGeral] = useState("");
  const [sucesso, setSucesso] = useState(false);
  const [pendingMsg, setPendingMsg] = useState("");
  const [loading, setLoading] = useState(false);

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    if (erros[name]) setErros(prev => ({ ...prev, [name]: "" }));
  }

  function validar(): boolean {
    const novosErros: Erros = {};
    if (!form.nomeEmpresa.trim()) novosErros.nomeEmpresa = "Nome da empresa obrigatório.";
    if (!form.cnpjCpf.trim()) novosErros.cnpjCpf = "CNPJ/CPF obrigatório.";
    if (!form.nomeAdmin.trim()) novosErros.nomeAdmin = "Nome do administrador obrigatório.";
    if (!form.email.trim()) novosErros.email = "E-mail obrigatório.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) novosErros.email = "E-mail inválido.";
    if (!form.senha) novosErros.senha = "Senha obrigatória.";
    else if (form.senha.length < 8) novosErros.senha = "Mínimo 8 caracteres.";
    if (!form.confirmarSenha) novosErros.confirmarSenha = "Confirme a senha.";
    else if (form.senha !== form.confirmarSenha) novosErros.confirmarSenha = "Senhas não coincidem.";
    setErros(novosErros);
    return Object.keys(novosErros).length === 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErroGeral("");
    if (!validar()) return;
    setLoading(true);
    try {
      const res = await fetch("/api/auth/cadastro", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nomeEmpresa: form.nomeEmpresa, cnpjCpf: form.cnpjCpf,
          nomeAdmin: form.nomeAdmin, email: form.email, senha: form.senha,
        }),
      });
      const data = await res.json();
      if (!res.ok) { setErroGeral(data.error || "Erro ao cadastrar."); return; }
      if (data.message) setPendingMsg(data.message);
      setSucesso(true);
      setTimeout(() => router.push("/login"), 4000);
    } catch {
      setErroGeral("Erro de conexão. Tente novamente.");
    } finally {
      setLoading(false);
    }
  }

  const campos = [
    { name: "nomeEmpresa", label: "Nome da Empresa", placeholder: "Ex: Controllares Automação", type: "text" },
    { name: "cnpjCpf", label: "CNPJ / CPF", placeholder: "00.000.000/0001-00", type: "text" },
    { name: "nomeAdmin", label: "Nome do Administrador", placeholder: "Seu nome completo", type: "text" },
    { name: "email", label: "E-mail Principal", placeholder: "contato@suaempresa.com", type: "email" },
    { name: "senha", label: "Senha", placeholder: "Mínimo 8 caracteres, misture letras e números", type: "password" },
    { name: "confirmarSenha", label: "Confirmar Senha", placeholder: "Repita a senha", type: "password" },
  ];

  return (
    <div className="auth-bg min-h-screen flex items-center justify-center p-4 py-8 relative">
      <div className="absolute top-4 right-4 z-10">
        <ThemeToggle />
      </div>

      <div className="w-full max-w-sm relative z-10">
        <div className="auth-card rounded-[28px] p-8">
          <div className="flex flex-col items-center mb-8">
            <div className="marca-vidro mb-4">
              <ControlDealLogo size={40} />
            </div>
            <h1 className="text-[22px] font-bold text-foreground tracking-tight">Criar conta</h1>
            <p className="text-[14px] text-muted-foreground mt-0.5">Sistema Controllares</p>
          </div>

          {sucesso ? (
            <div className="flex flex-col items-center gap-3 py-6 text-emerald-500">
              <CheckCircle2 className="w-12 h-12" />
              <p className="text-center font-medium text-foreground">Empresa cadastrada com sucesso!</p>
              <p className="text-[13px] text-muted-foreground text-center">{pendingMsg || "Aguarde a autorização do dono do site para acessar."}</p>
              <p className="text-[12px] text-muted-foreground/70">Redirecionando para o login...</p>
            </div>
          ) : (
            <>

              <form onSubmit={handleSubmit} className="space-y-4">
                {campos.map(campo => (
                  <div key={campo.name} className="space-y-1.5">
                    <Label htmlFor={campo.name} className="text-[14px] font-medium text-foreground">
                      {campo.label}
                    </Label>
                    <Input
                      id={campo.name}
                      name={campo.name}
                      type={campo.type}
                      placeholder={campo.placeholder}
                      value={form[campo.name as keyof FormData]}
                      onChange={handleChange}
                      className={`h-[48px] px-4 rounded-xl ${erros[campo.name] ? "border-destructive" : ""}`}
                    />
                    {erros[campo.name] && (
                      <p className="text-[12px] text-destructive flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {erros[campo.name]}
                      </p>
                    )}
                  </div>
                ))}

                {erroGeral && (
                  <div className="flex items-center gap-2 text-destructive text-[13px] bg-destructive/8 border border-destructive/20 rounded-xl px-3 py-2.5">
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    <span>{erroGeral}</span>
                  </div>
                )}

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full h-[48px] text-[16px] mt-2"
                >
                  {loading ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Cadastrando...</>
                  ) : "Criar conta"}
                </Button>
              </form>
            </>
          )}

          <p className="text-center text-[13px] text-muted-foreground mt-6">
            Já tem conta?{" "}
            <Link href="/login" className="text-primary hover:text-primary/80 font-medium transition-colors">
              Fazer login
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
