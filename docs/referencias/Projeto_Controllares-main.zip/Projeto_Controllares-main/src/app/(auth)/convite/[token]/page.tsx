"use client"

import { useState, useEffect, use } from "react"
import { useRouter } from "next/navigation"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { UserPlus, AlertCircle } from "lucide-react"
import { MedidorSenha, senhaAceitavel } from "@/components/medidor-senha"

interface InviteInfo { email: string; role: string; empresa: string; logo_url: string | null }

const ROLE_LABEL: Record<string, string> = {
  ADMIN: "Administrador", VENDEDOR: "Vendedor", RESPONSAVEL_TECNICO: "Responsável Técnico",
  ENGENHEIRO_PROJETOS: "Engenheiro de Projetos", INSTALADOR: "Instalador", FINANCEIRO: "Financeiro",
}

export default function ConvitePage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = use(params)
  const router = useRouter()
  const [info, setInfo] = useState<InviteInfo | null>(null)
  const [invalido, setInvalido] = useState(false)
  const [nome, setNome] = useState("")
  const [senha, setSenha] = useState("")
  const [senha2, setSenha2] = useState("")
  const [erro, setErro] = useState("")
  const [enviando, setEnviando] = useState(false)

  useEffect(() => {
    fetch(`/api/convite/${token}`).then(async r => {
      if (r.ok) setInfo(await r.json())
      else setInvalido(true)
    }).catch(() => setInvalido(true))
  }, [token])

  async function aceitar() {
    setErro("")
    if (senha !== senha2) { setErro("As senhas não conferem."); return }
    setEnviando(true)
    try {
      const r = await fetch(`/api/convite/${token}`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, senha }),
      })
      const j = await r.json()
      if (!r.ok) { setErro(j.error || "Erro ao aceitar convite."); return }
      router.push("/dashboard")
    } finally { setEnviando(false) }
  }

  return (
    <div className="auth-bg min-h-screen flex items-center justify-center p-5 relative">
      <div className="w-full max-w-sm relative z-10">
        <div className="auth-card rounded-[28px] p-8">
          {invalido ? (
            <div className="text-center space-y-3 py-6">
              <AlertCircle className="w-10 h-10 text-ios-red/70 mx-auto" />
              <p className="text-foreground font-semibold">Convite inválido ou expirado</p>
              <p className="text-muted-foreground text-sm">Peça um novo link ao administrador da empresa.</p>
            </div>
          ) : !info ? (
            <div className="py-16 text-center text-muted-foreground text-sm animate-pulse">Carregando convite...</div>
          ) : (
            <>
              <div className="flex flex-col items-center mb-7 text-center">
                {info.logo_url ? (
                  /* URL direta, sem o proxy: esta tela é aberta por quem ainda
                     não tem conta, e o proxy passou a exigir sessão para não
                     ser usado como proxy aberto. Se o logo não carregar, cai no
                     ícone padrão — é só identidade visual. */
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={info.logo_url} alt="" className="w-14 h-14 rounded-2xl object-contain mb-3"
                    onError={e => { (e.target as HTMLImageElement).style.display = "none" }} />
                ) : (
                  <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-3">
                    <UserPlus className="w-6 h-6 text-primary" />
                  </div>
                )}
                <h1 className="text-[20px] font-bold text-foreground tracking-tight">Junte-se à {info.empresa}</h1>
                <p className="text-muted-foreground text-[13px] mt-1">
                  Você foi convidado(a) como <b className="text-foreground">{ROLE_LABEL[info.role] ?? info.role}</b>
                </p>
                <p className="text-muted-foreground/60 text-[12px] mt-0.5">{info.email}</p>
              </div>

              <div className="space-y-4">
                <div className="space-y-1.5">
                  <Label className="text-foreground/80 text-[13px]">Seu nome</Label>
                  <Input value={nome} onChange={e => setNome(e.target.value)} placeholder="Nome completo" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-foreground/80 text-[13px]">Crie uma senha</Label>
                  <Input type="password" value={senha} onChange={e => setSenha(e.target.value)} placeholder="Mínimo 10 caracteres" />
                  <MedidorSenha senha={senha} email={info?.email} className="mt-2" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-foreground/80 text-[13px]">Confirme a senha</Label>
                  <Input type="password" value={senha2} onChange={e => setSenha2(e.target.value)} placeholder="Repita a senha" />
                </div>

                {erro && (
                  <p className="text-ios-red text-[13px] bg-ios-red/10 border border-ios-red/25 rounded-xl px-3 py-2">{erro}</p>
                )}

                <Button onClick={aceitar} disabled={enviando || !nome.trim() || !senhaAceitavel(senha, { nome, email: info?.email })}
                  className="w-full h-11 rounded-2xl font-semibold">
                  {enviando ? "Criando conta..." : "Aceitar convite e entrar"}
                </Button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
