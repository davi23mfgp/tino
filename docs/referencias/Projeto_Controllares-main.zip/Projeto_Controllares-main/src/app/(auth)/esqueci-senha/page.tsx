"use client"

import { useState } from "react"
import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { ControlDealLogo } from "@/components/logo"
import { Loader2, MailCheck } from "lucide-react"

export default function EsqueciSenhaPage() {
  const [email, setEmail] = useState("")
  const [enviando, setEnviando] = useState(false)
  const [enviado, setEnviado] = useState(false)

  async function enviar(e: React.FormEvent) {
    e.preventDefault()
    setEnviando(true)
    try {
      await fetch("/api/auth/esqueci-senha", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      })
      // Sempre mostra a mesma tela — a rota não revela se o e-mail existe.
      setEnviado(true)
    } finally {
      setEnviando(false)
    }
  }

  return (
    <div className="auth-bg min-h-screen flex items-center justify-center p-5 relative">
      <div className="w-full max-w-sm relative z-10">
        <div className="auth-card rounded-[28px] p-8">
          <div className="flex flex-col items-center mb-7">
            <div className="marca-vidro mb-4">
              <ControlDealLogo size={40} />
            </div>
            <h1 className="text-[22px] font-bold text-foreground tracking-tight">Esqueci minha senha</h1>
            <p className="text-[14px] text-muted-foreground mt-0.5 text-center">
              {enviado ? "Verifique seu e-mail" : "Enviamos um link para você criar uma nova"}
            </p>
          </div>

          {enviado ? (
            <div className="space-y-5 text-center">
              <div className="flex justify-center">
                <MailCheck className="w-12 h-12 text-ios-green/80" />
              </div>
              <p className="text-[14px] text-muted-foreground">
                Se <b className="text-foreground">{email}</b> tiver uma conta, o link de redefinição já está a caminho.
                O link vale por 1 hora.
              </p>
              <Link href="/login" className="block w-full">
                <Button variant="secondary" className="w-full h-[46px]">Voltar ao login</Button>
              </Link>
            </div>
          ) : (
            <form onSubmit={enviar} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="email" className="text-[14px] font-medium text-foreground">E-mail da conta</Label>
                <Input id="email" type="email" autoFocus required placeholder="seu@email.com"
                  value={email} onChange={e => setEmail(e.target.value)}
                  className="h-[48px] px-4 rounded-xl" autoComplete="email" />
              </div>
              <Button type="submit" disabled={enviando || !email.trim()} className="w-full h-[48px] text-[16px] mt-2">
                {enviando ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Enviando...</> : "Enviar link de redefinição"}
              </Button>
              <Link href="/login"
                className="block w-full text-center text-[13px] text-muted-foreground hover:text-foreground transition-colors">
                Voltar ao login
              </Link>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
