"use client"

import { useState, useEffect, Suspense } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { ControlDealLogo } from "@/components/logo"
import { Loader2, CheckCircle2, AlertCircle } from "lucide-react"
import { MedidorSenha, senhaAceitavel } from "@/components/medidor-senha"

function RedefinirForm() {
  const params = useSearchParams()
  const router = useRouter()
  const token = params.get("token") || ""

  const [estado, setEstado] = useState<"checando" | "valido" | "invalido" | "pronto">("checando")
  const [senha, setSenha] = useState("")
  const [senha2, setSenha2] = useState("")
  const [erro, setErro] = useState("")
  const [salvando, setSalvando] = useState(false)

  useEffect(() => {
    if (!token) { setEstado("invalido"); return }
    fetch(`/api/auth/redefinir-senha?token=${encodeURIComponent(token)}`)
      .then(r => r.json())
      .then(j => setEstado(j.valido ? "valido" : "invalido"))
      .catch(() => setEstado("invalido"))
  }, [token])

  async function salvar(e: React.FormEvent) {
    e.preventDefault()
    setErro("")
    if (senha !== senha2) { setErro("As senhas não conferem."); return }
    if (!senhaAceitavel(senha)) {
      setErro("Senha fraca. Veja as dicas abaixo do campo.")
      return
    }
    setSalvando(true)
    try {
      const r = await fetch("/api/auth/redefinir-senha", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, senha }),
      })
      const j = await r.json()
      if (!r.ok) { setErro(j.error || "Não foi possível redefinir a senha."); return }
      setEstado("pronto")
      setTimeout(() => router.push("/login"), 2500)
    } finally {
      setSalvando(false)
    }
  }

  return (
    <div className="auth-bg min-h-screen flex items-center justify-center p-5 relative">
      <div className="w-full max-w-sm relative z-10">
        <div className="auth-card rounded-[28px] p-8">
          <div className="flex flex-col items-center mb-7">
            <div className="marca-vidro mb-4">
              <ControlDealLogo size={40} />
            </div>
            <h1 className="text-[22px] font-bold text-foreground tracking-tight">Nova senha</h1>
          </div>

          {estado === "checando" && (
            <p className="py-10 text-center text-muted-foreground text-sm animate-pulse">Verificando link...</p>
          )}

          {estado === "invalido" && (
            <div className="text-center space-y-4 py-4">
              <AlertCircle className="w-11 h-11 text-ios-red/70 mx-auto" />
              <p className="text-foreground font-semibold">Link expirado ou inválido</p>
              <p className="text-muted-foreground text-sm">Peça um novo link na tela de recuperação.</p>
              <Link href="/esqueci-senha" className="block w-full">
                <Button className="w-full h-[46px]">Pedir novo link</Button>
              </Link>
            </div>
          )}

          {estado === "pronto" && (
            <div className="text-center space-y-4 py-4">
              <CheckCircle2 className="w-11 h-11 text-ios-green/80 mx-auto" />
              <p className="text-foreground font-semibold">Senha alterada!</p>
              <p className="text-muted-foreground text-sm">Redirecionando para o login...</p>
            </div>
          )}

          {estado === "valido" && (
            <form onSubmit={salvar} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="senha" className="text-[14px] font-medium text-foreground">Nova senha</Label>
                <Input id="senha" type="password" autoFocus placeholder="Mínimo 10 caracteres"
                  value={senha} onChange={e => setSenha(e.target.value)}
                  className="h-[48px] px-4 rounded-xl" autoComplete="new-password" />
                <MedidorSenha senha={senha} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="senha2" className="text-[14px] font-medium text-foreground">Confirme a nova senha</Label>
                <Input id="senha2" type="password" placeholder="Repita a senha"
                  value={senha2} onChange={e => setSenha2(e.target.value)}
                  className="h-[48px] px-4 rounded-xl" autoComplete="new-password" />
              </div>
              {erro && (
                <div className="flex items-center gap-2 text-destructive text-[13px] bg-destructive/8 border border-destructive/20 rounded-xl px-3 py-2.5">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{erro}</span>
                </div>
              )}
              <Button type="submit" disabled={salvando || senha.length < 8} className="w-full h-[48px] text-[16px] mt-2">
                {salvando ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Salvando...</> : "Salvar nova senha"}
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}

export default function RedefinirSenhaPage() {
  return (
    <Suspense>
      <RedefinirForm />
    </Suspense>
  )
}
