"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ThemeToggle } from "@/components/theme-toggle";
import { ControlDealLogo } from "@/components/logo";
import { AlertCircle, Loader2 } from "lucide-react";
import { Suspense } from "react";
import { MedidorSenha, senhaAceitavel } from "@/components/medidor-senha";

const GOOGLE_ERROR_MESSAGES: Record<string, string> = {
  google_cancelled: "Login com Google cancelado.",
  google_invalid: "Link de autenticação inválido.",
  google_state: "Sessão expirada. Tente novamente.",
  google_token: "Erro ao autenticar com Google.",
  google_unverified: "E-mail Google não verificado.",
  google_error: "Erro ao conectar com Google.",
};

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const googleError = searchParams.get("error");

  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState(googleError ? (GOOGLE_ERROR_MESSAGES[googleError] ?? "Erro no login Google.") : "");
  const [loading, setLoading] = useState(false);
  // 2FA: senha ok → pede o código do app autenticador
  const [twofa, setTwofa] = useState(false);
  const [codigo2fa, setCodigo2fa] = useState("");
  // Troca forçada de senha (ADMIN exigiu redefinição)
  const [mustChange, setMustChange] = useState(false);
  const [novaSenha, setNovaSenha] = useState("");
  const [novaSenha2, setNovaSenha2] = useState("");

  function irParaDestino(role: string) {
    const destino: Record<string, string> = {
      ADMIN: "/dashboard", VENDEDOR: "/propostas", FINANCEIRO: "/financeiro",
      RESPONSAVEL_TECNICO: "/operacional", INSTALADOR: "/minha-area", ENGENHEIRO_PROJETOS: "/operacional",
    };
    router.push(destino[role] ?? "/dashboard");
    router.refresh();
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErro("");

    if (mustChange) {
      if (!senhaAceitavel(novaSenha, { email })) {
        setErro("Senha fraca. Veja as dicas abaixo do campo.");
        return;
      }
      if (novaSenha !== novaSenha2) { setErro("As senhas não conferem."); return; }
      setLoading(true);
      try {
        const res = await fetch("/api/auth/trocar-senha", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, senha_atual: senha, senha_nova: novaSenha }),
        });
        const data = await res.json();
        if (!res.ok) { setErro(data.error || "Erro ao trocar a senha."); return; }
        if (data.twofaRequired) {
          // Senha trocada; refaz o login para receber o desafio 2FA
          setMustChange(false); setSenha(novaSenha); setNovaSenha(""); setNovaSenha2("");
          setErro("Senha trocada. Entre novamente para validar o 2FA.");
          return;
        }
        irParaDestino(data.role);
      } catch {
        setErro("Erro de conexão. Tente novamente.");
      } finally {
        setLoading(false);
      }
      return;
    }

    if (twofa) {
      if (codigo2fa.trim().length < 6) { setErro("Digite o código de 6 dígitos."); return; }
      setLoading(true);
      try {
        const res = await fetch("/api/auth/2fa/verify", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ codigo: codigo2fa.trim() }),
        });
        const data = await res.json();
        if (!res.ok) { setErro(data.error || "Código inválido."); return; }
        irParaDestino(data.role);
      } catch {
        setErro("Erro de conexão. Tente novamente.");
      } finally {
        setLoading(false);
      }
      return;
    }

    if (!email || !senha) { setErro("Preencha e-mail e senha."); return; }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, senha }),
      });
      const data = await res.json();
      if (!res.ok) { setErro(data.error || "Erro ao fazer login."); return; }
      if (data.mustChangePassword) { setMustChange(true); return; }
      if (data.twofa) { setTwofa(true); setCodigo2fa(""); return; }
      irParaDestino(data.role);
    } catch {
      setErro("Erro de conexão. Tente novamente.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-bg min-h-screen flex items-center justify-center p-5 relative">
      <div className="absolute top-5 right-5 z-10">
        <ThemeToggle />
      </div>

      <div className="w-full max-w-sm relative z-10">
        <div className="auth-card rounded-[28px] p-8">

          <div className="flex flex-col items-center mb-8">
            {/* Logo em placa de vidro: o PNG oficial é transparente, então
                precisa de uma superfície própria para não flutuar solto. */}
            <div className="marca-vidro mb-4">
              <ControlDealLogo size={44} />
            </div>
            {/* Só a marca. Palavra grande pede tracking fechado. */}
            <h1 className="text-center text-[28px] font-semibold leading-none tracking-[-0.035em] text-foreground">
              Controllares
            </h1>
          </div>

          {/* Login só por e-mail e senha. Google fica só para a Agenda. */}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mustChange ? (
              <div className="space-y-4">
                <p className="text-[13px] text-muted-foreground bg-ios-blue/8 border border-ios-blue/20 rounded-xl px-3 py-2.5">
                  O administrador exigiu a redefinição da sua senha. Crie uma nova para continuar.
                </p>
                <div className="space-y-1.5">
                  <Label htmlFor="novaSenha" className="text-[14px] font-medium text-foreground">Nova senha</Label>
                  <Input id="novaSenha" type="password" autoFocus placeholder="Mínimo 10 caracteres"
                    value={novaSenha} onChange={e => setNovaSenha(e.target.value)}
                    className="h-[48px] px-4 rounded-xl" autoComplete="new-password" />
                </div>
                <div className="space-y-1.5">
                  <MedidorSenha senha={novaSenha} email={email} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="novaSenha2" className="text-[14px] font-medium text-foreground">Confirme a nova senha</Label>
                  <Input id="novaSenha2" type="password" placeholder="Repita a senha"
                    value={novaSenha2} onChange={e => setNovaSenha2(e.target.value)}
                    className="h-[48px] px-4 rounded-xl" autoComplete="new-password" />
                </div>
              </div>
            ) : twofa ? (
              <div className="space-y-1.5">
                <Label htmlFor="codigo2fa" className="text-[14px] font-medium text-foreground">Código do autenticador</Label>
                <Input
                  id="codigo2fa"
                  inputMode="numeric"
                  autoFocus
                  placeholder="000000"
                  maxLength={6}
                  value={codigo2fa}
                  onChange={e => setCodigo2fa(e.target.value.replace(/\D/g, ""))}
                  className="h-[48px] px-4 rounded-xl text-center text-[22px] tracking-[0.4em] font-mono"
                  autoComplete="one-time-code"
                />
                <p className="text-muted-foreground text-[12px]">
                  Abra seu app autenticador (Google Authenticator, 1Password...) e digite o código de 6 dígitos.
                </p>
              </div>
            ) : (
              <>
                <div className="space-y-1.5">
                  <Label htmlFor="email" className="text-[14px] font-medium text-foreground">E-mail</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="seu@email.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className={`h-[48px] px-4 rounded-xl ${erro && !email ? "border-destructive" : ""}`}
                    autoComplete="email"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="senha" className="text-[14px] font-medium text-foreground">Senha</Label>
                  <Input
                    id="senha"
                    type="password"
                    placeholder="••••••••"
                    value={senha}
                    onChange={e => setSenha(e.target.value)}
                    className={`h-[48px] px-4 rounded-xl ${erro && !senha ? "border-destructive" : ""}`}
                    autoComplete="current-password"
                  />
                </div>
              </>
            )}

            {erro && (
              <div className="flex items-center gap-2 text-destructive text-[13px] bg-destructive/8 border border-destructive/20 rounded-xl px-3 py-2.5">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{erro}</span>
              </div>
            )}

            <Button type="submit" disabled={loading} className="w-full h-[48px] text-[16px] mt-2">
              {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Entrando...</>
                : mustChange ? "Salvar nova senha e entrar"
                : twofa ? "Verificar código" : "Entrar"}
            </Button>
            {(twofa || mustChange) && (
              <button type="button" onClick={() => { setTwofa(false); setMustChange(false); setErro("") }}
                className="w-full text-center text-[13px] text-muted-foreground hover:text-foreground transition-colors">
                Voltar ao login
              </button>
            )}
            {!twofa && !mustChange && (
              <Link href="/esqueci-senha"
                className="block w-full text-center text-[13px] text-muted-foreground hover:text-foreground transition-colors">
                Esqueci minha senha
              </Link>
            )}
          </form>

          {/* Sem convite para cadastrar empresa: o acesso é por convite do Admin.
              Oferecer autoatendimento aqui promete uma porta que ainda não
              existe — volta quando o sistema for aberto ao mercado. */}
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  );
}
