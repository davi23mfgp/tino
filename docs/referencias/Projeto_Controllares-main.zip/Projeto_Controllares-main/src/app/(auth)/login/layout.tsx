import type { Metadata } from "next"

/**
 * Metadados próprios do login.
 *
 * A página é client component e não pode exportar `metadata`, então herdava o
 * título e a descrição do layout raiz. Toda página do sistema saía com o mesmo
 * par — que é o "Title duplicates"/"Description duplicates" da auditoria — e
 * sem canonical, o buscador trata /login e / como candidatos ao mesmo conteúdo.
 */
export const metadata: Metadata = {
  title: "Entrar",
  description:
    "Acesso ao sistema da Controllares. Área restrita a usuários cadastrados —"
    + " propostas, obras, catálogo e financeiro.",
  alternates: { canonical: "/login" },
  // Tela de acesso não tem por que aparecer em busca; seguir os links, sim.
  robots: { index: false, follow: true },
}

export default function LoginLayout({ children }: { children: React.ReactNode }) {
  return children
}
