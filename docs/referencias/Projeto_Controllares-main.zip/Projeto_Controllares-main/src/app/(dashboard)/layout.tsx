import { redirect } from "next/navigation";
import { getSession } from "@/lib/session";
import { SidebarLayout } from "@/components/sidebar-layout";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getSession();

  if (!session) {
    redirect("/login");
  }

  return <SidebarLayout session={session}>{children}</SidebarLayout>;
}
