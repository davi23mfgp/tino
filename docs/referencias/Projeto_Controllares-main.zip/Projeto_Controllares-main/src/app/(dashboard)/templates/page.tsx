"use client"

import { useState, useEffect, useCallback, useMemo } from "react"
import { useRouter } from "next/navigation"
import { Copy, FileSignature, FileText, LayoutTemplate, Pencil, Plus, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { EmptyState } from "@/components/ui/empty-state"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { PageLoader } from "@/components/ui/bouncing-dots"
import { CabecalhoPagina } from "@/components/ui/cabecalho-pagina"
import { CartaoMetrica, FaixaMetricas } from "@/components/ui/cartao-metrica"
import { BarraFiltros } from "@/components/ui/barra-filtros"
import { useMemoriaDeFiltro } from "@/hooks/usar-memoria-filtro"

/* ──────────────────────────────────────────────────────────────────────────
   Modelos — tudo que é escrito uma vez e reaproveitado sempre.

   Eram três coisas em lugares diferentes: a estrutura de proposta ficava aqui
   (como "Propostas Modelo"), as páginas de anexo só apareciam dentro do editor
   de proposta, e o contrato não existia — era redigido fora do sistema. Quem
   procurava "o modelo" não sabia em qual tela olhar.

   Os três vêm de fontes distintas e continuam vindo: a proposta é uma árvore
   de ambientes e itens (/api/templates), anexo e contrato são texto
   (/api/page-templates). O que muda é que a pessoa vê tudo numa lista só.
   ────────────────────────────────────────────────────────────────────────── */

type Tipo = "PROPOSTA" | "CONTRATO" | "ANEXO"
type Filtro = "TODOS" | Tipo

interface ModeloProposta {
  id: string
  nome: string
  createdAt: string
  autor: { nome: string; email: string }
  categorias?: string[]
}

interface ModeloTexto {
  id: string
  nome: string
  tipo: string
  descricao: string | null
  conteudo: string
  updatedAt: string
}

/** Forma comum: a lista mostra os três lado a lado. */
interface Modelo {
  id: string
  nome: string
  tipo: Tipo
  detalhe: string
  etiquetas: string[]
  /** Primeiras linhas do texto — para reconhecer o modelo sem abrir. */
  previa?: string
}

interface Proposta { id: string; numero: string; client_name: string }

const ROTULO: Record<Tipo, string> = {
  PROPOSTA: "Proposta",
  CONTRATO: "Contrato",
  ANEXO: "Anexo",
}

const ICONE: Record<Tipo, typeof FileText> = {
  PROPOSTA: FileText,
  CONTRATO: FileSignature,
  ANEXO: Copy,
}

/* Placeholders trocados na hora de gerar o contrato, agrupados pelo que
   representam. Ficam à vista no editor porque escrever "{{clientes}}" errado
   só apareceria no documento impresso.

   Valem SÓ para contrato: a página de anexo é copiada como texto para a
   proposta, sem passar por substituição. Oferecer variáveis lá seria prometer
   algo que não acontece — o cliente receberia "{{valor}}" impresso. */
const VARIAVEIS: { grupo: string; itens: string[] }[] = [
  { grupo: "Contratante", itens: ["{{cliente}}", "{{documento}}", "{{endereco}}"] },
  { grupo: "Obra", itens: ["{{endereco_obra}}"] },
  { grupo: "Negócio", itens: ["{{proposta}}", "{{valor}}", "{{pagamento}}", "{{parcelas}}", "{{tabela_parcelas}}", "{{itens}}", "{{data}}"] },
  { grupo: "Contratada", itens: ["{{empresa}}", "{{cnpj_empresa}}"] },
]

export default function ModelosPage() {
  const router = useRouter()

  const [propostaModelos, setPropostaModelos] = useState<ModeloProposta[]>([])
  const [textoModelos, setTextoModelos] = useState<ModeloTexto[]>([])
  const [propostas, setPropostas] = useState<Proposta[]>([])
  const [carregando, setCarregando] = useState(true)

  const [busca, setBusca] = useMemoriaDeFiltro("templates:busca", "")
  const [filtro, setFiltro] = useMemoriaDeFiltro<Filtro>("templates:tipo", "TODOS")

  // Criação/edição de modelo de texto (contrato e anexo).
  const [editorAberto, setEditorAberto] = useState(false)
  const [editando, setEditando] = useState<ModeloTexto | null>(null)
  const [form, setForm] = useState({ nome: "", tipo: "CONTRATO" as Tipo, descricao: "", conteudo: "" })
  const [salvando, setSalvando] = useState(false)

  // Criação de modelo de proposta (estrutura, não texto).
  const [propostaAberta, setPropostaAberta] = useState(false)
  const [nomeProposta, setNomeProposta] = useState("")
  const [baseProposta, setBaseProposta] = useState("")

  const [excluindo, setExcluindo] = useState<Modelo | null>(null)
  const [removendo, setRemovendo] = useState(false)

  const carregar = useCallback(async () => {
    setCarregando(true)
    try {
      const [a, b, c] = await Promise.all([
        fetch("/api/templates", { cache: "no-store" }),
        fetch("/api/page-templates", { cache: "no-store" }),
        fetch("/api/propostas", { cache: "no-store" }),
      ])
      if (a.ok) setPropostaModelos((await a.json()).templates ?? [])
      if (b.ok) setTextoModelos((await b.json()).templates ?? [])
      if (c.ok) {
        const j = await c.json()
        setPropostas(j.proposals ?? j.propostas ?? [])
      }
    } finally { setCarregando(false) }
  }, [])

  useEffect(() => { carregar() }, [carregar])

  const modelos: Modelo[] = useMemo(() => [
    ...propostaModelos.map(t => ({
      id: t.id,
      nome: t.nome,
      tipo: "PROPOSTA" as Tipo,
      detalhe: `Por ${t.autor?.nome ?? "—"} · ${new Date(t.createdAt).toLocaleDateString("pt-BR")}`,
      etiquetas: t.categorias ?? [],
    })),
    ...textoModelos.map(t => ({
      id: t.id,
      nome: t.nome,
      tipo: (t.tipo === "CONTRATO" ? "CONTRATO" : "ANEXO") as Tipo,
      detalhe: t.descricao || `Atualizado em ${new Date(t.updatedAt).toLocaleDateString("pt-BR")}`,
      etiquetas: [],
      previa: t.conteudo.replace(/\s+/g, " ").trim().slice(0, 180),
    })),
  ], [propostaModelos, textoModelos])

  const visiveis = useMemo(() => {
    const termo = busca.trim().toLowerCase()
    return modelos.filter(m =>
      (filtro === "TODOS" || m.tipo === filtro) &&
      (!termo || m.nome.toLowerCase().includes(termo) || m.detalhe.toLowerCase().includes(termo)),
    )
  }, [modelos, filtro, busca])

  const contagem = (t: Tipo) => modelos.filter(m => m.tipo === t).length

  function abrirNovoTexto(tipo: Tipo) {
    setEditando(null)
    setForm({ nome: "", tipo, descricao: "", conteudo: "" })
    setEditorAberto(true)
  }

  function abrirEdicao(m: Modelo) {
    if (m.tipo === "PROPOSTA") {
      // Estrutura de proposta se edita montando a proposta, não num campo de texto.
      router.push(`/propostas/nova?templateId=${m.id}`)
      return
    }
    const t = textoModelos.find(x => x.id === m.id)
    if (!t) return
    setEditando(t)
    setForm({
      nome: t.nome,
      tipo: t.tipo === "CONTRATO" ? "CONTRATO" : "ANEXO",
      descricao: t.descricao ?? "",
      conteudo: t.conteudo,
    })
    setEditorAberto(true)
  }

  async function salvarTexto() {
    if (!form.nome.trim()) return
    setSalvando(true)
    try {
      const r = await fetch("/api/page-templates", {
        method: editando ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...(editando ? { id: editando.id } : {}), ...form }),
      })
      if (!r.ok) { alert((await r.json().catch(() => ({}))).error || "Não foi possível salvar."); return }
      setEditorAberto(false)
      carregar()
    } finally { setSalvando(false) }
  }

  async function criarModeloProposta() {
    if (!nomeProposta.trim()) return
    setSalvando(true)
    try {
      await fetch("/api/templates", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome: nomeProposta.trim(), proposalId: baseProposta || undefined }),
      })
      setPropostaAberta(false)
      setNomeProposta(""); setBaseProposta("")
      carregar()
    } finally { setSalvando(false) }
  }

  async function excluir() {
    if (!excluindo) return
    setRemovendo(true)
    try {
      const url = excluindo.tipo === "PROPOSTA"
        ? `/api/templates/${excluindo.id}`
        : `/api/page-templates?id=${excluindo.id}`
      await fetch(url, { method: "DELETE" })
      setExcluindo(null)
      carregar()
    } finally { setRemovendo(false) }
  }

  return (
    <div className="mx-auto max-w-[1560px] space-y-3 p-4 sm:space-y-4 sm:p-6">
      <CabecalhoPagina
        icone={LayoutTemplate}
        titulo="Modelos"
        contexto={`${modelos.length} disponíve${modelos.length === 1 ? "l" : "is"}`}
        acao={
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="h-9 gap-1.5" onClick={() => setPropostaAberta(true)}>
              <Plus className="h-4 w-4" /> <span className="hidden sm:inline">Modelo de proposta</span>
            </Button>
            <Button size="sm" className="h-9 gap-1.5" onClick={() => abrirNovoTexto("CONTRATO")}>
              <Plus className="h-4 w-4" /> Novo modelo
            </Button>
          </div>
        }
      />

      <FaixaMetricas>
        <CartaoMetrica icone={LayoutTemplate} rotulo="Modelos" valor={modelos.length} nota="Todos os tipos" />
        <CartaoMetrica icone={FileText} rotulo="Proposta" valor={contagem("PROPOSTA")} nota="Escopo e itens" />
        <CartaoMetrica icone={FileSignature} rotulo="Contrato" valor={contagem("CONTRATO")} nota="Minutas prontas" />
        <CartaoMetrica icone={Copy} rotulo="Anexo" valor={contagem("ANEXO")} nota="Páginas da proposta" />
      </FaixaMetricas>

      <BarraFiltros
        busca={busca}
        aoBuscar={setBusca}
        placeholder="Buscar por nome..."
        valor={filtro}
        aoTrocar={setFiltro}
        opcoes={[
          { valor: "TODOS", rotulo: "Todos" },
          { valor: "PROPOSTA", rotulo: "Proposta" },
          { valor: "CONTRATO", rotulo: "Contrato" },
          { valor: "ANEXO", rotulo: "Anexo" },
        ] as const}
      />

      {carregando ? (
        <div className="flex justify-center py-20"><PageLoader /></div>
      ) : visiveis.length === 0 ? (
        <EmptyState
          icon={LayoutTemplate}
          title={modelos.length ? "Nenhum modelo com esse filtro" : "Nenhum modelo ainda"}
          subtitle={modelos.length
            ? "Ajuste a busca ou escolha outro tipo."
            : "Escreva uma vez a minuta, a página de anexo ou o escopo padrão e reaproveite em toda proposta."}
          action={modelos.length
            ? undefined
            : <Button onClick={() => abrirNovoTexto("CONTRATO")}>Criar o primeiro</Button>}
        />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:gap-4 md:grid-cols-2 xl:grid-cols-3">
          {visiveis.map(m => {
            const Icone = ICONE[m.tipo]
            return (
              <div key={`${m.tipo}-${m.id}`} className="ios-card group flex flex-col gap-3 p-4 sm:p-5">
                <div className="flex items-start justify-between gap-2">
                  <div className="grid size-10 shrink-0 place-items-center rounded-2xl bg-foreground/[0.08] ring-1 ring-inset ring-border">
                    <Icone className="size-[18px] text-foreground" strokeWidth={1.8} />
                  </div>
                  <span className="rounded-full bg-foreground/[0.06] px-2.5 py-1 text-[11px] font-medium text-muted-foreground">
                    {ROTULO[m.tipo]}
                  </span>
                </div>

                <div className="min-w-0 flex-1">
                  <h3 className="truncate font-semibold text-foreground">{m.nome}</h3>
                  <p className="mt-0.5 line-clamp-1 text-[12px] text-muted-foreground">{m.detalhe}</p>
                  {m.previa ? (
                    <p className="mt-2.5 line-clamp-3 rounded-xl bg-foreground/[0.03] p-2.5 text-[12px] leading-relaxed text-muted-foreground">
                      {m.previa}
                    </p>
                  ) : m.tipo !== "PROPOSTA" ? (
                    <p className="mt-2.5 rounded-xl border border-dashed border-border p-2.5 text-[12px] text-muted-foreground">
                      Sem conteúdo ainda.
                    </p>
                  ) : null}
                  {m.etiquetas.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {m.etiquetas.map(c => (
                        <span key={c} className="rounded-full bg-ios-blue/10 px-2 py-0.5 text-[11px] font-medium text-ios-blue">
                          {c}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 border-t border-border pt-3">
                  {m.tipo === "PROPOSTA" ? (
                    <Button size="sm" variant="outline" className="flex-1"
                      onClick={() => router.push(`/propostas/nova?templateId=${m.id}`)}>
                      Usar na proposta
                    </Button>
                  ) : (
                    <Button size="sm" variant="outline" className="flex-1 gap-1.5" onClick={() => abrirEdicao(m)}>
                      <Pencil className="h-3.5 w-3.5" /> Editar
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" onClick={() => setExcluindo(m)}
                    className="h-8 w-8 shrink-0 p-0 text-muted-foreground hover:text-ios-red">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* ── Editor de contrato / anexo ── */}
      <Dialog open={editorAberto} onOpenChange={setEditorAberto}>
        <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editando ? "Editar modelo" : "Novo modelo"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 px-5 py-4 sm:px-6">
            <div className="space-y-1.5">
              <Label>Tipo</Label>
              <div className="inline-flex rounded-xl border border-border bg-muted p-0.5 text-[13px]">
                {(["CONTRATO", "ANEXO"] as const).map(t => (
                  <button key={t} type="button" onClick={() => setForm(f => ({ ...f, tipo: t }))}
                    className={`rounded-[10px] px-3.5 py-1.5 transition-colors ${
                      form.tipo === t ? "bg-background font-medium text-foreground shadow-sm" : "text-muted-foreground"
                    }`}>
                    {ROTULO[t]}
                  </button>
                ))}
              </div>
              <p className="text-[12px] text-muted-foreground">
                {form.tipo === "CONTRATO"
                  ? "Vira o contrato gerado quando a proposta chega na etapa Contrato."
                  : "Fica disponível para inserir como página na proposta."}
              </p>
            </div>

            <div className="space-y-1.5">
              <Label>Nome *</Label>
              <Input value={form.nome} onChange={e => setForm(f => ({ ...f, nome: e.target.value }))}
                placeholder={form.tipo === "CONTRATO" ? "Ex.: Contrato de instalação residencial" : "Ex.: Termos de garantia"} />
            </div>

            <div className="space-y-1.5">
              <Label>Para que serve</Label>
              <Input value={form.descricao} onChange={e => setForm(f => ({ ...f, descricao: e.target.value }))}
                placeholder="Aparece no cartão da lista" />
            </div>

            <div className="space-y-1.5">
              <Label>{form.tipo === "CONTRATO" ? "Minuta" : "Texto da página"}</Label>
              <Textarea rows={14} value={form.conteudo}
                onChange={e => setForm(f => ({ ...f, conteudo: e.target.value }))}
                className="font-mono text-[13px] leading-relaxed"
                placeholder={form.tipo === "CONTRATO"
                  ? "Cole ou escreva as cláusulas. Onde entra um dado da proposta, use a variável correspondente."
                  : "Escreva o texto que vai aparecer como página da proposta."} />

              {form.tipo === "CONTRATO" ? (
                <div className="rounded-xl border border-border bg-foreground/[0.03] p-3">
                  <p className="mb-2 text-[12px] text-muted-foreground">
                    Clique para inserir no ponto final do texto. São trocadas pelos dados reais ao gerar o contrato.
                  </p>
                  <div className="space-y-2">
                    {VARIAVEIS.map(g => (
                      <div key={g.grupo} className="flex flex-wrap items-center gap-1.5">
                        <span className="w-[86px] shrink-0 text-[11px] uppercase tracking-wide text-muted-foreground">
                          {g.grupo}
                        </span>
                        {g.itens.map(v => (
                          <button key={v} type="button"
                            onClick={() => setForm(f => ({ ...f, conteudo: f.conteudo + v }))}
                            className="rounded-lg bg-foreground/[0.07] px-2 py-1 font-mono text-[11px] text-foreground/80 transition-colors hover:bg-foreground/[0.12] hover:text-foreground">
                            {v}
                          </button>
                        ))}
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <p className="text-[12px] text-muted-foreground">
                  A página entra na proposta como está escrita aqui, sem variáveis. Para
                  texto que muda por cliente, use um modelo de contrato.
                </p>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setEditorAberto(false)}>Cancelar</Button>
            <Button onClick={salvarTexto} disabled={salvando || !form.nome.trim()}>
              {salvando ? "Salvando..." : "Salvar modelo"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Novo modelo de proposta (estrutura) ── */}
      <Dialog open={propostaAberta} onOpenChange={setPropostaAberta}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Novo modelo de proposta</DialogTitle></DialogHeader>
          <div className="space-y-4 px-5 py-4 sm:px-6">
            <div className="space-y-1.5">
              <Label>Nome *</Label>
              <Input value={nomeProposta} onChange={e => setNomeProposta(e.target.value)}
                placeholder="Ex.: Residencial padrão" />
            </div>
            <div className="space-y-1.5">
              <Label>Copiar o escopo de uma proposta</Label>
              <select value={baseProposta} onChange={e => setBaseProposta(e.target.value)}
                className="flex h-10 w-full rounded-xl border border-border bg-muted px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-ring/40">
                <option value="">Começar em branco</option>
                {propostas.map(p => (
                  <option key={p.id} value={p.id}>{p.numero}, {p.client_name}</option>
                ))}
              </select>
              <p className="text-[12px] text-muted-foreground">
                Traz os ambientes e itens da proposta escolhida. Os valores são recalculados a cada uso.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setPropostaAberta(false)}>Cancelar</Button>
            <Button onClick={criarModeloProposta} disabled={salvando || !nomeProposta.trim()}>
              {salvando ? "Salvando..." : "Criar modelo"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Exclusão ── */}
      <Dialog open={!!excluindo} onOpenChange={o => !o && setExcluindo(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Excluir modelo</DialogTitle></DialogHeader>
          <p className="px-5 text-sm text-muted-foreground sm:px-6">
            Excluir <span className="font-semibold text-foreground">{excluindo?.nome}</span>? Não dá para desfazer.
            As propostas e contratos já gerados a partir dele não mudam.
          </p>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setExcluindo(null)}>Cancelar</Button>
            <Button onClick={excluir} disabled={removendo} className="bg-ios-red text-background hover:bg-ios-red/90">
              {removendo ? "Excluindo..." : "Excluir"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
