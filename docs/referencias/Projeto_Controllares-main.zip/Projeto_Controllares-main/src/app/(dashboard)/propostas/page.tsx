﻿"use client"

import { PageLoader } from "@/components/ui/bouncing-dots"
import { useState, useEffect, useCallback, Suspense } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { FileText, KanbanSquare, Plus, Calendar, User, X, Search, ChevronRight, ChevronLeft, Mic } from "lucide-react"
import { MonthPicker } from "@/components/month-picker"
import { Button } from "@/components/ui/button"
import { CabecalhoPagina } from "@/components/ui/cabecalho-pagina"
import { GavetaReunioes } from "@/components/gaveta-reunioes"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog"
import {
  DndContext,
  PointerSensor,
  pointerWithin,
  useDraggable,
  useDroppable,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragStartEvent,
} from "@dnd-kit/core"
import { useMemoriaDeFiltro } from "@/hooks/usar-memoria-filtro"
import { brl } from "@/lib/formato"


type ProposalStatus = "RASCUNHO" | "ENVIADA" | "LIDA" | "EM_REVISAO" | "ACEITA" | "EM_FATURAMENTO" | "EM_CONTRATO" | "CONCLUIDA" | "CANCELADA" | "PROPOSTA_PERDIDA"

// Motivos pré-cadastrados de perda (select do modal + campo livre opcional)
const MOTIVOS_PERDA = [
  "Preço acima do concorrente",
  "Prazo de entrega",
  "Cliente desistiu do projeto",
  "Sem retorno do cliente",
  "Escopo mudou",
  "Fechou com concorrente",
]

const COLUMNS: { id: ProposalStatus; label: string; color: string; dot: string; zone: string; header: string; bl: string; bt: string }[] = [
  { id: "RASCUNHO",   label: "Rascunho",    color: "text-muted-fg",   dot: "bg-muted-fg",    zone: "bg-surface-2/40",  header: "bg-surface-2/60", bl: "border-l-muted-fg/40", bt: "border-t-muted-fg/40" },
  { id: "ENVIADA",    label: "Enviada",     color: "text-ios-blue",   dot: "bg-ios-blue",    zone: "bg-ios-blue/5",    header: "bg-ios-blue/10",   bl: "border-l-ios-blue",   bt: "border-t-ios-blue" },
  { id: "LIDA",       label: "Lida",        color: "text-ios-purple", dot: "bg-ios-purple",  zone: "bg-ios-purple/5",  header: "bg-ios-purple/10", bl: "border-l-ios-purple", bt: "border-t-ios-purple" },
  { id: "EM_REVISAO", label: "Em Revisão",  color: "text-ios-orange", dot: "bg-ios-orange",  zone: "bg-ios-orange/5",  header: "bg-ios-orange/10", bl: "border-l-ios-orange", bt: "border-t-ios-orange" },
  { id: "ACEITA",     label: "Aceita",      color: "text-ios-green",  dot: "bg-ios-green",   zone: "bg-ios-green/5",   header: "bg-ios-green/10",  bl: "border-l-ios-green",  bt: "border-t-ios-green" },
  /* Contrato vem ANTES de faturamento: o cliente aceita, assina o contrato e
     só então se fatura. A ordem anterior punha faturamento primeiro, o que
     convidava a faturar antes da assinatura. */
  { id: "EM_CONTRATO", label: "Contrato", color: "text-ios-purple", dot: "bg-ios-purple", zone: "bg-ios-purple/5", header: "bg-ios-purple/10", bl: "border-l-ios-purple", bt: "border-t-ios-purple" },
  { id: "EM_FATURAMENTO", label: "Em Faturamento", color: "text-ios-teal", dot: "bg-ios-teal", zone: "bg-ios-teal/5", header: "bg-ios-teal/10", bl: "border-l-ios-teal", bt: "border-t-ios-teal" },
  { id: "CONCLUIDA",  label: "Concluída",   color: "text-ios-green",  dot: "bg-ios-green",   zone: "bg-ios-green/5",   header: "bg-ios-green/10",  bl: "border-l-ios-green",  bt: "border-t-ios-green" },
  { id: "CANCELADA",  label: "Cancelada",   color: "text-ios-red",    dot: "bg-ios-red",     zone: "bg-ios-red/5",     header: "bg-ios-red/10",    bl: "border-l-ios-red",    bt: "border-t-ios-red" },
  { id: "PROPOSTA_PERDIDA", label: "Perdida", color: "text-ios-red", dot: "bg-ios-red", zone: "bg-ios-red/5", header: "bg-ios-red/10", bl: "border-l-ios-red", bt: "border-t-ios-red" },
]

const STATUS_LABELS_MAP: Record<ProposalStatus, string> = {
  RASCUNHO: "Rascunho",
  ENVIADA: "Enviada",
  LIDA: "Lida",
  EM_REVISAO: "Em Revisão",
  ACEITA: "Aceita",
  EM_FATURAMENTO: "Em Faturamento",
  EM_CONTRATO: "Contrato",
  CONCLUIDA: "Concluída",
  CANCELADA: "Cancelada",
  PROPOSTA_PERDIDA: "Perdida",
}

const STATUS_BADGE: Record<ProposalStatus, "secondary" | "default" | "outline" | "destructive" | "success" | "warning"> = {
  RASCUNHO: "secondary",
  ENVIADA: "default",
  LIDA: "outline",
  EM_REVISAO: "warning",
  ACEITA: "success",
  EM_FATURAMENTO: "default",
  EM_CONTRATO: "default",
  CONCLUIDA: "success",
  CANCELADA: "destructive",
  PROPOSTA_PERDIDA: "destructive",
}

interface Proposal {
  id: string
  numero: string
  client_name: string
  valor_total: number
  data_expiracao: string | null
  createdAt: string
  status: ProposalStatus
  last_opened_at: string | null
  open_count: number
  vendedor: { nome: string }
}

function relativeTime(iso: string): string {
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000)
  if (diff < 60) return "agora"
  if (diff < 3600) return `${Math.floor(diff / 60)}min`
  if (diff < 86400) return `${Math.floor(diff / 3600)}h`
  if (diff < 86400 * 7) return `${Math.floor(diff / 86400)}d`
  return new Date(iso).toLocaleDateString("pt-BR", { day: "numeric", month: "short" })
}

function ProposalCard({ proposal }: { proposal: Proposal }) {
  const router = useRouter()
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({ id: proposal.id })

  // Sem fantasma: o cartão em si acompanha o cursor. Fica opaco e por cima dos
  // outros, senão some atrás da coluna vizinha durante o arraste.
  const style = transform ? {
    transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
    zIndex: 50,
    position: "relative" as const,
    boxShadow: "0 18px 40px -12px rgba(0,0,0,.55)",
  } : undefined

  const col = COLUMNS.find(c => c.id === proposal.status)

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...listeners}
      {...attributes}
      /* O CARD INTEIRO arrasta, não só a alça.

         Pegar um card exigia acertar um ícone de 14 px no canto: quem tentava
         arrastar pelo corpo só abria a proposta. O sensor exige 6 px de
         movimento antes de considerar arraste, então o clique parado continua
         abrindo — as duas coisas convivem no mesmo alvo. */
      onClick={() => { if (!isDragging) router.push(`/propostas/${proposal.id}`) }}
      className={`bg-surface-1 rounded-2xl p-3 space-y-2 overflow-hidden border border-hairline border-l-[3px] ${col?.bl ?? "border-l-hairline"} transition-all duration-150 select-none ${
        isDragging ? "cursor-grabbing" : "cursor-grab hover:bg-surface-2 hover:-translate-y-px"
      }`}
    >
      {/* O nome do cliente ocupa a linha inteira, e não a fatia que sobra ao
          lado dos selos: dividindo a mesma linha com "lida 4min", o status e a
          alça de arrastar, ele era cortado no primeiro caractere ("A...") e o
          card deixava de dizer de quem era a proposta. Duas linhas resolvem
          sem esconder nada. */}
      <div className="min-w-0">
        <p className="text-foreground font-medium text-sm break-words leading-snug">{proposal.client_name}</p>
      </div>
      {/* Envolve em vez de empurrar para fora.

          Número, "lida 27min", selo e alça numa linha só somavam mais que a
          largura do card: o conteúdo transbordava e a alça aparecia do lado de
          fora da borda arredondada. Sem `flex-shrink-0` em tudo e com quebra
          permitida, o que não couber desce para a linha de baixo — dentro do
          card. A alça saiu: o card inteiro já arrasta, e ela era o item que
          transbordava sem informar nada. */}
      <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1">
        <p className="min-w-0 truncate text-xs text-muted-foreground">{proposal.numero}</p>
        <div className="flex min-w-0 flex-wrap items-center justify-end gap-1">
          {/* Leitura só importa enquanto a bola está com o cliente.
              Antes aparecia em qualquer status — inclusive Perdida, Aceita,
              Concluída — e "não lida" numa proposta perdida não pergunta
              nada, porque a resposta dele já chegou por outro canal e não
              depende mais de abrir o link. Só as três etapas em que o
              próximo passo é justamente ele ler e decidir. */}
          {["ENVIADA", "LIDA", "EM_REVISAO"].includes(proposal.status) && (
            proposal.last_opened_at ? (
              <span className="text-[10px] text-purple-500 font-medium whitespace-nowrap"
                title={`${proposal.open_count}x aberto`}>
                lida {relativeTime(proposal.last_opened_at)}
              </span>
            ) : (
              <span className="text-[10px] text-muted-foreground font-medium whitespace-nowrap"
                title="O cliente ainda não abriu o link da proposta">
                não lida
              </span>
            )
          )}
          <Badge variant={STATUS_BADGE[proposal.status]} className="text-xs">
            {STATUS_LABELS_MAP[proposal.status] ?? proposal.status}
          </Badge>
        </div>
      </div>
      <p className="text-foreground font-semibold">{brl(Number(proposal.valor_total))}</p>
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span className="flex items-center gap-1">
          <User className="w-3 h-3" /> {proposal.vendedor?.nome || "–"}
        </span>
        {proposal.data_expiracao && (
          <span className="flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            {new Date(proposal.data_expiracao).toLocaleDateString("pt-BR")}
          </span>
        )}
      </div>
    </div>
  )
}

function DroppableColumn({ column, proposals }: {
  column: typeof COLUMNS[0]
  proposals: Proposal[]
}) {
  const { setNodeRef, isOver } = useDroppable({ id: column.id })

  /* Quanto a etapa vale, não só quantas propostas tem.
     "Concluída 2" não diz se o mês fechou em 8 mil ou em 180 mil — a
     contagem trata uma proposta de R$ 8.000 e uma de R$ 125.000 como a
     mesma coisa. Some em linha própria: o cabeçalho tem 260px e o total
     disputando espaço com o contador cortava o nome da coluna. */
  const totalColuna = proposals.reduce((s, p) => s + Number(p.valor_total || 0), 0)

  return (
    <div className="flex flex-col min-w-[220px] max-w-[260px] flex-1">
      {/* Column header */}
      <div className={`mb-2 px-3 py-2 rounded-t-xl border-t-[3px] ${column.bt} ${column.header}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 min-w-0">
            <span className={`w-2 h-2 rounded-full flex-shrink-0 ${column.dot}`} />
            <h3 className={`font-semibold text-sm truncate ${column.color}`}>{column.label}</h3>
          </div>
          <span className="bg-background/60 text-muted-foreground text-xs rounded-full px-2 py-0.5 font-medium tabular-nums flex-shrink-0">
            {proposals.length}
          </span>
        </div>
        {/* Coluna vazia não ganha "R$ 0,00": seria ruído em toda etapa parada. */}
        {totalColuna > 0 && (
          <p className="mt-1 text-[11px] font-medium tabular-nums text-muted-foreground">
            {brl(totalColuna)}
          </p>
        )}
      </div>
      <div
        ref={setNodeRef}
        className={`flex-1 space-y-2 min-h-[200px] rounded-b-xl p-2 transition-colors border border-border/40 ${
          isOver ? `${column.zone} ring-1 ring-primary/40 border-primary/30` : column.zone
        }`}
      >
        {proposals.map(p => (
          <ProposalCard key={p.id} proposal={p} />
        ))}
        {proposals.length === 0 && (
          <div className="flex items-center justify-center h-24 text-muted-foreground/30 text-xs">
            Arraste aqui
          </div>
        )}
      </div>
    </div>
  )
}

// Pipeline mobile: pills de status no topo + lista full-width da coluna ativa
function MobilePipeline({ grouped, onMove, isAdmin }: {
  grouped: Record<ProposalStatus, Proposal[]>
  onMove: (p: Proposal, s: ProposalStatus) => void
  isAdmin: boolean
}) {
  const router = useRouter()
  // Lista única — o filtro de status vem das tabs de texto acima (mockup)
  const cards = COLUMNS.flatMap(c => grouped[c.id] || [])

  return (
    <div className="md:hidden flex-1 flex flex-col min-h-0">
      {/* Lista */}
      <div className="flex-1 overflow-y-auto space-y-2.5 pt-1 pb-4">
        {cards.length === 0 ? (
          <div className="flex items-center justify-center h-32 text-muted-foreground/40 text-sm">Nenhuma proposta aqui</div>
        ) : cards.map(p => (
          <div key={p.id} onClick={() => router.push(`/propostas/${p.id}`)}
            className={`bg-surface-1 rounded-[20px] p-5 border border-hairline active:opacity-70 transition-opacity`}>
            <div className="flex items-center justify-between gap-2">
              <p className="text-[11px] font-mono uppercase tracking-wider text-muted-fg">{p.numero}</p>
              <span className={`text-[12px] font-medium ${COLUMNS.find(c => c.id === p.status)?.color ?? "text-muted-fg"}`}>
                {STATUS_LABELS_MAP[p.status]}
              </span>
            </div>
            <p className="text-[22px] font-bold text-foreground leading-tight tracking-tight mt-1.5 truncate">{p.client_name}</p>
            <div className="flex items-end justify-between gap-2 mt-3">
              <div className="min-w-0">
                <p className="text-[11px] uppercase tracking-wider text-muted-fg">Total</p>
                <p className="text-[24px] font-bold text-foreground tracking-tight leading-none mt-0.5">{brl(Number(p.valor_total))}</p>
              </div>
              {p.data_expiracao && (
                <span className="text-[12px] text-muted-fg flex items-center gap-1 flex-shrink-0 pb-0.5"><Calendar className="w-3 h-3" />{new Date(p.data_expiracao).toLocaleDateString("pt-BR")}</span>
              )}
            </div>
            {isAdmin && (() => {
              /* Sem arrastar no mobile, o avançar/voltar por botão é o único
                 jeito de mudar a fase — só tinha "avançar". Sem "voltar", uma
                 fase marcada errado ficava presa lá até alguém abrir no
                 desktop pra arrastar de volta. */
              const fluxo = COLUMNS.filter(c => c.id !== "CANCELADA")
              const idx = fluxo.findIndex(c => c.id === p.status)
              const proxima = idx >= 0 && idx < fluxo.length - 1 ? fluxo[idx + 1] : null
              const anterior = idx > 0 ? fluxo[idx - 1] : null
              if (!proxima && !anterior) return null
              return (
                <div className="mt-3 flex items-center gap-1.5 flex-wrap" onClick={e => e.stopPropagation()}>
                  {anterior && (
                    <button onClick={() => onMove(p, anterior.id)}
                      className="flex items-center gap-1.5 px-3 h-8 rounded-full text-[12px] font-medium bg-muted text-muted-fg active:bg-muted/70">
                      <ChevronLeft className="w-3.5 h-3.5" />
                      Voltar para <span className={`w-1.5 h-1.5 rounded-full ${anterior.dot}`} /> {anterior.label}
                    </button>
                  )}
                  {proxima && (
                    <button onClick={() => onMove(p, proxima.id)}
                      className="flex items-center gap-1.5 px-3 h-8 rounded-full text-[12px] font-medium bg-muted text-foreground active:bg-muted/70">
                      Avançar para <span className={`w-1.5 h-1.5 rounded-full ${proxima.dot}`} /> {proxima.label}
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              )
            })()}
          </div>
        ))}
      </div>
    </div>
  )
}

function PropostasKanbanInner() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [proposals, setProposals] = useState<Proposal[]>([])
  const [loading, setLoading] = useState(false)
  const [activeId, setActiveId] = useState<string | null>(null)
  const [role, setRole] = useState<string>("")
  /* Gaveta de reuniões. A reunião não é algo que se gerencia — é o meio pelo
     qual a proposta aparece —, então não ganha item de menu. O botão existe
     por causa da falha silenciosa: sem lugar para olhar, uma gravação que
     chegou e não virou item nenhum desaparece sem ninguém saber. */
  const [gavetaAberta, setGavetaAberta] = useState(false)
  const [reunioesPendentes, setReunioesPendentes] = useState(0)

  const contarReunioes = useCallback(async () => {
    try {
      const r = await fetch("/api/reunioes", { cache: "no-store" })
      if (!r.ok) return
      const j = await r.json()
      type R = { status: string }
      setReunioesPendentes((j.reunioes ?? [])
        .filter((x: R) => x.status === "RECEBIDA" || x.status === "SEM_ITENS").length)
    } catch { /* contador é acessório: falhar aqui não atrapalha o kanban */ }
  }, [])

  /* Busca gravação nova ao abrir a tela. Quem acaba de sair de uma reunião não
     deve esperar o próximo ciclo do cron — e o servidor tem trava de 2 minutos
     para a tela não disparar uma busca a cada carregamento. */
  useEffect(() => {
    fetch("/api/integracoes/plaud/sync", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: "{}",
    }).then(() => contarReunioes()).catch(() => contarReunioes())
  }, [contarReunioes])

  const [pending, setPending] = useState<{ proposal: Proposal; newStatus: ProposalStatus } | null>(null)
  const [motivoSel, setMotivoSel] = useState("")
  const [motivoLivre, setMotivoLivre] = useState("")

  // Filtros vindos do dashboard via query string
  const [filtroCliente, setFiltroCliente] = useMemoriaDeFiltro("propostas:cliente", searchParams.get("cliente") || "", { preferirInicial: !!searchParams.get("cliente") })
  const [filtroStatus, setFiltroStatus] = useMemoriaDeFiltro<string>("propostas:status", searchParams.get("status") || "", { preferirInicial: !!searchParams.get("status") })
  const [filtroData, setFiltroData] = useMemoriaDeFiltro("propostas:data", searchParams.get("data") || "", { preferirInicial: !!searchParams.get("data") })
  const [filtroMes, setFiltroMes] = useMemoriaDeFiltro("propostas:mes", searchParams.get("mes") || "", { preferirInicial: !!searchParams.get("mes") })
  // Intervalo de datas (complementa o mês) — "Criada em" entre duas datas
  const [filtroDataIni, setFiltroDataIni] = useMemoriaDeFiltro("propostas:dataIni", "")
  const [filtroDataFim, setFiltroDataFim] = useMemoriaDeFiltro("propostas:dataFim", "")

  const [erroMover, setErroMover] = useState("")

  /**
   * @param silencioso  não liga o loader. A atualização automática usa isso:
   *   sem ele o quadro pisca a tela de carregamento a cada ciclo e parece que
   *   travou.
   */
  const fetchProposals = useCallback(async (silencioso = false) => {
    if (!silencioso) setLoading(true)
    try {
      const res = await fetch("/api/propostas", { cache: "no-store" })
      const data = await res.json()
      setProposals(data.proposals || [])
    } finally {
      if (!silencioso) setLoading(false)
    }
  }, [])

  useEffect(() => { fetchProposals() }, [fetchProposals])

  /**
   * Atualização automática do quadro.
   *
   * O cliente aceita ou pede revisão pelo link, e outra pessoa move card no
   * kanban — nada disso chegava aqui sem F5. Recarrega a cada 800 ms e também
   * assim que a aba volta ao foco, que é quando o dado desatualizado salta aos
   * olhos.
   *
   * 800 ms e não 4 s porque a resposta é pequena — só a lista de propostas da
   * empresa — e a espera de quatro segundos era percebida como travamento por
   * quem move um card e olha o quadro esperando ele reagir.
   *
   * Enquanto um card está sendo arrastado a atualização espera: trocar a lista
   * no meio do arraste faria o card sumir da mão.
   */
  useEffect(() => {
    const atualizar = () => { if (!activeId && !document.hidden) fetchProposals(true) }
    const timer = setInterval(atualizar, 800)
    document.addEventListener("visibilitychange", atualizar)
    window.addEventListener("focus", atualizar)
    return () => {
      clearInterval(timer)
      document.removeEventListener("visibilitychange", atualizar)
      window.removeEventListener("focus", atualizar)
    }
  }, [fetchProposals, activeId])

  useEffect(() => {
    fetch("/api/auth/me").then(r => r.ok ? r.json() : null).then(d => {
      if (d?.user?.role) setRole(d.user.role)
    }).catch(() => {})
  }, [])

  const isAdmin = role === "ADMIN"

  /* 6 px antes de virar arraste: sem essa folga, o card inteiro sendo alvo de
     arraste faria todo clique começar um gesto e a proposta nunca abriria. */
  const sensores = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }))

  function handleDragStart(event: DragStartEvent) {
    setActiveId(String(event.active.id))
  }

  function handleDragEnd(event: DragEndEvent) {
    setActiveId(null)
    const { active, over } = event
    if (!over) return

    const proposalId = String(active.id)
    const newStatus = String(over.id) as ProposalStatus
    const validStatuses = COLUMNS.map(c => c.id)
    if (!validStatuses.includes(newStatus)) return

    const proposal = proposals.find(p => p.id === proposalId)
    if (!proposal || proposal.status === newStatus) return

    // Confirmação antes de mover de etapa
    setPending({ proposal, newStatus })
  }

  async function confirmMove() {
    if (!pending) return
    const { proposal, newStatus } = pending

    let motivo_perda: string | undefined
    if (newStatus === "PROPOSTA_PERDIDA") {
      motivo_perda = (motivoLivre.trim() || motivoSel).trim()
      if (!motivo_perda) return // modal exige motivo antes de confirmar
    }

    setPending(null); setMotivoSel(""); setMotivoLivre("")

    const statusAnterior = proposal.status
    // Optimistic update
    setProposals(prev => prev.map(p => p.id === proposal.id ? { ...p, status: newStatus } : p))

    try {
      const res = await fetch(`/api/propostas/${proposal.id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus, ...(motivo_perda ? { motivo_perda } : {}) }),
      })

      if (!res.ok) {
        // Sem isto o card ficava na coluna nova mesmo com o servidor recusando,
        // e só um F5 mostrava a verdade.
        const j = await res.json().catch(() => ({}))
        setProposals(prev => prev.map(p => p.id === proposal.id ? { ...p, status: statusAnterior } : p))
        setErroMover(j.error || "Não foi possível mover a proposta.")
        return
      }

      // Aceite gera obra e parcelas no servidor: recarrega para o card refletir isso.
      await fetchProposals()
    } catch {
      setProposals(prev => prev.map(p => p.id === proposal.id ? { ...p, status: statusAnterior } : p))
      setErroMover("Falha de conexão ao mover a proposta.")
    }
  }

  const temFiltro = !!(filtroCliente || filtroStatus || filtroData || filtroMes || filtroDataIni || filtroDataFim)
  const filtradas = proposals.filter(p => {
    if (filtroCliente && !p.client_name.toLowerCase().includes(filtroCliente.toLowerCase())) return false
    if (filtroStatus && p.status !== filtroStatus) return false
    if (filtroData && (!p.data_expiracao || p.data_expiracao.slice(0, 10) !== filtroData)) return false
    if (filtroMes) {
      const criado = p.createdAt?.slice(0, 7) ?? ""
      if (criado !== filtroMes) return false
    }
    if (filtroDataIni || filtroDataFim) {
      const criado = p.createdAt?.slice(0, 10) ?? ""
      if (filtroDataIni && criado < filtroDataIni) return false
      if (filtroDataFim && criado > filtroDataFim) return false
    }
    return true
  })

  const grouped = COLUMNS.reduce((acc, col) => {
    acc[col.id] = filtradas.filter(p => p.status === col.id)
    return acc
  }, {} as Record<ProposalStatus, Proposal[]>)


  return (
    <div className="p-4 md:p-6 h-full flex flex-col space-y-4">
      <div className="flex-shrink-0">
        <CabecalhoPagina
          icone={FileText}
          titulo="Propostas"
          contexto={`${filtradas.length} proposta${filtradas.length !== 1 ? "s" : ""}${
            temFiltro && proposals.length !== filtradas.length ? ` de ${proposals.length}` : ""
          }`}
          acao={
            <div className="flex flex-shrink-0 gap-2">
              <Button variant="outline" size="sm" className="h-9 gap-1.5 relative"
                onClick={() => setGavetaAberta(true)}>
                <Mic className="h-4 w-4" />
                <span className="hidden sm:inline">Reuniões</span>
                {reunioesPendentes > 0 && (
                  <span className="ml-0.5 rounded-full bg-ios-blue px-1.5 text-[11px] font-medium text-primary-foreground">
                    {reunioesPendentes}
                  </span>
                )}
              </Button>
              <Button onClick={() => router.push("/propostas/nova")} size="sm" className="h-9 gap-1.5">
                <Plus className="h-4 w-4" /> <span className="hidden sm:inline">Nova proposta</span>
              </Button>
            </div>
          }
        />
      </div>

      {/* Mobile: busca + tabs texto (mockup) */}
      <div className="md:hidden space-y-1 flex-shrink-0">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-fg" />
          <input value={filtroCliente} onChange={e => setFiltroCliente(e.target.value)}
            placeholder="Buscar cliente ou nº"
            className="w-full h-12 pl-11 pr-4 rounded-2xl bg-surface-2 border border-hairline text-[15px] text-foreground placeholder:text-muted-fg outline-none focus:border-ios-blue/40" />
        </div>
        <div className="flex gap-5 overflow-x-auto no-scrollbar border-b border-hairline -mx-4 px-4">
          {[{ v: "", l: "Todas" }, ...COLUMNS.filter(c => c.id !== "CANCELADA").map(c => ({ v: c.id as string, l: c.label }))].map(t => (
            <button key={t.v} onClick={() => setFiltroStatus(t.v)}
              className={`pb-2.5 pt-1 text-[14px] font-medium flex-shrink-0 border-b-2 transition-colors ${
                filtroStatus === t.v ? "text-foreground border-white" : "text-muted-fg border-transparent"
              }`}>
              {t.l}
            </button>
          ))}
        </div>
      </div>

      {/* Filtros (desktop, no mobile a busca+tabs acima cobrem) */}
      <div className="hidden md:flex gap-2 md:flex-wrap items-center flex-shrink-0 overflow-x-auto md:overflow-visible no-scrollbar">
        <input
          placeholder="Cliente..."
          value={filtroCliente}
          onChange={e => setFiltroCliente(e.target.value)}
          className="h-9 px-3 w-44 flex-shrink-0 rounded-xl bg-muted/50 border border-border text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
        />
        <select
          value={filtroStatus}
          onChange={e => setFiltroStatus(e.target.value)}
          className="h-9 px-3 flex-shrink-0 rounded-xl bg-muted/50 border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
        >
          <option value="">Todos os status</option>
          {COLUMNS.map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
        </select>
        <div className="flex-shrink-0"><MonthPicker value={filtroMes} onChange={setFiltroMes} placeholder="Todos os meses" /></div>
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <input type="date" max="9999-12-31" value={filtroDataIni} onChange={e => setFiltroDataIni(e.target.value)}
            title="Criada de" className="h-9 px-2.5 rounded-xl bg-muted/50 border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/30" />
          <span className="text-muted-foreground text-xs">até</span>
          <input type="date" max="9999-12-31" value={filtroDataFim} onChange={e => setFiltroDataFim(e.target.value)}
            title="Criada até" className="h-9 px-2.5 rounded-xl bg-muted/50 border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/30" />
        </div>
        {temFiltro && (
          <button
            onClick={() => { setFiltroCliente(""); setFiltroStatus(""); setFiltroData(""); setFiltroMes(""); setFiltroDataIni(""); setFiltroDataFim("") }}
            className="h-9 px-3 flex-shrink-0 rounded-xl bg-muted hover:bg-muted/80 text-muted-foreground text-sm flex items-center gap-1 transition-colors"
          >
            <X className="w-3.5 h-3.5" /> Limpar
          </button>
        )}
      </div>

      {erroMover && (
        <div className="mb-3 flex items-start gap-2 rounded-xl bg-ios-red/10 px-4 py-3 text-sm text-ios-red">
          <span className="flex-1">{erroMover}</span>
          <button type="button" onClick={() => setErroMover("")} className="shrink-0 opacity-70 hover:opacity-100">
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {loading ? (
        <div className="flex-1 flex items-center justify-center"><PageLoader /></div>
      ) : (
        <>
          {/* ── DESKTOP: kanban DnD ── */}
          <DndContext sensors={sensores} collisionDetection={pointerWithin} onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
            <div className="hidden md:flex gap-3 overflow-x-auto pb-4 flex-1">
              {COLUMNS.map(col => (
                <DroppableColumn key={col.id} column={col} proposals={grouped[col.id] || []} />
              ))}
            </div>
          </DndContext>

          {/* ── MOBILE: pills de status + 1 coluna full-width ── */}
          <MobilePipeline grouped={grouped} onMove={(p, s) => setPending({ proposal: p, newStatus: s })} isAdmin={isAdmin} />
        </>
      )}

      {/* Confirmação de mudança de etapa */}
      <Dialog open={!!pending} onOpenChange={o => { if (!o) { setPending(null); setMotivoSel(""); setMotivoLivre("") } }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {!isAdmin ? "Ação não permitida"
                : pending?.newStatus === "PROPOSTA_PERDIDA" ? "Marcar como perdida"
                : "Mover proposta de etapa?"}
            </DialogTitle>
            <DialogDescription>
              {isAdmin && pending ? (
                pending.newStatus === "PROPOSTA_PERDIDA" ? (
                  <>Informe o motivo da perda de <span className="text-foreground font-medium">{pending.proposal.client_name}</span>.</>
                ) : (
                  <>
                    Mover <span className="text-foreground font-medium">{pending.proposal.client_name}</span> para{" "}
                    <span className="text-foreground font-medium">{STATUS_LABELS_MAP[pending.newStatus]}</span>?
                  </>
                )
              ) : (
                "Apenas administradores podem alterar a etapa de uma proposta no pipeline."
              )}
            </DialogDescription>
          </DialogHeader>

          {isAdmin && pending?.newStatus === "PROPOSTA_PERDIDA" && (
            <div className="space-y-4 px-5 sm:px-6 py-4">
              <div className="space-y-1.5">
                <label className="text-sm text-foreground/80">Motivo</label>
                <select value={motivoSel} onChange={e => setMotivoSel(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl bg-muted border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary">
                  <option value="">Selecione…</option>
                  {MOTIVOS_PERDA.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
              <div className="space-y-1.5">
                <label className="text-sm text-foreground/80">Detalhe (opcional)</label>
                <textarea value={motivoLivre} onChange={e => setMotivoLivre(e.target.value)} rows={3}
                  className="w-full rounded-xl bg-muted border border-border text-foreground text-sm p-3 focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Complemento livre, se preenchido, sobrepõe o motivo acima." />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="ghost" onClick={() => { setPending(null); setMotivoSel(""); setMotivoLivre("") }}>
              Cancelar
            </Button>
            {isAdmin && (
              <Button onClick={confirmMove}
                disabled={pending?.newStatus === "PROPOSTA_PERDIDA" && !(motivoLivre.trim() || motivoSel)}>
                Confirmar
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
          <GavetaReunioes
        aberta={gavetaAberta}
        aoFechar={() => setGavetaAberta(false)}
        aoMudar={() => { contarReunioes(); fetchProposals(true) }}
      />
</div>
  )
}

export default function PropostasKanbanPage() {
  return (
    <Suspense fallback={<PageLoader />}>
      <PropostasKanbanInner />
    </Suspense>
  )
}

