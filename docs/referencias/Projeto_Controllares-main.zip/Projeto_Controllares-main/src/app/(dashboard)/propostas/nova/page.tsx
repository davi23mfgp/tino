﻿"use client"

import { useState, useEffect, useCallback, useRef, Suspense } from "react"
import { embutidoNaCategoria, precoComServico } from "@/lib/servicos-categoria"
import { numeroBR } from "@/lib/numero-br"
import { CampoValor } from "@/components/campo-valor"
import { useRouter, useSearchParams } from "next/navigation"
import { Check, ChevronRight, Plus, Trash2, Search, X, Eye, EyeOff, ChevronDown, Users, Tag, Package, Zap, Building2, FileText as FileIcon, CreditCard, PenLine, Settings2, Lock, MoreVertical, Bookmark } from "lucide-react"
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog"
import { useEditor, EditorContent } from "@tiptap/react"
import StarterKit from "@tiptap/starter-kit"
import Image from "@tiptap/extension-image"
import Placeholder from "@tiptap/extension-placeholder"
import { proxiedImg } from "@/lib/img"
import { useConfirmar } from "@/components/confirmar"
import { brl, pct } from "@/lib/formato"


const PROJECT_TYPES = ["CONDOMINIO", "RESIDENCIAL", "APARTAMENTO", "CORPORATIVO", "RURAL"] as const
type ProjectType = typeof PROJECT_TYPES[number]

interface Product {
  id: string; sku: string; nome: string; preco_custo: number; preco_venda: number; markup_padrao: number; categoryId?: string | null; imagem_url?: string | null
  custo_componentes?: number; venda_componentes?: number; tem_componentes?: boolean
}
interface ServicoPreDef { nome: string; tipo: "percentual" | "fixo"; valor: string }
interface Category {
  id: string; nome: string; imagem_url?: string | null; servicos?: ServicoPreDef[] | null
}
interface KitItem {
  quantidade: number
  product: { id: string; nome: string; sku: string; preco_custo: number; preco_venda: number; markup_padrao: number }
}
interface Kit {
  id: string; nome: string; markup_global: number | null; items: KitItem[]
}
interface ProposalItem {
  id: string
  type: "product" | "kit"
  sourceId: string
  nome: string
  imagem_url?: string | null
  quantidade: number
  valor_unitario: number
  /** Preço antes da campanha — a diferença vira a linha "desconto de campanha". */
  valor_cheio?: number
  /**
   * Menor preço que este item pode ter nas mãos de quem não é Admin.
   *
   * É o valor que o item tinha ao entrar na proposta: preço de catálogo com
   * campanha, se acabou de ser adicionado, ou o valor salvo, se a proposta veio
   * do banco. Quem não é Admin sobe daqui para cima e não desce.
   *
   * Serve só para a tela avisar antes do erro — o servidor refaz a conta e
   * recusa por conta própria, porque este número vive no navegador do usuário.
   */
  valor_piso?: number
  preco_custo: number
  markup_especifico: number
  useMarkup: boolean
  desconto_unitario: number
  categoryId: string
  /* Item escrito na hora, que ainda não existe no catálogo. Segue na proposta
     como qualquer outro; o que muda é que a conclusão fica travada até alguém
     cadastrar o produto e ligar os dois. */
  avulso?: boolean
  avulso_marca?: string
  avulso_unidade?: string
  avulso_categoria?: string
  is_aditivo: boolean
}
interface Environment {
  id: string
  nome: string
  items: ProposalItem[]
  /** ATIVO vai ao cliente e soma; GUARDADO fica na ficha; RECUSADO ele ja disse nao. */
  status?: "ATIVO" | "GUARDADO" | "RECUSADO"
}
interface AnexoPagina { nome: string; url: string; ext: string }
interface ExtraPage {
  id: string
  titulo: string
  conteudo_markdown: string
  anexos?: AnexoPagina[]
}
interface Installment {
  numero_parcela: number
  valor: number
  data_vencimento: string
  /** Entrada é linha à parte, não a primeira do parcelamento. */
  entrada?: boolean
  forma?: string | null
}

interface ServicoItem {
  id: string
  nome: string
  tipo: "percentual" | "fixo"
  valor: string
  /* Sobre O QUÊ o percentual incide.

     Os dois nasciam vazios e todo serviço caía sobre o total da proposta: uma
     instalação de 15% cadastrada em Som Ambiente cobrava 15% da automação
     junto. O número saía maior que o combinado e ninguém percebia, porque o
     rodapé mostrava um valor só.

     `categoryId` — serviço da categoria: incide sobre os produtos daquela
     categoria na proposta inteira, que é como ele foi cadastrado.
     `environmentId` — serviço do ambiente: incide sobre os produtos daquele
     ambiente. É o caso do "projeto e instalação" de um sistema específico.
     Os dois vazios — serviço da proposta, sobre o total. */
  categoryId?: string | null
  environmentId?: string | null
}

/** Desconto concedido automaticamente no pagamento à vista. */
const DESCONTO_AVISTA = 5

type FormaPagamento = "CARTAO" | "AVISTA" | "OBRA" | "PERSONALIZADO"

const FORMAS_PAGAMENTO: { id: FormaPagamento; label: string; desc: string; Icon: typeof CreditCard }[] = [
  { id: "CARTAO", label: "Cartão de crédito", desc: "Até 6x",              Icon: CreditCard },
  { id: "AVISTA", label: "À vista",           desc: `${DESCONTO_AVISTA}% de desconto`, Icon: Zap },
  { id: "OBRA",   label: "Parcelado na obra", desc: "Parcelas livres",     Icon: Building2 },
]

/** O nome da forma como o cliente a viu, para o aviso de trava. */
const rotuloForma = (id: string | null) =>
  FORMAS_PAGAMENTO.find(f => f.id === id)?.label ?? "a forma que ele marcou"

/** Texto que o cliente lê na proposta, montado a partir da escolha. */
function textoCondicao(forma: FormaPagamento | "", parcelas: number): string {
  if (forma === "CARTAO") return `${parcelas || 6}x no cartão`
  if (forma === "AVISTA") return `À vista com ${DESCONTO_AVISTA}% de desconto`
  // Sem "(a combinar)": o número de parcelas já está definido logo ali.
  if (forma === "OBRA") return `Parcelamento da obra em ${parcelas || 1}x`
  if (forma === "PERSONALIZADO") return "Condição personalizada"
  return ""
}

const PAYMENT_OPTIONS = ["PIX", "Boleto", "Transferência Bancária", "Cartão de Crédito", "Cheque"] as const

// Máximo de parcelas que cada forma de pagamento permite.
// Ex.: transferência/PIX são à vista; cartão pode até 12x.
const MAX_PARCELAS: Record<string, number> = {
  "PIX": 1,
  "Transferência": 1,
  "Cheque": 6,
  "Boleto": 12,
  "Cartão de Crédito": 12,
}
const METODOS_PAGAMENTO = [
  { label: "PIX",              Icon: Zap,        desc: "À vista" },
  { label: "Transferência",    Icon: Building2,  desc: "À vista" },
  { label: "Boleto",           Icon: FileIcon,   desc: "Até 12x" },
  { label: "Cartão de Crédito",Icon: CreditCard, desc: "Até 12x" },
  { label: "Cheque",           Icon: PenLine,    desc: "Até 6x" },
  { label: "Outros",           Icon: Plus,       desc: "Personalizado" },
] as const

const CORES_PROPOSTA = [
  { label: "Azul Profissional", value: "#007AFF" },
  { label: "Verde Esmeralda",   value: "#34C759" },
  { label: "Cobre Moderno",     value: "#C47435" },
  { label: "Roxo Premium",      value: "#AF52DE" },
  { label: "Cinza Elegante",    value: "#636366" },
] as const

interface WizardState {
  client_name: string
  client_email: string
  client_city: string
  project_type: ProjectType
  data_expiracao: string
  environments: Environment[]
  instalacao_ativo: boolean
  instalacao_tipo: "percentual" | "fixo"
  instalacao_valor: string
  admin_ativo: boolean
  admin_tipo: "percentual" | "fixo"
  admin_valor: string
  servicos: ServicoItem[]
  /* Projeto e instalação é um bloco como os sistemas, e como eles pode ser
     guardado: fica montado aqui, mas não soma no total nem vai para o cliente. */
  servicos_guardados: boolean
  installments: Installment[]
  payment_methods: string[]
  /** Formas que a empresa aceita nesta proposta. O cliente escolhe uma. */
  formas_oferecidas: FormaPagamento[]
  personalizado_recado: string
  payment_outros: string
  dias_garantia: string
  exibir_valor_unitario: boolean
  desconto_aplicado: string
  valor_entrada: string
  observacoes: string
  extraPages: ExtraPage[]
  cor_destaque: string
  confidencial: boolean
}

const initialState: WizardState = {
  client_name: "", client_email: "", client_city: "",
  project_type: "RESIDENCIAL", data_expiracao: "",
  environments: [], instalacao_ativo: false, instalacao_tipo: "percentual", instalacao_valor: "",
  admin_ativo: false, admin_tipo: "percentual", admin_valor: "",
  servicos: [], servicos_guardados: false,
  installments: [], payment_methods: [], formas_oferecidas: ["CARTAO", "AVISTA", "OBRA"], personalizado_recado: "", payment_outros: "", dias_garantia: "", desconto_aplicado: "", valor_entrada: "", exibir_valor_unitario: false, observacoes: "", extraPages: [],
  cor_destaque: "#007AFF",
  confidencial: false,
}

const STEPS = ["Identificação", "Escopo", "Pagamento", "Revisão"]

async function uploadArquivo(file: File): Promise<string | null> {
  const fd = new FormData(); fd.append("file", file)
  const res = await fetch("/api/upload", { method: "POST", body: fd })
  if (!res.ok) return null
  const { url } = await res.json()
  return url as string
}

function TiptapEditor({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [uploadingImg, setUploadingImg] = useState(false)
  const [arrastando, setArrastando] = useState(false)

  const editor = useEditor({
    // SSR do Next: renderizar na primeira passada quebra a hidratação do editor.
    immediatelyRender: false,
    extensions: [
      StarterKit,
      Image.configure({ inline: false, allowBase64: false, HTMLAttributes: { class: "rounded-lg border border-border max-w-full" } }),
      Placeholder.configure({ placeholder: "Escreva aqui. Arraste ou cole imagens direto no texto." }),
    ],
    content: value,
    onUpdate: ({ editor }) => onChange(editor.getHTML()),
    editorProps: {
      handlePaste: (_view, event) => {
        const arquivo = Array.from(event.clipboardData?.files ?? []).find(f => f.type.startsWith("image/"))
        if (!arquivo) return false
        event.preventDefault()
        inserirImagem(arquivo)
        return true
      },
      handleDrop: (_view, event) => {
        const arquivo = Array.from((event as DragEvent).dataTransfer?.files ?? []).find(f => f.type.startsWith("image/"))
        if (!arquivo) return false
        event.preventDefault()
        inserirImagem(arquivo)
        return true
      },
    },
  })

  // Conteúdo chega depois (edição de proposta existente / inserir modelo):
  // sem isso o editor nasce vazio e o texto salvo some da tela.
  useEffect(() => {
    if (!editor) return
    if (value !== editor.getHTML()) editor.commands.setContent(value || "", { emitUpdate: false })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, editor])

  async function inserirImagem(file: File) {
    setUploadingImg(true)
    try {
      const url = await uploadArquivo(file)
      if (url) editor?.chain().focus().setImage({ src: url }).run()
    } finally { setUploadingImg(false) }
  }

  const ferramentas = [
    { label: "Título", action: () => editor?.chain().focus().toggleHeading({ level: 2 }).run(), active: editor?.isActive("heading", { level: 2 }) },
    { label: "Subtítulo", action: () => editor?.chain().focus().toggleHeading({ level: 3 }).run(), active: editor?.isActive("heading", { level: 3 }) },
    { label: "Negrito", action: () => editor?.chain().focus().toggleBold().run(), active: editor?.isActive("bold") },
    { label: "Itálico", action: () => editor?.chain().focus().toggleItalic().run(), active: editor?.isActive("italic") },
    { label: "Lista", action: () => editor?.chain().focus().toggleBulletList().run(), active: editor?.isActive("bulletList") },
    { label: "Numerada", action: () => editor?.chain().focus().toggleOrderedList().run(), active: editor?.isActive("orderedList") },
    { label: "Citação", action: () => editor?.chain().focus().toggleBlockquote().run(), active: editor?.isActive("blockquote") },
  ]

  return (
    <div className={`overflow-hidden rounded-xl transition-colors ${arrastando ? "bg-primary/10 ring-1 ring-primary" : "bg-background"}`}
      onDragOver={e => { e.preventDefault(); setArrastando(true) }}
      onDragLeave={() => setArrastando(false)}
      onDrop={() => setArrastando(false)}>
      <div className="flex flex-wrap items-center gap-1 border-b border-hairline px-2 py-1.5">
        {ferramentas.map(btn => (
          <button key={btn.label} type="button" onClick={btn.action}
            className={`h-7 rounded-lg px-2.5 text-xs font-medium transition-colors ${
              btn.active ? "bg-foreground/10 text-foreground" : "text-muted-fg hover:bg-muted hover:text-foreground"
            }`}>
            {btn.label}
          </button>
        ))}
        <span className="mx-1 h-4 w-px bg-hairline" />
        <label className={`flex h-7 cursor-pointer items-center gap-1.5 rounded-lg px-2.5 text-xs font-medium text-muted-fg transition-colors hover:bg-muted hover:text-foreground ${
          uploadingImg ? "pointer-events-none opacity-50" : ""
        }`}>
          <Plus className="h-3.5 w-3.5" />
          {uploadingImg ? "Enviando" : "Imagem"}
          <input type="file" accept="image/*" className="hidden"
            onChange={e => { const f = e.target.files?.[0]; if (f) inserirImagem(f); e.target.value = "" }} />
        </label>
      </div>
      <EditorContent
        editor={editor}
        className="doc-editor px-4 py-3 text-sm leading-relaxed text-foreground [&_.ProseMirror]:min-h-[180px] [&_.ProseMirror]:outline-none"
      />
    </div>
  )
}

function NovaPropostaInner() {
  const confirmar = useConfirmar()
  const router = useRouter()
  const searchParams = useSearchParams()
  const templateId = searchParams.get("templateId")

  const editId = searchParams.get("editar")

  const [step, setStep] = useState(0)
  /* A forma fechada pelo cliente no link, quando ja houve escolha. */
  const [formaDoCliente, setFormaDoCliente] = useState<string | null>(null)
  /* Ele pode ter pedido para trocar de forma na revisao. O texto do pedido nao
     da para interpretar sozinho, entao quem leu o pedido destrava a mao. */
  const [destravarFormas, setDestravarFormas] = useState(false)
  const travaFormas = !!formaDoCliente && !destravarFormas

  const [data, setData] = useState<WizardState>(() => {
    // Vindo do CRM de Leads: pré-preenche o nome do cliente
    const cliente = searchParams.get("cliente")
    return cliente ? { ...initialState, client_name: cliente } : initialState
  })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")
  const [showCusto, setShowCusto] = useState(false)
  const [modoCliente, setModoCliente] = useState(false)
  const [envModalOpen, setEnvModalOpen] = useState(false)
  /* Serviço nasce nomeado, igual a um sistema: "Projeto", "Instalação",
     "Comissionamento". Nascer sem nome obriga a lembrar de batizar depois, e
     serviço sem nome chega ao cliente como linha em branco. */
  const [servModalOpen, setServModalOpen] = useState(false)
  const [servNome, setServNome] = useState("")
  /* Atalhos de ambiente: os oito que ESTA empresa mais usa, não uma lista
     fixa. Quem monta home cinema nomeia "Home Theater" e "Sala de Estar";
     quem faz corporativo nomeia "Recepção" e "Sala de Reunião" — e ficava
     digitando tudo à mão porque os atalhos eram de outra casa. */
  const [ambientesFrequentes, setAmbientesFrequentes] = useState<string[]>([])
  const [envNome, setEnvNome] = useState("")

  // Catalog data
  const [products, setProducts] = useState<Product[]>([])
  const [kits, setKits] = useState<Kit[]>([])
  const [categories, setCategories] = useState<Category[]>([])

  // Sheet (add item)
  const [sheetOpen, setSheetOpen] = useState(false)
  const [activeEnvId, setActiveEnvId] = useState<string | null>(null)
  const [itemSearch, setItemSearch] = useState("")
  const itemSearchRef = useRef<HTMLInputElement>(null)

  // Teto de desconto + fila de aprovação (Bloco 7)
  const [tetoDesconto, setTetoDesconto] = useState(0)
  const [meuRole, setMeuRole] = useState("")
  const [pedidoDesconto, setPedidoDesconto] = useState<{ status: string; decididoPorNome?: string | null } | null>(null)
  const [justificativaDesconto, setJustificativaDesconto] = useState("")
  const [pedindoDesconto, setPedindoDesconto] = useState(false)
  const [itemCatFilter, setItemCatFilter] = useState<string>("")

  /* Formulário do item que não está no catálogo.

     O vendedor está na casa do cliente e aparece algo que ninguém cadastrou.
     As opções eram parar tudo para cadastrar, ou combinar por fora e esquecer.
     Aqui ele escreve o que viu e segue — a dívida fica registrada e cobrada na
     conclusão, não no meio da venda. */
  const [avulsoAberto, setAvulsoAberto] = useState(false)
  const [avulso, setAvulso] = useState({
    nome: "", marca: "", unidade: "UN", categoria: "", valor: "", quantidade: "1",
  })
  const [selectedItem, setSelectedItem] = useState<{ type: "product" | "kit"; source: Product | Kit } | null>(null)
  const [itemQty, setItemQty] = useState(1)
  const [itemMarkup, setItemMarkup] = useState("")
  const [itemDesconto, setItemDesconto] = useState("")
  const [itemUseMarkup, setItemUseMarkup] = useState(true)
  // Campanhas de desconto vigentes (auto-aplicadas ao adicionar itens)
  const [campanhas, setCampanhas] = useState<{ id: string; nome: string; tipo: string; valor: number; produtoIds: string[]; categoriaIds: string[]; kitIds: string[] }[]>([])

  // Desconto de campanha vigente. NÃO acumula: aplica só a melhor campanha
  // que casa por categoria/produto/kit do item (campanha sempre tem escopo).
  function aplicarCampanha(preco: number, sourceId: string, categoryId: string | null | undefined, isKit: boolean): number {
    let melhor = preco
    for (const c of campanhas) {
      const casa =
        (isKit ? c.kitIds.includes(sourceId) : c.produtoIds.includes(sourceId))
        || (!!categoryId && c.categoriaIds.includes(categoryId))
      if (!casa) continue
      const comDesc = c.tipo === "VALOR" ? Math.max(0, preco - c.valor) : preco * (1 - (c.valor || 0) / 100)
      if (comDesc < melhor) melhor = comDesc
    }
    return melhor
  }

  /**
   * Serviço cadastrado na categoria, já dentro do preço do produto.
   *
   * Control4 com 30% cadastrado: todo produto Control4 da proposta entra com
   * 30% em cima. Com R$ 1.000 cadastrado, cada um entra com R$ 1.000 somado.
   * Produto de outra categoria não é tocado.
   *
   * Fazer isso no nascimento do item é o que permite todo o resto ignorar o
   * assunto: a linha do produto, o total, o documento do cliente, o contrato e
   * o pedido do Olist leem o valor do item e ele já vem somado. Calculado na
   * hora de exibir, seriam seis lugares refazendo a mesma conta — e um deles
   * ficaria diferente sem ninguém ver.
   */
  function comServicoDaCategoria(preco: number, categoryId: string | null | undefined): number {
    if (!categoryId) return preco
    const cat = categories.find(c => c.id === categoryId)
    if (!cat?.servicos?.length) return preco

    /* A mesma conta que as opções avançadas desfazem para reprecificar: as
       duas moram em `servicos-categoria` porque uma inversa que não bate com a
       ida devolve um preço que ninguém reconhece. */
    return precoComServico(preco, cat.servicos as ServicoPreDef[])
  }

  // Config da empresa: teto de desconto + texto padrão pré-preenchido
  useEffect(() => {
    Promise.all([
      fetch("/api/empresa").then(r => r.ok ? r.json() : null),
      fetch("/api/auth/me").then(r => r.ok ? r.json() : null),
    ]).then(([emp, me]) => {
      if (emp) {
        setTetoDesconto(Number(emp.desconto_maximo) || 0)
        /* O texto padrão da proposta saiu das Configurações, e o
           pré-preenchimento saiu junto. Deixar a escrita automática sem o campo
           que a controla seria pior que as duas coisas: a observação apareceria
           sozinha em toda proposta nova e ninguém saberia de onde, nem teria
           onde desligar. Quem quiser uma cláusula fixa escreve na proposta. */
      }
      if (me?.user?.role) setMeuRole(me.user.role)
    }).catch(() => {})
    fetch("/api/campanhas/ativas").then(r => r.ok ? r.json() : null)
      .then(d => { if (d?.campanhas) setCampanhas(d.campanhas) }).catch(() => {})
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const fetchCatalog = useCallback(async () => {
    const [pRes, kRes, cRes] = await Promise.all([
      fetch("/api/produtos?limit=5000"), // era 200 — cortava produtos, categorias "sumiam"
      fetch("/api/kits"),
      fetch("/api/categorias"),
    ])
    const pData = await pRes.json()
    const kData = await kRes.json()
    const cData = await cRes.json()
    // Só ATIVO e não-inativo-p/-proposta entram na busca de itens da proposta
    setProducts((pData.products || []).filter((p: Product & { status: string; inativo_proposta?: boolean }) => p.status === "ATIVO" && !p.inativo_proposta))
    setKits(kData.kits || [])
    setCategories(cData.categories || [])
  }, [])

  useEffect(() => { fetchCatalog() }, [fetchCatalog])

  useEffect(() => {
    fetch("/api/ambientes/frequentes", { cache: "no-store" })
      .then(r => r.ok ? r.json() : null)
      .then(d => { if (Array.isArray(d?.ambientes)) setAmbientesFrequentes(d.ambientes) })
      // Falhou: o campo continua digitável, só sem atalho.
      .catch(() => {})
  }, [])

  // ---- Carregar proposta existente para edição (editId) ----
  const editLoaded = useRef(false)
  useEffect(() => {
    if (!editId || editLoaded.current) return
    if (products.length === 0 && kits.length === 0) return
    editLoaded.current = true
    ;(async () => {
      try {
        const res = await fetch(`/api/propostas/${editId}`)
        if (!res.ok) return
        const p = await res.json()
        const envs: Environment[] = (p.environments || []).map((env: {
          nome: string
          status?: string
          proposalItems?: Array<{
            productId?: string | null; kitId?: string | null; quantidade: number
            nome_snapshot?: string | null
            valor_unitario: number | string; markup_especifico?: number | null
            desconto_unitario?: number | string | null; categoryId?: string | null
            is_aditivo?: boolean
          }>
        }) => ({
          id: crypto.randomUUID(),
          nome: env.nome,
          /* Reabrir a proposta tem que reencontrar o que foi guardado: sem
             isto, tudo voltava como ATIVO e o sistema recusado reaparecia
             cobrando no total. */
          status: (["ATIVO", "GUARDADO", "RECUSADO"].includes(env.status ?? "")
            ? env.status : "ATIVO") as Environment["status"],
          items: (env.proposalItems || []).map(item => {
            const isKit = !!item.kitId
            const sourceId = (item.kitId || item.productId || "") as string
            const prod = !isKit ? products.find(pp => pp.id === sourceId) : undefined
            const kit = isKit ? kits.find(k => k.id === sourceId) : undefined
            return {
              id: crypto.randomUUID(),
              type: (isKit ? "kit" : "product") as "product" | "kit",
              sourceId,
              /* nome_snapshot antes do fallback: item escrito na visita não tem
                 produto no catálogo, e sem isto reabrir a proposta trocava o
                 nome combinado com o cliente por "Item". */
              nome: prod?.nome || kit?.nome || item.nome_snapshot || "Item",
              imagem_url: prod?.imagem_url ?? null,
              quantidade: item.quantidade || 1,
              valor_unitario: Number(item.valor_unitario || 0),
              // Veio do banco: o piso é o valor que já estava lá.
              valor_piso: Number(item.valor_unitario || 0),
              preco_custo: prod ? Number(prod.preco_custo) : 0,
              markup_especifico: Number(item.markup_especifico || 0),
              useMarkup: !!item.markup_especifico,
              desconto_unitario: Number(item.desconto_unitario || 0),
              categoryId: item.categoryId || "",
              is_aditivo: !!item.is_aditivo,
            }
          }),
        }))
        /* A forma que o CLIENTE ja fechou no link. Ela trava as outras: mexer
           aqui depois da escolha reabre uma decisao que ja foi tomada, e o
           cliente so descobriria ao reabrir a proposta. */
        setFormaDoCliente(
          p.pagamento_definido_por === "CLIENTE" && p.forma_pagamento
            ? String(p.forma_pagamento).toUpperCase()
            : null,
        )
        setData({
          ...initialState,
          client_name: p.client_name || "",
          client_email: p.client_email || "",
          client_city: p.client_city || "",
          project_type: p.project_type || "RESIDENCIAL",
          data_expiracao: p.data_expiracao ? p.data_expiracao.slice(0, 10) : "",
          environments: envs,
          dias_garantia: p.dias_garantia != null ? String(p.dias_garantia)
            : p.anos_garantia != null ? String(p.anos_garantia * 365) : "",
          exibir_valor_unitario: p.exibir_valor_unitario === true,
          formas_oferecidas: (() => {
            try {
              const l = JSON.parse(p.formas_oferecidas || "[]")
              return Array.isArray(l) && l.length ? l : ["CARTAO", "AVISTA", "OBRA"]
            } catch { return ["CARTAO", "AVISTA", "OBRA"] }
          })(),
          personalizado_recado: p.personalizado_recado || "",
          servicos: Array.isArray(p.servicos_detalhe) ? p.servicos_detalhe : [],
          desconto_aplicado: p.desconto_aplicado != null ? String(p.desconto_aplicado) : "",
          valor_entrada: p.valor_entrada != null ? String(p.valor_entrada) : "",
          installments: (p.installments || []).map((inst: { numero_parcela: number; valor: number; data_vencimento: string }) => ({
            numero_parcela: inst.numero_parcela,
            valor: Number(inst.valor),
            data_vencimento: inst.data_vencimento.slice(0, 10),
          })),
          extraPages: p.extraPages || [],
        })
        /* Fica no passo 1 (Identificação), não pula pra Escopo. Pulava direto
           e a pessoa via a tela de identificação vazia por um instante antes
           do redirect — e ainda perdia a chance de conferir/corrigir nome,
           e-mail e cidade do cliente antes de seguir pro escopo. */
      } catch { /* silencia */ }
    })()
  }, [editId, products, kits])

  // Aplicar template (clonagem/renderização) — só após o catálogo carregar,
  // para resolver nomes e custos dos itens.
  const [templateName, setTemplateName] = useState<string | null>(null)
  const [mostrarAjuste, setMostrarAjuste] = useState(false)
  const templateApplied = useRef(false)
  useEffect(() => {
    if (!templateId || templateApplied.current) return
    if (products.length === 0 && kits.length === 0) return // aguarda catálogo
    templateApplied.current = true

    ;(async () => {
      try {
        const res = await fetch(`/api/templates/${templateId}`)
        if (!res.ok) return
        const tpl = await res.json()
        setTemplateName(tpl.nome || null)
        const est = tpl.estrutura || {}

        const envs: Environment[] = (est.environments || []).map((env: {
          nome: string
          proposalItems?: Array<{
            productId?: string | null; kitId?: string | null; quantidade?: number
            nome_snapshot?: string | null
            valor_unitario?: number | string; markup_especifico?: number | null
            desconto_unitario?: number | string | null; categoryId?: string | null
            is_aditivo?: boolean
          }>
        }) => ({
          id: crypto.randomUUID(),
          nome: env.nome,
          items: (env.proposalItems || []).map(pi => {
            const isKit = !!pi.kitId
            const sourceId = (pi.kitId || pi.productId || "") as string
            const prod = !isKit ? products.find(p => p.id === sourceId) : undefined
            const kit = isKit ? kits.find(k => k.id === sourceId) : undefined
            const nome = prod?.nome || kit?.nome || pi.nome_snapshot || "Item"
            const preco_custo = prod
              ? Number(prod.preco_custo)
              : kit
                ? kit.items.reduce((s, i) => s + Number(i.product.preco_custo) * i.quantidade, 0)
                : 0
            return {
              id: crypto.randomUUID(),
              type: (isKit ? "kit" : "product") as "product" | "kit",
              sourceId,
              nome,
              quantidade: pi.quantidade || 1,
              valor_unitario: Number(pi.valor_unitario || 0),
              // Veio do banco: o piso é o valor que já estava lá.
              valor_piso: Number(pi.valor_unitario || 0),
              preco_custo,
              markup_especifico: pi.markup_especifico || 0,
              useMarkup: true,
              desconto_unitario: Number(pi.desconto_unitario || 0),
              categoryId: pi.categoryId || "",
              is_aditivo: !!pi.is_aditivo,
            } as ProposalItem
          }),
        }))

        const extras: ExtraPage[] = (est.extraPages || []).map((p: { titulo: string; conteudo_markdown: string; anexos?: AnexoPagina[] }) => ({
          id: crypto.randomUUID(),
          titulo: p.titulo,
          conteudo_markdown: p.conteudo_markdown || "",
          anexos: Array.isArray(p.anexos) ? p.anexos : [],
        }))

        setData(d => ({
          ...d,
          project_type: est.project_type || d.project_type,
          environments: envs,
          extraPages: extras,
        }))
      } catch {
        // silencioso — template é opcional
      }
    })()
  }, [templateId, products, kits])

  /* Resgatar um sistema do histórico do lead (guardado, recusado ou já
     aceito numa proposta anterior — ver ficha-lead.tsx). Ao contrário do
     template, aqui o preço NUNCA é o congelado: recalcula pelo catálogo de
     hoje (mesma fórmula do preco_venda usado ao adicionar item na mão) e
     mostra a diferença, porque ressuscitar valor velho calado é vender no
     prejuízo sem perceber. */
  const resgatarSistemaId = searchParams.get("resgatarSistema")
  const leadDaUrlResgate = searchParams.get("lead")
  const resgateAplicado = useRef(false)
  const [resgateInfo, setResgateInfo] = useState<{ nome: string; antes: number; agora: number } | null>(null)
  useEffect(() => {
    if (!resgatarSistemaId || !leadDaUrlResgate || resgateAplicado.current) return
    if (products.length === 0 && kits.length === 0) return // aguarda catálogo
    resgateAplicado.current = true

    ;(async () => {
      try {
        const res = await fetch(`/api/leads/${leadDaUrlResgate}/sistemas-guardados/${resgatarSistemaId}`)
        if (!res.ok) return
        const j = await res.json()
        const itensSrc: {
          productId: string | null; kitId: string | null; quantidade: number
          nome_snapshot: string | null; categoryId: string | null; is_aditivo: boolean
          valorNaEpoca: number
        }[] = j.itens ?? []

        let antes = 0, agora = 0
        const items: ProposalItem[] = itensSrc.map(it => {
          antes += it.valorNaEpoca
          const isKit = !!it.kitId
          const prod = !isKit ? products.find(p => p.id === it.productId) : undefined
          const kit = isKit ? kits.find(k => k.id === it.kitId) : undefined
          const nome = prod?.nome || kit?.nome || it.nome_snapshot || "Item"
          const preco_custo = prod
            ? Number(prod.preco_custo)
            : kit
              ? kit.items.reduce((s, i) => s + Number(i.product.preco_custo) * i.quantidade, 0)
              : 0
          // Preço de HOJE: preco_venda do catálogo, com o mesmo fallback
          // (custo × markup padrão) que o resto da tela usa pra produto sem
          // preço de venda cadastrado.
          const valor_unitario = prod
            ? (Number(prod.preco_venda) || Number(prod.preco_custo) * (1 + (prod.markup_padrao || 0) / 100))
            : kit
              ? kit.items.reduce((s, i) => s + Number(i.product.preco_venda) * i.quantidade, 0)
              : it.valorNaEpoca / (it.quantidade || 1) // sem cadastro (item avulso da época): mantém o que tinha
          agora += valor_unitario * it.quantidade
          return {
            id: crypto.randomUUID(),
            type: (isKit ? "kit" : "product") as "product" | "kit",
            sourceId: (it.kitId || it.productId || "") as string,
            nome,
            quantidade: it.quantidade,
            valor_unitario,
            valor_piso: valor_unitario,
            preco_custo,
            markup_especifico: 0,
            useMarkup: false,
            desconto_unitario: 0,
            categoryId: it.categoryId || "",
            is_aditivo: it.is_aditivo,
          } as ProposalItem
        })

        const novoEnv: Environment = { id: crypto.randomUUID(), nome: j.nome || "Sistema resgatado", items }
        update("environments", [...data.environments, novoEnv])
        setResgateInfo({ nome: j.nome || "Sistema resgatado", antes, agora })
      } catch {
        // silencioso — resgate é opcional, a proposta segue em branco
      }
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resgatarSistemaId, leadDaUrlResgate, products, kits])

  function update<K extends keyof WizardState>(key: K, value: WizardState[K]) {
    setData(d => ({ ...d, [key]: value }))
  }

  function addEnvironment() {
    setEnvNome("")
    setEnvModalOpen(true)
  }

  function confirmAddEnvironment() {
    const nome = envNome.trim()
    if (!nome) return
    const env: Environment = { id: crypto.randomUUID(), nome, items: [] }
    update("environments", [...data.environments, env])
    setEnvModalOpen(false)
    setEnvNome("")
  }

  /** Tira projeto e instalação da proposta: os três lugares de lançamento. */
  function removerServicos() {
    setData(d => ({
      ...d,
      instalacao_ativo: false,
      admin_ativo: false,
      servicos: [],
      servicos_guardados: false,
    }))
  }

  function removeEnvironment(id: string) {
    update("environments", data.environments.filter(e => e.id !== id))
  }

  function openAddItem(envId: string) {
    setActiveEnvId(envId)
    setItemSearch(""); setSelectedItem(null); setItemQty(1)
    setItemMarkup(""); setItemDesconto(""); setItemUseMarkup(true)
    setItemCatFilter("")   // reset — usuário escolhe categoria ao abrir
    setSheetOpen(true)
  }

  /** Põe o item escrito no ambiente aberto e fecha o formulário. */
  function adicionarAvulso() {
    const valor = parseFloat(avulso.valor.replace(",", ".")) || 0
    const qtd = Math.max(1, parseInt(avulso.quantidade) || 1)
    if (!avulso.nome.trim() || valor <= 0 || !activeEnvId) return

    const item: ProposalItem = {
      id: Math.random().toString(36).slice(2),
      type: "product",
      // Sem produto no catálogo ainda: é justamente o que define o avulso.
      sourceId: "",
      nome: avulso.nome.trim(),
      imagem_url: null,
      quantidade: qtd,
      valor_unitario: valor,
      // Custo desconhecido: o vendedor sabe por quanto vende, não por quanto compra.
      preco_custo: 0,
      markup_especifico: 0,
      useMarkup: false,
      desconto_unitario: 0,
      categoryId: "",
      avulso: true,
      avulso_marca: avulso.marca.trim(),
      avulso_unidade: avulso.unidade.trim() || "UN",
      avulso_categoria: avulso.categoria.trim(),
      is_aditivo: false,
    }

    update("environments", data.environments.map(e =>
      e.id === activeEnvId ? { ...e, items: [...e.items, item] } : e))

    setAvulso({ nome: "", marca: "", unidade: "UN", categoria: "", valor: "", quantidade: "1" })
    setAvulsoAberto(false)
    /* Limpa a busca junto: o termo que não achou nada acabou de virar item, e
       deixá-lo no campo mantém na tela uma lista vazia sobre algo resolvido. */
    setItemSearch("")
  }

  function selectCatalogItem(type: "product" | "kit", source: Product | Kit) {
    setSelectedItem({ type, source })
    if (type === "product") {
      const p = source as Product
      setItemMarkup(String(p.markup_padrao || 0))
    }
    setItemSearch("")
  }

  function addItemToEnv() {
    if (!selectedItem || !activeEnvId) return
    const isProduct = selectedItem.type === "product"
    const source = selectedItem.source

    let valorUnit = 0
    if (isProduct) {
      const p = source as Product
      if (modoCliente) {
        // Em modo cliente usa sempre markup_padrao — já foi configurado antes da reunião
        valorUnit = Number(p.preco_custo) * (1 + (p.markup_padrao || 0) / 100)
      } else {
        // Fallback: se preco_venda vier 0/nulo (produto importado só com custo),
        // usa custo × markup — evita item entrar na proposta com valor zerado.
        const vendaBase = Number(p.preco_venda) || Number(p.preco_custo) * (1 + (p.markup_padrao || 0) / 100)
        valorUnit = itemUseMarkup
          ? Number(p.preco_custo) * (1 + (parseFloat(itemMarkup) || 0) / 100)
          : vendaBase - (parseFloat(itemDesconto) || 0)
      }
    } else {
      const k = source as Kit
      // Kit: soma preco_venda de cada componente (já tem markup embutido)
      valorUnit = k.items.reduce((s, i) => s + Number(i.product.preco_venda) * i.quantidade, 0)
    }

    let custoBruto = isProduct
      ? Number((source as Product).preco_custo)
      : (source as Kit).items.reduce((s, i) => s + Number(i.product.preco_custo) * i.quantidade, 0)

    // Produto composto: soma valor e custo dos componentes ocultos (internos).
    if (isProduct && (source as Product).tem_componentes) {
      valorUnit += Number((source as Product).venda_componentes || 0)
      custoBruto += Number((source as Product).custo_componentes || 0)
    }

    // Campanha de desconto vigente: aplica automático sobre o preço do item
    const catItem = isProduct ? (source as Product).categoryId : null
    const valorCheio = valorUnit
    valorUnit = aplicarCampanha(valorUnit, source.id, catItem, !isProduct)
    /* O serviço da categoria entra DEPOIS da campanha: o desconto de campanha
       incide sobre o produto, e o serviço sobre o preço que o cliente paga. */
    valorUnit = comServicoDaCategoria(valorUnit, catItem)

    const newItem: ProposalItem = {
      id: crypto.randomUUID(),
      type: selectedItem.type,
      sourceId: source.id,
      nome: source.nome,
      imagem_url: isProduct ? (source as Product).imagem_url : null,
      quantidade: itemQty,
      valor_unitario: valorUnit,
      valor_cheio: valorCheio,
      // Item novo: o piso é o preço de catálogo já com a campanha aplicada.
      valor_piso: valorUnit,
      preco_custo: custoBruto,
      markup_especifico: parseFloat(itemMarkup) || 0,
      useMarkup: itemUseMarkup,
      desconto_unitario: parseFloat(itemDesconto) || 0,
      categoryId: (itemCatFilter && itemCatFilter !== "__todos__") ? itemCatFilter : "",
      is_aditivo: false,
    }

    update("environments", data.environments.map(env =>
      env.id === activeEnvId ? { ...env, items: [...env.items, newItem] } : env
    ))
    // Volta para a lista da mesma categoria (não fecha o sheet)
    setSelectedItem(null)
    setItemQty(1)
    setItemMarkup(""); setItemDesconto(""); setItemUseMarkup(true)
    // Foco volta pra busca — adiciona o próximo sem clicar de novo
    setTimeout(() => itemSearchRef.current?.focus(), 50)
  }

  function addAllToEnv() {
    if (!activeEnvId || catalogFiltered.length === 0) return
    const newItems: ProposalItem[] = catalogFiltered.map(result => {
      const isProduct = result.type === "product"
      const source = result.source
      let valorUnit = 0
      if (isProduct) {
        const p = source as Product
        valorUnit = Number(p.preco_custo) * (1 + (p.markup_padrao || 0) / 100)
      } else {
        const k = source as Kit
        valorUnit = k.items.reduce((s, i) => s + Number(i.product.preco_venda) * i.quantidade, 0)
      }
      let custoBruto = isProduct
        ? Number((source as Product).preco_custo)
        : (source as Kit).items.reduce((s, i) => s + Number(i.product.preco_custo) * i.quantidade, 0)
      if (isProduct && (source as Product).tem_componentes) {
        valorUnit += Number((source as Product).venda_componentes || 0)
        custoBruto += Number((source as Product).custo_componentes || 0)
      }
      const catItem = isProduct ? (source as Product).categoryId : null
      valorUnit = aplicarCampanha(valorUnit, source.id, catItem, !isProduct)
    /* O serviço da categoria entra DEPOIS da campanha: o desconto de campanha
       incide sobre o produto, e o serviço sobre o preço que o cliente paga. */
    valorUnit = comServicoDaCategoria(valorUnit, catItem)
      return {
        id: crypto.randomUUID(), type: result.type, sourceId: source.id, nome: source.nome,
        imagem_url: isProduct ? (source as Product).imagem_url : null,
        quantidade: 1, valor_unitario: valorUnit, valor_piso: valorUnit,
        preco_custo: custoBruto,
        markup_especifico: isProduct ? Number((source as Product).markup_padrao || 0) : 0,
        useMarkup: true, desconto_unitario: 0,
        categoryId: (itemCatFilter && itemCatFilter !== "__todos__") ? itemCatFilter : "",
        is_aditivo: false,
      }
    })
    update("environments", data.environments.map(env =>
      env.id === activeEnvId ? { ...env, items: [...env.items, ...newItems] } : env
    ))
    setSelectedItem(null)
  }

  /** Troca a quantidade de um item já no escopo. */
  /**
   * Preço unitário editado na linha do item, dentro do escopo.
   *
   * O Admin põe o valor que quiser. Os demais só sobem: se digitarem abaixo do
   * piso, o valor volta para o piso em vez de ser recusado — a pessoa vê o que
   * aconteceu na hora, em vez de descobrir só ao salvar.
   */
  function updateItemPreco(envId: string, itemId: string, valor: number) {
    update("environments", data.environments.map(env =>
      env.id !== envId ? env : {
        ...env,
        items: env.items.map(i => {
          if (i.id !== itemId) return i
          const piso = i.valor_piso ?? 0
          const novo = meuRole === "ADMIN" ? valor : Math.max(valor, piso)
          return { ...i, valor_unitario: Math.max(0, novo) }
        }),
      }
    ))
  }

  function updateItemQtd(envId: string, itemId: string, quantidade: number) {
    update("environments", data.environments.map(env =>
      env.id === envId
        ? { ...env, items: env.items.map(i => i.id === itemId ? { ...i, quantidade } : i) }
        : env
    ))
  }

  function removeItem(envId: string, itemId: string) {
    update("environments", data.environments.map(env =>
      env.id === envId ? { ...env, items: env.items.filter(i => i.id !== itemId) } : env
    ))
  }

  /* Só o que está sendo oferecido entra na conta, aqui e no servidor.
     Se a tela somasse tudo, o vendedor fecharia a proposta vendo um total que
     o documento enviado ao cliente não teria — e a diferença só apareceria
     depois, na frente dele. */
  const sistemasOferecidos = data.environments.filter(e => (e.status ?? "ATIVO") === "ATIVO")

  // Calculate totals
  const subtotalProdutos = sistemasOferecidos.reduce((sum, env) =>
    sum + env.items.reduce((s, i) => s + i.valor_unitario * i.quantidade, 0), 0)

  const calcCusto = (tipo: "percentual" | "fixo", valor: string, base: number) => {
    const v = parseFloat(valor) || 0
    return tipo === "percentual" ? base * v / 100 : v
  }

  /* Marcar o sistema em vez de apagar.
     O cliente que gosta de tudo e fecha um so era resolvido apagando o resto
     da proposta — e com ele ia o trabalho de montar. Guardado, o sistema
     continua aqui e na ficha do cliente, sem cobrar. */
  function marcarSistema(envId: string, status: "ATIVO" | "GUARDADO" | "RECUSADO") {
    setData(d => ({
      ...d,
      environments: d.environments.map(e => e.id === envId ? { ...e, status } : e),
    }))
  }

  /** Soma dos produtos de um ambiente. */
  const totalDoAmbiente = (envId: string) => {
    const env = data.environments.find(e => e.id === envId)
    return env ? env.items.reduce((s, i) => s + i.valor_unitario * i.quantidade, 0) : 0
  }

  /** Soma dos produtos de uma categoria, na proposta inteira. */
  const totalDaCategoria = (categoryId: string) =>
    sistemasOferecidos.reduce((sum, env) =>
      sum + env.items
        .filter(i => (i.categoryId || products.find(p => p.id === i.sourceId)?.categoryId) === categoryId)
        .reduce((s, i) => s + i.valor_unitario * i.quantidade, 0), 0)

  /* A base de cada serviço. Serviço sem vínculo continua sobre o total: é o
     serviço da proposta inteira, e mudar isso quebraria proposta já salva. */
  const baseDoServico = (s: ServicoItem) =>
    s.environmentId ? totalDoAmbiente(s.environmentId)
      : s.categoryId ? totalDaCategoria(s.categoryId)
      : subtotalProdutos

  /* Bloco guardado não cobra: some do total, do documento e do que vai para o
     cliente — exatamente como um sistema guardado. */
  const servicosOferecidos = !data.servicos_guardados
  const custoInstalacao = data.instalacao_ativo && servicosOferecidos
    ? calcCusto(data.instalacao_tipo, data.instalacao_valor, subtotalProdutos) : 0
  const custoAdmin = data.admin_ativo && servicosOferecidos
    ? calcCusto(data.admin_tipo, data.admin_valor, subtotalProdutos) : 0
  const custoServicos = servicosOferecidos
    ? data.servicos.reduce((sum, s) => sum + calcCusto(s.tipo, s.valor, baseDoServico(s)), 0)
    : 0
  const subtotal = subtotalProdutos + custoInstalacao + custoAdmin + custoServicos

  /**
   * Quanto de serviço de categoria já está DENTRO do preço dos produtos.
   *
   * Não entra em conta nenhuma: o valor já está no preço do item, e somar de
   * novo cobraria duas vezes. Serve para quem monta a proposta enxergar o que
   * está cobrando — sem esta lista o serviço da categoria some de vista, e
   * ninguém lembra que ele existe até o cliente perguntar por que o produto
   * custa mais que na tabela.
   *
   * A conta é exata, e não é a ingênua. Se o preço do item é
   * `limpo × (1 + r) + fixo`, a soma da categoria é `P × (1 + r) + fixo × Q`.
   * Tirando a parte fixa sobra `P × (1 + r)`, e a fatia do percentual dentro
   * disso é `total × r / (1 + r)` — não `total × r`, que daria a mais.
   */
  const servicosEmbutidos = (() => {
    const porCategoria = new Map<string, { total: number; qtd: number }>()
    for (const env of sistemasOferecidos) {
      for (const i of env.items) {
        const cat = i.categoryId || products.find(p => p.id === i.sourceId)?.categoryId
        if (!cat) continue
        const acc = porCategoria.get(cat) ?? { total: 0, qtd: 0 }
        acc.total += i.valor_unitario * i.quantidade
        acc.qtd += i.quantidade
        porCategoria.set(cat, acc)
      }
    }

    const fora: { nome: string; categoria: string; detalhe: string; valor: number }[] = []
    for (const [catId, { total, qtd }] of porCategoria) {
      const cat = categories.find(c => c.id === catId)
      if (!cat?.servicos?.length) continue

      for (const s of embutidoNaCategoria(total, qtd, cat.servicos as ServicoPreDef[])) {
        if (s.embutido <= 0) continue
        const v = parseFloat(String(s.valor).replace(",", ".")) || 0
        fora.push({
          nome: s.nome,
          categoria: cat.nome,
          detalhe: s.tipo === "percentual" ? `${v}% em cada produto` : `${brl(v)} por unidade`,
          valor: s.embutido,
        })
      }
    }
    return fora
  })()
  const totalEmbutido = servicosEmbutidos.reduce((t, s) => t + s.valor, 0)

  /* O retrato do que foi embutido: uma entrada por categoria presente na
     proposta, com os serviços que ela tinha na hora da gravação. É o que
     permite, depois, desfazer o embutido pela taxa certa — a do dia em que a
     proposta foi montada, não a que estiver no cadastro quando alguém abrir. */
  const servicosDeCategoriaUsados = [...new Set(
    sistemasOferecidos.flatMap(env => env.items
      .map(i => i.categoryId || products.find(p => p.id === i.sourceId)?.categoryId)
      .filter((c): c is string => !!c)),
  )].map(categoryId => ({
    categoryId,
    servicos: (categories.find(c => c.id === categoryId)?.servicos ?? []) as ServicoPreDef[],
  }))

  /* Projeto e instalação vai para o cliente como BLOCO, do mesmo jeito que um
     sistema. Para isso os três lugares onde o serviço é lançado aqui
     — instalação, administração de obra e a lista de serviços — viram uma
     lista só. Antes instalação e administração entravam apenas no
     `valor_servico` somado: o documento do cliente cobrava os dois sem saber
     o nome deles, e quem reabrisse a proposta para editar os perdia. */
  const servicosDaProposta: ServicoItem[] = !servicosOferecidos ? [] : [
    ...(data.instalacao_ativo && custoInstalacao > 0
      ? [{
        id: "instalacao",
        nome: "Instalação e configuração",
        tipo: data.instalacao_tipo,
        valor: data.instalacao_valor,
      } as ServicoItem]
      : []),
    ...(data.admin_ativo && custoAdmin > 0
      ? [{
        id: "administracao",
        nome: "Administração de obra",
        tipo: data.admin_tipo,
        valor: data.admin_valor,
      } as ServicoItem]
      : []),
    ...data.servicos,
  ]
  const valorDeUmServico = (sv: ServicoItem) => calcCusto(sv.tipo, sv.valor, baseDoServico(sv))

  /* O que o bloco mostra no escopo, mesmo guardado: guardar não apaga o
     trabalho de montar, só tira do total. */
  const servicosNoEscopo: ServicoItem[] = [
    ...(data.instalacao_ativo
      ? [{ id: "instalacao", nome: "Instalação e configuração", tipo: data.instalacao_tipo, valor: data.instalacao_valor } as ServicoItem]
      : []),
    ...(data.admin_ativo
      ? [{ id: "administracao", nome: "Administração de obra", tipo: data.admin_tipo, valor: data.admin_valor } as ServicoItem]
      : []),
    ...data.servicos,
  ]

  /* O parcelamento deixou de ser montado aqui: quem escolhe forma, parcelas e
     entrada é o cliente, no link. Este passo só marca o que é oferecido. */
  // Teto de desconto do vendedor (config da empresa). ADMIN não tem teto.
  const descontoNum = Number(data.desconto_aplicado) || 0
  const [descontoModo, setDescontoModo] = useState<"PCT" | "VALOR">("PCT")
  // Texto do desconto enquanto digita; fora do foco mostra o valor calculado.
  const [descontoTxt, setDescontoTxt] = useState<string | null>(null)

  // ---- Leads como origem do cliente ----
  const [leads, setLeads] = useState<{ id: string; nome: string; email: string | null; telefone: string | null }[]>([])
  const [mostrarLeads, setMostrarLeads] = useState(false)
  /* Cliente que ainda não é lead.

     A proposta era o único lugar onde o nome entrava, e o cliente ficava sem
     cadastro nenhum: na visita seguinte tudo era redigitado, e o CRM não
     enxergava um negócio que já estava em andamento. Ao sair da
     Identificação, se o nome digitado não é de nenhum lead, a tela oferece
     guardá-lo. Recusar não impede de seguir — a proposta é o trabalho, o
     cadastro é consequência. */
  const [salvarLeadAberto, setSalvarLeadAberto] = useState(false)
  const [leadTelefone, setLeadTelefone] = useState("")
  const [leadOrigem, setLeadOrigem] = useState("INDICACAO")
  const [leadOrigemDetalhe, setLeadOrigemDetalhe] = useState("")
  const [leadSalvando, setLeadSalvando] = useState(false)
  /* O lead que veio do CRM já entra vinculado.

     A tela de Leads abre esta com ?lead=…, e isso era ignorado: o vínculo só
     nascia quando a proposta era criada para um cliente que ainda não existia
     no funil. Quem já vinha do card fechava a proposta e o lead ficava parado
     em "Criação de Proposta", sem apontar para o documento que nasceu dele. */
  const [leadVinculado, setLeadVinculado] = useState<string | null>(() => searchParams.get("lead"))
  /* Recusou uma vez, não pergunta de novo: a pessoa vai e volta entre as
     etapas, e um popup a cada passagem vira obstáculo. */
  const [leadDispensado, setLeadDispensado] = useState(false)

  useEffect(() => {
    fetch("/api/leads", { cache: "no-store" })
      .then(r => r.json())
      .then(j => setLeads(j.leads ?? []))
      .catch(() => {})
  }, [])

  /* Lead que veio do card do CRM: completa o contato a partir do próprio
     registro.

     A tela de Leads só mandava o nome na URL (?cliente=), então o email
     cadastrado no lead simplesmente sumia na proposta e era redigitado à mão.
     Preencher daqui, e não da query string, mantém o lead como fonte única —
     e não joga o email do cliente no histórico do navegador.

     Só preenche campo vazio: quem já digitou algo mandou mais que o cadastro. */
  const leadDaUrl = searchParams.get("lead")
  /* Nome do projeto vem pela URL junto do id: e so rotulo de tela, e busca-lo
     no servidor custaria uma requisicao para exibir um texto que quem clicou
     acabou de ver no card. */
  const projetoNome = searchParams.get("projetoNome")
  useEffect(() => {
    if (!leadDaUrl || leads.length === 0) return
    const lead = leads.find(l => l.id === leadDaUrl)
    if (!lead) return
    setData(d => ({
      ...d,
      client_name: d.client_name || lead.nome,
      client_email: d.client_email || lead.email || "",
    }))
  }, [leadDaUrl, leads])

  /* Só sugere quando há o que filtrar: a lista inteira aberta no foco esconde
     o campo e atrapalha quem já sabe o nome que vai digitar. */
  const leadsSugeridos = (() => {
    const termo = data.client_name.trim().toLowerCase()
    if (termo.length < 2) return []
    return leads
      .filter(l => l.nome.toLowerCase().includes(termo) && l.nome.toLowerCase() !== termo)
      .slice(0, 6)
  })()
  /** O nome digitado já é um lead? Compara sem acento e sem caixa. */
  function nomeJaEhLead(nome: string) {
    const chave = (t: string) => t.normalize("NFD").replace(/[̀-ͯ]/g, "").trim().toLowerCase()
    const alvo = chave(nome)
    return !!alvo && leads.some(l => chave(l.nome) === alvo)
  }

  function avancarDaIdentificacao() {
    if (!leadVinculado && !leadDispensado && data.client_name.trim() && !nomeJaEhLead(data.client_name)) {
      setSalvarLeadAberto(true)
      return
    }
    setStep(s => s + 1)
  }

  async function salvarComoLead() {
    setLeadSalvando(true)
    try {
      const r = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nome: data.client_name.trim(),
          email: data.client_email || null,
          telefone: leadTelefone || null,
          origem: leadOrigem,
          origem_detalhe: leadOrigem === "OUTRO" ? leadOrigemDetalhe : null,
          /* A cidade não tem campo próprio no lead e ia se perder. Escrita nas
             observações, ela pelo menos continua junto do contato. */
          observacoes: data.client_city ? `Cidade: ${data.client_city}` : null,
          /* Nasce já em Criação de Proposta: a proposta dele está sendo escrita
             agora. NOVO é para quem foi cadastrado pelo menu Leads e ainda não
             virou nada. */
          status: "ELABORANDO_PROPOSTA",
        }),
      })
      if (r.ok) {
        const lead = await r.json()
        setLeadVinculado(lead.id)
        // Entra na lista local para o próprio campo parar de sugerir criá-lo.
        setLeads(l => [{ id: lead.id, nome: lead.nome, email: lead.email, telefone: lead.telefone }, ...l])
      }
    } catch { /* cadastro é consequência, não pode travar a proposta */ }
    finally {
      setLeadSalvando(false)
      setSalvarLeadAberto(false)
      setStep(s => s + 1)
    }
  }

  const descontoAcimaTeto = meuRole !== "ADMIN" && descontoNum > tetoDesconto
  const descontoLiberado = !descontoAcimaTeto || pedidoDesconto?.status === "APROVADO"

  async function pedirAprovacaoDesconto() {
    setPedindoDesconto(true)
    try {
      const r = await fetch("/api/descontos", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ valor_desconto: descontoNum, justificativa: justificativaDesconto }),
      })
      const j = await r.json()
      if (r.ok) setPedidoDesconto(j.pedido)
      else await confirmar({ titulo: j.error || "Erro ao pedir aprovação.", apenasAviso: true })
    } finally { setPedindoDesconto(false) }
  }

  /* Quanto a campanha abateu no total. Some por item a diferença entre o preço
     cheio e o preço já com campanha. */
  const descontoCampanha = sistemasOferecidos.reduce((soma, env) =>
    soma + env.items.reduce((s, it) =>
      s + Math.max(0, (Number(it.valor_cheio ?? it.valor_unitario) - Number(it.valor_unitario)) * it.quantidade), 0), 0)

  const totalComDesconto = data.desconto_aplicado && Number(data.desconto_aplicado) > 0
    ? subtotal * (1 - Number(data.desconto_aplicado) / 100)
    : subtotal

  /* Qualquer coisa que mexa no total refaz as parcelas: entrada, desconto e
     também o próprio total (mudar a quantidade de um item, por exemplo).
     Sem o total aqui, trocar uma quantidade deixava a soma das parcelas
     divergente e o valor aparecia em vermelho como se fosse erro. */
  useEffect(() => {
    if (data.installments.length > 0) applyInstallments(data.installments.length)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data.valor_entrada, data.desconto_aplicado, totalComDesconto])



  /** Abre o modal de nome. Mesmo caminho de addEnvironment. */
  function novoServico() {
    setServNome("")
    setServModalOpen(true)
  }

  function confirmAddServico() {
    const nome = servNome.trim()
    if (!nome) return
    update("servicos", [
      ...data.servicos,
      { id: crypto.randomUUID(), nome, tipo: "fixo", valor: "" },
    ])
    setServModalOpen(false)
    setServNome("")
  }
  function updateServico(id: string, key: keyof ServicoItem, value: string) {
    update("servicos", data.servicos.map(s => s.id === id ? { ...s, [key]: value } : s))
  }

  function removeServico(id: string) {
    update("servicos", data.servicos.filter(s => s.id !== id))
  }

  /* Editar o serviço onde ele aparece.

     O bloco SERVIÇOS do escopo mandava ajustar em "Valores": quem monta via o
     valor errado na tela e tinha de atravessar a proposta para corrigir uma
     casa decimal. Estas três funções deixam o mesmo controle valer nos dois
     lugares — instalação e administração de obra moram em campos próprios da
     proposta, o resto na lista de serviços, e quem edita não precisa saber
     dessa diferença. */
  function ajustarServico(id: string, key: "nome" | "tipo" | "valor", value: string) {
    if (id === "instalacao") {
      if (key === "tipo") update("instalacao_tipo", value as "percentual" | "fixo")
      else if (key === "valor") update("instalacao_valor", value)
      return
    }
    if (id === "administracao") {
      if (key === "tipo") update("admin_tipo", value as "percentual" | "fixo")
      else if (key === "valor") update("admin_valor", value)
      return
    }
    updateServico(id, key, value)
  }

  /* Tirar instalação ou administração é desligar o switch, não apagar linha:
     o valor digitado fica guardado para quem religar. */
  function tirarServico(id: string) {
    if (id === "instalacao") return update("instalacao_ativo", false)
    if (id === "administracao") return update("admin_ativo", false)
    removeServico(id)
  }

  /** Instalação e administração têm nome fixo e moram em campos próprios. */
  const servicoDaProposta = (id: string) => id === "instalacao" || id === "administracao"

  /* O serviço é sempre um valor em reais.

     O percentual continua sendo calculado — proposta antiga foi lançada assim e
     o total dela não pode mudar sozinha —, mas a caixa mostra reais mesmo
     nesses casos: percentual escrito numa caixa sem o "%" ao lado é 10 lido
     como dez reais. Editar converte a linha para valor fixo, que é o que ela
     passa a ser dali em diante. */
  const valorEmReais = (sv: ServicoItem) =>
    sv.tipo === "percentual"
      ? (calcCusto(sv.tipo, sv.valor, baseDoServico(sv)) || 0).toFixed(2)
      : sv.valor

  /* Tipo e valor mudam JUNTOS, numa gravação só: `updateServico` lê a lista da
     renderização atual, então duas chamadas seguidas fariam a segunda escrever
     por cima da primeira e o "fixo" voltaria a ser percentual no mesmo clique.
     (Instalação e administração são campos separados do estado, aí não há
     disputa.) */
  function ajustarValorEmReais(id: string, valor: string) {
    if (id === "instalacao") {
      update("instalacao_tipo", "fixo")
      update("instalacao_valor", valor)
      return
    }
    if (id === "administracao") {
      update("admin_tipo", "fixo")
      update("admin_valor", valor)
      return
    }
    update("servicos", data.servicos.map(sv =>
      sv.id === id ? { ...sv, tipo: "fixo" as const, valor } : sv))
  }

  function applyInstallments(count: number) {
    // Entrada abate do total; o restante é dividido nas parcelas.
    const entrada = Number(data.valor_entrada) || 0
    const aParcelar = Math.max(0, totalComDesconto - entrada)
    const valorParcela = aParcelar / count
    const base = new Date()
    /* A ENTRADA VIRA UMA LINHA.

       Ela era descontada do total e sumia: o cronograma nascia só com as
       parcelas, e o pedido no Olist chegava sem a entrada — que é o dinheiro
       que entra primeiro. Agora ela é a primeira linha, vencendo hoje e
       marcada como entrada, e as parcelas seguem a partir do mês seguinte. */
    const inst: Installment[] = []
    if (entrada > 0) {
      inst.push({
        numero_parcela: 1,
        valor: parseFloat(entrada.toFixed(2)),
        data_vencimento: base.toISOString().split("T")[0],
        entrada: true,
      })
    }
    for (let i = 0; i < count; i++) {
      const d = new Date(base)
      d.setMonth(d.getMonth() + i + 1)
      // A última fecha a conta: a divisão trunca centavos e a soma ficava
      // abaixo do total, virando saldo em aberto de uma venda quitada.
      const ultima = i === count - 1
      const jaLancado = parseFloat(valorParcela.toFixed(2)) * i
      inst.push({
        numero_parcela: inst.length + 1,
        valor: parseFloat((ultima ? aParcelar - jaLancado : valorParcela).toFixed(2)),
        data_vencimento: d.toISOString().split("T")[0],
        entrada: false,
      })
    }
    update("installments", inst)
  }

  function addExtraPage() {
    update("extraPages", [
      ...data.extraPages,
      { id: crypto.randomUUID(), titulo: "Nova Página", conteudo_markdown: "" }
    ])
  }

  // Modelos de página (informativos prontos)
  const [pageTemplates, setPageTemplates] = useState<{ id: string; nome: string; conteudo: string }[]>([])
  const carregarPageTemplates = useCallback(async () => {
    const r = await fetch("/api/page-templates").catch(() => null)
    if (r?.ok) setPageTemplates((await r.json()).templates || [])
  }, [])
  useEffect(() => { carregarPageTemplates() }, [carregarPageTemplates])

  function inserirModeloPagina(tplId: string) {
    const tpl = pageTemplates.find(t => t.id === tplId)
    if (!tpl) return
    update("extraPages", [
      ...data.extraPages,
      { id: crypto.randomUUID(), titulo: tpl.nome, conteudo_markdown: tpl.conteudo },
    ])
  }
  async function salvarComoModelo(page: ExtraPage) {
    const nome = prompt("Nome do modelo:", page.titulo || "Informativo")
    if (!nome?.trim()) return
    const r = await fetch("/api/page-templates", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nome: nome.trim(), conteudo: page.conteudo_markdown }),
    })
    if (r.ok) { await carregarPageTemplates(); await confirmar({ titulo: "Modelo salvo!", apenasAviso: true }) }
  }

  function updateExtraPage(id: string, key: "titulo" | "conteudo_markdown", value: string) {
    update("extraPages", data.extraPages.map(p => p.id === id ? { ...p, [key]: value } : p))
  }

  function removeExtraPage(id: string) {
    update("extraPages", data.extraPages.filter(p => p.id !== id))
  }

  // Anexos por página extra
  const [uploadingPagina, setUploadingPagina] = useState<string | null>(null)
  const [erroAnexo, setErroAnexo] = useState("")
  async function anexarNaPagina(pageId: string, file: File) {
    setUploadingPagina(pageId)
    setErroAnexo("")
    try {
      const fd = new FormData(); fd.append("file", file)
      const res = await fetch("/api/upload", { method: "POST", body: fd })
      if (!res.ok) {
        // Antes o erro era engolido: a barra sumia e o anexo simplesmente não
        // aparecia, sem nenhuma pista do motivo (tipo bloqueado, tamanho, blob).
        const j = await res.json().catch(() => ({}))
        setErroAnexo(j.error || `Falha ao enviar o arquivo (HTTP ${res.status}).`)
        return
      }
      const { url, nome } = await res.json()
      const ext = file.name.includes(".") ? file.name.split(".").pop()! : "file"
      // Forma funcional: o upload é assíncrono e `data` aqui já pode estar velho.
      setData(d => ({
        ...d,
        extraPages: d.extraPages.map(p => p.id === pageId
          ? { ...p, anexos: [...(p.anexos ?? []), { nome: file.name || nome, url, ext }] } : p),
      }))
    } catch {
      setErroAnexo("Falha de conexão ao enviar o arquivo.")
    } finally { setUploadingPagina(null) }
  }
  function removerAnexoPagina(pageId: string, idx: number) {
    update("extraPages", data.extraPages.map(p => p.id === pageId
      ? { ...p, anexos: (p.anexos ?? []).filter((_, i) => i !== idx) } : p))
  }

  async function handleSave() {
    if (!data.client_name) { setError("Nome do cliente é obrigatório"); setStep(0); return }
    setSaving(true); setError("")
    try {
      const payload = {
        /* O vínculo vai junto da criação: é ele que faz a proposta nascer com
           o cadastro do cliente (CPF/CNPJ, endereço) que já está no lead, em
           vez de pedir tudo de novo a quem já é cliente. */
        leadId: !editId ? leadVinculado : undefined,
        /* De qual projeto DAQUELE cliente e esta proposta. Vem da URL, posta
           pelo botao do projeto no card do funil; nulo quando o cliente tem
           um negocio so, que e o caso comum. */
        leadProjetoId: !editId ? (searchParams.get("projeto") || null) : undefined,
        client_name: data.client_name,
        client_email: data.client_email || null,
        client_city: data.client_city || null,
        project_type: data.project_type,
        data_expiracao: data.data_expiracao || null,
        environments: data.environments.map(env => ({
          /* O id do navegador vai junto. Ele não é gravado: serve para o
             servidor religar o serviço preso a este sistema ao id que o banco
             vai gerar. Sem ele, o vínculo apontava para um ambiente que não
             existe e o serviço valia R$ 0 na proposta do cliente, no contrato
             e no Olist, enquanto o total cobrava o valor cheio. */
          id: env.id,
          nome: env.nome,
          status: env.status ?? "ATIVO",
          items: env.items.map(item => {
            const prodRef = item.type === "product" ? products.find(p => p.id === item.sourceId) : undefined
            return {
            [item.type === "product" ? "productId" : "kitId"]: item.sourceId || null,
            categoryId: item.categoryId || prodRef?.categoryId || null,
            nome_snapshot: item.nome || null,
            sku_snapshot: prodRef?.sku ?? null,
            quantidade: item.quantidade,
            markup_especifico: item.markup_especifico || null,
            desconto_unitario: item.desconto_unitario || null,
            valor_unitario: item.valor_unitario,
            valor_total: item.valor_unitario * item.quantidade,
            is_aditivo: item.is_aditivo,
            // Item escrito na hora: o que o vendedor digitou é tudo o que se
            // sabe dele até alguém cadastrar o produto de verdade.
            avulso: item.avulso ?? false,
            avulso_marca: item.avulso_marca || null,
            avulso_unidade: item.avulso_unidade || null,
            avulso_categoria: item.avulso_categoria || null,
          }})
        })),
        valor_servico: (custoInstalacao + custoAdmin + custoServicos),
        installments: data.installments,
        extraPages: data.extraPages.map((p, i) => ({ ...p, ordem: i })),
        payment_methods: [
          ...data.payment_methods,
          ...(data.payment_outros.trim() ? [data.payment_outros.trim()] : []),
        ],
        dias_garantia: data.dias_garantia ? Number(data.dias_garantia) : null,
        exibir_valor_unitario: data.exibir_valor_unitario === true,
        formas_oferecidas: JSON.stringify(data.formas_oferecidas),
        servicos_detalhe: servicosDaProposta,
        servicos_categoria: servicosDeCategoriaUsados,
        desconto_campanha: descontoCampanha > 0 ? descontoCampanha : null,
        desconto_aplicado: data.desconto_aplicado ? Number(data.desconto_aplicado) : null,
        valor_entrada: data.valor_entrada ? Number(data.valor_entrada) : null,
        observacoes: [
          data.observacoes || null,
          `[META:${JSON.stringify({ cor: data.cor_destaque, confidencial: data.confidencial })}]`,
        ].filter(Boolean).join("\n"),
      }
      const url = editId ? `/api/propostas/${editId}` : "/api/propostas"
      const method = editId ? "PUT" : "POST"
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })
      const json = await res.json().catch(() => ({}))
      if (!res.ok) throw new Error(json.error || `Erro ${res.status} ao salvar proposta`)

      /* Fecha o laço com o CRM: o lead passa a apontar para a proposta que
         nasceu dele. Sem isto o cadastro ficava solto em "Novo" enquanto a
         negociação já estava em outra tela. Falhar aqui não desfaz a proposta,
         que é o que importa. */
      if (leadVinculado && !editId) {
        fetch(`/api/leads/${leadVinculado}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          /* Aqui, e só aqui, o lead passa a "Proposta Enviada": existe um
             documento que o cliente pode receber. Ao abrir o assistente ele
             tinha ido para "Criação de Proposta" — montar o orçamento leva
             dias, e o funil não pode dizer que já saiu. O motivo entra no
             histórico do lead, que é onde a negociação continua sendo lida. */
          body: JSON.stringify({
            proposalId: json.id,
            status: "PROPOSTA_ENVIADA",
            motivo: `Proposta ${json.numero ?? ""} criada.`.replace(/\s+/g, " ").trim(),
          }),
        }).catch(() => {})
      }

      router.push(`/propostas/${editId || json.id}`)
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Erro desconhecido")
    } finally {
      setSaving(false)
    }
  }

  /* Busca em todo o catálogo, sem passar por categoria.

     Inclui produto sem categoria — que antes ficava inalcançável, porque a
     única porta para a lista era escolher uma categoria primeiro. */
  const buscaGlobal = (() => {
    const termo = itemSearch.trim().toLowerCase()
    if (termo.length < 2) return []
    return [
      ...products
        .filter(p => p.nome.toLowerCase().includes(termo) || p.sku.toLowerCase().includes(termo))
        .slice(0, 40)
        .map(p => ({ type: "product" as const, source: p })),
      ...kits
        .filter(k => k.nome.toLowerCase().includes(termo))
        .slice(0, 8)
        .map(k => ({ type: "kit" as const, source: k })),
    ]
  })()

  // Filtro por categoria: "__todos__" mostra tudo; uma categoria específica
  // mostra SÓ os produtos dela (bug: antes ignorava o itemCatFilter).
  const catFiltroAtivo = itemCatFilter && itemCatFilter !== "__todos__" ? itemCatFilter : null
  const catalogFiltered = [
    ...products.filter(p => {
      if (catFiltroAtivo && p.categoryId !== catFiltroAtivo) return false
      if (!itemSearch) return true
      return p.nome.toLowerCase().includes(itemSearch.toLowerCase()) ||
             p.sku.toLowerCase().includes(itemSearch.toLowerCase())
    }).slice(0, 50).map(p => ({ type: "product" as const, source: p })),
    // Kits só aparecem quando não há categoria específica selecionada
    ...(catFiltroAtivo ? [] : kits.filter(k =>
      k.nome.toLowerCase().includes(itemSearch.toLowerCase())
    ).slice(0, 5).map(k => ({ type: "kit" as const, source: k }))),
  ]

  // Sem min-h-screen nem fundo próprio: esta tela vive DENTRO do painel de
  // conteúdo, que já rola e já tem o vidro. `min-h-screen` pedia 100vh numa
  // área menor que isso (a topbar ocupa parte), o que criava rolagem sobrando
  // e a sensação de travamento; `bg-background` pintava um retângulo opaco
  // por cima do vidro, deixando o preto sobre cinza.
  return (
    <div className="p-4 md:p-6">
      {/* Modal: novo ambiente */}
      {/* Guardar o cliente como lead ao sair da Identificação.

          Sem isto a proposta era o único registro do cliente: na visita
          seguinte tudo era redigitado e o CRM não enxergava um negócio já em
          andamento. "Agora não" segue direto e não volta a perguntar. */}
      <Dialog open={salvarLeadAberto} onOpenChange={v => { if (!v) setSalvarLeadAberto(false) }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Guardar {data.client_name.trim()} nos leads?</DialogTitle>
            <DialogDescription className="pt-1">
              Ainda não há cadastro com esse nome. Guardando agora, o contato fica
              disponível na próxima proposta e o negócio aparece no CRM.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3 px-5 sm:px-6 py-3">
            <div className="rounded-xl bg-muted/40 px-3 py-2 text-[13px] text-muted-foreground">
              {[data.client_email, data.client_city].filter(Boolean).join(" · ") || "Sem e-mail ou cidade preenchidos"}
            </div>
            <div>
              <Label className="text-foreground/80 text-sm">Telefone</Label>
              <Input value={leadTelefone} onChange={e => setLeadTelefone(e.target.value)}
                placeholder="(11) 9..." className="bg-muted border-border text-foreground mt-1.5" />
            </div>
            <div>
              <Label className="text-foreground/80 text-sm">Origem</Label>
              <select value={leadOrigem} onChange={e => setLeadOrigem(e.target.value)}
                className="mt-1.5 h-10 w-full rounded-xl border border-border bg-muted px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40">
                <option value="INDICACAO">Indicação</option>
                <option value="SITE">Site</option>
                <option value="PARCEIRO">Parceiro</option>
                <option value="INSTAGRAM">Instagram</option>
                <option value="OUTRO">Outro</option>
              </select>
            </div>
            {/* "Outro" sozinho vira a maior fatia do relatório de origem sem
                ninguém saber do que ela é feita. O texto entra em campo
                próprio; `origem` continua "OUTRO" para o agrupamento não
                quebrar em uma fatia por resposta. */}
            {leadOrigem === "OUTRO" && (
              <div>
                <Label className="text-foreground/80 text-sm">Qual outro?</Label>
                <Input autoFocus value={leadOrigemDetalhe}
                  onChange={e => setLeadOrigemDetalhe(e.target.value)}
                  placeholder="Ex: feira, arquiteto, cliente antigo"
                  className="bg-muted border-border text-foreground mt-1.5" />
              </div>
            )}
          </div>

          <DialogFooter className="gap-2 sm:gap-2">
            <Button variant="outline" disabled={leadSalvando}
              onClick={() => { setLeadDispensado(true); setSalvarLeadAberto(false); setStep(s => s + 1) }}>
              Agora não
            </Button>
            <Button onClick={salvarComoLead} disabled={leadSalvando}>
              {leadSalvando ? "Salvando..." : "Guardar e continuar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Novo Serviço: mesmo caminho do Novo Sistema, para o serviço nascer
          com nome. Serviço sem nome chega ao cliente como linha em branco. */}
      <Dialog open={servModalOpen} onOpenChange={setServModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-primary/15">
              <Plus className="h-7 w-7 text-primary" />
            </div>
            <DialogTitle className="text-center text-xl">Novo Serviço</DialogTitle>
            <DialogDescription className="text-center pt-1">
              Dê um nome ao serviço. É por ele que o cliente vai reconhecer o que está contratando.
            </DialogDescription>
          </DialogHeader>

          <div className="px-5 py-3 sm:px-6">
            <Label className="text-sm text-foreground/80">Nome do serviço</Label>
            <Input
              autoFocus
              value={servNome}
              onChange={e => setServNome(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter") confirmAddServico() }}
              placeholder="Ex: Projeto, Instalação, Comissionamento..."
              className="mt-1.5 border-border bg-muted text-foreground"
            />
            <div className="mt-3 flex flex-wrap gap-1.5">
              {["Projeto", "Instalação", "Comissionamento", "Treinamento", "Administração de Obra"].map(sugestao => (
                <button
                  key={sugestao}
                  type="button"
                  onClick={() => setServNome(sugestao)}
                  className="rounded-full border border-border bg-muted px-2.5 py-1 text-xs text-muted-foreground transition-colors hover:border-primary hover:text-foreground"
                >
                  {sugestao}
                </button>
              ))}
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-2">
            <Button
              variant="outline"
              onClick={() => setServModalOpen(false)}
              className="flex-1 border-border text-foreground/80 hover:text-foreground"
            >
              Cancelar
            </Button>
            <Button
              onClick={confirmAddServico}
              disabled={!servNome.trim()}
              className="flex-1 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Plus className="h-4 w-4" /> Adicionar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={envModalOpen} onOpenChange={setEnvModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <div className="mx-auto mb-3 w-14 h-14 rounded-full bg-primary/15 flex items-center justify-center">
              <Plus className="w-7 h-7 text-primary" />
            </div>
            <DialogTitle className="text-center text-xl">Novo Sistema</DialogTitle>
            <DialogDescription className="text-center pt-1">
              Dê um nome para o sistema que será detalhado na proposta.
            </DialogDescription>
          </DialogHeader>

          <div className="px-5 sm:px-6 py-3">
            <Label className="text-foreground/80 text-sm">Nome do sistema</Label>
            <Input
              autoFocus
              value={envNome}
              onChange={e => setEnvNome(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter") confirmAddEnvironment() }}
              placeholder="Ex: Sala de Estar, Home Theater, Cozinha..."
              className="bg-muted border-border text-foreground mt-1.5"
            />
            <div className="flex flex-wrap gap-1.5 mt-3">
              {ambientesFrequentes.map(sugestao => (
                <button
                  key={sugestao}
                  type="button"
                  onClick={() => setEnvNome(sugestao)}
                  className="px-2.5 py-1 rounded-full text-xs bg-muted border border-border text-muted-foreground hover:text-foreground hover:border-primary transition-colors"
                >
                  {sugestao}
                </button>
              ))}
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-2">
            <Button
              variant="outline"
              onClick={() => setEnvModalOpen(false)}
              className="border-border text-foreground/80 hover:text-foreground flex-1"
            >
              Cancelar
            </Button>
            <Button
              onClick={confirmAddEnvironment}
              disabled={!envNome.trim()}
              className="bg-primary hover:bg-primary/90 text-primary-foreground flex-1 gap-1.5"
            >
              <Plus className="w-4 h-4" /> Adicionar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header estilo iOS */}
        <div>
          <p className="text-[11px] uppercase tracking-widest text-muted-fg">
            {templateId ? (templateName ? `Template · ${templateName}` : "Nova proposta") : "Nova proposta"}
          </p>
          <h1 className="text-[30px] md:text-[32px] font-bold text-foreground tracking-tight leading-none mt-1 truncate">
            {data.client_name?.trim() || "Nova Proposta"}
          </h1>
          {/* De qual projeto do cliente é esta proposta.
              Sem isto, duas propostas do mesmo comprador ficam idênticas na
              tela, e quem volta depois do café não sabe se está montando a da
              cobertura ou a da casa de praia. */}
          {projetoNome && (
            <p className="mt-1.5 inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-2.5 py-1 text-[12px] font-medium text-primary">
              Projeto: {projetoNome}
            </p>
          )}
          {/* Resgate de sistema do histórico: mostra que o preço mudou (ou
              não) em vez de deixar o número novo aparecer calado, como se
              sempre tivesse sido esse. */}
          {resgateInfo && (
            <p className="mt-1.5 inline-flex items-center gap-1.5 rounded-full bg-ios-orange/10 px-2.5 py-1 text-[12px] font-medium text-ios-orange">
              &quot;{resgateInfo.nome}&quot; resgatado do histórico, preço da época {brl(resgateInfo.antes)}, hoje {brl(resgateInfo.agora)}
              {resgateInfo.agora !== resgateInfo.antes ? ` (${resgateInfo.agora > resgateInfo.antes ? "+" : ""}${brl(resgateInfo.agora - resgateInfo.antes)})` : ""}
            </p>
          )}
        </div>

        {/* Step indicator, segmented com linha conectora */}
        <div className="flex items-center">
          {STEPS.map((label, i) => {
            const done = i < step
            const active = i === step
            return (
              <div key={i} className="flex items-center flex-1 last:flex-none min-w-0">
                <button onClick={() => setStep(i)} className="flex items-center gap-2 min-w-0 active:opacity-70">
                  <span className={`w-7 h-7 rounded-full flex items-center justify-center text-[13px] font-semibold flex-shrink-0 transition-all ${
                    done ? "bg-ios-blue text-background" : active ? "bg-ios-blue text-background ring-4 ring-ios-blue/15" : "bg-surface-2 text-muted-fg"
                  }`}>
                    {done ? <Check className="w-3.5 h-3.5" strokeWidth={2.5} /> : i + 1}
                  </span>
                  <span className={`hidden sm:inline text-[14px] font-medium truncate ${active ? "text-foreground" : done ? "text-ios-blue" : "text-muted-fg"}`}>{label}</span>
                </button>
                {i < STEPS.length - 1 && (
                  <div className="flex-1 h-[2px] mx-2 rounded-full bg-surface-3 overflow-hidden">
                    <div className={`h-full rounded-full transition-all duration-300 ${done ? "bg-ios-blue w-full" : "w-0"}`} />
                  </div>
                )}
              </div>
            )
          })}
        </div>

        {error && (
          <div className="bg-ios-red/10 border border-ios-red/30 text-ios-red rounded-2xl px-4 py-3 text-sm">{error}</div>
        )}

        {/* STEP 1 - Identificação */}
        {step === 0 && (
          <div className="space-y-8">
            {/* Cabeçalho da etapa */}
            <div>
              <p className="text-[11px] uppercase tracking-[0.2em] text-muted-fg font-medium">Etapa 01</p>
              <h2 className="text-[26px] md:text-[32px] font-bold text-foreground tracking-tight leading-tight mt-1">Identificação do cliente</h2>
            </div>

            <div className="space-y-7">
              <div className="space-y-2">
                <Label className="text-[11px] uppercase tracking-[0.15em] text-muted-fg font-medium">Nome do cliente / empresa</Label>
                {/* Sugere leads já cadastrados enquanto digita. O contato veio
                    pelo CRM com nome, e-mail e telefone; redigitar é onde o
                    dado diverge entre as duas telas. */}
                <div className="relative">
                  <Input value={data.client_name}
                    onChange={e => { update("client_name", e.target.value); setMostrarLeads(true) }}
                    onFocus={() => setMostrarLeads(true)}
                    onBlur={() => setTimeout(() => setMostrarLeads(false), 150)}
                    className="rounded-none border-0 border-b border-hairline bg-transparent px-0 h-11 text-[16px] focus-visible:ring-0 focus-visible:border-ios-blue"
                    placeholder="Ex: Arquiteta Marina Albuquerque" />
                  {mostrarLeads && leadsSugeridos.length > 0 && (
                    <div className="absolute left-0 right-0 top-full z-30 mt-1 max-h-56 overflow-y-auto rounded-xl border border-hairline bg-surface-1 shadow-lg">
                      {leadsSugeridos.map(l => (
                        <button key={l.id} type="button"
                          onMouseDown={e => e.preventDefault()}
                          onClick={() => {
                            setData(d => ({
                              ...d,
                              client_name: l.nome,
                              client_email: l.email || d.client_email,
                            }))
                            // Veio de um lead: não faz sentido oferecer criar outro.
                            setLeadVinculado(l.id)
                            setMostrarLeads(false)
                          }}
                          className="flex w-full flex-col gap-0.5 px-3.5 py-2.5 text-left transition-colors hover:bg-surface-2">
                          <span className="text-[14px] text-foreground">{l.nome}</span>
                          <span className="text-[12px] text-muted-fg">
                            {[l.email, l.telefone].filter(Boolean).join(" · ") || "Sem contato cadastrado"}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-7">
                <div className="space-y-2">
                  <Label className="text-[11px] uppercase tracking-[0.15em] text-muted-fg font-medium">E-mail</Label>
                  <Input type="email" value={data.client_email} onChange={e => update("client_email", e.target.value)}
                    className="rounded-none border-0 border-b border-hairline bg-transparent px-0 h-11 text-[16px] focus-visible:ring-0 focus-visible:border-ios-blue"
                    placeholder="contato@empresa.com.br" />
                </div>
                <div className="space-y-2">
                  <Label className="text-[11px] uppercase tracking-[0.15em] text-muted-fg font-medium">Cidade</Label>
                  <Input value={data.client_city} onChange={e => update("client_city", e.target.value)}
                    className="rounded-none border-0 border-b border-hairline bg-transparent px-0 h-11 text-[16px] focus-visible:ring-0 focus-visible:border-ios-blue"
                    placeholder="São Paulo, SP" />
                </div>
                <div className="space-y-2">
                  <Label className="text-[11px] uppercase tracking-[0.15em] text-muted-fg font-medium">Validade da proposta</Label>
                  <Input type="date" max="9999-12-31" value={data.data_expiracao} onChange={e => update("data_expiracao", e.target.value)}
                    className="rounded-none border-0 border-b border-hairline bg-transparent px-0 h-11 text-[16px] focus-visible:ring-0 focus-visible:border-ios-blue" />
                </div>
              </div>

              <div className="space-y-2.5">
                <Label className="text-[11px] uppercase tracking-[0.15em] text-muted-fg font-medium">Tipo de projeto</Label>
                <div className="flex flex-wrap gap-2">
                  {PROJECT_TYPES.map(type => (
                    <button key={type} type="button" onClick={() => update("project_type", type)}
                      className={`px-4 py-2 rounded-full text-[13px] font-semibold transition-all border ${
                        data.project_type === type
                          ? "bg-foreground border-foreground text-background"
                          : "bg-surface-2 border-hairline text-muted-fg hover:text-foreground"
                      }`}>
                      {type}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2 - Escopo */}
        {step === 1 && (
          <div className="space-y-5">
            <div className="flex items-end justify-between flex-wrap gap-3">
              <div>
                <p className="text-[11px] uppercase tracking-[0.2em] text-muted-fg font-medium">Etapa 02</p>
                <h2 className="text-[26px] md:text-[32px] font-bold text-foreground tracking-tight leading-tight mt-1">Definição de escopo</h2>
              </div>
              <div className="flex items-center gap-2">
                {/* Olho, ver custo interno (desabilitado em modo cliente) */}
                {!modoCliente && (
                  <button
                    onClick={() => setShowCusto(v => !v)}
                    title={showCusto ? "Ocultar custos" : "Ver custos internos"}
                    className={`p-1.5 rounded-lg border transition-colors ${
                      showCusto
                        ? "bg-amber-500/10 border-amber-500/50 text-amber-400"
                        : "bg-muted border-border text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {showCusto ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                )}

                {/* Modo Cliente */}
                <button
                  onClick={() => { setModoCliente(v => !v); setShowCusto(false) }}
                  title={modoCliente ? "Sair do modo apresentação" : "Ativar modo apresentação com cliente"}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm border transition-colors ${
                    modoCliente
                      ? "bg-emerald-500/15 border-emerald-500/50 text-emerald-300"
                      : "bg-muted border-border text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Users className="w-3.5 h-3.5" />
                  {modoCliente ? "Com cliente" : "Modo cliente"}
                </button>

                {/* Serviço ao lado de Sistema, com o mesmo desenho: projeto e
                    instalação são escopo tanto quanto um sistema, e quem monta
                    a proposta acrescenta os dois do mesmo jeito. */}
                <Button onClick={novoServico} variant="outline"
                  className="border-border text-foreground/80 hover:text-foreground hover:border-primary">
                  <Plus className="w-4 h-4 mr-2" /> Adicionar Serviço
                </Button>

                <Button onClick={addEnvironment} variant="outline"
                  className="border-border text-foreground/80 hover:text-foreground hover:border-primary">
                  <Plus className="w-4 h-4 mr-2" /> Adicionar Sistema
                </Button>
              </div>
            </div>

            {/* Banner modo cliente */}
            {modoCliente && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs">
                <Users className="w-3.5 h-3.5 flex-shrink-0" />
                <span>Modo apresentação ativo</span>
              </div>
            )}

            {data.environments.length === 0 ? (
              <div className="text-center py-16 ios-card">
                <p className="text-muted-foreground/60">Nenhum sistema adicionado ainda</p>
                <Button onClick={addEnvironment} className="mt-4 bg-primary hover:bg-primary/90 text-primary-foreground">
                  <Plus className="w-4 h-4 mr-2" /> Primeiro Sistema
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {data.environments.map(env => (
                  <div key={env.id} className="overflow-hidden rounded-2xl border border-hairline bg-surface-1">
                    <div className="flex items-center justify-between gap-2 border-b border-hairline px-5 py-4">
                      <div className="flex min-w-0 items-center gap-3">
                        <h3 className="truncate text-[15px] font-semibold text-foreground">{env.nome}</h3>
                      </div>
                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        {/* Guardado não soma no total e não vai pra página do
                            cliente; fica na ficha dele, pronto pra virar
                            proposta depois. "Recusado" não existe aqui: quem
                            monta a proposta ainda não mandou nada, então não
                            existe recusa ainda pra marcar, era o vendedor
                            recusando pelo cliente antes da hora. */}
                        {(env.status ?? "ATIVO") === "GUARDADO" && (
                          <span className="flex items-center gap-1 rounded-full bg-ios-orange/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-[0.06em] text-ios-orange">
                            <Bookmark className="h-2.5 w-2.5" /> Guardado
                          </span>
                        )}
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <button className="flex h-7 w-7 items-center justify-center rounded-full text-muted-fg hover:bg-muted hover:text-foreground">
                              <MoreVertical className="h-4 w-4" />
                            </button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {(env.status ?? "ATIVO") !== "ATIVO" && (
                              <DropdownMenuItem onClick={() => marcarSistema(env.id, "ATIVO")}>Oferecer</DropdownMenuItem>
                            )}
                            {(env.status ?? "ATIVO") !== "GUARDADO" && (
                              <DropdownMenuItem onClick={() => marcarSistema(env.id, "GUARDADO")}>Guardar</DropdownMenuItem>
                            )}
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => removeEnvironment(env.id)} className="text-ios-red focus:text-ios-red">
                              Remover
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                    <div className="px-5">
                      {env.items.length === 0 ? (
                        <p className="text-muted-foreground/40 text-sm py-3">Nenhum item ainda</p>
                      ) : (
                        <div className="-mx-5 divide-y divide-white/5">
                          {env.items.map((item, idx) => {
                            const totalVenda = item.valor_unitario * item.quantidade
                            const totalCusto = item.preco_custo * item.quantidade
                            const margem = totalCusto > 0 ? ((totalVenda - totalCusto) / totalCusto * 100) : 0
                            // Encontra o kit original para mostrar componentes
                            const kitSource = item.type === "kit" ? kits.find(k => k.id === item.sourceId) : null
                            return (
                              <KitItemRow
                                key={item.id}
                                indice={idx + 1}
                                item={item}
                                kitSource={kitSource ?? null}
                                totalVenda={totalVenda}
                                totalCusto={totalCusto}
                                margem={margem}
                                showCusto={showCusto && !modoCliente}
                                podeBaixarPreco={meuRole === "ADMIN"}
                                onRemove={() => removeItem(env.id, item.id)}
                                onQtd={n => updateItemQtd(env.id, item.id, n)}
                                onPreco={v => updateItemPreco(env.id, item.id, v)}
                              />
                            )
                          })}
                        </div>
                      )}
                      <button onClick={() => openAddItem(env.id)}
                        className="my-3 inline-flex items-center gap-1.5 rounded-xl bg-primary px-4 py-2.5 text-[13px] font-semibold text-primary-foreground transition-opacity hover:opacity-90">
                        <Plus className="w-3.5 h-3.5" /> Adicionar Item
                      </button>
                    </div>
                    {env.items.length > 0 && (
                      <div className="flex items-center justify-between px-5 py-4 border-t border-hairline">
                        <span className="text-[11px] uppercase tracking-[0.15em] text-muted-fg font-medium">Total do sistema</span>
                        <span className="text-foreground text-[18px] font-bold tracking-tight">
                          {brl(env.items.reduce((s, i) => s + i.valor_unitario * i.quantidade, 0))}
                        </span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Projeto e instalação, aqui no escopo e com o mesmo desenho de um
                sistema: cartão, valor e o menu de Guardar / Remover. É um
                bloco da venda como os outros — o cliente escolhe sobre ele do
                mesmo jeito, e quem monta precisa poder tirá-lo ou deixá-lo de
                lado sem caçar o lançamento em outro passo.

                Os valores se ajustam aqui mesmo — e também em "Valores", para
                quem estiver fechando por lá. Parte do serviço entra sozinho
                pela categoria do produto e já vem dentro do preço dele. */}
            {(data.instalacao_ativo || data.admin_ativo || data.servicos.length > 0) && (
              <div className="ios-card overflow-hidden">
                <div className="flex items-center justify-between px-5 py-4">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="w-2 h-2 rounded-full bg-foreground flex-shrink-0" />
                    <h3 className="text-[13px] font-semibold text-foreground uppercase tracking-[0.1em] truncate">
                      Serviços
                    </h3>
                  </div>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    {data.servicos_guardados && (
                      <span className="flex items-center gap-1 rounded-full bg-ios-orange/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-[0.06em] text-ios-orange">
                        <Bookmark className="h-2.5 w-2.5" /> Guardado
                      </span>
                    )}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button className="flex h-7 w-7 items-center justify-center rounded-full text-muted-fg hover:bg-muted hover:text-foreground">
                          <MoreVertical className="h-4 w-4" />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        {data.servicos_guardados ? (
                          <DropdownMenuItem onClick={() => update("servicos_guardados", false)}>Oferecer</DropdownMenuItem>
                        ) : (
                          <DropdownMenuItem onClick={() => update("servicos_guardados", true)}>Guardar</DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={removerServicos} className="text-ios-red focus:text-ios-red">
                          Remover
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>

                {/* Edita aqui mesmo. Antes esta lista era só leitura e mandava
                    ajustar em "Valores" — o valor errado ficava na cara de quem
                    monta, a dois passos de distância de onde se corrige.

                    O serviço é o valor que se escolhe, em reais: o percentual e
                    o "sobre toda a proposta" saíram. Serviço lançado como % do
                    escopo mudava de preço sozinho a cada item que entrava, e
                    quem fechava não sabia mais que número tinha combinado. A
                    caixa mostra sempre reais — inclusive na proposta antiga,
                    lançada em percentual, que aparece já convertida. */}
                <div className="px-5">
                  <div className="divide-y divide-hairline/60 border-t border-hairline/60">
                    {servicosNoEscopo.map(sv => (
                      <div key={sv.id} className="flex items-center gap-2 py-3">
                        {servicoDaProposta(sv.id) ? (
                          <p className="min-w-0 flex-1 truncate text-[14px] font-medium leading-tight text-foreground">{sv.nome}</p>
                        ) : (
                          <Input value={sv.nome} onChange={e => ajustarServico(sv.id, "nome", e.target.value)}
                            placeholder="Nome do serviço"
                            className="h-8 min-w-0 flex-1 border-0 bg-transparent p-0 text-[14px] font-medium focus-visible:ring-0" />
                        )}
                        {/* Caixa discreta: o valor do serviço é uma linha de
                            leitura antes de ser um campo, e um campo encaixotado
                            do lado do nome pesava mais que o próprio serviço. */}
                        <span className="flex-shrink-0 text-[13px] text-muted-fg">R$</span>
                        <CampoValor value={valorEmReais(sv)}
                          onChange={v => ajustarValorEmReais(sv.id, v)}
                          placeholder="0,00"
                          className="h-7 w-24 flex-shrink-0 border-0 bg-transparent px-0 text-right text-[15px] font-semibold tabular-nums shadow-none focus-visible:ring-0" />
                        <button type="button" onClick={() => tirarServico(sv.id)}
                          className="flex-shrink-0 text-muted-foreground/50 hover:text-destructive">
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                  <button type="button" onClick={novoServico}
                    className="my-3 flex w-full items-center justify-center gap-1.5 rounded-lg border border-dashed border-border py-2 text-[12px] font-medium text-muted-foreground transition-all hover:border-primary/60 hover:text-foreground">
                    <Plus className="h-3.5 w-3.5" /> Adicionar serviço
                  </button>
                </div>

                <div className="flex items-center justify-between px-5 py-4 border-t border-hairline">
                  <span className="text-[11px] uppercase tracking-[0.15em] text-muted-fg font-medium">Total do bloco</span>
                  <span className={`text-[18px] font-bold tracking-tight ${data.servicos_guardados ? "text-muted-fg line-through" : "text-foreground"}`}>
                    {brl(servicosNoEscopo.reduce((t, sv) => t + calcCusto(sv.tipo, sv.valor, baseDoServico(sv)), 0))}
                  </span>
                </div>
              </div>
            )}

            {/* Não há cartão por serviço aqui: o bloco SERVIÇOS logo acima já
                lista todos, com nome, base e valor, e é ele que vai ao cliente.
                Dois lugares mostrando a mesma lista na mesma tela é só ruído. */}

            {data.environments.length > 0 && (
              <div className="bg-surface-1 border border-hairline rounded-2xl px-5 py-4 flex justify-between items-center">
                <span className="text-[11px] uppercase tracking-widest text-muted-fg">Total dos Produtos</span>
                <span className="text-foreground font-bold text-[22px] tracking-tight">{brl(subtotalProdutos)}</span>
              </div>
            )}
          </div>
        )}


        {/* STEP 3 - Condições de Pagamento */}
        {step === 2 && (
          <div className="space-y-4">
            {/* Resumo do valor */}
            <div className="ios-card p-5">
              <div className="flex items-end justify-between flex-wrap gap-3">
                <div>
                  <p className="text-muted-foreground text-xs uppercase tracking-wider">Total da proposta</p>
                  <p className="text-3xl md:text-4xl font-bold text-foreground mt-1 tracking-tight">{brl(totalComDesconto)}</p>
                  {data.desconto_aplicado && Number(data.desconto_aplicado) > 0 && (
                    <p className="text-muted-foreground text-sm mt-1 line-through">{brl(subtotal)}</p>
                  )}
                </div>
                {data.installments.length > 0 && (
                  <div className="text-right">
                    <p className="text-muted-foreground text-xs uppercase tracking-wider">Parcelamento</p>
                    <p className="text-primary text-lg font-semibold mt-1">
                      {data.installments.length === 1 ? "À vista" : `${data.installments.length}x de ${brl(data.installments[0]?.valor || 0)}`}
                    </p>
                  </div>
                )}
              </div>
            </div>
            {/* Formas OFERECIDAS ao cliente.
                Aqui só se marca o que a empresa aceita. Quem escolhe — e quem
                define parcelas e entrada — é o cliente, no link da proposta. A
                escolha dele vira a condição confirmada no aceite e segue direto
                para o faturamento, sem redigitação. */}
            <div className="space-y-5">
              <div>
                <h2 className="text-[26px] font-bold leading-tight tracking-tight text-foreground md:text-[32px]">
                  O que oferecer ao cliente?
                </h2>
                <p className="mt-1 text-[13px] text-muted-fg">
                  Marque as formas aceitas. O cliente escolhe e monta as parcelas no link.
                </p>
              </div>

              {travaFormas && (
                <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-hairline bg-surface-1 px-4 py-3">
                  <p className="text-[13px] text-muted-fg">
                    O cliente já escolheu <span className="font-semibold text-foreground">{rotuloForma(formaDoCliente)}</span> no link. As outras formas ficam travadas.
                  </p>
                  <button type="button" onClick={() => setDestravarFormas(true)}
                    className="ios-tap rounded-lg border border-hairline px-3 py-1.5 text-[12px] font-semibold text-foreground">
                    Ele pediu para mudar
                  </button>
                </div>
              )}

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                {FORMAS_PAGAMENTO.map(f => {
                  const marcada = data.formas_oferecidas.includes(f.id)
                  const travada = travaFormas && f.id !== formaDoCliente
                  return (
                    <button key={f.id} type="button" disabled={travada}
                      onClick={() => setData(d => ({
                        ...d,
                        formas_oferecidas: marcada
                          ? d.formas_oferecidas.filter(x => x !== f.id)
                          : [...d.formas_oferecidas, f.id],
                      }))}
                      className={`ios-tap relative flex flex-col items-start gap-3 rounded-2xl border p-4 text-left ${
                        marcada ? "border-ios-blue bg-ios-blue/[0.08]" : "border-hairline bg-surface-1 hover:border-hairline/80"
                      } ${travada ? "cursor-not-allowed opacity-40" : ""}`}>
                      <div className="flex w-full items-center justify-between">
                        <f.Icon className={`h-5 w-5 ${marcada ? "text-ios-blue" : "text-muted-fg"}`} strokeWidth={1.5} />
                        <span className={`flex h-[18px] w-[18px] items-center justify-center rounded-md border-2 transition-colors ${marcada ? "border-ios-blue bg-ios-blue" : "border-hairline"}`}>
                          {marcada && <Check className="h-3 w-3 text-white" strokeWidth={3} />}
                        </span>
                      </div>
                      <div>
                        <span className="block text-[14px] font-semibold leading-tight text-foreground">{f.label}</span>
                        <span className="mt-0.5 block text-[12px] text-muted-fg">{f.desc}</span>
                      </div>
                    </button>
                  )
                })}
              </div>

              {data.formas_oferecidas.length === 0 && (
                <p className="text-[13px] text-ios-red">
                  Marque ao menos uma forma, sem nenhuma, o cliente não tem como aceitar.
                </p>
              )}


            </div>


            {/* Observações */}
            <div className="space-y-5">
              <div className="space-y-2.5">
                <Label className="text-[11px] uppercase tracking-[0.15em] text-muted-fg font-medium">Observações &amp; condições</Label>
                <Textarea value={data.observacoes} onChange={e => update("observacoes", e.target.value)}
                  rows={3} placeholder="Ex: Proposta válida por 30 dias. Instalação inclui mão de obra e deslocamento..." />
              </div>
            </div>

            {/* Personalização Avançada */}
            <div className="ios-card overflow-hidden">
              <button type="button" onClick={() => setMostrarAjuste(v => !v)}
                className="flex items-center justify-between w-full px-5 py-3.5 text-left hover:bg-muted/30 transition-colors">
                <div className="flex items-center gap-2.5">
                  <Settings2 className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
                  <span className="text-sm font-medium text-foreground">Personalização Avançada</span>
                  {(data.desconto_aplicado && Number(data.desconto_aplicado) > 0) && (
                    <span className="text-[11px] bg-green-500/10 text-green-600 dark:text-green-400 px-2 py-0.5 rounded-full font-medium">
                      -{pct(Number(data.desconto_aplicado) || 0, 2)} desconto
                    </span>
                  )}
                </div>
                <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform duration-200 ${mostrarAjuste ? "rotate-180" : ""}`} />
              </button>

              {mostrarAjuste && (
                <div className="px-5 pb-5 space-y-5 border-t border-hairline/50 pt-5">

                  {/* Serviços */}
                  <div className="space-y-3">
                    <Label className="text-muted-foreground text-xs uppercase tracking-wide">Serviços incluídos</Label>

                    {/* Instalação */}
                    <div className="space-y-2">
                      <div className="flex items-center gap-3">
                        <Switch checked={data.instalacao_ativo} onCheckedChange={v => update("instalacao_ativo", v)} />
                        <span className="text-sm text-foreground">Instalação e Configuração</span>
                        {custoInstalacao > 0 && <span className="text-xs text-green-600 dark:text-green-400 ml-auto font-medium">{brl(custoInstalacao)}</span>}
                      </div>
                      {data.instalacao_ativo && (
                        <div className="ml-11 flex items-center gap-2">
                          <span className="text-[13px] text-muted-foreground">R$</span>
                          <CampoValor
                            value={data.instalacao_tipo === "percentual"
                              ? (calcCusto(data.instalacao_tipo, data.instalacao_valor, subtotalProdutos) || 0).toFixed(2)
                              : data.instalacao_valor}
                            onChange={v => { update("instalacao_tipo", "fixo"); update("instalacao_valor", v) }}
                            className="h-7 w-24 border-0 bg-transparent px-0 text-right text-[15px] font-semibold tabular-nums shadow-none focus-visible:ring-0"
                            placeholder="0,00" />
                        </div>
                      )}
                    </div>

                    {/* Administração */}
                    <div className="space-y-2">
                      <div className="flex items-center gap-3">
                        <Switch checked={data.admin_ativo} onCheckedChange={v => update("admin_ativo", v)} />
                        <span className="text-sm text-foreground">Administração de Obra</span>
                        {custoAdmin > 0 && <span className="text-xs text-green-600 dark:text-green-400 ml-auto font-medium">{brl(custoAdmin)}</span>}
                      </div>
                      {data.admin_ativo && (
                        <div className="ml-11 flex items-center gap-2">
                          <span className="text-[13px] text-muted-foreground">R$</span>
                          <CampoValor
                            value={data.admin_tipo === "percentual"
                              ? (calcCusto(data.admin_tipo, data.admin_valor, subtotalProdutos) || 0).toFixed(2)
                              : data.admin_valor}
                            onChange={v => { update("admin_tipo", "fixo"); update("admin_valor", v) }}
                            className="h-7 w-24 border-0 bg-transparent px-0 text-right text-[15px] font-semibold tabular-nums shadow-none focus-visible:ring-0"
                            placeholder="0,00" />
                        </div>
                      )}
                    </div>

                    {/* A lista de serviços. O bloco SERVIÇOS no escopo mostra os
                        mesmos itens e também os edita; os dois lugares escrevem
                        nos mesmos campos, então o que muda em um aparece no
                        outro — e os dois lançam do mesmo jeito: um valor em
                        reais, escolhido.

                        Instalação e Administração ficam acima como switch: ou a
                        proposta tem, ou não tem. */}
                    {data.servicos.map(sv => (
                      <div key={sv.id} className="flex items-center gap-2 rounded-lg bg-muted/40 px-3 py-2">
                        <Input value={sv.nome} onChange={e => updateServico(sv.id, "nome", e.target.value)}
                          placeholder="Nome do serviço"
                          className="h-8 min-w-0 flex-1 border-0 bg-transparent p-0 text-sm focus-visible:ring-0" />
                        <span className="flex-shrink-0 text-[13px] text-muted-foreground">R$</span>
                        <CampoValor value={valorEmReais(sv)}
                          onChange={v => ajustarValorEmReais(sv.id, v)}
                          placeholder="0,00"
                          className="h-7 w-24 flex-shrink-0 border-0 bg-transparent px-0 text-right text-[15px] font-semibold tabular-nums shadow-none focus-visible:ring-0" />
                        <button type="button" onClick={() => removeServico(sv.id)}
                          className="flex-shrink-0 text-muted-foreground/50 hover:text-destructive">
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ))}

                    <button type="button" onClick={novoServico}
                      className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-dashed border-border py-2 text-xs font-medium text-muted-foreground transition-all hover:border-primary/60 hover:text-foreground">
                      <Plus className="h-3.5 w-3.5" /> Adicionar serviço
                    </button>

                    {(custoInstalacao + custoAdmin + custoServicos) > 0 && (
                      <div className="flex items-center justify-between text-sm bg-muted/50 rounded-lg px-3 py-2">
                        <span className="text-muted-foreground">Total de serviços</span>
                        <span className="font-medium text-foreground">{brl(custoInstalacao + custoAdmin + custoServicos)}</span>
                      </div>
                    )}

                    {/* Serviço que veio da categoria. Aparece AQUI e não no
                        documento do cliente: lá ele já está dentro do preço de
                        cada produto, e mostrá-lo de novo como linha faria a
                        soma não bater.

                        Aqui é o contrário — some de vista e ninguém lembra que
                        existe, até o cliente perguntar por que o produto custa
                        mais que na tabela. Por isso: em cinza, fora do total,
                        e dizendo de onde vem. */}
                    {servicosEmbutidos.length > 0 && (
                      <div className="space-y-2 rounded-lg border border-dashed border-border/60 px-3 py-2.5">
                        <p className="text-[11px] uppercase tracking-wide text-muted-foreground/70">
                          Já incluído no preço dos produtos
                        </p>
                        {servicosEmbutidos.map((s, i) => (
                          <div key={`${s.categoria}-${s.nome}-${i}`} className="flex items-baseline justify-between gap-3 text-sm">
                            <span className="min-w-0 flex-1 truncate text-muted-foreground">
                              {s.nome}
                              <span className="text-muted-foreground/60"> · {s.categoria} · {s.detalhe}</span>
                            </span>
                            <span className="flex-shrink-0 tabular-nums text-muted-foreground">{brl(s.valor)}</span>
                          </div>
                        ))}
                        <div className="flex items-baseline justify-between border-t border-border/40 pt-2 text-sm">
                          <span className="text-muted-foreground/70">Soma</span>
                          <span className="tabular-nums text-muted-foreground">{brl(totalEmbutido)}</span>
                        </div>
                        <p className="text-[11px] leading-snug text-muted-foreground/50">
                          Não soma no total: já está no preço de cada produto da categoria.
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Desconto: digita em % ou em reais, o que estiver na cabeça
                      de quem negocia. O valor guardado é sempre o percentual —
                      assim o desconto acompanha mudanças no escopo em vez de
                      virar um abatimento fixo que ninguém revisa. */}
                  <div className="space-y-2">
                    <Label className="text-muted-foreground text-xs uppercase tracking-wide">Desconto sobre o total</Label>
                    <div className="flex items-center gap-2">
                      <div className="inline-flex rounded-xl border border-border bg-muted p-0.5 text-[13px]">
                        {(["PCT", "VALOR"] as const).map(m => (
                          <button key={m} type="button" onClick={() => { setDescontoModo(m); setDescontoTxt(null) }}
                            className={`rounded-[10px] px-3 py-1.5 transition-colors ${
                              descontoModo === m ? "bg-background font-medium text-foreground shadow-sm" : "text-muted-foreground"
                            }`}>
                            {m === "PCT" ? "%" : "R$"}
                          </button>
                        ))}
                      </div>
                      <Input type="text" inputMode="decimal"
                        value={descontoTxt ?? (descontoNum > 0
                          ? (descontoModo === "PCT"
                              ? String(Number(descontoNum.toFixed(2)))
                              : (subtotal * descontoNum / 100).toFixed(2)
                            ).replace(".", ",")
                          : "")}
                        onChange={e => {
                          const txt = e.target.value.replace(/[^\d.,]/g, "")
                          setDescontoTxt(txt)
                          const v = numeroBR(txt)
                          // Reais → percentual sobre o subtotal atual, sem arredondar.
                          const pct = descontoModo === "PCT" ? v : (subtotal > 0 ? (v / subtotal) * 100 : 0)
                          update("desconto_aplicado", pct > 0 ? String(pct) : "")
                        }}
                        onBlur={() => setDescontoTxt(null)}
                        placeholder="0" className="h-10 w-32 text-sm text-center" />
                      {data.desconto_aplicado && Number(data.desconto_aplicado) > 0 && (
                        <button type="button" onClick={() => { setDescontoTxt(null); update("desconto_aplicado", "") }} className="text-muted-foreground/50 hover:text-destructive">
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                    {descontoNum > 0 && (
                      <p className="text-[12px] text-muted-fg">
                        {descontoModo === "PCT"
                          ? `Equivale a ${brl(subtotal * descontoNum / 100)}`
                          : `Equivale a ${descontoNum.toFixed(2).replace(".", ",")}%`}
                      </p>
                    )}
                    {data.desconto_aplicado && Number(data.desconto_aplicado) > 0 && (
                      <div className="flex items-center justify-between text-sm bg-green-500/[0.07] border border-green-500/20 rounded-lg px-3 py-2">
                        <span className="text-muted-foreground">Total com desconto</span>
                        <span className="font-bold text-green-600 dark:text-green-400">{brl(totalComDesconto)}</span>
                      </div>
                    )}
                    {/* Acima do teto: trava o avanço e abre pedido ao Admin */}
                    {descontoAcimaTeto && (
                      <div className="space-y-2 bg-ios-orange/[0.07] border border-ios-orange/25 rounded-xl px-3 py-2.5">
                        <p className="text-[13px] text-ios-orange">
                          Esse desconto passou do teto permitido. Precisa da aprovação do Admin para avançar.
                        </p>
                        {pedidoDesconto?.status === "PENDENTE" ? (
                          <p className="text-[13px] text-muted-fg">Pedido enviado, aguardando decisão do Admin.</p>
                        ) : pedidoDesconto?.status === "RECUSADO" ? (
                          <p className="text-[13px] text-ios-red">Pedido recusado. Reduza o desconto ou peça nova aprovação.</p>
                        ) : (
                          <div className="flex gap-2">
                            <Input value={justificativaDesconto} onChange={e => setJustificativaDesconto(e.target.value)}
                              placeholder="Justificativa (opcional)" className="h-9 text-sm flex-1" />
                            <Button size="sm" onClick={pedirAprovacaoDesconto} disabled={pedindoDesconto} className="h-9">
                              {pedindoDesconto ? "Enviando..." : "Pedir aprovação"}
                            </Button>
                          </div>
                        )}
                      </div>
                    )}
                    {pedidoDesconto?.status === "APROVADO" && (
                      <p className="text-[13px] text-ios-green">Desconto aprovado por {pedidoDesconto.decididoPorNome}.</p>
                    )}
                  </div>

                  {/* Garantia */}
                  <div className="space-y-2">
                    <Label className="text-muted-foreground text-xs uppercase tracking-wide">Garantia (dias)</Label>
                    <div className="flex items-center gap-2">
                      <Input type="number" min={0} max={3650} value={data.dias_garantia}
                        onChange={e => update("dias_garantia", e.target.value)}
                        placeholder="Ex.: 365" className="h-10 w-32 text-sm" />
                      {Number(data.dias_garantia) > 0 && (
                        <span className="text-xs text-muted-foreground">
                          ≈ {(Number(data.dias_garantia) / 30).toFixed(0)} meses · começa no check de instalação da obra
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Opções da proposta enviada ao cliente */}
                  <div className="space-y-3">
                    <Label className="text-muted-foreground text-xs uppercase tracking-wide">Opções da proposta</Label>
                    <div className="flex items-center justify-between gap-4 rounded-lg border border-border/50 bg-muted/40 px-3 py-2.5">
                      <div className="min-w-0">
                        <p className="text-sm text-foreground">Mostrar preço por item</p>
                        <p className="text-xs text-muted-foreground">
                          Desligado, o cliente vê o escopo e o total geral, sem preço linha a linha.
                        </p>
                      </div>
                      <Switch checked={data.exibir_valor_unitario}
                        onCheckedChange={v => update("exibir_valor_unitario", v)} />
                    </div>
                  </div>

                </div>
              )}
            </div>
          </div>
        )}

        {/* STEP 4 - Revisão */}
        {step === 3 && (
          <div className="space-y-4">
            {/* Valor total em destaque (estilo mockup) */}
            <div className="ios-card p-5">
              <p className="text-[11px] uppercase tracking-widest text-muted-fg">Valor total</p>
              <p className="text-[36px] font-bold text-foreground tracking-tight leading-none mt-1">{brl(totalComDesconto)}</p>
              {data.desconto_aplicado && Number(data.desconto_aplicado) > 0 && (
                <p className="text-[13px] text-muted-fg mt-1 line-through">{brl(subtotal)}</p>
              )}
              {data.installments.length > 0 && (
                <p className="text-[13px] text-muted-fg mt-2">
                  ou {data.installments.length}x de {brl(data.installments[0]?.valor || 0)}
                </p>
              )}
            </div>

            <div className="ios-card p-5 space-y-4">
              <h2 className="text-[15px] font-semibold text-foreground">Revisão Final</h2>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground text-xs">Cliente</p>
                  <p className="text-foreground font-medium">{data.client_name || "—"}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">Tipo de Projeto</p>
                  <p className="text-foreground">{data.project_type}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">Cidade</p>
                  <p className="text-foreground">{data.client_city || "—"}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">Expiração</p>
                  <p className="text-foreground">{data.data_expiracao ? new Date(data.data_expiracao).toLocaleDateString("pt-BR") : "—"}</p>
                </div>
              </div>
              {/* Revisão item a item, e não só o total do ambiente.

                  "Home Theater (3 itens) — R$ 137.697,26" é exatamente o que
                  esta tela existe para evitar: é a última parada antes de a
                  proposta ir ao cliente, e conferir um número agregado não
                  revela quantidade trocada, item repetido nem preço editado à
                  mão. Cada linha traz código, quantidade, unitário e total. */}
              <div className="border-t border-hairline pt-4">
                {/* Guardado não vai pro cliente e não soma no total — não faz
                    sentido reaparecer na conferência final também. Quem
                    revisa antes de enviar quer ver exatamente o que o
                    cliente vai receber, não o que foi posto de lado. */}
                {(() => { const ativos = data.environments.filter(e => (e.status ?? "ATIVO") === "ATIVO"); return (
                <>
                <p className="text-muted-foreground text-sm mb-3">Sistemas ({ativos.length})</p>
                {ativos.map(env => {
                  const totalEnv = env.items.reduce((s, i) => s + i.valor_unitario * i.quantidade, 0)
                  return (
                    <div key={env.id} className="mb-4">
                      <div className="mb-1.5 flex items-baseline justify-between gap-2">
                        <p className="text-foreground text-sm font-medium">
                          {env.nome} <span className="text-muted-foreground font-normal">({env.items.length} {env.items.length === 1 ? "item" : "itens"})</span>
                        </p>
                        <p className="text-sm font-medium tabular-nums text-foreground">{brl(totalEnv)}</p>
                      </div>

                      {env.items.length === 0 ? (
                        <p className="text-xs text-muted-foreground">Nenhum item neste sistema.</p>
                      ) : (
                        <div className="overflow-x-auto rounded-xl border border-hairline">
                          <table className="w-full text-xs">
                            <thead>
                              <tr className="border-b border-hairline text-[10px] uppercase tracking-wider text-muted-foreground">
                                <th className="px-2.5 py-1.5 text-left font-medium">Item</th>
                                <th className="px-2.5 py-1.5 text-center font-medium">Qtd</th>
                                <th className="px-2.5 py-1.5 text-right font-medium">Unitário</th>
                                <th className="px-2.5 py-1.5 text-right font-medium">Total</th>
                              </tr>
                            </thead>
                            <tbody>
                              {env.items.map(item => {
                                const cat = products.find(pr => pr.id === item.sourceId)
                                const codigo = item.type === "kit" ? "Kit" : (cat?.sku ?? item.avulso_marca ?? "")
                                return (
                                  <tr key={item.id} className="border-b border-hairline/60 last:border-0 align-top">
                                    <td className="px-2.5 py-1.5">
                                      <span className="block text-foreground">{item.nome}</span>
                                      <span className="block text-[10px] text-muted-foreground">
                                        {codigo}
                                        {item.avulso && " · fora do catálogo"}
                                        {item.is_aditivo && " · aditivo"}
                                      </span>
                                    </td>
                                    <td className="px-2.5 py-1.5 text-center tabular-nums text-foreground">{item.quantidade}</td>
                                    <td className="px-2.5 py-1.5 text-right tabular-nums text-muted-foreground">{brl(item.valor_unitario)}</td>
                                    <td className="px-2.5 py-1.5 text-right tabular-nums text-foreground">
                                      {brl(item.valor_unitario * item.quantidade)}
                                    </td>
                                  </tr>
                                )
                              })}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  )
                })}

                {/* Projeto e instalação como BLOCO, do mesmo jeito de um
                    sistema: é assim que ele sai para o cliente, com nome e
                    valor à frente, e é assim que ele é escolhido lá. */}
                {servicosDaProposta.length > 0 && (
                  <div className="mb-4">
                    <div className="mb-1.5 flex items-baseline justify-between gap-2">
                      <p className="text-foreground text-sm font-medium">
                        Serviços{" "}
                        <span className="text-muted-foreground font-normal">
                          ({servicosDaProposta.length} {servicosDaProposta.length === 1 ? "item" : "itens"})
                        </span>
                      </p>
                      <p className="text-sm font-medium tabular-nums text-foreground">
                        {brl(custoInstalacao + custoAdmin + custoServicos)}
                      </p>
                    </div>
                    <div className="overflow-x-auto rounded-xl border border-hairline">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="border-b border-hairline text-[10px] uppercase tracking-wider text-muted-foreground">
                            <th className="px-2.5 py-1.5 text-left font-medium">Serviço</th>
                            <th className="px-2.5 py-1.5 text-right font-medium">Total</th>
                          </tr>
                        </thead>
                        <tbody>
                          {servicosDaProposta.map(sv => (
                            <tr key={sv.id} className="border-b border-hairline/60 last:border-0 align-top">
                              <td className="px-2.5 py-1.5">
                                <span className="block text-foreground">{sv.nome?.trim() || "Serviço"}</span>
                                <span className="block text-[10px] text-muted-foreground">
                                  {sv.tipo === "percentual"
                                    ? `${sv.valor || 0}% de ${brl(baseDoServico(sv))}`
                                    : "valor fixo"}
                                </span>
                              </td>
                              <td className="px-2.5 py-1.5 text-right tabular-nums text-foreground">
                                {brl(valorDeUmServico(sv))}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
                </>
                ) })()}
              </div>
              <div className="border-t border-hairline pt-4 space-y-1.5 text-sm">
                <div className="flex justify-between text-muted-foreground">
                  <span>Produtos</span><span>{brl(subtotalProdutos)}</span>
                </div>
                {/* Instalação, administração e serviços não voltam aqui um a
                    um: eles são o bloco de projeto e instalação acima, e o
                    rodapé fecha com ele inteiro. */}
                {(custoInstalacao + custoAdmin + custoServicos) > 0 && (
                  <div className="flex justify-between text-muted-foreground">
                    <span>Serviços</span>
                    <span>{brl(custoInstalacao + custoAdmin + custoServicos)}</span>
                  </div>
                )}
                {data.desconto_aplicado && Number(data.desconto_aplicado) > 0 && (
                  <div className="flex justify-between text-ios-green">
                    <span>Desconto ({pct(Number(data.desconto_aplicado) || 0, 2)})</span><span>-{brl(subtotal - totalComDesconto)}</span>
                  </div>
                )}
                <div className="flex justify-between text-foreground font-bold text-base pt-2 border-t border-hairline">
                  <span>Total</span><span>{brl(totalComDesconto)}</span>
                </div>
              </div>
            </div>

            {/* Extra Pages */}
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 px-1">
                <div>
                  <h3 className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-fg">Páginas extras</h3>
                  <p className="mt-0.5 text-xs text-muted-fg">Escopo detalhado, cláusulas ou apresentação, no fim da proposta.</p>
                </div>
                <div className="flex items-center gap-2">
                  {pageTemplates.length > 0 && (
                    <select value="" onChange={e => { if (e.target.value) { inserirModeloPagina(e.target.value); e.target.value = "" } }}
                      className="h-9 rounded-full bg-surface-1 px-3.5 text-sm text-foreground outline-none">
                      <option value="">Usar modelo</option>
                      {pageTemplates.map(t => <option key={t.id} value={t.id}>{t.nome}</option>)}
                    </select>
                  )}
                  <button type="button" onClick={addExtraPage}
                    className="flex h-9 items-center gap-1.5 rounded-full bg-foreground px-4 text-sm font-medium text-background transition-opacity hover:opacity-90 active:scale-[0.98]">
                    <Plus className="h-3.5 w-3.5" /> Nova página
                  </button>
                </div>
              </div>

              {data.extraPages.length === 0 ? (
                <button type="button" onClick={addExtraPage}
                  className="w-full rounded-2xl bg-surface-1 px-5 py-8 text-center transition-colors hover:bg-muted">
                  <FileIcon className="mx-auto mb-2 h-5 w-5 text-muted-fg" strokeWidth={1.5} />
                  <p className="text-sm font-medium text-foreground">Nenhuma página extra</p>
                  <p className="mt-0.5 text-xs text-muted-fg">Toque para escrever a primeira.</p>
                </button>
              ) : data.extraPages.map(page => (
                <div key={page.id} className="overflow-hidden rounded-2xl bg-surface-1">
                  <div className="flex items-center gap-1 px-3 py-2.5">
                    <input value={page.titulo}
                      onChange={e => updateExtraPage(page.id, "titulo", e.target.value)}
                      placeholder="Título da página"
                      className="min-w-0 flex-1 bg-transparent px-1.5 text-[15px] font-semibold text-foreground outline-none placeholder:font-normal placeholder:text-muted-fg" />
                    <button type="button" onClick={() => salvarComoModelo(page)}
                      title="Salvar esta página como modelo reutilizável"
                      className="h-8 shrink-0 rounded-full px-3 text-xs font-medium text-muted-fg transition-colors hover:bg-muted hover:text-foreground">
                      Salvar modelo
                    </button>
                    <button type="button" onClick={() => removeExtraPage(page.id)}
                      className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-muted-fg transition-colors hover:bg-muted hover:text-ios-red">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>

                  <div className="px-3 pb-3">
                    <TiptapEditor
                      value={page.conteudo_markdown}
                      onChange={v => updateExtraPage(page.id, "conteudo_markdown", v)}
                    />
                  </div>

                  {/* Anexos da página */}
                  <div className="border-t border-hairline px-3 py-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="pl-1.5 text-xs text-muted-fg">
                        {(page.anexos ?? []).length > 0
                          ? `${(page.anexos ?? []).length} anexo${(page.anexos ?? []).length > 1 ? "s" : ""}`
                          : "Sem anexos"}
                      </span>
                      <label className={`flex h-8 cursor-pointer items-center gap-1.5 rounded-full px-3.5 text-xs font-medium transition-colors ${
                        uploadingPagina === page.id ? "pointer-events-none bg-muted text-muted-fg" : "bg-muted text-foreground hover:bg-muted/70"
                      }`}>
                        <Plus className="h-3.5 w-3.5" />
                        {uploadingPagina === page.id ? "Enviando" : "Anexar arquivo"}
                        <input type="file" className="hidden" disabled={uploadingPagina === page.id}
                          onChange={e => { const f = e.target.files?.[0]; if (f) anexarNaPagina(page.id, f); e.target.value = "" }} />
                      </label>
                    </div>
                    {erroAnexo && (
                      <p className="mt-2 pl-1.5 text-xs text-ios-red">{erroAnexo}</p>
                    )}
                    {(page.anexos ?? []).length > 0 && (
                      <div className="mt-2 grid gap-1.5 sm:grid-cols-2">
                        {(page.anexos ?? []).map((a, i) => (
                          <div key={i} className="flex items-center gap-2 rounded-xl bg-muted px-3 py-2 text-sm">
                            <span className="font-mono text-[10px] uppercase text-muted-fg">{a.ext}</span>
                            <a href={a.url} target="_blank" rel="noreferrer" className="min-w-0 flex-1 truncate text-foreground hover:text-primary">{a.nome}</a>
                            <button type="button" onClick={() => removerAnexoPagina(page.id, i)} className="shrink-0 text-muted-fg hover:text-ios-red">
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Navigation. No mobile fica fixo, ancorado logo acima da barra pill
            de baixo (mesmo offset dela, ~76px + safe-area) — não empurra o
            layout com padding gigante (deixava um vão vazio feio quando o
            passo tinha pouco conteúdo). No desktop volta ao fluxo normal,
            sem barra pill pra desviar. */}
        <div className="hidden md:flex items-center gap-2 justify-between mt-8 pt-4 border-t border-hairline">
          <Button variant="ghost" onClick={() => setStep(s => Math.max(0, s - 1))}
            disabled={step === 0}
            className="h-10 px-3 text-muted-fg hover:text-foreground disabled:opacity-30">
            <ChevronRight className="w-4 h-4 mr-1 rotate-180" /> Voltar
          </Button>
          {step < STEPS.length - 1 ? (
            <Button onClick={() => (step === 0 ? avancarDaIdentificacao() : setStep(s => s + 1))}
              disabled={step === 2 && !descontoLiberado}
              title={step === 2 && !descontoLiberado ? `Desconto acima do teto permitido, aguarda aprovação do Admin` : undefined}
              className="h-10 px-6 rounded-xl">
              Próximo <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          ) : (
            <Button onClick={handleSave} disabled={saving || !descontoLiberado}
              className="h-10 px-6 rounded-xl bg-gradient-to-r from-ios-blue to-ios-purple text-white font-semibold border-0">
              {saving ? "Salvando..." : "Salvar proposta"}
            </Button>
          )}
        </div>
      </div>

      {/* Mesmo rodapé, versão mobile: fixo, colado acima da barra pill. */}
      <div className="md:hidden fixed inset-x-0 z-30 flex items-center gap-2 justify-between border-t border-hairline bg-background/90 px-4 py-3 backdrop-blur-xl"
        style={{ bottom: "calc(max(env(safe-area-inset-bottom), 1rem) + 76px)" }}>
        <Button variant="ghost" onClick={() => setStep(s => Math.max(0, s - 1))}
          disabled={step === 0}
          className="h-10 px-3 text-muted-fg hover:text-foreground disabled:opacity-30">
          <ChevronRight className="w-4 h-4 mr-1 rotate-180" /> Voltar
        </Button>
        {step < STEPS.length - 1 ? (
          <Button onClick={() => (step === 0 ? avancarDaIdentificacao() : setStep(s => s + 1))}
            disabled={step === 2 && !descontoLiberado}
            title={step === 2 && !descontoLiberado ? `Desconto acima do teto permitido, aguarda aprovação do Admin` : undefined}
            className="h-10 px-6 rounded-xl">
            Próximo <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        ) : (
          <Button onClick={handleSave} disabled={saving || !descontoLiberado}
            className="h-10 px-6 rounded-xl bg-gradient-to-r from-ios-blue to-ios-purple text-white font-semibold border-0">
            {saving ? "Salvando..." : "Salvar proposta"}
          </Button>
        )}
      </div>
      {/* Compensa a altura do rodapé fixo, senão o fim do conteúdo fica
          escondido atrás dele no mobile. */}
      <div className="md:hidden" style={{ height: "calc(max(env(safe-area-inset-bottom), 1rem) + 76px + 68px)" }} />

      {/* Sheet: Add Item */}
      <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
        <SheetContent className="w-[420px] sm:max-w-[420px] overflow-y-auto p-0 bg-card" style={{ scrollbarWidth: "none" }}>
          <div className="sticky top-0 z-10 bg-card/95 backdrop-blur-xl border-b border-border/40 px-4 py-3">
            <SheetHeader>
              <div className="flex items-center justify-between gap-2">
                {/* Voltar: se já escolheu categoria/item, volta pro grid; senão fecha */}
                {(itemCatFilter || selectedItem) ? (
                  <button type="button"
                    onClick={() => { setSelectedItem(null); setItemCatFilter(""); setItemSearch("") }}
                    className="flex items-center gap-1 text-ios-blue text-[15px] active:opacity-70">
                    <ChevronRight className="w-4 h-4 rotate-180" /> Categorias
                  </button>
                ) : (
                  <span className="w-16" />
                )}
                <SheetTitle className="text-[16px] font-semibold flex-1 text-center">Adicionar Item</SheetTitle>
                <button type="button" onClick={() => setSheetOpen(false)}
                  className="w-8 h-8 rounded-full bg-muted/60 flex items-center justify-center text-muted-foreground active:scale-95">
                  <X className="w-4 h-4" />
                </button>
              </div>
            </SheetHeader>
          </div>
          <div className="px-6 py-5 space-y-4">
            {/* PASSO 1, Escolha a categoria */}
            {!selectedItem && !itemCatFilter ? (
              <div className="space-y-4">
                {/* Busca antes das categorias.

                    Categoria é um bom atalho para quem está montando o escopo
                    do zero, mas atrapalha quem já sabe o que quer: obrigava a
                    lembrar em qual categoria o produto foi cadastrado — e
                    produto sem categoria não aparecia em lugar nenhum. */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    value={itemSearch}
                    onChange={e => setItemSearch(e.target.value)}
                    placeholder="Buscar por nome ou SKU em todo o catálogo"
                    className="pl-9 h-11"
                    autoFocus
                  />
                </div>

                {/* Item que ainda não existe no catálogo.

                    Três campos, e só. Marca, categoria e unidade ficam para o
                    cadastro no faturamento: na visita o que importa é não
                    interromper a conversa, e o cliente não espera enquanto
                    alguém preenche ficha de produto. */}
                {avulsoAberto && (
                  <div className="rounded-2xl border border-border bg-background p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-foreground text-[14px] font-medium">Item fora do catálogo</p>
                      <button type="button" onClick={() => setAvulsoAberto(false)}
                        className="text-muted-foreground hover:text-foreground">
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <Input value={avulso.nome} autoFocus
                      onChange={e => setAvulso(a => ({ ...a, nome: e.target.value }))}
                      placeholder="O que é o item" className="h-10" />

                    <div className="grid grid-cols-2 gap-2.5">
                      <Input value={avulso.quantidade} inputMode="numeric"
                        onChange={e => setAvulso(a => ({ ...a, quantidade: e.target.value.replace(/\D/g, "") }))}
                        placeholder="Quantidade" className="h-10" />
                      <Input value={avulso.valor} inputMode="decimal"
                        onChange={e => setAvulso(a => ({ ...a, valor: e.target.value.replace(/[^\d.,]/g, "") }))}
                        placeholder="Valor unitário R$" className="h-10" />
                    </div>

                    <Button type="button" className="w-full h-10"
                      disabled={!avulso.nome.trim() || !(parseFloat(avulso.valor.replace(",", ".")) > 0)}
                      onClick={adicionarAvulso}>
                      Adicionar ao sistema
                    </Button>
                  </div>
                )}

                {itemSearch.trim().length >= 2 ? (
                  <div className="space-y-1.5">
                    <p className="text-muted-foreground text-[12px]">
                      {buscaGlobal.length
                        ? `${buscaGlobal.length} resultado(s) em todo o catálogo`
                        : "Nada encontrado com esse termo."}
                    </p>

                    {/* O caminho de quem procurou e não achou nasce aqui, na
                        busca, e não numa lista à parte: o nome já foi digitado,
                        e é ele que vai para o campo do item. */}
                    <button type="button"
                      onClick={() => {
                        setAvulso(a => ({ ...a, nome: itemSearch.trim() }))
                        setAvulsoAberto(true)
                      }}
                      className="w-full flex items-center gap-2 p-2.5 rounded-xl border border-dashed border-border text-left text-[13px] text-muted-foreground hover:border-foreground/30 hover:text-foreground transition-colors">
                      <Plus className="w-3.5 h-3.5" /> Adicionar item
                    </button>
                    {buscaGlobal.map(({ type, source }) => (
                      <button
                        key={`${type}-${source.id}`}
                        type="button"
                        onClick={() => selectCatalogItem(type, source)}
                        className="w-full flex items-center gap-3 p-2.5 rounded-xl bg-background border border-border/50 hover:border-foreground/20 text-left transition-all"
                      >
                        <span className="w-9 h-9 rounded-lg overflow-hidden img-produto flex items-center justify-center flex-shrink-0">
                          {type === "product" && (source as Product).imagem_url ? (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img src={proxiedImg((source as Product).imagem_url!)} alt=""
                              className="w-full h-full object-cover" />
                          ) : (
                            <Package className="w-4 h-4 text-muted-foreground" />
                          )}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block text-foreground text-[13px] leading-tight truncate">
                            {source.nome}
                          </span>
                          <span className="block text-muted-foreground text-[11px]">
                            {type === "kit" ? "Kit" : (source as Product).sku}
                          </span>
                        </span>
                      </button>
                    ))}
                  </div>
                ) : (
                  <>
                <div className="grid grid-cols-2 gap-2.5">
                  {categories.map(cat => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => {
                        setItemCatFilter(cat.id); setItemSearch("")
                        /* O serviço cadastrado na categoria NÃO vira linha aqui.
                           Ele entra direto no preço de cada produto daquela
                           categoria, em comServicoDaCategoria(): porcentagem
                           multiplica, valor fixo soma. Virar linha também
                           cobraria o mesmo serviço duas vezes. */
                      }}
                      className="flex flex-col items-start gap-2.5 p-3.5 rounded-2xl bg-background border border-border/50 hover:border-foreground/20 hover:bg-muted/20 text-left transition-all min-h-[76px]"
                    >
                      <div className="w-9 h-9 rounded-xl overflow-hidden bg-muted flex items-center justify-center flex-shrink-0">
                        {cat.imagem_url ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={proxiedImg(cat.imagem_url)} alt={cat.nome} className="w-full h-full object-cover" />
                        ) : (
                          <Tag className="w-4 h-4 text-muted-foreground" />
                        )}
                      </div>
                      <span className="text-foreground text-[13px] font-medium leading-tight">{cat.nome}</span>
                    </button>
                  ))}
                </div>
                  </>
                )}
              </div>

            ) : !selectedItem ? (
              /* PASSO 2 — Busca dentro da categoria */
              <div className="space-y-4">
                {/* Cabeçalho da categoria selecionada */}
                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => { setItemCatFilter(""); setItemSearch("") }}
                    className="w-7 h-7 rounded-lg bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
                  >
                    <ChevronRight className="w-4 h-4 rotate-180" />
                  </button>
                  <span className="text-foreground font-semibold text-[15px]">
                    {itemCatFilter === "__todos__"
                      ? "Todos os produtos"
                      : (categories.find(c => c.id === itemCatFilter)?.nome ?? "Categoria")}
                  </span>
                </div>

                {/* Busca */}
                <div className="relative">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50 pointer-events-none" strokeWidth={2} />
                  <Input
                    ref={itemSearchRef}
                    autoFocus
                    value={itemSearch}
                    onChange={e => setItemSearch(e.target.value)}
                    className="pl-10 h-11 bg-muted/60 border-border/60 text-foreground rounded-xl placeholder:text-muted-foreground/40"
                    placeholder="Buscar produto ou SKU..."
                  />
                </div>

                {/* Resultados */}
                <div className="space-y-2 max-h-[58vh] overflow-y-auto" style={{ scrollbarWidth: "none" }}>
                  {catalogFiltered.length === 0 ? (
                    <div className="text-center py-10">
                      <Package className="w-8 h-8 text-muted-foreground/20 mx-auto mb-2" />
                      <p className="text-muted-foreground text-sm">Nenhum produto encontrado</p>
                      <p className="text-muted-foreground/60 text-xs mt-1">Tente buscar pelo nome ou SKU</p>
                    </div>
                  ) : catalogFiltered.map((result, i) => (
                    <div key={i} className="flex items-center gap-3.5 p-3.5 rounded-2xl border border-border/50 bg-background hover:border-border hover:bg-muted/30 transition-all">
                      {/* Thumbnail */}
                      {result.type === "product" && (result.source as Product).imagem_url ? (
                        <>
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img src={proxiedImg((result.source as Product).imagem_url)} alt={result.source.nome}
                            className="w-12 h-12 rounded-xl object-cover flex-shrink-0 border border-border/50"
                            onError={e => { const el = e.target as HTMLImageElement; el.style.display="none"; el.nextElementSibling?.classList.remove("hidden") }} />
                          <div className="w-12 h-12 rounded-xl bg-muted flex-shrink-0 flex items-center justify-center border border-border/50 hidden">
                            <Package className="w-5 h-5 text-muted-foreground/30" />
                          </div>
                        </>
                      ) : (
                        <div className="w-12 h-12 rounded-xl bg-muted flex-shrink-0 flex items-center justify-center border border-border/50">
                          <Package className="w-5 h-5 text-muted-foreground/30" />
                        </div>
                      )}
                      {/* Info */}
                      <div className="flex-1 min-w-0 cursor-pointer" onClick={() => selectCatalogItem(result.type, result.source)}>
                        <p className="text-foreground text-[13px] font-medium truncate leading-tight">{result.source.nome}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-muted-foreground/50 text-[11px]">
                            {result.type === "kit" ? "Kit" : (result.source as Product).sku}
                          </span>
                          {result.type === "product" && (
                            <span className="text-green-500 text-[11px] font-medium">
                              {brl(Number((result.source as Product).preco_venda))}
                            </span>
                          )}
                        </div>
                      </div>
                      {/* Add button */}
                      <button type="button"
                        onClick={() => {
                          if (result.type === "product") setItemMarkup(String((result.source as Product).markup_padrao || 0))
                          setSelectedItem({ type: result.type, source: result.source })
                        }}
                        className="w-8 h-8 rounded-full bg-foreground text-background flex items-center justify-center flex-shrink-0 hover:opacity-75 transition-opacity">
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-foreground font-medium">{selectedItem.source.nome}</p>
                    <p className="text-muted-foreground text-xs capitalize">{selectedItem.type}</p>
                  </div>
                  <button onClick={() => setSelectedItem(null)} className="text-muted-foreground/60 hover:text-foreground">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-1">
                  <Label className="text-foreground/80">Quantidade</Label>
                  <Input type="number" min="1" value={itemQty === 0 ? "" : itemQty}
                    onChange={e => {
                      const v = e.target.value
                      setItemQty(v === "" ? 0 : Math.max(0, parseInt(v) || 0))
                    }}
                    onBlur={() => setItemQty(q => q < 1 ? 1 : q)}
                    className="bg-muted border-border text-foreground" />
                </div>

                {selectedItem.type === "product" && !modoCliente && (
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <Switch checked={itemUseMarkup} onCheckedChange={setItemUseMarkup} />
                      <Label className="text-foreground/80 text-sm">{itemUseMarkup ? "Markup %" : "Desconto R$"}</Label>
                    </div>
                    {itemUseMarkup ? (
                      <div className="space-y-1">
                        <Label className="text-muted-foreground text-xs">Markup Específico (%)</Label>
                        <Input type="number" step="0.1" value={itemMarkup} onChange={e => setItemMarkup(e.target.value)}
                          className="bg-muted border-border text-foreground" placeholder="0" />
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <Label className="text-muted-foreground text-xs">Desconto (R$)</Label>
                        <Input type="number" step="0.01" value={itemDesconto} onChange={e => setItemDesconto(e.target.value)}
                          className="bg-muted border-border text-foreground" placeholder="0,00" />
                      </div>
                    )}
                  </div>
                )}
                {selectedItem.type === "product" && modoCliente && (
                  <p className="text-emerald-400/70 text-xs">Preço com markup padrão do catálogo aplicado.</p>
                )}

                <div className="bg-muted rounded-lg p-3 text-sm">
                  <div className="flex justify-between text-muted-foreground">
                    <span>Valor unitário</span>
                    <span>
                      {(() => {
                        if (selectedItem.type === "product") {
                          const p = selectedItem.source as Product
                          return itemUseMarkup
                            ? brl(Number(p.preco_custo) * (1 + (parseFloat(itemMarkup) || 0) / 100))
                            : brl(Number(p.preco_venda) - (parseFloat(itemDesconto) || 0))
                        }
                        const k = selectedItem.source as Kit
                        return brl(k.items.reduce((s, i) => s + Number(i.product.preco_custo) * i.quantidade, 0))
                      })()}
                    </span>
                  </div>
                  <div className="flex justify-between text-foreground font-medium mt-1">
                    <span>Total ({itemQty}x)</span>
                    <span className="text-green-400">
                      {(() => {
                        let unit = 0
                        if (selectedItem.type === "product") {
                          const p = selectedItem.source as Product
                          unit = itemUseMarkup
                            ? Number(p.preco_custo) * (1 + (parseFloat(itemMarkup) || 0) / 100)
                            : Number(p.preco_venda) - (parseFloat(itemDesconto) || 0)
                        } else {
                          const k = selectedItem.source as Kit
                          unit = k.items.reduce((s, i) => s + Number(i.product.preco_custo) * i.quantidade, 0)
                        }
                        return brl(unit * itemQty)
                      })()}
                    </span>
                  </div>
                </div>

                <Button onClick={addItemToEnv} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                  Adicionar ao Orçamento
                </Button>
              </div>
            )}
          </div>
        </SheetContent>
      </Sheet>
    </div>
  )
}

// ---- Linha de item com expansão de kit ----
function KitItemRow({ indice, item, kitSource, totalVenda, totalCusto, margem, showCusto, podeBaixarPreco, onRemove, onQtd, onPreco }: {
  indice: number
  item: ProposalItem
  kitSource: Kit | null
  totalVenda: number
  totalCusto: number
  margem: number
  showCusto: boolean
  podeBaixarPreco: boolean
  onRemove: () => void
  onQtd: (n: number) => void
  onPreco: (v: number) => void
}) {
  const [expanded, setExpanded] = useState(false)

  /* Preço editado por DUPLO clique.
     Clique simples abriria o campo sem querer o tempo todo: a linha inteira é
     alvo de clique para expandir kit e a pessoa passa o mouse por ali para ler.
     Duplo clique é gesto deliberado.

     `rascunho` guarda o texto enquanto se digita. Sem ele, cada tecla passaria
     pela trava do piso: apagar "1250" para escrever "1400" viraria "1", que é
     menor que o piso, e o campo saltaria de volta no meio da digitação. O valor
     só é conferido ao sair do campo. */
  const [rascunho, setRascunho] = useState<string | null>(null)
  const piso = item.valor_piso ?? 0
  const noPiso = !podeBaixarPreco && item.valor_unitario <= piso + 0.005

  function abrir() {
    setRascunho(String(item.valor_unitario * item.quantidade))
  }

  function fechar(salvar: boolean) {
    if (salvar && rascunho !== null) {
      const n = parseFloat(rascunho.replace(/\./g, "").replace(",", "."))
      // O campo é o TOTAL da linha; o que é guardado é o unitário. Dividir
      // aqui evita que trocar a quantidade depois desfaça o valor combinado.
      if (!Number.isNaN(n)) onPreco(n / Math.max(1, item.quantidade))
    }
    setRascunho(null)
  }
  const hasKitItems = item.type === "kit" && kitSource && kitSource.items.length > 0

  return (
    <div className="space-y-1 px-4 py-3 md:px-5">
      <div className="flex items-center gap-3">
        <span className="w-5 flex-shrink-0 font-mono text-[11px] text-muted-fg/60">
          {String(indice).padStart(2, "0")}
        </span>
        <div className="relative h-11 w-11 flex-shrink-0">
          <div className={`flex h-11 w-11 items-center justify-center overflow-hidden rounded-xl ${item.imagem_url ? "bg-white" : "img-produto"}`}>
            {item.imagem_url ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={proxiedImg(item.imagem_url)} alt={item.nome} className="h-full w-full object-cover"
                onError={e => { (e.target as HTMLImageElement).style.display = "none" }} />
            ) : (
              <Package className="h-4 w-4 text-muted-foreground/30" />
            )}
          </div>
          {item.quantidade > 1 && (
            <span aria-hidden
              className="absolute -right-1.5 -top-1.5 flex h-[18px] min-w-[18px] items-center justify-center rounded-full border border-hairline bg-surface-3 px-1 text-[10px] font-semibold text-foreground">
              ×{item.quantidade}
            </span>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            {hasKitItems && (
              <button onClick={() => setExpanded(v => !v)} className="flex-shrink-0 text-muted-foreground/60 hover:text-foreground/80 transition-colors">
                <ChevronDown className={`w-3.5 h-3.5 transition-transform ${expanded ? "rotate-180" : ""}`} />
              </button>
            )}
            <p className="truncate text-[14px] font-medium leading-tight text-foreground">{item.nome}</p>
          </div>
          <p className="ml-5 mt-0.5 text-[12px] text-muted-fg">
            {item.type === "kit" ? "Kit" : "Produto"} • {brl(item.valor_unitario)} / un
          </p>
          {showCusto && (
            <p className="text-amber-400 text-xs ml-5 mt-0.5">
              Custo: {brl(item.preco_custo)} / un · Margem: {margem.toFixed(1)}%
            </p>
          )}
        </div>
        {/* Quantidade editável direto no escopo, é aqui que se monta a
            proposta. Antes era só leitura e obrigava a remover e recadastrar
            o item para trocar um número. */}
        <input
          type="number" min={1} step={1}
          value={item.quantidade}
          onChange={e => onQtd(Math.max(1, Number(e.target.value) || 1))}
          onFocus={e => e.currentTarget.select()}
          aria-label={`Quantidade de ${item.nome}`}
          /* Estreito no celular: quantidade de item de proposta é 1, 2, 4 — o
             campo largo de desktop empurrava nome e total para fora da linha
             numa tela onde a largura é o recurso escasso. */
          className="h-7 w-11 flex-shrink-0 rounded-lg border border-border bg-muted/50 text-center text-[13px] text-foreground focus:border-primary/60 focus:outline-none focus:ring-1 focus:ring-primary/40 sm:h-8 sm:w-16 sm:text-sm"
        />
        <div className="text-right w-24 flex-shrink-0 sm:w-32">
          {/* Duplo clique no total abre a edição.
              Quem monta a proposta olha o total da linha, não o unitário — é o
              número que fecha com o cliente. Editando aqui, o unitário é
              recalculado dividindo pela quantidade, e não o contrário.

              Duplo clique, e não simples: a linha inteira já é alvo de clique
              para expandir kit, e a pessoa passa o mouse por cima só para ler. */}
          {rascunho === null ? (
            <button type="button" onDoubleClick={abrir}
              title={podeBaixarPreco
                ? "Duplo clique para editar o valor"
                : `Duplo clique para editar, só para cima. Mínimo ${brl(piso * item.quantidade)}`}
              className="w-full rounded-md px-1 py-0.5 text-right text-[15px] font-semibold tabular-nums text-foreground transition-colors hover:bg-muted/60">
              {brl(totalVenda)}
            </button>
          ) : (
            <input autoFocus type="text" inputMode="decimal"
              value={rascunho}
              onChange={e => setRascunho(e.target.value)}
              onFocus={e => e.currentTarget.select()}
              onBlur={() => fechar(true)}
              onKeyDown={e => {
                if (e.key === "Enter") { e.preventDefault(); fechar(true) }
                if (e.key === "Escape") { e.preventDefault(); fechar(false) }
              }}
              aria-label={`Valor de ${item.nome}`}
              className="h-7 w-full rounded-lg border border-primary/50 bg-muted/60 px-1.5 text-right text-[13px] tabular-nums text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40 sm:text-sm"
            />
          )}
          {showCusto && <p className="text-amber-400 text-[11px] sm:text-xs">custo {brl(totalCusto)}</p>}
          {/* O cadeado explica por que o valor não desce, sem precisar errar
              primeiro para descobrir. */}
          {noPiso && (
            <p className="mt-0.5 flex items-center justify-end gap-1 text-[10px] text-muted-foreground/60">
              <Lock className="h-2.5 w-2.5 flex-shrink-0" aria-hidden="true" />
              mínimo
            </p>
          )}
        </div>
        <Button size="sm" variant="ghost" onClick={onRemove}
          className="text-muted-foreground/40 hover:text-red-400 h-7 w-7 p-0 flex-shrink-0">
          <X className="w-3.5 h-3.5" />
        </Button>
      </div>

      {/* Componentes do kit, expandidos discretamente */}
      {hasKitItems && expanded && (
        <div className="ml-5 pl-3 border-l border-border space-y-1 pb-1">
          {kitSource!.items.map((ki, idx) => (
            <div key={idx} className="flex items-center justify-between text-xs text-muted-foreground/60">
              <span className="truncate flex-1">{ki.product.nome}</span>
              <span className="ml-2 flex-shrink-0">x{ki.quantidade}</span>
              <span className="ml-3 flex-shrink-0 tabular-nums">{brl(Number(ki.product.preco_venda) * ki.quantidade)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default function NovaPropostaPage() {
  return (
    <Suspense fallback={<div className="p-6 text-muted-foreground">Carregando...</div>}>
      <NovaPropostaInner />
    </Suspense>
  )
}


