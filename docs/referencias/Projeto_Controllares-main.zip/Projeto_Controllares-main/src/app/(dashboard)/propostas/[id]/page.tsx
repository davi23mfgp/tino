"use client"

import { baseDoServico, type ServicoProposta } from "@/lib/servicos-proposta"
import { numeroBR } from "@/lib/numero-br"
import { CampoValor } from "@/components/campo-valor"
import {
  embutidoNaCategoria, lerPresetsDaProposta, presetsDaCategoria, reprecificar,
  type PresetsDaProposta, type ServicoDeCategoria,
} from "@/lib/servicos-categoria"
import { blocosDaProposta, NOME_BLOCO_SERVICO } from "@/lib/blocos-proposta"
import { useState, useEffect, useCallback, use } from "react"
import { PageLoader } from "@/components/ui/bouncing-dots"
import { ItensAvulsos } from "@/components/itens-avulsos"
import { useRouter } from "next/navigation"
import { Package, Printer, ArrowLeft, Clock, FileSignature, RefreshCw, Copy, Receipt, CheckCheck, Send, MessageCircle, Link2, HardHat, Search, X, Settings2, Pencil, MapPin, ChevronRight, Trash2, MoreHorizontal, AlertCircle, MessageSquare, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { sanitizeHtml } from "@/lib/sanitize"
import { proxiedImg } from "@/lib/img"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog"
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator } from "@/components/ui/dropdown-menu"
import { DadosFaturamento, DADOS_FAT_VAZIO, type DadosFat } from "@/components/dados-faturamento"
import { faturamentoCompleto, faltaNoFaturamento } from "@/lib/faturamento"
import { formatarDocumento } from "@/lib/documento"
import { useConfirmar } from "@/components/confirmar"
import { gerarCronograma, redistribuir, somaParcelas, FORMAS_PARCELA, type Parcela } from "@/lib/parcelas-calculo"
import { HistoricoLead } from "@/components/leads/historico-lead"
import { brl, pct } from "@/lib/formato"

/* Data de hoje em ISO curto, que é o formato do <input type="date">.
   `toISOString()` converte para UTC e, à noite no Brasil, devolve o dia
   seguinte — o campo abria já com a data errada. */
const hojeISO = () => {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`
}


/**
 * Formas aceitas no faturamento.
 *
 * A proposta anuncia só as três condições padrão; aqui o time fecha a forma
 * real com o cliente, então a lista é completa. `max` é o teto de parcelas
 * de cada uma.
 */
const FORMAS_FATURAMENTO = [
  { id: "AVISTA",        label: "À vista",       desc: "5% de desconto", max: 1 },
  { id: "PIX",           label: "PIX",           desc: "À vista",        max: 1 },
  { id: "TRANSFERENCIA", label: "Transferência", desc: "À vista",        max: 1 },
  { id: "CARTAO",        label: "Cartão",        desc: "Até 12x",        max: 12 },
  { id: "BOLETO",        label: "Boleto",        desc: "Até 12x",        max: 12 },
  { id: "CHEQUE",        label: "Cheque",        desc: "Até 6x",         max: 6 },
  { id: "OBRA",          label: "Na obra",       desc: "Parcelas livres", max: 120 },
  /* Personalizado existe para o combinado que mistura formas: entrada no Pix,
     duas no cartão, o resto em boleto. As outras opções descrevem UMA forma
     para o pagamento inteiro, e esse acordo não cabia em nenhuma delas. */
  { id: "PERSONALIZADO", label: "Personalizado", desc: "Forma por parcela", max: 120 },
] as const

type ProposalStatus = "RASCUNHO" | "ENVIADA" | "LIDA" | "EM_REVISAO" | "ACEITA" | "EM_FATURAMENTO" | "EM_CONTRATO" | "CONCLUIDA" | "CANCELADA" | "PROPOSTA_PERDIDA"

const STATUS_BADGE: Record<ProposalStatus, "secondary" | "default" | "outline" | "destructive" | "success" | "warning"> = {
  RASCUNHO: "secondary",
  ENVIADA: "default",
  LIDA: "outline",
  EM_REVISAO: "warning",
  ACEITA: "success",
  EM_FATURAMENTO: "default",
  EM_CONTRATO: "default",
  CONCLUIDA: "success",
  CANCELADA: "destructive",
  PROPOSTA_PERDIDA: "destructive",
}

/**
 * Miniatura do item: a imagem cadastrada; sem ela, o ícone do catálogo.
 *
 * Um ícone só, o mesmo para todos. A versão anterior escolhia um emoji por
 * palavra do nome — e um emoji colorido ao lado de cada linha compete com o
 * conteúdo da proposta, que é o que a pessoa foi ali ler. Placeholder é
 * ausência de imagem, e deve parecer ausência.
 */
function ItemIcon({ nome, qtd, img }: { nome: string; qtd: number; img?: string | null }) {
  return (
    /* Duas camadas de propósito.

       O recorte arredondado da foto exige `overflow-hidden`, mas o selo de
       quantidade fica de fora da moldura (`-top-1.5 -right-1.5`) para não tapar
       o produto. Com os dois no mesmo elemento, o `overflow-hidden` cortava o
       selo justamente na quina: aparecia meia bolinha e a quantidade sumia.

       Então o recorte fica na camada de dentro, com a imagem, e o selo na de
       fora, que não corta nada. */
    <div className="relative w-11 h-11 flex-shrink-0">
      <div className={`w-11 h-11 rounded-xl overflow-hidden ${img ? "bg-white" : "img-produto"} flex items-center justify-center`}>
        {img ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={proxiedImg(img)} alt={nome} className="w-full h-full object-cover"
            onError={e => { const el = e.target as HTMLImageElement; el.style.display = "none"; if (el.nextElementSibling) (el.nextElementSibling as HTMLElement).style.display = "flex" }} />
        ) : null}
        <span className="w-full h-full items-center justify-center" style={{ display: img ? "none" : "flex" }}>
          <Package className="w-4 h-4 text-muted-foreground" />
        </span>
      </div>
      {qtd > 1 && (
        <span aria-label={`Quantidade: ${qtd}`}
          className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 rounded-full bg-surface-3 border border-hairline text-[10px] font-semibold text-foreground flex items-center justify-center">
          ×{qtd}
        </span>
      )}
    </div>
  )
}

const STATUS_LABEL: Record<ProposalStatus, string> = {
  RASCUNHO: "Rascunho", ENVIADA: "Enviada", LIDA: "Lida",
  EM_REVISAO: "Em revisão", ACEITA: "Aceita", EM_FATURAMENTO: "Em faturamento", EM_CONTRATO: "Contrato",
  CONCLUIDA: "Concluída",
  CANCELADA: "Cancelada", PROPOSTA_PERDIDA: "Perdida",
}
function STATUS_BADGE_LABEL(s: ProposalStatus) { return STATUS_LABEL[s] ?? s }

interface ProposalItem {
  id: string
  quantidade: number
  valor_unitario: number
  valor_total: number
  product: { nome: string; sku: string; imagem_url?: string | null } | null
  kit: { nome: string } | null
  categoryId?: string | null
  category: { nome: string; imagem_url?: string | null } | null
  nome_snapshot?: string | null
  sku_snapshot?: string | null
  /* Item escrito direto na proposta. Enquanto `avulso_resolvido_em` for nulo,
     não há produto no catálogo e o faturamento fica barrado. */
  avulso?: boolean
  avulso_resolvido_em?: string | null
}

interface Environment {
  id: string
  nome: string
  status: string
  proposalItems: ProposalItem[]
}

interface ProposalVersion {
  id: string
  numero_versao: number
  motivo_alteracao: string | null
  valor_historico: number
  createdAt: string
}

interface ObraLite {
  id: string
  client_name: string
  etapa: string | null
  cidade: string | null
}

interface Proposal {
  id: string
  numero: string
  contrato_gerado_em: string | null
  contrato_enviado_em: string | null
  contrato_assinado_em: string | null
  olist_contrato_em: string | null
  client_name: string
  client_email: string | null
  client_city: string | null
  project_type: string
  status: ProposalStatus
  valor_total: number
  valor_servico: number
  desconto_aplicado: number | null
  credito_st: number
  anos_garantia: number | null
  dias_garantia: number | null
  desconto_campanha: number | null
  pagamento_definido_por: string | null
  fat_razao_social: string | null; fat_documento: string | null; fat_ie: string | null; fat_email: string | null
  fat_nascimento: string | null
  fat_cep: string | null; fat_logradouro: string | null; fat_numero: string | null
  fat_complemento: string | null; fat_bairro: string | null; fat_cidade: string | null; fat_uf: string | null
  olist_enviado_em: string | null; olist_pedido_numero: string | null
  servicos_detalhe?: { id: string; nome: string; tipo: "percentual" | "fixo"; valor: string }[] | null
  /* O serviço da categoria que ESTA proposta embutiu no preço dos produtos. */
  servicos_categoria?: PresetsDaProposta[] | null
  obra_cep: string | null; obra_logradouro: string | null; obra_numero: string | null
  obra_complemento: string | null; obra_bairro: string | null; obra_cidade: string | null; obra_uf: string | null
  exibir_valor_unitario: boolean
  aplicar_desconto_campanha: boolean
  forma_pagamento: string | null
  parcelas_forma: number | null
  valor_entrada: number | null
  mensagem_cliente: string | null
  mensagem_cliente_em: string | null
  data_expiracao: string | null
  createdAt: string
  link_token: string | null
  obraId: string | null
  // obra que esta proposta gerou (crossover) — se preenchido, não pode ser aditivo
  obraOrigem: { id: string; client_name: string } | null
  // obra à qual esta proposta está vinculada como aditivo
  obra: { id: string; client_name: string; etapa: string | null } | null
  vendedor: { id: string; nome: string; email: string }
  environments: Environment[]
  versions: ProposalVersion[]
  payment_methods: string | null
  installments: Array<{ id: string; numero_parcela: number; valor: number; data_vencimento: string; status: string }>
  extraPages: Array<{ titulo: string; conteudo_markdown: string; ordem: number; anexos?: { nome: string; url: string; ext: string }[] }>
}

/**
 * Endereço público da proposta.
 *
 * Usa APP_URL, não window.location.origin: se o time abre o sistema por uma URL
 * de preview da Vercel, o link copiado sai com esse domínio e o cliente, que não
 * tem conta na Vercel, cai numa tela de login em vez da proposta.
 */
function linkPublico(token: string) {
  const base = (process.env.NEXT_PUBLIC_APP_URL || "").replace(/\/+$/, "")
  return `${base || window.location.origin}/p/${token}`
}

/**
 * Indicador de pendência que trava o envio ao Olist.
 *
 * Fica no topo da proposta, e a regra de desenho é: pendente pede atenção,
 * resolvido apenas confirma. Por isso o estado verde perde a cor de fundo e o
 * peso da fonte — some do caminho sem sumir da tela, para quem quiser conferir
 * depois ainda encontrar.
 */
function IndicadorPendencia({ ok, rotulo, onClick }: {
  ok: boolean
  rotulo: string
  onClick: () => void
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={ok ? `${rotulo}: preenchido. Clique para alterar.` : `${rotulo}: pendente, trava o envio ao Olist.`}
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[12px] transition-colors ${
        ok
          ? "border-success/30 text-success hover:bg-success/10"
          : "border-warning/40 bg-warning/10 font-medium text-warning hover:bg-warning/20"
      }`}
    >
      {ok ? <CheckCheck className="h-3.5 w-3.5" /> : <AlertCircle className="h-3.5 w-3.5" />}
      {rotulo}
    </button>
  )
}

export default function PropostaDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const confirmar = useConfirmar()
  const { id } = use(params)
  const router = useRouter()
  const [proposal, setProposal] = useState<Proposal | null>(null)
  const [loading, setLoading] = useState(true)
  const [restoringId, setRestoringId] = useState<string | null>(null)
  const [linkCopied, setLinkCopied] = useState(false)
  const [emittingNfe, setEmittingNfe] = useState(false)
  const [nfeToast, setNfeToast] = useState(false)
  const [enviando, setEnviando] = useState(false)
  const [enviandoTiny, setEnviandoTiny] = useState(false)
  const [olistResultado, setOlistResultado] = useState<
    { ok: true; numeroPedido: string | null } | { ok: false; erro: string } | null
  >(null)
  const [enviadaToast, setEnviadaToast] = useState(false)
  const [emailStatus, setEmailStatus] = useState<string | null>(null)
  // Painel de faturamento: começa com o que veio da proposta.
  const [pgto, setPgto] = useState<
    { forma: string; parcelas: number; entrada: string; inicio: string } | null>(null)
  /* Cronograma em edição. Fica fora de `pgto` porque tem vida própria: nasce
     calculado da condição e passa a ser o que a pessoa ajustou. */
  const [parcelas, setParcelas] = useState<Parcela[]>([])
  const [parcelasTocadas, setParcelasTocadas] = useState(false)
  const [erroParcelas, setErroParcelas] = useState("")

  /* A prévia se refaz sozinha enquanto ninguém mexeu nela: trocar a forma, o
     número de parcelas ou a entrada recalcula as datas e os valores na hora —
     que é o ponto de mostrar a tabela antes de salvar. Depois da primeira
     edição manual ela para de se refazer, senão a linha ajustada à mão seria
     apagada pelo próximo caractere digitado na entrada. */
  useEffect(() => {
    if (!pgto || parcelasTocadas) return
    setParcelas(gerarCronograma({
      total: Number(proposal?.valor_total ?? 0),
      entrada: Number(pgto.entrada || 0),
      parcelas: pgto.parcelas,
      /* A data do primeiro pagamento é escolhida, não presumida. Antes saía
         sempre de hoje, e um pagamento combinado para o mês que vem obrigava a
         corrigir cada linha da tabela à mão. */
      primeiroVencimento: pgto.inicio ? new Date(`${pgto.inicio}T12:00:00`) : undefined,
      formaPadrao: pgto.forma === "PERSONALIZADO" ? null : pgto.forma,
    }))
  }, [pgto, parcelasTocadas, proposal?.valor_total])
  const [salvandoPgto, setSalvandoPgto] = useState(false)
  const [dadosFat, setDadosFat] = useState<DadosFat | null>(null)
  const [salvandoFat, setSalvandoFat] = useState(false)

  /* Abrir o editor virou função nomeada porque agora tem duas portas: o botão
     do próprio bloco, lá embaixo, e o indicador de pendência no topo. Deixar o
     corpo no `onClick` obrigaria a duplicar — e duplicar isto significa que um
     dia um dos dois deixa de carregar o cronograma já gravado. */
  async function abrirEditorPagamento() {
    if (!proposal) return
    setErroParcelas("")
    setParcelasTocadas(false)
    setPgto({
      forma: proposal.forma_pagamento ?? "",
      parcelas: proposal.parcelas_forma ?? 6,
      entrada: proposal.valor_entrada != null ? String(proposal.valor_entrada) : "",
      inicio: hojeISO(),
    })
    /* Cronograma já gravado abre como está, não recalculado: a data
       renegociada com o cliente não pode ser desfeita só porque alguém abriu
       a tela para conferir. */
    const r = await fetch(`/api/propostas/${id}/parcelas`, { cache: "no-store" })
    const j = await r.json().catch(() => null)
    if (r.ok && j && !j.previa && j.parcelas?.length) {
      setParcelas(j.parcelas)
      setParcelasTocadas(true)
    }
  }

  function abrirEditorFaturamento() {
    if (!proposal) return
    setDadosFat({
      ...DADOS_FAT_VAZIO,
      fat_razao_social: proposal.fat_razao_social ?? proposal.client_name ?? "",
      fat_documento: proposal.fat_documento ?? "",
      fat_ie: proposal.fat_ie ?? "",
      fat_email: proposal.fat_email ?? proposal.client_email ?? "",
      fat_nascimento: proposal.fat_nascimento ? String(proposal.fat_nascimento).slice(0, 10) : "",
      fat_cep: proposal.fat_cep ?? "", fat_logradouro: proposal.fat_logradouro ?? "",
      fat_numero: proposal.fat_numero ?? "", fat_complemento: proposal.fat_complemento ?? "",
      fat_bairro: proposal.fat_bairro ?? "", fat_cidade: proposal.fat_cidade ?? "",
      fat_uf: proposal.fat_uf ?? "",
      obra_cep: proposal.obra_cep ?? "", obra_logradouro: proposal.obra_logradouro ?? "",
      obra_numero: proposal.obra_numero ?? "", obra_complemento: proposal.obra_complemento ?? "",
      obra_bairro: proposal.obra_bairro ?? "", obra_cidade: proposal.obra_cidade ?? "",
      obra_uf: proposal.obra_uf ?? "",
    })
  }

  async function salvarFaturamento() {
    if (!dadosFat) return
    setSalvandoFat(true)
    try {
      const r = await fetch(`/api/propostas/${id}/faturamento`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(dadosFat),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { await confirmar({ titulo: j.error || "Não foi possível salvar.", apenasAviso: true }); return }
      setDadosFat(null)
      await fetchProposal()
    } finally { setSalvandoFat(false) }
  }

  const [concluindo, setConcluindo] = useState(false)
  const [enviandoOlist, setEnviandoOlist] = useState(false)

  /* Manda a cópia do contrato ao Olist. Falhar aqui não desfaz nada: o
     contrato daqui continua válido, e o botão volta para nova tentativa. */
  async function enviarContratoOlist() {
    setEnviandoOlist(true)
    try {
      const r = await fetch("/api/integracoes/olist/contratos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ proposalId: id }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { await confirmar({ titulo: j.error || "Não foi possível enviar o contrato ao Olist.", apenasAviso: true }); return }
      await fetchProposal()
    } catch {
      await confirmar({ titulo: "Falha de conexão ao enviar o contrato ao Olist.", apenasAviso: true })
    } finally { setEnviandoOlist(false) }
  }
  const [modelosContrato, setModelosContrato] = useState<{ id: string; nome: string }[]>([])
  const [confirmarAssinatura, setConfirmarAssinatura] = useState(false)
  const [assinando, setAssinando] = useState(false)
  const [confirmarEnvioContrato, setConfirmarEnvioContrato] = useState(false)
  const [emailContrato, setEmailContrato] = useState("")
  const [enviandoContrato, setEnviandoContrato] = useState(false)

  /* Confirmar a assinatura é irreversível de propósito: dizer que um contrato
     assinado deixou de estar assinado não é correção de digitação. */
  async function confirmarContratoAssinado() {
    setAssinando(true)
    try {
      const r = await fetch(`/api/propostas/${id}/contrato/assinar`, { method: "POST" })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { await confirmar({ titulo: j.error || "Não foi possível registrar a assinatura.", apenasAviso: true }); return }
      setConfirmarAssinatura(false)
      await fetchProposal()
    } finally { setAssinando(false) }
  }

  async function enviarContratoAoCliente() {
    setEnviandoContrato(true)
    try {
      const r = await fetch(`/api/propostas/${id}/contrato/enviar`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: emailContrato.trim() }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { await confirmar({ titulo: j.error || "Não foi possível enviar.", apenasAviso: true }); return }
      setConfirmarEnvioContrato(false)
      await fetchProposal()
    } finally { setEnviandoContrato(false) }
  }
  const [escolherModelo, setEscolherModelo] = useState(false)

  /* Modelos de contrato só interessam quando a proposta chega nessa etapa —
     buscar antes é uma requisição por proposta aberta, sem uso. */
  useEffect(() => {
    if (proposal?.status !== "EM_CONTRATO") return
    fetch("/api/page-templates?tipo=CONTRATO", { cache: "no-store" })
      .then(r => r.json())
      .then(j => setModelosContrato(j.templates ?? []))
      .catch(() => {})
  }, [proposal?.status])

  /* Fecha uma etapa do fim do fluxo: faturamento → contrato → concluída.
     A ordem é validada no servidor; aqui só disparamos o próximo passo. */
  /* Itens escritos direto na proposta, sem produto no catálogo.

     Sem aviso permanente: quem escreveu o item já sabe que ele não está no
     catálogo — foi por isso que escreveu. A gaveta abre só quando o faturamento
     é barrado, que é quando a pendência de fato atrapalha; mostrar o erro sem
     dar onde resolver obrigaria a procurar a tela certa. */
  const [avulsosAberto, setAvulsosAberto] = useState(false)


  async function avancarEtapa(status: "EM_CONTRATO" | "CONCLUIDA" | "EM_FATURAMENTO") {
    if (!proposal) return
    setConcluindo(true)
    try {
      const r = await fetch(`/api/propostas/${id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) {
        /* Item sem cadastro tem tela própria: abrir direto poupa a pessoa de
           ler o erro, fechar, e procurar onde resolver. */
        if (j.itensAvulsos) { setAvulsosAberto(true); return }
        await confirmar({ titulo: j.error || "Não foi possível avançar a etapa.", apenasAviso: true })
        return
      }
      await fetchProposal()
    } finally { setConcluindo(false) }
  }

  async function salvarPagamento() {
    if (!pgto) return
    setSalvandoPgto(true)
    setErroParcelas("")
    try {
      const r = await fetch(`/api/propostas/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          forma_pagamento: pgto.forma || null,
          parcelas_forma: pgto.forma ? pgto.parcelas : null,
          valor_entrada: pgto.entrada ? Number(pgto.entrada) : null,
          motivo_alteracao: "Condição de pagamento definida no faturamento",
        }),
      })
      if (!r.ok) return

      /* O cronograma vai numa rota própria: parcela não é alteração de escopo
         e não deve entrar no histórico de versões da proposta. Salvar as duas
         coisas juntas é o que evita a condição dizer "6x" e o financeiro
         mostrar outra coisa. */
      if (parcelas.length) {
        const rp = await fetch(`/api/propostas/${id}/parcelas`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ parcelas }),
        })
        if (!rp.ok) {
          const j = await rp.json().catch(() => ({}))
          setErroParcelas(j.error || "Não foi possível gravar as parcelas.")
          return
        }
      }
      setPgto(null)
      await fetchProposal()
    } finally { setSalvandoPgto(false) }
  }
  const [confirmEnvio, setConfirmEnvio] = useState(false)
  const [confirmExcluir, setConfirmExcluir] = useState(false)
  const [excluindo, setExcluindo] = useState(false)
  const [erroExcluir, setErroExcluir] = useState("")

  /* Guardar esta proposta como ponto de partida das próximas.
     O nome vem sugerido mas editável: é por ele que alguém acha o modelo daqui
     a três meses, e "Cópia de PROP-2026-014" não ajuda ninguém. */
  const [modeloOpen, setModeloOpen] = useState(false)
  const [modeloNome, setModeloNome] = useState("")
  const [salvandoModelo, setSalvandoModelo] = useState(false)
  const [erroModelo, setErroModelo] = useState("")
  const [modeloSalvo, setModeloSalvo] = useState(false)

  function abrirSalvarModelo() {
    setModeloNome(proposal?.project_type ? `Modelo ${proposal.project_type.toLowerCase()}` : "Novo modelo")
    setErroModelo(""); setModeloSalvo(false); setModeloOpen(true)
  }

  async function salvarComoModelo() {
    const nome = modeloNome.trim()
    if (!nome) { setErroModelo("Dê um nome ao modelo."); return }
    setSalvandoModelo(true); setErroModelo("")
    try {
      const res = await fetch("/api/templates", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, proposalId: id }),
      })
      if (!res.ok) {
        const j = await res.json().catch(() => null)
        setErroModelo(j?.error || "Não deu para salvar o modelo.")
        return
      }
      setModeloSalvo(true)
    } catch {
      setErroModelo("Não deu para salvar o modelo.")
    } finally { setSalvandoModelo(false) }
  }

  async function excluirProposta() {
    setExcluindo(true); setErroExcluir("")
    try {
      const r = await fetch(`/api/propostas/${id}?definitivo=1`, { method: "DELETE" })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { setErroExcluir(j.error || "Não foi possível excluir."); return }
      router.push("/propostas")
    } catch {
      setErroExcluir("Falha de conexão.")
    } finally { setExcluindo(false) }
  }

  // --- Inline edit de itens da proposta ---
  const [itemEdit, setItemEdit] = useState<{ itemId: string; field: 'quantidade' | 'valor_unitario'; value: string } | null>(null)

  async function saveItemEdit(ie = itemEdit) {
    if (!ie || !proposal) return
    setItemEdit(null)
    let num = parseFloat(ie.value.replace(',', '.'))
    if (isNaN(num) || num <= 0) return

    /* Preço só sobe, exceto para o Admin.
       O piso é o valor que o item tem agora — a mesma conta que o servidor
       refaz ao receber o PATCH. Aqui o valor é puxado de volta para o piso em
       vez de a gravação ser recusada: a pessoa vê o que aconteceu na hora, em
       vez de levar um erro depois de já ter saído do campo. */
    if (ie.field === 'valor_unitario' && userRole !== 'ADMIN') {
      const atual = proposal.environments
        .flatMap(env => env.proposalItems)
        .find(i => i.id === ie.itemId)
      const piso = Number(atual?.valor_unitario ?? 0)
      if (num < piso) {
        num = piso
        await confirmar({
          titulo: "O preço só pode subir",
          texto: `Este item fica em ${brl(piso)}. Você pode aumentar, mas só o `
            + `Admin reduz.`,
          apenasAviso: true,
        })
      }
    }
    // Optimistic update
    setProposal(prev => {
      if (!prev) return prev
      return {
        ...prev,
        environments: prev.environments.map(env => ({
          ...env,
          proposalItems: env.proposalItems.map(item => {
            if (item.id !== ie.itemId) return item
            const qt = ie.field === 'quantidade' ? num : item.quantidade
            const vu = ie.field === 'valor_unitario' ? num : Number(item.valor_unitario)
            return { ...item, [ie.field]: num, valor_total: qt * vu }
          })
        }))
      }
    })
    const r = await fetch(`/api/propostas/${id}/items/${ie.itemId}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ [ie.field]: num }),
    })
    /* Recusa do servidor precisa aparecer. Sem isto, o valor otimista some
       sozinho no fetchProposal seguinte e a tela "volta atrás" sem explicação —
       parece falha da tela, não regra de negócio. */
    if (!r.ok) {
      const j = await r.json().catch(() => ({}))
      await confirmar({ titulo: j.error || "Não foi possível salvar o item.", apenasAviso: true })
    }
    fetchProposal()
  }

  // --- Role do usuário logado ---
  const [userRole, setUserRole] = useState<string>("")
  useEffect(() => {
    fetch("/api/auth/me").then(r => r.json()).then(d => setUserRole(d.user?.role ?? ""))
  }, [])

  // --- Opções Avançadas ---
  const [avancadoOpen, setAvancadoOpen] = useState(false)
  const [avancadoSaving, setAvancadoSaving] = useState(false)
  const [avancadoForm, setAvancadoForm] = useState({
    status: "" as ProposalStatus | "",
    desconto_aplicado: "",
    credito_st: "",
    exibir_valor_unitario: false,
    aplicar_desconto_campanha: true,
    valor_servico: "",
    dias_garantia: "",
    data_expiracao: "",
    motivo_alteracao: "",
  })
  /* A composicao dos servicos vinha so como total. Editar a proposta depois
     deixava quem abriu sem saber de onde o numero saiu. */
  const [servicos, setServicos] = useState<{
    id: string; nome: string; tipo: "percentual" | "fixo"; valor: string
    /* Sobre o que o percentual incide. Esta tela calculava tudo sobre o total
       da proposta, sempre — um serviço de 15% cadastrado para o Home Theater
       cobrava 15% da automação junto, e a conta fechava sem ninguém ver. */
    environmentId?: string | null
    categoryId?: string | null
  }[]>([])
  const [descontoModo, setDescontoModo] = useState<"PCT" | "VALOR">("PCT")
  /* Texto do desconto enquanto a pessoa digita. O campo em R$ era derivado do
     percentual guardado: cada tecla virava % arredondado e voltava como reais
     recalculados — "1" aparecia como 0,91 e nada mais entrava nem apagava. */
  const [descontoTxt, setDescontoTxt] = useState<string | null>(null)

  /* O serviço da CATEGORIA, o que já está dentro do preço de cada produto.

     Ele some de vista: quem abre a proposta vê o produto Control4 custando mais
     que a tabela e não tem onde conferir o porquê. Aqui ele aparece, categoria
     por categoria, e pode ser mudado só para ESTA proposta — mudar a taxa
     reescreve o preço dos itens daquela categoria, desfazendo o que estava
     embutido e embutindo o novo. Quem faz essa conta é o servidor. */
  const [catCadastro, setCatCadastro] = useState<{ id: string; nome: string; servicos: ServicoDeCategoria[] | null }[]>([])
  const [servCategoria, setServCategoria] = useState<PresetsDaProposta[]>([])
  const [servCategoriaBase, setServCategoriaBase] = useState("[]")

  /* Sistema GUARDADO não vai pro cliente e não soma em nada aqui — total,
     serviços, categorias, avulso pendente. Ele só existe pra ficar salvo na
     ficha do lead; misturado nessas contas, inflava o valor da proposta com
     algo que nem foi oferecido. */
  const ambientesAtivos = proposal
    ? proposal.environments.filter(e => (e.status ?? "ATIVO") === "ATIVO")
    : []

  // Subtotal bruto dos produtos (soma dos itens, sem serviços/ST/desconto)
  const subtotalProdutos = ambientesAtivos.flatMap(e => e.proposalItems).reduce((s, i) => s + Number(i.valor_total), 0)

  /* Total dos servicos vem da composicao: percentual incide sobre os produtos,
     fixo entra como esta. Antes o total era digitado solto e podia divergir do
     que estava listado. */
  /* Itens no formato que a regra compartilhada entende. É a mesma função que a
     proposta do cliente, o contrato e o pedido do Olist usam — três contas do
     mesmo número é como uma delas fica errada sem ninguém notar. */
  const itensParaServico = ambientesAtivos.flatMap(e => e.proposalItems.map(i => ({
    environmentId: e.id,
    categoryId: i.categoryId ?? null,
    valor_total: Number(i.valor_total),
  })))

  /* As categorias que ESTA proposta tem, não o catálogo inteiro. Oferecer uma
     categoria sem produto aqui dá serviço de R$ 0 e uma lista longa demais para
     achar o que interessa. */
  const categoriasDaProposta = [...new Map(
    ambientesAtivos
      .flatMap(e => e.proposalItems)
      .filter(i => i.categoryId && i.category?.nome)
      .map(i => [i.categoryId as string, { id: i.categoryId as string, nome: i.category!.nome }]),
  ).values()]

  /* Quanto de serviço da categoria está dentro do preço dos itens desta
     proposta. Não entra em conta nenhuma — já está no preço, e somar de novo
     cobraria duas vezes —, serve para conferir o que está sendo cobrado e para
     mudar a taxa só aqui.

     O que a proposta guardou manda; sem registro (proposta anterior à coluna),
     vale o cadastro da categoria, que foi o que embutiu o preço dela. */
  const presetsSalvos = lerPresetsDaProposta(proposal?.servicos_categoria)
  const embutidosPorCategoria = categoriasDaProposta.map(cat => {
    const itens = ambientesAtivos.flatMap(e => e.proposalItems)
      .filter(i => i.categoryId === cat.id)
      .map(i => ({ unitario: Number(i.valor_unitario), qtd: i.quantidade }))
    const doCadastro = catCadastro.find(c => c.id === cat.id)?.servicos ?? null
    const qtd = itens.reduce((t, i) => t + i.qtd, 0)
    const salvos = presetsDaCategoria(cat.id, presetsSalvos, doCadastro)
    const editados = presetsDaCategoria(cat.id, servCategoria, doCadastro)
    const totalAtual = itens.reduce((t, i) => t + i.unitario * i.qtd, 0)
    /* O total como ele FICARÁ com a taxa proposta: sem isto, quem digita 20% no
       lugar de 30% vê o valor antigo e não sabe o que está prestes a aplicar. */
    const totalNovo = itens.reduce((t, i) => t + reprecificar(i.unitario, salvos, editados) * i.qtd, 0)
    return {
      id: cat.id, nome: cat.nome, qtd, totalAtual, totalNovo, editados,
      linhas: embutidoNaCategoria(totalNovo, qtd, editados),
    }
  })
  const totalEmbutido = embutidosPorCategoria.reduce(
    (t, c) => t + c.linhas.reduce((soma, l) => soma + l.embutido, 0), 0)
  /* Mudou a taxa, mudou o preço dos produtos: o desconto e o total do popup
     precisam ler o subtotal que vai valer, não o que está gravado. */
  const subtotalProdutosPrevisto = embutidosPorCategoria.reduce((t, c) => t + c.totalNovo, 0)
    + ambientesAtivos.flatMap(e => e.proposalItems)
      .filter(i => !i.categoryId || !categoriasDaProposta.some(c => c.id === i.categoryId))
      .reduce((t, i) => t + Number(i.valor_total), 0)
  const servCategoriaMudou = JSON.stringify(servCategoria) !== servCategoriaBase

  /** Troca a lista de serviços de uma categoria só nesta proposta. */
  function definirServicosDaCategoria(catId: string, servicos: ServicoDeCategoria[]) {
    setServCategoria(lista => [...lista.filter(p => p.categoryId !== catId), { categoryId: catId, servicos }])
  }

  /* Os itens pelo preço que VAI valer, para a base do percentual acompanhar a
     reprecificação. Serviço em reais ignora a base — mas proposta antiga tem
     serviço em percentual, e ele cobraria sobre o preço que deixou de existir,
     gravando um `valor_servico` que não corresponde à tela. */
  const itensParaServicoPrevisto = ambientesAtivos.flatMap(e => e.proposalItems.map(i => {
    const doCadastro = i.categoryId ? catCadastro.find(c => c.id === i.categoryId)?.servicos ?? null : null
    const unitario = Number(i.valor_unitario)
    const previsto = i.categoryId
      ? reprecificar(
        unitario,
        presetsDaCategoria(i.categoryId, presetsSalvos, doCadastro),
        presetsDaCategoria(i.categoryId, servCategoria, doCadastro),
      )
      : unitario
    return { environmentId: e.id, categoryId: i.categoryId ?? null, valor_total: previsto * i.quantidade }
  }))

  const baseDoSv = (sv: { environmentId?: string | null; categoryId?: string | null }) =>
    baseDoServico(sv, itensParaServicoPrevisto)

  const valorDoSv = (sv: { tipo: "percentual" | "fixo"; valor: string; environmentId?: string | null; categoryId?: string | null }) =>
    sv.tipo === "percentual"
      ? baseDoSv(sv) * (Number(sv.valor) || 0) / 100
      : Number(sv.valor) || 0

  const totalServicos = servicos.reduce((soma, sv) => soma + valorDoSv(sv), 0)

  /* Os mesmos blocos que o cliente vê no link: cada sistema com o seu valor e
     projeto e instalação como bloco, não mais como linha de "composição do
     valor". Quem confere a proposta aqui precisa ler exatamente o que foi
     enviado — duas leituras diferentes do mesmo número é como uma delas passa
     a mentir. Vem do que está SALVO, não do formulário de avançadas. */
  const servicosSalvos: ServicoProposta[] = (() => {
    const detalhe = (proposal?.servicos_detalhe ?? []) as unknown as ServicoProposta[]
    if (Array.isArray(detalhe) && detalhe.length) return detalhe
    const total = Number(proposal?.valor_servico ?? 0)
    return total > 0 ? [{ nome: NOME_BLOCO_SERVICO, tipo: "fixo", valor: total }] : []
  })()
  const blocosProposta = blocosDaProposta(
    ambientesAtivos.map(e => ({ id: e.id, nome: e.nome })),
    itensParaServico,
    servicosSalvos,
    Number(proposal?.valor_servico ?? 0),
  )
  const blocoServico = blocosProposta.find(b => b.servico) ?? null

  /* Base do desconto: produtos + servicos, que e sobre o que ele incide.
     Produtos pelo preço que vai valer: mexer na taxa da categoria muda o preço
     dos itens, e o desconto incide sobre o que será cobrado. */
  const baseDesconto = subtotalProdutosPrevisto + totalServicos

  // Cálculo: ST acrescenta (custo recuperado), serviços somam, desconto deduz no final
  const calcEscada = (f: typeof avancadoForm) => {
    const servico  = parseFloat(f.valor_servico)      || 0
    const desconto = parseFloat(f.desconto_aplicado)  || 0
    // Imposto ST saiu da tela: era um percentual manual que ninguém preenchia e
    // inflava o total sem lastro. O crédito real vem do produto, no catálogo.
    const st = 0, stValor = 0
    const subtotal     = subtotalProdutosPrevisto + servico
    const descontoValor = subtotal * (desconto / 100)
    const totalFinal   = subtotal - descontoValor
    return { servico, st, stValor, desconto, subtotal, descontoValor, totalFinal }
  }
  const escada = calcEscada(avancadoForm)

  function abrirAvancado() {
    if (!proposal) return
    setAvancadoForm({
      status: proposal.status,
      desconto_aplicado: proposal.desconto_aplicado != null ? String(proposal.desconto_aplicado) : "0",
      credito_st: String(proposal.credito_st ?? 0),
      exibir_valor_unitario: proposal.exibir_valor_unitario === true,
      aplicar_desconto_campanha: proposal.aplicar_desconto_campanha !== false,
      valor_servico: String(proposal.valor_servico ?? 0),
      dias_garantia: proposal.dias_garantia != null ? String(proposal.dias_garantia)
        : proposal.anos_garantia != null ? String(proposal.anos_garantia * 365) : "",
      data_expiracao: proposal.data_expiracao ? proposal.data_expiracao.split("T")[0] : "",
      motivo_alteracao: "",
    })
    /* Proposta antiga guarda instalação e administração só no `valor_servico`,
       sem linha. Sem isto, abrir e salvar este popup gravava `valor_servico` =
       soma das linhas visíveis e o serviço que faltava sumia do total, sem
       ninguém pedir. A diferença entra como linha editável: quem quiser
       separar "Instalação" de "Administração" renomeia e divide aqui. */
    const salvos = Array.isArray(proposal.servicos_detalhe) ? proposal.servicos_detalhe : []
    const somaSalvos = salvos.reduce((t, sv) => t + valorDoSv(sv), 0)
    const faltando = Number(proposal.valor_servico ?? 0) - somaSalvos
    setServicos(faltando > 0.01
      ? [...salvos, {
        id: `sv_${Date.now()}`,
        nome: NOME_BLOCO_SERVICO,
        tipo: "fixo" as const,
        valor: faltando.toFixed(2),
      }]
      : salvos)
    /* O que ESTA proposta embutiu, e o cadastro de cada categoria para as
       propostas anteriores a esse registro. */
    const daProposta = lerPresetsDaProposta(proposal.servicos_categoria)
    setServCategoria(daProposta)
    setServCategoriaBase(JSON.stringify(daProposta))
    fetch("/api/categorias")
      .then(r => r.ok ? r.json() : null)
      .then(d => {
        const lista = (d?.categories ?? d?.categorias ?? d ?? []) as {
          id: string; nome: string; servicos?: ServicoDeCategoria[] | null
        }[]
        if (Array.isArray(lista)) {
          setCatCadastro(lista.map(c => ({ id: c.id, nome: c.nome, servicos: c.servicos ?? null })))
        }
      })
      .catch(() => {})
    setDescontoModo("PCT")
    setAvancadoOpen(true)
  }

  async function salvarAvancado() {
    if (!proposal) return
    setAvancadoSaving(true)
    try {
      const { totalFinal } = calcEscada(avancadoForm)
      const body: Record<string, unknown> = {
        motivo_alteracao: avancadoForm.motivo_alteracao || "Ajuste avançado",
        valor_total:      Math.max(0, totalFinal),
        // O total vem da composicao, nao de um campo digitado a parte: assim
        // a lista e o numero nunca divergem.
        valor_servico:    totalServicos,
        servicos_detalhe: servicos,
        /* Só quando muda: mandar sempre faria o servidor reprecificar item por
           item em toda gravação do popup, para chegar no mesmo preço. */
        ...(servCategoriaMudou ? { servicos_categoria: servCategoria } : {}),
        desconto_aplicado: parseFloat(avancadoForm.desconto_aplicado) || 0,
        credito_st:        parseFloat(avancadoForm.credito_st) || 0,
        exibir_valor_unitario: avancadoForm.exibir_valor_unitario,
        aplicar_desconto_campanha: avancadoForm.aplicar_desconto_campanha,
      }
      if (avancadoForm.status)       body.status       = avancadoForm.status
      if (avancadoForm.dias_garantia !== "") body.dias_garantia = parseInt(avancadoForm.dias_garantia)
      if (avancadoForm.data_expiracao)      body.data_expiracao = avancadoForm.data_expiracao
      await fetch(`/api/propostas/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      })
      setAvancadoOpen(false)
      await fetchProposal()
    } finally {
      setAvancadoSaving(false)
    }
  }

  // --- Aditivo ---
  const [aditivoOpen, setAditivoOpen] = useState(false)
  const [obrasDisponiveis, setObrasDisponiveis] = useState<ObraLite[]>([])
  const [selectedObraId, setSelectedObraId] = useState<string>("")
  const [buscaObra, setBuscaObra] = useState("")
  const [vinculating, setVinculating] = useState(false)
  const [aditivoToast, setAditivoToast] = useState(false)

  /** @param silencioso  não liga o loader (usado pela atualização automática). */
  const fetchProposal = useCallback(async (silencioso = false) => {
    if (!silencioso) setLoading(true)
    try {
      const res = await fetch(`/api/propostas/${id}`, { cache: "no-store" })
      if (!res.ok) { router.push("/propostas"); return }
      const data = await res.json()
      setProposal(data)
    } finally {
      if (!silencioso) setLoading(false)
    }
  }, [id, router])

  useEffect(() => { fetchProposal() }, [fetchProposal])

  /**
   * Mantém a tela em dia com o kanban.
   *
   * O status muda em outro lugar — alguém arrasta o card, ou o próprio cliente
   * aceita pelo link — e esta página continuava mostrando o estado antigo até
   * um F5. Recarrega a cada 4s e ao voltar o foco da aba.
   *
   * Fica parado enquanto há um formulário aberto (opções avançadas, condição de
   * pagamento, edição de item): recarregar no meio da digitação apagaria o que
   * a pessoa está escrevendo.
   */
  useEffect(() => {
    const editando = avancadoOpen || !!pgto || !!itemEdit
    if (editando) return
    const atualizar = () => { if (!document.hidden) fetchProposal(true) }
    const timer = setInterval(atualizar, 800)
    window.addEventListener("focus", atualizar)
    return () => { clearInterval(timer); window.removeEventListener("focus", atualizar) }
  }, [fetchProposal, avancadoOpen, pgto, itemEdit])

  function copyLink() {
    if (!proposal?.link_token) return
    const url = linkPublico(proposal.link_token)
    navigator.clipboard.writeText(url).then(() => {
      setLinkCopied(true)
      setTimeout(() => setLinkCopied(false), 2500)
    })
  }

  async function enviarProposta() {
    if (!proposal) return
    setEnviando(true)
    try {
      const res = await fetch(`/api/propostas/${id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "ENVIADA" }),
      })
      if (res.ok) {
        // Copia o link automaticamente para facilitar o envio
        if (proposal.link_token) {
          const url = linkPublico(proposal.link_token)
          try { await navigator.clipboard.writeText(url) } catch {}
        }
        // O servidor diz se o e-mail ao cliente saiu — sem isso o vendedor
        // acha que enviou e a proposta ficou parada.
        const j = await res.json().catch(() => ({}))
        setEmailStatus(j?.emailCliente ?? null)
        setEnviadaToast(true)
        setTimeout(() => setEnviadaToast(false), 6000)
        await fetchProposal()
      }
    } finally {
      setEnviando(false)
      setConfirmEnvio(false)
    }
  }

  /* Produtos parecidos encontrados no Olist, aguardando decisão.
     Nome parecido NÃO decide sozinho: "Módulo X-2" e "Módulo X-4" batem 96% de
     semelhança e são produtos diferentes. Cadastrar errado divide o estoque
     entre clones e ninguém descobre até faltar peça. */
  const [duplicados, setDuplicados] = useState<
    { nome: string; sku: string | null; semelhanca?: number; candidato?: { id: string; nome: string; sku?: string | null } }[] | null
  >(null)
  const [verificando, setVerificando] = useState(false)

  /** Confere os produtos no Olist antes de mandar o pedido. */
  async function conferirProdutos() {
    if (!proposal) return
    setVerificando(true)
    setOlistResultado(null)
    try {
      const r = await fetch("/api/integracoes/olist/produtos/verificar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ proposalId: id }),
      })
      const j = await r.json().catch(() => ({}))
      /* Conferência é uma proteção contra produto duplicado, não uma condição
         para vender. Falhando ela, o fluxo segue para o cadastro — que tem o
         próprio caminho alternativo. Antes o `return` aqui matava o envio
         inteiro, e era o que travava quem não tinha o OAuth autorizado. */
      if (r.ok && j.parecidos?.length) {
        setDuplicados(j.parecidos)
        return
      }
      if (!(await cadastrarProdutos())) return
      await enviarTiny()
    } catch {
      setOlistResultado({ ok: false, erro: "Falha de conexão ao conferir os produtos." })
    } finally {
      setVerificando(false)
    }
  }

  /* Cria no Olist os produtos que ainda não existem lá. Sem isto o pedido
     entrava com itens avulsos: a API aceita código que não está no cadastro, o
     pedido aparece no Olist e a tela de Produtos continua vazia — sem produto
     não há controle de estoque nem nota. */
  async function cadastrarProdutos() {
    try {
      const r = await fetch("/api/integracoes/olist/produtos/cadastrar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ proposalId: id }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) {
        setOlistResultado({ ok: false, erro: j.error || "Não foi possível cadastrar os produtos no Olist." })
        return false
      }
      if (j.falhas?.length) {
        const lista = j.falhas.map((f: { sku: string; erro: string }) => `${f.sku}: ${f.erro}`).join(" · ")
        setOlistResultado({ ok: false, erro: `Produtos não cadastrados, ${lista}` })
        return false
      }
      return true
    } catch {
      setOlistResultado({ ok: false, erro: "Falha de conexão ao cadastrar os produtos." })
      return false
    }
  }

  async function enviarTiny() {
    if (!proposal) return
    setDuplicados(null)
    setEnviandoTiny(true)
    setOlistResultado(null)
    try {
      const res = await fetch("/api/integracoes/tiny/sincronizar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ proposalId: id }),
      })
      const d = await res.json().catch(() => ({}))
      // Antes isto era um alert do navegador — feio e sem o número do pedido
      // em destaque. Agora abre um diálogo com o resultado.
      if (res.ok) {
        setOlistResultado({ ok: true, numeroPedido: d?.numeroPedido ?? null })
        await fetchProposal()
      } else {
        setOlistResultado({ ok: false, erro: d?.error || "Falha ao enviar para o Olist." })
      }
    } catch {
      setOlistResultado({ ok: false, erro: "Falha de conexão com o Olist." })
    } finally {
      setEnviandoTiny(false)
    }
  }

  function abrirWhatsApp() {
    if (!proposal?.link_token) return
    const url = linkPublico(proposal.link_token)
    const msg = `Olá! Segue a proposta ${proposal.numero}. Você pode visualizar e responder pelo link: ${url}`
    window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, "_blank")
  }

  async function emitirNfe() {
    if (!proposal) return
    const firstInst = proposal.installments[0]
    if (!firstInst) return
    setEmittingNfe(true)
    await fetch(`/api/financeiro/${firstInst.id}/nfe`, { method: "POST" })
    setEmittingNfe(false)
    setNfeToast(true)
    setTimeout(() => setNfeToast(false), 3000)
  }

  async function restoreVersion(versionId: string) {
    const ok = await confirmar({
      titulo: "Restaurar esta versão?",
      texto: "O estado atual é salvo como uma nova versão antes, então nada se perde.",
      confirmar: "Restaurar",
    })
    if (!ok) return
    setRestoringId(versionId)
    try {
      await fetch(`/api/propostas/${id}/versoes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ versionId }),
      })
      fetchProposal()
    } finally {
      setRestoringId(null)
    }
  }

  async function abrirAditivoDialog() {
    setBuscaObra("")
    setSelectedObraId(proposal?.obraId ?? "")
    setAditivoOpen(true)
    const res = await fetch("/api/obras")
    if (res.ok) {
      const { obras } = await res.json()
      setObrasDisponiveis(obras)
    }
  }

  async function vincularAditivo() {
    if (!selectedObraId) return
    setVinculating(true)
    try {
      const res = await fetch(`/api/propostas/${id}/vincular-aditivo`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ obraId: selectedObraId }),
      })
      if (res.ok) {
        setAditivoOpen(false)
        setAditivoToast(true)
        setTimeout(() => setAditivoToast(false), 3500)
        await fetchProposal()
      }
    } finally {
      setVinculating(false)
    }
  }

  async function desvincularAditivo() {
    setVinculating(true)
    try {
      const res = await fetch(`/api/propostas/${id}/vincular-aditivo`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ obraId: null }),
      })
      if (res.ok) {
        setAditivoOpen(false)
        await fetchProposal()
      }
    } finally {
      setVinculating(false)
    }
  }

  if (loading) {
    return <div className="p-6 flex justify-center"><PageLoader /></div>
  }
  if (!proposal) return null

  // payment_methods é gravado como JSON de strings pelo wizard.
  const formasPagamento: string[] = (() => {
    try {
      const j = JSON.parse(proposal.payment_methods || "[]")
      return Array.isArray(j) ? j.filter(Boolean).map(String) : []
    } catch { return [] }
  })()

  /* Etapas do kanban em que a proposta ainda aceita mudança de conteúdo.
     Depois de ACEITA ela virou compromisso: obra e financeiro já partiram
     desses números. */
  const podeEditar = proposal.status === "RASCUNHO" || proposal.status === "EM_REVISAO"

  /* Faturamento: a condição vem pronta da proposta e pode ser ajustada aqui,
     depois de acertar com o cliente. Sem ela o envio ao Olist fica travado. */
  const emFaturamento = ["ACEITA", "EM_CONTRATO", "EM_FATURAMENTO"].includes(proposal.status)
  const pagamentoDefinido = !!proposal.forma_pagamento
  const maxParcelasFat = FORMAS_FATURAMENTO.find(f => f.id === pgto?.forma)?.max ?? 1
  /* Sem cadastro completo a nota é recusada no Olist e alguém perde tempo
     descobrindo o porquê — por isso trava aqui. A mesma função decide no
     servidor: a cópia da regra que existia nesta linha aceitava documento
     inválido e UF em branco, e o contrato saía assim. */
  const dadosCompletos = faturamentoCompleto(proposal)
  const faltaFaturamento = faltaNoFaturamento(proposal)

  /* Itens escritos na visita que ainda não viraram produto do catálogo.
     O Olist precisa de SKU: sem cadastro o pedido vai com item que o estoque e
     a compra não sabem localizar. Trava o envio e dá o caminho para resolver. */
  const avulsosPendentes = ambientesAtivos
    .flatMap(e => e.proposalItems)
    .filter(i => i.avulso && !i.avulso_resolvido_em)

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      {/* Produtos parecidos no Olist, quem decide é uma pessoa.
          A comparação por nome acerta a maioria, mas erra no que importa:
          modelos da mesma linha ("Módulo X-2" vs "X-4") passam de 96%. */}
      <Dialog open={!!duplicados} onOpenChange={o => !o && setDuplicados(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Produtos parecidos no Olist</DialogTitle>
            <DialogDescription>
              Encontramos itens com nome semelhante já cadastrados. Confira antes de enviar —
              cadastrar duplicado divide o estoque entre os dois.
            </DialogDescription>
          </DialogHeader>

          <div className="max-h-[50vh] space-y-3 overflow-y-auto">
            {duplicados?.map((d, i) => (
              <div key={i} className="rounded-xl border border-border/60 bg-muted/30 p-3.5">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-[11px] uppercase tracking-wide text-muted-foreground">Na proposta</p>
                    <p className="truncate text-sm font-semibold text-foreground">{d.nome}</p>
                    {d.sku && <p className="font-mono text-[11px] text-muted-foreground">{d.sku}</p>}
                  </div>
                  {d.semelhanca != null && (
                    <span className="shrink-0 rounded-full bg-warning/15 px-2 py-0.5 text-[11px] font-semibold text-warning">
                      {d.semelhanca}% parecido
                    </span>
                  )}
                </div>
                <div className="mt-2.5 border-t border-border/50 pt-2.5">
                  <p className="text-[11px] uppercase tracking-wide text-muted-foreground">Já existe no Olist</p>
                  <p className="truncate text-sm text-foreground">{d.candidato?.nome}</p>
                  {d.candidato?.sku && (
                    <p className="font-mono text-[11px] text-muted-foreground">{d.candidato.sku}</p>
                  )}
                </div>
              </div>
            ))}
          </div>

          <DialogFooter className="gap-2 sm:justify-between">
            <Button variant="outline" onClick={() => setDuplicados(null)}>
              Cancelar e revisar
            </Button>
            <Button
              onClick={async () => { if (await cadastrarProdutos()) await enviarTiny() }}
              disabled={enviandoTiny}>
              {enviandoTiny ? "Enviando..." : "Conferi, pode cadastrar e enviar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={confirmarAssinatura} onOpenChange={setConfirmarAssinatura}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>O contrato foi assinado?</DialogTitle></DialogHeader>
          <div className="space-y-2 px-5 py-4 text-sm text-muted-foreground sm:px-6">
            <p>
              Confirme apenas se o documento assinado já está em mãos. Isso libera a
              conclusão da proposta <span className="font-semibold text-foreground">{proposal.numero}</span>.
            </p>
            <p className="text-[13px]">Não dá para desfazer.</p>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setConfirmarAssinatura(false)}>Ainda não</Button>
            <Button onClick={confirmarContratoAssinado} disabled={assinando}>
              {assinando ? "Registrando..." : "Sim, foi assinado"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={confirmarEnvioContrato} onOpenChange={setConfirmarEnvioContrato}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Enviar o contrato ao cliente</DialogTitle></DialogHeader>
          <div className="space-y-3 px-5 py-4 sm:px-6">
            <p className="text-sm text-muted-foreground">
              O cliente recebe o contrato da proposta{" "}
              <span className="font-semibold text-foreground">{proposal.numero}</span> por e-mail.
            </p>
            <div className="space-y-1.5">
              <Label>Enviar para</Label>
              <Input value={emailContrato} onChange={e => setEmailContrato(e.target.value)}
                placeholder="email@cliente.com.br" />
              <p className="text-[12px] text-muted-foreground">
                Vem do cadastro de faturamento. Dá para corrigir aqui sem voltar à proposta.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setConfirmarEnvioContrato(false)}>Cancelar</Button>
            <Button onClick={enviarContratoAoCliente}
              disabled={enviandoContrato || !emailContrato.trim()}>
              {enviandoContrato ? "Enviando..." : "Enviar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={escolherModelo} onOpenChange={setEscolherModelo}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Qual modelo de contrato?</DialogTitle></DialogHeader>
          <div className="space-y-2 px-5 py-4 sm:px-6">
            {modelosContrato.map(m => (
              <button key={m.id}
                onClick={() => {
                  window.open(`/api/propostas/${id}/contrato?modeloId=${m.id}`, "_blank")
                  setEscolherModelo(false)
                }}
                className="flex w-full items-center gap-3 rounded-xl border border-border p-3 text-left transition-colors hover:bg-muted">
                <FileSignature className="h-4 w-4 shrink-0 text-muted-foreground" />
                <span className="truncate text-sm text-foreground">{m.nome}</span>
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Toast NF-e */}
      {nfeToast && (
        <div className="fixed top-4 right-4 z-50 bg-amber-600 text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2">
          <CheckCheck className="w-4 h-4" />
          NF-e preparada para emissão!
        </div>
      )}

      {/* Toast Aditivo vinculado */}
      {aditivoToast && (
        <div className="fixed top-4 right-4 z-50 bg-amber-600 text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2">
          <Link2 className="w-4 h-4" />
          Proposta vinculada como aditivo da obra!
        </div>
      )}

      {/* Toast Enviada */}
      {enviadaToast && (
        <div className="fixed top-4 right-4 z-50 max-w-sm rounded-xl bg-primary px-4 py-3 text-primary-foreground shadow-lg">
          <p className="flex items-center gap-2 font-medium">
            <CheckCheck className="h-4 w-4 shrink-0" />
            Proposta enviada, link copiado
          </p>
          {/* O vendedor precisa saber se o e-mail saiu de verdade. */}
          {emailStatus === "enviado" && (
            <p className="mt-1 pl-6 text-[13px] opacity-90">E-mail enviado ao cliente.</p>
          )}
          {emailStatus === "sem_email" && (
            <p className="mt-1 pl-6 text-[13px] opacity-90">Cliente sem e-mail. Mande o link pelo WhatsApp.</p>
          )}
          {emailStatus === "falhou" && (
            <p className="mt-1 pl-6 text-[13px] opacity-90">O e-mail não saiu. Mande o link direto ao cliente.</p>
          )}
          {emailStatus === "nao_configurado" && (
            <p className="mt-1 pl-6 text-[13px] opacity-90">Envio de e-mail não configurado. Mande o link direto.</p>
          )}
        </div>
      )}

      {/* Modal de confirmação de envio */}
      {/* Resultado do envio ao Olist */}
      <Dialog open={!!olistResultado} onOpenChange={o => { if (!o) setOlistResultado(null) }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <div className={`mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full ${
              olistResultado?.ok ? "bg-ios-green/15" : "bg-ios-red/15"
            }`}>
              {olistResultado?.ok
                ? <CheckCheck className="h-7 w-7 text-ios-green" />
                : <AlertCircle className="h-7 w-7 text-ios-red" />}
            </div>
            <DialogTitle className="text-center text-xl">
              {olistResultado?.ok ? "Pedido enviado ao Olist" : "Não foi possível enviar"}
            </DialogTitle>
          </DialogHeader>

          <div className="px-5 pb-1 text-center text-sm text-muted-foreground sm:px-6">
            {olistResultado?.ok ? (
              <>
                {olistResultado.numeroPedido && (
                  <p className="mb-3">
                    <span className="block text-xs uppercase tracking-wide text-muted-fg">Número do pedido</span>
                    <span className="mt-0.5 block text-2xl font-bold tabular-nums text-foreground">
                      {olistResultado.numeroPedido}
                    </span>
                  </p>
                )}
                <p>
                  A proposta passou para <b className="text-foreground">Em Faturamento</b>.
                  O pedido está no Olist em Vendas → Pedidos.
                </p>
              </>
            ) : (
              <p className="text-ios-red">{olistResultado?.ok === false ? olistResultado.erro : ""}</p>
            )}
          </div>

          <DialogFooter className="gap-2 px-5 pb-4 sm:px-6">
            {olistResultado?.ok === false && (
              <Button variant="outline" onClick={() => { setOlistResultado(null); enviarTiny() }}>
                Tentar de novo
              </Button>
            )}
            <Button onClick={() => setOlistResultado(null)}>Fechar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Exclusão definitiva, só ADMIN chega aqui */}
      <Dialog open={confirmExcluir} onOpenChange={o => { if (!o) { setConfirmExcluir(false); setErroExcluir("") } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-ios-red/15">
              <Trash2 className="h-6 w-6 text-ios-red" />
            </div>
            <DialogTitle className="text-center text-xl">Excluir {proposal.numero}?</DialogTitle>
            <DialogDescription className="text-center">
              A proposta e todo o conteúdo dela (itens, parcelas, versões e páginas extras)
              serão apagados. Não dá para desfazer.
            </DialogDescription>
          </DialogHeader>
          {erroExcluir && (
            <p className="px-5 text-center text-sm text-ios-red sm:px-6">{erroExcluir}</p>
          )}
          <DialogFooter className="gap-2 px-5 pb-4 sm:px-6">
            <Button variant="outline" onClick={() => setConfirmExcluir(false)}>Cancelar</Button>
            <Button onClick={excluirProposta} disabled={excluindo}
              className="gap-1.5 bg-ios-red text-background hover:bg-ios-red/90">
              {excluindo ? <><RefreshCw className="h-4 w-4 animate-spin" /> Excluindo…</> : "Excluir definitivamente"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={modeloOpen} onOpenChange={setModeloOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-sky-500/15">
              <Copy className="h-7 w-7 text-sky-400" />
            </div>
            <DialogTitle className="text-center text-xl">
              {modeloSalvo ? "Modelo salvo" : "Salvar como modelo"}
            </DialogTitle>
            <DialogDescription className="text-center">
              {modeloSalvo
                ? "Ele já aparece na lista de modelos e pode ser usado em qualquer proposta nova."
                : "Guarda ambientes, itens, serviços, desconto, garantia e formas de pagamento. O cliente desta proposta não vai junto."}
            </DialogDescription>
          </DialogHeader>

          {!modeloSalvo && (
            <div className="space-y-1.5 px-5 sm:px-6">
              <Label htmlFor="nome-modelo">Nome do modelo</Label>
              <Input id="nome-modelo" value={modeloNome} autoFocus
                onChange={e => setModeloNome(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter" && !salvandoModelo) salvarComoModelo() }}
                placeholder="Automação residencial completa" />
              <p className="text-xs text-muted-foreground">
                É por este nome que alguém vai encontrar o modelo daqui a três meses.
              </p>
            </div>
          )}

          {erroModelo && (
            <p className="px-5 text-center text-sm text-ios-red sm:px-6">{erroModelo}</p>
          )}

          <DialogFooter className="gap-2 px-5 pb-4 sm:px-6">
            {modeloSalvo ? (
              <>
                <Button variant="outline" onClick={() => setModeloOpen(false)}>Fechar</Button>
                <Button onClick={() => router.push("/templates")} className="gap-1.5">Ver modelos</Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={() => setModeloOpen(false)} disabled={salvandoModelo}>
                  Cancelar
                </Button>
                <Button onClick={salvarComoModelo} disabled={salvandoModelo || !modeloNome.trim()} className="gap-1.5">
                  {salvandoModelo
                    ? <><RefreshCw className="h-4 w-4 animate-spin" /> Salvando…</>
                    : <><Copy className="h-4 w-4" /> Salvar modelo</>}
                </Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={confirmEnvio} onOpenChange={setConfirmEnvio}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <div className="mx-auto mb-3 w-14 h-14 rounded-full bg-purple-500/15 flex items-center justify-center">
              <Send className="w-7 h-7 text-sky-400" />
            </div>
            <DialogTitle className="text-center text-xl">Enviar proposta?</DialogTitle>
            <DialogDescription className="text-center pt-1">
              A proposta <span className="text-white font-semibold">{proposal.numero}</span> será marcada
              como <span className="text-sky-400 font-semibold">ENVIADA</span> e o link do cliente
              será copiado automaticamente.
            </DialogDescription>
          </DialogHeader>

          <div className="bg-card/60 rounded-lg p-4 my-2 space-y-1 text-center">
            <p className="text-muted-foreground text-xs uppercase tracking-wide">Destinatário</p>
            <p className="text-white font-medium">{proposal.client_name}</p>
            {proposal.client_email && (
              <p className="text-muted-foreground text-sm">{proposal.client_email}</p>
            )}
          </div>

          <DialogFooter className="gap-2 sm:gap-2">
            <Button
              variant="outline"
              onClick={() => setConfirmEnvio(false)}
              disabled={enviando}
              className="border-border text-muted-foreground/70 hover:text-white flex-1"
            >
              Cancelar
            </Button>
            <Button
              onClick={enviarProposta}
              disabled={enviando}
              className="bg-amber-600 hover:bg-amber-700 text-white flex-1 gap-1.5"
            >
              {enviando ? (
                <><RefreshCw className="w-4 h-4 animate-spin" /> Enviando...</>
              ) : (
                <><Send className="w-4 h-4" /> Confirmar Envio</>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog: Vincular como Aditivo */}
      <Dialog open={aditivoOpen} onOpenChange={setAditivoOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <div className="mx-auto mb-3 w-14 h-14 rounded-full bg-purple-500/15 flex items-center justify-center">
              <HardHat className="w-7 h-7 text-amber-400" />
            </div>
            <DialogTitle className="text-center text-xl">Vincular como Aditivo</DialogTitle>
            <DialogDescription className="text-center pt-1">
              Selecione a obra à qual esta proposta será adicionada como aditivo.
              Os itens serão marcados com <span className="text-amber-400 font-semibold">is_aditivo = true</span> para
              distinção do contrato original.
            </DialogDescription>
          </DialogHeader>

          {/* Sugestão automática */}
          {proposal.client_name && obrasDisponiveis.some(o =>
            o.client_name.toLowerCase().includes(proposal.client_name.toLowerCase().split(" ")[0])
          ) && (
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3 text-sm text-amber-300 flex items-center gap-2">
              <Search className="w-4 h-4 flex-shrink-0" />
              Sugestão automática: encontramos obras com o nome <strong className="ml-1">{proposal.client_name.split(" ")[0]}</strong>
            </div>
          )}

          {/* Busca */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              className="w-full bg-card border border-border rounded-xl pl-9 pr-4 py-2 text-sm text-white placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-amber-500"
              placeholder="Buscar obra por cliente..."
              value={buscaObra}
              onChange={e => setBuscaObra(e.target.value)}
            />
          </div>

          {/* Lista de obras */}
          <div className="max-h-64 overflow-y-auto space-y-1.5">
            {obrasDisponiveis
              .filter(o => !buscaObra || o.client_name.toLowerCase().includes(buscaObra.toLowerCase()))
              .map(o => {
                const sugerida = o.client_name.toLowerCase().includes(
                  proposal.client_name.toLowerCase().split(" ")[0]
                )
                return (
                  <button
                    key={o.id}
                    onClick={() => setSelectedObraId(o.id)}
                    className={`w-full text-left rounded-lg p-3 flex items-center justify-between gap-2 border transition-colors ${
                      selectedObraId === o.id
                        ? "bg-amber-500/20 border-amber-500/60 text-white"
                        : "bg-card border-border text-muted-foreground/70 hover:border-border"
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <HardHat className="w-4 h-4 text-amber-400 flex-shrink-0" />
                      <div className="min-w-0">
                        <p className="font-medium truncate">{o.client_name}</p>
                        {o.etapa && <p className="text-xs text-muted-foreground truncate">{o.etapa}</p>}
                      </div>
                    </div>
                    {sugerida && (
                      <span className="text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full flex-shrink-0">
                        Sugerida
                      </span>
                    )}
                  </button>
                )
              })}
            {obrasDisponiveis.filter(o => !buscaObra || o.client_name.toLowerCase().includes(buscaObra.toLowerCase())).length === 0 && (
              <p className="text-center text-muted-foreground text-sm py-6">Nenhuma obra encontrada</p>
            )}
          </div>

          <DialogFooter className="gap-2 flex-col sm:flex-row">
            {proposal.obraId && (
              <Button
                variant="outline"
                onClick={desvincularAditivo}
                disabled={vinculating}
                className="border-red-700/50 text-red-400 hover:text-red-300 gap-1.5"
              >
                <X className="w-4 h-4" /> Desvincular
              </Button>
            )}
            <Button variant="outline" onClick={() => setAditivoOpen(false)} disabled={vinculating}
              className="border-border text-muted-foreground/70 hover:text-white flex-1">
              Cancelar
            </Button>
            <Button
              onClick={vincularAditivo}
              disabled={vinculating || !selectedObraId}
              className="bg-amber-600 hover:bg-amber-700 text-white flex-1 gap-1.5"
            >
              {vinculating
                ? <><RefreshCw className="w-4 h-4 animate-spin" /> Vinculando...</>
                : <><Link2 className="w-4 h-4" /> Confirmar Vínculo</>
              }
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog: Opções Avançadas */}
      <Dialog open={avancadoOpen} onOpenChange={setAvancadoOpen}>
        {/* Largura de trabalho, não de aviso: cada serviço tem nome, tipo,
            valor, escopo e o resultado na mesma linha. Em `max-w-lg` o nome
            e o "sobre <categoria>" ficavam espremidos contra os campos. */}
        <DialogContent className="max-w-[min(calc(100vw-32px),820px)]">
          <DialogHeader>
            <div className="mx-auto mb-3 w-14 h-14 rounded-full bg-purple-500/15 flex items-center justify-center">
              <Settings2 className="w-7 h-7 text-purple-400" />
            </div>
            <DialogTitle className="text-center text-xl">Opções Avançadas</DialogTitle>
            <DialogDescription className="text-center pt-1">
              Alterações restritas a <span className="text-purple-400 font-semibold">ADMIN / FINANCEIRO</span>.
              A versão atual será salva antes de aplicar.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 px-5 py-4 sm:px-8">
            {/* Status */}
            <div className="space-y-1">
              <label className="text-muted-foreground/70 text-sm font-medium">Status da proposta</label>
              <select value={avancadoForm.status} onChange={e => setAvancadoForm(f => ({ ...f, status: e.target.value as ProposalStatus }))}
                className="w-full h-9 px-3 rounded-xl bg-card border border-border text-white text-sm focus:outline-none focus:ring-1 focus:ring-purple-500">
                {/* Rótulo legível: o valor cru do banco (EM_REVISAO) não é para
                    a tela. */}
                {/* Na ordem do processo: aceita, assina o contrato, e só então
                    fatura. */}
                {(["RASCUNHO","ENVIADA","LIDA","EM_REVISAO","ACEITA","EM_CONTRATO","EM_FATURAMENTO","CONCLUIDA","CANCELADA","PROPOSTA_PERDIDA"] as const).map(s =>
                  <option key={s} value={s}>{STATUS_LABEL[s]}</option>
                )}
              </select>
            </div>

            {/* Composição do valor, mesmo desenho do escopo no wizard:
                serviços, desconto e as opções da proposta, sem tabela cheia de
                percentuais que ninguém preenchia. */}
            <div className="space-y-5">

              {/* Serviços */}
              <div className="space-y-2">
                <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                  Serviços e mão de obra
                </p>
                {/* O serviço é o valor que se escolhe, em reais. O percentual
                    e o "sobre toda a proposta" saíram: serviço lançado como %
                    do escopo mudava de preço sozinho a cada item que entrava, e
                    quem fechava não sabia mais que número tinha combinado.
                    Proposta antiga lançada em percentual aparece já convertida
                    — o mesmo dinheiro, agora escrito como ele é cobrado. */}
                {servicos.map((sv, i) => (
                  <div key={sv.id} className="flex items-center gap-2 rounded-xl bg-surface-1 px-3 py-2">
                    <input value={sv.nome}
                      onChange={e => setServicos(l => l.map((x, j) => j === i ? { ...x, nome: e.target.value } : x))}
                      placeholder="Nome do serviço"
                      className="h-9 min-w-0 flex-1 bg-transparent text-sm text-foreground outline-none" />
                    <span className="shrink-0 text-[13px] text-muted-foreground">R$</span>
                    <CampoValor
                      value={sv.tipo === "percentual" ? (valorDoSv(sv) || 0).toFixed(2) : sv.valor}
                      onChange={val => setServicos(l => l.map((x, j) =>
                        j === i ? { ...x, tipo: "fixo" as const, valor: val } : x))}
                      placeholder="0,00"
                      className="h-7 w-24 shrink-0 bg-transparent text-right text-[15px] font-semibold tabular-nums text-foreground outline-none" />
                    <button type="button" onClick={() => setServicos(l => l.filter((_, j) => j !== i))}
                      className="shrink-0 text-muted-foreground/50 hover:text-ios-red"><X className="h-4 w-4" /></button>
                  </div>
                ))}
                <button type="button"
                  onClick={() => setServicos(l => [...l, { id: `sv_${l.length + 1}_${Math.round(subtotalProdutos)}`, nome: "", tipo: "fixo", valor: "" }])}
                  className="w-full rounded-xl border border-dashed border-border py-2 text-[13px] text-muted-foreground transition-colors hover:text-foreground">
                  + Adicionar servico
                </button>
                <div className="flex items-center justify-between rounded-xl bg-surface-1 px-4 py-2.5">
                  <span className="text-sm text-muted-foreground">Total de servicos</span>
                  <span className="text-sm font-semibold tabular-nums text-foreground">{brl(totalServicos)}</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Produtos: {brl(subtotalProdutosPrevisto)}
                  {Math.abs(subtotalProdutosPrevisto - subtotalProdutos) > 0.01 && (
                    <span className="text-muted-foreground/60"> · antes {brl(subtotalProdutos)}</span>
                  )}
                </p>
              </div>

              {/* Serviço da CATEGORIA, o que já está dentro do preço do produto.

                  Control4 com 30% cadastrado entra com 30% em cada produto
                  Control4 — e some de vista: o item custa mais que a tabela e
                  não havia onde conferir o porquê. Aqui ele aparece com a conta
                  exata (a fatia do percentual dentro de um preço que já o
                  contém é total × r/(1+r), não total × r) e, quando o banco
                  guarda o que cada proposta embutiu, pode ser mudado só nesta
                  proposta: a gravação reescreve o preço dos itens da categoria.

                  Não soma no total: já está no preço de cada item. */}
              {embutidosPorCategoria.length > 0 && (
                <div className="space-y-2">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                    Já incluído no preço dos produtos
                  </p>
                  {embutidosPorCategoria.map(cat => (
                    <div key={cat.id} className="space-y-1.5 rounded-xl border border-dashed border-border/60 px-3 py-2.5">
                      <div className="flex items-baseline justify-between gap-3">
                        <span className="text-sm text-foreground">{cat.nome}</span>
                        <span className="text-xs tabular-nums text-muted-foreground">
                          {cat.qtd} {cat.qtd === 1 ? "item" : "itens"} · {brl(cat.totalNovo)}
                          {Math.abs(cat.totalNovo - cat.totalAtual) > 0.01 && (
                            <span className="text-muted-foreground/60"> · antes {brl(cat.totalAtual)}</span>
                          )}
                        </span>
                      </div>

                      {cat.editados.length === 0 && (
                        <p className="text-xs text-muted-foreground/60">Nenhum serviço nesta categoria.</p>
                      )}

                      {cat.editados.map((sv, i) => (
                        <div key={`${cat.id}-${i}`} className="flex items-center gap-2">
                          <input value={sv.nome}
                            onChange={e => definirServicosDaCategoria(cat.id,
                              cat.editados.map((x, j) => j === i ? { ...x, nome: e.target.value } : x))}
                            placeholder="Nome do serviço"
                            className="h-9 min-w-0 flex-1 bg-transparent text-sm text-foreground outline-none" />
                          {/* O percentual fica: aqui é uma taxa sobre o preço de
                              cada produto da categoria, não um valor combinado
                              com o cliente. */}
                          <div className="inline-flex h-9 shrink-0 items-center rounded-lg border border-border bg-muted p-0.5 text-[12px]">
                            {(["percentual", "fixo"] as const).map(t => (
                              <button key={t} type="button"
                                onClick={() => definirServicosDaCategoria(cat.id,
                                  cat.editados.map((x, j) => j === i ? { ...x, tipo: t } : x))}
                                className={`h-8 rounded-md px-2 ${sv.tipo === t ? "bg-background font-medium text-foreground" : "text-muted-foreground"}`}>
                                {t === "percentual" ? "%" : "R$"}
                              </button>
                            ))}
                          </div>
                          <CampoValor value={String(sv.valor ?? "")} moeda={sv.tipo === "fixo"}
                            onChange={val => definirServicosDaCategoria(cat.id,
                              cat.editados.map((x, j) => j === i ? { ...x, valor: val } : x))}
                            className="h-9 w-20 shrink-0 rounded-lg border border-border bg-muted px-2 text-center text-sm tabular-nums text-foreground outline-none" />
                          <span className="w-24 shrink-0 text-right text-[13px] tabular-nums text-muted-foreground">
                            {brl(cat.linhas[i]?.embutido ?? 0)}
                          </span>
                          <button type="button"
                            onClick={() => definirServicosDaCategoria(cat.id, cat.editados.filter((_, j) => j !== i))}
                            className="shrink-0 text-muted-foreground/50 hover:text-ios-red"><X className="h-4 w-4" /></button>
                        </div>
                      ))}

                      <button type="button"
                        onClick={() => definirServicosDaCategoria(cat.id,
                          [...cat.editados, { nome: "", tipo: "percentual" as const, valor: "" }])}
                        className="w-full rounded-lg border border-dashed border-border py-1.5 text-[12px] text-muted-foreground transition-colors hover:text-foreground">
                        + Adicionar serviço em {cat.nome}
                      </button>
                    </div>
                  ))}
                  <p className="text-[11px] leading-snug text-muted-foreground/60">
                    Não soma no total: já está no preço de cada produto da categoria.
                    Soma embutida: {brl(totalEmbutido)}. Mudar aqui reescreve o preço dos itens
                    desta proposta, só dela — o cadastro da categoria fica como está.
                  </p>
                </div>
              )}

              {/* Desconto sobre o total */}
              <div className="space-y-2">
                <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                  Desconto sobre o total
                </p>
                <div className="flex items-center gap-2">
                  {/* O seletor e a caixa com a mesma altura: um controle mais
                      alto que o outro lia como dois campos de importância
                      diferente, e são o mesmo campo. */}
                  <div className="inline-flex h-9 shrink-0 items-center rounded-lg border border-border bg-muted p-0.5 text-[13px]">
                    {(["PCT", "VALOR"] as const).map(m => (
                      <button key={m} type="button" onClick={() => { setDescontoModo(m); setDescontoTxt(null) }}
                        className={`h-8 rounded-md px-3 transition-colors ${
                          descontoModo === m ? "bg-background font-medium text-foreground" : "text-muted-foreground"
                        }`}>
                        {m === "PCT" ? "%" : "R$"}
                      </button>
                    ))}
                  </div>
                  <input type="text" inputMode="decimal" placeholder="0"
                    value={descontoTxt ?? (Number(avancadoForm.desconto_aplicado) > 0
                      ? (descontoModo === "PCT"
                          ? String(Number(Number(avancadoForm.desconto_aplicado).toFixed(2)))
                          : (baseDesconto * Number(avancadoForm.desconto_aplicado) / 100).toFixed(2)
                        ).replace(".", ",")
                      : "")}
                    onChange={e => {
                      const txt = e.target.value.replace(/[^\d.,]/g, "")
                      setDescontoTxt(txt)
                      const v = numeroBR(txt)
                      // Reais → % sem arredondar: arredondado, o valor voltava diferente do digitado.
                      const pct = descontoModo === "PCT" ? v : (baseDesconto > 0 ? (v / baseDesconto) * 100 : 0)
                      setAvancadoForm(f => ({ ...f, desconto_aplicado: pct > 0 ? String(pct) : "0" }))
                    }}
                    onBlur={() => setDescontoTxt(null)}
                    className="h-9 w-28 rounded-lg border border-border bg-muted px-3 text-center text-sm tabular-nums text-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
                  {Number(avancadoForm.desconto_aplicado) > 0 && (
                    <button type="button" onClick={() => { setDescontoTxt(null); setAvancadoForm(f => ({ ...f, desconto_aplicado: "0" })) }}
                      className="text-muted-foreground/50 hover:text-destructive"><X className="h-4 w-4" /></button>
                  )}
                </div>
                {Number(avancadoForm.desconto_aplicado) > 0 && (
                  <p className="text-[12px] text-muted-foreground">
                    {descontoModo === "PCT"
                      ? `Equivale a ${brl(baseDesconto * Number(avancadoForm.desconto_aplicado) / 100)}`
                      : `Equivale a ${Number(avancadoForm.desconto_aplicado).toFixed(2).replace(".", ",")}%`}
                  </p>
                )}
                <div className="flex items-center justify-between rounded-xl border border-success/25 bg-success/10 px-4 py-3">
                  <span className="text-sm text-muted-foreground">Total com desconto</span>
                  <span className="text-[15px] font-bold tabular-nums text-success">{brl(Math.max(0, escada.totalFinal))}</span>
                </div>
              </div>

              {/* Opções da proposta */}
              <div className="space-y-2">
                <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                  Opções da proposta
                </p>

                <label className="flex cursor-pointer items-center justify-between gap-4 rounded-xl border border-border/50 bg-muted/40 px-3 py-2.5">
                  <span className="min-w-0">
                    <span className="block text-sm text-foreground">Mostrar preço por item</span>
                    <span className="block text-xs text-muted-foreground">
                      Desligado, o cliente vê o escopo e o total geral, sem preço linha a linha.
                    </span>
                  </span>
                  <input type="checkbox" className="ios-checkbox h-5 w-5 shrink-0 cursor-pointer"
                    checked={avancadoForm.exibir_valor_unitario}
                    onChange={e => setAvancadoForm(f => ({ ...f, exibir_valor_unitario: e.target.checked }))} />
                </label>

                <label className="flex cursor-pointer items-center justify-between gap-4 rounded-xl border border-border/50 bg-muted/40 px-3 py-2.5">
                  <span className="min-w-0">
                    <span className="block text-sm text-foreground">Aplicar desconto de campanha</span>
                    <span className="block text-xs text-muted-foreground">
                      {Number(proposal.desconto_campanha) > 0
                        ? `Abate ${brl(Number(proposal.desconto_campanha))} das campanhas vigentes.`
                        : "Nenhuma campanha alcança os itens desta proposta."}
                    </span>
                  </span>
                  <input type="checkbox" className="ios-checkbox h-5 w-5 shrink-0 cursor-pointer"
                    checked={avancadoForm.aplicar_desconto_campanha}
                    onChange={e => setAvancadoForm(f => ({ ...f, aplicar_desconto_campanha: e.target.checked }))} />
                </label>
              </div>
            </div>

            {/* Garantia + Validade */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-muted-foreground/70 text-sm font-medium">Garantia (dias)</label>
                <input type="number" min={0} max={3650}
                  value={avancadoForm.dias_garantia}
                  onChange={e => setAvancadoForm(f => ({ ...f, dias_garantia: e.target.value }))}
                  placeholder="—"
                  className="w-full h-9 px-3 rounded-xl bg-card border border-border text-white text-sm focus:outline-none focus:ring-1 focus:ring-purple-500 placeholder:text-muted-foreground" />
              </div>
              <div className="space-y-1">
                <label className="text-muted-foreground/70 text-sm font-medium">Validade da proposta</label>
                <input type="date" max="9999-12-31"
                  value={avancadoForm.data_expiracao}
                  onChange={e => setAvancadoForm(f => ({ ...f, data_expiracao: e.target.value }))}
                  className="w-full h-9 px-3 rounded-xl bg-card border border-border text-white text-sm focus:outline-none focus:ring-1 focus:ring-purple-500" />
              </div>
            </div>

            {/* Motivo */}
            <div className="space-y-1">
              <label className="text-muted-foreground/70 text-sm font-medium">Motivo da alteração <span className="text-muted-foreground text-xs">(salvo no histórico de versões)</span></label>
              <input value={avancadoForm.motivo_alteracao}
                onChange={e => setAvancadoForm(f => ({ ...f, motivo_alteracao: e.target.value }))}
                placeholder="Ex: Desconto negociado com cliente, ajuste de margem..."
                className="w-full h-9 px-3 rounded-xl bg-card border border-border text-white text-sm focus:outline-none focus:ring-1 focus:ring-purple-500 placeholder:text-muted-foreground" />
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-2">
            <Button variant="outline" onClick={() => setAvancadoOpen(false)} disabled={avancadoSaving}
              className="border-border text-muted-foreground/70 hover:text-white flex-1">Cancelar</Button>
            <Button onClick={salvarAvancado} disabled={avancadoSaving}
              className="bg-purple-600 hover:bg-purple-700 text-white flex-1 gap-1.5">
              {avancadoSaving ? <><RefreshCw className="w-4 h-4 animate-spin" /> Salvando...</> : <><Settings2 className="w-4 h-4" /> Aplicar alterações</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── HEADER MOBILE, estilo mockup (sheet iOS) ── */}
      <div className="md:hidden pb-2">
        <div className="flex items-center justify-between mb-4">
          <button onClick={() => router.push("/propostas")} className="text-ios-blue text-[15px] active:opacity-70">Voltar</button>
          <span className="text-[11px] font-mono uppercase tracking-widest text-muted-fg">
            {proposal.numero}{proposal.versions.length > 0 ? ` · V${proposal.versions.length + 1}` : ""}
          </span>
          {proposal.link_token ? (
            <button onClick={copyLink} className="w-9 h-9 -mr-1 rounded-full bg-surface-2 flex items-center justify-center text-muted-fg active:scale-95">
              {linkCopied ? <CheckCheck className="w-4 h-4 text-ios-green" /> : <Link2 className="w-4 h-4" />}
            </button>
          ) : <span className="w-9" />}
        </div>
        <p className="text-[12px] uppercase tracking-wider text-muted-fg">
          {STATUS_BADGE_LABEL(proposal.status)} · {proposal.project_type}
        </p>
        <h1 className="text-[30px] font-bold text-foreground tracking-tight leading-none mt-1 truncate">{proposal.client_name}</h1>
        <div className="mt-4 pb-4 border-b border-hairline">
          <p className="text-[11px] uppercase tracking-widest text-muted-fg">Valor total</p>
          <p className="text-[38px] font-bold text-foreground tracking-tight leading-none mt-0.5">{brl(Number(proposal.valor_total))}</p>
        </div>
        <div className="mt-4 space-y-3">
          {[
            { icon: <HardHat className="w-4 h-4" />, label: "Responsável", value: proposal.vendedor.nome },
            { icon: <MessageCircle className="w-4 h-4" />, label: "Contato", value: proposal.client_email || "—" },
            { icon: <MapPin className="w-4 h-4" />, label: "Cidade", value: proposal.client_city || "—" },
            { icon: <Clock className="w-4 h-4" />, label: "Validade", value: proposal.data_expiracao ? new Date(proposal.data_expiracao).toLocaleDateString("pt-BR") : "—" },
          ].map(r => (
            <div key={r.label} className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-2 text-muted-fg text-[14px]">{r.icon}{r.label}</span>
              <span className="text-foreground text-[14px] font-medium truncate max-w-[55%]">{r.value}</span>
            </div>
          ))}
        </div>
        {/* Ações do fluxo, também no mobile.
            Ficavam só no header desktop (hidden md:flex) — no celular a
            proposta em Rascunho não tinha "Editar" em lugar nenhum, nem
            "Enviar", nem o menu Mais. Mesmo bloco de baixo, só duplicado
            aqui porque os dois headers têm estrutura muito diferente pra
            compartilhar um wrapper comum sem reescrever os dois. */}
        <div className="mt-4 flex items-center gap-2 flex-wrap">
          {(proposal.status === "RASCUNHO" || proposal.status === "EM_REVISAO") && (
            <>
              <Button
                size="sm"
                onClick={() => router.push(`/propostas/nova?editar=${id}`)}
                variant="outline"
                className="border-amber-600/50 text-amber-400 hover:text-amber-300 hover:bg-amber-500/10 gap-1.5"
              >
                <Pencil className="w-3.5 h-3.5" />
                Editar Proposta
              </Button>
              <Button
                size="sm"
                onClick={() => setConfirmEnvio(true)}
                className="bg-sky-600 hover:bg-sky-700 text-white gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                Enviar Proposta
              </Button>
            </>
          )}
          {((proposal.status === "EM_CONTRATO" && !!proposal.contrato_assinado_em)
            || proposal.status === "EM_FATURAMENTO")
            && !proposal.olist_enviado_em && (
            <Button
              size="sm"
              onClick={conferirProdutos}
              disabled={enviandoTiny || verificando || !pagamentoDefinido || !dadosCompletos
                || avulsosPendentes.length > 0}
              title={!pagamentoDefinido ? "Defina a forma de pagamento antes de enviar"
                : !dadosCompletos ? "Preencha os dados de faturamento antes de enviar"
                : avulsosPendentes.length ? "Cadastre os itens fora do catálogo antes de enviar"
                : undefined}
              className="gap-1.5"
            >
              {verificando
                ? <><RefreshCw className="w-3.5 h-3.5 animate-spin" /> Conferindo...</>
                : enviandoTiny
                ? <><RefreshCw className="w-3.5 h-3.5 animate-spin" /> Enviando...</>
                : <><Send className="w-3.5 h-3.5" /> Enviar para Olist</>}
            </Button>
          )}
          {proposal.status === "ACEITA" && (
            <Button
              size="sm"
              onClick={() => avancarEtapa("EM_CONTRATO")}
              disabled={concluindo || !pagamentoDefinido}
              title={pagamentoDefinido ? undefined : "Defina a condição de pagamento antes de avançar"}
              className="gap-1.5"
            >
              {concluindo
                ? <><RefreshCw className="h-3.5 w-3.5 animate-spin" /> Enviando...</>
                : <><FileSignature className="h-3.5 w-3.5" /> Ir para o contrato</>}
            </Button>
          )}
          {proposal.status === "EM_CONTRATO" && (
            <Button size="sm" variant="outline" className="gap-1.5"
              disabled={!dadosCompletos}
              title={dadosCompletos
                ? undefined
                : `Complete os dados de faturamento antes: falta ${faltaFaturamento.join(", ")}.`}
              onClick={async () => {
                if (!dadosCompletos) {
                  await confirmar({
                    titulo: "Faltam dados de faturamento",
                    texto: `O contrato só sai com o cadastro completo. Falta: ${faltaFaturamento.join(", ")}.`,
                    apenasAviso: true,
                  })
                  return
                }
                if (!modelosContrato.length) {
                  await confirmar({ titulo: "Nenhum modelo de contrato cadastrado. Crie um em Modelos.", apenasAviso: true })
                  return
                }
                if (modelosContrato.length === 1) {
                  window.open(`/api/propostas/${id}/contrato?modeloId=${modelosContrato[0].id}`, "_blank")
                  return
                }
                setEscolherModelo(true)
              }}>
              <FileSignature className="h-3.5 w-3.5" /> Gerar contrato
            </Button>
          )}
          {proposal.status === "EM_CONTRATO" && !!proposal.contrato_gerado_em && (
            <Button size="sm" variant="outline" className="gap-1.5"
              onClick={() => {
                setEmailContrato(proposal.fat_email || proposal.client_email || "")
                setConfirmarEnvioContrato(true)
              }}>
              <Send className="h-3.5 w-3.5" />
              {proposal.contrato_enviado_em ? "Reenviar contrato" : "Enviar ao cliente"}
            </Button>
          )}
          {proposal.status === "EM_CONTRATO" && !proposal.contrato_assinado_em && (
            <Button size="sm" variant="outline" className="gap-1.5"
              disabled={!proposal.contrato_gerado_em}
              title={proposal.contrato_gerado_em ? undefined : "Gere o contrato primeiro"}
              onClick={() => setConfirmarAssinatura(true)}>
              <FileSignature className="h-3.5 w-3.5" /> Contrato assinado
            </Button>
          )}
          {proposal.status === "EM_CONTRATO" && !!proposal.contrato_assinado_em
            && !proposal.olist_contrato_em && (
            <Button size="sm" variant="outline" className="gap-1.5" disabled={enviandoOlist}
              onClick={enviarContratoOlist}>
              {enviandoOlist
                ? <><RefreshCw className="h-3.5 w-3.5 animate-spin" /> Enviando...</>
                : <><Upload className="h-3.5 w-3.5" /> Contrato no Olist</>}
            </Button>
          )}
          {proposal.status === "EM_FATURAMENTO" && (
            <Button size="sm" className="gap-1.5" disabled={concluindo}
              onClick={() => avancarEtapa("CONCLUIDA")}>
              {concluindo
                ? <><RefreshCw className="h-3.5 w-3.5 animate-spin" /> Concluindo...</>
                : <><CheckCheck className="h-3.5 w-3.5" /> Concluir</>}
            </Button>
          )}
          {(!proposal.obraOrigem || proposal.link_token || userRole === "ADMIN") && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" variant="outline" className="gap-1.5 border-border text-muted-foreground/70 hover:text-white">
                  <MoreHorizontal className="w-3.5 h-3.5" /> Mais
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                {/* Pela via interna: o link do cliente pede o código que foi
                    pro e-mail dele, e a equipe não tem esse código. */}
                <DropdownMenuItem onClick={() => window.open(`/documento/${id}`, "_blank")}>
                  <Printer className="w-3.5 h-3.5" /> Imprimir / visualizar
                </DropdownMenuItem>
                {/* Guarda esta proposta como ponto de partida para as próximas.
                    Leva serviços, desconto e formas de pagamento; deixa de fora o
                    cliente, que é o que separa modelo de cópia. */}
                {(userRole === "ADMIN" || userRole === "FINANCEIRO") && (
                  <DropdownMenuItem onClick={abrirSalvarModelo}>
                    <Copy className="w-3.5 h-3.5" /> Salvar como modelo
                  </DropdownMenuItem>
                )}
                {userRole === "ADMIN" && (
                  <>
                    {(!proposal.obraOrigem || proposal.link_token) && <DropdownMenuSeparator />}
                    <DropdownMenuItem onClick={() => setConfirmExcluir(true)} className="text-ios-red focus:text-ios-red">
                      <Trash2 className="w-3.5 h-3.5" /> Excluir
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>

      {/* Header desktop */}
      <div className="hidden md:flex items-start justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" onClick={() => router.push("/propostas")}
            className="text-muted-foreground hover:text-white h-9 w-9 p-0">
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold text-white">{proposal.numero}</h1>
              <Badge variant={STATUS_BADGE[proposal.status]}>{STATUS_BADGE_LABEL(proposal.status)}</Badge>
            </div>
            <p className="text-muted-foreground mt-1">{proposal.client_name}</p>
          </div>
        </div>
        <div className="text-right space-y-2">
          <p className="text-3xl font-bold text-green-400">{brl(Number(proposal.valor_total))}</p>
          <p className="text-muted-foreground text-sm">Vendedor: {proposal.vendedor.nome}</p>
          {/* Só as ações do fluxo principal ficam à mostra. Aditivo, copiar
              link e excluir são raras — viravam ruído do lado das que
              importam no dia a dia, então foram para o menu "Mais". */}
          <div className="flex items-center gap-2 justify-end mt-2 flex-wrap">
            {(proposal.status === "RASCUNHO" || proposal.status === "EM_REVISAO") && (
              <>
                <Button
                  size="sm"
                  onClick={() => router.push(`/propostas/nova?editar=${id}`)}
                  variant="outline"
                  className="border-amber-600/50 text-amber-400 hover:text-amber-300 hover:bg-amber-500/10 gap-1.5"
                >
                  <Pencil className="w-3.5 h-3.5" />
                  Editar Proposta
                </Button>
                <Button
                  size="sm"
                  onClick={() => setConfirmEnvio(true)}
                  className="bg-sky-600 hover:bg-sky-700 text-white gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  Enviar Proposta
                </Button>
              </>
            )}
            {/* Enviar ao Olist é o que move para Faturamento, e faturar só
                depois do contrato assinado. */}
            {((proposal.status === "EM_CONTRATO" && !!proposal.contrato_assinado_em)
              || proposal.status === "EM_FATURAMENTO")
              && !proposal.olist_enviado_em && (
              <Button
                size="sm"
                onClick={conferirProdutos}
                /* Sem pagamento definido o pedido chega no Olist sem condição e
                   alguém precisa corrigir lá — por isso trava aqui. */
                disabled={enviandoTiny || verificando || !pagamentoDefinido || !dadosCompletos
                  || avulsosPendentes.length > 0}
                title={!pagamentoDefinido ? "Defina a forma de pagamento antes de enviar"
                  : !dadosCompletos ? "Preencha os dados de faturamento antes de enviar"
                  : avulsosPendentes.length ? "Cadastre os itens fora do catálogo antes de enviar"
                  : undefined}
                className="gap-1.5"
              >
                {verificando
                  ? <><RefreshCw className="w-3.5 h-3.5 animate-spin" /> Conferindo...</>
                  : enviandoTiny
                  ? <><RefreshCw className="w-3.5 h-3.5 animate-spin" /> Enviando...</>
                  : <><Send className="w-3.5 h-3.5" /> Enviar para Olist</>}
              </Button>
            )}
            {/* Aceite fechado, vai para o contrato. Exige a condição de
                pagamento definida — ela entra no próprio contrato, e a proposta
                não avança sem ninguém ter registrado como o cliente vai pagar. */}
            {proposal.status === "ACEITA" && (
              <Button
                size="sm"
                onClick={() => avancarEtapa("EM_CONTRATO")}
                disabled={concluindo || !pagamentoDefinido}
                title={pagamentoDefinido ? undefined : "Defina a condição de pagamento antes de avançar"}
                className="gap-1.5"
              >
                {concluindo
                  ? <><RefreshCw className="h-3.5 w-3.5 animate-spin" /> Enviando...</>
                  : <><FileSignature className="h-3.5 w-3.5" /> Ir para o contrato</>}
              </Button>
            )}
            {/* O contrato sai do modelo com os dados da proposta já dentro —
                antes era redigido fora, copiando nome e valor à mão. */}
            {proposal.status === "EM_CONTRATO" && (
              <Button size="sm" variant="outline" className="gap-1.5"
                /* Contrato é assinado e vira a base da nota: nome divergente ou
                   CPF errado só aparecem na hora de faturar, com o cliente
                   esperando, e a correção pede aditivo. A rota recusa igual. */
                disabled={!dadosCompletos}
                title={dadosCompletos
                  ? undefined
                  : `Complete os dados de faturamento antes: falta ${faltaFaturamento.join(", ")}.`}
                onClick={async () => {
                  if (!dadosCompletos) {
                    await confirmar({
                      titulo: "Faltam dados de faturamento",
                      texto: `O contrato só sai com o cadastro completo. Falta: ${faltaFaturamento.join(", ")}.`,
                      apenasAviso: true,
                    })
                    return
                  }
                  if (!modelosContrato.length) {
                    await confirmar({ titulo: "Nenhum modelo de contrato cadastrado. Crie um em Modelos.", apenasAviso: true })
                    return
                  }
                  if (modelosContrato.length === 1) {
                    window.open(`/api/propostas/${id}/contrato?modeloId=${modelosContrato[0].id}`, "_blank")
                    return
                  }
                  setEscolherModelo(true)
                }}>
                <FileSignature className="h-3.5 w-3.5" /> Gerar contrato
              </Button>
            )}
            {proposal.status === "EM_CONTRATO" && !!proposal.contrato_gerado_em && (
              <Button size="sm" variant="outline" className="gap-1.5"
                onClick={() => {
                  setEmailContrato(proposal.fat_email || proposal.client_email || "")
                  setConfirmarEnvioContrato(true)
                }}>
                <Send className="h-3.5 w-3.5" />
                {proposal.contrato_enviado_em ? "Reenviar contrato" : "Enviar ao cliente"}
              </Button>
            )}
            {/* Duas afirmações diferentes, dois botões. "Assinado" é um fato
                sobre o documento; "Concluído" é o fim do fluxo comercial. Num
                clique só, a segunda acontecia sem ninguém confirmar a
                primeira. */}
            {proposal.status === "EM_CONTRATO" && !proposal.contrato_assinado_em && (
              <Button size="sm" variant="outline" className="gap-1.5"
                disabled={!proposal.contrato_gerado_em}
                title={proposal.contrato_gerado_em ? undefined : "Gere o contrato primeiro"}
                onClick={() => setConfirmarAssinatura(true)}>
                <FileSignature className="h-3.5 w-3.5" /> Contrato assinado
              </Button>
            )}
            {/* Cópia do contrato no Olist. Só depois de assinado: contrato
                gerado ainda muda, e o Olist não é rascunho. */}
            {proposal.status === "EM_CONTRATO" && !!proposal.contrato_assinado_em
              && !proposal.olist_contrato_em && (
              <Button size="sm" variant="outline" className="gap-1.5" disabled={enviandoOlist}
                onClick={enviarContratoOlist}>
                {enviandoOlist
                  ? <><RefreshCw className="h-3.5 w-3.5 animate-spin" /> Enviando...</>
                  : <><Upload className="h-3.5 w-3.5" /> Contrato no Olist</>}
              </Button>
            )}
            {/* Conclui a partir do faturamento, que é a última etapa. */}
            {proposal.status === "EM_FATURAMENTO" && (
              <Button size="sm" className="gap-1.5" disabled={concluindo}
                onClick={() => avancarEtapa("CONCLUIDA")}>
                {concluindo
                  ? <><RefreshCw className="h-3.5 w-3.5 animate-spin" /> Concluindo...</>
                  : <><CheckCheck className="h-3.5 w-3.5" /> Concluir</>}
              </Button>
            )}

            {(!proposal.obraOrigem || proposal.link_token || userRole === "ADMIN") && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="sm" variant="outline" className="gap-1.5 border-border text-muted-foreground/70 hover:text-white">
                    <MoreHorizontal className="w-3.5 h-3.5" /> Mais
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  {/* Abre o mesmo documento que o cliente recebe, pela via
                      interna: o link dele pede o código enviado por e-mail, e a
                      equipe não tem esse código. NÃO envia nada: quem envia é o
                      botão de enviar. */}
                  <DropdownMenuItem onClick={() => window.open(`/documento/${id}`, "_blank")}>
                    <Printer className="w-3.5 h-3.5" /> Imprimir / visualizar
                  </DropdownMenuItem>
                  {/* Guarda esta proposta como ponto de partida para as próximas.
                      Leva serviços, desconto e formas de pagamento; deixa de fora o
                      cliente, que é o que separa modelo de cópia. */}
                  {(userRole === "ADMIN" || userRole === "FINANCEIRO") && (
                    <DropdownMenuItem onClick={abrirSalvarModelo}>
                      <Copy className="w-3.5 h-3.5" /> Salvar como modelo
                    </DropdownMenuItem>
                  )}
                  
                  {userRole === "ADMIN" && (
                    <>
                      {(!proposal.obraOrigem || proposal.link_token) && <DropdownMenuSeparator />}
                      <DropdownMenuItem onClick={() => setConfirmExcluir(true)} className="text-ios-red focus:text-ios-red">
                        <Trash2 className="w-3.5 h-3.5" /> Excluir
                      </DropdownMenuItem>
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </div>

      {/* Meta info (desktop, no mobile o header ja mostra) */}
      <div className="hidden md:grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: "Tipo de Projeto", value: proposal.project_type },
          { label: "Cidade", value: proposal.client_city || "—" },
          { label: "E-mail", value: proposal.client_email || "—" },
          { label: "Expira em", value: proposal.data_expiracao ? new Date(proposal.data_expiracao).toLocaleDateString("pt-BR") : "—" },
        ].map(item => (
          <div key={item.label} className="bg-background rounded-lg p-3">
            <p className="text-muted-foreground text-xs">{item.label}</p>
            <p className="text-white text-sm font-medium mt-0.5 truncate">{item.value}</p>
          </div>
        ))}
      </div>

      <Tabs defaultValue="detalhes">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <TabsList className="bg-card">
            <TabsTrigger value="detalhes">Detalhes</TabsTrigger>
            <TabsTrigger value="versoes">Versões ({proposal.versions.length})</TabsTrigger>
            {/* A conversa que virou este documento continua aqui: o que foi
                levantado na visita não pode ficar preso na tela de Leads, ou
                quem monta a proposta pergunta de novo ao cliente o que ele já
                respondeu. */}
            <TabsTrigger value="historico">Histórico</TabsTrigger>
          </TabsList>
          {/* O que trava o envio ao Olist, visível sem rolar. Do lado do
              Histórico porque os dois são "acompanhamento da proposta" — não
              dado dela. Verde quando resolvido, e aí param de pedir atenção
              sem sumir da vista. */}
          <div className="flex flex-wrap items-center gap-2">
            <IndicadorPendencia ok={pagamentoDefinido} rotulo="Condição de pagamento"
              onClick={abrirEditorPagamento} />
            <IndicadorPendencia ok={dadosCompletos} rotulo="Dados de faturamento"
              onClick={abrirEditorFaturamento} />
          </div>
        </div>

        <TabsContent value="detalhes" className="mt-4 space-y-4">
          {/* Guardado não vai pro cliente nem soma no total — também não
              aparece aqui. Ele mora na ficha do lead (SistemasGuardados),
              pronto pra virar proposta depois; misturado aqui, parecia que
              tinha entrado na proposta por engano. */}
          {ambientesAtivos.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">Nenhum sistema nesta proposta</div>
          ) : (
            ambientesAtivos.map(env => (
              <div key={env.id} className="bg-surface-1 rounded-2xl border border-hairline overflow-hidden">
                <div className="px-5 py-4 border-b border-hairline flex items-center justify-between gap-2">
                  <h3 className="font-semibold text-foreground text-[15px]">{env.nome}</h3>
                  <span className="text-[14px] text-muted-fg font-medium">
                    {brl(env.proposalItems.reduce((s, i) => s + Number(i.valor_total), 0))}
                  </span>
                </div>
                <div className="divide-y divide-white/5">
                  {env.proposalItems.length === 0 ? (
                    <p className="px-5 py-4 text-muted-foreground text-sm">Nenhum item</p>
                  ) : (
                    env.proposalItems.map((item, idx) => (
                      <div key={item.id} className="flex items-center gap-3 px-4 md:px-5 py-3">
                        <span className="text-[11px] font-mono text-muted-fg/60 w-5 flex-shrink-0">{String(idx + 1).padStart(2, "0")}</span>
                        <ItemIcon nome={item.product?.nome || item.kit?.nome || item.nome_snapshot || ""} qtd={item.quantidade} /* Sem foto do produto, usa a da categoria; só então cai no ícone. */
                          img={item.product?.imagem_url || item.category?.imagem_url} />
                        <div className="flex-1 min-w-0">
                          <p className="text-foreground text-[14px] font-medium leading-tight">{item.product?.nome || item.kit?.nome || item.nome_snapshot || "Item"}</p>
                          <p className="text-muted-fg text-[12px] mt-0.5 md:hidden">{item.quantidade}× · {brl(Number(item.valor_unitario))}</p>
                          {(item.product?.sku || item.sku_snapshot) && <p className="text-muted-foreground text-xs hidden md:block">{item.product?.sku || item.sku_snapshot}</p>}
                        </div>
                        {itemEdit?.itemId === item.id && itemEdit.field === 'quantidade' ? (
                          <input autoFocus type="number" min="1" step="1"
                            className="w-16 bg-muted border border-primary/40 text-foreground text-sm rounded-xl px-2 py-0.5 text-center focus:outline-none focus:ring-1 focus:ring-primary"
                            value={itemEdit.value}
                            onChange={e => setItemEdit(ie => ie ? { ...ie, value: e.target.value } : ie)}
                            onBlur={() => saveItemEdit()}
                            onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); saveItemEdit() } if (e.key === 'Escape') setItemEdit(null) }}
                          />
                        ) : (
                          /* Só leitura aqui. Quantidade se muda em Editar Proposta,
                             no escopo — é onde a proposta é montada e onde os
                             totais e as parcelas são recalculados juntos. */
                          <span className="hidden shrink-0 pr-1 text-sm text-muted-foreground md:inline">x{item.quantidade}</span>
                        )}
                        {/* Preço aqui é só leitura.
                            O preço se edita no ESCOPO, dentro de Editar
                            Proposta — é lá que a proposta é montada e onde os
                            totais e as parcelas são recalculados juntos. Ter o
                            campo nas duas telas faz a pessoa mexer num lugar,
                            conferir no outro e não saber qual valeu. */}
                        <span className="ml-2 hidden shrink-0 whitespace-nowrap text-right text-sm tabular-nums text-muted-foreground md:inline md:min-w-[8.5rem]">
                          {brl(Number(item.valor_unitario))}
                        </span>
                        <span className="text-foreground font-semibold text-[15px] md:w-28 text-right flex-shrink-0">{brl(Number(item.valor_total))}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            ))
          )}

          {/* Projeto e instalação como bloco, do lado dos sistemas: é assim
              que ele vai para o cliente, com nome e valor à frente, e é assim
              que ele é escolhido. A linha solta em "composição do valor" saiu. */}
          {blocoServico && (
            <div className="bg-surface-1 rounded-2xl border border-hairline overflow-hidden">
              <div className="px-5 py-4 border-b border-hairline flex items-center justify-between gap-2">
                <h3 className="font-semibold text-foreground text-[15px]">Serviços</h3>
                <span className="text-[14px] text-muted-fg font-medium">{brl(blocoServico.valor)}</span>
              </div>
              <div className="divide-y divide-white/5">
                {(blocoServico.itens ?? []).map((sv, i) => (
                  <div key={`${sv.nome}-${i}`} className="flex items-center gap-3 px-4 md:px-5 py-3">
                    <span className="text-[11px] font-mono text-muted-fg/60 w-5 flex-shrink-0">{String(i + 1).padStart(2, "0")}</span>
                    <p className="flex-1 min-w-0 text-foreground text-[14px] font-medium leading-tight">{sv.nome}</p>
                    <span className="text-foreground font-semibold text-[15px] md:w-28 text-right flex-shrink-0">{brl(sv.valor)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Fechamento: os blocos e o total, iguais aos do link do cliente. */}
          {blocosProposta.length > 0 && (
            <section className="space-y-2">
              <h3 className="px-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-fg">Valor da proposta</h3>
              <div className="overflow-hidden rounded-2xl bg-surface-1 divide-y divide-hairline">
                {blocosProposta.map(b => (
                  <div key={`fech-${b.id}`} className="flex items-center justify-between gap-4 px-4 py-3 text-sm">
                    <span className="min-w-0 truncate text-muted-foreground">{b.servico ? "Serviços" : b.nome}</span>
                    <span className="shrink-0 font-medium tabular-nums text-foreground">{brl(b.valor)}</span>
                  </div>
                ))}
                {Number(proposal.desconto_aplicado ?? 0) > 0 && (
                  <div className="flex items-center justify-between gap-4 px-4 py-3 text-sm">
                    <span className="text-muted-foreground">Desconto de {pct(Number(proposal.desconto_aplicado) || 0, 2)}</span>
                    <span className="shrink-0 font-medium tabular-nums text-ios-green">
                      -{brl(blocosProposta.reduce((t, b) => t + b.valor, 0) * Number(proposal.desconto_aplicado) / 100)}
                    </span>
                  </div>
                )}
                <div className="flex items-baseline justify-between gap-4 bg-muted px-4 py-3">
                  <span className="text-sm font-medium text-muted-foreground">Total</span>
                  <span className="text-lg font-bold tabular-nums text-foreground">{brl(Number(proposal.valor_total))}</span>
                </div>
              </div>
            </section>
          )}

          {proposal.installments.length > 0 && (
            <section className="space-y-2">
              {/* Título e resumo juntos: separar "Parcelas" de "12x" nas pontas
                  opostas de uma barra larga fazia os dois perderem relação. */}
              <div className="px-1">
                <h3 className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-fg">
                  Parcelas
                  <span className="ml-2 font-normal normal-case tracking-normal tabular-nums text-muted-fg/70">
                    {proposal.installments.length}x de {brl(Number(proposal.installments[0]?.valor ?? 0))}
                  </span>
                </h3>
                {formasPagamento.length > 0 && (
                  <p className="mt-0.5 text-xs text-muted-fg">{formasPagamento.join(" · ")}</p>
                )}
              </div>
              {/* Mesmo desenho do link público: duas colunas, só filete
                  separando. Sem cartão por parcela — 12 caixas viravam ruído. */}
              <div className="grid gap-x-10 sm:grid-cols-2">
                {proposal.installments.map(inst => {
                  const pago = inst.status === "PAGO"
                  const atrasado = inst.status === "ATRASADO"
                  return (
                    <div key={inst.numero_parcela}
                      className="flex items-baseline justify-between gap-3 border-b border-hairline py-2.5 text-sm">
                      <span className="flex min-w-0 items-baseline gap-2 tabular-nums text-muted-fg">
                        <span className="w-6 shrink-0 text-right">{inst.numero_parcela}</span>
                        <span>{new Date(inst.data_vencimento).toLocaleDateString("pt-BR")}</span>
                        {(pago || atrasado) && (
                          <span className={`shrink-0 text-[11px] ${pago ? "text-ios-green" : "text-ios-red"}`}>
                            {pago ? "pago" : "atrasado"}
                          </span>
                        )}
                      </span>
                      <span className="shrink-0 font-medium tabular-nums text-foreground">
                        {brl(Number(inst.valor))}
                      </span>
                    </div>
                  )
                })}
              </div>
            </section>
          )}

          {proposal.extraPages.length > 0 && (
            <section className="space-y-2">
              <h3 className="px-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-fg">Páginas extras</h3>
              <div className="space-y-2">
                {proposal.extraPages.map((page, i) => {
                  const vazia = !page.conteudo_markdown?.replace(/<[^>]*>/g, "").trim()
                  return (
                    <div key={i} className="rounded-2xl bg-surface-1 px-4 py-4">
                      <h4 className="text-[15px] font-semibold text-foreground">{page.titulo}</h4>
                      {vazia ? (
                        <p className="mt-1 text-sm text-muted-fg">Sem conteúdo escrito.</p>
                      ) : (
                        <div className="doc-editor mt-2 text-sm leading-relaxed text-muted-foreground"
                          dangerouslySetInnerHTML={{ __html: sanitizeHtml(page.conteudo_markdown) }} />
                      )}
                      {(page.anexos ?? []).length > 0 && (
                        <div className="mt-3 grid gap-1.5 sm:grid-cols-2">
                          {(page.anexos ?? []).map((a, j) => (
                            <a key={j} href={a.url} target="_blank" rel="noreferrer"
                              className="flex items-center gap-2 rounded-xl bg-muted px-3 py-2 text-sm text-foreground transition-colors hover:text-primary">
                              <span className="font-mono text-[10px] uppercase text-muted-fg">{a.ext}</span>
                              <span className="truncate">{a.nome}</span>
                            </a>
                          ))}
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            </section>
          )}

          {/* Itens escritos na visita que ainda não existem no catálogo.

              Aparece só no faturamento, e é aqui que a dívida assumida na
              visita se paga: o Olist localiza produto por SKU, e sem cadastro o
              pedido chega com item que ninguém consegue comprar nem baixar do
              estoque. Fica antes do pagamento porque é o primeiro bloqueio do
              envio, e o botão de enviar está logo acima. */}
          {emFaturamento && avulsosPendentes.length > 0 && (
            <div className="ios-card p-5 border-l-4 border-l-ios-orange">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-foreground text-[15px] font-medium">
                    {avulsosPendentes.length === 1
                      ? "1 item ainda não está no catálogo"
                      : `${avulsosPendentes.length} itens ainda não estão no catálogo`}
                  </p>
                  <p className="text-muted-fg text-[13px] mt-1 leading-relaxed">
                    {avulsosPendentes.map(i => i.nome_snapshot).filter(Boolean).join(", ")}
                    {", "}cadastre antes de enviar para o Olist.
                  </p>
                </div>
                <Button size="sm" onClick={() => setAvulsosAberto(true)} className="gap-1.5">
                  <Package className="w-3.5 h-3.5" /> Cadastrar
                </Button>
              </div>
            </div>
          )}

          {/* Condição de pagamento, etapa de faturamento.
              Chega preenchida com o que foi escolhido na proposta; aqui o time
              ajusta depois de acertar com o cliente, e só então o Olist libera. */}
          {emFaturamento && (
            <div className={`ios-card p-5 ${pagamentoDefinido ? "" : "border-l-4 border-l-warning"}`}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                    Condição de pagamento
                    {proposal.pagamento_definido_por === "CLIENTE" && (
                      <span className="ml-2 rounded-full bg-success/15 px-2 py-0.5 text-[10px] font-semibold normal-case tracking-normal text-success">
                        escolhida pelo cliente
                      </span>
                    )}
                  </p>
                  {pagamentoDefinido ? (
                    <p className="mt-1.5 text-[16px] font-semibold text-foreground">
                      {proposal.forma_pagamento === "CARTAO" && `${proposal.parcelas_forma ?? 6}x no cartão`}
                      {proposal.forma_pagamento === "AVISTA" && "À vista (5% de desconto)"}
                      {proposal.forma_pagamento === "OBRA" && `Parcelado na obra em ${proposal.parcelas_forma ?? 1}x`}
                      {proposal.forma_pagamento === "PERSONALIZADO"
                        && `Personalizado em ${proposal.parcelas_forma ?? 1}x`}
                      {proposal.forma_pagamento === "PIX" && "PIX"}
                      {proposal.forma_pagamento === "BOLETO" && `Boleto em ${proposal.parcelas_forma ?? 1}x`}
                      {proposal.forma_pagamento === "CHEQUE" && `Cheque em ${proposal.parcelas_forma ?? 1}x`}
                      {proposal.forma_pagamento === "TRANSFERENCIA" && "Transferência"}
                      {Number(proposal.valor_entrada) > 0 && (
                        <span className="ml-2 text-[13px] font-normal text-muted-foreground">
                          · entrada {brl(Number(proposal.valor_entrada))}
                        </span>
                      )}
                    </p>
                  ) : (
                    <p className="mt-1.5 text-[15px] text-warning">
                      {proposal.forma_pagamento === "OBRA"
                        ? "Parcelado na obra, combine as parcelas com o cliente e registre aqui."
                        : "Ainda não definida, o envio ao Olist fica bloqueado."}
                    </p>
                  )}
                </div>
                {!pgto && (
                  <Button size="sm" variant="outline" className="gap-1.5" onClick={abrirEditorPagamento}>
                    <Pencil className="h-3.5 w-3.5" />
                    {pagamentoDefinido ? "Alterar" : "Definir"}
                  </Button>
                )}
              </div>

              {/* Editor em popup, não mais expandindo no fim da pagina.
                  Com lista de itens longa, resolver o que trava o envio ao
                  Olist exigia descer a tela inteira. O Dialog renderiza em
                  portal, então o bloco continua declarado aqui, junto do que
                  ele edita, e aparece centralizado. */}
              <Dialog open={!!pgto}
                onOpenChange={o => { if (!o) { setPgto(null); setParcelasTocadas(false); setErroParcelas("") } }}>
                <DialogContent className="max-w-3xl">
                  <DialogHeader>
                    <DialogTitle>Condição de pagamento</DialogTitle>
                  </DialogHeader>
                  {pgto && (
                  /* Respiro nas quatro bordas: o conteúdo era filho direto do
                     DialogContent, sem o padding que o DialogBody dá, e as
                     opções encostavam na borda do popup. */
                  <div className="max-h-[65vh] space-y-4 overflow-y-auto px-5 py-5 sm:px-6 sm:py-6">
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                    {FORMAS_FATURAMENTO.map(f => (
                      <button key={f.id} type="button"
                        onClick={() => {
                          // Trocar a forma refaz o cronograma: manter a tabela
                          // da condição anterior é o que fazia "à vista"
                          // aparecer com entrada e uma parcela.
                          setParcelasTocadas(false)
                          setPgto(v => v && ({
                            ...v, forma: f.id,
                            parcelas: Math.min(f.max, Math.max(1, v.parcelas || 1)),
                          }))
                        }}
                        className={`ios-tap rounded-xl border p-3 text-left ${
                          pgto.forma === f.id ? "border-primary bg-primary/10" : "border-hairline hover:border-hairline/70"
                        }`}>
                        <span className="block text-sm font-semibold text-foreground">{f.label}</span>
                        <span className="block text-xs text-muted-foreground">{f.desc}</span>
                      </button>
                    ))}
                  </div>

                  {pgto.forma && maxParcelasFat > 1 && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">Parcelas</span>
                      <input type="number" min={1} max={maxParcelasFat}
                        value={pgto.parcelas}
                        onChange={e => {
                          setParcelasTocadas(false)
                          setPgto(v => v && ({
                            ...v,
                            parcelas: Math.max(1, Math.min(maxParcelasFat, Number(e.target.value) || 1)),
                          }))
                        }}
                        className="h-10 w-24 rounded-xl border border-border bg-muted px-3 text-center text-sm text-foreground" />
                      <span className="text-xs text-muted-foreground">até {maxParcelasFat}x</span>
                    </div>
                  )}

                  {/* Entrada vale para QUALQUER forma, inclusive as de
                      pagamento único. O campo só aparecia acima de 1x, e à
                      vista, Pix e transferência herdavam a entrada da condição
                      anterior sem ter onde apagá-la: a tabela mostrava
                      "Entrada + 1 parcela" e não havia como desfazer.

                      A data do primeiro pagamento entra aqui do lado: sem ela
                      tudo vencia a partir de hoje, e um combinado para o mês
                      seguinte obrigava a corrigir linha por linha. */}
                  <div className="flex flex-wrap items-end gap-4">
                    <label className="flex flex-col gap-1">
                      <span className="text-sm text-muted-foreground">Entrada</span>
                      <CampoValor placeholder="R$ 0,00"
                        value={pgto.entrada}
                        onChange={val => {
                          setParcelasTocadas(false)
                          setPgto(v => v && ({ ...v, entrada: val }))
                        }}
                        className="h-10 w-40 rounded-xl border border-border bg-muted px-3 text-sm text-foreground" />
                    </label>
                    <label className="flex flex-col gap-1">
                      <span className="text-sm text-muted-foreground">
                        {Number(pgto.entrada || 0) > 0 ? "Data da entrada" : "Primeiro vencimento"}
                      </span>
                      <input type="date" value={pgto.inicio}
                        onChange={e => {
                          setParcelasTocadas(false)
                          setPgto(v => v && ({ ...v, inicio: e.target.value }))
                        }}
                        className="h-10 rounded-xl border border-border bg-muted px-3 text-sm text-foreground" />
                    </label>
                    {Number(pgto.entrada || 0) > 0 && (
                      <button type="button"
                        onClick={() => { setParcelasTocadas(false); setPgto(v => v && ({ ...v, entrada: "" })) }}
                        className="h-10 text-sm text-muted-foreground underline underline-offset-2 hover:text-foreground">
                        Sem entrada
                      </button>
                    )}
                  </div>

                  {/* Prévia das parcelas.

                      A condição era só um número — "6x" — e as datas só
                      apareciam depois, no Olist. Quem fechava a venda não
                      conseguia dizer ao cliente em que dia cada parcela cai, e
                      todo ajuste combinado na conversa virava conta de cabeça.

                      Mexer numa linha redistribui as SEGUINTES, nunca as
                      anteriores: o que já foi combinado fica, e o que ainda
                      não venceu absorve a diferença. */}
                  {parcelas.length > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                          Parcelas
                        </span>
                        {parcelasTocadas && (
                          <button type="button"
                            onClick={() => setParcelasTocadas(false)}
                            className="text-xs text-muted-foreground underline underline-offset-2 hover:text-foreground">
                            Recalcular
                          </button>
                        )}
                      </div>

                      <div className="overflow-x-auto rounded-xl border border-hairline">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b border-hairline text-[11px] uppercase tracking-wider text-muted-foreground">
                              <th className="px-3 py-2 text-left font-medium">#</th>
                              <th className="px-3 py-2 text-left font-medium">Vencimento</th>
                              <th className="px-3 py-2 text-right font-medium">Valor</th>
                              <th className="px-3 py-2 text-left font-medium">Forma</th>
                            </tr>
                          </thead>
                          <tbody>
                            {parcelas.map((linha, i) => (
                              <tr key={i} className="border-b border-hairline/60 last:border-0">
                                <td className="whitespace-nowrap px-3 py-1.5 text-muted-foreground">
                                  {/* A entrada não consome número: "entrada + 6x"
                                      numera as parcelas de 1 a 6, não de 2 a 7. */}
                                  {linha.entrada
                                    ? <span className="font-medium text-foreground">Entrada</span>
                                    : `${i + 1 - parcelas.filter(x => x.entrada).length}`}
                                </td>
                                <td className="px-3 py-1.5">
                                  <input type="date" value={linha.vencimento}
                                    onChange={e => {
                                      setParcelasTocadas(true)
                                      setParcelas(v => v.map((x, j) =>
                                        j === i ? { ...x, vencimento: e.target.value } : x))
                                    }}
                                    className="h-8 rounded-lg border border-border bg-muted px-2 text-sm text-foreground" />
                                </td>
                                <td className="px-3 py-1.5 text-right">
                                  <CampoValor value={linha.valor}
                                    onChange={val => {
                                      const n = Number(val) || 0
                                      setParcelasTocadas(true)
                                      setParcelas(v => redistribuir(
                                        v.map((x, j) => j === i ? { ...x, valor: n } : x),
                                        i,
                                        Number(proposal.valor_total ?? 0),
                                      ))
                                    }}
                                    className="h-8 w-32 rounded-lg border border-border bg-muted px-2 text-right text-sm tabular-nums text-foreground" />
                                </td>
                                <td className="px-3 py-1.5">
                                  <select value={linha.forma ?? ""}
                                    onChange={e => {
                                      setParcelasTocadas(true)
                                      setParcelas(v => v.map((x, j) =>
                                        j === i ? { ...x, forma: e.target.value || null } : x))
                                    }}
                                    className="h-8 rounded-lg border border-border bg-muted px-2 text-sm text-foreground">
                                    <option value="">A combinar</option>
                                    {FORMAS_PARCELA.map(f => (
                                      <option key={f.id} value={f.id}>{f.label}</option>
                                    ))}
                                  </select>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>

                      {/* A soma tem que fechar com o total: um centavo de
                          diferença vira saldo em aberto no financeiro de uma
                          venda quitada, e ninguém acha a origem depois. */}
                      {(() => {
                        const soma = somaParcelas(parcelas)
                        const total = Number(proposal.valor_total ?? 0)
                        const fecha = Math.abs(soma - total) <= 0.01
                        return (
                          <p className={`text-xs ${fecha ? "text-muted-foreground" : "text-warning"}`}>
                            Soma {brl(soma)} de {brl(total)}
                            {!fecha && `, faltam ${brl(total - soma)} para fechar`}
                          </p>
                        )
                      })()}
                    </div>
                  )}

                  {erroParcelas && <p className="text-xs text-destructive">{erroParcelas}</p>}

                  <div className="flex gap-2">
                    <Button size="sm" onClick={salvarPagamento} disabled={salvandoPgto || !pgto.forma}>
                      {salvandoPgto ? "Salvando..." : "Salvar condição"}
                    </Button>
                    <Button size="sm" variant="outline"
                      onClick={() => { setPgto(null); setParcelasTocadas(false); setErroParcelas("") }}>
                      Cancelar
                    </Button>
                  </div>
                  </div>
                  )}
                </DialogContent>
              </Dialog>
            </div>
          )}

          {/* Dados de faturamento, exigidos antes do Olist.
              A nota é emitida por negócio, não por cliente: o mesmo comprador
              pode faturar em CPF numa obra e em CNPJ na outra. Por isso os
              dados ficam na proposta. */}
          {emFaturamento && (
            <div className={`ios-card p-5 ${dadosCompletos ? "" : "border-l-4 border-l-warning"}`}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                    Dados de faturamento
                  </p>
                  {dadosCompletos ? (
                    <p className="mt-1.5 text-[15px] font-semibold text-foreground">
                      {proposal.fat_razao_social}
                      <span className="ml-2 text-[13px] font-normal text-muted-foreground">
                        {formatarDocumento(proposal.fat_documento ?? "")}
                      </span>
                    </p>
                  ) : (
                    <p className="mt-1.5 text-[15px] text-warning">
                      Faltam dados, o envio ao Olist fica bloqueado.
                    </p>
                  )}
                </div>
                {!dadosFat && (
                  <Button size="sm" variant="outline" className="gap-1.5" onClick={abrirEditorFaturamento}>
                    <Pencil className="h-3.5 w-3.5" />
                    {dadosCompletos ? "Alterar" : "Preencher"}
                  </Button>
                )}
              </div>

              <Dialog open={!!dadosFat} onOpenChange={o => { if (!o) setDadosFat(null) }}>
                <DialogContent className="max-w-3xl">
                  <DialogHeader>
                    <DialogTitle>Dados de faturamento</DialogTitle>
                  </DialogHeader>
                  {dadosFat && (
                  /* Mesmo respiro do popup de pagamento: sem o padding do
                     DialogBody, os campos encostavam na borda. */
                  <div className="max-h-[65vh] space-y-4 overflow-y-auto px-5 py-5 sm:px-6 sm:py-6">
                  <DadosFaturamento dados={dadosFat} onChange={setDadosFat} />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={salvarFaturamento}
                      disabled={salvandoFat || !faturamentoCompleto(dadosFat)}>
                      {salvandoFat ? "Salvando..." : "Salvar dados"}
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => setDadosFat(null)}>Cancelar</Button>
                  </div>
                  </div>
                  )}
                </DialogContent>
              </Dialog>
            </div>
          )}

          {/* Resumo financeiro visível quando há desconto/serviço/ST */}
          {/* "Serviços e mão de obra" saiu daqui: projeto e instalação virou
              bloco, com os sistemas. Aqui ficou o que não é bloco — crédito de
              imposto, desconto e garantia. */}
          {(proposal.desconto_aplicado || proposal.credito_st > 0 || proposal.dias_garantia != null || proposal.anos_garantia != null) && (
            <section className="space-y-2">
              <h3 className="px-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-fg">Condições</h3>
              <div className="overflow-hidden rounded-2xl bg-surface-1 divide-y divide-hairline">
                {proposal.credito_st > 0 && (
                  <div className="flex items-start justify-between gap-4 px-4 py-3 text-sm">
                    <div className="min-w-0">
                      <p className="text-muted-foreground">Crédito ICMS-ST</p>
                      <p className="text-xs text-muted-fg">Substituição tributária já recolhida</p>
                    </div>
                    <span className="shrink-0 text-right">
                      <span className="block font-medium tabular-nums text-ios-green">-{proposal.credito_st}%</span>
                      <span className="block text-xs tabular-nums text-muted-fg">
                        {brl(Number(proposal.valor_total) * (proposal.credito_st / 100))}
                      </span>
                    </span>
                  </div>
                )}
                {(proposal.dias_garantia != null || proposal.anos_garantia != null) && (
                  <div className="flex items-center justify-between px-4 py-3 text-sm">
                    <span className="text-muted-foreground">Garantia</span>
                    <span className="font-medium tabular-nums text-foreground">
                      {proposal.dias_garantia != null
                        ? `${proposal.dias_garantia} dias`
                        /* Proposta antiga guardava anos; converte só para exibir. */
                        : `${(proposal.anos_garantia ?? 0) * 365} dias`}
                    </span>
                  </div>
                )}
              </div>
            </section>
          )}

          {/* Opções Avançadas, só ADMIN e FINANCEIRO */}
          {(userRole === "ADMIN" || userRole === "FINANCEIRO") && (
            <button type="button" onClick={abrirAvancado}
              className="flex w-full items-center gap-3 rounded-2xl bg-surface-1 px-4 py-3.5 text-left transition-colors hover:bg-muted active:scale-[0.995]">
              <Settings2 className="h-4 w-4 shrink-0 text-muted-fg" />
              <span className="min-w-0 flex-1 text-sm font-medium text-foreground">Opções avançadas</span>
              <ChevronRight className="h-4 w-4 shrink-0 text-muted-fg" />
            </button>
          )}
        </TabsContent>

        <TabsContent value="historico" className="mt-4">
          <div className="rounded-2xl border border-hairline bg-surface-1 p-4">
            <HistoricoLead proposalId={proposal.id} titulo="Histórico do cliente" />
          </div>
        </TabsContent>

        <TabsContent value="versoes" className="mt-4">
          {proposal.versions.length === 0 ? (
            <div className="text-center py-12">
              <Clock className="w-10 h-10 text-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">Nenhuma versão salva ainda</p>
            </div>
          ) : (
            <div className="space-y-3">
              {proposal.versions.map(version => (
                <div key={version.id}
                  className="bg-background rounded-xl border border-border/30 p-4 flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-card flex items-center justify-center flex-shrink-0">
                    <span className="text-sky-400 text-sm font-bold">v{version.numero_versao}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-medium">
                      {version.motivo_alteracao || "Atualização"}
                    </p>
                    <p className="text-muted-foreground text-xs mt-0.5">
                      {new Date(version.createdAt).toLocaleString("pt-BR")}
                    </p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-green-400 font-semibold">{brl(Number(version.valor_historico))}</p>
                  </div>
                  {/* Restaurar só nas etapas que aceitam edição. Fora delas a
                      proposta já foi para frente no kanban (aceita, faturando)
                      e voltar o conteúdo desalinharia obra e financeiro.
                      A API recusa de qualquer forma; aqui o botão nem aparece,
                      para não prometer uma ação que vai falhar. */}
                  {podeEditar ? (
                    <Button size="sm" variant="outline" onClick={() => restoreVersion(version.id)}
                      disabled={restoringId === version.id}
                      className="border-border text-muted-foreground/70 hover:text-white flex-shrink-0">
                      {restoringId === version.id
                        ? <><RefreshCw className="w-3.5 h-3.5 mr-1 animate-spin" /> Restaurando...</>
                        : <><RefreshCw className="w-3.5 h-3.5 mr-1" /> Restaurar</>
                      }
                    </Button>
                  ) : (
                    <span className="shrink-0 text-[12px] text-muted-foreground/60">
                      Bloqueado nesta etapa
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
      {/* O que o cliente escreveu ao pedir revisão ou recusar. Fica no topo:
          é a informação que decide o próximo passo do vendedor, e antes ela
          nem chegava a ser gravada. */}
      {proposal.mensagem_cliente && (
        <div className="ios-card border-l-4 border-l-warning p-5">
          <div className="flex items-start gap-3">
            <MessageSquare className="mt-0.5 h-5 w-5 shrink-0 text-warning" />
            <div className="min-w-0 flex-1">
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                Mensagem do cliente
                {proposal.mensagem_cliente_em && (
                  <span className="ml-2 font-normal tracking-normal normal-case">
                    · {new Date(proposal.mensagem_cliente_em).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" })}
                  </span>
                )}
              </p>
              <p className="mt-1.5 whitespace-pre-wrap text-[15px] leading-relaxed text-foreground">
                {proposal.mensagem_cliente}
              </p>
            </div>
          </div>
        </div>
      )}
          <ItensAvulsos
        proposalId={id}
        aberto={avulsosAberto}
        aoFechar={() => setAvulsosAberto(false)}
        aoResolver={() => { fetchProposal() }}
      />
</div>
  )
}
