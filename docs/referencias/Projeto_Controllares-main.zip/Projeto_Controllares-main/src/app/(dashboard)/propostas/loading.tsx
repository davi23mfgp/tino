export default function Loading() {
  return (
    <div className="flex flex-col gap-4 p-5 animate-pulse">
      <div className="flex items-center justify-between">
        <div className="h-7 w-36 bg-muted rounded-xl" />
        <div className="h-9 w-32 bg-muted rounded-xl" />
      </div>
      <div className="flex gap-3 overflow-hidden">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="flex-shrink-0 w-64 flex flex-col gap-2">
            <div className="h-8 bg-muted rounded-xl" />
            {Array.from({ length: 3 }).map((_, j) => (
              <div key={j} className="h-24 bg-card rounded-xl border border-border" />
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}
