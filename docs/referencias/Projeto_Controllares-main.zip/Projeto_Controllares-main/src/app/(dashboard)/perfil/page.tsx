"use client"

import { useEffect, useState } from "react"
import { CheckCheck, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useConfirmar } from "@/components/confirmar"
import { CampoMascarado } from "@/components/ui/campo-mascarado"

interface Perfil {
  nome: string
  email: string
  telefone: string
  whatsapp_numero: string
  whatsapp_apikey: string
  notificar_whatsapp: boolean
  telegram_chat_id?: string | null
  telegram_username?: string | null
  notificar_telegram?: boolean
}

const VAZIO: Perfil = {
  nome: "", email: "", telefone: "",
  whatsapp_numero: "", whatsapp_apikey: "", notificar_whatsapp: true,
  telegram_chat_id: null, telegram_username: null, notificar_telegram: true,
}

const campo = "w-full rounded-xl border border-border bg-muted/50 px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30"

/**
 * Página de perfil da própria pessoa. Existe separada de Configurações porque
 * aquela é do Admin: Vendedor e Financeiro precisam configurar o próprio
 * WhatsApp sem depender de ninguém.
 */
export default function PerfilPage() {
  const confirmar = useConfirmar()
  const [form, setForm] = useState<Perfil>(VAZIO)
  const [carregando, setCarregando] = useState(true)
  const [salvando, setSalvando] = useState(false)
  const [ligandoTg, setLigandoTg] = useState(false)
  const [aguardandoTg, setAguardandoTg] = useState(false)
  const [erroTg, setErroTg] = useState("")
  const [salvo, setSalvo] = useState(false)

  useEffect(() => {
    fetch("/api/perfil", { cache: "no-store" })
      .then(r => r.json())
      .then(d => setForm({
        nome: d.nome ?? "", email: d.email ?? "", telefone: d.telefone ?? "",
        whatsapp_numero: d.whatsapp_numero ?? "", whatsapp_apikey: d.whatsapp_apikey ?? "",
        notificar_whatsapp: d.notificar_whatsapp !== false,
        telegram_chat_id: d.telegram_chat_id ?? null,
        telegram_username: d.telegram_username ?? null,
        notificar_telegram: d.notificar_telegram !== false,
      }))
      .catch(() => {})
      .finally(() => setCarregando(false))
  }, [])

  async function salvar() {
    setSalvando(true)
    try {
      const r = await fetch("/api/perfil", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { await confirmar({ titulo: j.error || "Não foi possível salvar.", apenasAviso: true }); return }
      setSalvo(true)
      setTimeout(() => setSalvo(false), 2500)
    } finally { setSalvando(false) }
  }

  /* O vínculo com o Telegram é pessoal por natureza: o chat_id só existe
     depois que ESTA pessoa abre a conversa com o bot. Por isso o botão fica
     aqui, e não em Integrações junto da lista de destinatários. */
  async function conectarTelegram() {
    setLigandoTg(true); setErroTg("")
    try {
      const r = await fetch("/api/perfil/telegram", { method: "POST" })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { setErroTg(j.error || "Não foi possível gerar o link."); return }
      // Abre o Telegram já com o código. O vínculo se fecha do outro lado.
      window.open(j.url, "_blank")
      setAguardandoTg(true)
    } finally { setLigandoTg(false) }
  }

  async function desconectarTelegram() {
    await fetch("/api/perfil/telegram", { method: "DELETE" }).catch(() => {})
    setForm(f => ({ ...f, telegram_chat_id: null, telegram_username: null }))
  }

  /* Depois de abrir o Telegram, a tela recarrega o perfil ao voltar ao foco:
     o vínculo acontece no outro aplicativo, e sem isto a pessoa voltaria para
     um botão que ainda diz "Conectar" mesmo já tendo conectado. */
  useEffect(() => {
    if (!aguardandoTg) return
    const conferir = () => {
      fetch("/api/perfil", { cache: "no-store" })
        .then(r => r.json())
        .then(d => {
          if (d.telegram_chat_id) {
            setForm(f => ({ ...f, telegram_chat_id: d.telegram_chat_id, telegram_username: d.telegram_username }))
            setAguardandoTg(false)
          }
        })
        .catch(() => {})
    }
    window.addEventListener("focus", conferir)
    const t = setInterval(conferir, 3_000)
    return () => { window.removeEventListener("focus", conferir); clearInterval(t) }
  }, [aguardandoTg])

  if (carregando) return <div className="p-6 text-sm text-muted-foreground">Carregando...</div>

  return (
    <div className="mx-auto max-w-2xl space-y-6 p-4 sm:p-6">
      {salvo && (
        <div className="fixed right-4 top-4 z-50 flex items-center gap-2 rounded-xl bg-green-600 px-4 py-3 text-white shadow-lg">
          <CheckCheck className="h-4 w-4" /> Perfil salvo!
        </div>
      )}

      <div>
        <h1 className="text-xl font-semibold text-foreground">Meu perfil</h1>
        <p className="mt-1 text-sm text-muted-foreground">{form.nome} · {form.email}</p>
      </div>

      <div className="ios-card space-y-4 p-5">
        <h2 className="font-medium text-foreground">Contato</h2>
        <div>
          <label htmlFor="telefone" className="mb-1.5 block text-xs text-muted-foreground">Telefone</label>
          <CampoMascarado id="telefone" mascara="telefone" estilo="proprio" value={form.telefone}
            className={campo} placeholder="(17) 99999-9999"
            onValorChange={v => setForm(f => ({ ...f, telefone: v }))} />
          <p className="mt-1.5 text-xs text-muted-foreground">
            Aparece no rodapé das propostas que você desenvolve.
          </p>
        </div>
      </div>

      {/* Telegram: gratuito, sem cota e individual.

          O CallMeBot corta o número quando as mensagens grátis acabam, e a
          Evolution exige servidor próprio. O bot entrega direto na conversa de
          cada pessoa — e é ela quem liga, porque o chat_id só nasce quando
          alguém abre a conversa com o bot. */}
      <div className="ios-card space-y-3 p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 className="font-medium text-foreground">Avisos no Telegram</h2>
            <p className="mt-0.5 text-xs text-muted-foreground">
              Proposta lida, aceita, revisão pedida, no seu celular, sem custo.
            </p>
          </div>
          {form.telegram_chat_id && (
            <span className="rounded-full bg-ios-green/15 px-2.5 py-1 text-[11px] font-medium text-ios-green">
              Conectado{form.telegram_username ? ` · @${form.telegram_username}` : ""}
            </span>
          )}
        </div>

        {form.telegram_chat_id ? (
          <div className="flex flex-wrap items-center gap-3">
            <label className="flex items-center gap-2 text-sm text-muted-foreground">
              <input type="checkbox" checked={form.notificar_telegram !== false}
                onChange={e => setForm(f => ({ ...f, notificar_telegram: e.target.checked }))}
                className="h-4 w-4 accent-primary" />
              Receber avisos
            </label>
            <button type="button" onClick={desconectarTelegram}
              className="text-xs text-muted-foreground underline underline-offset-2 hover:text-foreground">
              Desconectar
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            <Button onClick={conectarTelegram} disabled={ligandoTg} variant="outline" className="gap-1.5">
              {ligandoTg ? <><RefreshCw className="h-4 w-4 animate-spin" /> Gerando link...</> : "Conectar Telegram"}
            </Button>
            {aguardandoTg && (
              <p className="text-xs text-muted-foreground">
                Abra o Telegram e toque em <span className="text-foreground">Iniciar</span>. Esta tela
                reconhece sozinha quando terminar.
              </p>
            )}
            {erroTg && <p className="text-xs text-ios-red">{erroTg}</p>}
          </div>
        )}
      </div>

      {/* O WhatsApp saiu daqui.

          Cada pessoa cadastrava número e apikey no próprio perfil, e quem não
          preenchesse ficava fora do aviso sem que ninguém percebesse — a falha
          era silenciosa e só aparecia quando uma proposta importante passava
          batida. Agora a lista de destinatários fica em Integrações, num lugar
          só, onde o Admin vê quem recebe e quem não. */}

      <Button onClick={salvar} disabled={salvando} className="gap-1.5">
        {salvando ? <><RefreshCw className="h-4 w-4 animate-spin" /> Salvando...</> : "Salvar"}
      </Button>
    </div>
  )
}
