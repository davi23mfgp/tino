export default function Loading() {
  return (
    <div className="flex flex-col gap-4 p-5 animate-pulse">
      <div className="flex items-center justify-between">
        <div className="h-7 w-36 bg-muted rounded-xl" />
        <div className="h-9 w-28 bg-muted rounded-xl" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="flex flex-col gap-2">
            <div className="h-8 bg-muted rounded-xl" />
            {Array.from({ length: 2 }).map((_, j) => (
              <div key={j} className="h-32 bg-card rounded-xl border border-border" />
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}
