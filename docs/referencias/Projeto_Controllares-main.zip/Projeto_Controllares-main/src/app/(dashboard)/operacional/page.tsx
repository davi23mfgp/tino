﻿"use client"

import { PageLoader } from "@/components/ui/bouncing-dots"
import { useState, useEffect, useCallback } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Package, Flag,
  HardHat, DraftingCompass, Wrench, Plus, GripVertical,
  User, MapPin, RefreshCw, LayoutDashboard, AlertTriangle,
  CheckCircle2, FolderOpen, ShieldCheck, FileText, ChevronRight, ChevronDown, Check,
  Search, Building2,
} from "lucide-react"
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { EmptyState } from "@/components/ui/empty-state"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { CabecalhoPagina } from "@/components/ui/cabecalho-pagina"
import { CartaoMetrica, FaixaMetricas } from "@/components/ui/cartao-metrica"
import { usarAtualizacaoAutomatica } from "@/lib/usar-atualizacao-automatica"
import { useConfirmar } from "@/components/confirmar"
import {
  DndContext, closestCenter, useDraggable, useDroppable,
  type DragEndEvent, type DragStartEvent,
} from "@dnd-kit/core"
import { useMemoriaDeFiltro } from "@/hooks/usar-memoria-filtro"

const COLS_OBRA = [
  "Nova obra", "Ampliação", "Em projeto", "Em tubulações",
  "Em cabeamentos", "Em instalação", "Em programação", "Em entrega",
]
// As 3 categorias de projeto (menu Projetos e vínculo com a obra)
const PROJ_LABEL = {
  OBRA: "Projetos de Obra",
  SOFTWARE: "Arquivos de Software",
  CONTROLLARES: "Projetos Controllares",
} as const

const COLS_PROJETO = [
  "Novo projeto", "Croquis", "Desenho Técnico", "Em conferência", "Alterações",
]
const COLS_MANUTENCAO: { id: string; label: string }[] = [
  { id: "NOVA", label: "Nova manutenção" },
  { id: "AGUARDANDO", label: "Aguardando" },
  { id: "EM_ANDAMENTO", label: "Em andamento" },
  { id: "EM_CONFERENCIA", label: "Em conferência" },
  { id: "CONCLUIDA", label: "Concluído" },
]

interface ParceiroLite { id: string; name: string; type: string; company_name: string | null }

interface Obra {
  id: string
  client_name: string
  address: string | null
  cidade: string | null
  etapa: string | null
  etapa_projeto: string | null
  tipo_projeto?: string | null
  logistics_status: string
  physical_progress_percentage: number
  compra_liberada: boolean
  resp_tecnico: string | null
  resp_tecnico_id: string | null
  checklist_tecnico?: { id: string; texto: string; feito: boolean; origem: string }[] | null
  construtora: string | null
  parceiros: ParceiroLite[]
  proposta_origem: string | null
}

interface ChecklistItem { id: string; texto: string; feito: boolean }
interface AnexoItem { nome: string; url: string }

interface Manutencao {
  id: string
  titulo: string
  descricao: string | null
  status: string
  registro_notas?: string | null
  checklist?: ChecklistItem[] | null
  anexos?: AnexoItem[] | null
  item_catalogo_id?: string | null
  quantidade_item?: number
  // preco_venda/valor_total só chegam para ADMIN (API filtra por role)
  item_info?: { nome: string; sku: string; preco_venda?: number; valor_total?: number } | null
  itens_usados?: { tipo?: string; productId: string; nome: string; sku: string; qtd: number; valor_total?: number }[]
  valor_total_itens?: number | null
  decisao_faturamento?: string | null
  obraId: string
  obra_nome: string | null
  obra_cidade: string | null
}

function DraggableCard({ id, onClick, children }: {
  id: string; onClick?: () => void; children: React.ReactNode
}) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({ id })
  const style = transform ? {
    transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
    opacity: isDragging ? 0.4 : 1,
  } : undefined

  return (
    <div ref={setNodeRef} style={style} onClick={onClick}
      className="bg-card rounded-xl p-3 border border-border/50 hover:border-border transition-all duration-200 select-none cursor-pointer shadow-sm">
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">{children}</div>
        <button {...listeners} {...attributes} onClick={e => e.stopPropagation()}
          className="text-muted-foreground/40 hover:text-muted-foreground cursor-grab active:cursor-grabbing p-0.5 flex-shrink-0" title="Arrastar">
          <GripVertical className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  )
}

// Paleta ciclada para colorir as colunas do kanban
const COL_CORES = [
  { dot: "bg-ios-blue",   bt: "border-t-ios-blue",   zone: "bg-ios-blue/[0.04]" },
  { dot: "bg-ios-purple", bt: "border-t-ios-purple", zone: "bg-ios-purple/[0.04]" },
  { dot: "bg-ios-teal",   bt: "border-t-ios-teal",   zone: "bg-ios-teal/[0.04]" },
  { dot: "bg-ios-orange", bt: "border-t-ios-orange", zone: "bg-ios-orange/[0.04]" },
  { dot: "bg-ios-yellow", bt: "border-t-ios-yellow", zone: "bg-ios-yellow/[0.04]" },
  { dot: "bg-ios-green",  bt: "border-t-ios-green",  zone: "bg-ios-green/[0.04]" },
  { dot: "bg-ios-red",    bt: "border-t-ios-red",    zone: "bg-ios-red/[0.04]" },
  { dot: "bg-ios-blue",   bt: "border-t-ios-blue",   zone: "bg-ios-blue/[0.04]" },
]

function Column({ id, label, count, colorIdx = 0, children }: {
  id: string; label: string; count: number; colorIdx?: number; children: React.ReactNode
}) {
  const { setNodeRef, isOver } = useDroppable({ id })
  const c = COL_CORES[colorIdx % COL_CORES.length]
  return (
    <div className="flex flex-col min-w-[230px] max-w-[260px] flex-1">
      <div className={`flex items-center justify-between mb-2 px-3 py-2 rounded-t-xl border-t-[3px] ${c.bt} bg-surface-2/60`}>
        <div className="flex items-center gap-2 min-w-0">
          <span className={`w-2 h-2 rounded-full flex-shrink-0 ${c.dot}`} />
          <h3 className="font-semibold text-sm text-foreground truncate">{label}</h3>
        </div>
        <span className="bg-background/60 text-muted-foreground text-xs rounded-full px-2 py-0.5 font-medium tabular-nums flex-shrink-0">{count}</span>
      </div>
      <div ref={setNodeRef}
        className={`flex-1 space-y-2 min-h-[200px] rounded-b-xl p-2 border border-hairline transition-colors ${isOver ? `${c.zone} ring-1 ring-ios-blue/40` : c.zone}`}>
        {children}
      </div>
    </div>
  )
}

function ObraCard({ obra, onOpen }: { obra: Obra; onOpen: (target?: string) => void }) {
  const pct = Math.min(100, Math.max(0, obra.physical_progress_percentage ?? 0))
  const liberado = obra.logistics_status === "LIBERADO_INSTALACAO" || obra.compra_liberada

  const etapa = obra.etapa ?? "Nova obra"
  const iniciando = pct < 5
  const statusColor = iniciando ? "text-ios-yellow" : "text-ios-blue"

  return (
    <div onClick={() => onOpen()}
      className="bg-surface-1 border border-hairline rounded-[20px] p-4 hover:bg-surface-2 transition-colors cursor-pointer">
      {/* Topo: ícone + nome/cliente + status */}
      <div className="flex items-start gap-3">
        <div className="w-11 h-11 rounded-2xl bg-surface-2 flex items-center justify-center flex-shrink-0">
          <HardHat className="w-5 h-5 text-ios-orange" strokeWidth={1.8} />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-[16px] font-semibold text-foreground leading-tight truncate">{obra.client_name}</p>
          {obra.resp_tecnico && <p className="text-[13px] text-muted-fg truncate mt-0.5">{obra.resp_tecnico}</p>}
        </div>
        <span className={`text-[12px] font-medium flex-shrink-0 ${statusColor}`}>{etapa}</span>
      </div>

      {/* Endereço */}
      {(obra.cidade || obra.address) && (
        <p className="text-[13px] text-muted-fg flex items-center gap-1.5 mt-3 min-w-0">
          <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
          <span className="truncate">{obra.address || obra.cidade}</span>
        </p>
      )}

      {/* Progresso */}
      <div className="mt-3">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[13px] text-muted-fg">Progresso</span>
          <span className="text-[14px] font-semibold text-foreground">{pct}%</span>
        </div>
        <div className="h-1 bg-surface-3 rounded-full overflow-hidden">
          <div className={`h-full rounded-full transition-all ${pct >= 80 ? "bg-ios-green" : pct >= 40 ? "bg-ios-blue" : "bg-ios-orange"}`}
            style={{ width: `${pct}%` }} />
        </div>
      </div>

      {/* Rodapé: liberação + ações rápidas */}
      <div className="flex items-center gap-1 mt-3 pt-3 border-t border-hairline" onClick={e => e.stopPropagation()}>
        <span className={`text-[11px] font-medium mr-auto flex items-center gap-1 ${liberado ? "text-ios-green" : "text-ios-orange"}`}>
          {liberado ? <><CheckCircle2 className="w-3 h-3" /> Liberado</> : <><AlertTriangle className="w-3 h-3" /> Aguardando</>}
        </span>
        <button title="Projetos" onClick={() => onOpen("tab=engenharia&sub=projetos")}
          className="w-8 h-8 rounded-xl flex items-center justify-center text-muted-fg hover:text-foreground hover:bg-white/5"><FileText className="w-4 h-4" /></button>
        <button title="Anexos" onClick={() => onOpen("tab=engenharia&sub=anexos")}
          className="w-8 h-8 rounded-xl flex items-center justify-center text-muted-fg hover:text-foreground hover:bg-white/5"><FolderOpen className="w-4 h-4" /></button>
        <button title="Senhas" onClick={() => onOpen("tab=suporte&sub=senhas")}
          className="w-8 h-8 rounded-xl flex items-center justify-center text-muted-fg hover:text-foreground hover:bg-white/5"><ShieldCheck className="w-4 h-4" /></button>
      </div>
    </div>
  )
}

export default function OperacionalPage() {
  const confirmar = useConfirmar()
  const router = useRouter()
  const searchParams = useSearchParams()
  // Deep-link: /operacional?tab=projetos abre direto a aba (nav "Projetos")
  const tabInicial = ["dashboard", "obras", "projetos", "manutencoes"].includes(searchParams.get("tab") ?? "")
    ? (searchParams.get("tab") as string) : "dashboard"
  const [tabAtiva, setTabAtiva] = useState<string>(tabInicial)
  const [obras, setObras] = useState<Obra[]>([])
  const [projTipo, setProjTipo] = useState<"OBRA" | "SOFTWARE" | "CONTROLLARES" | null>(null)
  const [manutencoes, setManutencoes] = useState<Manutencao[]>([])
  const [loading, setLoading] = useState(true)
  const [activeId, setActiveId] = useState<string | null>(null)

  const [busca, setBusca] = useMemoriaDeFiltro("operacional:busca", "")
  const [filtroTecnico, setFiltroTecnico] = useMemoriaDeFiltro("operacional:tecnico", "")
  const [filtroParceiro, setFiltroParceiro] = useMemoriaDeFiltro("operacional:parceiro", "")
  const [filtroConstrutora, setFiltroConstrutora] = useMemoriaDeFiltro("operacional:construtora", "")
  const [filtroStatus, setFiltroStatus] = useMemoriaDeFiltro<"ativas" | "finalizadas" | "todas">("operacional:status", "ativas")
  const [filtroPct, setFiltroPct] = useMemoriaDeFiltro<"" | "0-25" | "25-75" | "75-100">("operacional:progresso", "")

  const [mntModal, setMntModal] = useState(false)
  const [mntObraId, setMntObraId] = useState("")
  const [mntTitulo, setMntTitulo] = useState("")
  const [mntDesc, setMntDesc] = useState("")
  const [savingMnt, setSavingMnt] = useState(false)

  // ── Criação manual de Obra / Projeto (Bloco 7) ──
  const [obraModal, setObraModal] = useState(false)
  const [obraModalTipo, setObraModalTipo] = useState<"obra" | "projeto">("obra")
  const [obraNome, setObraNome] = useState("")
  const [obraPropBusca, setObraPropBusca] = useState("")
  /* Obra é dado de equipe: o técnico marca etapa no canteiro, o financeiro
     libera a compra. Quem está com a tela aberta via tudo velho até apertar
     "Atualizar" — e só apertaria se desconfiasse, que é justamente o que não
     acontece. */
  usarAtualizacaoAutomatica(() => fetchAll(true))

  const emAndamento = obras.filter(o => o.etapa && o.etapa !== "Em entrega")

  const [obraProps, setObraProps] = useState<{ id: string; numero: string; client_name: string; status?: string }[]>([])
  const [obraPropSel, setObraPropSel] = useState<{ id: string; numero: string; client_name: string } | null>(null)
  const [savingObra, setSavingObra] = useState(false)

  // ── Registro da manutenção (notas + checklist + anexos) ──
  const [regTicket, setRegTicket] = useState<Manutencao | null>(null)
  const [regNotas, setRegNotas] = useState("")
  const [regChecklist, setRegChecklist] = useState<ChecklistItem[]>([])
  const [regAnexos, setRegAnexos] = useState<AnexoItem[]>([])
  const [regNovoItem, setRegNovoItem] = useState("")
  const [regSaving, setRegSaving] = useState(false)
  const [regUploading, setRegUploading] = useState(false)

  // Itens (catálogo) e serviços (livres) usados no chamado. Técnico não vê preço.
  const [regItemBusca, setRegItemBusca] = useState("")
  const [regMarca, setRegMarca] = useState("") // filtro de fornecedor na busca
  const [regMarcas, setRegMarcas] = useState<{ id: string; nome: string }[]>([])
  const [regItemResultados, setRegItemResultados] = useState<{ id: string; nome: string; sku: string }[]>([])
  const [regItens, setRegItens] = useState<{ tipo: "produto" | "servico"; productId: string; nome: string; sku: string; qtd: number }[]>([])
  const [regServico, setRegServico] = useState("")
  const [regDecidindo, setRegDecidindo] = useState(false)
  const [meuRole, setMeuRole] = useState("")
  // Página do fluxo: 1 = checklist; 2 = relatório do serviço + decisão
  const [regStep, setRegStep] = useState<1 | 2>(1)

  useEffect(() => {
    fetch("/api/auth/me").then(r => r.ok ? r.json() : null).then(d => setMeuRole(d?.user?.role ?? ""))
    fetch("/api/fornecedores").then(r => r.ok ? r.json() : null).then(d => {
      const list = d?.suppliers || d?.fornecedores || d || []
      setRegMarcas(Array.isArray(list) ? list.map((s: { id: string; nome: string }) => ({ id: s.id, nome: s.nome })) : [])
    }).catch(() => {})
  }, [])

  useEffect(() => {
    // Busca só com marca selecionada OU 2+ letras. Marca deixa a busca leve/rápida.
    if (!regMarca && regItemBusca.trim().length < 2) { setRegItemResultados([]); return }
    const t = setTimeout(async () => {
      const qs = new URLSearchParams({ limit: "20" })
      if (regItemBusca.trim()) qs.set("search", regItemBusca.trim())
      if (regMarca) qs.set("supplierId", regMarca)
      const r = await fetch(`/api/produtos?${qs}`)
      if (r.ok) {
        const d = await r.json()
        setRegItemResultados((d.products || []).map((p: { id: string; nome: string; sku: string }) => ({ id: p.id, nome: p.nome, sku: p.sku })))
      }
    }, 250)
    return () => clearTimeout(t)
  }, [regItemBusca, regMarca])

  function abrirRegistro(m: Manutencao) {
    setRegTicket(m)
    setRegNotas(m.registro_notas || "")
    setRegChecklist(Array.isArray(m.checklist) ? m.checklist : [])
    setRegAnexos(Array.isArray(m.anexos) ? m.anexos : [])
    setRegNovoItem("")
    setRegItens(Array.isArray(m.itens_usados) ? m.itens_usados.map(i => ({ tipo: (i.tipo === "servico" ? "servico" : "produto") as "produto" | "servico", productId: i.productId, nome: i.nome, sku: i.sku, qtd: i.qtd })) : [])
    setRegItemBusca(""); setRegMarca(""); setRegServico(""); setRegItemResultados([])
    // Checklist já 100%? Abre direto no relatório.
    const ck = Array.isArray(m.checklist) ? m.checklist : []
    setRegStep(ck.length > 0 && ck.every(c => c.feito) ? 2 : 1)
  }

  async function salvarRegistro(fechar = true) {
    if (!regTicket) return
    setRegSaving(true)
    try {
      const payload = {
        registro_notas: regNotas, checklist: regChecklist, anexos: regAnexos,
        itens_usados: regItens,
      }
      const res = await fetch(`/api/manutencoes/${regTicket.id}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })
      if (res.ok && fechar) {
        setRegTicket(null)
        fetchAll() // recarrega — valores vêm do servidor
      }
    } finally { setRegSaving(false) }
  }

  // Decisão do ADMIN: Faturar (cobra do cliente) ou Custear (empresa assume).
  // Também aplica a baixa de estoque que estava pendente (autorização).
  async function decidirFaturamento(decisao: "FATURAR" | "CUSTEADO") {
    if (!regTicket) return
    setRegDecidindo(true)
    try {
      const res = await fetch(`/api/manutencoes/${regTicket.id}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ decisao_faturamento: decisao }),
      })
      if (res.ok) { setRegTicket(null); fetchAll() }
      else alert((await res.json()).error || "Erro na decisão.")
    } finally { setRegDecidindo(false) }
  }

  async function uploadAnexoRegistro(file: File) {
    setRegUploading(true)
    try {
      const fd = new FormData()
      fd.append("file", file)
      const res = await fetch("/api/upload", { method: "POST", body: fd })
      const j = await res.json()
      if (res.ok && j.url) setRegAnexos(prev => [...prev, { nome: j.nome || file.name, url: j.url }])
    } finally { setRegUploading(false) }
  }

  /** @param silencioso não liga o loader — usado pela atualização automática. */
  const fetchAll = useCallback(async (silencioso = false) => {
    if (!silencioso) setLoading(true)
    try {
      const [oRes, mRes] = await Promise.all([
        fetch("/api/obras", { cache: "no-store" }),
        fetch("/api/manutencoes", { cache: "no-store" }),
      ])
      const oData = await oRes.json()
      const mData = await mRes.json()
      setObras(oData.obras || [])
      setManutencoes(mData.tickets || [])
    } finally {
      if (!silencioso) setLoading(false)
    }
  }, [])

  useEffect(() => { fetchAll() }, [fetchAll])

  const obraCol = (o: Obra) => (o.etapa && COLS_OBRA.includes(o.etapa)) ? o.etapa : COLS_OBRA[0]
  const projCol = (o: Obra) => (o.etapa_projeto && COLS_PROJETO.includes(o.etapa_projeto)) ? o.etapa_projeto : COLS_PROJETO[0]

  async function moveObra(obraId: string, etapa: string) {
    setObras(prev => prev.map(o => o.id === obraId ? { ...o, etapa } : o))
    await fetch(`/api/obras/${obraId}/etapa`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ etapa }),
    })
  }
  async function moveProjeto(obraId: string, etapa_projeto: string) {
    setObras(prev => prev.map(o => o.id === obraId ? { ...o, etapa_projeto } : o))
    await fetch(`/api/obras/${obraId}/etapa-projeto`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ etapa_projeto }),
    })
  }
  async function mudarTipoProjeto(obraId: string, tipo_projeto: string) {
    setObras(prev => prev.map(o => o.id === obraId ? { ...o, tipo_projeto } : o))
    await fetch(`/api/obras/${obraId}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tipo_projeto }),
    })
  }
  async function moveManutencao(id: string, status: string) {
    setManutencoes(prev => prev.map(m => m.id === id ? { ...m, status } : m))
    await fetch(`/api/manutencoes/${id}/status`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    })
  }

  function onDragStart(e: DragStartEvent) { setActiveId(String(e.active.id)) }

  function makeDragEnd(move: (itemId: string, col: string) => void, validCols: string[]) {
    return (e: DragEndEvent) => {
      setActiveId(null)
      const { active, over } = e
      if (!over) return
      const col = String(over.id)
      if (!validCols.includes(col)) return
      move(String(active.id), col)
    }
  }

  async function criarManutencao() {
    if (!mntObraId || !mntTitulo.trim()) return
    setSavingMnt(true)
    try {
      const res = await fetch("/api/manutencoes", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ obraId: mntObraId, titulo: mntTitulo, descricao: mntDesc }),
      })
      if (res.ok) {
        setMntModal(false)
        setMntObraId(""); setMntTitulo(""); setMntDesc("")
        await fetchAll()
      }
    } finally {
      setSavingMnt(false)
    }
  }

  /* Propostas que podem virar obra: do ACEITE em diante, e ainda sem obra.

     A régua é o aceite, não a etapa exata. Depois que o cliente aceita, a obra
     existe — contrato, faturamento e conclusão são passos administrativos que
     acontecem em paralelo à execução, não antes dela. Listando só ACEITA e
     EM_FATURAMENTO, uma proposta que já estava em contrato sumia da lista e a
     obra tinha de ser criada em branco, sem vínculo com o que foi vendido.

     Proposta em revisão continua fora: o escopo ainda muda. E proposta que já
     gerou obra não gera outra. */
  // A lista carrega assim que o diálogo abre — são poucas, e esconder até
  // digitar dava a impressão de que não havia nenhuma.
  useEffect(() => {
    if (!obraModal) return
    const t = setTimeout(async () => {
      const qs = new URLSearchParams({ semObra: "1" })
      if (obraPropBusca.trim()) qs.set("search", obraPropBusca.trim())
      const r = await fetch(`/api/propostas?${qs}`).catch(() => null)
      if (!r?.ok) { setObraProps([]); return }
      const d = await r.json()
      const arr = (d?.propostas || d?.proposals || d || []) as { id: string; numero: string; client_name: string; status?: string; obraId?: string | null }[]
      setObraProps(
        arr.filter(p => !p.obraId
          && ["ACEITA", "EM_CONTRATO", "EM_FATURAMENTO", "CONCLUIDA"].includes(p.status ?? "")).slice(0, 20)
      )
    }, 200)
    return () => clearTimeout(t)
  }, [obraModal, obraPropBusca])

  async function criarObra() {
    const nome = (obraPropSel?.client_name || obraNome).trim()
    if (!nome) return
    setSavingObra(true)
    try {
      const res = await fetch("/api/obras", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ client_name: obraNome.trim() || undefined, proposalId: obraPropSel?.id }),
      })
      if (res.ok) {
        const d = await res.json().catch(() => ({}))
        setObraModal(false)
        setObraNome(""); setObraPropBusca(""); setObraPropSel(null); setObraProps([])
        if (d?.id) router.push(`/obras/${d.id}`)
        else await fetchAll()
      } else {
        const e = await res.json().catch(() => ({}))
        await confirmar({ titulo: e?.error || "Não foi possível criar.", apenasAviso: true })
      }
    } finally {
      setSavingObra(false)
    }
  }

  const parceiros = [...new Map(
    obras.flatMap(o => o.parceiros.filter(p => p.type === "ARQUITETO" || p.type === "DESIGNER").map(p => [p.id, p.name]))
  ).values()]
  const construtoras = [...new Set(obras.map(o => o.construtora).filter(Boolean))] as string[]

  const obrasFiltradas = obras.filter(o => {
    if (filtroStatus === "ativas" && o.etapa === "Em entrega") return false
    if (filtroStatus === "finalizadas" && o.etapa !== "Em entrega") return false
    if (busca && !o.client_name.toLowerCase().includes(busca.toLowerCase())) return false
    if (filtroTecnico && o.resp_tecnico_id !== filtroTecnico) return false
    if (filtroParceiro && !o.parceiros.some(p => p.id === filtroParceiro)) return false
    if (filtroConstrutora && o.construtora !== filtroConstrutora) return false
    const pct = o.physical_progress_percentage ?? 0
    if (filtroPct === "0-25" && pct >= 25) return false
    if (filtroPct === "25-75" && (pct < 25 || pct >= 75)) return false
    if (filtroPct === "75-100" && pct < 75) return false
    return true
  })

  const inputCls = "bg-muted/50 border border-border text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary/30 rounded-xl px-3 py-2"
  const selectCls = inputCls

  return (
    <div className="p-4 md:p-6 h-full flex flex-col space-y-4">
      <CabecalhoPagina
        icone={HardHat}
        titulo="Obras"
        contexto={`${emAndamento.length} em andamento`}
      />

      <Tabs value={tabAtiva} onValueChange={setTabAtiva} className="flex-1 flex flex-col">
        <TabsList className="h-auto p-0 bg-transparent border-b border-border w-full rounded-none justify-start gap-0 overflow-x-auto no-scrollbar">
          <TabsTrigger value="dashboard" className="rounded-none h-9 px-4 text-[13px] border-b-2 border-transparent flex-shrink-0 whitespace-nowrap data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none text-muted-foreground data-[state=active]:text-foreground font-normal data-[state=active]:font-medium">
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="obras" className="rounded-none h-9 px-4 text-[13px] border-b-2 border-transparent flex-shrink-0 whitespace-nowrap data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none text-muted-foreground data-[state=active]:text-foreground font-normal data-[state=active]:font-medium">
            Obras
          </TabsTrigger>
          {/* Projetos abre um menu com as 3 categorias (como Suporte na obra) */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className={`rounded-none h-9 px-4 text-[13px] border-b-2 flex-shrink-0 whitespace-nowrap inline-flex items-center gap-1 transition-colors ${
                tabAtiva === "projetos" ? "border-foreground text-foreground font-medium" : "border-transparent text-muted-foreground font-normal hover:text-foreground"
              }`}>
                Projetos
                {tabAtiva === "projetos" && projTipo && (
                  <span className="text-muted-foreground/70 font-normal">· {PROJ_LABEL[projTipo]}</span>
                )}
                <ChevronDown className="w-3.5 h-3.5 opacity-60" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              {(Object.keys(PROJ_LABEL) as (keyof typeof PROJ_LABEL)[]).map(k => (
                <DropdownMenuItem key={k} className="gap-2 cursor-pointer"
                  onSelect={() => { setTabAtiva("projetos"); setProjTipo(k) }}>
                  <Check className={`w-3.5 h-3.5 ${tabAtiva === "projetos" && projTipo === k ? "opacity-100 text-primary" : "opacity-0"}`} />
                  {PROJ_LABEL[k]}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <TabsTrigger value="manutencoes" className="rounded-none h-9 px-4 text-[13px] border-b-2 border-transparent flex-shrink-0 whitespace-nowrap data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none text-muted-foreground data-[state=active]:text-foreground font-normal data-[state=active]:font-medium">
            Manutenções
          </TabsTrigger>
        </TabsList>

        {/* ABA DASHBOARD */}
        <TabsContent value="dashboard" className="flex-1 mt-4 space-y-4">
          {/* Checklist do responsável técnico, pendências de projetos, obras e manutenções */}
          {(() => {
            const pendObras = obras.flatMap(o =>
              (o.checklist_tecnico ?? []).filter(c => !c.feito).map(c => ({
                key: `${o.id}-${c.id}`, texto: c.texto, origem: c.origem,
                contexto: o.client_name, href: `/obras/${o.id}?tab=tarefas`,
              })))
            const pendMnt = manutencoes.flatMap(m =>
              (m.checklist ?? []).filter(c => !c.feito).map(c => ({
                key: `${m.id}-${c.id}`, texto: c.texto, origem: "MANUTENCAO",
                contexto: m.titulo, href: `/operacional?tab=manutencoes`,
              })))
            const pend = [...pendObras, ...pendMnt]
            if (pend.length === 0) return null
            const CORES: Record<string, string> = {
              PROJETO: "bg-ios-purple/10 text-ios-purple",
              OBRA: "bg-ios-blue/10 text-ios-blue",
              MANUTENCAO: "bg-ios-orange/10 text-ios-orange",
            }
            return (
              <div className="bg-card border border-border shadow-apple-card rounded-2xl p-4 space-y-2.5">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-primary" />
                  <h3 className="text-foreground font-medium text-sm">Checklist técnico, pendências</h3>
                  <span className="text-[11px] font-semibold bg-ios-red/10 text-ios-red px-2 py-0.5 rounded-full">{pend.length}</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5 max-h-44 overflow-y-auto">
                  {pend.slice(0, 20).map(p => (
                    <button key={p.key} onClick={() => router.push(p.href)}
                      className="flex items-center gap-2 text-left px-2.5 py-1.5 rounded-xl hover:bg-muted/50 transition-colors">
                      <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded-full flex-shrink-0 ${CORES[p.origem] ?? CORES.OBRA}`}>
                        {p.origem === "PROJETO" ? "Projeto" : p.origem === "MANUTENCAO" ? "Manutenção" : "Obra"}
                      </span>
                      <span className="text-sm text-foreground truncate flex-1">{p.texto}</span>
                      <span className="text-[11px] text-muted-foreground/60 truncate max-w-[120px] flex-shrink-0">{p.contexto}</span>
                    </button>
                  ))}
                </div>
              </div>
            )
          })()}
          {/* Filtros: busca em cima, controles em linha rolável (estilo iOS no mobile) */}
          <div className="space-y-2.5">
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-fg pointer-events-none" />
              <input
                className="w-full bg-surface-1 border border-hairline rounded-2xl pl-10 pr-4 h-11 text-[15px] text-foreground placeholder:text-muted-fg focus:outline-none focus:ring-2 focus:ring-ios-blue/20 focus:border-ios-blue/40 transition-all"
                placeholder="Buscar obra..."
                value={busca}
                onChange={e => setBusca(e.target.value)}
              />
            </div>
            <div className="flex gap-2 overflow-x-auto no-scrollbar pb-0.5 [&>select]:flex-shrink-0 [&>div]:flex-shrink-0">

            <select value={filtroTecnico} onChange={e => setFiltroTecnico(e.target.value)} className={selectCls}>
              <option value="">Todos os técnicos</option>
              {obras.filter(o => o.resp_tecnico).map(o => (
                <option key={o.resp_tecnico_id ?? o.id} value={o.resp_tecnico_id ?? ""}>
                  {o.resp_tecnico}
                </option>
              )).filter((v, i, a) => a.findIndex(x => x.key === v.key) === i)}
            </select>

            {parceiros.length > 0 && (
              <select value={filtroParceiro} onChange={e => setFiltroParceiro(e.target.value)} className={selectCls}>
                <option value="">Todos os escritórios</option>
                {obras.flatMap(o => o.parceiros.filter(p => p.type === "ARQUITETO" || p.type === "DESIGNER"))
                  .filter((p, i, a) => a.findIndex(x => x.id === p.id) === i)
                  .map(p => (
                    <option key={p.id} value={p.id}>{p.name}{p.company_name ? ` (${p.company_name})` : ""}</option>
                  ))}
              </select>
            )}

            {construtoras.length > 0 && (
              <select value={filtroConstrutora} onChange={e => setFiltroConstrutora(e.target.value)} className={selectCls}>
                <option value="">Todas as construtoras</option>
                {construtoras.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            )}

            <div className="flex gap-1 bg-muted rounded-xl p-1">
              {(["ativas", "todas", "finalizadas"] as const).map(s => (
                <button key={s} onClick={() => setFiltroStatus(s)}
                  className={`px-3 py-1 rounded-2xl text-xs font-medium transition-colors ${filtroStatus === s
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                    }`}>
                  {s === "ativas" ? "Ativas" : s === "finalizadas" ? "Finalizadas" : "Todas"}
                </button>
              ))}
            </div>

            {/* Progresso vira select, economiza a largura das 4 pills */}
            <select value={filtroPct} onChange={e => setFiltroPct(e.target.value as typeof filtroPct)} className={selectCls}>
              <option value="">Progresso: todos</option>
              <option value="0-25">0–25%</option>
              <option value="25-75">25–75%</option>
              <option value="75-100">75–100%</option>
            </select>
            </div>
          </div>

          {!loading && (
            <FaixaMetricas>
              <CartaoMetrica icone={HardHat} rotulo="Em andamento" valor={emAndamento.length} nota="Obras abertas" />
              <CartaoMetrica icone={Package} rotulo="Aguardando material"
                valor={obras.filter(o => o.logistics_status === "AGUARDANDO_EQUIPAMENTOS").length}
                nota="Compra não chegou" />
              <CartaoMetrica icone={CheckCircle2} rotulo="Liberadas"
                valor={obras.filter(o => o.compra_liberada).length} nota="Prontas para instalar" />
              <CartaoMetrica icone={Flag} rotulo="Finalizadas"
                valor={obras.filter(o => o.etapa === "Em entrega").length} nota="Em entrega" />
            </FaixaMetricas>
          )}

          {loading ? (
            <div className="flex items-center justify-center h-64"><PageLoader /></div>
          ) : obrasFiltradas.length === 0 ? (
            <EmptyState icon={Building2} title="Nenhuma obra" subtitle="Nenhuma obra encontrada com esses filtros." />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {obrasFiltradas.map(o => (
                <ObraCard key={o.id} obra={o} onOpen={(t) => router.push(`/obras/${o.id}${t ? `?${t}` : ""}`)} />
              ))}
            </div>
          )}
        </TabsContent>

        {/* ABA OBRAS */}
        <TabsContent value="obras" className="flex-1 mt-4">
          <div className="flex justify-end mb-3">
            <Button onClick={() => { setObraModalTipo("obra"); setObraModal(true) }} className="gap-1.5">
              <Plus className="w-4 h-4" /> Nova Obra
            </Button>
          </div>
          {loading ? <Loading /> : (
            <DndContext collisionDetection={closestCenter} onDragStart={onDragStart}
              onDragEnd={makeDragEnd((id, col) => moveObra(id, col), COLS_OBRA)}>
              <div className="flex gap-3 overflow-x-auto pb-4">
                {COLS_OBRA.map((col, ci) => {
                  const items = obras.filter(o => obraCol(o) === col)
                  return (
                    <Column key={col} id={col} label={col} count={items.length} colorIdx={ci}>
                      {items.map(o => (
                        <DraggableCard key={o.id} id={o.id} onClick={() => router.push(`/obras/${o.id}`)}>
                          <p className="text-foreground font-medium text-sm truncate">{o.client_name}</p>
                          <p className="text-muted-foreground text-xs mt-0.5">{o.etapa || "Nova obra"}</p>
                          <div className="flex flex-col gap-0.5 mt-2 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <User className="w-3 h-3" /> {o.resp_tecnico || "Sem técnico"}
                            </span>
                            {o.cidade && (
                              <span className="flex items-center gap-1">
                                <MapPin className="w-3 h-3" /> {o.cidade}
                              </span>
                            )}
                          </div>
                        </DraggableCard>
                      ))}
                      {items.length === 0 && <EmptyHint />}
                    </Column>
                  )
                })}
              </div>
              </DndContext>
          )}
        </TabsContent>

        {/* ABA PROJETOS, escolhe 1 das 3 seções, depois entra no kanban */}
        <TabsContent value="projetos" className="flex-1 mt-4">
          {projTipo === null ? (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-4xl">
              {([
                ["OBRA", "Projetos de Obra", "Projetos ligados às obras físicas.", HardHat],
                ["SOFTWARE", "Arquivos de Software", "Programação de controladoras, firmware e configs.", DraftingCompass],
                ["CONTROLLARES", "Projetos Controllares", "Áudio/vídeo, rede, automação e segurança.", Wrench],
              ] as const).map(([v, titulo, desc, Icon]) => {
                const qtd = obras.filter(o => (o.tipo_projeto ?? "OBRA") === v).length
                return (
                  <button key={v} onClick={() => setProjTipo(v)}
                    className="text-left bg-surface-1 border border-hairline rounded-2xl p-5 hover:border-primary/40 hover:shadow-sm transition-all">
                    <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                      <Icon className="w-5 h-5 text-primary" />
                    </div>
                    <p className="text-foreground font-semibold">{titulo}</p>
                    <p className="text-muted-fg text-xs mt-1 leading-snug">{desc}</p>
                    <p className="text-[11px] text-muted-fg mt-3">{qtd} {qtd === 1 ? "projeto" : "projetos"}</p>
                  </button>
                )
              })}
            </div>
          ) : (
          <>
          <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
            <button onClick={() => setProjTipo(null)} className="flex items-center gap-1 text-ios-blue text-sm hover:opacity-70">
              <ChevronDown className="w-4 h-4 rotate-90" /> Projetos
            </button>
            <Button onClick={() => { setObraModalTipo("projeto"); setObraModal(true) }} className="gap-1.5">
              <Plus className="w-4 h-4" /> Novo Projeto
            </Button>
          </div>
          {loading ? <Loading /> : projTipo === "SOFTWARE" ? (
            /* Arquivos de Software: sem kanban — lista direta que leva aos arquivos/engenharia */
            (() => {
              const lista = obras.filter(o => (o.tipo_projeto ?? "OBRA") === "SOFTWARE")
              if (lista.length === 0) return <div className="py-16 text-center text-muted-foreground/40 text-sm">Nenhum projeto de software. Use “Novo Projeto” e marque o tipo como Software.</div>
              return (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                  {lista.map(o => (
                    <button key={o.id} onClick={() => router.push(`/obras/${o.id}?modo=projeto&tab=engenharia&sub=anexos`)}
                      className="text-left bg-surface-1 border border-hairline rounded-2xl p-4 hover:border-primary/40 transition-all">
                      <div className="flex items-center gap-2">
                        <DraftingCompass className="w-4 h-4 text-primary" />
                        <p className="text-foreground font-medium truncate">{o.client_name}</p>
                      </div>
                      <p className="text-muted-fg text-xs mt-1">Programação / firmware / configs</p>
                      <span className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                        <User className="w-3 h-3" /> {o.resp_tecnico || "Sem técnico"}
                      </span>
                      <select value={o.tipo_projeto ?? "OBRA"}
                        onClick={e => e.stopPropagation()} onChange={e => { e.stopPropagation(); mudarTipoProjeto(o.id, e.target.value) }}
                        className="mt-2 w-full h-7 px-2 rounded-lg bg-muted border border-border text-foreground text-[11px] outline-none">
                        <option value="OBRA">Projeto de Obra</option>
                        <option value="SOFTWARE">Software</option>
                        <option value="CONTROLLARES">Controllares</option>
                      </select>
                    </button>
                  ))}
                </div>
              )
            })()
          ) : (
            <DndContext collisionDetection={closestCenter} onDragStart={onDragStart}
              onDragEnd={makeDragEnd((id, col) => moveProjeto(id, col), COLS_PROJETO)}>
              <div className="flex gap-3 overflow-x-auto pb-4">
                {COLS_PROJETO.map((col, ci) => {
                  const items = obras.filter(o => (o.tipo_projeto ?? "OBRA") === projTipo && projCol(o) === col)
                  return (
                    <Column key={col} id={col} label={col} count={items.length} colorIdx={ci}>
                      {items.map(o => (
                        <DraggableCard key={o.id} id={o.id} onClick={() => router.push(`/obras/${o.id}?modo=projeto&tab=engenharia&sub=projetos`)}>
                          <p className="text-foreground font-medium text-sm truncate">{o.client_name}</p>
                          <p className="text-muted-foreground text-xs mt-0.5">{o.etapa_projeto || "Novo projeto"}</p>
                          <span className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                            <User className="w-3 h-3" /> {o.resp_tecnico || "Sem técnico"}
                          </span>
                          <select value={o.tipo_projeto ?? "OBRA"}
                            onClick={e => e.stopPropagation()}
                            onPointerDown={e => e.stopPropagation()}
                            onChange={e => { e.stopPropagation(); mudarTipoProjeto(o.id, e.target.value) }}
                            className="mt-2 w-full h-7 px-2 rounded-lg bg-muted border border-border text-foreground text-[11px] outline-none">
                            <option value="OBRA">Projeto de Obra</option>
                            <option value="SOFTWARE">Software</option>
                            <option value="CONTROLLARES">Controllares</option>
                          </select>
                        </DraggableCard>
                      ))}
                      {items.length === 0 && <EmptyHint />}
                    </Column>
                  )
                })}
              </div>
              </DndContext>
          )}
          </>
          )}
        </TabsContent>

        {/* ABA MANUTENÇÕES */}
        <TabsContent value="manutencoes" className="flex-1 mt-4">
          <div className="flex justify-end mb-3">
            <Button onClick={() => setMntModal(true)} className="gap-1.5">
              <Plus className="w-4 h-4" /> Nova Manutenção
            </Button>
          </div>
          {loading ? <Loading /> : (
            <DndContext collisionDetection={closestCenter} onDragStart={onDragStart}
              onDragEnd={makeDragEnd((id, col) => moveManutencao(id, col), COLS_MANUTENCAO.map(c => c.id))}>
              <div className="flex gap-3 overflow-x-auto pb-4">
                {COLS_MANUTENCAO.map((col, ci) => {
                  const items = manutencoes.filter(m => m.status === col.id)
                  return (
                    <Column key={col.id} id={col.id} label={col.label} count={items.length} colorIdx={ci}>
                      {items.map(m => {
                        const feitos = (m.checklist || []).filter(c => c.feito).length
                        const totalCk = (m.checklist || []).length
                        return (
                          <DraggableCard key={m.id} id={m.id} onClick={() => abrirRegistro(m)}>
                            <p className="text-foreground font-medium text-sm">{m.titulo}</p>
                            {m.obra_nome && <p className="text-muted-foreground text-xs mt-0.5">{m.obra_nome}</p>}
                            {m.descricao && <p className="text-muted-foreground/60 text-xs mt-1 line-clamp-2">{m.descricao}</p>}
                            {(totalCk > 0 || m.registro_notas || (m.anexos?.length ?? 0) > 0) && (
                              <div className="flex items-center gap-2 mt-1.5 text-[11px] text-muted-foreground/60">
                                {totalCk > 0 && <span className={feitos === totalCk ? "text-ios-green" : ""}>☑ {feitos}/{totalCk}</span>}
                                {m.registro_notas && <span>📝</span>}
                                {(m.anexos?.length ?? 0) > 0 && <span>📎 {m.anexos!.length}</span>}
                              </div>
                            )}
                          </DraggableCard>
                        )
                      })}
                      {items.length === 0 && <EmptyHint />}
                    </Column>
                  )
                })}
              </div>
              </DndContext>
          )}
        </TabsContent>
      </Tabs>

      <Dialog open={mntModal} onOpenChange={setMntModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <div className="mx-auto mb-3 w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
              <Wrench className="w-7 h-7 text-primary" />
            </div>
            <DialogTitle className="text-center text-xl">Nova Manutenção</DialogTitle>
            <DialogDescription className="text-center pt-1">
              Abra um chamado vinculado a uma obra existente.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 px-5 sm:px-6 py-4">
            <div className="space-y-1">
              <Label className="text-sm">Obra</Label>
              <select value={mntObraId} onChange={e => setMntObraId(e.target.value)}
                className="w-full h-9 px-3 rounded-xl bg-muted/50 border border-border text-foreground text-sm focus:outline-none focus:ring-1 focus:ring-primary/30">
                <option value="">Selecione a obra...</option>
                {obras.map(o => (
                  <option key={o.id} value={o.id}>{o.client_name}{o.cidade ? `, ${o.cidade}` : ""}</option>
                ))}
              </select>
            </div>
            <div className="space-y-1">
              <Label className="text-sm">Título do chamado</Label>
              <Input value={mntTitulo} onChange={e => setMntTitulo(e.target.value)}
                placeholder="Ex: Trocar fonte do rack" />
            </div>
            <div className="space-y-1">
              <Label className="text-sm">Descrição (opcional)</Label>
              <Textarea value={mntDesc} onChange={e => setMntDesc(e.target.value)} rows={3}
                placeholder="Detalhes do problema..." />
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-2">
            <Button variant="outline" onClick={() => setMntModal(false)} className="flex-1">Cancelar</Button>
            <Button onClick={criarManutencao} disabled={!mntObraId || !mntTitulo.trim() || savingMnt}
              className="flex-1 gap-1.5">
              {savingMnt ? <><RefreshCw className="w-4 h-4 animate-spin" /> Salvando...</> : <><Plus className="w-4 h-4" /> Abrir Chamado</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Criação manual de Obra / Projeto (Bloco 7) */}
      <Dialog open={obraModal} onOpenChange={o => { if (!o) { setObraModal(false); setObraNome(""); setObraPropBusca(""); setObraPropSel(null); setObraProps([]) } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <div className="mx-auto mb-3 w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
              {obraModalTipo === "projeto" ? <DraftingCompass className="w-7 h-7 text-primary" /> : <HardHat className="w-7 h-7 text-primary" />}
            </div>
            <DialogTitle className="text-center text-xl">
              {obraModalTipo === "projeto" ? "Novo Projeto" : "Nova Obra"}
            </DialogTitle>
            <DialogDescription className="text-center pt-1">
              Vincule uma proposta aceita (opcional) ou crie em branco.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 px-5 sm:px-6 py-4">
            <div className="space-y-1">
              <Label className="text-sm">Proposta de origem (opcional)</Label>
              {obraPropSel ? (
                <div className="flex items-center justify-between px-3 py-2 rounded-xl bg-primary/10 border border-primary/30 text-sm">
                  <span className="truncate">{obraPropSel.numero}, {obraPropSel.client_name}</span>
                  <button onClick={() => setObraPropSel(null)} className="text-ios-red text-xs flex-shrink-0 ml-2">Trocar</button>
                </div>
              ) : (
                <>
                  <Input value={obraPropBusca} onChange={e => setObraPropBusca(e.target.value)}
                    placeholder="Buscar por número ou cliente..." />
                  {obraProps.length > 0 ? (
                    <div className="max-h-40 overflow-y-auto rounded-xl border border-border bg-muted/50 divide-y divide-border">
                      {obraProps.map(p => (
                        <button key={p.id} onClick={() => { setObraPropSel(p); setObraNome(p.client_name) }}
                          className="w-full text-left px-3 py-2 text-sm hover:bg-muted transition-colors flex items-center justify-between gap-2">
                          <span className="truncate"><span className="font-medium">{p.numero}</span>, {p.client_name}</span>
                          {p.status && <span className="text-[10px] uppercase tracking-wide text-muted-foreground flex-shrink-0">{p.status.replace(/_/g, " ")}</span>}
                        </button>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[11px] text-muted-foreground/70">
                      Nenhuma proposta disponível.
                    </p>
                  )}
                </>
              )}
            </div>
            <div className="space-y-1">
              <Label className="text-sm">Nome / cliente</Label>
              <Input value={obraNome} onChange={e => setObraNome(e.target.value)}
                placeholder="Ex: Residência Silva" />
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-2">
            <Button variant="outline" onClick={() => setObraModal(false)} className="flex-1">Cancelar</Button>
            <Button onClick={criarObra} disabled={savingObra || !(obraPropSel?.client_name || obraNome).trim()}
              className="flex-1 gap-1.5">
              {savingObra ? <><RefreshCw className="w-4 h-4 animate-spin" /> Criando...</> : <><Plus className="w-4 h-4" /> Criar</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Registro da manutenção, notas, checklist e anexos */}
      <Dialog open={!!regTicket} onOpenChange={o => !o && setRegTicket(null)}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{regTicket?.titulo}</DialogTitle>
            <DialogDescription>
              {regTicket?.obra_nome ?? ""}, registre como foi a manutenção.
            </DialogDescription>
          </DialogHeader>
          {/* Indicador de página: 1 Checklist → 2 Relatório */}
          <div className="flex items-center gap-2 px-1">
            {[1, 2].map(s => (
              <div key={s} className={`flex-1 h-1 rounded-full transition-colors ${regStep >= s ? "bg-ios-blue" : "bg-surface-2"}`} />
            ))}
          </div>

          {regStep === 1 ? (
            /* ── PÁGINA 1: só o checklist ── */
            <div className="space-y-3 px-1 py-2">
              <Label className="text-sm">Checklist da manutenção</Label>
              {regChecklist.map(item => (
                <div key={item.id} className="flex items-center gap-2.5 group">
                  <button onClick={() => setRegChecklist(prev => prev.map(c => c.id === item.id ? { ...c, feito: !c.feito } : c))}
                    className={`w-5 h-5 rounded-md border flex items-center justify-center flex-shrink-0 transition-colors ${
                      item.feito ? "bg-ios-blue border-ios-blue text-background" : "border-border hover:border-ios-blue/50"
                    }`}>
                    {item.feito && <CheckCircle2 className="w-3.5 h-3.5" />}
                  </button>
                  <span className={`flex-1 text-sm ${item.feito ? "line-through text-muted-foreground/50" : "text-foreground"}`}>{item.texto}</span>
                  <button onClick={() => setRegChecklist(prev => prev.filter(c => c.id !== item.id))}
                    className="opacity-0 group-hover:opacity-100 text-muted-foreground/50 hover:text-destructive transition-all text-xs">✕</button>
                </div>
              ))}
              <div className="flex gap-2">
                <Input value={regNovoItem} onChange={e => setRegNovoItem(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === "Enter" && regNovoItem.trim()) {
                      setRegChecklist(prev => [...prev, { id: crypto.randomUUID(), texto: regNovoItem.trim(), feito: false }])
                      setRegNovoItem("")
                    }
                  }}
                  placeholder="Novo item... (Enter adiciona)" className="h-9 text-sm" />
                <Button variant="outline" size="sm" className="h-9"
                  disabled={!regNovoItem.trim()}
                  onClick={() => {
                    setRegChecklist(prev => [...prev, { id: crypto.randomUUID(), texto: regNovoItem.trim(), feito: false }])
                    setRegNovoItem("")
                  }}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ) : (
            /* ── PÁGINA 2: relatório do serviço + decisão do Admin ── */
            <div className="space-y-5 px-1 py-2">
              <div className="space-y-1.5">
                <Label className="text-sm">Como foi o serviço</Label>
                <Textarea value={regNotas} onChange={e => setRegNotas(e.target.value)} rows={3}
                  placeholder="Descreva o que foi feito, peças trocadas, pendências..." />
              </div>

              {/* Lista única, itens do catálogo (baixam estoque) + serviços livres */}
              <div className="space-y-2">
                <Label className="text-sm">Itens e serviços utilizados</Label>
                {regItens.map((it, i) => (
                  <div key={i} className="flex items-center gap-2 bg-surface-2 border border-hairline rounded-xl px-3 py-2">
                    <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md flex-shrink-0 ${it.tipo === "servico" ? "bg-ios-purple/15 text-ios-purple" : "bg-ios-blue/15 text-ios-blue"}`}>
                      {it.tipo === "servico" ? "SERVIÇO" : "ITEM"}
                    </span>
                    <span className="flex-1 text-sm text-foreground truncate">{it.nome}{it.sku ? <span className="text-muted-foreground text-xs font-mono"> [{it.sku}]</span> : null}</span>
                    <Input type="number" min="1" value={it.qtd}
                      onChange={e => setRegItens(prev => prev.map((x, j) => j === i ? { ...x, qtd: Math.max(1, Number(e.target.value) || 1) } : x))}
                      className="w-16 h-8 text-center text-sm" title="Quantidade" />
                    <button onClick={() => setRegItens(prev => prev.filter((_, j) => j !== i))}
                      className="text-muted-foreground/60 hover:text-destructive text-xs">✕</button>
                  </div>
                ))}

                {/* Buscar ITEM do catálogo, filtro por marca deixa a busca rápida */}
                <div className="flex gap-2">
                  <select value={regMarca} onChange={e => setRegMarca(e.target.value)}
                    className="h-10 px-2 rounded-xl bg-muted border border-border text-foreground text-[13px] outline-none max-w-[140px]">
                    <option value="">Todas marcas</option>
                    {regMarcas.map(m => <option key={m.id} value={m.id}>{m.nome}</option>)}
                  </select>
                  <div className="relative flex-1">
                    <Input value={regItemBusca} onChange={e => setRegItemBusca(e.target.value)}
                      placeholder={regMarca ? "Filtrar por nome/SKU..." : "Buscar item no catálogo..."} className="h-10 text-sm" />
                    {regItemResultados.length > 0 && (
                      <div className="absolute z-30 top-full left-0 right-0 mt-1 rounded-xl border border-hairline bg-surface-1 shadow-lg shadow-black/30 overflow-hidden max-h-52 overflow-y-auto">
                        {regItemResultados.filter(p => !regItens.some(x => x.productId === p.id)).map(p => (
                          <button key={p.id}
                            onClick={() => { setRegItens(prev => [...prev, { tipo: "produto", productId: p.id, nome: p.nome, sku: p.sku, qtd: 1 }]); setRegItemBusca(""); setRegItemResultados([]) }}
                            className="w-full text-left px-3 py-2 text-sm text-foreground hover:bg-white/5">
                            <Plus className="w-3 h-3 inline mr-1.5 text-ios-blue" />{p.nome} <span className="text-muted-foreground text-xs font-mono">[{p.sku}]</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Serviço livre, não é catálogo, técnico descreve */}
                <div className="flex gap-2">
                  <Input value={regServico} onChange={e => setRegServico(e.target.value)}
                    onKeyDown={e => {
                      if (e.key === "Enter" && regServico.trim()) {
                        setRegItens(prev => [...prev, { tipo: "servico", productId: `svc-${crypto.randomUUID()}`, nome: regServico.trim(), sku: "", qtd: 1 }])
                        setRegServico("")
                      }
                    }}
                    placeholder="Descreva um serviço prestado... (Enter)" className="h-10 text-sm flex-1" />
                  <Button variant="outline" size="sm" className="h-10" disabled={!regServico.trim()}
                    onClick={() => { setRegItens(prev => [...prev, { tipo: "servico", productId: `svc-${crypto.randomUUID()}`, nome: regServico.trim(), sku: "", qtd: 1 }]); setRegServico("") }}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-[11px] text-muted-foreground/60">Itens do catálogo baixam do estoque (pendente até o Admin decidir). Serviços não mexem no estoque.</p>
              </div>

              {/* Fotos e anexos, quantos quiser */}
              <div className="space-y-2">
                <Label className="text-sm">Fotos e anexos</Label>
                {regAnexos.map((a, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm group">
                    <FileText className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                    <a href={a.url} target="_blank" rel="noreferrer" className="flex-1 truncate text-ios-blue hover:underline">{a.nome}</a>
                    <button onClick={() => setRegAnexos(prev => prev.filter((_, j) => j !== i))}
                      className="opacity-0 group-hover:opacity-100 text-muted-foreground/50 hover:text-destructive transition-all text-xs">✕</button>
                  </div>
                ))}
                <label className={`flex items-center justify-center gap-2 h-10 rounded-xl border border-dashed border-border text-sm text-muted-foreground hover:text-foreground hover:border-ios-blue/40 transition-colors cursor-pointer ${regUploading ? "opacity-50 pointer-events-none" : ""}`}>
                  {regUploading ? <><RefreshCw className="w-4 h-4 animate-spin" /> Enviando...</> : <><Plus className="w-4 h-4" /> Adicionar arquivo</>}
                  <input type="file" multiple className="hidden" onChange={e => { for (const f of Array.from(e.target.files ?? [])) uploadAnexoRegistro(f); e.target.value = "" }} />
                </label>
              </div>

              {/* Decisão do ADMIN, vê o total e decide */}
              {meuRole === "ADMIN" && (regItens.length > 0 || regTicket?.item_catalogo_id) && (
                <div className="space-y-2 border-t border-hairline pt-4">
                  <Label className="text-sm">Decisão de faturamento (Admin)</Label>
                  {regTicket?.valor_total_itens != null && regTicket.valor_total_itens > 0 && (
                    <p className="text-sm text-foreground">
                      Total dos itens: <b>{Number(regTicket.valor_total_itens).toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}</b>
                    </p>
                  )}
                  {regTicket?.decisao_faturamento ? (
                    <p className={`text-sm font-medium ${regTicket.decisao_faturamento === "FATURAR" ? "text-ios-green" : "text-ios-orange"}`}>
                      {regTicket.decisao_faturamento === "FATURAR" ? "✓ Faturar do cliente" : "✓ Custeado internamente"}, baixa de estoque aplicada.
                    </p>
                  ) : (
                    <div className="flex gap-2">
                      <Button onClick={() => decidirFaturamento("FATURAR")} disabled={regDecidindo}
                        className="flex-1 bg-ios-green hover:bg-ios-green/90 text-background">Faturar do cliente</Button>
                      <Button onClick={() => decidirFaturamento("CUSTEADO")} disabled={regDecidindo} variant="outline"
                        className="flex-1">Custear internamente</Button>
                    </div>
                  )}
                  <p className="text-[11px] text-muted-foreground/60">A decisão autoriza e aplica as saídas no estoque.</p>
                </div>
              )}
            </div>
          )}

          <DialogFooter className="gap-2 sm:gap-2">
            {regStep === 1 ? (
              <>
                <Button variant="outline" onClick={() => router.push(`/obras/${regTicket?.obraId}`)} className="flex-1">Ver obra</Button>
                <Button
                  disabled={regChecklist.length > 0 && !regChecklist.every(c => c.feito)}
                  onClick={() => { salvarRegistro(false); setRegStep(2) }}
                  className="flex-1 gap-1.5">
                  Concluir checklist →
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={() => setRegStep(1)} className="flex-1">← Checklist</Button>
                <Button onClick={() => salvarRegistro(true)} disabled={regSaving} className="flex-1 gap-1.5">
                  {regSaving ? <><RefreshCw className="w-4 h-4 animate-spin" /> Salvando...</> : "Salvar registro"}
                </Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function Loading() {
  return <div className="flex items-center justify-center h-64"><PageLoader /></div>
}
function EmptyHint() {
  return <div className="flex items-center justify-center h-20 text-muted-foreground/30 text-xs">Arraste aqui</div>
}
function DragGhost({ label }: { label?: string }) {
  return (
    <div className="bg-card rounded-xl p-3 border border-primary/40 shadow-apple-float rotate-2 opacity-90 w-56">
      <p className="text-foreground font-medium text-sm truncate">{label || "..."}</p>
    </div>
  )
}
