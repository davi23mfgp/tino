import type { Metadata } from "next"

/* Só título de aba.

   A página desta seção é componente de cliente, e no App Router componente de
   cliente não exporta `metadata`. O layout de segmento é de servidor e exporta
   — por isso este arquivo existe sem desenhar nada.

   O rótulo é o mesmo do menu lateral: o que se lê na aba tem que bater com o
   que foi clicado. O sufixo vem do template no layout raiz. */
export const metadata: Metadata = { title: "Dimensionamento" }

export default function Layout({ children }: { children: React.ReactNode }) {
  return children
}
