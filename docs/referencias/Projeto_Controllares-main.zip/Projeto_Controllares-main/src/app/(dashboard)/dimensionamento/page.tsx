﻿"use client"

import { useState, useEffect, useCallback } from "react"
import { Maximize2, Search, Download, Pencil, Check, X, FileDown, RefreshCw } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { proxiedImg } from "@/lib/img"
import { useConfirmar } from "@/components/confirmar"

interface Product {
  id: string
  nome: string
  marca: string | null
  sku: string
  status: string
  peso_kg: number | null
  medidas_raw: string | null
  imagem_url: string | null
  largura_mm: number | null
  altura_mm: number | null
  profundidade_mm: number | null
  volume_cm3: number | null
  tipo_dimensao?: string | null
  outros_descricao?: string | null
  outros_formato?: string | null
  outros_formato_custom?: string | null
  outros_instalacao?: string | null
  outros_instalacao_custom?: string | null
  category: { id: string; nome: string } | null
}

function statusDimensao(p: Product) {
  const temDados = p.peso_kg || (p.largura_mm && p.altura_mm && p.profundidade_mm)
  return temDados ? "completo" : "sem_dados"
}

/**
 * Medida do item: 3 dimensões → volume em m³; só 2 (sem profundidade) → área em m².
 * Nem tudo é caixa — painel/forro/tela é superfície (m²).
 */
function medidaDoItem(p: Product): { valor: number; unidade: "m³" | "m²" } | null {
  const l = p.largura_mm, a = p.altura_mm, pr = p.profundidade_mm
  if (l && a && pr) return { valor: (l * a * pr) / 1_000_000_000, unidade: "m³" }
  if (l && a) return { valor: (l * a) / 1_000_000, unidade: "m²" }
  return null
}

// Remove zeros desnecessários: 3.00 → "3", 3.50 → "3.5"
function fmtN(v: string | number | null | undefined): string {
  if (!v && v !== 0) return "—"
  const n = Number(v)
  if (isNaN(n) || n === 0) return "—"
  return parseFloat(n.toFixed(4)).toString()
}

// SVG do formato como string pura (p/ relatório impresso) — cotas em mm.
// Mesma geometria dos diagramas do dimensionamento da obra.
function formatoSvgStr(formato: string, vals: { l: string; h: string; c: string }): string {
  const { l, h, c } = vals
  const vl = fmtN(l); const vh = fmtN(h); const vc = fmtN(c)
  const u = (v: string) => v !== "—" ? v + "cm" : ""
  const s = `stroke="#334155" fill="none" stroke-width="1.5"`
  const dd = `stroke="#1e40af" fill="none" stroke-width="1" stroke-dasharray="4 2"`
  const arrow = `fill="#1e40af"`
  const txt = `fill="#1e40af" font-size="9" font-family="monospace" text-anchor="middle"`
  const sub = `fill="#64748b" font-size="8" font-family="monospace" text-anchor="middle"`
  if (formato === "Circular") return `<svg viewBox="0 0 110 95" width="110" height="95" xmlns="http://www.w3.org/2000/svg"><circle cx="55" cy="48" r="33" ${s}/><line x1="22" y1="48" x2="88" y2="48" ${dd}/><polygon points="22,46 22,50 18,48" ${arrow}/><polygon points="88,46 88,50 92,48" ${arrow}/><text x="55" y="42" ${txt}>Ø ${u(vl)||"diâm."}</text><text x="55" y="88" ${sub}>A = π×(Ø/2)²</text></svg>`
  if (formato === "Oval") return `<svg viewBox="0 0 120 95" width="120" height="95" xmlns="http://www.w3.org/2000/svg"><ellipse cx="60" cy="47" rx="46" ry="27" ${s}/><line x1="14" y1="47" x2="106" y2="47" ${dd}/><polygon points="14,45 14,49 10,47" ${arrow}/><polygon points="106,45 106,49 110,47" ${arrow}/><text x="60" y="41" ${txt}>${u(vl)||"Ø H"}</text><line x1="60" y1="20" x2="60" y2="74" ${dd}/><text x="60" y="90" ${sub}>A = π×(H/2)×(V/2)</text></svg>`
  if (formato === "Quadrado") return `<svg viewBox="0 0 100 95" width="100" height="95" xmlns="http://www.w3.org/2000/svg"><rect x="15" y="13" width="70" height="70" ${s}/><line x1="15" y1="5" x2="85" y2="5" ${dd}/><polygon points="15,3 15,7 11,5" ${arrow}/><polygon points="85,3 85,7 89,5" ${arrow}/><text x="50" y="4" ${txt}>${u(vl)||"Lado"}</text><text x="50" y="90" ${sub}>A = Lado²</text></svg>`
  if (formato === "Retangular") return `<svg viewBox="0 0 120 95" width="120" height="95" xmlns="http://www.w3.org/2000/svg"><rect x="10" y="18" width="95" height="55" ${s}/><line x1="10" y1="8" x2="105" y2="8" ${dd}/><polygon points="10,6 10,10 6,8" ${arrow}/><polygon points="105,6 105,10 109,8" ${arrow}/><text x="57" y="7" ${txt}>${u(vl)||"Larg."}</text><line x1="112" y1="18" x2="112" y2="73" ${dd}/><text x="57" y="90" ${sub}>A = L × C</text></svg>`
  if (formato === "Triangular") return `<svg viewBox="0 0 120 100" width="120" height="100" xmlns="http://www.w3.org/2000/svg"><polygon points="60,10 8,82 112,82" ${s}/><line x1="8" y1="91" x2="112" y2="91" ${dd}/><polygon points="8,89 8,93 4,91" ${arrow}/><polygon points="112,89 112,93 116,91" ${arrow}/><text x="60" y="99" ${txt}>${u(vl)||"Base"}</text><line x1="60" y1="10" x2="60" y2="82" stroke="#1e40af" stroke-width="1" stroke-dasharray="3 2"/><polygon points="58,10 62,10 60,6" ${arrow}/><text x="69" y="50" ${txt}>${u(vh)||"Alt."}</text><text x="60" y="5" ${sub}>A = (B×Alt.)/2</text></svg>`
  if (formato === "Irregular") return `<svg viewBox="0 0 100 90" width="100" height="90" xmlns="http://www.w3.org/2000/svg"><polygon points="18,72 30,22 65,13 92,38 88,78 47,86" ${s} stroke-dasharray="5 3"/><text x="50" y="50" fill="#94a3b8" font-size="14" font-family="monospace" text-anchor="middle">?</text><text x="50" y="88" ${sub}>Área manual</text></svg>`
  return ""
}

// Diagrama SVG por formato (JSX) — usado no modal de especificação.
function FormatoSVG({ formato }: { formato: string }) {
  const confirmar = useConfirmar()
  const s = { stroke: "#94a3b8", fill: "none", strokeWidth: 1.5 }
  const dim = { stroke: "#38bdf8", fill: "none", strokeWidth: 1, strokeDasharray: "4 2" }
  const txt = { fill: "#38bdf8", fontSize: 10, fontFamily: "monospace" }
  const arrow = "#38bdf8"
  if (formato === "Circular") return (
    <svg viewBox="0 0 120 100" width={120} height={100}>
      <circle cx={60} cy={50} r={36} {...s} />
      <line x1={24} y1={50} x2={96} y2={50} {...dim} />
      <polygon points={`24,48 24,52 20,50`} fill={arrow} /><polygon points={`96,48 96,52 100,50`} fill={arrow} />
      <text x={60} y={44} textAnchor="middle" {...txt}>Ø diâm.</text>
      <text x={60} y={90} textAnchor="middle" fill="#64748b" fontSize={9} fontFamily="monospace">A = π × (Ø/2)²</text>
    </svg>
  )
  if (formato === "Oval") return (
    <svg viewBox="0 0 130 100" width={130} height={100}>
      <ellipse cx={65} cy={50} rx={48} ry={28} {...s} />
      <line x1={17} y1={50} x2={113} y2={50} {...dim} />
      <polygon points={`17,48 17,52 13,50`} fill={arrow} /><polygon points={`113,48 113,52 117,50`} fill={arrow} />
      <text x={65} y={44} textAnchor="middle" {...txt}>Ø H</text>
      <line x1={65} y1={22} x2={65} y2={78} {...dim} />
      <polygon points={`63,22 67,22 65,18`} fill={arrow} /><polygon points={`63,78 67,78 65,82`} fill={arrow} />
      <text x={75} y={54} {...txt}>Ø V</text>
      <text x={65} y={95} textAnchor="middle" fill="#64748b" fontSize={9} fontFamily="monospace">A = π × (H/2) × (V/2)</text>
    </svg>
  )
  if (formato === "Quadrado") return (
    <svg viewBox="0 0 110 100" width={110} height={100}>
      <rect x={20} y={15} width={70} height={70} {...s} />
      <line x1={20} y1={6} x2={90} y2={6} {...dim} />
      <polygon points={`20,4 20,8 16,6`} fill={arrow} /><polygon points={`90,4 90,8 94,6`} fill={arrow} />
      <text x={55} y={4} textAnchor="middle" {...txt}>Lado</text>
      <text x={55} y={92} textAnchor="middle" fill="#64748b" fontSize={9} fontFamily="monospace">A = Lado²</text>
    </svg>
  )
  if (formato === "Retangular") return (
    <svg viewBox="0 0 130 100" width={130} height={100}>
      <rect x={15} y={20} width={100} height={55} {...s} />
      <line x1={15} y1={8} x2={115} y2={8} {...dim} />
      <polygon points={`15,6 15,10 11,8`} fill={arrow} /><polygon points={`115,6 115,10 119,8`} fill={arrow} />
      <text x={65} y={6} textAnchor="middle" {...txt}>Larg.</text>
      <line x1={120} y1={20} x2={120} y2={75} {...dim} />
      <polygon points={`118,20 122,20 120,16`} fill={arrow} /><polygon points={`118,75 122,75 120,79`} fill={arrow} />
      <text x={126} y={51} textAnchor="middle" {...txt} fontSize={9}>Comp.</text>
      <text x={65} y={95} textAnchor="middle" fill="#64748b" fontSize={9} fontFamily="monospace">A = Larg. × Comp.</text>
    </svg>
  )
  if (formato === "Triangular") return (
    <svg viewBox="0 0 130 105" width={130} height={105}>
      <polygon points="65,12 10,85 120,85" {...s} />
      <line x1={10} y1={94} x2={120} y2={94} {...dim} />
      <polygon points={`10,92 10,96 6,94`} fill={arrow} /><polygon points={`120,92 120,96 124,94`} fill={arrow} />
      <text x={65} y={102} textAnchor="middle" {...txt}>Base</text>
      <line x1={65} y1={12} x2={65} y2={85} stroke="#38bdf8" strokeWidth={1} strokeDasharray="3 2" />
      <line x1={56} y1={70} x2={74} y2={70} stroke="#38bdf8" strokeWidth={1} />
      <polygon points={`63,12 67,12 65,8`} fill={arrow} /><polygon points={`63,85 67,85 65,89`} fill={arrow} />
      <text x={73} y={52} {...txt}>Alt.</text>
      <text x={65} y={6} textAnchor="middle" fill="#64748b" fontSize={9} fontFamily="monospace">A = (Base × Alt.) / 2</text>
    </svg>
  )
  if (formato === "Irregular") return (
    <svg viewBox="0 0 120 100" width={120} height={100}>
      <polygon points="20,75 35,25 70,15 100,40 95,80 50,90" {...s} strokeDasharray="5 3" />
      <text x={60} y={52} textAnchor="middle" fill="#94a3b8" fontSize={11} fontFamily="monospace">?</text>
      <text x={60} y={95} textAnchor="middle" fill="#64748b" fontSize={9} fontFamily="monospace">Área manual (m²)</text>
    </svg>
  )
  return null
}

function exportCSV(products: Product[], nomeArquivo = "dimensionamento.csv") {
  const header = "Nome,Marca,SKU,Peso(kg),Largura(cm),Altura(cm),Prof(cm),Volume(m³),Medidas Raw"
  const rows = products.map(p =>
    [p.nome, p.marca || "", p.sku,
     p.peso_kg ?? "", p.largura_mm != null ? p.largura_mm / 10 : "", p.altura_mm != null ? p.altura_mm / 10 : "",
     p.profundidade_mm != null ? p.profundidade_mm / 10 : "", p.volume_cm3 != null ? p.volume_cm3 / 1_000_000 : "", p.medidas_raw || ""]
    .map(v => `"${v}"`).join(",")
  )
  const blob = new Blob([[header, ...rows].join("\n")], { type: "text/csv;charset=utf-8;" })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a"); a.href = url
  a.download = nomeArquivo; a.click()
  URL.revokeObjectURL(url)
}

/**
 * Relatório avulso — mesmo template visual do relatório de dimensionamento
 * da obra (cabeçalho, seção com borda de destaque, tabela profissional).
 */
async function gerarRelatorioAvulso(
  products: Product[], origemLabel: string | undefined, logoUrl: string | undefined,
  avisar: (msg: string) => void,
) {
  const absImg = (u: string | null) => {
    if (!u) return ""
    const p = proxiedImg(u)
    return p.startsWith("/") ? location.origin + p : p
  }
  // Caixa 3D isométrica simples com cotas L × A × P
  const caixaSvg = (l?: number | null, a?: number | null, pr?: number | null) => {
    if (!(l && a && pr)) return `<div class="svg-ph">—</div>`
    return `<svg viewBox="0 0 120 100" class="box-svg">
      <polygon points="20,35 70,35 70,80 20,80" fill="#e8eef7" stroke="#1e40af" stroke-width="1.5"/>
      <polygon points="20,35 40,20 90,20 70,35" fill="#f4f7fc" stroke="#1e40af" stroke-width="1.5"/>
      <polygon points="70,35 90,20 90,65 70,80" fill="#dbe4f3" stroke="#1e40af" stroke-width="1.5"/>
      <text x="45" y="94" text-anchor="middle" font-size="9" fill="#1e40af" font-weight="700">${l}</text>
      <text x="9" y="60" text-anchor="middle" font-size="9" fill="#1e40af" font-weight="700" transform="rotate(-90 9 60)">${a}</text>
      <text x="83" y="16" text-anchor="middle" font-size="9" fill="#7c3aed" font-weight="700">${pr}</text>
    </svg>`
  }
  const linha = (p: Product) => {
    const temMedidas = p.largura_mm && p.altura_mm && p.profundidade_mm
    const img = absImg(p.imagem_url)
    // Forma: se tem formato especificado (Outros), usa o diagrama geométrico da obra;
    // senão, a caixa isométrica com L×A×P.
    const fmt = p.outros_formato === "Outros" ? "" : (p.outros_formato || "")
    const svgForma = fmt
      ? formatoSvgStr(fmt, { l: String(p.largura_mm != null ? p.largura_mm / 10 : ""), h: String(p.altura_mm != null ? p.altura_mm / 10 : ""), c: String(p.profundidade_mm != null ? p.profundidade_mm / 10 : "") })
      : caixaSvg(p.largura_mm, p.altura_mm, p.profundidade_mm)
    const fmtLabel = p.outros_formato === "Outros" ? (p.outros_formato_custom || "Outros") : (p.outros_formato || "")
    const instLabel = p.outros_instalacao === "Outros" ? (p.outros_instalacao_custom || "Outros") : (p.outros_instalacao || "")
    const tag = [p.tipo_dimensao, fmtLabel].filter(Boolean).join(" · ")
    return `
      <tr>
        <td class="photo-cell">${img ? `<img src="${img}" class="thumb"/>` : `<div class="thumb noimg">—</div>`}</td>
        <td class="shape-cell">${svgForma || `<div class="svg-ph">—</div>`}</td>
        <td class="item-info-cell">
          <div class="item-nome">${p.nome} <span class="sku">[${p.sku}]</span></div>
          ${p.marca ? `<div class="item-tag-marca">${p.marca}</div>` : ""}
          ${tag ? `<div class="item-tag">${tag}</div>` : ""}
          ${p.outros_descricao ? `<div class="item-desc">${p.outros_descricao}</div>` : ""}
          ${instLabel ? `<div class="item-desc">Instalação: ${instLabel}</div>` : ""}
        </td>
        <td class="num">${p.peso_kg != null ? `${fmtN2(p.peso_kg)} kg` : `<span style="color:#94a3b8">—</span>`}</td>
        <td class="num">${temMedidas ? `${fmtN(p.largura_mm! / 10)} × ${fmtN(p.altura_mm! / 10)} × ${fmtN(p.profundidade_mm! / 10)} cm` : `<span style="color:#94a3b8">—</span>`}</td>
        <td class="num">${(() => { const m = medidaDoItem(p); return m ? `${fmtN(m.valor)} ${m.unidade}` : `<span style="color:#94a3b8">—</span>` })()}</td>
      </tr>`
  }

  const html = `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"/>
    <title>Relatório de Dimensionamento, Itens Avulsos</title>
    <style>
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:Arial,Helvetica,sans-serif;background:#fff;color:#1e293b;font-size:11px;padding:24px 28px;max-width:960px;margin:0 auto}
      .doc-header{display:flex;align-items:flex-start;justify-content:space-between;border-bottom:2px solid #1e40af;padding-bottom:12px;margin-bottom:20px}
      .doc-title{font-size:16px;font-weight:700;color:#0f172a;letter-spacing:-.3px}
      .doc-subtitle{font-size:10px;color:#64748b;margin-top:2px;text-transform:uppercase;letter-spacing:.6px}
      .doc-meta{margin-top:8px;display:grid;grid-template-columns:auto auto;column-gap:32px;row-gap:2px}
      .doc-meta-row{font-size:11px;color:#475569}
      .doc-meta-row b{color:#0f172a}
      .section{margin-bottom:22px;page-break-inside:avoid}
      .section-header{display:flex;align-items:center;gap:8px;background:#f8fafc;border-left:3px solid #1e40af;padding:5px 8px;margin-bottom:6px}
      .section-title{font-size:12px;font-weight:700;color:#0f172a}
      .section-count{font-size:10px;color:#94a3b8;background:#e2e8f0;padding:1px 6px;border-radius:10px}
      .items-table{width:100%;border-collapse:collapse;font-size:10.5px}
      .items-table thead tr{background:#f1f5f9}
      .items-table th{padding:6px;text-align:center;border:1px solid #e2e8f0;font-weight:600;color:#475569;white-space:nowrap}
      .items-table th:first-child{text-align:left}
      .items-table td{padding:6px;border:1px solid #e2e8f0;vertical-align:top}
      .num{text-align:center;white-space:nowrap;vertical-align:middle}
      .item-info-cell{vertical-align:top;padding:6px}
      .item-nome{font-weight:600;font-size:11px;color:#0f172a}
      .sku{font-weight:400;color:#94a3b8;font-size:10px}
      .item-tag-marca{margin-top:2px;font-size:10px;color:#64748b;font-weight:500}
      .item-tag{margin-top:2px;font-size:10px;color:#1e40af;font-weight:600}
      .item-desc{font-size:9.5px;color:#94a3b8;margin-top:1px}
      .header-logo{max-height:52px;max-width:140px;object-fit:contain}
      .photo-cell{width:70px;text-align:center;vertical-align:middle;padding:5px}
      .thumb{width:60px;height:60px;object-fit:cover;border-radius:5px;display:block;margin:0 auto}
      .thumb.noimg{width:60px;height:60px;background:#f1f5f9;display:flex;align-items:center;justify-content:center;color:#cbd5e1;border-radius:5px;margin:0 auto}
      .shape-cell{width:90px;text-align:center;vertical-align:middle}
      .shape-cell svg{width:82px;height:66px}
      .box-svg{width:72px;height:60px}
      .svg-ph{width:72px;height:60px;color:#cbd5e1;display:flex;align-items:center;justify-content:center}
      .doc-footer{margin-top:24px;border-top:1px solid #e2e8f0;padding-top:8px;color:#94a3b8;font-size:9.5px;display:flex;justify-content:space-between}
      .actions{margin-bottom:16px}
      .actions button{background:#1e40af;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:13px;cursor:pointer;font-weight:600}
      @media print{.actions{display:none}body{padding:0}}
    </style></head><body>
    <div class="actions"><button onclick="window.print()">Imprimir / Salvar PDF</button></div>
    <div class="doc-header">
      <div>
        <div class="doc-title">Relatório de Dimensionamento</div>
        <div class="doc-subtitle">Itens avulsos do catálogo</div>
        <div class="doc-meta">
          ${origemLabel ? `<div class="doc-meta-row">Origem: <b>${origemLabel}</b></div>` : "<div></div>"}
          <div class="doc-meta-row">Data: <b>${new Date().toLocaleDateString("pt-BR")}</b></div>
        </div>
      </div>
      ${logoUrl ? `<img src="${absImg(logoUrl)}" alt="logo" class="header-logo"/>` : ""}
    </div>
    <div class="section">
      <div class="section-header">
        <span class="section-title">Itens selecionados</span>
        <span class="section-count">${products.length} ${products.length === 1 ? "item" : "itens"}</span>
      </div>
      <table class="items-table">
        <thead><tr><th>Foto</th><th>Forma</th><th>Item</th><th>Peso</th><th>L × A × P (cm)</th><th>Volume</th></tr></thead>
        <tbody>${products.map(linha).join("")}</tbody>
      </table>
    </div>
    <div class="doc-footer">
      <span>Control.Deal, Sistema de Gestão de Obras</span>
      <span>Gerado em ${new Date().toLocaleString("pt-BR")}</span>
    </div>
  </body></html>`
  const win = window.open("", "_blank", "width=1000,height=750")
  // /* Bloqueio de pop-up é do navegador, não do sistema: o relatório abre em
  //    outra aba e não há como contornar por código. Avisar é o que resta. */
  if (!win) { avisar("Permita pop-ups para gerar o relatório."); return }
  win.document.write(html)
  win.document.close()
}
function fmtN2(n: number) { return Number(n.toFixed(2)).toString().replace(".", ",") }

interface EditState {
  peso_kg: string
  largura_mm: string
  altura_mm: string
  profundidade_mm: string
}

export default function DimensionamentoPage() {
  const confirmar = useConfirmar()
  const [products, setProducts] = useState<Product[]>([])
  const [total, setTotal] = useState(0)
  const [pages, setPages] = useState(1)
  const [page, setPage] = useState(1)
  const [limit] = useState(20)
  const [loading, setLoading] = useState(false)
  const [search, setSearch] = useState("")
  const [marcaFiltro, setMarcaFiltro] = useState("")
  const [marcas, setMarcas] = useState<string[]>([])
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editState, setEditState] = useState<EditState>({ peso_kg: "", largura_mm: "", altura_mm: "", profundidade_mm: "" })
  const [saving, setSaving] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  // Itens trazidos via "Sincronizar com proposta" — podem não estar na página atual
  const [extraProducts, setExtraProducts] = useState<Product[]>([])
  const [origemSync, setOrigemSync] = useState<string | null>(null)
  const [syncOpen, setSyncOpen] = useState(false)
  const [propostas, setPropostas] = useState<{ id: string; numero: string; client_name: string }[]>([])
  const [buscaProposta, setBuscaProposta] = useState("")
  const [syncing, setSyncing] = useState(false)
  const [empresaLogoUrl, setEmpresaLogoUrl] = useState<string | undefined>(undefined)

  useEffect(() => {
    fetch("/api/empresa").then(r => r.ok ? r.json() : null).then(data => {
      if (data?.logo_url) setEmpresaLogoUrl(data.logo_url)
    }).catch(() => {})
  }, [])

  // ── Especificação do item (descrição livre + formato + instalação) ──
  // Clique único na coluna Tipo abre direto o modal — sem passo Gesso/Marcenaria/Outros.
  const [outrosOpen, setOutrosOpen] = useState(false)
  const [outrosProdId, setOutrosProdId] = useState<string | null>(null)
  const [outrosForm, setOutrosForm] = useState({ descricao: "", formato: "", formato_custom: "", instalacao: "", instalacao_custom: "" })

  function abrirEspec(p: Product) {
    setOutrosProdId(p.id)
    setOutrosForm({
      descricao: p.outros_descricao || "", formato: p.outros_formato || "", formato_custom: p.outros_formato_custom || "",
      instalacao: p.outros_instalacao || "", instalacao_custom: p.outros_instalacao_custom || "",
    })
    setOutrosOpen(true)
  }

  async function salvarOutros() {
    if (!outrosProdId) return
    const payload = {
      id: outrosProdId,
      outros_descricao: outrosForm.descricao,
      outros_formato: outrosForm.formato,
      outros_formato_custom: outrosForm.formato_custom,
      outros_instalacao: outrosForm.instalacao,
      outros_instalacao_custom: outrosForm.instalacao_custom,
    }
    setProducts(prev => prev.map(x => x.id === outrosProdId ? { ...x, ...payload } : x))
    await fetch("/api/dimensionamento", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    })
    setOutrosOpen(false)
  }

  useEffect(() => {
    if (!syncOpen || propostas.length > 0) return
    fetch("/api/propostas").then(r => r.ok ? r.json() : null).then(d => {
      if (d?.proposals) setPropostas(d.proposals.map((p: { id: string; numero: string; client_name: string }) => ({ id: p.id, numero: p.numero, client_name: p.client_name })))
    }).catch(() => {})
  }, [syncOpen, propostas.length])

  async function sincronizarComProposta(propId: string, label: string) {
    setSyncing(true)
    try {
      const r = await fetch(`/api/propostas/${propId}`)
      if (!r.ok) return
      const prop = await r.json()
      const ids = new Set<string>()
      for (const env of prop.environments ?? []) {
        for (const item of env.proposalItems ?? []) {
          if (item.product?.id) ids.add(item.product.id)
        }
      }
      if (ids.size === 0) { setSyncOpen(false); return }
      const res = await fetch(`/api/dimensionamento?ids=${[...ids].join(",")}`)
      const data = await res.json()
      setExtraProducts(data.products || [])
      setSelected(new Set(ids))
      setOrigemSync(label)
      setSyncOpen(false)
      setBuscaProposta("")
    } finally { setSyncing(false) }
  }

  // Une os itens da página atual com os trazidos via sync (sem duplicar)
  const allKnownProducts = (() => {
    const map = new Map<string, Product>()
    for (const p of extraProducts) map.set(p.id, p)
    for (const p of products) map.set(p.id, p)
    return [...map.values()]
  })()

  function toggleSelect(id: string) {
    setSelected(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id); else next.add(id)
      return next
    })
  }
  function toggleSelectAll() {
    setSelected(prev => prev.size === products.length ? new Set() : new Set(products.map(p => p.id)))
  }

  const fetchData = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({
        page: String(page), limit: String(limit),
        search, marca: marcaFiltro,
      })
      const res = await fetch(`/api/dimensionamento?${params}`)
      const data = await res.json()
      setProducts(data.products || [])
      setTotal(data.total || 0)
      setPages(data.pages || 1)
      if (data.marcas) setMarcas(data.marcas)
    } finally {
      setLoading(false)
    }
  }, [page, limit, search, marcaFiltro])

  useEffect(() => { fetchData() }, [fetchData])

  // UI trabalha em CENTÍMETROS; o banco continua em mm (÷10 ao exibir, ×10 ao salvar).
  function startEdit(p: Product) {
    setEditingId(p.id)
    setEditState({
      peso_kg: p.peso_kg != null ? String(p.peso_kg) : "",
      largura_mm: p.largura_mm != null ? String(p.largura_mm / 10) : "",
      altura_mm: p.altura_mm != null ? String(p.altura_mm / 10) : "",
      profundidade_mm: p.profundidade_mm != null ? String(p.profundidade_mm / 10) : "",
    })
  }

  async function saveEdit(id: string) {
    setSaving(true)
    try {
      const l = (parseFloat(editState.largura_mm) || 0) * 10 || null
      const a = (parseFloat(editState.altura_mm) || 0) * 10 || null
      const pr = (parseFloat(editState.profundidade_mm) || 0) * 10 || null
      const medidas_raw = l && a && pr ? `${l}x${a}x${pr}mm` : null
      await fetch("/api/dimensionamento", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id,
          peso_kg: parseFloat(editState.peso_kg) || null,
          largura_mm: l, altura_mm: a, profundidade_mm: pr,
          medidas_raw,
        }),
      })
      setEditingId(null)
      fetchData()
    } finally {
      setSaving(false)
    }
  }

  const semDados = products.filter(p => statusDimensao(p) === "sem_dados").length
  const completos = products.filter(p => statusDimensao(p) === "completo").length

  return (
    <div className="px-4 py-4 md:px-6 md:py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight flex items-center gap-2">
            <Maximize2 className="w-6 h-6 text-primary" /> Dimensionamento
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            {total} produto{total !== 1 ? "s" : ""}, {completos} completos, {semDados} sem dados
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap relative">
          <div className="relative">
            <Button variant="outline" onClick={() => setSyncOpen(o => !o)}
              className="flex items-center gap-2 border-border text-foreground">
              <RefreshCw className="w-4 h-4" /> Sincronizar com proposta
            </Button>
            {syncOpen && (
              <>
                <div className="fixed inset-0 z-20" onClick={() => setSyncOpen(false)} />
                <div className="absolute right-0 top-full mt-1.5 z-30 w-[300px] rounded-2xl border border-hairline bg-surface-1 shadow-lg shadow-black/30 overflow-hidden">
                  <div className="p-2 border-b border-hairline">
                    <Input autoFocus value={buscaProposta} onChange={e => setBuscaProposta(e.target.value)}
                      placeholder="Buscar por cliente ou número..." className="h-9 text-sm" />
                  </div>
                  <div className="max-h-72 overflow-y-auto p-1">
                    {propostas.filter(p =>
                      !buscaProposta ||
                      p.client_name.toLowerCase().includes(buscaProposta.toLowerCase()) ||
                      p.numero.toLowerCase().includes(buscaProposta.toLowerCase())
                    ).slice(0, 30).map(p => (
                      <button key={p.id} disabled={syncing}
                        onClick={() => sincronizarComProposta(p.id, `${p.numero}, ${p.client_name}`)}
                        className="w-full text-left px-3 py-2 rounded-lg text-[13px] text-foreground hover:bg-white/5 disabled:opacity-50">
                        <span className="font-mono text-muted-fg">{p.numero}</span>, {p.client_name}
                      </button>
                    ))}
                    {propostas.length === 0 && <p className="text-center text-[13px] text-muted-fg py-4">Carregando...</p>}
                  </div>
                </div>
              </>
            )}
          </div>
          {selected.size > 0 && (
            <Button onClick={() => gerarRelatorioAvulso(
              allKnownProducts.filter(p => selected.has(p.id)), origemSync ?? undefined, empresaLogoUrl,
              msg => { confirmar({ titulo: msg, apenasAviso: true }) })}
              className="flex items-center gap-2">
              <FileDown className="w-4 h-4" /> Gerar relatório ({selected.size})
            </Button>
          )}
          <Button variant="outline" onClick={() => exportCSV(products)}
            className="flex items-center gap-2 border-border text-foreground">
            <Download className="w-4 h-4" /> Exportar CSV
          </Button>
          {/* Importar CSV, mesmo formato do exportado (medidas em cm, volume ignorado) */}
          <label className="inline-flex items-center gap-2 h-10 px-4 rounded-[16px] border border-border text-foreground text-sm font-medium cursor-pointer hover:bg-muted transition-colors">
            <Download className="w-4 h-4 rotate-180" /> Importar CSV
            <input type="file" accept=".csv" className="hidden" onChange={async e => {
              const file = e.target.files?.[0]
              if (!file) return
              e.target.value = ""
              const texto = await file.text()
              const linhas = texto.replace(/\r/g, "").split("\n").filter(l => l.trim())
              if (linhas.length < 2) { await confirmar({ titulo: "CSV vazio.", apenasAviso: true }); return }
              const sep = linhas[0].includes(";") ? ";" : ","
              const cols = linhas[0].split(sep).map(c => c.replace(/"/g, "").trim().toLowerCase())
              const idx = (frag: string) => cols.findIndex(c => c.includes(frag))
              const iSku = idx("sku"), iPeso = idx("peso"), iL = idx("largura"), iA = idx("altura"), iP = idx("prof")
              if (iSku < 0) { await confirmar({ titulo: "CSV precisa da coluna SKU.", apenasAviso: true }); return }
              let ok = 0, falha = 0
              const bySku = new Map(products.map(p => [p.sku.toLowerCase(), p.id]))
              for (const linha of linhas.slice(1)) {
                const v = linha.split(sep).map(c => c.replace(/"/g, "").trim())
                const id = bySku.get((v[iSku] ?? "").toLowerCase())
                if (!id) { falha++; continue }
                const num = (i: number) => i >= 0 && v[i] ? parseFloat(v[i].replace(",", ".")) : null
                const cm = (n: number | null) => n != null && !isNaN(n) ? n * 10 : null // cm → mm
                const body: Record<string, unknown> = { id }
                const peso = num(iPeso); if (peso != null && !isNaN(peso)) body.peso_kg = peso
                const l = cm(num(iL)); if (l != null) body.largura_mm = l
                const a = cm(num(iA)); if (a != null) body.altura_mm = a
                const pr = cm(num(iP)); if (pr != null) body.profundidade_mm = pr
                if (Object.keys(body).length === 1) { falha++; continue }
                const r = await fetch("/api/dimensionamento", {
                  method: "PATCH", headers: { "Content-Type": "application/json" },
                  body: JSON.stringify(body),
                })
                r.ok ? ok++ : falha++
              }
              alert(`Importação: ${ok} atualizado(s), ${falha} ignorado(s) (SKU não encontrado ou sem dados).`)
              fetchData()
            }} />
          </label>
          <button onClick={() => {
            const modelo = [
              "SKU,Peso(kg),Largura(cm),Altura(cm),Prof(cm)",
              "UNIF-005,0.7,22,4.8,22",
              "HMR-019,0.15,8,3,8",
            ].join("\n")
            const blob = new Blob([modelo], { type: "text/csv;charset=utf-8;" })
            const url = URL.createObjectURL(blob)
            const a = document.createElement("a"); a.href = url; a.download = "modelo-dimensionamento.csv"; a.click()
            URL.revokeObjectURL(url)
          }}
            className="text-[12px] text-ios-blue hover:underline self-center">
            Baixar modelo
          </button>
        </div>
      </div>
      {origemSync && (
        <div className="rounded-xl border border-ios-blue/25 bg-ios-blue/5 px-4 py-2.5 text-[13px] text-foreground flex items-center justify-between gap-2 -mt-2">
          <span>Sincronizado com <b>{origemSync}</b>, {selected.size} item(ns) selecionado(s)</span>
          <button onClick={() => { setOrigemSync(null); setExtraProducts([]); setSelected(new Set()) }}
            className="text-muted-fg hover:text-foreground flex-shrink-0"><X className="w-4 h-4" /></button>
        </div>
      )}

      {/* Filtros */}
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50 pointer-events-none" />
          <Input
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(1) }}
            placeholder="Buscar por nome ou marca..."
            className="pl-9 h-[40px] rounded-xl bg-muted border-border text-foreground"
          />
        </div>
        <select
          value={marcaFiltro}
          onChange={e => { setMarcaFiltro(e.target.value); setPage(1) }}
          className="h-[40px] px-3 rounded-xl bg-muted border border-border text-foreground text-sm min-w-[160px]"
        >
          <option value="">Todas as marcas</option>
          {marcas.map(m => <option key={m} value={m}>{m}</option>)}
        </select>
      </div>

      {/* Tabela */}
      <div className="rounded-2xl border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                <th className="px-4 py-3 w-8">
                  <input type="checkbox" checked={products.length > 0 && selected.size === products.length}
                    onChange={toggleSelectAll} className="w-4 h-4 accent-primary cursor-pointer" />
                </th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium text-[12px] uppercase tracking-wide">Produto</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium text-[12px] uppercase tracking-wide">Marca</th>
                <th className="text-right px-4 py-3 text-muted-foreground font-medium text-[12px] uppercase tracking-wide">Peso (kg)</th>
                <th className="text-center px-4 py-3 text-muted-foreground font-medium text-[12px] uppercase tracking-wide">L × A × P (cm)</th>
                <th className="text-right px-4 py-3 text-muted-foreground font-medium text-[12px] uppercase tracking-wide">Medida (m³/m²)</th>
                <th className="text-center px-4 py-3 text-muted-foreground font-medium text-[12px] uppercase tracking-wide">Tipo</th>
                <th className="text-center px-4 py-3 text-muted-foreground font-medium text-[12px] uppercase tracking-wide">Status</th>
                <th className="text-center px-4 py-3 text-muted-foreground font-medium text-[12px] uppercase tracking-wide">Ações</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={9} className="text-center py-16 text-muted-foreground">Carregando...</td></tr>
              ) : products.length === 0 ? (
                <tr><td colSpan={9} className="text-center py-16 text-muted-foreground">Nenhum produto encontrado</td></tr>
              ) : products.map(p => {
                const isEditing = editingId === p.id
                const status = statusDimensao(p)
                return (
                  <tr key={p.id} className="border-b border-border/40 hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <input type="checkbox" checked={selected.has(p.id)} onChange={() => toggleSelect(p.id)}
                        className="w-4 h-4 accent-primary cursor-pointer" />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg overflow-hidden bg-muted flex items-center justify-center flex-shrink-0">
                          {p.imagem_url ? (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img src={proxiedImg(p.imagem_url)} alt="" className="w-full h-full object-cover"
                              onError={e => { (e.target as HTMLImageElement).style.display = "none" }} />
                          ) : (
                            <Maximize2 className="w-4 h-4 text-muted-foreground/30" />
                          )}
                        </div>
                        <div className="min-w-0">
                          <p className="font-medium text-foreground truncate max-w-[220px]">{p.nome}</p>
                          <p className="text-muted-foreground text-[11px]">{p.sku}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{p.marca || "—"}</td>

                    {/* Peso */}
                    <td className="px-4 py-3 text-right">
                      {isEditing ? (
                        <input type="number" step="0.001"
                          value={editState.peso_kg}
                          onChange={e => setEditState(s => ({ ...s, peso_kg: e.target.value }))}
                          className="w-20 h-8 px-2 rounded-2xl bg-muted border border-border text-foreground text-right text-sm placeholder:text-muted-foreground/40 [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
                          placeholder="—"
                        />
                      ) : (
                        <span className="text-foreground">{p.peso_kg != null ? `${p.peso_kg}` : <span className="text-muted-foreground/40">—</span>}</span>
                      )}
                    </td>

                    {/* Medidas */}
                    <td className="px-4 py-3">
                      {isEditing ? (
                        <div className="flex items-center gap-1 justify-center">
                          {(["largura_mm", "altura_mm", "profundidade_mm"] as const).map((field, i) => (
                            <div key={field} className="flex items-center gap-1">
                              <input type="number" step="0.1"
                                value={editState[field]}
                                onChange={e => setEditState(s => ({ ...s, [field]: e.target.value }))}
                                className="w-16 h-8 px-2 rounded-2xl bg-muted border border-border text-foreground text-center text-sm placeholder:text-muted-foreground/40 [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
                                placeholder="—"
                              />
                              {i < 2 && <span className="text-muted-foreground text-xs">×</span>}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="flex items-center justify-center gap-1 text-foreground">
                          {p.largura_mm || p.altura_mm || p.profundidade_mm
                            ? <span>
                                {p.largura_mm != null ? fmtN(p.largura_mm / 10) : <span className="text-muted-foreground/40">—</span>} × {p.altura_mm != null ? fmtN(p.altura_mm / 10) : <span className="text-muted-foreground/40">—</span>} × {p.profundidade_mm != null ? fmtN(p.profundidade_mm / 10) : <span className="text-muted-foreground/40">—</span>}
                              </span>
                            : <span className="text-muted-foreground/40">—</span>
                          }
                        </div>
                      )}
                    </td>

                    {/* Volume */}
                    <td className="px-4 py-3 text-right text-foreground">
                      {(() => {
                        const m = medidaDoItem(p)
                        return m
                          ? <span>{fmtN(m.valor)} <span className="text-muted-foreground text-[11px]">{m.unidade}</span></span>
                          : <span className="text-muted-foreground/40">—</span>
                      })()}
                    </td>

                    {/* Especificação, clique único abre modal (descrição livre + formato + instalação). */}
                    <td className="px-4 py-3 text-center">
                      {p.outros_descricao || p.outros_formato || p.outros_instalacao ? (
                        <button onClick={() => abrirEspec(p)} title="Editar especificação"
                          className="inline-flex items-center gap-1 h-8 px-2.5 rounded-xl bg-ios-blue/10 border border-ios-blue/25 text-ios-blue text-[12px] max-w-[160px] hover:bg-ios-blue/15 transition-colors">
                          <span className="truncate">{p.outros_descricao || p.outros_formato || p.outros_instalacao}</span>
                          <Pencil className="w-3 h-3 flex-shrink-0" />
                        </button>
                      ) : (
                        <button onClick={() => abrirEspec(p)}
                          className="h-8 px-3 rounded-xl bg-muted border border-border text-muted-foreground text-[12px] hover:text-foreground hover:border-ios-blue/40 transition-colors">
                          Especificar
                        </button>
                      )}
                    </td>

                    {/* Status badge */}
                    <td className="px-4 py-3 text-center">
                      {status === "completo" ? (
                        <span className="inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-medium bg-emerald-500/15 text-emerald-500 dark:text-emerald-400">
                          Completo
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-medium bg-amber-500/15 text-amber-500 dark:text-amber-400">
                          Sem dados
                        </span>
                      )}
                    </td>

                    {/* Ações */}
                    <td className="px-4 py-3 text-center">
                      {isEditing ? (
                        <div className="flex items-center justify-center gap-1">
                          <button onClick={() => saveEdit(p.id)} disabled={saving}
                            className="p-1.5 rounded-2xl bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20 transition-colors">
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button onClick={() => setEditingId(null)}
                            className="p-1.5 rounded-2xl bg-muted text-muted-foreground hover:bg-muted/80 transition-colors">
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <button onClick={() => startEdit(p)}
                          className="p-1.5 rounded-2xl text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        {/* Paginação */}
        {pages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-border bg-muted/20">
            <span className="text-muted-foreground text-sm">{total} produtos</span>
            <div className="flex items-center gap-1">
              {Array.from({ length: Math.min(pages, 10) }, (_, i) => i + 1).map(p => (
                <button key={p} onClick={() => setPage(p)}
                  className={`px-3 py-1.5 rounded-2xl text-sm transition-colors ${
                    page === p
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-muted"
                  }`}>
                  {p}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {outrosOpen && (
        <div className="fixed inset-0 z-[999] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setOutrosOpen(false)} />
          <div className="relative w-full max-w-md rounded-2xl border border-hairline bg-surface-1 shadow-lg shadow-black/30 overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-hairline">
              <h3 className="font-semibold text-foreground text-[15px]">Especificar item</h3>
              <button onClick={() => setOutrosOpen(false)} className="text-muted-foreground/60 hover:text-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-xs text-muted-foreground/70 mb-1 block">Descrição</label>
                <Input value={outrosForm.descricao} onChange={e => setOutrosForm(f => ({ ...f, descricao: e.target.value }))}
                  placeholder="Ex: Nicho, Painel de LED, Forro decorativo..." className="h-9 text-sm" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground/70 mb-1 block">Formato</label>
                <select value={outrosForm.formato} onChange={e => setOutrosForm(f => ({ ...f, formato: e.target.value }))}
                  className="w-full h-9 px-2 rounded-xl bg-muted border border-border text-foreground text-sm outline-none">
                  <option value="">—</option>
                  <option value="Quadrado">Quadrado</option>
                  <option value="Retangular">Retangular</option>
                  <option value="Triangular">Triangular</option>
                  <option value="Circular">Circular</option>
                  <option value="Oval">Oval</option>
                  <option value="Irregular">Irregular (área livre)</option>
                  <option value="Outros">Outros (especificar)</option>
                </select>
                {outrosForm.formato === "Outros" && (
                  <Input value={outrosForm.formato_custom} onChange={e => setOutrosForm(f => ({ ...f, formato_custom: e.target.value }))}
                    placeholder="Especifique o formato..." className="h-9 text-sm mt-2" />
                )}
                {/* Diagrama SVG + fórmula por formato, igual ao dimensionamento da obra */}
                {outrosForm.formato && outrosForm.formato !== "Outros" && (
                  <div className="mt-2 flex items-start gap-3">
                    <div className="bg-surface-2 rounded-2xl p-2 border border-hairline flex-shrink-0">
                      <FormatoSVG formato={outrosForm.formato} />
                    </div>
                    <p className="text-xs text-muted-fg mt-1 leading-relaxed">
                      {outrosForm.formato === "Circular" && <>Informe o <span className="text-ios-blue font-medium">diâmetro</span> em <strong>Larg.</strong><br/>Fórmula: A = π × (Ø/2)²</>}
                      {outrosForm.formato === "Oval" && <>Informe <span className="text-ios-blue font-medium">Diâm. H</span> em <strong>Larg.</strong> e <span className="text-ios-blue font-medium">Diâm. V</span> em <strong>Comp.</strong><br/>Fórmula: A = π × (H/2) × (V/2)</>}
                      {outrosForm.formato === "Quadrado" && <>Informe o <span className="text-ios-blue font-medium">lado</span> em <strong>Larg.</strong><br/>Fórmula: A = Lado²</>}
                      {outrosForm.formato === "Retangular" && <>Informe <span className="text-ios-blue font-medium">largura</span> e <span className="text-ios-blue font-medium">comprimento</span>.<br/>Fórmula: A = Larg. × Comp.</>}
                      {outrosForm.formato === "Triangular" && <>Informe a <span className="text-ios-blue font-medium">base</span> em <strong>Larg.</strong> e a <span className="text-ios-blue font-medium">altura</span> em <strong>Alt.</strong><br/>Fórmula: A = (Base × Alt.) / 2</>}
                      {outrosForm.formato === "Irregular" && <>Informe a área diretamente. Campos de medida desativados.</>}
                    </p>
                  </div>
                )}
              </div>
              <div>
                <label className="text-xs text-muted-foreground/70 mb-1 block">Tipo de instalação</label>
                <select value={outrosForm.instalacao} onChange={e => setOutrosForm(f => ({ ...f, instalacao: e.target.value }))}
                  className="w-full h-9 px-2 rounded-xl bg-muted border border-border text-foreground text-sm outline-none">
                  <option value="">—</option>
                  <option value="Embutir no gesso">Embutir no gesso</option>
                  <option value="Dentro da marcenaria">Dentro da marcenaria</option>
                  <option value="Sobrepor">Sobrepor</option>
                  <option value="Pendente">Pendente</option>
                  <option value="Em mesa / rack">Em mesa / rack</option>
                  <option value="Outros">Outros (especificar)</option>
                </select>
                {outrosForm.instalacao === "Outros" && (
                  <Input value={outrosForm.instalacao_custom} onChange={e => setOutrosForm(f => ({ ...f, instalacao_custom: e.target.value }))}
                    placeholder="Especifique a instalação..." className="h-9 text-sm mt-2" />
                )}
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 px-5 py-4 border-t border-hairline">
              <Button variant="outline" onClick={() => setOutrosOpen(false)} className="border-border text-foreground">Cancelar</Button>
              <Button onClick={salvarOutros} className="gap-1.5"><Check className="w-3.5 h-3.5" /> Salvar</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
