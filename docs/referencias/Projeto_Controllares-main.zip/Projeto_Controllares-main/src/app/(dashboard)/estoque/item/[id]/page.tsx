"use client"

import { useState, useEffect, useCallback, use } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, QrCode, Package, ArrowDownToLine, ArrowUpFromLine, Printer } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { PageLoader } from "@/components/ui/bouncing-dots"
import { proxiedImg } from "@/lib/img"
import { brl } from "@/lib/formato"


interface Mov { id: string; tipo: string; quantidade: number; motivo: string; status: string; criadoPorNome: string; aprovadoPorNome: string | null; createdAt: string; obra: string | null; chamado: string | null }
interface Data {
  product: { id: string; sku: string; nome: string; nome_cliente: string | null; marca: string | null; imagem_url: string | null; estoque_qtd: number | null; estoque_minimo: number | null; preco_venda: number; category: { nome: string } | null; supplier: { nome: string } | null }
  movimentos: Mov[]
  obras_vinculadas: string[]
}

export default function ItemHistoricoPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const router = useRouter()
  const [d, setD] = useState<Data | null>(null)
  const [erro, setErro] = useState("")

  const load = useCallback(async () => {
    const r = await fetch(`/api/estoque/item/${id}`).catch(() => null)
    if (!r) { setErro("Erro de conexão."); return }
    if (!r.ok) { setErro("Produto não encontrado."); return }
    setD(await r.json())
  }, [id])
  useEffect(() => { load() }, [load])

  if (erro) return <p className="text-center text-ios-red py-16">{erro}</p>
  if (!d) return <div className="py-24"><PageLoader /></div>
  const p = d.product

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto space-y-5">
      <button onClick={() => router.push("/estoque")} className="flex items-center gap-1 text-ios-blue text-sm hover:opacity-70">
        <ArrowLeft className="w-4 h-4" /> Estoque
      </button>

      {/* Ficha */}
      <div className="bg-surface-1 border border-hairline rounded-2xl p-5 flex gap-4 items-start">
        <div className="w-20 h-20 rounded-xl overflow-hidden bg-surface-2 flex-shrink-0 flex items-center justify-center">
          {p.imagem_url
            // eslint-disable-next-line @next/next/no-img-element
            ? <img src={proxiedImg(p.imagem_url)} alt="" className="w-full h-full object-cover" />
            : <Package className="w-7 h-7 text-muted-fg/40" />}
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl font-bold text-foreground truncate">{p.nome}</h1>
          <p className="text-muted-fg text-sm font-mono">{p.sku}{p.marca ? ` · ${p.marca}` : ""}</p>
          <div className="flex flex-wrap gap-2 mt-2 text-xs">
            <span className="px-2 py-1 rounded-full bg-surface-2 text-muted-fg">Saldo: <b className="text-foreground">{p.estoque_qtd ?? 0}</b></span>
            {p.category && <span className="px-2 py-1 rounded-full bg-surface-2 text-muted-fg">{p.category.nome}</span>}
            {p.supplier && <span className="px-2 py-1 rounded-full bg-surface-2 text-muted-fg">{p.supplier.nome}</span>}
            <span className="px-2 py-1 rounded-full bg-surface-2 text-muted-fg">{brl(Number(p.preco_venda))}</span>
          </div>
        </div>
        <a href={`/api/estoque/item/${id}/etiqueta`} target="_blank" rel="noreferrer"
          className="flex-shrink-0 flex items-center gap-1.5 h-9 px-3 rounded-xl bg-primary text-primary-foreground text-sm hover:opacity-90">
          <Printer className="w-4 h-4" /> Etiqueta
        </a>
      </div>

      {d.obras_vinculadas.length > 0 && (
        <div className="bg-surface-1 border border-hairline rounded-2xl p-4">
          <p className="text-[11px] uppercase tracking-wide text-muted-fg mb-2">Obras vinculadas</p>
          <div className="flex flex-wrap gap-2">
            {d.obras_vinculadas.map(o => <span key={o} className="px-2.5 py-1 rounded-full bg-ios-blue/10 text-ios-blue text-xs">{o}</span>)}
          </div>
        </div>
      )}

      {/* Histórico de movimentação */}
      <div className="bg-surface-1 border border-hairline rounded-2xl p-5 space-y-3">
        <h2 className="text-[15px] font-semibold text-foreground flex items-center gap-2"><QrCode className="w-4 h-4 text-ios-blue" /> Histórico de movimentação</h2>
        {d.movimentos.length === 0 ? (
          <p className="text-muted-fg text-sm">Sem movimentações registradas.</p>
        ) : (
          <div className="divide-y divide-hairline/60">
            {d.movimentos.map(m => (
              <div key={m.id} className="py-2.5 flex items-center gap-3">
                <span className={m.tipo === "ENTRADA" ? "text-ios-green" : "text-ios-red"}>
                  {m.tipo === "ENTRADA" ? <ArrowDownToLine className="w-4 h-4" /> : <ArrowUpFromLine className="w-4 h-4" />}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-foreground">{m.tipo} {m.quantidade} · {m.motivo}{m.obra ? ` · ${m.obra}` : ""}</p>
                  <p className="text-[11px] text-muted-fg">{m.criadoPorNome} · {new Date(m.createdAt).toLocaleString("pt-BR")}{m.aprovadoPorNome ? ` · aprovado por ${m.aprovadoPorNome}` : ""}</p>
                </div>
                <Badge variant={m.status === "APLICADO" ? "success" : m.status === "PENDENTE" ? "warning" : "secondary"}>{m.status}</Badge>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
