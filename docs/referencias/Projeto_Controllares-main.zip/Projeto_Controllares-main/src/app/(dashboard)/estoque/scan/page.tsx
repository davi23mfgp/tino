"use client"

import { useEffect, useRef, useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Camera, X } from "lucide-react"

// BarcodeDetector é nativo no Chrome/Android; sem dependência externa.
declare global {
  interface Window { BarcodeDetector?: new (opts?: { formats?: string[] }) => { detect: (src: CanvasImageSource) => Promise<{ rawValue: string }[]> } }
}

export default function EstoqueScanPage() {
  const router = useRouter()
  const videoRef = useRef<HTMLVideoElement>(null)
  const [erro, setErro] = useState("")
  const [suportado, setSuportado] = useState(true)

  useEffect(() => {
    if (typeof window === "undefined" || !window.BarcodeDetector) { setSuportado(false); return }
    let stream: MediaStream | null = null
    let raf = 0
    let parado = false
    const detector = new window.BarcodeDetector({ formats: ["qr_code", "code_128", "ean_13"] })

    async function start() {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } })
        if (videoRef.current) { videoRef.current.srcObject = stream; await videoRef.current.play() }
        loop()
      } catch { setErro("Não foi possível abrir a câmera. Permita o acesso.") }
    }
    async function loop() {
      if (parado || !videoRef.current) return
      try {
        const codes = await detector.detect(videoRef.current)
        if (codes.length) { onCode(codes[0].rawValue); return }
      } catch { /* frame sem código */ }
      raf = requestAnimationFrame(loop)
    }
    function onCode(valor: string) {
      parado = true
      // O QR aponta para /estoque/item/<id> — extrai o id.
      const m = valor.match(/\/estoque\/item\/([^/?#]+)/)
      const destino = m ? `/estoque/item/${m[1]}` : (valor.startsWith("http") ? valor : `/estoque?scan=${encodeURIComponent(valor)}`)
      router.push(destino)
    }
    start()
    return () => { parado = true; cancelAnimationFrame(raf); stream?.getTracks().forEach(t => t.stop()) }
  }, [router])

  return (
    <div className="p-4 md:p-6 max-w-lg mx-auto space-y-4">
      <button onClick={() => router.push("/estoque")} className="flex items-center gap-1 text-ios-blue text-sm hover:opacity-70">
        <ArrowLeft className="w-4 h-4" /> Estoque
      </button>
      <div>
        <h1 className="text-2xl font-bold text-foreground flex items-center gap-2"><Camera className="w-6 h-6 text-ios-blue" /> Escanear etiqueta</h1>
        <p className="text-sm text-muted-fg mt-0.5">Aponte a câmera para o QR do produto para abrir a ficha e movimentar.</p>
      </div>

      {!suportado ? (
        <div className="rounded-2xl border border-dashed border-border p-8 text-center text-muted-fg text-sm">
          <X className="w-6 h-6 mx-auto mb-2 text-ios-red" />
          Seu navegador não suporta leitura de QR pela câmera. Use o Chrome no celular, ou abra a etiqueta e digite o SKU na busca do estoque.
        </div>
      ) : erro ? (
        <p className="text-ios-red text-sm">{erro}</p>
      ) : (
        <div className="relative rounded-2xl overflow-hidden bg-black aspect-square">
          <video ref={videoRef} playsInline muted className="w-full h-full object-cover" />
          <div className="absolute inset-8 border-2 border-white/70 rounded-2xl pointer-events-none" />
        </div>
      )}
    </div>
  )
}
