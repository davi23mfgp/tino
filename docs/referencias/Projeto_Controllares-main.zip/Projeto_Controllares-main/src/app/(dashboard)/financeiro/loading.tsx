export default function Loading() {
  return (
    <div className="flex flex-col gap-4 p-5 animate-pulse">
      <div className="flex items-center justify-between">
        <div className="h-7 w-32 bg-muted rounded-xl" />
        <div className="h-9 w-36 bg-muted rounded-xl" />
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="h-28 bg-card rounded-2xl border border-border" />
        ))}
      </div>
      <div className="h-72 bg-card rounded-2xl border border-border" />
      <div className="h-48 bg-card rounded-2xl border border-border" />
    </div>
  )
}
