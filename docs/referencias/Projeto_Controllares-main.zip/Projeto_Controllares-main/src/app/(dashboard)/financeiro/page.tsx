﻿"use client"

import { useState, useEffect, useCallback, useMemo } from "react"
import {
  DollarSign, TrendingUp, TrendingDown, Clock, AlertCircle, CheckCircle, RefreshCw, Wallet,
  FileText, FileCheck, Download, Ban, Receipt, Filter,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog"
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Line, ComposedChart, Legend,
} from "recharts"
import { useMemoriaDeFiltro } from "@/hooks/usar-memoria-filtro"
import { brl } from "@/lib/formato"

const fmtDate = (d: string | null) => (d ? new Date(d).toLocaleDateString("pt-BR") : "—")

interface ContaReceber {
  id: string; cliente: string; proposta: string; vendedor: string
  numero_parcela: number; valor: number; vencimento: string
  statusInterno: string; statusOlist: string | null
}
interface ContaPagar {
  id: string; descricao: string; fornecedor: string; valor: number
  vencimento: string | null; situacao: string
}
interface Nota {
  id: string; numero: string; cliente: string; valor: number
  dataEmissao: string | null; situacao: string
}
interface FluxoDia { dia: string; entradas: number; saidas: number }
interface SyncInfo { status: string; em: string; erro: string | null }
interface PanelData {
  olistConectado: boolean
  cards: {
    totalAReceber: number; totalRecebidoMes: number; totalAPagarMes: number
    saldoProjetado: number; nfEmitidasMes: number; nfPendentes: number
  }
  contasReceber: ContaReceber[]
  contasPagar: ContaPagar[]
  notas: Nota[]
  fluxo: FluxoDia[]
  syncStatus: Record<string, SyncInfo>
}

function SyncDot({ info }: { info?: SyncInfo }) {
  if (!info) return <span className="w-2 h-2 rounded-full bg-muted-foreground/30" title="Nunca sincronizado" />
  const map: Record<string, { c: string; t: string }> = {
    SUCESSO: { c: "bg-green-400", t: `Sincronizado ${new Date(info.em).toLocaleString("pt-BR")}` },
    SINCRONIZANDO: { c: "bg-yellow-400 animate-pulse", t: "Sincronizando..." },
    ERRO: { c: "bg-red-400", t: `Erro: ${info.erro ?? "desconhecido"}` },
  }
  const s = map[info.status] ?? map.SUCESSO
  return <span className={`w-2 h-2 rounded-full ${s.c}`} title={s.t} />
}

function MetricCard({
  label, value, icon: Icon, color, sync, isCount, pct,
}: {
  label: string; value: number; icon: React.ElementType
  color: "blue" | "green" | "red" | "purple" | "sky" | "amber"
  sync?: SyncInfo; isCount?: boolean; pct?: number
}) {
  const c = {
    blue:   { bg: "bg-ios-blue/10",   text: "text-ios-blue",   bar: "bg-ios-blue" },
    green:  { bg: "bg-ios-green/10",  text: "text-ios-green",  bar: "bg-ios-green" },
    red:    { bg: "bg-ios-red/10",    text: "text-ios-red",    bar: "bg-ios-red" },
    purple: { bg: "bg-ios-purple/10", text: "text-ios-purple", bar: "bg-ios-purple" },
    sky:    { bg: "bg-ios-blue/10",   text: "text-ios-blue",   bar: "bg-ios-blue" },
    amber:  { bg: "bg-ios-orange/10", text: "text-ios-orange", bar: "bg-ios-orange" },
  }[color]

  const fmt = (v: number) => {
    if (v >= 1_000_000) return `R$ ${(v / 1_000_000).toFixed(1)}M`
    if (v >= 10_000) return `R$ ${(v / 1_000).toFixed(1)}k`
    return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 }).format(v)
  }

  return (
    <div className="ios-card p-4 flex flex-col gap-2.5 min-w-0 overflow-hidden">
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-xl ${c.bg} flex items-center justify-center flex-shrink-0`}>
          <Icon className={`w-4.5 h-4.5 ${c.text}`} />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <p className="text-muted-foreground text-xs font-medium truncate">{label}</p>
            {sync !== undefined && <SyncDot info={sync} />}
          </div>
          <p className={`text-sm font-bold mt-0.5 truncate ${c.text}`}>{isCount ? value : fmt(value)}</p>
        </div>
      </div>
      {pct !== undefined && (
        <div className="h-1 rounded-full bg-muted overflow-hidden">
          <div className={`h-full rounded-full transition-all duration-500 ${c.bar}`} style={{ width: `${Math.max(2, pct)}%` }} />
        </div>
      )}
    </div>
  )
}

function reqBadge(status: string) {
  const s = status.toLowerCase()
  if (s === "pago" || s.includes("autoriz")) return <Badge variant="success">{s.includes("autoriz") ? "Autorizada" : "Pago"}</Badge>
  if (s === "atrasado") return <Badge variant="destructive">Atrasado</Badge>
  if (s.includes("cancel")) return <Badge variant="destructive">Cancelada</Badge>
  if (s.includes("rejeit")) return <Badge className="bg-orange-500/15 text-orange-500 border-orange-500/30">Rejeitada</Badge>
  return <Badge variant="secondary">{s.includes("pend") ? "Pendente" : s === "pendente" ? "Pendente" : status}</Badge>
}

export default function FinanceiroPage() {
  const [data, setData] = useState<PanelData | null>(null)
  const [loading, setLoading] = useState(true)
  const [acessoNegado, setAcessoNegado] = useState(false)
  const [syncing, setSyncing] = useState(false)
  const [paying, setPaying] = useState<string | null>(null)
  const [toast, setToast] = useState<{ ok: boolean; msg: string } | null>(null)
  const [periodo, setPeriodo] = useMemoriaDeFiltro<30 | 60 | 90>("financeiro:periodo", 30)
  const [series, setSeries] = useState({ entradas: true, saidas: true, saldo: true })

  const [fReceberStatus, setFReceberStatus] = useState("")
  const [fReceberCliente, setFReceberCliente] = useState("")
  const [fPagarStatus, setFPagarStatus] = useState("")

  const showToast = (ok: boolean, msg: string) => { setToast({ ok, msg }); setTimeout(() => setToast(null), 4000) }

  const fetchData = useCallback(async () => {
    const res = await fetch("/api/financeiro/olist")
    if (res.status === 403) { setAcessoNegado(true); setLoading(false); return }
    if (res.ok) setData(await res.json())
    setLoading(false)
  }, [])

  useEffect(() => { fetchData() }, [fetchData])

  async function sincronizar() {
    setSyncing(true)
    try {
      const res = await fetch("/api/integracoes/olist/sync", { method: "POST" })
      const j = await res.json()
      if (res.ok) showToast(true, "Sincronização concluída")
      else showToast(false, j.error ?? "Erro na sincronização")
      await fetchData()
    } finally { setSyncing(false) }
  }

  async function marcarPago(id: string) {
    setPaying(id)
    const res = await fetch(`/api/financeiro/${id}/pagar`, { method: "PATCH" })
    if (res.ok) { showToast(true, "Parcela marcada como paga"); await fetchData() }
    setPaying(null)
  }

  const fluxoChart = useMemo(() => {
    if (!data) return []
    let acc = 0
    return data.fluxo.slice(0, periodo + 1).map(d => {
      acc += d.entradas - d.saidas
      return {
        dia: new Date(d.dia + "T00:00:00").toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" }),
        entradas: d.entradas,
        saidas: d.saidas,
        saldo: acc,
      }
    })
  }, [data, periodo])

  if (loading) {
    return <div className="p-6 space-y-4 animate-pulse">
      <div className="h-8 w-48 bg-muted rounded-xl" />
      <div className="grid grid-cols-[repeat(auto-fit,minmax(170px,1fr))] gap-3">
        {[...Array(6)].map((_, i) => <div key={i} className="h-20 ios-card" />)}
      </div>
    </div>
  }

  if (acessoNegado) {
    return <div className="p-6"><div className="ios-card p-16 text-center">
      <AlertCircle className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
      <p className="text-muted-foreground">Você não tem permissão para acessar o painel financeiro.</p>
      <p className="text-muted-foreground/60 text-sm mt-1">Disponível apenas para ADMIN e FINANCEIRO.</p>
    </div></div>
  }

  if (!data) return null

  const receberFiltrado = data.contasReceber.filter(c =>
    (!fReceberStatus || c.statusInterno?.toUpperCase() === fReceberStatus.toUpperCase()) &&
    (!fReceberCliente || (c.cliente ?? "").toLowerCase().includes(fReceberCliente.toLowerCase()))
  )
  const pagarFiltrado = data.contasPagar.filter(c =>
    !fPagarStatus || (c.situacao ?? "").toLowerCase().includes(fPagarStatus.toLowerCase())
  )
  const algumErro = Object.values(data.syncStatus).some(s => s.status === "ERRO")
  const ultimaSync = Object.values(data.syncStatus).map(s => s.em).sort().reverse()[0]

  const selectCls = "h-9 px-3 rounded-xl bg-muted/50 border border-border text-foreground text-sm focus:outline-none focus:ring-1 focus:ring-primary/30"

  return (
    <div className="p-4 md:p-6 space-y-5 md:space-y-6">
      {toast && (
        <div className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-2xl shadow-apple-float flex items-center gap-2 text-white ${toast.ok ? "bg-green-500" : "bg-destructive"}`}>
          {toast.ok ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          {toast.msg}
        </div>
      )}

      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[11px] uppercase tracking-widest text-muted-fg md:hidden">
            {new Date().toLocaleDateString("pt-BR", { month: "long", year: "numeric" }).replace(" de ", " · ")}
          </p>
          <h1 className="text-[28px] md:text-xl font-bold md:font-semibold text-foreground tracking-tight leading-tight">Financeiro</h1>
          {data.olistConectado && ultimaSync && (
            <p className="text-muted-foreground mt-0.5 text-xs">Olist · sync {new Date(ultimaSync).toLocaleString("pt-BR")}</p>
          )}
        </div>
        <Button onClick={sincronizar} disabled={syncing || !data.olistConectado} className="gap-2 h-9 w-9 md:w-auto p-0 md:px-3 flex-shrink-0">
          <RefreshCw className={`w-4 h-4 ${syncing ? "animate-spin" : ""}`} />
          <span className="hidden md:inline">{syncing ? "Sincronizando..." : "Sincronizar com Olist"}</span>
        </Button>
      </div>

      {algumErro && (
        <div className="bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-300 rounded-xl px-4 py-2.5 text-sm flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          Dados podem estar desatualizados. Última sincronização com erro{ultimaSync ? ` em ${new Date(ultimaSync).toLocaleString("pt-BR")}` : ""}.
        </div>
      )}

      <Tabs defaultValue="resumo">
        <TabsList className="h-10 p-1 bg-surface-3 rounded-xl gap-0.5 md:flex-wrap overflow-x-auto no-scrollbar justify-start max-w-full">
          <TabsTrigger value="resumo" className="rounded-lg h-8 px-3 text-[13px] gap-1.5 flex-shrink-0 transition-all duration-150 data-[state=active]:bg-surface-1 data-[state=active]:shadow-sm data-[state=active]:shadow-black/20 data-[state=active]:text-foreground text-muted-fg">
            Resumo
          </TabsTrigger>
          <TabsTrigger value="receber" className="rounded-lg h-8 px-3 text-[13px] gap-1.5 flex-shrink-0 transition-all duration-150 data-[state=active]:bg-surface-1 data-[state=active]:shadow-sm data-[state=active]:shadow-black/20 data-[state=active]:text-foreground text-muted-fg">
            <DollarSign className="w-3.5 h-3.5" /> A Receber
          </TabsTrigger>
          <TabsTrigger value="pagar" className="rounded-lg h-8 px-3 text-[13px] gap-1.5 flex-shrink-0 transition-all duration-150 data-[state=active]:bg-surface-1 data-[state=active]:shadow-sm data-[state=active]:shadow-black/20 data-[state=active]:text-foreground text-muted-fg">
            <Wallet className="w-3.5 h-3.5" /> A Pagar
          </TabsTrigger>
          <TabsTrigger value="fluxo" className="rounded-lg h-8 px-3 text-[13px] gap-1.5 flex-shrink-0 transition-all duration-150 data-[state=active]:bg-surface-1 data-[state=active]:shadow-sm data-[state=active]:shadow-black/20 data-[state=active]:text-foreground text-muted-fg">
            <TrendingUp className="w-3.5 h-3.5" /> Fluxo de Caixa
          </TabsTrigger>
        </TabsList>

        {/* RESUMO, SALDO DO MÊS + próximas entradas/saídas (estilo mockup) */}
        <TabsContent value="resumo" className="mt-4 space-y-4">
          {/* Card saldo */}
          <div className="bg-surface-1 border border-hairline rounded-3xl p-5 md:p-6">
            <p className="text-[11px] uppercase tracking-widest text-muted-fg">Saldo do mês</p>
            <p className="text-[34px] md:text-[40px] font-bold text-foreground tracking-tight leading-none mt-1">
              {brl(data.cards.saldoProjetado)}
            </p>
            <div className="grid grid-cols-2 gap-3 mt-5">
              <div className="rounded-2xl border border-hairline bg-surface-2/50 px-4 py-3">
                <p className="text-[13px] text-muted-fg flex items-center gap-1.5"><TrendingDown className="w-3.5 h-3.5 text-ios-green" /> A receber</p>
                <p className="text-[18px] md:text-[20px] font-bold text-foreground tracking-tight mt-1">{brl(data.cards.totalAReceber)}</p>
              </div>
              <div className="rounded-2xl border border-hairline bg-surface-2/50 px-4 py-3">
                <p className="text-[13px] text-muted-fg flex items-center gap-1.5"><TrendingUp className="w-3.5 h-3.5 text-ios-red" /> A pagar</p>
                <p className="text-[18px] md:text-[20px] font-bold text-foreground tracking-tight mt-1">{brl(data.cards.totalAPagarMes)}</p>
              </div>
            </div>
          </div>

          {/* Próximas entradas */}
          {(() => {
            const proximas = [...data.contasReceber]
              .filter(c => c.statusInterno !== "PAGO" && c.vencimento)
              .sort((a, b) => new Date(a.vencimento).getTime() - new Date(b.vencimento).getTime())
              .slice(0, 6)
            return (
              <div className="bg-surface-1 border border-hairline rounded-3xl overflow-hidden">
                <div className="flex items-center justify-between px-5 pt-5 pb-3">
                  <h3 className="text-[15px] font-semibold text-foreground">Próximas entradas</h3>
                  <span className="text-[13px] text-muted-fg">{proximas.length}</span>
                </div>
                {proximas.length === 0 ? (
                  <p className="px-5 pb-6 text-[14px] text-muted-fg">Nenhuma entrada pendente.</p>
                ) : (
                  <div className="divide-y divide-white/5">
                    {proximas.map(c => (
                      <div key={c.id} className="flex items-center gap-3 px-5 py-3.5">
                        <div className="w-9 h-9 rounded-xl bg-surface-2 flex items-center justify-center flex-shrink-0">
                          <Clock className="w-4 h-4 text-ios-yellow" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[14px] font-medium text-foreground truncate">{c.proposta || c.cliente}</p>
                          <p className="text-[12px] text-muted-fg mt-0.5 truncate">{c.cliente} · Venc. {fmtDate(c.vencimento)}</p>
                        </div>
                        <span className="text-[15px] font-semibold text-ios-green flex-shrink-0">+ {brl(c.valor)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )
          })()}

          {/* Próximas saídas */}
          {(() => {
            const saidas = [...data.contasPagar]
              .filter(c => c.situacao !== "PAGO" && c.vencimento)
              .sort((a, b) => new Date(a.vencimento!).getTime() - new Date(b.vencimento!).getTime())
              .slice(0, 5)
            if (saidas.length === 0) return null
            return (
              <div className="bg-surface-1 border border-hairline rounded-3xl overflow-hidden">
                <div className="flex items-center justify-between px-5 pt-5 pb-3">
                  <h3 className="text-[15px] font-semibold text-foreground">Próximas saídas</h3>
                  <span className="text-[13px] text-muted-fg">{saidas.length}</span>
                </div>
                <div className="divide-y divide-white/5">
                  {saidas.map(c => (
                    <div key={c.id} className="flex items-center gap-3 px-5 py-3.5">
                      <div className="w-9 h-9 rounded-xl bg-surface-2 flex items-center justify-center flex-shrink-0">
                        <Clock className="w-4 h-4 text-ios-orange" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-[14px] font-medium text-foreground truncate">{c.descricao}</p>
                        <p className="text-[12px] text-muted-fg mt-0.5 truncate">{c.fornecedor} · Venc. {fmtDate(c.vencimento)}</p>
                      </div>
                      <span className="text-[15px] font-semibold text-ios-red flex-shrink-0">- {brl(c.valor)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )
          })()}
        </TabsContent>

        {/* CONTAS A RECEBER */}
        <TabsContent value="receber" className="mt-4 space-y-3">
          <div className="flex gap-2 flex-wrap items-center">
            <Filter className="w-4 h-4 text-muted-foreground" />
            <input placeholder="Cliente..." value={fReceberCliente} onChange={e => setFReceberCliente(e.target.value)}
              className="h-9 px-3 w-44 rounded-xl bg-muted/50 border border-border text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary/30" />
            <select value={fReceberStatus} onChange={e => setFReceberStatus(e.target.value)} className={selectCls}>
              <option value="">Todos os status</option>
              <option value="PENDENTE">Pendente</option>
              <option value="PAGO">Pago</option>
              <option value="ATRASADO">Atrasado</option>
            </select>
          </div>
          {/* DESKTOP: tabela */}
          <div className="hidden md:block ios-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b border-border bg-muted/50 text-muted-foreground">
                  <th className="text-left px-4 py-3 font-medium">Cliente</th>
                  <th className="text-left px-3 py-3 font-medium">Proposta</th>
                  <th className="text-center px-3 py-3 font-medium">Parc.</th>
                  <th className="text-right px-3 py-3 font-medium">Valor</th>
                  <th className="text-right px-3 py-3 font-medium">Vencimento</th>
                  <th className="text-center px-3 py-3 font-medium">Status interno</th>
                  <th className="text-center px-3 py-3 font-medium">No Olist</th>
                  <th className="text-center px-4 py-3 font-medium">Ações</th>
                </tr></thead>
                <tbody>
                  {receberFiltrado.length === 0 ? (
                    <tr><td colSpan={8} className="text-center py-10 text-muted-foreground">Nenhuma conta a receber</td></tr>
                  ) : receberFiltrado.map(c => (
                    <tr key={c.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                      <td className="px-4 py-3 text-foreground font-medium">{c.cliente}</td>
                      <td className="px-3 py-3 text-foreground/80">{c.proposta}</td>
                      <td className="px-3 py-3 text-center text-foreground/80">#{c.numero_parcela}</td>
                      <td className="px-3 py-3 text-right text-foreground font-semibold">{brl(c.valor)}</td>
                      <td className="px-3 py-3 text-right text-foreground/80">{fmtDate(c.vencimento)}</td>
                      <td className="px-3 py-3 text-center">{reqBadge(c.statusInterno)}</td>
                      <td className="px-3 py-3 text-center text-muted-foreground text-xs">{c.statusOlist ?? "—"}</td>
                      <td className="px-4 py-3 text-center">
                        {c.statusInterno !== "PAGO" && (
                          <Button size="sm" variant="outline" onClick={() => marcarPago(c.id)} disabled={paying === c.id}
                            className="border-green-500/30 text-green-600 dark:text-green-400 hover:bg-green-500/10 text-xs h-7">
                            {paying === c.id ? "..." : "Marcar Pago"}
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* MOBILE: cards */}
          <div className="md:hidden space-y-2.5">
            {receberFiltrado.length === 0 ? (
              <p className="text-center py-10 text-muted-foreground text-sm">Nenhuma conta a receber</p>
            ) : receberFiltrado.map(c => (
              <div key={c.id} className="ios-card p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="text-[15px] font-semibold text-foreground leading-tight">{c.cliente}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{c.proposta} · parc. #{c.numero_parcela}</p>
                  </div>
                  {reqBadge(c.statusInterno)}
                </div>
                <div className="flex items-end justify-between mt-2.5">
                  <div>
                    <p className="text-lg font-bold text-foreground">{brl(c.valor)}</p>
                    <p className="text-xs text-muted-foreground">vence {fmtDate(c.vencimento)}</p>
                  </div>
                  {c.statusInterno !== "PAGO" && (
                    <Button size="sm" variant="outline" onClick={() => marcarPago(c.id)} disabled={paying === c.id}
                      className="border-green-500/30 text-green-600 dark:text-green-400 hover:bg-green-500/10 text-xs h-8">
                      {paying === c.id ? "..." : "Marcar Pago"}
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        {/* CONTAS A PAGAR */}
        <TabsContent value="pagar" className="mt-4 space-y-3">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs bg-muted text-muted-foreground px-2.5 py-1 rounded-full border border-border">Somente leitura, cadastre despesas no Olist</span>
            <select value={fPagarStatus} onChange={e => setFPagarStatus(e.target.value)} className={`${selectCls} ml-auto`}>
              <option value="">Todos os status</option>
              <option value="aberto">Aberto</option>
              <option value="pago">Pago</option>
              <option value="atrasado">Atrasado</option>
            </select>
          </div>
          {/* DESKTOP: tabela */}
          <div className="hidden md:block ios-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b border-border bg-muted/50 text-muted-foreground">
                  <th className="text-left px-4 py-3 font-medium">Descrição</th>
                  <th className="text-left px-3 py-3 font-medium">Fornecedor</th>
                  <th className="text-right px-3 py-3 font-medium">Valor</th>
                  <th className="text-right px-3 py-3 font-medium">Vencimento</th>
                  <th className="text-center px-4 py-3 font-medium">Status</th>
                </tr></thead>
                <tbody>
                  {!data.olistConectado ? (
                    <tr><td colSpan={5} className="text-center py-10 text-muted-foreground">Conecte o Olist para ver contas a pagar</td></tr>
                  ) : pagarFiltrado.length === 0 ? (
                    <tr><td colSpan={5} className="text-center py-10 text-muted-foreground">Nenhuma conta a pagar</td></tr>
                  ) : pagarFiltrado.map(c => (
                    <tr key={c.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                      <td className="px-4 py-3 text-foreground">{c.descricao || "—"}</td>
                      <td className="px-3 py-3 text-foreground/80">{c.fornecedor}</td>
                      <td className="px-3 py-3 text-right text-foreground font-semibold">{brl(c.valor)}</td>
                      <td className="px-3 py-3 text-right text-foreground/80">{fmtDate(c.vencimento)}</td>
                      <td className="px-4 py-3 text-center">{reqBadge(c.situacao)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* MOBILE: cards */}
          <div className="md:hidden space-y-2.5">
            {!data.olistConectado ? (
              <p className="text-center py-10 text-muted-foreground text-sm">Conecte o Olist para ver contas a pagar</p>
            ) : pagarFiltrado.length === 0 ? (
              <p className="text-center py-10 text-muted-foreground text-sm">Nenhuma conta a pagar</p>
            ) : pagarFiltrado.map(c => (
              <div key={c.id} className="ios-card p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="text-[15px] font-semibold text-foreground leading-tight">{c.descricao || "—"}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{c.fornecedor}</p>
                  </div>
                  {reqBadge(c.situacao)}
                </div>
                <div className="flex items-end justify-between mt-2.5">
                  <p className="text-lg font-bold text-foreground">{brl(c.valor)}</p>
                  <p className="text-xs text-muted-foreground">vence {fmtDate(c.vencimento)}</p>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        {/* FLUXO DE CAIXA */}
        <TabsContent value="fluxo" className="mt-4 space-y-3">
          <div className="ios-card p-3 md:p-5">
            <div className="flex items-center justify-between flex-wrap gap-3 mb-4">
              <h3 className="text-foreground font-semibold">Fluxo de Caixa Projetado</h3>
              <div className="flex gap-1 bg-muted rounded-xl p-0.5">
                {([30, 60, 90] as const).map(p => (
                  <button key={p} onClick={() => setPeriodo(p)}
                    className={`px-3 py-1 rounded-2xl text-xs font-medium transition-colors ${periodo === p ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}>
                    {p} dias
                  </button>
                ))}
              </div>
            </div>
            <ResponsiveContainer width="100%" height={320}>
              <ComposedChart data={fluxoChart} margin={{ top: 8, right: 8, left: -10, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="dia" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }} axisLine={false} tickLine={false} interval="preserveStartEnd" minTickGap={24} />
                <YAxis tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={v => `${(v / 1000).toFixed(0)}k`} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12, color: "hsl(var(--foreground))" }}
                  formatter={(v) => brl(Number(v))} />
                <Legend onClick={(e) => { const k = String(e.dataKey) as keyof typeof series; setSeries(s => ({ ...s, [k]: !s[k] })) }}
                  wrapperStyle={{ cursor: "pointer", fontSize: 12 }} />
                {series.entradas && <Bar dataKey="entradas" name="Entradas" fill="#4ade80" radius={[3, 3, 0, 0]} />}
                {series.saidas && <Bar dataKey="saidas" name="Saídas" fill="#f87171" radius={[3, 3, 0, 0]} />}
                {series.saldo && <Line dataKey="saldo" name="Saldo acumulado" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />}
              </ComposedChart>
            </ResponsiveContainer>
            <p className="text-muted-foreground/60 text-xs mt-2">Baseado em contas a receber abertas (parcelas) e contas a pagar do Olist. Clique na legenda para ocultar séries.</p>
          </div>
        </TabsContent>

      </Tabs>
    </div>
  )
}
