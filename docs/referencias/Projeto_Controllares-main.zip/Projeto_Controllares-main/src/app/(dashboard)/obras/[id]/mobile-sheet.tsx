"use client"

import { useRef, useState } from "react"
import { useRouter } from "next/navigation"
import {
  MapPin, User, Calendar, Navigation, Phone, Mail, Upload, Download,
  FileText, Image as ImageIcon, Ruler, KeyRound, Eye, EyeOff, Plus,
  ExternalLink, CalendarCheck, FileDown, Box,
} from "lucide-react"
import { showToast } from "@/components/ui/toast"
import { proxiedImg } from "@/lib/img"
import { brlSemCentavos as brl } from "@/lib/formato"


// ── Tipos mínimos (espelham a página) ────────────────────────────────────────
interface Anexo { nome: string; url: string; ext: string; createdAt?: string }
interface Credencial {
  id: string; tipo_equipamento: string; login: string | null
  tem_senha: boolean; tem_mac: boolean; tem_ip: boolean
}
interface EnvItem {
  id: string; quantidade: number
  product: { nome: string; sku: string; imagem_url?: string | null } | null
  kit: { nome: string } | null
  nome_snapshot?: string | null
  sku_snapshot?: string | null
}
interface Env { id: string; nome: string; proposalItems: EnvItem[] }
interface PropLite { id: string; numero: string; status: string; valor_total: number }
interface Contato { nome: string; papel: string }
interface Parceiro { id: string; name: string; type: string; phone: string | null }

interface Props {
  obraId: string
  clientName: string
  etapa: string | null
  construtora: string | null
  address: string | null
  latitude: number | null
  longitude: number | null
  respTecnico: string | null
  previsaoInicio: string | null
  progresso?: number | null
  anexos: Anexo[]
  environments: Env[]
  proposals: PropLite[]
  credenciais: Credencial[]
  acessos: Contato[]
  parceiros: Parceiro[]
  onOpenFull: (tab?: string, sub?: string) => void
}

const TABS = ["RESUMO", "ANEXOS", "AMBIENTES", "DIMENSÕES", "CREDENCIAIS"] as const
type Tab = typeof TABS[number]

const IMG_EXTS = ["jpg", "jpeg", "png", "webp", "gif", "avif", "heic"]
function anexoCategoria(ext: string): string {
  const e = (ext || "").toLowerCase()
  if (["dwg", "dxf"].includes(e)) return "PLANTA"
  if (IMG_EXTS.includes(e)) return "FOTO"
  if (e === "pdf") return "PDF"
  return "DOC"
}
function AnexoIcon({ ext }: { ext: string }) {
  const cat = anexoCategoria(ext)
  if (cat === "PLANTA") return <Ruler className="w-4 h-4 text-ios-orange" />
  if (cat === "FOTO") return <ImageIcon className="w-4 h-4 text-ios-purple" />
  return <FileText className="w-4 h-4 text-ios-blue" />
}

const CTA = "fixed bottom-[84px] left-4 right-4 z-40 h-[54px] rounded-2xl bg-ios-blue text-background font-semibold flex items-center justify-center gap-2 shadow-lg active:scale-[0.98] transition-transform md:hidden"
const CARD = "bg-surface-1 border border-hairline rounded-2xl overflow-hidden"
const KICKER = "text-[11px] uppercase tracking-widest text-muted-fg"

export function ObraMobileSheet(p: Props) {
  const router = useRouter()
  const [tab, setTab] = useState<Tab>("RESUMO")
  const [anexos, setAnexos] = useState<Anexo[]>(p.anexos)
  const [filtroAnexo, setFiltroAnexo] = useState("TODOS")
  const [enviando, setEnviando] = useState(false)
  const [revelado, setRevelado] = useState<{ id: string; texto: string } | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  const pct = Math.min(100, Math.max(0, p.progresso ?? 0))
  const mapsUrl = p.latitude && p.longitude
    ? `https://www.google.com/maps?q=${p.latitude},${p.longitude}`
    : `https://www.google.com/maps/search/${encodeURIComponent(p.address ?? "")}`
  const dirUrl = p.latitude && p.longitude
    ? `https://www.google.com/maps/dir/?api=1&destination=${p.latitude},${p.longitude}`
    : `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(p.address ?? "")}`

  // ── Upload de anexo (mesmo padrão da aba Engenharia: /api/upload + PATCH) ──
  async function enviarAnexo(file: File) {
    setEnviando(true)
    try {
      const fd = new FormData(); fd.append("file", file)
      const up = await fetch("/api/upload", { method: "POST", body: fd })
      const j = await up.json()
      if (!up.ok || !j.url) { showToast(j.error || "Falha no upload.", { variant: "error" }); return }
      const novo: Anexo = { nome: file.name, url: j.url, ext: (file.name.split(".").pop() || "").toLowerCase(), createdAt: new Date().toISOString() }
      const lista = [...anexos, novo]
      const patch = await fetch(`/api/obras/${p.obraId}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ anexos: lista }),
      })
      if (!patch.ok) { showToast("Falha ao salvar o anexo na obra.", { variant: "error" }); return }
      setAnexos(lista)
      showToast("Anexo enviado.", { variant: "success" })
    } finally { setEnviando(false) }
  }

  // ── Revelar credencial (30s) ──
  async function revelar(c: Credencial) {
    if (revelado?.id === c.id) { setRevelado(null); return }
    const r = await fetch(`/api/obras/${p.obraId}/credenciais/${c.id}/revelar`)
    if (!r.ok) { showToast("Falha ao revelar.", { variant: "error" }); return }
    const d = await r.json()
    const partes = [d.ip && `IP: ${d.ip}`, c.login && `Login: ${c.login}`, d.senha && `Senha: ${d.senha}`, d.mac && `MAC: ${d.mac}`].filter(Boolean)
    setRevelado({ id: c.id, texto: partes.join("  ·  ") || "Sem dados" })
    setTimeout(() => setRevelado(prev => (prev?.id === c.id ? null : prev)), 30_000)
  }

  const catsAnexo = ["TODOS", ...Array.from(new Set(anexos.map(a => anexoCategoria(a.ext))))]
  const anexosFiltrados = filtroAnexo === "TODOS" ? anexos : anexos.filter(a => anexoCategoria(a.ext) === filtroAnexo)
  const propostaOrigem = p.proposals[0]
  const totalItens = p.environments.reduce((s, e) => s + e.proposalItems.length, 0)

  const Row = ({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) => (
    <div className="flex items-center justify-between gap-3 px-4 py-3.5">
      <span className="flex items-center gap-2.5 text-muted-fg text-[14px]">{icon}{label}</span>
      <span className="text-foreground text-[14px] font-semibold text-right truncate max-w-[55%]">{value}</span>
    </div>
  )

  return (
    <div className="pb-36">
      {/* Kicker status + endereço */}
      <p className={`${KICKER} text-ios-blue -mt-1`}>
        {(p.etapa ?? "Nova obra").toUpperCase()}{p.construtora ? ` · ${p.construtora.toUpperCase()}` : ""}
      </p>
      {p.address && (
        <p className="text-[13px] text-muted-fg flex items-center gap-1.5 mt-2">
          <MapPin className="w-3.5 h-3.5 flex-shrink-0" /> <span className="truncate">{p.address}</span>
        </p>
      )}

      {/* Abas texto sublinhado */}
      <div className="flex gap-5 overflow-x-auto no-scrollbar border-b border-hairline mt-4 -mx-4 px-4">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`pb-2.5 text-[13px] font-semibold tracking-wider flex-shrink-0 border-b-2 transition-colors ${
              tab === t ? "text-ios-blue border-ios-blue" : "text-muted-fg border-transparent"
            }`}>
            {t}
          </button>
        ))}
        {/* Painel completo, todas as seções do site (Agenda, Suporte, Engenharia...) */}
        <button onClick={() => p.onOpenFull()}
          className="pb-2.5 text-[13px] font-semibold tracking-wider flex-shrink-0 border-b-2 border-transparent text-ios-blue">
          MAIS +
        </button>
      </div>

      {/* ═══ RESUMO ═══ */}
      {tab === "RESUMO" && (
        <div className="space-y-5 mt-4">
          <div className={`${CARD} px-4 py-4`}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[14px] text-muted-fg">Progresso</span>
              <span className="text-[16px] font-bold text-foreground">{pct}%</span>
            </div>
            <div className="h-1.5 bg-surface-3 rounded-full overflow-hidden">
              <div className="h-full rounded-full bg-ios-blue transition-all" style={{ width: `${pct}%` }} />
            </div>
          </div>

          <div>
            <p className={`${KICKER} mb-2`}>Detalhes</p>
            <div className={`${CARD} divide-y divide-white/5`}>
              <Row icon={<User className="w-4 h-4" />} label="Responsável" value={p.respTecnico ?? "—"} />
              <Row icon={<Calendar className="w-4 h-4" />} label="Início" value={p.previsaoInicio ? new Date(p.previsaoInicio + "T12:00:00").toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" }) : "—"} />
              <Row icon={<Calendar className="w-4 h-4" />} label="Etapa" value={p.etapa ?? "—"} />
            </div>
          </div>

          <div>
            <p className={`${KICKER} mb-2`}>Localização</p>
            <div className={CARD}>
              <div className="px-4 py-3.5">
                <p className="text-[14px] text-foreground font-medium">{p.address || "Endereço não informado"}</p>
                {p.latitude && p.longitude && (
                  <p className="text-[12px] font-mono text-muted-fg mt-1">{p.latitude.toFixed(4)}, {p.longitude.toFixed(4)}</p>
                )}
              </div>
              <div className="grid grid-cols-2 divide-x divide-white/5 border-t border-hairline">
                <a href={mapsUrl} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-1.5 py-3 text-[14px] text-ios-blue active:opacity-70">
                  <MapPin className="w-4 h-4" /> Ver mapa
                </a>
                <a href={dirUrl} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-1.5 py-3 text-[14px] text-ios-blue active:opacity-70">
                  <Navigation className="w-4 h-4" /> Como chegar
                </a>
              </div>
            </div>
          </div>

          {(p.acessos.length > 0 || p.parceiros.length > 0) && (
            <div>
              <p className={`${KICKER} mb-2`}>Contatos</p>
              <div className={`${CARD} divide-y divide-white/5`}>
                {p.acessos.map((c, i) => (
                  <div key={`a${i}`} className="px-4 py-3.5">
                    <p className="text-[15px] font-semibold text-foreground">{c.nome}</p>
                    <p className={`${KICKER} mt-0.5`}>{c.papel}</p>
                  </div>
                ))}
                {p.parceiros.map(pc => (
                  <div key={pc.id} className="px-4 py-3.5">
                    <p className="text-[15px] font-semibold text-foreground">{pc.name}</p>
                    <p className={`${KICKER} mt-0.5`}>{pc.type}</p>
                    {pc.phone && (
                      <a href={`tel:${pc.phone}`} className="inline-flex items-center gap-1.5 mt-2 px-3 h-8 rounded-full bg-surface-2 text-[13px] text-foreground active:opacity-70">
                        <Phone className="w-3.5 h-3.5 text-ios-green" /> {pc.phone}
                      </a>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          <button onClick={() => p.onOpenFull("agenda")} className={CTA}>
            <CalendarCheck className="w-5 h-5" /> Registrar visita
          </button>
        </div>
      )}

      {/* ═══ ANEXOS ═══ */}
      {tab === "ANEXOS" && (
        <div className="space-y-4 mt-4">
          <input ref={fileRef} type="file" className="hidden"
            onChange={e => { const f = e.target.files?.[0]; if (f) enviarAnexo(f); e.target.value = "" }} />
          <button onClick={() => fileRef.current?.click()} disabled={enviando}
            className="w-full flex items-center justify-center gap-2 border-2 border-dashed border-hairline rounded-2xl py-4 text-foreground font-medium text-[15px] active:opacity-70 disabled:opacity-50">
            <Upload className="w-4 h-4" /> {enviando ? "Enviando..." : "Enviar novo anexo"}
          </button>

          <div className="flex gap-2 overflow-x-auto no-scrollbar">
            {catsAnexo.map(c => (
              <button key={c} onClick={() => setFiltroAnexo(c)}
                className={`px-4 h-9 rounded-full text-[12px] font-semibold tracking-wider flex-shrink-0 border transition-colors ${
                  filtroAnexo === c ? "bg-white text-black border-white" : "bg-surface-2 text-muted-fg border-hairline"
                }`}>
                {c}
              </button>
            ))}
          </div>

          <div className={`${CARD} divide-y divide-white/5`}>
            {anexosFiltrados.length === 0 && (
              <p className="text-center text-muted-fg text-[14px] py-8">Nenhum anexo</p>
            )}
            {anexosFiltrados.map((a, i) => (
              <div key={i} className="flex items-center gap-3 px-4 py-3.5">
                <div className="w-10 h-10 rounded-xl bg-surface-2 flex items-center justify-center flex-shrink-0">
                  <AnexoIcon ext={a.ext} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[14px] font-medium text-foreground truncate">
                    <span className={`${KICKER} bg-surface-2 rounded px-1.5 py-0.5 mr-2`}>{anexoCategoria(a.ext)}</span>
                    {a.nome}
                  </p>
                  <p className="text-[12px] text-muted-fg mt-0.5">
                    {a.ext?.toUpperCase() || "arquivo"}{a.createdAt ? ` · ${new Date(a.createdAt).toLocaleDateString("pt-BR")}` : ""}
                  </p>
                </div>
                <a href={a.url} target="_blank" rel="noreferrer" download
                  className="w-9 h-9 rounded-full bg-surface-2 flex items-center justify-center text-muted-fg active:scale-95 flex-shrink-0">
                  <Download className="w-4 h-4" />
                </a>
              </div>
            ))}
          </div>

        </div>
      )}

      {/* ═══ AMBIENTES ═══ */}
      {tab === "AMBIENTES" && (
        <div className="space-y-4 mt-4">
          {propostaOrigem && (
            <button onClick={() => router.push(`/propostas/${propostaOrigem.id}`)}
              className={`${CARD} w-full text-left px-4 py-4 flex items-center gap-3 active:opacity-70`}>
              <div className="flex-1 min-w-0">
                <p className={`${KICKER} text-ios-blue`}>Proposta · {propostaOrigem.numero}</p>
                <p className="text-[15px] font-semibold text-foreground mt-1 truncate">{p.clientName}</p>
                <p className="text-[13px] text-muted-fg mt-0.5">{brl(Number(propostaOrigem.valor_total))}</p>
              </div>
              <ExternalLink className="w-4 h-4 text-muted-fg flex-shrink-0" />
            </button>
          )}

          {p.environments.length === 0 && (
            <div className={`${CARD} py-10 text-center text-muted-fg text-[14px]`}>Nenhum ambiente nesta obra</div>
          )}
          {p.environments.map(env => (
            <div key={env.id} className={CARD}>
              <div className="flex items-center justify-between px-4 py-3.5 border-b border-hairline">
                <p className="text-[15px] font-bold text-foreground">{env.nome}</p>
                <span className={KICKER}>{env.proposalItems.length} {env.proposalItems.length === 1 ? "item" : "itens"}</span>
              </div>
              <div className="divide-y divide-white/5">
                {env.proposalItems.map(it => (
                  <div key={it.id} className="flex items-center gap-3 px-4 py-3">
                    <div className="w-9 h-9 rounded-lg overflow-hidden flex-shrink-0 bg-surface-2 flex items-center justify-center">
                      {it.product?.imagem_url ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={proxiedImg(it.product.imagem_url)} alt="" className="w-full h-full object-cover"
                          onError={e => { (e.target as HTMLImageElement).style.display = "none" }} />
                      ) : (
                        <Box className="w-3.5 h-3.5 text-muted-fg/40" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] text-foreground truncate">{it.product?.nome ?? it.kit?.nome ?? it.nome_snapshot ?? "Item"}</p>
                      <p className="text-[12px] text-muted-fg mt-0.5">Qtd {it.quantidade}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}

          <button onClick={() => p.onOpenFull("engenharia", "ambientes")} className={CTA}>
            <Box className="w-5 h-5" /> Adicionar ambiente
          </button>
        </div>
      )}

      {/* ═══ DIMENSÕES ═══ */}
      {tab === "DIMENSÕES" && (
        <div className="space-y-4 mt-4">
          <div className="rounded-2xl border border-ios-blue/25 bg-ios-blue/5 px-4 py-4">
            <p className={`${KICKER} text-ios-purple`}>
              {propostaOrigem ? `Origem · ${propostaOrigem.numero}` : "Dimensionamento"}
            </p>
            <p className="text-[15px] font-semibold text-foreground mt-1">Dimensionamento derivado da proposta</p>
            <p className="text-[13px] text-muted-fg mt-0.5">{totalItens} {totalItens === 1 ? "item" : "itens"} · {p.environments.length} {p.environments.length === 1 ? "ambiente" : "ambientes"}</p>
            <button onClick={() => p.onOpenFull("dimensionamento")}
              className="mt-3 inline-flex items-center gap-2 h-10 px-4 rounded-xl bg-ios-blue text-background text-[14px] font-medium active:opacity-80">
              <FileDown className="w-4 h-4" /> Gerar relatório PDF
            </button>
          </div>

          {p.environments.map(env => (
            <div key={env.id} className={CARD}>
              <div className="flex items-center justify-between px-4 py-3.5 border-b border-hairline">
                <p className="text-[15px] font-bold text-foreground">{env.nome}</p>
                <span className={KICKER}>{env.proposalItems.length} items</span>
              </div>
              <div className="divide-y divide-white/5">
                {env.proposalItems.map(it => (
                  <div key={it.id} className="flex items-center gap-3 px-4 py-3.5">
                    <div className="w-10 h-10 rounded-lg overflow-hidden flex-shrink-0 bg-surface-2 flex items-center justify-center">
                      {it.product?.imagem_url ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={proxiedImg(it.product.imagem_url)} alt="" className="w-full h-full object-cover"
                          onError={e => { (e.target as HTMLImageElement).style.display = "none" }} />
                      ) : (
                        <Box className="w-4 h-4 text-muted-fg/40" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-medium text-foreground truncate">{it.product?.nome ?? it.kit?.nome ?? it.nome_snapshot ?? "Item"}</p>
                      <p className="text-[12px] text-muted-fg mt-0.5">
                        Qtd {it.quantidade}{it.product?.sku ? ` · ${it.product.sku}` : ""}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}

        </div>
      )}

      {/* ═══ CREDENCIAIS ═══ */}
      {tab === "CREDENCIAIS" && (
        <div className="space-y-4 mt-4">
          <div className="rounded-2xl border border-hairline bg-surface-2/50 px-4 py-3">
            <p className="text-[13px] text-muted-fg">Credenciais visíveis apenas para perfis autorizados.</p>
          </div>

          <div className={`${CARD} divide-y divide-white/5`}>
            {p.credenciais.length === 0 && (
              <p className="text-center text-muted-fg text-[14px] py-8">Nenhuma credencial cadastrada</p>
            )}
            {p.credenciais.map(c => (
              <div key={c.id} className="flex items-center gap-3 px-4 py-3.5">
                <div className="w-10 h-10 rounded-xl bg-surface-2 flex items-center justify-center flex-shrink-0">
                  <KeyRound className="w-4 h-4 text-ios-yellow" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[15px] font-semibold text-foreground truncate">{c.tipo_equipamento}</p>
                  {revelado?.id === c.id ? (
                    <p className="text-[13px] font-mono text-ios-green mt-0.5 break-all">{revelado.texto}</p>
                  ) : (
                    <p className="text-[13px] font-mono text-muted-fg tracking-[0.2em] mt-0.5">• • • • • • • • •</p>
                  )}
                </div>
                <button onClick={() => revelar(c)}
                  className="w-9 h-9 rounded-full bg-surface-2 flex items-center justify-center text-muted-fg active:scale-95 flex-shrink-0">
                  {revelado?.id === c.id ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            ))}
          </div>

          <button onClick={() => p.onOpenFull("suporte", "senhas")} className={CTA}>
            <Plus className="w-5 h-5" /> Adicionar credencial
          </button>
        </div>
      )}
    </div>
  )
}
