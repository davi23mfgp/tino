"use client"

/**
 * Dimensionamento da obra (Bloco 10) — itens da proposta agrupados por AMBIENTE.
 * Parâmetros técnicos vêm do CADASTRO do produto (tipo de aplicação, formato,
 * dimensões) já pré-preenchidos; o técnico só ajusta. Checkbox define o que
 * entra no relatório. Formato manda nas medidas:
 *   Círculo = só diâmetro · Quadrado = lado único (altura=largura) · Retângulo = L×A.
 */
import { useState, useEffect, useCallback } from "react"
import { Ruler, FileDown, Check, RefreshCw, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { PageLoader } from "@/components/ui/bouncing-dots"
import { proxiedImg } from "@/lib/img"
import { useConfirmar } from "@/components/confirmar"

interface Dim {
  id?: string
  valor_largura?: number | null
  valor_altura?: number | null
  valor_profundidade?: number | null
  valor_diametro?: number | null
  formato_selecionado?: string | null
  incluir_relatorio?: boolean
  notas_dimensionamento?: string | null
}
interface Item {
  proposalItemId: string
  nome_item: string
  sku: string
  imagem_url: string | null
  quantidade: number
  tipo_aplicacao: string | null
  formato_medida: string | null
  largura_mm: number | null
  altura_mm: number | null
  profundidade_mm: number | null
  especificacoes: string | null
  garantia_meses: number | null
  jaAdicionado: boolean
  dimensionamento: Dim | null
}
interface Grupo { ambiente: string; itens: Item[] }

// Estado editável por item (chave = proposalItemId)
interface Edit { formato: string; incluir: boolean; largura: string; altura: string; comprimento: string; diametro: string; salvo?: boolean }

const cm = (mm: number | null | undefined) => (mm != null ? String(mm / 10) : "")
// Catálogo salva "Outros"; aqui chamamos de "Personalizado" (sem figura, só cotas).
const ehPersonalizado = (fmt: string) => fmt === "Outros" || fmt === "Personalizado"
/* Cilindro e Linear vêm do catálogo (caixa redonda de embutir, cabo). Antes a
   tela não os conhecia: o select ficava em branco e o relatório saía sem figura. */
const ehRedondo = (fmt: string) => fmt === "Circulo" || fmt === "Cilindro"
const temComprimento = (fmt: string) => ehPersonalizado(fmt) || fmt === "Cilindro" || fmt === "Linear"

/** Medida em texto, no formato certo pro formato escolhido. Módulo, não
 *  método, porque tanto o PDF quanto o e-mail precisam do mesmo texto. */
const medidaTxt = (e: Edit): string =>
  e.formato === "Circulo" ? `Ø ${e.diametro || "—"} cm`
    : e.formato === "Cilindro" ? `Ø ${e.diametro || "—"} × ${e.comprimento || "—"} cm (Ø×P)`
    : e.formato === "Linear" ? `${e.comprimento || "—"} cm`
    : e.formato === "Quadrado" ? `${e.largura || "—"} × ${e.largura || "—"} cm`
    : ehPersonalizado(e.formato) ? `${e.largura || "—"} × ${e.altura || "—"} × ${e.comprimento || "—"} cm (L×A×C)`
    : `${e.largura || "—"} × ${e.altura || "—"} cm`

/**
 * Transforma o HTML do relatório em PDF A4 (base64, sem o prefixo data:).
 * Renderiza num iframe escondido para o CSS do relatório não vazar para a
 * tela, fotografa com html2canvas e fatia em páginas, cortando sempre entre
 * linhas da tabela para nenhum item sair partido ao meio.
 */
async function htmlParaPdfBase64(html: string): Promise<string> {
  const [{ jsPDF }, html2canvas] = await Promise.all([import("jspdf"), import("html2canvas").then(m => m.default)])
  const LARG = 794 // A4 a 96 dpi
  const iframe = document.createElement("iframe")
  iframe.style.cssText = `position:fixed;left:-10000px;top:0;width:${LARG}px;height:1123px;border:0;`
  document.body.appendChild(iframe)
  try {
    const doc = iframe.contentDocument!
    doc.open()
    doc.write(html.replace("</head>", "<style>.acoes{display:none!important}body{max-width:none;margin:0}</style></head>"))
    doc.close()
    await Promise.all([...doc.images].map(img => img.complete ? null : new Promise(r => { img.onload = img.onerror = r })))
    const corpo = doc.body
    iframe.style.height = `${corpo.scrollHeight}px`
    // 1.5x: nítido na impressão e leve o bastante para caber no limite de 4,5 MB da Vercel.
    const escala = 1.5
    const canvas = await html2canvas(corpo, { scale: escala, useCORS: true, backgroundColor: "#ffffff", windowWidth: LARG })

    // Pontos onde dá para cortar a página: fim de cada linha e início de cada ambiente.
    const cortes = [...corpo.querySelectorAll("tr, h2")].map(el => {
      const r = el.getBoundingClientRect()
      return Math.round((el.tagName === "H2" ? r.top : r.bottom) * escala)
    }).sort((a, b) => a - b)

    const pdf = new jsPDF({ unit: "mm", format: "a4" })
    const margem = 8, largMm = 210 - margem * 2, altMm = 297 - margem * 2
    const pxPorMm = canvas.width / largMm
    const altPagPx = Math.floor(altMm * pxPorMm)
    let ini = 0, pagina = 0
    while (ini < canvas.height - 2) {
      let fim = Math.min(ini + altPagPx, canvas.height)
      if (fim < canvas.height) {
        const c = cortes.filter(y => y > ini + altPagPx * 0.3 && y <= fim).pop()
        if (c) fim = c
      }
      const fatia = document.createElement("canvas")
      fatia.width = canvas.width; fatia.height = fim - ini
      fatia.getContext("2d")!.drawImage(canvas, 0, ini, canvas.width, fim - ini, 0, 0, canvas.width, fim - ini)
      if (pagina++) pdf.addPage()
      pdf.addImage(fatia.toDataURL("image/jpeg", 0.8), "JPEG", margem, margem, largMm, (fim - ini) / pxPorMm)
      ini = fim
    }
    return pdf.output("datauristring").split(",")[1]
  } finally {
    iframe.remove()
  }
}

export default function DimensionamentoObra(
  { obraId, obraNome, ehAdmin = false }: { obraId: string; obraNome?: string; ehAdmin?: boolean },
) {
  const confirmar = useConfirmar()
  const [grupos, setGrupos] = useState<Grupo[] | null>(null)
  /* Produtos que ainda nao foram para um ambiente. Eles nem chegam nesta tela,
     entao sem este numero a lista parecia completa e alguem media so metade
     da obra. */
  const [semAmbiente, setSemAmbiente] = useState(0)
  const [edits, setEdits] = useState<Record<string, Edit>>({})
  const [salvando, setSalvando] = useState<string | null>(null)
  const [emailDestino, setEmailDestino] = useState("")
  const [enviando, setEnviando] = useState(false)
  const [envioMsg, setEnvioMsg] = useState<{ tipo: "ok" | "erro"; texto: string } | null>(null)

  const load = useCallback(async () => {
    const r = await fetch(`/api/obras/${obraId}/dimensionamento`)
    if (!r.ok) { setGrupos([]); return }
    const d = await r.json()
    const gs: Grupo[] = d.dimensionamento || []
    setGrupos(gs)
    setSemAmbiente(Number(d.semAmbiente) || 0)
    // Inicializa edits: valores salvos > dims do produto (mm→cm)
    const e: Record<string, Edit> = {}
    for (const g of gs) for (const it of g.itens) {
      const dim = it.dimensionamento
      e[it.proposalItemId] = {
        formato: dim?.formato_selecionado || it.formato_medida || "",
        incluir: dim?.incluir_relatorio ?? true,
        largura: dim?.valor_largura != null ? String(dim.valor_largura) : cm(it.largura_mm),
        altura: dim?.valor_altura != null ? String(dim.valor_altura) : cm(it.altura_mm),
        comprimento: dim?.valor_profundidade != null ? String(dim.valor_profundidade) : cm(it.profundidade_mm),
        diametro: dim?.valor_diametro != null ? String(dim.valor_diametro) : (ehRedondo(it.formato_medida || "") ? cm(it.largura_mm) : ""),
      }
    }
    setEdits(e)
  }, [obraId])

  useEffect(() => { load() }, [load])

  async function salvar(it: Item) {
    const e = edits[it.proposalItemId]
    if (!e) return
    setSalvando(it.proposalItemId)
    try {
      const num = (s: string) => (s === "" ? null : Number(s))
      await fetch(`/api/obras/${obraId}/dimensionamento`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          proposalItemId: it.proposalItemId,
          formato_selecionado: e.formato || null,
          incluir_relatorio: e.incluir,
          valor_diametro: ehRedondo(e.formato) ? num(e.diametro) : null,
          valor_largura: ehRedondo(e.formato) || e.formato === "Linear" ? null : num(e.largura),
          // Quadrado: altura travada = largura
          valor_altura: ehRedondo(e.formato) || e.formato === "Linear" ? null : e.formato === "Quadrado" ? num(e.largura) : num(e.altura),
          valor_profundidade: temComprimento(e.formato) ? num(e.comprimento) : null,
          /* A medida conferida na obra corrige o cadastro do produto, que vem
             do fornecedor e erra. Sem isto o erro voltava na proxima obra. O
             servidor recusa de quem nao for Admin. */
          gravarNoCatalogo: ehAdmin,
        }),
      })
      setEdits(prev => ({ ...prev, [it.proposalItemId]: { ...prev[it.proposalItemId], salvo: true } }))
      setTimeout(() => setEdits(prev => ({ ...prev, [it.proposalItemId]: { ...prev[it.proposalItemId], salvo: false } })), 2000)
    } finally { setSalvando(null) }
  }

  function set(id: string, patch: Partial<Edit>) {
    setEdits(prev => ({ ...prev, [id]: { ...prev[id], ...patch } }))
  }

  /** HTML do relatório: o mesmo documento serve para o "Gerar relatório"
   *  (abre para imprimir) e para o PDF que vai anexo no e-mail. */
  function montarRelatorioHtml(): string | null {
    if (!grupos) return null
    // Figura do formato com as cotas (SVG). Personalizado com medida vira caixa
    // em perspectiva (L × A × C); sem nenhuma medida continua sem figura.
    const figura = (e: Edit): string => {
      const L = e.largura || "—", A = e.altura || "—", C = e.comprimento || "—", D = e.diametro || "—"
      if (e.formato === "Circulo")
        return `<svg width="70" height="70" viewBox="0 0 70 70"><circle cx="35" cy="35" r="26" fill="none" stroke="#1e40af" stroke-width="2"/><line x1="9" y1="35" x2="61" y2="35" stroke="#94a3b8" stroke-dasharray="3"/><text x="35" y="31" font-size="9" fill="#1e293b" text-anchor="middle">Ø ${D}</text></svg>`
      if (e.formato === "Quadrado")
        return `<svg width="70" height="70" viewBox="0 0 70 70"><rect x="14" y="14" width="42" height="42" fill="none" stroke="#1e40af" stroke-width="2"/><text x="35" y="11" font-size="9" fill="#1e293b" text-anchor="middle">${L}</text><text x="9" y="38" font-size="9" fill="#1e293b" text-anchor="middle" transform="rotate(-90 9 38)">${L}</text></svg>`
      if (e.formato === "Retangulo")
        return `<svg width="86" height="64" viewBox="0 0 86 64"><rect x="14" y="14" width="58" height="36" fill="none" stroke="#1e40af" stroke-width="2"/><text x="43" y="11" font-size="9" fill="#1e293b" text-anchor="middle">${L}</text><text x="9" y="34" font-size="9" fill="#1e293b" text-anchor="middle" transform="rotate(-90 9 34)">${A}</text></svg>`
      if (e.formato === "Cilindro")
        return `<svg width="80" height="70" viewBox="0 0 80 70"><ellipse cx="34" cy="20" rx="22" ry="7" fill="none" stroke="#1e40af" stroke-width="2"/><path d="M12 20 V50 A22 7 0 0 0 56 50 V20" fill="none" stroke="#1e40af" stroke-width="2"/><text x="34" y="10" font-size="9" fill="#1e293b" text-anchor="middle">Ø ${D}</text><text x="66" y="38" font-size="9" fill="#1e293b">${C}</text></svg>`
      if (e.formato === "Linear")
        return `<svg width="86" height="40" viewBox="0 0 86 40"><line x1="8" y1="24" x2="78" y2="24" stroke="#1e40af" stroke-width="3" stroke-linecap="round"/><line x1="8" y1="18" x2="8" y2="30" stroke="#94a3b8"/><line x1="78" y1="18" x2="78" y2="30" stroke="#94a3b8"/><text x="43" y="14" font-size="9" fill="#1e293b" text-anchor="middle">${C}</text></svg>`
      if (ehPersonalizado(e.formato) && (e.largura || e.altura || e.comprimento))
        return `<svg width="96" height="76" viewBox="0 0 96 76"><path d="M12 30 H60 V66 H12 Z M12 30 L28 16 H76 L60 30 M76 16 V52 L60 66" fill="none" stroke="#1e40af" stroke-width="2" stroke-linejoin="round"/><text x="36" y="76" font-size="9" fill="#1e293b" text-anchor="middle">${L}</text><text x="7" y="50" font-size="9" fill="#1e293b" text-anchor="middle" transform="rotate(-90 7 50)">${A}</text><text x="80" y="64" font-size="9" fill="#1e293b">${C}</text></svg>`
      return "" // sem formato ou sem medida: sem figura
    }
    const secoes = grupos.map(g => {
      const linhas = g.itens.filter(it => edits[it.proposalItemId]?.incluir).map(it => {
        const e = edits[it.proposalItemId]
        const img = it.imagem_url ? `<img src="${proxiedImg(it.imagem_url)}" class="itemimg"/>` : `<div class="itemimg noimg">—</div>`
        const fmtLabel = ehPersonalizado(e.formato) ? "Personalizado" : (e.formato || "—")
        return `<tr><td><div class="itemcell">${img}<span>${it.nome_item} <span class="sku">[${it.sku}]</span></span></div></td><td class="c">${it.quantidade}</td><td class="c">${it.tipo_aplicacao || "—"}</td><td class="c">${fmtLabel}</td><td class="c">${figura(e)}</td><td class="c">${medidaTxt(e)}</td></tr>`
      }).join("")
      if (!linhas) return ""
      return `<h2>${g.ambiente}</h2><table><thead><tr><th>Item</th><th>Qtd</th><th>Aplicação</th><th>Formato</th><th>Figura</th><th>Medidas</th></tr></thead><tbody>${linhas}</tbody></table>`
    }).join("")
    /* O documento sai da casa e chega na mão do instalador ou do arquiteto,
       então leva a marca e o mesmo cuidado do resto: cabeçalho com o logo,
       tipografia do sistema e tabela clara em vez de grade cinza fechada. O
       logo vem do próprio servidor, por caminho absoluto, porque a janela
       aberta com window.open não tem base para caminho relativo. */
    const logo = `${window.location.origin}/brand/logo-completo.png`
    const html = `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"/><title>Dimensionamento, ${obraNome ?? ""}</title><style>
      *{box-sizing:border-box}
      body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;
           font-size:12px;color:#111827;padding:32px 28px;max-width:940px;margin:0 auto;background:#fff}
      .topo{display:flex;align-items:flex-end;justify-content:space-between;gap:24px;
            border-bottom:1px solid #e5e7eb;padding-bottom:16px;margin-bottom:24px}
      .topo img{height:34px;width:auto}
      .titulo{font-size:20px;font-weight:600;letter-spacing:-.3px;margin:0}
      .sub{color:#6b7280;font-size:12px;margin:4px 0 0}
      .meta{text-align:right;color:#6b7280;font-size:11px;line-height:1.5}
      h2{font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.1em;color:#6b7280;
         margin:26px 0 10px;padding:0}
      table{width:100%;border-collapse:collapse;font-size:11.5px}
      thead th{background:#f9fafb;color:#6b7280;font-weight:600;font-size:10px;text-transform:uppercase;
               letter-spacing:.06em;padding:8px 10px;text-align:left;border-bottom:1px solid #e5e7eb}
      td{padding:10px;border-bottom:1px solid #f1f3f5;vertical-align:middle}
      tbody tr:last-child td{border-bottom:1px solid #e5e7eb}
      .c{text-align:center}
      .sku{color:#9ca3af;font-size:10px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace}
      .itemcell{display:flex;align-items:center;gap:10px}
      .itemimg{width:42px;height:42px;object-fit:cover;border-radius:10px;border:1px solid #e5e7eb;flex:0 0 auto}
      .noimg{display:flex;align-items:center;justify-content:center;color:#d1d5db;background:#f9fafb}
      .acoes{margin-bottom:20px}
      .acoes button{background:#111827;color:#fff;border:0;padding:10px 18px;border-radius:10px;
                    cursor:pointer;font-size:13px;font-weight:600}
      .rodape{margin-top:32px;padding-top:14px;border-top:1px solid #e5e7eb;color:#9ca3af;font-size:10.5px;
              display:flex;justify-content:space-between}
      @media print{
        .acoes{display:none}
        body{padding:0}
        tr{break-inside:avoid}
        h2{break-after:avoid}
        img{-webkit-print-color-adjust:exact;print-color-adjust:exact}
      }
      @page{size:A4;margin:14mm}
    </style></head><body>
      <div class="acoes"><button onclick="window.print()">Imprimir ou salvar em PDF</button></div>
      <div class="topo">
        <div>
          <img src="${logo}" alt="Controllares" />
          <p class="titulo" style="margin-top:14px">Relatório de dimensionamento</p>
          <p class="sub">${obraNome ?? "Obra"}</p>
        </div>
        <div class="meta">
          Gerado em ${new Date().toLocaleDateString("pt-BR")}<br/>
          ${new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
        </div>
      </div>
      ${secoes || "<p style='color:#6b7280'>Nenhum item marcado para o relatório.</p>"}
      <div class="rodape">
        <span>Controllares · Automação e Home Cinema</span>
        <span>${obraNome ?? ""}</span>
      </div>
    </body></html>`
    return html
  }

  async function gerarRelatorio() {
    const html = montarRelatorioHtml()
    if (!html) return
    const w = window.open("", "_blank", "width=1000,height=750")
    if (!w) { await confirmar({ titulo: "Permita pop-ups para gerar o relatório.", apenasAviso: true }); return }
    w.document.write(html); w.document.close()
  }

  /**
   * Manda o dimensionamento por e-mail, com o relatório em PDF anexo. O PDF é
   * o mesmo documento do "Gerar relatório" (com figuras e fotos): a tabela no
   * corpo do e-mail perdia as figuras e chegava diferente do que se imprime.
   */
  async function enviarPorEmail() {
    const email = emailDestino.trim().toLowerCase()
    if (!email || !email.includes("@")) return
    const html = montarRelatorioHtml()
    if (!html) return

    setEnviando(true)
    setEnvioMsg(null)
    try {
      const pdf = await htmlParaPdfBase64(html)
      /* A Vercel recusa corpo de requisição acima de 4,5 MB (sem chegar na
         rota). Melhor avisar aqui do que falhar calado. */
      if (pdf.length > 4_000_000) {
        setEnvioMsg({ tipo: "erro", texto: "O PDF ficou grande demais para o e-mail. Desmarque alguns itens e tente de novo." })
        return
      }
      const nomeArq = `Dimensionamento - ${(obraNome ?? "Obra").replace(/[\\/:*?"<>|]/g, "")}.pdf`
      const r = await fetch(`/api/obras/${obraId}/relatorio/enviar`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          emails: [email], titulo: "Dimensionamento",
          anexo: { nome: nomeArq, base64: pdf },
        }),
      })
      const j = await r.json().catch(() => null)
      if (r.ok) { setEnvioMsg({ tipo: "ok", texto: `Enviado para ${email}.` }); setEmailDestino("") }
      else setEnvioMsg({ tipo: "erro", texto: j?.error || (r.status === 413 ? "O PDF ficou grande demais para o e-mail." : `Falha ao enviar (erro ${r.status}).`) })
    } catch (err) {
      setEnvioMsg({ tipo: "erro", texto: `Falha ao gerar o PDF: ${err instanceof Error ? err.message : String(err)}` })
    } finally {
      setEnviando(false)
    }
  }

  if (grupos === null) return <div className="py-16 flex justify-center"><PageLoader /></div>

  const totalMarcados = grupos.reduce((s, g) => s + g.itens.filter(it => edits[it.proposalItemId]?.incluir).length, 0)

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <p className="text-sm text-muted-fg">
          Medidas em <b>cm</b>, pré-preenchidas do cadastro do produto. Marque o que entra no relatório.
        </p>
        <Button onClick={gerarRelatorio} disabled={totalMarcados === 0} className="gap-1.5">
          <FileDown className="w-4 h-4" /> Gerar relatório ({totalMarcados})
        </Button>
      </div>

      {/* Enviar por e-mail, escolhe pra quem, clica, envia. Sem toggle,
          sem gatilho automático: é a mesma informação do PDF acima. */}
      {totalMarcados > 0 && (
        <div className="flex items-center gap-2 flex-wrap bg-surface-1 rounded-2xl p-3">
          <Input value={emailDestino} onChange={e => setEmailDestino(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && !enviando) enviarPorEmail() }}
            placeholder="email@destino.com.br" className="flex-1 min-w-[200px] h-9" />
          <Button onClick={enviarPorEmail} disabled={enviando || !emailDestino.trim()} variant="outline" size="sm" className="gap-1.5">
            <Send className="w-3.5 h-3.5" /> {enviando ? "Enviando..." : "Enviar por e-mail"}
          </Button>
          {envioMsg && (
            <span className={`text-xs w-full ${envioMsg.tipo === "ok" ? "text-ios-green" : "text-ios-red"}`}>
              {envioMsg.texto}
            </span>
          )}
        </div>
      )}

      {semAmbiente > 0 && (
        <div className="rounded-2xl border border-warning/40 bg-surface-1 px-5 py-4">
          <p className="text-[14px] font-semibold text-foreground">
            Faltam {semAmbiente} {semAmbiente === 1 ? "produto" : "produtos"} sem ambiente
          </p>
          <p className="mt-1 text-[13px] text-muted-fg">
            Produto solto não entra no dimensionamento. Organize tudo em Engenharia &gt; Ambientes/Produtos e salve; a lista aqui abre completa.
          </p>
        </div>
      )}

      {grupos.length === 0 && semAmbiente === 0 && (
        <p className="text-center text-muted-fg py-10">Nenhum item de proposta vinculado a esta obra.</p>
      )}

      {grupos.map(g => (
        <div key={g.ambiente} className="bg-surface-1 border border-hairline rounded-2xl overflow-hidden">
          <div className="flex items-center gap-2.5 px-5 py-3.5 border-b border-hairline">
            <span className="w-2 h-2 rounded-full bg-ios-blue flex-shrink-0" />
            <h3 className="text-[13px] font-semibold text-foreground uppercase tracking-[0.08em]">{g.ambiente}</h3>
            <span className="text-[12px] text-muted-fg ml-auto">{g.itens.length} {g.itens.length === 1 ? "item" : "itens"}</span>
          </div>
          <div className="divide-y divide-hairline/60">
            {g.itens.map(it => {
              const e = edits[it.proposalItemId]
              if (!e) return null
              return (
                <div key={it.proposalItemId} className="px-5 py-3 flex items-center gap-3 flex-wrap">
                  {/* Checkbox: entra no relatório */}
                  <button onClick={() => { set(it.proposalItemId, { incluir: !e.incluir }); }}
                    className={`w-5 h-5 rounded-md border flex items-center justify-center flex-shrink-0 transition-colors ${
                      e.incluir ? "bg-ios-blue border-ios-blue text-background" : "border-border hover:border-ios-blue/50"
                    }`} title="Incluir no relatório">
                    {e.incluir && <Check className="w-3.5 h-3.5" strokeWidth={3} />}
                  </button>

                  {/* Miniatura do item (imagem do catálogo) */}
                  <span className="w-11 h-11 rounded-xl overflow-hidden bg-surface-2 flex-shrink-0 flex items-center justify-center">
                    {it.imagem_url ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={proxiedImg(it.imagem_url)} alt="" className="w-full h-full object-cover"
                        onError={e => { (e.target as HTMLImageElement).style.display = "none" }} />
                    ) : (
                      <Ruler className="w-4 h-4 text-muted-fg/40" />
                    )}
                  </span>

                  <div className="min-w-[180px] flex-1">
                    <p className="text-sm text-foreground truncate">{it.nome_item} <span className="text-muted-foreground text-xs font-mono">[{it.sku}]</span></p>
                    <p className="text-[11px] text-muted-fg">Qtd {it.quantidade}{it.tipo_aplicacao ? ` · ${it.tipo_aplicacao}` : ""}{it.garantia_meses ? ` · ${it.garantia_meses}m garantia` : ""}</p>
                    {it.especificacoes && (
                      <p className="text-[11px] text-muted-fg/80 mt-0.5 line-clamp-2" title={it.especificacoes}>{it.especificacoes}</p>
                    )}
                  </div>

                  {/* Tipo de aplicação (do produto) */}
                  {it.tipo_aplicacao && (
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full flex-shrink-0 ${
                      it.tipo_aplicacao === "Teto" ? "bg-ios-blue/12 text-ios-blue" : "bg-ios-orange/12 text-ios-orange"
                    }`}>{it.tipo_aplicacao.toUpperCase()}</span>
                  )}

                  {/* Formato manda nas medidas */}
                  <select value={ehPersonalizado(e.formato) ? "Personalizado" : e.formato} onChange={ev => set(it.proposalItemId, { formato: ev.target.value })}
                    className="h-8 px-2 rounded-xl bg-muted border border-border text-foreground text-[12px] outline-none flex-shrink-0">
                    <option value="">Formato…</option>
                    <option value="Circulo">Círculo</option>
                    <option value="Cilindro">Cilindro</option>
                    <option value="Quadrado">Quadrado</option>
                    <option value="Retangulo">Retângulo</option>
                    <option value="Linear">Linear</option>
                    <option value="Personalizado">Personalizado</option>
                  </select>

                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    {e.formato === "Circulo" ? (
                      <Input type="number" step="0.1" min="0" value={e.diametro}
                        onChange={ev => set(it.proposalItemId, { diametro: ev.target.value })}
                        placeholder="Ø cm" className="w-20 h-8 text-center text-[12px]" title="Diâmetro (cm)" />
                    ) : e.formato === "Cilindro" ? (
                      <>
                        <Input type="number" step="0.1" min="0" value={e.diametro}
                          onChange={ev => set(it.proposalItemId, { diametro: ev.target.value })}
                          placeholder="Ø cm" className="w-16 h-8 text-center text-[12px]" title="Diâmetro (cm)" />
                        <span className="text-muted-fg text-xs">×</span>
                        <Input type="number" step="0.1" min="0" value={e.comprimento}
                          onChange={ev => set(it.proposalItemId, { comprimento: ev.target.value })}
                          placeholder="P" className="w-14 h-8 text-center text-[12px]" title="Profundidade (cm)" />
                      </>
                    ) : e.formato === "Linear" ? (
                      <Input type="number" step="0.1" min="0" value={e.comprimento}
                        onChange={ev => set(it.proposalItemId, { comprimento: ev.target.value })}
                        placeholder="C cm" className="w-20 h-8 text-center text-[12px]" title="Comprimento (cm)" />
                    ) : e.formato === "Quadrado" ? (
                      <Input type="number" step="0.1" min="0" value={e.largura}
                        onChange={ev => set(it.proposalItemId, { largura: ev.target.value, altura: ev.target.value })}
                        placeholder="Lado" className="w-20 h-8 text-center text-[12px]" title="Lado (cm), altura = largura" />
                    ) : ehPersonalizado(e.formato) ? (
                      <>
                        <Input type="number" step="0.1" min="0" value={e.largura}
                          onChange={ev => set(it.proposalItemId, { largura: ev.target.value })}
                          placeholder="L" className="w-14 h-8 text-center text-[12px]" title="Largura (cm)" />
                        <span className="text-muted-fg text-xs">×</span>
                        <Input type="number" step="0.1" min="0" value={e.altura}
                          onChange={ev => set(it.proposalItemId, { altura: ev.target.value })}
                          placeholder="A" className="w-14 h-8 text-center text-[12px]" title="Altura (cm)" />
                        <span className="text-muted-fg text-xs">×</span>
                        <Input type="number" step="0.1" min="0" value={e.comprimento}
                          onChange={ev => set(it.proposalItemId, { comprimento: ev.target.value })}
                          placeholder="C" className="w-14 h-8 text-center text-[12px]" title="Comprimento (cm)" />
                      </>
                    ) : (
                      <>
                        <Input type="number" step="0.1" min="0" value={e.largura}
                          onChange={ev => set(it.proposalItemId, { largura: ev.target.value })}
                          placeholder="L" className="w-16 h-8 text-center text-[12px]" title="Largura (cm)" />
                        <span className="text-muted-fg text-xs">×</span>
                        <Input type="number" step="0.1" min="0" value={e.altura}
                          onChange={ev => set(it.proposalItemId, { altura: ev.target.value })}
                          placeholder="A" className="w-16 h-8 text-center text-[12px]" title="Altura (cm)" />
                      </>
                    )}
                  </div>

                  <Button size="sm" variant={e.salvo ? "default" : "outline"} onClick={() => salvar(it)}
                    disabled={salvando === it.proposalItemId}
                    title={ehAdmin
                      ? "Salva na obra e corrige a medida no cadastro do produto"
                      : "Salva a medida nesta obra"}
                    className={`h-8 text-xs flex-shrink-0 ${e.salvo ? "bg-ios-green hover:bg-ios-green text-background" : ""}`}>
                    {salvando === it.proposalItemId ? <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      : e.salvo ? <><Check className="w-3.5 h-3.5 mr-1" /> Salvo</>
                      : it.jaAdicionado ? "Atualizar" : "Salvar"}
                  </Button>
                </div>
              )
            })}
          </div>
        </div>
      ))}

      <p className="text-[12px] text-muted-fg flex items-center gap-1.5">
        <Ruler className="w-3.5 h-3.5" /> Círculo usa só o diâmetro · Quadrado trava altura = largura · Retângulo é livre.
      </p>
    </div>
  )
}
