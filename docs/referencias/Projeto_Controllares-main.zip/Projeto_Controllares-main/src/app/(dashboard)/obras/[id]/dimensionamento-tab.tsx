﻿"use client"

import { useState, useMemo, useCallback, useEffect } from "react"
import { Printer, Save, ChevronDown, ChevronRight, Ruler, FileText, ImageOff } from "lucide-react"
import { proxiedImg } from "@/lib/img"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { useConfirmar } from "@/components/confirmar"

interface Item {
  id: string
  quantidade: number
  is_aditivo: boolean
  product: { nome: string; sku: string; imagem_url?: string | null } | null
  kit: { nome: string } | null
  category: { nome: string } | null
}

interface Env {
  id: string
  nome: string
  proposalItems: Item[]
}

interface Dimensoes {
  largura: string
  altura: string
  comprimento: string
  area: string
  obs: string
  tipo: string // Gesso | Marcenaria | Outros | ""
  outros_descricao: string
  outros_formato: string
  outros_formato_custom: string
  outros_instalacao: string
  outros_instalacao_custom: string
}

type DimMap = Record<string, Dimensoes>

interface Props {
  obraId: string
  obraNome?: string
  environments: Env[]
  dimensionamentoInicial?: Record<string, Partial<Dimensoes>>
}

const DIM_EMPTY: Dimensoes = { largura: "", altura: "", comprimento: "", area: "", obs: "", tipo: "", outros_descricao: "", outros_formato: "", outros_formato_custom: "", outros_instalacao: "", outros_instalacao_custom: "" }
const TIPOS = ["Gesso", "Marcenaria", "Outros"] as const

function getDim(dims: DimMap, id: string): Dimensoes {
  return { ...DIM_EMPTY, ...(dims[id] ?? {}) }
}

function calcArea(d: Dimensoes): number {
  const fmt = d.tipo === "Outros" ? (d.outros_formato || "") : ""
  const l = Number(d.largura) || 0
  const h = Number(d.altura) || 0
  const c = Number(d.comprimento) || 0
  // Fórmulas geométricas têm prioridade — manual só para Irregular
  if (fmt === "Circular")    return l > 0 ? Math.PI * (l / 2) ** 2 : 0
  if (fmt === "Oval")        return l > 0 && c > 0 ? Math.PI * (l / 2) * (c / 2) : 0
  if (fmt === "Quadrado")    return l > 0 ? l * l : 0
  if (fmt === "Triangular")  return l > 0 && h > 0 ? (l * h) / 2 : 0
  if (fmt === "Irregular")   return d.area && !isNaN(Number(d.area)) ? Number(d.area) : 0
  // Sem formato ou padrão: fórmula se dims preenchidas, senão manual
  const calculado = l > 0 && c > 0 ? l * c : 0
  if (calculado > 0) return calculado
  return d.area && !isNaN(Number(d.area)) ? Number(d.area) : 0
}

// Volume m³: area × profundidade (campo que não é usado na área 2D)
function calcVolume(d: Dimensoes): number {
  const area = calcArea(d)
  if (area <= 0) return 0
  const fmt = d.tipo === "Outros" ? (d.outros_formato || "") : ""
  const l = Number(d.largura) || 0
  const h = Number(d.altura) || 0
  const c = Number(d.comprimento) || 0
  if (fmt === "Circular")   return h > 0 ? area * h : 0   // prof = altura
  if (fmt === "Quadrado")   return h > 0 ? area * h : 0   // prof = altura
  if (fmt === "Retangular") return h > 0 ? area * h : 0   // prof = altura
  if (fmt === "Oval")       return h > 0 ? area * h : 0   // prof = altura
  if (fmt === "Triangular") return c > 0 ? area * c : 0   // prof = comprimento
  if (fmt === "Irregular")  return 0
  // Default (sem formato especial): L × A × C
  return l > 0 && h > 0 && c > 0 ? l * h * c : 0
}

// Retorna config dos 3 campos de medida baseada no formato
// "Prof." = profundidade, usado para calcular volume (não a área 2D)
function getMedidaCfg(formato: string): { field: "largura" | "altura" | "comprimento"; placeholder: string; disabled: boolean }[] {
  switch (formato) {
    case "Circular":    return [{ field: "largura", placeholder: "Diâm.", disabled: false }, { field: "altura", placeholder: "Prof.", disabled: false }, { field: "comprimento", placeholder: "—", disabled: true }]
    case "Oval":        return [{ field: "largura", placeholder: "Diâm.H", disabled: false }, { field: "altura", placeholder: "Prof.", disabled: false }, { field: "comprimento", placeholder: "Diâm.V", disabled: false }]
    case "Quadrado":    return [{ field: "largura", placeholder: "Lado", disabled: false }, { field: "altura", placeholder: "Prof.", disabled: false }, { field: "comprimento", placeholder: "—", disabled: true }]
    case "Retangular":  return [{ field: "largura", placeholder: "Larg.", disabled: false }, { field: "altura", placeholder: "Prof.", disabled: false }, { field: "comprimento", placeholder: "Comp.", disabled: false }]
    case "Triangular":  return [{ field: "largura", placeholder: "Base", disabled: false }, { field: "altura", placeholder: "Alt.", disabled: false }, { field: "comprimento", placeholder: "Prof.", disabled: false }]
    case "Irregular":   return [{ field: "largura", placeholder: "—", disabled: true }, { field: "altura", placeholder: "—", disabled: true }, { field: "comprimento", placeholder: "—", disabled: true }]
    default:            return [{ field: "largura", placeholder: "Larg.", disabled: false }, { field: "altura", placeholder: "Alt.", disabled: false }, { field: "comprimento", placeholder: "Comp.", disabled: false }]
  }
}

// Remove zeros desnecessários: 3.00 → "3", 3.50 → "3.5"
function fmtN(v: string | number | null | undefined): string {
  if (!v && v !== 0) return "—"
  const n = Number(v)
  if (isNaN(n) || n === 0) return "—"
  return parseFloat(n.toFixed(4)).toString()
}

// SVG como string pura com valores reais embutidos
function formatoSvgStr(formato: string, vals: { l: string; h: string; c: string }): string {
  const { l, h, c } = vals
  const vl = fmtN(l); const vh = fmtN(h); const vc = fmtN(c)
  const s = `stroke="#334155" fill="none" stroke-width="1.5"`
  const dd = `stroke="#1e40af" fill="none" stroke-width="1" stroke-dasharray="4 2"`
  const arrow = `fill="#1e40af"`
  const txt = `fill="#1e40af" font-size="9" font-family="monospace" text-anchor="middle"`
  const sub = `fill="#64748b" font-size="8" font-family="monospace" text-anchor="middle"`
  if (formato === "Circular") return `<svg viewBox="0 0 110 95" width="110" height="95" xmlns="http://www.w3.org/2000/svg"><circle cx="55" cy="48" r="33" ${s}/><line x1="22" y1="48" x2="88" y2="48" ${dd}/><polygon points="22,46 22,50 18,48" ${arrow}/><polygon points="88,46 88,50 92,48" ${arrow}/><text x="55" y="42" ${txt}>Ø ${vl!=="—"?vl+"m":"diâm."}</text><text x="55" y="88" ${sub}>A = π×(Ø/2)²</text></svg>`
  if (formato === "Oval") return `<svg viewBox="0 0 120 95" width="120" height="95" xmlns="http://www.w3.org/2000/svg"><ellipse cx="60" cy="47" rx="46" ry="27" ${s}/><line x1="14" y1="47" x2="106" y2="47" ${dd}/><polygon points="14,45 14,49 10,47" ${arrow}/><polygon points="106,45 106,49 110,47" ${arrow}/><text x="60" y="41" ${txt}>${vl!=="—"?vl+"m":"Ø H"}</text><line x1="60" y1="20" x2="60" y2="74" ${dd}/><text x="73" y="50" ${txt}>${vc!=="—"?vc+"m":"Ø V"}</text><text x="60" y="90" ${sub}>A = π×(H/2)×(V/2)</text></svg>`
  if (formato === "Quadrado") return `<svg viewBox="0 0 100 95" width="100" height="95" xmlns="http://www.w3.org/2000/svg"><rect x="15" y="13" width="70" height="70" ${s}/><line x1="15" y1="5" x2="85" y2="5" ${dd}/><polygon points="15,3 15,7 11,5" ${arrow}/><polygon points="85,3 85,7 89,5" ${arrow}/><text x="50" y="4" ${txt}>${vl!=="—"?vl+"m":"Lado"}</text><text x="50" y="90" ${sub}>A = Lado²</text></svg>`
  if (formato === "Retangular") return `<svg viewBox="0 0 120 95" width="120" height="95" xmlns="http://www.w3.org/2000/svg"><rect x="10" y="18" width="95" height="55" ${s}/><line x1="10" y1="8" x2="105" y2="8" ${dd}/><polygon points="10,6 10,10 6,8" ${arrow}/><polygon points="105,6 105,10 109,8" ${arrow}/><text x="57" y="7" ${txt}>${vl!=="—"?vl+"m":"Larg."}</text><line x1="112" y1="18" x2="112" y2="73" ${dd}/><text x="116" y="49" fill="#1e40af" font-size="8" font-family="monospace" text-anchor="start">${vc!=="—"?vc+"m":"Comp."}</text><text x="57" y="90" ${sub}>A = L × C</text></svg>`
  if (formato === "Triangular") return `<svg viewBox="0 0 120 100" width="120" height="100" xmlns="http://www.w3.org/2000/svg"><polygon points="60,10 8,82 112,82" ${s}/><line x1="8" y1="91" x2="112" y2="91" ${dd}/><polygon points="8,89 8,93 4,91" ${arrow}/><polygon points="112,89 112,93 116,91" ${arrow}/><text x="60" y="99" ${txt}>${vl!=="—"?vl+"m":"Base"}</text><line x1="60" y1="10" x2="60" y2="82" stroke="#1e40af" stroke-width="1" stroke-dasharray="3 2"/><polygon points="58,10 62,10 60,6" ${arrow}/><text x="69" y="50" ${txt}>${vh!=="—"?vh+"m":"Alt."}</text><text x="60" y="5" ${sub}>A = (B×Alt.)/2</text></svg>`
  if (formato === "Irregular") return `<svg viewBox="0 0 100 90" width="100" height="90" xmlns="http://www.w3.org/2000/svg"><polygon points="18,72 30,22 65,13 92,38 88,78 47,86" ${s} stroke-dasharray="5 3"/><text x="50" y="50" fill="#94a3b8" font-size="14" font-family="monospace" text-anchor="middle">?</text><text x="50" y="88" ${sub}>Área manual</text></svg>`
  return ""
}

// ===== Diagramas SVG por formato =====
function FormatoSVG({ formato }: { formato: string }) {
  const s = { stroke: "#94a3b8", fill: "none", strokeWidth: 1.5 }
  const dim = { stroke: "#38bdf8", fill: "none", strokeWidth: 1, strokeDasharray: "4 2" }
  const txt = { fill: "#38bdf8", fontSize: 10, fontFamily: "monospace" }
  const arrow = "#38bdf8"

  if (formato === "Circular") return (
    <svg viewBox="0 0 120 100" width={120} height={100}>
      <circle cx={60} cy={50} r={36} {...s} />
      {/* diâmetro horizontal */}
      <line x1={24} y1={50} x2={96} y2={50} {...dim} />
      <polygon points={`24,48 24,52 20,50`} fill={arrow} />
      <polygon points={`96,48 96,52 100,50`} fill={arrow} />
      <text x={60} y={44} textAnchor="middle" {...txt}>Ø diâm.</text>
      {/* fórmula */}
      <text x={60} y={90} textAnchor="middle" fill="#64748b" fontSize={9} fontFamily="monospace">A = π × (Ø/2)²</text>
    </svg>
  )

  if (formato === "Oval") return (
    <svg viewBox="0 0 130 100" width={130} height={100}>
      <ellipse cx={65} cy={50} rx={48} ry={28} {...s} />
      <line x1={17} y1={50} x2={113} y2={50} {...dim} />
      <polygon points={`17,48 17,52 13,50`} fill={arrow} />
      <polygon points={`113,48 113,52 117,50`} fill={arrow} />
      <text x={65} y={44} textAnchor="middle" {...txt}>Ø H</text>
      <line x1={65} y1={22} x2={65} y2={78} {...dim} />
      <polygon points={`63,22 67,22 65,18`} fill={arrow} />
      <polygon points={`63,78 67,78 65,82`} fill={arrow} />
      <text x={75} y={54} {...txt}>Ø V</text>
      <text x={65} y={95} textAnchor="middle" fill="#64748b" fontSize={9} fontFamily="monospace">A = π × (H/2) × (V/2)</text>
    </svg>
  )

  if (formato === "Quadrado") return (
    <svg viewBox="0 0 110 100" width={110} height={100}>
      <rect x={20} y={15} width={70} height={70} {...s} />
      <line x1={20} y1={6} x2={90} y2={6} {...dim} />
      <polygon points={`20,4 20,8 16,6`} fill={arrow} />
      <polygon points={`90,4 90,8 94,6`} fill={arrow} />
      <text x={55} y={4} textAnchor="middle" {...txt}>Lado</text>
      <text x={55} y={92} textAnchor="middle" fill="#64748b" fontSize={9} fontFamily="monospace">A = Lado²</text>
    </svg>
  )

  if (formato === "Retangular") return (
    <svg viewBox="0 0 130 100" width={130} height={100}>
      <rect x={15} y={20} width={100} height={55} {...s} />
      {/* largura */}
      <line x1={15} y1={8} x2={115} y2={8} {...dim} />
      <polygon points={`15,6 15,10 11,8`} fill={arrow} />
      <polygon points={`115,6 115,10 119,8`} fill={arrow} />
      <text x={65} y={6} textAnchor="middle" {...txt}>Larg.</text>
      {/* comprimento */}
      <line x1={120} y1={20} x2={120} y2={75} {...dim} />
      <polygon points={`118,20 122,20 120,16`} fill={arrow} />
      <polygon points={`118,75 122,75 120,79`} fill={arrow} />
      <text x={126} y={51} textAnchor="middle" {...txt} fontSize={9}>Comp.</text>
      <text x={65} y={95} textAnchor="middle" fill="#64748b" fontSize={9} fontFamily="monospace">A = Larg. × Comp.</text>
    </svg>
  )

  if (formato === "Triangular") return (
    <svg viewBox="0 0 130 105" width={130} height={105}>
      {/* triângulo isósceles */}
      <polygon points="65,12 10,85 120,85" {...s} />
      {/* base */}
      <line x1={10} y1={94} x2={120} y2={94} {...dim} />
      <polygon points={`10,92 10,96 6,94`} fill={arrow} />
      <polygon points={`120,92 120,96 124,94`} fill={arrow} />
      <text x={65} y={102} textAnchor="middle" {...txt}>Base</text>
      {/* altura */}
      <line x1={65} y1={12} x2={65} y2={85} stroke="#38bdf8" strokeWidth={1} strokeDasharray="3 2" />
      <line x1={56} y1={70} x2={74} y2={70} stroke="#38bdf8" strokeWidth={1} />
      <polygon points={`63,12 67,12 65,8`} fill={arrow} />
      <polygon points={`63,85 67,85 65,89`} fill={arrow} />
      <text x={73} y={52} {...txt}>Alt.</text>
      <text x={65} y={6} textAnchor="middle" fill="#64748b" fontSize={9} fontFamily="monospace">A = (Base × Alt.) / 2</text>
    </svg>
  )

  if (formato === "Irregular") return (
    <svg viewBox="0 0 120 100" width={120} height={100}>
      <polygon points="20,75 35,25 70,15 100,40 95,80 50,90" {...s} strokeDasharray="5 3" />
      <text x={60} y={52} textAnchor="middle" fill="#94a3b8" fontSize={11} fontFamily="monospace">?</text>
      <text x={60} y={95} textAnchor="middle" fill="#64748b" fontSize={9} fontFamily="monospace">Área manual (m²)</text>
    </svg>
  )

  return null
}

type ItemComAmbiente = Item & { envNome: string }

// Agrupa todos os itens de todos os ambientes por categoria
function groupByCategory(environments: Env[], incluirAditivos: boolean) {
  const catMap = new Map<string, { label: string; items: ItemComAmbiente[] }>()
  for (const env of environments) {
    for (const item of env.proposalItems) {
      if (!incluirAditivos && item.is_aditivo) continue
      const key = item.category?.nome ?? "__none__"
      const label = item.category?.nome ?? "Sem categoria"
      if (!catMap.has(key)) catMap.set(key, { label, items: [] })
      catMap.get(key)!.items.push({ ...item, envNome: env.nome })
    }
  }
  return [...catMap.entries()]
    .sort(([ka], [kb]) => (ka === "__none__" ? 1 : kb === "__none__" ? -1 : 0))
    .map(([, v]) => v)
}

const nomeDoItem = (i: Item) => i.product?.nome ?? i.kit?.nome ?? "—"

// Seção de dimensionamento por categoria
function CategoriaSection({
  label, items, dims, onDimChange,
}: {
  label: string
  items: ItemComAmbiente[]
  dims: DimMap
  onDimChange: (itemId: string, field: keyof Dimensoes, value: string) => void
}) {
  const confirmar = useConfirmar()
  const [margem, setMargem] = useState(10)
  const [expanded, setExpanded] = useState(true)
  const [outrosOpen, setOutrosOpen] = useState(false)
  const [outrosId, setOutrosId] = useState<string | null>(null)
  const [outrosForm, setOutrosForm] = useState({ descricao: "", formato: "", formato_custom: "", instalacao: "", instalacao_custom: "" })

  function abrirOutros(itemId: string, d: Dimensoes) {
    setOutrosId(itemId)
    setOutrosForm({
      descricao: d.outros_descricao || "",
      formato: d.outros_formato || "",
      formato_custom: d.outros_formato_custom || "",
      instalacao: d.outros_instalacao || "",
      instalacao_custom: d.outros_instalacao_custom || "",
    })
    setOutrosOpen(true)
  }

  function salvarOutros() {
    if (outrosId) {
      onDimChange(outrosId, "outros_descricao", outrosForm.descricao)
      onDimChange(outrosId, "outros_formato", outrosForm.formato)
      onDimChange(outrosId, "outros_formato_custom", outrosForm.formato_custom)
      onDimChange(outrosId, "outros_instalacao", outrosForm.instalacao)
      onDimChange(outrosId, "outros_instalacao_custom", outrosForm.instalacao_custom)
    }
    setOutrosOpen(false)
  }

  const totalQtd = items.reduce((s, i) => s + i.quantidade, 0)
  const totalQtdMargem = Math.ceil(totalQtd * (1 + margem / 100))
  const totalArea = items.reduce((s, i) => s + calcArea(getDim(dims, i.id)) * i.quantidade, 0)
  const totalAreaMargem = totalArea > 0 ? totalArea * (1 + margem / 100) : 0
  const hasAreas = items.some(i => calcArea(getDim(dims, i.id)) > 0)

  return (
    <div className="bg-slate-900 rounded-xl border border-white/10 overflow-hidden">
      <div className="flex items-center justify-between px-5 py-3 border-b border-white/10 bg-slate-800/50">
        <button type="button" onClick={() => setExpanded(e => !e)}
          className="flex items-center gap-2 text-white font-semibold text-sm hover:text-sky-400 transition-colors">
          {expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          <Ruler className="w-4 h-4 text-sky-400" />
          {label}
          <span className="text-slate-500 font-normal text-xs ml-1">({items.length} {items.length === 1 ? "item" : "itens"})</span>
        </button>
        <div className="flex items-center gap-2">
          <span className="text-slate-400 text-xs">Margem</span>
          <input type="number" min={0} max={100} step={1} value={margem}
            onChange={e => setMargem(Math.max(0, Math.min(100, Number(e.target.value))))}
            className="w-14 h-6 px-2 rounded bg-slate-800 border border-slate-700 text-white text-xs text-center focus:outline-none focus:ring-1 focus:ring-sky-500" />
          <span className="text-slate-400 text-xs">%</span>
        </div>
      </div>

      {expanded && (
        <div className="p-5 space-y-4">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-slate-500 text-xs border-b border-white/10">
                  <th className="text-left py-1.5 pr-3 font-medium">Item</th>
                  <th className="text-left py-1.5 pr-2 font-medium w-32">Tipo</th>
                  <th className="text-left py-1.5 pr-3 font-medium text-slate-600">Ambiente</th>
                  <th className="text-center py-1.5 pr-2 font-medium w-12">Qtd</th>
                  <th className="text-center py-1.5 pr-2 font-medium w-20">Larg. m</th>
                  <th className="text-center py-1.5 pr-2 font-medium w-20">Alt. m</th>
                  <th className="text-center py-1.5 pr-2 font-medium w-20">Comp. m</th>
                  <th className="text-center py-1.5 pr-2 font-medium w-24 text-sky-400/80">Área m²</th>
                  <th className="text-center py-1.5 pr-2 font-medium w-24 text-violet-400/80">Vol. m³</th>
                  <th className="text-center py-1.5 pr-2 font-medium w-24 text-amber-400/80">+{margem}%</th>
                  <th className="text-center py-1.5 pr-2 font-medium w-20">Qtd+{margem}%</th>
                  <th className="text-left py-1.5 font-medium min-w-[100px]">Obs.</th>
                </tr>
              </thead>
              <tbody>
                {items.map(item => {
                  const d = getDim(dims, item.id)
                  const area = calcArea(d)
                  const vol = calcVolume(d)
                  const areaTotal = area * item.quantidade
                  const areaMargem = areaTotal > 0 ? areaTotal * (1 + margem / 100) : 0
                  const qtdMargem = Math.ceil(item.quantidade * (1 + margem / 100))
                  const isIrregular = d.tipo === "Outros" && d.outros_formato === "Irregular"

                  return (
                    <tr key={item.id} className="border-b border-white/5 hover:bg-slate-800/30 group">
                      <td className="py-2 pr-3">
                        <div className="flex items-center gap-2.5">
                          {item.product?.imagem_url ? (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img src={proxiedImg(item.product.imagem_url)} alt={nomeDoItem(item)} referrerPolicy="no-referrer"
                              className="w-9 h-9 rounded-xl object-cover bg-slate-800 flex-shrink-0" />
                          ) : (
                            <div className="w-9 h-9 rounded-xl bg-slate-800 flex items-center justify-center flex-shrink-0">
                              <ImageOff className="w-4 h-4 text-slate-600" />
                            </div>
                          )}
                          <div className="min-w-0">
                            <p className="text-white text-sm truncate">{nomeDoItem(item)}</p>
                            <p className="text-slate-600 text-xs">
                              {item.product?.sku}
                              {item.is_aditivo && <span className="ml-1.5 text-[10px] bg-orange-500/20 text-orange-300 rounded px-1">aditivo</span>}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="py-2 pr-2">
                        <select value={d.tipo} onChange={e => {
                          onDimChange(item.id, "tipo", e.target.value)
                          if (e.target.value === "Outros") abrirOutros(item.id, getDim(dims, item.id))
                        }}
                          className="w-full h-7 px-1.5 rounded bg-slate-800 border border-slate-700/50 group-hover:border-slate-600 text-white text-xs focus:outline-none focus:ring-1 focus:ring-sky-500">
                          <option value="">—</option>
                          {TIPOS.map(t => <option key={t} value={t}>{t}</option>)}
                        </select>
                        {d.tipo === "Outros" && (
                          <button type="button" onClick={() => abrirOutros(item.id, d)}
                            className="mt-0.5 text-[10px] text-sky-400 hover:text-sky-300 truncate max-w-full block leading-tight">
                            {d.outros_descricao ? `✎ ${d.outros_descricao.slice(0, 12)}${d.outros_descricao.length > 12 ? "…" : ""}` : "⚙ especificar"}
                            {d.outros_formato && <span className="ml-1 text-slate-500">{d.outros_formato === "Outros" ? d.outros_formato_custom || "fmt?" : d.outros_formato.slice(0, 6)}</span>}
                          </button>
                        )}
                      </td>
                      <td className="py-2 pr-3 text-slate-500 text-xs">{item.envNome}</td>
                      <td className="py-2 pr-2 text-center text-slate-300 font-medium">{item.quantidade}</td>

                      {getMedidaCfg(d.tipo === "Outros" ? d.outros_formato : "").map(({ field, placeholder, disabled }) => (
                        <td key={field} className="py-2 pr-2">
                          <input type="number" min={0} step={0.01} value={disabled ? "" : d[field]}
                            onChange={e => !disabled && onDimChange(item.id, field, e.target.value)}
                            placeholder={placeholder} disabled={disabled}
                            className={`w-full h-7 px-1.5 rounded bg-slate-800 border text-white text-xs text-center focus:outline-none focus:ring-1 focus:ring-sky-500 placeholder:text-slate-600 ${disabled ? "opacity-30 cursor-not-allowed border-transparent" : "border-slate-700/50 group-hover:border-slate-600"}`} />
                        </td>
                      ))}

                      <td className="py-2 pr-2">
                        {isIrregular ? (
                          /* Irregular: área é entrada manual */
                          <input type="number" min={0} step={0.01} value={d.area}
                            onChange={e => onDimChange(item.id, "area", e.target.value)}
                            placeholder="m²"
                            className="w-full h-7 px-1.5 rounded bg-slate-800 border border-sky-500/50 text-sky-300 text-xs text-center focus:outline-none focus:ring-1 focus:ring-sky-500 placeholder:text-slate-600" />
                        ) : area > 0 ? (
                          /* Área calculada automaticamente — somente leitura */
                          <div className="w-full h-7 flex items-center justify-center rounded bg-sky-900/30 border border-sky-500/30 text-sky-300 text-xs font-semibold">
                            {area.toFixed(2)}
                          </div>
                        ) : (
                          <div className="w-full h-7 flex items-center justify-center text-slate-600 text-xs">—</div>
                        )}
                      </td>
                      <td className="py-2 pr-2 text-center text-violet-300 text-xs font-semibold">
                        {vol > 0 ? vol.toFixed(3) : <span className="text-slate-700">—</span>}
                      </td>
                      <td className="py-2 pr-2 text-center text-amber-400 text-xs font-semibold">{areaMargem > 0 ? areaMargem.toFixed(2) : "—"}</td>
                      <td className="py-2 pr-2 text-center text-white font-bold">{qtdMargem}</td>
                      <td className="py-2">
                        <input value={d.obs} onChange={e => onDimChange(item.id, "obs", e.target.value)} placeholder="observação…"
                          className="w-full h-7 px-1.5 rounded bg-transparent border border-transparent group-hover:border-slate-700 text-slate-400 text-xs focus:outline-none focus:border-slate-600 placeholder:text-slate-700" />
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          <div className="flex flex-wrap justify-end gap-6 border-t border-white/10 pt-3 text-xs">
            <span className="text-slate-400">Qtd total: <span className="text-white font-semibold">{totalQtd}</span></span>
            <span className="text-slate-400">Qtd c/ margem: <span className="text-white font-bold">{totalQtdMargem}</span></span>
            {hasAreas && (
              <>
                <span className="text-slate-400">Área total: <span className="text-sky-300 font-semibold">{totalArea.toFixed(2)} m²</span></span>
                <span className="text-slate-400">Área c/ margem: <span className="text-amber-400 font-bold">{totalAreaMargem.toFixed(2)} m²</span></span>
              </>
            )}
          </div>
        </div>
      )}

      {/* Dialog: especificar "Outros" */}
      <Dialog open={outrosOpen} onOpenChange={setOutrosOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Especificar &quot;Outros&quot;</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1">
              <label className="text-slate-300 text-sm">Descrição</label>
              <input value={outrosForm.descricao} onChange={e => setOutrosForm(f => ({ ...f, descricao: e.target.value }))}
                placeholder="Ex: Nicho, Painel de LED, Forro decorativo..."
                className="w-full h-9 px-3 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-1 focus:ring-sky-500" />
            </div>
            <div className="space-y-1">
              <label className="text-slate-300 text-sm">Formato</label>
              <select value={outrosForm.formato} onChange={e => setOutrosForm(f => ({ ...f, formato: e.target.value, formato_custom: "" }))}
                className="w-full h-9 px-3 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-1 focus:ring-sky-500">
                <option value="">—</option>
                <option value="Quadrado">Quadrado</option>
                <option value="Retangular">Retangular</option>
                <option value="Triangular">Triangular</option>
                <option value="Circular">Circular</option>
                <option value="Oval">Oval</option>
                <option value="Irregular">Irregular (área livre)</option>
                <option value="Outros">Outros (especificar)</option>
              </select>
              {outrosForm.formato === "Outros" && (
                <input value={outrosForm.formato_custom} onChange={e => setOutrosForm(f => ({ ...f, formato_custom: e.target.value }))}
                  placeholder="Descreva o formato..."
                  className="mt-1.5 w-full h-9 px-3 rounded-xl bg-slate-800 border border-sky-500/40 text-white text-sm focus:outline-none focus:ring-1 focus:ring-sky-500" />
              )}
              {/* Diagrama SVG + hint por formato */}
              {outrosForm.formato && outrosForm.formato !== "Outros" && (
                <div className="mt-2 flex items-start gap-3">
                  <div className="bg-slate-900 rounded-2xl p-2 border border-slate-700/50 flex-shrink-0">
                    <FormatoSVG formato={outrosForm.formato} />
                  </div>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    {outrosForm.formato === "Circular" && <>Informe o <span className="text-sky-300 font-medium">diâmetro</span> no campo <strong>Larg.</strong><br/>Fórmula: A = π × (Ø/2)²</>}
                    {outrosForm.formato === "Oval" && <>Informe <span className="text-sky-300 font-medium">Diâm. H</span> em <strong>Larg.</strong> e <span className="text-sky-300 font-medium">Diâm. V</span> em <strong>Comp.</strong><br/>Fórmula: A = π × (H/2) × (V/2)</>}
                    {outrosForm.formato === "Quadrado" && <>Informe o <span className="text-sky-300 font-medium">lado</span> em <strong>Larg.</strong><br/>Fórmula: A = Lado²</>}
                    {outrosForm.formato === "Retangular" && <>Informe <span className="text-sky-300 font-medium">largura</span> e <span className="text-sky-300 font-medium">comprimento</span>.<br/>Fórmula: A = Larg. × Comp.</>}
                    {outrosForm.formato === "Triangular" && <>Informe a <span className="text-sky-300 font-medium">base</span> em <strong>Larg.</strong> e a <span className="text-sky-300 font-medium">altura</span> em <strong>Alt.</strong><br/>Fórmula: A = (Base × Alt.) / 2</>}
                    {outrosForm.formato === "Irregular" && <>Informe a área diretamente no campo <span className="text-sky-300 font-medium">Área m²</span> na tabela.<br/>Os campos de medida ficam desativados.</>}
                  </p>
                </div>
              )}
            </div>
            <div className="space-y-1">
              <label className="text-slate-300 text-sm">Tipo de instalação</label>
              <select value={outrosForm.instalacao} onChange={e => setOutrosForm(f => ({ ...f, instalacao: e.target.value, instalacao_custom: "" }))}
                className="w-full h-9 px-3 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-1 focus:ring-sky-500">
                <option value="">—</option>
                <option value="Embutir no gesso">Embutir no gesso</option>
                <option value="Dentro da marcenaria">Dentro da marcenaria</option>
                <option value="Sobrepor">Sobrepor</option>
                <option value="Pendente">Pendente</option>
                <option value="Em mesa / rack">Em mesa / rack</option>
                <option value="Outros">Outros (especificar)</option>
              </select>
              {outrosForm.instalacao === "Outros" && (
                <input value={outrosForm.instalacao_custom} onChange={e => setOutrosForm(f => ({ ...f, instalacao_custom: e.target.value }))}
                  placeholder="Descreva o tipo de instalação..."
                  className="mt-1.5 w-full h-9 px-3 rounded-xl bg-slate-800 border border-sky-500/40 text-white text-sm focus:outline-none focus:ring-1 focus:ring-sky-500" />
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOutrosOpen(false)} className="border-slate-700 text-slate-300">Cancelar</Button>
            <Button onClick={salvarOutros} className="bg-sky-600 hover:bg-sky-700 text-white">Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ===== Gerador de relatório profissional (abre janela para imprimir/PDF) =====
async function gerarRelatorio(opts: {
  avisar?: (msg: string) => void
  obraNome: string
  responsavel: string
  margem: number
  itens: ItemComAmbiente[]
  dims: DimMap
  logoUrl?: string
}) {
  const { obraNome, responsavel, margem, itens, dims, logoUrl } = opts
  const abs = (u?: string | null) => {
    if (!u) return ""
    const p = proxiedImg(u)
    return p.startsWith("/") ? location.origin + p : p
  }

  // Agrupa por AMBIENTE
  const ambienteMap = new Map<string, ItemComAmbiente[]>()
  for (const it of itens) {
    if (!ambienteMap.has(it.envNome)) ambienteMap.set(it.envNome, [])
    ambienteMap.get(it.envNome)!.push(it)
  }
  const gruposOrdenados = [...ambienteMap.entries()]

  // Colunas: foto | svg | item | qtd | larg | alt | comp = 7
  const NCOLS = 7
  const linhaItem = (it: ItemComAmbiente) => {
    const d = getDim(dims, it.id)
    const img = abs(it.product?.imagem_url)
    const fmt = d.tipo === "Outros" ? (d.outros_formato === "Outros" ? (d.outros_formato_custom || "Outros") : d.outros_formato) : ""
    const svgCode = fmt ? formatoSvgStr(fmt, { l: d.largura, h: d.altura, c: d.comprimento }) : ""
    const dimCfg = getMedidaCfg(fmt)
    const dimCells = dimCfg.map(({ field, placeholder, disabled }) =>
      `<td class="num">${disabled ? "—" : (d[field] ? `${fmtN(d[field])} m` : `<span style="color:#94a3b8">${placeholder}</span>`)}</td>`
    ).join("")

    return `
      <tr class="item-row">
        <td class="item-photo-cell">
          ${img ? `<img src="${img}" class="thumb"/>` : `<div class="thumb noimg">—</div>`}
        </td>
        <td class="item-svg-cell">
          ${svgCode ? svgCode : `<div class="svg-placeholder"></div>`}
        </td>
        <td class="item-info-cell">
          <div class="item-nome">${nomeDoItem(it)}${it.product?.sku ? ` <span class="sku">[${it.product.sku}]</span>` : ""}</div>
          ${d.tipo ? `<div class="item-tag">${d.tipo}${fmt ? ` · ${fmt}` : ""}</div>` : ""}
          ${d.outros_descricao ? `<div class="item-desc">${d.outros_descricao}</div>` : ""}
        </td>
        <td class="num">${it.quantidade}</td>
        ${dimCells}
      </tr>
      ${d.obs ? `<tr class="obs-row"><td colspan="${NCOLS}" class="item-obs-cell">Obs: ${d.obs}</td></tr>` : ""}`
  }

  const secoes = gruposOrdenados.map(([ambiente, lista]) => {
    const totalArea = lista.reduce((s, i) => s + calcArea(getDim(dims, i.id)) * i.quantidade, 0)
    const totalVol = lista.reduce((s, i) => s + calcVolume(getDim(dims, i.id)) * i.quantidade, 0)
    const totalQtd = lista.reduce((s, i) => s + i.quantidade, 0)
    return `
      <div class="section">
        <div class="section-header">
          <span class="section-accent"></span>
          <span class="section-title">${ambiente}</span>
          <span class="section-count">${lista.length} ${lista.length === 1 ? "item" : "itens"}</span>
          <span class="section-totals">
            ${totalArea > 0 ? `Área: <strong>${fmtN(totalArea)} m²</strong> → <strong>${fmtN(totalArea * (1 + margem / 100))} m²</strong>` : ""}
            ${totalVol > 0 ? ` &nbsp;·&nbsp; Vol: <strong>${fmtN(totalVol)} m³</strong>` : ""}
          </span>
        </div>
        <table class="items-table">
          <thead>
            <tr>
              <th class="col-foto">Foto</th>
              <th class="col-forma">Forma</th>
              <th class="col-nome">Item</th>
              <th>Qtd</th>
              <th>Larg.</th><th>Alt./Prof.</th><th>Comp.</th>
            </tr>
          </thead>
          <tbody>
            ${lista.map(linhaItem).join("")}
          </tbody>
          <tfoot>
            <tr>
              <td colspan="3" class="tfoot-label">Totais do ambiente</td>
              <td class="num"><strong>${totalQtd}</strong></td>
              <td colspan="3"></td>
            </tr>
          </tfoot>
        </table>
      </div>`
  }).join("")

  const logoHtml = logoUrl ? `<img src="${abs(logoUrl)}" alt="logo" class="header-logo"/>` : ""

  const html = `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"/>
    <title>Relatório de Dimensionamento, ${obraNome}</title>
    <style>
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:Arial,Helvetica,sans-serif;background:#fff;color:#1e293b;font-size:11px;padding:24px 28px;max-width:960px;margin:0 auto}
      html{background:#fff}
      /* ---- HEADER ---- */
      .doc-header{display:flex;align-items:flex-start;justify-content:space-between;border-bottom:2px solid #1e40af;padding-bottom:12px;margin-bottom:20px}
      .doc-header-left{}
      .doc-title{font-size:16px;font-weight:700;color:#0f172a;letter-spacing:-.3px}
      .doc-subtitle{font-size:10px;color:#64748b;margin-top:2px;text-transform:uppercase;letter-spacing:.6px}
      .doc-meta{margin-top:8px;display:grid;grid-template-columns:auto auto;column-gap:32px;row-gap:2px}
      .doc-meta-row{font-size:11px;color:#475569}
      .doc-meta-row b{color:#0f172a}
      .header-logo{max-height:52px;max-width:140px;object-fit:contain}
      /* ---- SECTION ---- */
      .section{margin-bottom:22px;page-break-inside:avoid}
      .section-header{display:flex;align-items:center;gap:8px;background:#f8fafc;border-left:3px solid #1e40af;padding:5px 8px;margin-bottom:6px}
      .section-accent{width:0}
      .section-title{font-size:12px;font-weight:700;color:#0f172a}
      .section-count{font-size:10px;color:#94a3b8;background:#e2e8f0;padding:1px 6px;border-radius:10px}
      .section-totals{margin-left:auto;font-size:10px;color:#475569}
      /* ---- TABLE ---- */
      .items-table{width:100%;border-collapse:collapse;font-size:10.5px}
      .items-table thead tr{background:#f1f5f9}
      .items-table th{padding:4px 6px;text-align:center;border:1px solid #e2e8f0;font-weight:600;color:#475569;white-space:nowrap}
      .col-foto{width:110px;text-align:center!important}
      .col-forma{width:90px;text-align:center!important}
      .col-nome{text-align:left!important;min-width:110px}
      .items-table td{padding:4px 5px;border:1px solid #e2e8f0;vertical-align:top}
      .num{text-align:center;white-space:nowrap;vertical-align:middle}
      /* foto — coluna esquerda, grande, rowspan=2 */
      .item-photo-cell{text-align:center;vertical-align:middle;padding:5px;width:110px}
      .thumb{width:100px;height:100px;object-fit:cover;border-radius:5px;display:block;margin:0 auto}
      .thumb.noimg{width:100px;height:100px;background:#f1f5f9;display:flex;align-items:center;justify-content:center;color:#cbd5e1;font-size:9px;border-radius:5px;margin:0 auto}
      /* svg — col 2 linha 1 */
      .item-svg-cell{text-align:center;vertical-align:middle;padding:4px;width:90px;border-bottom:none!important}
      .item-svg-cell svg{width:80px;height:66px}
      .svg-placeholder{width:80px;height:66px}
      /* métricas — col 2 linha 2 (abaixo do svg) */
      .item-metrics-row td{border-top:none!important}
      .item-metrics-cell{text-align:center;padding:3px 4px 5px;font-size:9.5px;color:#475569;vertical-align:top;white-space:nowrap}
      .m-area{color:#1e40af}.m-vol{color:#7c3aed}.m-marg{color:#b45309}
      /* info do item — col 3, rowspan=2 */
      .item-info-cell{vertical-align:top;padding:5px 6px}
      .item-nome{font-weight:600;font-size:11px;color:#0f172a}
      .sku{font-weight:400;color:#94a3b8;font-size:10px}
      .item-tag{margin-top:2px;font-size:10px;color:#1e40af;font-weight:600}
      .item-desc{font-size:10px;color:#64748b;margin-top:1px}
      /* obs — full-width abaixo de tudo */
      .obs-row td{border-top:none!important}
      .item-obs-cell{font-size:9.5px;color:#94a3b8;font-style:italic;padding:2px 6px 5px;border-top:none!important}
      /* tfoot */
      tfoot tr{background:#f8fafc}
      .tfoot-label{text-align:right;color:#475569;padding-right:8px;font-size:10px}
      .tfoot-metrics-row td{border-top:none!important}
      .tfoot-metrics{font-size:9.5px;color:#475569;padding:2px 5px 4px;border-top:none!important}
      /* ---- FOOTER ---- */
      .doc-footer{margin-top:24px;border-top:1px solid #e2e8f0;padding-top:8px;color:#94a3b8;font-size:9.5px;display:flex;justify-content:space-between}
      /* ---- PRINT ---- */
      .actions{margin-bottom:16px}
      .actions button{background:#1e40af;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:13px;cursor:pointer;font-weight:600}
      @media print{.actions{display:none}body{padding:0}}
    </style></head><body>
    <div class="actions"><button onclick="window.print()">Imprimir / Salvar PDF</button></div>
    <div class="doc-header">
      <div class="doc-header-left">
        <div class="doc-title">Relatório de Dimensionamento</div>
        <div class="doc-subtitle">Levantamento técnico de materiais</div>
        <div class="doc-meta">
          <div class="doc-meta-row">Projeto: <b>${obraNome}</b></div>
          <div class="doc-meta-row">Data: <b>${new Date().toLocaleDateString("pt-BR")}</b></div>
          ${responsavel ? `<div class="doc-meta-row">Responsável: <b>${responsavel}</b></div>` : "<div></div>"}
          <div class="doc-meta-row">Margem aplicada: <b>${margem}%</b></div>
        </div>
      </div>
      ${logoHtml}
    </div>
    ${secoes || "<p style='color:#94a3b8'>Nenhum item para exibir.</p>"}
    <div class="doc-footer">
      <span>Control.Deal, Sistema de Gestão de Obras</span>
      <span>Gerado em ${new Date().toLocaleString("pt-BR")}</span>
    </div>
  </body></html>`

  const win = window.open("", "_blank", "width=1000,height=750")
  if (!win) { opts.avisar?.("Permita pop-ups para gerar o relatório."); return }
  win.document.write(html)
  win.document.close()
}

export default function DimensionamentoTab({ obraId, obraNome, environments, dimensionamentoInicial }: Props) {
  const [dims, setDims] = useState<DimMap>(() => {
    const init: DimMap = {}
    for (const [k, v] of Object.entries(dimensionamentoInicial ?? {})) init[k] = { ...DIM_EMPTY, ...v }
    return init
  })
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [incluirAditivos, setIncluirAditivos] = useState(false)
  const [responsavel, setResponsavel] = useState("")
  const [margemRelatorio, setMargemRelatorio] = useState(10)
  const [empresaLogoUrl, setEmpresaLogoUrl] = useState<string | undefined>(undefined)

  useEffect(() => {
    fetch("/api/empresa").then(r => r.ok ? r.json() : null).then(data => {
      if (data?.logo_url) setEmpresaLogoUrl(data.logo_url)
    }).catch(() => {})
  }, [])

  const handleDimChange = useCallback((itemId: string, field: keyof Dimensoes, value: string) => {
    setDims(prev => ({ ...prev, [itemId]: { ...getDim(prev, itemId), [field]: value } }))
    setSaved(false)
  }, [])

  const categorias = useMemo(() => groupByCategory(environments, incluirAditivos), [environments, incluirAditivos])
  const todosItens = useMemo(() => categorias.flatMap(c => c.items), [categorias])
  const totalItens = environments.reduce((s, e) => s + e.proposalItems.length, 0)

  async function handleSave() {
    setSaving(true)
    try {
      await fetch(`/api/obras/${obraId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dimensionamento: dims }),
      })
      setSaved(true)
      setTimeout(() => setSaved(false), 3000)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-5">
      {/* Barra de controles */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <p className="text-white font-semibold">Relatório de Dimensionamento</p>
          <p className="text-slate-500 text-xs">Classifique cada item (Gesso / Marcenaria / Outros), preencha as dimensões e gere o relatório para o responsável.</p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <label className="flex items-center gap-2 text-slate-400 text-sm cursor-pointer">
            <input type="checkbox" checked={incluirAditivos} onChange={e => setIncluirAditivos(e.target.checked)} className="w-4 h-4 accent-sky-500" />
            Incluir aditivos
          </label>
          <button onClick={handleSave} disabled={saving}
            className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-white text-sm font-medium px-4 py-2 rounded-2xl transition-colors">
            <Save className="w-4 h-4" />
            {saving ? "Salvando..." : saved ? "Salvo ✓" : "Salvar dimensões"}
          </button>
        </div>
      </div>

      {/* Gerar relatório */}
      {totalItens > 0 && (
        <div className="bg-slate-900 rounded-xl border border-white/10 p-4 flex flex-wrap items-end gap-3">
          <div className="flex-1 min-w-[180px]">
            <label className="text-slate-400 text-xs">Responsável (aparece no relatório)</label>
            <input value={responsavel} onChange={e => setResponsavel(e.target.value)} placeholder="Ex: Gesseiro João / Marceneiro Carlos"
              className="w-full mt-1 h-9 px-3 rounded-2xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-1 focus:ring-sky-500 placeholder:text-slate-600" />
          </div>
          <div>
            <label className="text-slate-400 text-xs">Margem do relatório (%)</label>
            <input type="number" min={0} max={100} value={margemRelatorio} onChange={e => setMargemRelatorio(Math.max(0, Math.min(100, Number(e.target.value))))}
              className="w-24 mt-1 h-9 px-3 rounded-2xl bg-slate-800 border border-slate-700 text-white text-sm text-center focus:outline-none focus:ring-1 focus:ring-sky-500" />
          </div>
          <button
            onClick={() => gerarRelatorio({ obraNome: obraNome ?? "Obra", responsavel, margem: margemRelatorio, itens: todosItens, dims, logoUrl: empresaLogoUrl })}
            className="flex items-center gap-2 bg-sky-600 hover:bg-sky-500 text-white text-sm font-medium px-4 py-2 rounded-2xl transition-colors">
            <FileText className="w-4 h-4" /> Gerar relatório
          </button>
        </div>
      )}

      {totalItens === 0 ? (
        <div className="bg-slate-900 rounded-xl border border-white/10 p-16 text-center">
          <Ruler className="w-10 h-10 text-slate-700 mx-auto mb-3" />
          <p className="text-slate-500">Nenhum item na obra.</p>
          <p className="text-slate-600 text-xs mt-1">Sincronize os ambientes da proposta na aba Engenharia.</p>
        </div>
      ) : categorias.length === 0 ? (
        <div className="bg-slate-900 rounded-xl border border-white/10 p-16 text-center">
          <Ruler className="w-10 h-10 text-slate-700 mx-auto mb-3" />
          <p className="text-slate-500">Nenhum item visível.</p>
        </div>
      ) : (
        categorias.map((cat, i) => (
          <CategoriaSection key={i} label={cat.label} items={cat.items} dims={dims} onDimChange={handleDimChange} />
        ))
      )}
    </div>
  )
}
