export default function Loading() {
  return (
    <div className="flex flex-col gap-4 p-5 animate-pulse">
      <div className="flex items-center justify-between">
        <div className="h-7 w-24 bg-muted rounded-xl" />
        <div className="h-9 w-28 bg-muted rounded-xl" />
      </div>
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="h-24 bg-card rounded-2xl border border-border" />
      ))}
    </div>
  )
}
