"use client"

/**
 * Estudo de keypads — Obra → Engenharia → Projetos → Projeto Controllares.
 *
 * Fluxo: escolhe a planta (de Projetos ou do computador) → recorta → clica onde
 * fica cada KP → confere → planilha → "Salvar em Projetos" grava o .xlsx como
 * linha de Projetos (categoria Projeto Controllares, versão R00, R01…).
 * Regras e conferência em src/lib/projetos/keypads.ts.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import Link from "next/link"
import {
  ArrowLeft, Crop, FileUp, Image as ImageIcon, Loader2, Maximize2, Minus, Plus, Save,
  Sparkles, X, Check, FileSpreadsheet, Map as MapIcon,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { proxiedImg } from "@/lib/img"
import {
  ACABAMENTOS, MEDIDAS, PAVIMENTOS, conferencia, corDoNome, estudoVazio, kpNum, medidaDoNome,
  normalizaEstudo, normalizaKp, novoId, proximoKp, salasPerto, todosKps,
  type EstudoKeypads, type Keypad, type PlantaPav, type ProdutoKeypad,
} from "@/lib/projetos/keypads"
import { COLUNAS, EDITAVEIS, gerarXlsx, linhasDoPav, nomeAba, pavsComKp, valor, type Coluna } from "@/lib/projetos/keypads-planilha"
import { acharPlanta, carregarPlanta, cortarImagem, subirArquivo } from "@/lib/projetos/planta"
import { EscolherPlanta, Recorte, adicionarBlueprint as gravarBlueprint, nomeArquivo, roda, src, type Anexo, type Blueprint } from "../_projetos/comum"

interface ObraDados {
  id: string
  client_name: string
  projetos_blueprints: Blueprint[] | null
  anexos_projeto: Anexo[] | null
  estudo_keypads: EstudoKeypads | null
}

export default function EstudoKeypads({ obraId }: { obraId: string }) {
  const [obra, setObra] = useState<ObraDados | null>(null)
  const [erro, setErro] = useState("")
  const [e, setE] = useState<EstudoKeypads>(estudoVazio())
  const [pav, setPav] = useState<string>("TÉRREO")
  const [produtos, setProdutos] = useState<ProdutoKeypad[]>([])
  const [ambObra, setAmbObra] = useState<string[]>([])
  const [vista, setVista] = useState<"planta" | "planilha">("planta")
  const [ocupado, setOcupado] = useState("")
  const [salvo, setSalvo] = useState<"" | "salvando" | "ok">("")
  const [sel, setSel] = useState<string | null>(null)
  const [dlg, setDlg] = useState<{ id: string; novo: boolean; antes: Keypad[] } | null>(null)
  const [escolher, setEscolher] = useState(false)
  const [crop, setCrop] = useState<{ f: [number, number, number, number]; orig: { img: string; W: number; H: number } } | null>(null)
  const [pip, setPip] = useState(false)
  const [ia, setIa] = useState<"" | "rodando" | string>("")
  const [exportado, setExportado] = useState<string>("")
  const carregou = useRef(false)
  const eRef = useRef(e)
  eRef.current = e
  const hist = useRef<EstudoKeypads[]>([])
  /** Guarda o estado atual para o Ctrl+Z (chamar antes de mudar). */
  const marcar = useCallback(() => { hist.current.push(structuredClone(eRef.current)); if (hist.current.length > 60) hist.current.shift() }, [])
  const gravado = useRef("")

  const produto = useCallback((sku?: string) => (sku ? produtos.find((p) => p.sku === sku) : undefined), [produtos])
  const P = e.pavs[pav] ?? { nome: "", planta: null, kps: [] }
  const planta = P.planta

  /* -------- carregar -------- */
  useEffect(() => {
    ;(async () => {
      try {
        const [ro, rc, ra] = await Promise.all([
          fetch(`/api/obras/${obraId}`),
          fetch(`/api/obras/${obraId}/keypads-catalogo`),
          fetch(`/api/obras/${obraId}/ambientes`),
        ])
        if (!ro.ok) throw new Error("Não consegui abrir a obra.")
        const o = (await ro.json()) as ObraDados
        setObra(o)
        const est = normalizaEstudo(o.estudo_keypads)
        gravado.current = JSON.stringify(est)
        setE(est)
        carregou.current = true
        const primeiro = PAVIMENTOS.find((p) => est.pavs[p]?.planta || est.pavs[p]?.kps.length)
        if (primeiro) setPav(primeiro)
        if (rc.ok) setProdutos(await rc.json())
        if (ra.ok) setAmbObra(((await ra.json()).ambientes ?? []).map((a: { nome: string }) => a.nome.toUpperCase()))
      } catch (err) {
        setErro(err instanceof Error ? err.message : "Erro ao abrir.")
      }
    })()
  }, [obraId])

  /* -------- gravar sozinho (800 ms depois da última mudança) -------- */
  useEffect(() => {
    // Abrir a tela não grava nada: só grava quando o estudo ficou diferente
    // do que está no banco.
    const atual = JSON.stringify(e)
    if (!carregou.current || atual === gravado.current) return
    setSalvo("salvando")
    const t = setTimeout(async () => {
      const r = await fetch(`/api/obras/${obraId}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ estudo_keypads: e }),
      }).catch(() => null)
      if (r?.ok) gravado.current = atual
      setSalvo(r?.ok ? "ok" : "")
    }, 800)
    return () => clearTimeout(t)
  }, [e, obraId])

  /** Muda o estudo (cópia) e devolve o novo. */
  const mudar = useCallback((fn: (n: EstudoKeypads) => void) => {
    setE((velho) => {
      const n = structuredClone(velho)
      fn(n)
      return n
    })
  }, [])
  const mudarPav = useCallback((fn: (p: { nome: string; planta: PlantaPav | null; kps: Keypad[] }) => void) => {
    mudar((n) => {
      n.pavs[pav] ??= { nome: "", planta: null, kps: [] }
      fn(n.pavs[pav])
    })
  }, [mudar, pav])

  /* -------- planta: escolher, subir, recortar -------- */
  async function abrirPlanta(fonte: File | { url: string; nome: string }, origem: { nome: string; url: string } | null) {
    if (P.kps.length && !confirm(`Este pavimento já tem ${P.kps.length} keypad(s). Eles continuam nas mesmas posições na planta nova; confira e arraste se precisar. Trocar a planta?`)) return
    setEscolher(false)
    setOcupado("Abrindo a planta…")
    try {
      const pl = await carregarPlanta(fonte instanceof File ? fonte : { url: src(fonte.url), nome: fonte.nome })
      setOcupado("Guardando a planta…")
      const url = await subirArquivo(pl.dataUrl, `planta-${pav.toLowerCase()}.jpg`)
      // Arquivo novo do computador também vira linha de Projetos (Projeto de Obra)
      let orig = origem
      if (fonte instanceof File) {
        const urlArq = await subirArquivo(fonte, fonte.name)
        orig = { nome: fonte.name, url: urlArq }
        await adicionarBlueprint({ categoria: "Projeto de Obra", nome: fonte.name.replace(/\.[a-z0-9]+$/i, ""), url: urlArq })
      }
      const nova: PlantaPav = { origem: orig, img: url, W: pl.W, H: pl.H, orig: { img: url, W: pl.W, H: pl.H }, off: { x: 0, y: 0 }, salas: pl.salas, salasOrig: pl.salas }
      marcar()
      mudarPav((p) => {
        // KPs já marcados vão para a folha nova: desfaz o recorte antigo e
        // acompanha a escala (revisão da mesma planta costuma ter o mesmo enquadramento).
        const velha = p.planta
        if (velha?.orig) {
          const sx = nova.W / velha.orig.W, sy = nova.H / velha.orig.H
          p.kps.forEach((k) => { k.x = (k.x + velha.off.x) * sx; k.y = (k.y + velha.off.y) * sy })
        }
        p.planta = nova; p.nome = orig?.nome.replace(/\.[a-z0-9]+$/i, "") ?? p.nome })
      setOcupado("")
      // Já abre o recorte com a sugestão do programa
      setTimeout(() => abrirRecorte(nova), 50)
    } catch (err) {
      setOcupado("")
      alert(err instanceof Error ? err.message : "Não consegui abrir a planta.")
    }
  }

  async function abrirRecorte(pl = planta) {
    if (!pl?.orig) return
    const o = pl.orig
    const atual: [number, number, number, number] = [pl.off.x / o.W, pl.off.y / o.H, (pl.off.x + pl.W) / o.W, (pl.off.y + pl.H) / o.H]
    const cortada = pl.off.x || pl.off.y || pl.W !== o.W || pl.H !== o.H
    setCrop({ f: atual, orig: o })
    if (!cortada) {
      const f = await acharPlanta(src(o.img))
      setCrop((c) => (c ? { ...c, f } : c))
    }
  }

  async function aplicarRecorte(f: [number, number, number, number]) {
    if (!crop || !planta) return
    setOcupado("Recortando…")
    try {
      const r = await cortarImagem(src(crop.orig.img), f)
      const url = await subirArquivo(r.dataUrl, `planta-${pav.toLowerCase()}-recorte.jpg`)
      marcar()
      const dx = r.x - planta.off.x
      const dy = r.y - planta.off.y
      mudarPav((p) => {
        if (!p.planta) return
        p.kps.forEach((k) => { k.x -= dx; k.y -= dy })
        p.planta.salas = p.planta.salasOrig.map((s) => ({ ...s, x: s.x - r.x, y: s.y - r.y })).filter((s) => s.x >= 0 && s.y >= 0 && s.x <= r.W && s.y <= r.H)
        p.planta.img = url
        p.planta.W = r.W
        p.planta.H = r.H
        p.planta.off = { x: r.x, y: r.y }
      })
      setCrop(null)
    } catch (err) {
      alert(err instanceof Error ? err.message : "Não consegui recortar.")
    } finally {
      setOcupado("")
    }
  }

  /* -------- Projetos: adicionar linha (planta nova ou planilha exportada) -------- */
  async function adicionarBlueprint(linha: { categoria: string; nome: string; url: string }) {
    const { versao, lista } = await gravarBlueprint(obraId, linha)
    setObra((ob) => (ob ? { ...ob, projetos_blueprints: lista } : ob))
    return versao
  }

  async function salvarEmProjetos() {
    if (!obra || !todosKps(e).length) return alert("Marque os keypads primeiro.")
    setOcupado("Gerando a planilha…")
    try {
      const blob = await gerarXlsx(e, obra.client_name, produto)
      setOcupado("Salvando em Projetos…")
      const url = await subirArquivo(blob, `${nomeArquivo("KEYPADS", obra.client_name)}.xlsx`)
      const versao = await adicionarBlueprint({ categoria: "Projeto Controllares", nome: "Estudo de keypads", url })
      setExportado(`Planilha salva em Projetos → Projeto Controllares (${versao}).`)
    } catch (err) {
      alert(err instanceof Error ? err.message : "Não consegui salvar.")
    } finally {
      setOcupado("")
    }
  }

  async function baixarXlsx() {
    if (!obra) return
    const blob = await gerarXlsx(e, obra.client_name, produto)
    const a = document.createElement("a")
    a.href = URL.createObjectURL(blob)
    a.download = `${nomeArquivo("KEYPADS", obra.client_name)}.xlsx`
    a.click()
  }

  async function classificarSetores() {
    const ambs = [...new Set(todosKps(e).map((k) => k.amb).filter(Boolean))]
    if (!ambs.length) return
    setIa("rodando")
    const r = await fetch(`/api/obras/${obraId}/setores`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ambientes: ambs }) }).catch(() => null)
    const j = r ? await r.json().catch(() => ({})) : {}
    if (!r?.ok) return setIa(j.error || "A IA não respondeu agora.")
    mudar((n) => { n.setores = { ...n.setores, ...(j.setores ?? {}) } })
    setIa("")
  }

  /* -------- KP: criar, editar, apagar -------- */
  function novoKp(x: number, y: number) {
    const kp = proximoKp(e)
    const id = novoId()
    const ult = P.kps[P.kps.length - 1]
    const amb = planta ? salasPerto(planta.salas, x, y, 1)[0] ?? "" : ""
    const antes = structuredClone(P.kps)
    marcar()
    mudarPav((p) => p.kps.push({ id, kp, x, y, med: ult?.med ?? "4X2", amb, acab: ult?.acab ?? "PADRÃO", obs: "" }))
    setSel(id)
    setDlg({ id, novo: true, antes })
  }

  /* -------- teclado: Delete apaga, Esc solta, Ctrl+Z desfaz -------- */
  useEffect(() => {
    const h = (ev: KeyboardEvent) => {
      const alvo = ev.target instanceof Element ? ev.target : null
      if (dlg || crop || escolher || alvo?.closest("input, textarea, select, [contenteditable=true]")) return
      if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === "z") {
        const v = hist.current.pop()
        if (v) { ev.preventDefault(); setE(v) }
      } else if ((ev.key === "Delete" || ev.key === "Backspace") && sel && vista === "planta") {
        ev.preventDefault()
        marcar()
        mudarPav((p) => { p.kps = p.kps.filter((k) => k.id !== sel) })
        setSel(null)
      } else if (ev.key === "Escape") setSel(null)
    }
    window.addEventListener("keydown", h)
    return () => window.removeEventListener("keydown", h)
  }, [dlg, crop, escolher, sel, vista, marcar, mudarPav])

  /* -------- render -------- */
  if (erro) return <div className="p-6 text-sm text-destructive">{erro}</div>
  if (!obra) return <div className="p-10 grid place-items-center text-muted-foreground"><Loader2 className="w-5 h-5 animate-spin" /></div>

  const avisos = conferencia(e, pav, produto)
  const kpDlg = dlg ? P.kps.find((k) => k.id === dlg.id) : undefined

  return (
    <div className="p-3 sm:p-4 space-y-3">
      {/* Cabeçalho */}
      <div className="ios-card flex flex-wrap items-center justify-between gap-3 p-4">
        <div className="flex min-w-[12rem] flex-1 basis-0 items-center gap-3">
          <Link href={`/obras/${obraId}?tab=engenharia&sub=projetos`} className="grid size-10 shrink-0 place-items-center rounded-full bg-foreground/[0.06] hover:bg-foreground/[0.1]" title="Voltar para Projetos">
            <ArrowLeft className="size-[18px]" />
          </Link>
          <div className="min-w-0">
            <h1 className="truncate text-[20px] font-semibold leading-tight tracking-tight">Estudo de keypads</h1>
            <p className="truncate text-[13px] text-muted-foreground">
              {obra.client_name} · Projeto Controllares
              {salvo === "salvando" ? " · salvando…" : salvo === "ok" ? " · salvo" : ""}
            </p>
          </div>
        </div>
        <div className="grid grid-cols-2 rounded-xl bg-foreground/[0.06] p-1">
          {(["planta", "planilha"] as const).map((v) => (
            <button key={v} onClick={() => setVista(v)}
              className={`rounded-lg px-4 py-1.5 text-[13px] font-medium transition-all ${vista === v ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"}`}>
              {v === "planta" ? "Planta" : "Planilha"}
            </button>
          ))}
        </div>
      </div>

      {/* Barra da planta */}
      <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-border bg-card p-2.5">
        <select value={pav} onChange={(ev) => { setPav(ev.target.value); setSel(null) }}
          className="h-9 rounded-xl border border-border bg-background px-2.5 text-xs font-semibold">
          {PAVIMENTOS.map((p) => <option key={p}>{p}</option>)}
        </select>
        <div className="min-w-[50%] flex-1 px-1 sm:min-w-0">
          <p className="truncate text-sm font-medium">{planta ? (P.nome || planta.origem?.nome || "Planta") : "Sem planta neste pavimento"}</p>
          <p className="truncate text-xs text-muted-foreground">
            {planta ? (planta.salas.length ? `${new Set(planta.salas.map((s) => s.n)).size} nomes de ambiente lidos da planta` : "Planta sem nomes escritos: digite o ambiente de cada KP") : "Escolha a planta em Projetos ou suba do computador"}
          </p>
        </div>
        <Button size="sm" variant="outline" onClick={() => setEscolher(true)}><MapIcon className="size-4" />{planta ? "Trocar planta" : "Escolher planta"}</Button>
        {planta && <Button size="sm" variant="outline" onClick={() => abrirRecorte()}><Crop className="size-4" />Recortar</Button>}
        <Button size="sm" onClick={salvarEmProjetos} disabled={!todosKps(e).length}><Save className="size-4" />Salvar em Projetos</Button>
      </div>
      {exportado && (
        <div className="flex items-center gap-2 rounded-xl bg-foreground/[0.05] px-3 py-2 text-sm"><Check className="size-4" />{exportado}
          <button className="ml-auto text-muted-foreground" onClick={() => setExportado("")}><X className="size-4" /></button></div>
      )}

      {vista === "planta" ? (
        <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_290px]">
          <Palco
            planta={planta} kps={P.kps} sel={sel} esboco={e.esboco} pip={pip} setPip={setPip}
            onClique={(x, y) => planta && novoKp(x, y)}
            onAbrir={(id) => { setSel(id); setDlg({ id, novo: false, antes: structuredClone(P.kps) }) }}
            onMoverInicio={marcar}
            onMover={(id, x, y) => mudarPav((p) => { const k = p.kps.find((q) => q.id === id); if (k) { k.x = x; k.y = y } })}
            onEscolher={() => setEscolher(true)}
          />
          <Painel
            e={e} pav={pav} kps={P.kps} sel={sel} avisos={avisos} produto={produto} ia={ia}
            onSel={setSel} onAbrir={(id) => setDlg({ id, novo: false, antes: structuredClone(P.kps) })}
            onSetores={classificarSetores} onPip={() => setPip((v) => !v)} pip={pip}
            onEsboco={async (f) => {
              setOcupado("Guardando o esboço…")
              try { const url = await subirArquivo(f, f.name); mudar((n) => { n.esboco = url }); setPip(true) } finally { setOcupado("") }
            }}
          />
        </div>
      ) : (
        <Planilha e={e} obra={obra.client_name} produto={produto} pavAtual={pav} onBaixar={baixarXlsx}
          onEditar={(p, indice, c, v) => { marcar(); mudar((n) => {
            const k = n.pavs[p].kps[indice]
            if (c === "teclas" || c === "puls") k[c] = Math.max(0, parseInt(String(v)) || 0)
            else if (c === "kp") k.kp = normalizaKp(String(v))
            else (k as unknown as Record<string, string>)[c] = String(v).toUpperCase()
          }) }}
        />
      )}

      {/* Escolher planta */}
      <Dialog open={escolher} onOpenChange={setEscolher}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Planta do pavimento {pav.toLowerCase()}</DialogTitle></DialogHeader>
          <EscolherPlanta obra={obra} onEscolher={(b) => abrirPlanta({ url: b.url, nome: b.nome }, { nome: b.nome, url: b.url })} onArquivo={(f) => abrirPlanta(f, null)} />
        </DialogContent>
      </Dialog>

      {/* Recorte */}
      <Dialog open={!!crop} onOpenChange={(v) => !v && setCrop(null)}>
        <DialogContent className="max-w-5xl">
          <DialogHeader><DialogTitle>Recortar a planta</DialogTitle></DialogHeader>
          {crop && <Recorte img={src(crop.orig.img)} f={crop.f} onMudar={(f) => setCrop({ ...crop, f })}
            onAuto={async () => setCrop({ ...crop, f: await acharPlanta(src(crop.orig.img)) })}
            onCancelar={() => setCrop(null)} onAplicar={() => aplicarRecorte(crop.f)} />}
        </DialogContent>
      </Dialog>

      {/* KP */}
      <Dialog open={!!dlg && !!kpDlg} onOpenChange={(v) => {
        if (!v && dlg) { if (dlg.novo) mudarPav((p) => { p.kps = dlg.antes }); setDlg(null) }
      }}>
        <DialogContent className="max-w-lg">
          {dlg && kpDlg && (
            <JanelaKp
              kp={kpDlg} novo={dlg.novo} produtos={produtos}
              sugestoes={[...new Set([kpDlg.amb, ...(planta ? salasPerto(planta.salas, kpDlg.x, kpDlg.y) : []), ...ambObra].filter(Boolean))].slice(0, 6)}
              temSalas={!!planta?.salas.length}
              onSalvar={(k) => {
                if (!dlg.novo) marcar()
                mudarPav((p) => { const i = p.kps.findIndex((q) => q.id === dlg.id); if (i >= 0) p.kps[i] = k })
                setSel(k.id)
                setDlg(null)
              }}
              onApagar={() => { if (!dlg.novo) marcar(); mudarPav((p) => { p.kps = dlg.novo ? dlg.antes : p.kps.filter((q) => q.id !== dlg.id) }); setSel(null); setDlg(null) }}
              onCancelar={() => { if (dlg.novo) mudarPav((p) => { p.kps = dlg.antes }); setDlg(null) }}
            />
          )}
        </DialogContent>
      </Dialog>

      {ocupado && (
        <div className="fixed inset-0 z-[60] grid place-items-center bg-black/20 backdrop-blur-[2px]">
          <div className="flex items-center gap-2 rounded-2xl bg-card px-4 py-3 text-sm shadow-lg"><Loader2 className="size-4 animate-spin" />{ocupado}</div>
        </div>
      )}
    </div>
  )
}

/* ================= Palco: planta + KPs ================= */
function Palco(props: {
  planta: PlantaPav | null; kps: Keypad[]; sel: string | null; esboco: string | null; pip: boolean; setPip: (v: boolean) => void
  onClique: (x: number, y: number) => void; onAbrir: (id: string) => void; onMover: (id: string, x: number, y: number) => void; onMoverInicio: () => void; onEscolher: () => void
}) {
  const { planta, kps, sel } = props
  const svgRef = useRef<SVGSVGElement>(null)
  const [vb, setVb] = useState({ x: 0, y: 0, w: 1000, h: 700 })
  const arr = useRef<{ kp: string | null; x0: number; y0: number; p0: [number, number]; vb0: typeof vb; mov: boolean } | null>(null)

  const ajustar = useCallback(() => {
    const el = svgRef.current
    if (!planta || !el) return
    const r = el.getBoundingClientRect()
    const a = planta.W / planta.H, b = r.width / Math.max(1, r.height)
    if (b > a) { const w = planta.H * b; setVb({ x: -(w - planta.W) / 2, y: 0, w, h: planta.H }) }
    else { const h = planta.W / b; setVb({ x: 0, y: -(h - planta.H) / 2, w: planta.W, h }) }
  }, [planta])
  useEffect(() => { ajustar() }, [ajustar, planta?.img])
  useEffect(() => { const f = () => ajustar(); window.addEventListener("resize", f); return () => window.removeEventListener("resize", f) }, [ajustar])

  const pos = (ev: { clientX: number; clientY: number }): [number, number] => {
    const el = svgRef.current!
    const pt = el.createSVGPoint()
    pt.x = ev.clientX
    pt.y = ev.clientY
    const q = pt.matrixTransform(el.getScreenCTM()!.inverse())
    return [q.x, q.y]
  }
  const limita = (v: typeof vb) => planta ? { ...v, x: Math.min(planta.W - v.w / 2, Math.max(-v.w / 2, v.x)), y: Math.min(planta.H - v.h / 2, Math.max(-v.h / 2, v.y)) } : v
  const zoom = (f: number, cx?: number, cy?: number) => setVb((v) => {
    if (!planta) return v
    const nw = Math.min(planta.W * 1.15, Math.max(planta.W / 14, v.w * f)), k = nw / v.w
    const x = cx ?? v.x + v.w / 2, y = cy ?? v.y + v.h / 2
    return limita({ x: x - (x - v.x) * k, y: y - (y - v.y) * k, w: v.w * k, h: v.h * k })
  })

  useEffect(() => {
    const el = svgRef.current
    if (!el) return
    const h = (ev: WheelEvent) => roda(ev, (f) => { const [x, y] = pos(ev); zoom(f, x, y) }, (dx, dy) => setVb((v) => {
      const f = v.w / el.getBoundingClientRect().width
      return limita({ ...v, x: v.x + dx * f, y: v.y + dy * f })
    }))
    el.addEventListener("wheel", h, { passive: false })
    return () => el.removeEventListener("wheel", h)
  })

  if (!planta) {
    return (
      <div className="grid min-h-[60vh] place-items-center rounded-2xl border border-dashed border-border bg-card p-6 text-center">
        <div className="space-y-3">
          <MapIcon className="mx-auto size-8 text-muted-foreground" />
          <p className="font-medium">Sem planta neste pavimento</p>
          <p className="text-sm text-muted-foreground">Use um arquivo que já está em Projetos ou suba do computador.</p>
          <Button onClick={props.onEscolher}>Escolher planta</Button>
        </div>
      </div>
    )
  }

  // Tamanho pela planta, mas nunca menor que ~7 px na tela (no celular a planta inteira cabe em 350 px)
  const pxTela = vb.w / (svgRef.current?.getBoundingClientRect().width || 800)
  const R = Math.max(9, planta.W / 170, 7 * pxTela), F = R * 1.05
  return (
    <div className="relative overflow-hidden rounded-2xl border border-border bg-white">
      <svg ref={svgRef} viewBox={`${vb.x} ${vb.y} ${vb.w} ${vb.h}`} className="block h-[62vh] w-full cursor-crosshair touch-none select-none lg:h-[calc(100vh-250px)]"
        onPointerDown={(ev) => {
          if (ev.button !== 0) return
          const g = (ev.target as Element).closest("[data-k]")
          arr.current = { kp: g?.getAttribute("data-k") ?? null, x0: ev.clientX, y0: ev.clientY, p0: pos(ev), vb0: vb, mov: false }
          ;(ev.currentTarget as Element).setPointerCapture(ev.pointerId)
        }}
        onPointerMove={(ev) => {
          const a = arr.current
          if (!a) return
          if (!a.mov && Math.hypot(ev.clientX - a.x0, ev.clientY - a.y0) < 5) return
          if (!a.mov && a.kp) props.onMoverInicio()
          a.mov = true
          if (a.kp) { const [x, y] = pos(ev); props.onMover(a.kp, x, y) }
          else {
            const f = a.vb0.w / svgRef.current!.getBoundingClientRect().width
            setVb(limita({ ...a.vb0, x: a.vb0.x - (ev.clientX - a.x0) * f, y: a.vb0.y - (ev.clientY - a.y0) * f }))
          }
        }}
        onPointerUp={() => {
          const a = arr.current
          arr.current = null
          if (!a || a.mov) return
          if (a.kp) return props.onAbrir(a.kp)
          const [x, y] = a.p0
          if (x >= 0 && y >= 0 && x <= planta.W && y <= planta.H) props.onClique(x, y)
        }}>
        <image href={src(planta.img)} x={0} y={0} width={planta.W} height={planta.H} style={{ filter: "grayscale(1)", opacity: 0.5 }} />
        {kps.map((k) => {
          const on = sel === k.id, cor = !k.med || !k.amb ? "#b45309" : "#1d1d1f"
          return (
            <g key={k.id} data-k={k.id} style={{ cursor: "pointer" }}>
              <circle cx={k.x} cy={k.y} r={R * 1.9} fill="transparent" />
              <circle cx={k.x} cy={k.y} r={R} fill={cor} stroke={on ? "#f59e0b" : "#fff"} strokeWidth={on ? R * 0.45 : R * 0.22} />
              <text x={k.x + R * 1.4} y={k.y - R * 0.15} fontSize={F} fontWeight={700} fill={cor} fontFamily="Helvetica,Arial" paintOrder="stroke" stroke="#fff" strokeWidth={F * 0.3}>{k.kp}</text>
              <text x={k.x + R * 1.4} y={k.y + F * 0.95} fontSize={F * 0.8} fill="#374151" fontFamily="Helvetica,Arial" paintOrder="stroke" stroke="#fff" strokeWidth={F * 0.3}>{k.med || "medida?"}</text>
            </g>
          )
        })}
      </svg>
      {props.pip && props.esboco && <Esboco url={props.esboco} onFechar={() => props.setPip(false)} />}
      <div className="absolute right-3 top-3 flex flex-col gap-0.5 rounded-2xl border border-border bg-card p-1 shadow-md">
        <button className="grid size-8 place-items-center rounded-lg hover:bg-muted" onClick={() => zoom(1 / 1.4)} title="Aproximar"><Plus className="size-4" /></button>
        <button className="grid size-8 place-items-center rounded-lg hover:bg-muted" onClick={() => zoom(1.4)} title="Afastar"><Minus className="size-4" /></button>
        <button className="grid size-8 place-items-center rounded-lg hover:bg-muted" onClick={ajustar} title="Planta inteira"><Maximize2 className="size-4" /></button>
      </div>
      <div className="pointer-events-none absolute bottom-3 left-3 rounded-full bg-[#1d1d1f]/85 px-3.5 py-1.5 text-xs text-white">
        <b className="underline underline-offset-2">Clique</b> onde fica o keypad <span className="opacity-60">· arraste para andar</span>
      </div>
    </div>
  )
}

/* Esboço flutuante por cima da planta */
function Esboco({ url, onFechar }: { url: string; onFechar: () => void }) {
  const [z, setZ] = useState(1)
  const [p, setP] = useState({ x: 12, y: 12 })
  const arr = useRef<{ x: number; y: number; l: number; t: number } | null>(null)
  return (
    <div className="absolute z-10 flex h-[60%] w-[min(46%,560px)] min-w-[240px] resize flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-2xl" style={{ left: p.x, top: p.y }}>
      <div className="flex cursor-move items-center gap-1 border-b border-border px-3 py-1.5 text-[13px] touch-none"
        onPointerDown={(ev) => { if ((ev.target as Element).closest("button")) return; arr.current = { x: ev.clientX, y: ev.clientY, l: p.x, t: p.y }; (ev.currentTarget as Element).setPointerCapture(ev.pointerId) }}
        onPointerMove={(ev) => { const a = arr.current; if (a) setP({ x: Math.max(0, a.l + ev.clientX - a.x), y: Math.max(0, a.t + ev.clientY - a.y) }) }}
        onPointerUp={() => { arr.current = null }}>
        <b className="font-semibold">Esboço</b><span className="ml-1 text-xs text-muted-foreground">arraste aqui</span>
        <span className="flex-1" />
        <button className="grid size-7 place-items-center rounded-lg hover:bg-muted" onClick={() => setZ((v) => Math.max(1, v / 1.3))}><Minus className="size-3.5" /></button>
        <button className="grid size-7 place-items-center rounded-lg hover:bg-muted" onClick={() => setZ((v) => Math.min(6, v * 1.3))}><Plus className="size-3.5" /></button>
        <button className="grid size-7 place-items-center rounded-lg hover:bg-muted" onClick={onFechar}><X className="size-3.5" /></button>
      </div>
      <div className="flex-1 overflow-auto bg-muted/40">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={src(url)} alt="Esboço" draggable={false} style={{ width: `${z * 100}%` }} className="block select-none" />
      </div>
    </div>
  )
}

/* ================= Painel lateral ================= */
function Painel(props: {
  e: EstudoKeypads; pav: string; kps: Keypad[]; sel: string | null; avisos: ReturnType<typeof conferencia>
  produto: (sku?: string) => ProdutoKeypad | undefined; ia: string; pip: boolean
  onSel: (id: string) => void; onAbrir: (id: string) => void; onSetores: () => void; onPip: () => void; onEsboco: (f: File) => void
}) {
  const { e, kps, produto } = props
  const n = (m: string) => kps.filter((k) => k.med === m).length
  const sm = kps.filter((k) => !k.med).length
  const grupos: Record<string, Keypad[]> = {}
  ;[...kps].sort((a, b) => (kpNum(a.kp) ?? 0) - (kpNum(b.kp) ?? 0)).forEach((k) => (grupos[k.amb || "SEM AMBIENTE"] ??= []).push(k))
  return (
    <aside className="space-y-3 lg:max-h-[calc(100vh-250px)] lg:overflow-auto">
      <section className="rounded-2xl border border-border bg-card p-3.5">
        <div className="mb-2.5 flex items-center justify-between">
          <span className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Esboço</span>
          <label className="cursor-pointer rounded-lg px-2 py-0.5 text-xs text-muted-foreground hover:bg-muted">{e.esboco ? "Trocar" : "Subir"}
            <input type="file" accept="image/*" hidden onChange={(ev) => { const f = ev.target.files?.[0]; if (f) props.onEsboco(f); ev.target.value = "" }} />
          </label>
        </div>
        {e.esboco ? (
          <button onClick={props.onPip} className={`relative block aspect-[16/10] w-full overflow-hidden rounded-xl bg-muted ${props.pip ? "ring-2 ring-foreground ring-offset-2" : ""}`}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={src(e.esboco)} alt="Esboço" className="h-full w-full object-cover" />
            <span className={`absolute bottom-2 left-2 inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold shadow ${props.pip ? "bg-foreground text-background" : "bg-white/90 text-[#1d1d1f]"}`}>
              {props.pip ? <><X className="size-3.5" />Fechar da planta</> : <><Maximize2 className="size-3.5" />Abrir sobre a planta</>}
            </span>
          </button>
        ) : (
          <p className="rounded-xl border border-dashed border-border p-3 text-center text-xs text-muted-foreground"><ImageIcon className="mx-auto mb-1 size-5" />Foto do esboço à mão (opcional), para copiar os KPs.</p>
        )}
      </section>

      <section className="rounded-2xl border border-border bg-card p-3.5">
        <div className="mb-2.5 flex items-center justify-between">
          <span className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Keypads</span>
          <span className="rounded-full bg-foreground/[0.05] px-2 py-0.5 text-[11px] text-muted-foreground">{nomeAba(props.pav)}</span>
        </div>
        <div className="mb-3 grid grid-cols-4 gap-1.5">
          {[["Total", kps.length], ...MEDIDAS.map((m) => [m, n(m)])].map(([l, v], i) => (
            <div key={String(l)} className={`flex flex-col items-center rounded-xl py-2 ${i === 0 ? "bg-foreground text-background" : "bg-foreground/[0.04]"}`}>
              <b className="text-lg font-semibold leading-tight">{v}</b>
              <span className={`text-[10px] font-medium uppercase ${i === 0 ? "opacity-70" : "text-muted-foreground"}`}>{l}</span>
            </div>
          ))}
          {sm > 0 && <div className="col-span-4 rounded-xl bg-destructive/10 py-1.5 text-center text-xs text-destructive"><b>{sm}</b> sem medida</div>}
        </div>
        {kps.length ? (
          <div className="max-h-[330px] space-y-2.5 overflow-auto">
            {Object.entries(grupos).map(([amb, l]) => (
              <div key={amb} className="space-y-1">
                <div className="flex justify-between px-1 text-[11px] font-semibold text-muted-foreground"><span>{amb}</span><span>{l.length}</span></div>
                {l.map((k) => {
                  const p = produto(k.sku)
                  return (
                    <button key={k.id} onClick={() => props.onSel(k.id)} onDoubleClick={() => props.onAbrir(k.id)}
                      className={`flex w-full items-center gap-2 rounded-xl border px-2 py-1.5 text-left text-[12.5px] ${props.sel === k.id ? "border-foreground bg-card" : "border-transparent bg-foreground/[0.03] hover:bg-foreground/[0.06]"}`}>
                      <span className="shrink-0 rounded-md bg-foreground px-1.5 py-0.5 text-xs font-semibold text-background">{k.kp}</span>
                      <span className="min-w-0 flex-1 truncate">{p ? `${p.marca} · ${p.nome}` : <span className="text-muted-foreground">{k.acab || "Padrão"}</span>}</span>
                      <span className={`shrink-0 rounded-md border px-1.5 text-[11px] font-semibold ${k.med ? "border-border" : "border-destructive/30 bg-destructive/10 text-destructive"}`}>{k.med || "medida?"}</span>
                    </button>
                  )
                })}
              </div>
            ))}
          </div>
        ) : (
          <div className="rounded-xl border border-dashed border-border p-4 text-center text-xs text-muted-foreground"><b className="block text-sm text-foreground">Nenhum keypad ainda</b>Clique na planta onde fica o primeiro.</div>
        )}
      </section>

      <section className="rounded-2xl border border-border bg-card p-3.5">
        <span className="mb-2.5 block text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Conferência</span>
        <div className="space-y-1.5">
          {props.avisos.length ? props.avisos.map((a, i) => (
            <div key={i} className={`relative rounded-xl py-2 pl-7 pr-2.5 text-[12.5px] ${a.tipo === "erro" ? "bg-destructive/10 text-destructive" : "bg-foreground/[0.04]"}`}>
              <span className={`absolute left-2.5 top-3 size-2 rounded-full ${a.tipo === "erro" ? "bg-destructive" : a.tipo === "ok" ? "bg-foreground" : "bg-muted-foreground"}`} />
              {a.texto}{a.detalhe && <small className="mt-0.5 block text-[11px] opacity-75">{a.detalhe}</small>}
            </div>
          )) : <p className="text-xs text-muted-foreground">Marque os keypads para conferir.</p>}
          {props.ia && props.ia !== "rodando" && <div className="rounded-xl bg-destructive/10 px-2.5 py-2 text-xs text-destructive">{props.ia}</div>}
          {Object.keys(e.setores).length > 0 && (
            <div className="rounded-xl bg-foreground/[0.04] px-2.5 py-2 text-[12px]">Setores pela IA: {Object.entries(e.setores).map(([a, s]) => `${a}: ${s}`).join(" · ")}</div>
          )}
        </div>
        <Button variant="outline" size="sm" className="mt-2.5 w-full" onClick={props.onSetores} disabled={!kps.length || props.ia === "rodando"}>
          {props.ia === "rodando" ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}Classificar setores com IA
        </Button>
      </section>
    </aside>
  )
}

/* ================= Janela do KP ================= */
function JanelaKp(props: {
  kp: Keypad; novo: boolean; produtos: ProdutoKeypad[]; sugestoes: string[]; temSalas: boolean
  onSalvar: (k: Keypad) => void; onApagar: () => void; onCancelar: () => void
}) {
  const [k, setK] = useState<Keypad>(props.kp)
  const [busca, setBusca] = useState("")
  const [marca, setMarca] = useState("Todas")
  const p = props.produtos.find((x) => x.sku === k.sku)
  const marcas = useMemo(() => ["Todas", ...new Set(props.produtos.map((x) => x.marca))], [props.produtos])
  const lista = useMemo(() => {
    const t = busca.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").split(/\s+/).filter(Boolean)
    return props.produtos
      .filter((x) => (marca === "Todas" || x.marca === marca) && t.every((w) => `${x.sku} ${x.marca} ${x.nome} ${x.nomeCliente}`.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").includes(w)))
      .sort((a, b) => Number(b.daObra) - Number(a.daObra))
  }, [busca, marca, props.produtos])
  const escolher = (x: ProdutoKeypad) => {
    const cor = corDoNome(`${x.nome} ${x.nomeCliente}`), med = medidaDoNome(`${x.nome} ${x.nomeCliente}`)
    setK((v) => ({ ...v, sku: x.sku, acab: cor || v.acab, med: (MEDIDAS as readonly string[]).includes(med) ? med : v.med }))
  }
  const chip = (on: boolean) => `rounded-full border px-3 py-1 text-[12.5px] font-medium ${on ? "border-foreground bg-foreground text-background" : "border-border bg-card hover:bg-muted"}`
  return (
    <form className="space-y-4" onSubmit={(ev) => { ev.preventDefault(); props.onSalvar({ ...k, kp: normalizaKp(k.kp) || props.kp.kp, amb: k.amb.trim().toUpperCase() }) }}>
      <DialogHeader>
        <DialogTitle>{props.novo ? "Novo keypad" : "Keypad"} {props.kp.kp}</DialogTitle>
        <p className="text-xs text-muted-foreground">{props.temSalas ? "Ambiente sugerido pelo nome escrito mais perto na planta. Confira." : "Esta planta não tem nomes escritos: digite o ambiente."}</p>
      </DialogHeader>
      <div className="grid grid-cols-[110px_1fr] gap-3">
        <label className="space-y-1 text-xs font-medium text-muted-foreground">Número<Input value={k.kp} onChange={(ev) => setK({ ...k, kp: ev.target.value })} /></label>
        <div className="space-y-1 text-xs font-medium text-muted-foreground">Medida da caixa
          <div className="flex gap-1.5">{MEDIDAS.map((m) => <button type="button" key={m} className={chip(k.med === m)} onClick={() => setK({ ...k, med: m })}>{m}</button>)}</div>
        </div>
      </div>
      <div className="space-y-1.5 text-xs font-medium text-muted-foreground">Ambiente
        {props.sugestoes.length > 0 && <div className="flex flex-wrap gap-1.5">{props.sugestoes.map((s) => <button type="button" key={s} className={chip(k.amb === s)} onClick={() => setK({ ...k, amb: s })}>{s}</button>)}</div>}
        <Input value={k.amb} placeholder="ex.: SUÍTE 02" onChange={(ev) => setK({ ...k, amb: ev.target.value.toUpperCase() })} />
      </div>
      <div className="space-y-1.5 text-xs font-medium text-muted-foreground">Modelo do catálogo <span className="font-normal opacity-70">· opcional, já acerta acabamento e medida</span>
        {p ? (
          <div className="flex items-center gap-2.5 rounded-xl border border-foreground p-2 text-foreground">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            {p.img ? <img src={proxiedImg(p.img)} alt="" className="size-9 rounded-lg bg-muted object-contain" /> : <span className="size-9 rounded-lg bg-muted" />}
            <div className="min-w-0 flex-1"><b className="block truncate text-[13px] font-semibold">{p.marca} · {p.nome}</b><span className="text-[11px] text-muted-foreground">{p.nomeCliente} · {p.sku}</span></div>
            <button type="button" className="grid size-7 place-items-center rounded-lg hover:bg-muted" onClick={() => setK({ ...k, sku: undefined })}><X className="size-4" /></button>
          </div>
        ) : (
          <div className="space-y-2">
            <Input value={busca} onChange={(ev) => setBusca(ev.target.value)} placeholder="Buscar (marca, modelo, 4x2, preto…)"
              onKeyDown={(ev) => { if (ev.key === "Enter") { ev.preventDefault(); if (lista[0]) escolher(lista[0]) } }} />
            <div className="flex flex-wrap gap-1">{marcas.map((m) => <button type="button" key={m} className={chip(marca === m) + " !px-2.5 !py-0.5 text-[11.5px]"} onClick={() => setMarca(m)}>{m}</button>)}</div>
            <div className="max-h-48 overflow-auto rounded-xl border border-border">
              {lista.slice(0, 40).map((x) => (
                <button type="button" key={x.sku} onClick={() => escolher(x)} className="flex w-full items-center gap-2.5 border-b border-border px-2.5 py-1.5 text-left text-[12.5px] text-foreground last:border-0 hover:bg-muted">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  {x.img ? <img src={proxiedImg(x.img)} alt="" loading="lazy" className="size-8 rounded-lg bg-muted object-contain" /> : <span className="size-8 rounded-lg bg-muted" />}
                  <span className="min-w-0 flex-1"><b className="block truncate font-semibold">{x.marca} · {x.nome}</b><span className="text-[11px] text-muted-foreground">{x.nomeCliente}</span></span>
                  {x.daObra && <span className="shrink-0 rounded-full bg-foreground px-2 py-0.5 text-[10px] font-semibold text-background">na proposta</span>}
                </button>
              ))}
              {!lista.length && <p className="p-2.5 text-xs">Nada no catálogo com isso.</p>}
            </div>
          </div>
        )}
      </div>
      <div className="space-y-1.5 text-xs font-medium text-muted-foreground">Acabamento
        <div className="flex flex-wrap gap-1.5">{ACABAMENTOS.map((a) => <button type="button" key={a} className={chip(k.acab === a)} onClick={() => setK({ ...k, acab: a })}>{a}</button>)}</div>
      </div>
      <label className="block space-y-1 text-xs font-medium text-muted-foreground">Observação<Input value={k.obs} placeholder="ex.: ao lado da porta, teclas de cortina" onChange={(ev) => setK({ ...k, obs: ev.target.value })} /></label>
      <div className="flex items-center gap-2 border-t border-border pt-3">
        <Button type="button" variant="ghost" className="text-destructive" onClick={props.onApagar}>{props.novo ? "Descartar" : "Apagar"}</Button>
        <span className="flex-1" />
        <Button type="button" variant="outline" onClick={props.onCancelar}>Cancelar</Button>
        <Button type="submit">Salvar</Button>
      </div>
    </form>
  )
}

/* ================= Planilha (prévia com cara de Excel) ================= */
function Planilha({ e, obra, produto, pavAtual, onBaixar, onEditar }: {
  e: EstudoKeypads; obra: string; produto: (sku?: string) => ProdutoKeypad | undefined; pavAtual: string
  onBaixar: () => void; onEditar: (pav: string, indice: number, c: Coluna, v: string) => void
}) {
  const pavs = pavsComKp(e)
  const [aba, setAba] = useState<string>(pavs.includes(pavAtual) ? pavAtual : pavs[0] ?? "Resumo")
  // Enquanto a planilha está aberta a ordem das linhas fica parada: editar
  // setor ou ambiente não faz a linha pular. Reordena ao sair e voltar.
  const ordem = useRef<Record<string, string[]>>({})
  const letras = "ABCDEFGHIJKLMNOP"
  const td = todosKps(e)
  if (!pavs.length) return <div className="rounded-2xl border border-border bg-card p-10 text-center text-sm text-muted-foreground">Marque keypads na planta para a planilha aparecer aqui.</div>
  const cel = "border border-[#e1e3e6] px-1.5 h-[22px] whitespace-nowrap overflow-hidden text-ellipsis"
  const num = "sticky left-0 z-[1] w-[34px] bg-[#f3f3f3] text-center text-[11px] text-[#666] border border-[#e1e3e6]"
  return (
    <div className="flex flex-col overflow-hidden rounded-2xl border border-border bg-card">
      <div className="flex flex-wrap items-center gap-3 border-b border-border p-3">
        <span className="grid size-9 place-items-center rounded-lg bg-[#1d6f42] text-white"><FileSpreadsheet className="size-5" /></span>
        <div className="min-w-0 flex-1"><b className="block text-sm font-semibold">Planilha de keypads</b><span className="text-xs text-muted-foreground">{td.length} keypads · {pavs.length} pavimento{pavs.length === 1 ? "" : "s"} · clique numa célula para editar · amarelo = conferir</span></div>
        <Button size="sm" variant="outline" onClick={onBaixar}>Baixar .xlsx</Button>
      </div>
      <div className="max-h-[calc(100vh-330px)] min-h-[300px] overflow-auto bg-white text-[#111]" style={{ font: "12.5px/1.35 Calibri, Carlito, 'Segoe UI', Arial, sans-serif" }}>
        {aba === "Resumo" ? (
          <table className="border-collapse">
            <tbody>
              <tr><td className={num}>1</td><td colSpan={2 + pavs.length} className="px-1.5 py-1 text-[15px] font-bold">RESUMO DE KEYPADS</td></tr>
              <tr><td className={num}>2</td><td colSpan={2 + pavs.length} className="px-1.5 text-[11.5px] text-[#6b7280]">{obra}</td></tr>
              <tr className="bg-[#1f2328] text-center text-[11.5px] font-bold text-white"><td className={num}>4</td><td className={cel + " w-[173px]"}>MEDIDA</td>{pavs.map((p) => <td key={p} className={cel + " w-[89px]"}>{p}</td>)}<td className={cel + " w-[89px]"}>TOTAL</td></tr>
              {[...MEDIDAS, ""].map((m, i) => (
                <tr key={m}><td className={num}>{5 + i}</td><td className={cel}>{m || "(sem medida)"}</td>
                  {pavs.map((p) => <td key={p} className={cel + " text-center"}>{e.pavs[p].kps.filter((k) => (k.med || "") === m).length}</td>)}
                  <td className={cel + " text-center"}>{td.filter((k) => (k.med || "") === m).length}</td></tr>
              ))}
              <tr className="font-bold"><td className={num}>9</td><td className={cel}>TOTAL KEYPADS</td>{pavs.map((p) => <td key={p} className={cel + " text-center"}>{e.pavs[p].kps.length}</td>)}<td className={cel + " text-center"}>{td.length}</td></tr>
            </tbody>
          </table>
        ) : (() => {
          const base = linhasDoPav(e, aba, produto)
          ordem.current[aba] ??= base.map((l) => l.k.id)
          const pos = (id: string) => { const i = ordem.current[aba].indexOf(id); return i < 0 ? 1e9 : i }
          let faixa = false, ant: string | null = null
          const L = [...base].sort((x, y) => pos(x.k.id) - pos(y.k.id)).map((l) => {
            if (l.k.amb !== ant) { faixa = !faixa; ant = l.k.amb }
            return { ...l, faixa }
          })
          return (
            <table className="border-collapse" style={{ tableLayout: "fixed" }}>
              <colgroup><col style={{ width: 34 }} />{COLUNAS.map((c) => <col key={c[2]} style={{ width: c[1] * 7 + 5 }} />)}</colgroup>
              <thead><tr className="sticky top-0 z-[2] bg-[#f3f3f3] text-center text-[11px] font-normal text-[#666]"><th className="border border-[#e1e3e6]" />{COLUNAS.map((c, i) => <th key={c[2]} className="border border-[#e1e3e6] font-normal">{letras[i]}</th>)}</tr></thead>
              <tbody>
                <tr><td className={num}>1</td><td colSpan={COLUNAS.length} className="px-1.5 py-1 text-[15px] font-bold">KEYPADS · PAVIMENTO {aba}</td></tr>
                <tr><td className={num}>2</td><td colSpan={COLUNAS.length} className="px-1.5 text-[11.5px] text-[#6b7280]">{obra} · Linhas em amarelo: conferir no esboço</td></tr>
                <tr><td className={num}>3</td><td colSpan={COLUNAS.length} /></tr>
                <tr className="bg-[#1f2328] text-center text-[11px] font-bold text-white"><td className={num}>4</td>{COLUNAS.map((c) => <td key={c[2]} className="h-[38px] border border-[#3a3f45] px-1 whitespace-normal">{c[0]}</td>)}</tr>
                {L.map((l, i) => (
                  <tr key={l.k.id} className={l.conferir ? "bg-[#fff2cc]" : l.faixa ? "" : "bg-[#f3f4f6]"}>
                    <td className={num}>{5 + i}</td>
                    {COLUNAS.map((c) => {
                      const ed = (EDITAVEIS as string[]).includes(c[2])
                      const centro = ["kp", "med", "teclas", "puls"].includes(c[2])
                      return (
                        <td key={c[2]} className={`${cel} ${centro ? "text-center" : ""} ${ed ? "focus:bg-white focus:outline focus:outline-2 focus:outline-[#1d6f42] focus:whitespace-normal" : ""}`}
                          contentEditable={ed} suppressContentEditableWarning
                          onKeyDown={(ev) => { if (ev.key === "Enter") { ev.preventDefault(); (ev.target as HTMLElement).blur() } }}
                          onBlur={(ev) => { const v = ev.currentTarget.textContent?.trim() ?? ""; if (ed && String(valor(l, c[2], produto)) !== v) onEditar(aba, l.indice, c[2], v) }}>
                          {valor(l, c[2], produto)}
                        </td>
                      )
                    })}
                  </tr>
                ))}
                <tr><td className={num}>{5 + L.length}</td><td colSpan={COLUNAS.length} /></tr>
                <tr className="font-bold"><td className={num}>{6 + L.length}</td><td className={cel} /><td className={cel}>TOTAL</td><td className={cel + " text-center"}>{L.length}</td><td className={cel} /><td className={cel} /><td className={cel} /><td className={cel} />
                  <td className={cel + " text-center"}>{L.reduce((s, l) => s + (Number(valor(l, "teclas", produto)) || 0), 0)}</td>
                  <td className={cel + " text-center"}>{L.reduce((s, l) => s + (Number(valor(l, "puls", produto)) || 0), 0)}</td><td className={cel} /><td className={cel} /></tr>
              </tbody>
            </table>
          )
        })()}
      </div>
      <div className="flex gap-0.5 border-t border-[#e1e3e6] bg-[#f3f3f3] px-2.5">
        {["Resumo", ...pavs].map((a) => (
          <button key={a} onClick={() => setAba(a)} className={`border-b-2 px-4 py-1.5 text-[12.5px] ${aba === a ? "border-[#1d6f42] bg-white font-semibold text-[#1d6f42]" : "border-transparent text-[#555]"}`}>
            {a === "Resumo" ? "Resumo" : nomeAba(a)}
          </button>
        ))}
      </div>
    </div>
  )
}
