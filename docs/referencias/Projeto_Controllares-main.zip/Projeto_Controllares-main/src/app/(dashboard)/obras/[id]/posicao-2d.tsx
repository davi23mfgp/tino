"use client"

/**
 * Posição 2D — planta baixa com marcadores de itens (estilo AutoCAD simplificado).
 * Upload da planta como fundo + itens da obra arrastáveis por cima.
 * Superfície: TETO (azul) ou PAREDE (laranja). Coordenadas em % (responsivo).
 * Salva tudo em Obra.posicoes_2d (JSON) via PATCH.
 */
import { useState, useRef, useEffect, useCallback } from "react"
import { Upload, Plus, Trash2, Save, Check, Map as MapIcon, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { proxiedImg } from "@/lib/img"
import { PageLoader } from "@/components/ui/bouncing-dots"
import { useConfirmar } from "@/components/confirmar"

type Sup = "TETO" | "PAREDE"
interface Marcador { id: string; nome: string; x: number; y: number; sup: Sup; img?: string | null }
// largura_m: largura REAL da planta em metros — habilita as cotas estilo AutoCAD
interface Planta { id: string; nome: string; imagem_url: string; largura_m?: number | null; marcadores: Marcador[] }

interface ItemObra { nome: string; sku?: string | null; imagem_url?: string | null }

const SUP_COR: Record<Sup, { dot: string; ring: string; label: string }> = {
  TETO:   { dot: "bg-ios-blue",   ring: "ring-ios-blue/40",   label: "text-ios-blue" },
  PAREDE: { dot: "bg-ios-orange", ring: "ring-ios-orange/40", label: "text-ios-orange" },
}

export default function Posicao2D({ obraId, itens }: { obraId: string; itens: ItemObra[] }) {
  const confirmar = useConfirmar()
  const [plantas, setPlantas] = useState<Planta[] | null>(null)
  const [ativa, setAtiva] = useState(0)
  const [supNovo, setSupNovo] = useState<Sup>("TETO")
  const [salvando, setSalvando] = useState(false)
  const [salvo, setSalvo] = useState(false)
  const [enviando, setEnviando] = useState(false)
  const [selecionado, setSelecionado] = useState<string | null>(null)
  const [nomeLivre, setNomeLivre] = useState("")
  // Proporção da imagem carregada (altura/largura) — converte escala X em Y
  const [imgRatio, setImgRatio] = useState(0.7)
  const canvasRef = useRef<HTMLDivElement>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const dragRef = useRef<string | null>(null)

  useEffect(() => {
    fetch(`/api/obras/${obraId}`).then(r => r.ok ? r.json() : null).then(d => {
      setPlantas((d?.posicoes_2d as Planta[]) ?? [])
    }).catch(() => setPlantas([]))
  }, [obraId])

  const persistir = useCallback(async (novas: Planta[]) => {
    setSalvando(true)
    try {
      await fetch(`/api/obras/${obraId}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ posicoes_2d: novas }),
      })
      setSalvo(true); setTimeout(() => setSalvo(false), 2500)
    } finally { setSalvando(false) }
  }, [obraId])

  function mutate(fn: (ps: Planta[]) => Planta[], salvar = false) {
    setPlantas(prev => {
      const novas = fn(prev ?? [])
      if (salvar) persistir(novas)
      return novas
    })
  }

  async function uploadPlanta(file: File) {
    setEnviando(true)
    try {
      const fd = new FormData(); fd.append("file", file)
      const r = await fetch("/api/upload", { method: "POST", body: fd })
      const j = await r.json()
      if (!r.ok) { await confirmar({ titulo: j.error || "Falha no upload.", apenasAviso: true }); return }
      mutate(ps => {
        const nova: Planta = { id: crypto.randomUUID(), nome: file.name.replace(/\.[^.]+$/, ""), imagem_url: j.url, marcadores: [] }
        setAtiva(ps.length)
        return [...ps, nova]
      }, true)
    } finally { setEnviando(false) }
  }

  function addMarcador(nome: string, img?: string | null) {
    if (!planta) return
    const m: Marcador = { id: crypto.randomUUID(), nome, x: 50, y: 50, sup: supNovo, img: img ?? null }
    mutate(ps => ps.map((p, i) => i === ativa ? { ...p, marcadores: [...p.marcadores, m] } : p))
    setSelecionado(m.id)
  }

  // Drag por pointer events — coordenadas em % do canvas
  function onPointerMove(e: React.PointerEvent) {
    if (!dragRef.current || !canvasRef.current) return
    const rect = canvasRef.current.getBoundingClientRect()
    const x = Math.min(100, Math.max(0, ((e.clientX - rect.left) / rect.width) * 100))
    const y = Math.min(100, Math.max(0, ((e.clientY - rect.top) / rect.height) * 100))
    const id = dragRef.current
    mutate(ps => ps.map((p, i) => i === ativa
      ? { ...p, marcadores: p.marcadores.map(m => m.id === id ? { ...m, x, y } : m) }
      : p))
  }
  function onPointerUp() {
    if (dragRef.current && plantas) persistir(plantas)
    dragRef.current = null
  }

  if (plantas === null) return <PageLoader message="Carregando plantas..." />
  const planta = plantas[ativa]

  return (
    <div className="space-y-3">
      {/* Barra: plantas + upload + salvar */}
      <div className="flex items-center gap-2 flex-wrap">
        {plantas.map((p, i) => (
          <button key={p.id} onClick={() => { setAtiva(i); setSelecionado(null) }}
            className={`px-3 h-9 rounded-full text-[13px] font-medium border transition-colors flex items-center gap-1.5 ${
              i === ativa ? "bg-ios-blue/10 text-ios-blue border-ios-blue/30" : "bg-surface-2 text-muted-fg border-hairline"
            }`}>
            <MapIcon className="w-3.5 h-3.5" /> {p.nome}
          </button>
        ))}
        <input ref={fileRef} type="file" accept="image/*,.pdf" className="hidden"
          onChange={e => { const f = e.target.files?.[0]; if (f) uploadPlanta(f); e.target.value = "" }} />
        <Button size="sm" variant="outline" onClick={() => fileRef.current?.click()} disabled={enviando} className="h-9 gap-1.5">
          <Upload className="w-3.5 h-3.5" /> {enviando ? "Enviando..." : plantas.length ? "Nova planta" : "Enviar planta"}
        </Button>
        {planta && (
          <div className="ml-auto flex items-center gap-2">
            {salvo && <span className="text-[12px] text-ios-green flex items-center gap-1"><Check className="w-3.5 h-3.5" /> Salvo</span>}
            <Button size="sm" onClick={() => plantas && persistir(plantas)} disabled={salvando} className="h-9 gap-1.5">
              <Save className="w-3.5 h-3.5" /> {salvando ? "Salvando..." : "Salvar"}
            </Button>
          </div>
        )}
      </div>

      {!planta ? (
        <div className="border-2 border-dashed border-hairline rounded-3xl py-16 text-center">
          <MapIcon className="w-10 h-10 text-muted-fg/30 mx-auto mb-3" />
          <p className="text-foreground font-medium">Nenhuma planta ainda</p>
          <p className="text-muted-fg text-sm mt-1">Envie a planta baixa (imagem) e posicione os itens por cima.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-3">
          {/* Painel lateral: superfície + itens da obra */}
          <div className="space-y-3">
            {/* Escala: largura real da planta → cotas em metros */}
            <div className="bg-surface-1 border border-hairline rounded-2xl p-3 space-y-2">
              <p className="text-[11px] uppercase tracking-wide text-muted-fg font-medium">Escala, largura real da planta</p>
              <div className="flex items-center gap-2">
                <Input type="number" step="0.1" min="0" value={planta.largura_m ?? ""}
                  onChange={e => {
                    const v = e.target.value === "" ? null : parseFloat(e.target.value)
                    mutate(ps => ps.map((p, i) => i === ativa ? { ...p, largura_m: v } : p))
                  }}
                  onBlur={() => plantas && persistir(plantas)}
                  placeholder="Ex: 12" className="h-9 text-sm flex-1" />
                <span className="text-[13px] text-muted-fg flex-shrink-0">metros</span>
              </div>
              <p className="text-[11px] text-muted-fg leading-snug">
                {planta.largura_m ? "Cotas em metros ativas." : "Sem escala, as cotas saem em % da planta."}
              </p>
            </div>

            <div className="bg-surface-1 border border-hairline rounded-2xl p-3 space-y-2">
              <p className="text-[11px] uppercase tracking-wide text-muted-fg font-medium">Superfície do próximo item</p>
              <div className="flex p-0.5 rounded-xl bg-surface-2 gap-0.5">
                {(["TETO", "PAREDE"] as Sup[]).map(s => (
                  <button key={s} onClick={() => setSupNovo(s)}
                    className={`flex-1 py-1.5 text-[12px] font-semibold rounded-[10px] transition-all flex items-center justify-center gap-1.5 ${
                      supNovo === s ? "bg-surface-1 shadow-sm shadow-black/20 " + SUP_COR[s].label : "text-muted-fg"
                    }`}>
                    <span className={`w-2 h-2 rounded-full ${SUP_COR[s].dot}`} /> {s}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-surface-1 border border-hairline rounded-2xl p-3 space-y-1.5 max-h-[340px] overflow-y-auto">
              <p className="text-[11px] uppercase tracking-wide text-muted-fg font-medium">Itens da obra, clique para posicionar</p>
              {itens.length === 0 && <p className="text-muted-fg text-[13px] py-2">Sem itens nos ambientes.</p>}
              {itens.map((it, i) => (
                <button key={i} onClick={() => addMarcador(it.nome, it.imagem_url)}
                  className="w-full text-left px-3 py-2 rounded-xl bg-surface-2/60 hover:bg-surface-2 text-[13px] text-foreground flex items-center gap-2 transition-colors">
                  {it.imagem_url ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={proxiedImg(it.imagem_url)} alt="" className="w-6 h-6 rounded-md object-cover flex-shrink-0"
                      onError={e => { (e.target as HTMLImageElement).style.display = "none" }} />
                  ) : (
                    <Plus className="w-3.5 h-3.5 text-ios-blue flex-shrink-0" />
                  )}
                  <span className="truncate">{it.nome}</span>
                </button>
              ))}
              <div className="flex gap-1.5 pt-1">
                <Input value={nomeLivre} onChange={e => setNomeLivre(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter" && nomeLivre.trim()) { addMarcador(nomeLivre.trim()); setNomeLivre("") } }}
                  placeholder="Item livre (Enter)" className="h-9 text-[13px]" />
              </div>
            </div>

            {selecionado && (() => {
              const m = planta.marcadores.find(x => x.id === selecionado)
              if (!m) return null
              return (
                <div className="bg-surface-1 border border-hairline rounded-2xl p-3 space-y-2">
                  <p className="text-[13px] font-semibold text-foreground truncate">{m.nome}</p>
                  <p className="text-[12px] text-muted-fg">
                    {planta.largura_m
                      ? <>← {(m.x / 100 * planta.largura_m).toFixed(2)} m da parede esq. · ↑ {(m.y / 100 * planta.largura_m * imgRatio).toFixed(2)} m do topo</>
                      : <>x {m.x.toFixed(1)}% · y {m.y.toFixed(1)}%</>}
                  </p>
                  <div className="flex gap-1.5">
                    <Button size="sm" variant="outline" className="h-8 text-xs flex-1"
                      onClick={() => mutate(ps => ps.map((p, i) => i === ativa
                        ? { ...p, marcadores: p.marcadores.map(x => x.id === m.id ? { ...x, sup: x.sup === "TETO" ? "PAREDE" : "TETO" } : x) }
                        : p), true)}>
                      {m.sup === "TETO" ? "→ Parede" : "→ Teto"}
                    </Button>
                    <Button size="sm" variant="ghost" className="h-8 text-xs text-ios-red hover:bg-ios-red/10"
                      onClick={() => { mutate(ps => ps.map((p, i) => i === ativa ? { ...p, marcadores: p.marcadores.filter(x => x.id !== m.id) } : p), true); setSelecionado(null) }}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              )
            })()}

            <Button size="sm" variant="ghost" className="w-full h-8 text-xs text-ios-red hover:bg-ios-red/10"
              onClick={async () => { if (await confirmar({ titulo: `Excluir a planta "${planta.nome}" e seus marcadores?`, perigo: true })) { mutate(ps => ps.filter((_, i) => i !== ativa), true); setAtiva(0); setSelecionado(null) } }}>
              <X className="w-3.5 h-3.5 mr-1" /> Excluir esta planta
            </Button>
          </div>

          {/* Canvas da planta */}
          <div ref={canvasRef}
            className="relative rounded-2xl overflow-hidden border border-hairline bg-white select-none touch-none min-h-[300px]"
            onPointerMove={onPointerMove} onPointerUp={onPointerUp} onPointerLeave={onPointerUp}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={proxiedImg(planta.imagem_url)} alt={planta.nome} draggable={false}
              onLoad={e => { const im = e.target as HTMLImageElement; setImgRatio(im.naturalHeight / im.naturalWidth) }}
              className="w-full h-auto pointer-events-none" />

            {/* Cotas estilo AutoCAD do marcador selecionado: até as bordas (parede)
                e até o vizinho mais próximo. Valores em metros quando a escala
                (largura real) está definida; senão em % da planta. */}
            {(() => {
              const sel = planta.marcadores.find(m => m.id === selecionado)
              if (!sel) return null
              const largM = planta.largura_m ?? null
              const altM = largM != null ? largM * imgRatio : null
              const fx = (px: number) => largM != null ? `${(px / 100 * largM).toFixed(2)} m` : `${px.toFixed(0)}%`
              const fy = (py: number) => altM != null ? `${(py / 100 * altM).toFixed(2)} m` : `${py.toFixed(0)}%`
              // Vizinho mais próximo (referência de objeto)
              let viz: Marcador | null = null, dviz = Infinity
              for (const m of planta.marcadores) {
                if (m.id === sel.id) continue
                const d = Math.hypot(m.x - sel.x, (m.y - sel.y) * imgRatio)
                if (d < dviz) { dviz = d; viz = m }
              }
              const distViz = viz && largM != null
                ? `${(Math.hypot((viz.x - sel.x) / 100 * largM, (viz.y - sel.y) / 100 * (altM ?? 0))).toFixed(2)} m`
                : viz ? `${dviz.toFixed(0)}%` : null
              const C = "#e11d48" // rosa-vermelho tipo cota CAD
              return (
                <svg className="absolute inset-0 w-full h-full pointer-events-none z-[15]" preserveAspectRatio="none" viewBox="0 0 100 100">
                  {/* Horizontal: borda esquerda → marcador */}
                  <line x1={0} y1={sel.y} x2={sel.x} y2={sel.y} stroke={C} strokeWidth={0.35} strokeDasharray="1.2 0.8" vectorEffect="non-scaling-stroke" />
                  {/* Vertical: topo → marcador */}
                  <line x1={sel.x} y1={0} x2={sel.x} y2={sel.y} stroke={C} strokeWidth={0.35} strokeDasharray="1.2 0.8" vectorEffect="non-scaling-stroke" />
                  {/* Referência ao vizinho */}
                  {viz && (
                    <line x1={sel.x} y1={sel.y} x2={viz.x} y2={viz.y} stroke="#7c3aed" strokeWidth={0.35} strokeDasharray="0.6 0.6" vectorEffect="non-scaling-stroke" />
                  )}
                  {/* Labels via foreignObject não escaláveis, usamos texto SVG com tamanho fixo compensado */}
                  <text x={sel.x / 2} y={Math.max(3, sel.y - 1.5)} fill={C} fontSize="2.6" textAnchor="middle" fontFamily="monospace" fontWeight="700">{fx(sel.x)}</text>
                  <text x={Math.min(96, sel.x + 1.5)} y={sel.y / 2} fill={C} fontSize="2.6" fontFamily="monospace" fontWeight="700">{fy(sel.y)}</text>
                  {viz && distViz && (
                    <text x={(sel.x + viz.x) / 2} y={(sel.y + viz.y) / 2 - 1.5} fill="#7c3aed" fontSize="2.4" textAnchor="middle" fontFamily="monospace" fontWeight="700">{distViz}</text>
                  )}
                </svg>
              )
            })()}

            {planta.marcadores.map(m => (
              <div key={m.id}
                onPointerDown={e => { e.preventDefault(); dragRef.current = m.id; setSelecionado(m.id) }}
                style={{ left: `${m.x}%`, top: `${m.y}%` }}
                className={`absolute -translate-x-1/2 -translate-y-1/2 cursor-grab active:cursor-grabbing group ${selecionado === m.id ? "z-20" : "z-10"}`}>
                {m.img ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={proxiedImg(m.img)} alt="" draggable={false}
                    className={`w-9 h-9 rounded-lg object-cover border-2 shadow-md bg-white ${
                      m.sup === "TETO" ? "border-ios-blue" : "border-ios-orange"
                    } ${selecionado === m.id ? `ring-4 ${SUP_COR[m.sup].ring}` : ""}`}
                    onError={e => { (e.target as HTMLImageElement).style.display = "none" }} />
                ) : (
                  <span className={`block w-4 h-4 rounded-full border-2 border-white shadow-md ${SUP_COR[m.sup].dot} ${selecionado === m.id ? `ring-4 ${SUP_COR[m.sup].ring}` : ""}`} />
                )}
                <span className="absolute left-1/2 -translate-x-1/2 top-full mt-1 px-1.5 py-0.5 rounded-md bg-black/75 text-white text-[10px] font-medium whitespace-nowrap pointer-events-none">
                  {m.nome}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {planta && (
        <p className="text-[12px] text-muted-fg">
          <span className="inline-flex items-center gap-1 mr-3"><span className="w-2 h-2 rounded-full bg-ios-blue inline-block" /> Teto</span>
          <span className="inline-flex items-center gap-1 mr-3"><span className="w-2 h-2 rounded-full bg-ios-orange inline-block" /> Parede</span>
          Arraste os pontos para posicionar · clique para selecionar · posições salvas em %.
        </p>
      )}
    </div>
  )
}
