import EstudoKeypads from "./estudo-keypads"

/** Estudo de keypads da obra (aberto por Engenharia → Projetos → Projeto Controllares). */
export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  return <EstudoKeypads obraId={id} />
}
