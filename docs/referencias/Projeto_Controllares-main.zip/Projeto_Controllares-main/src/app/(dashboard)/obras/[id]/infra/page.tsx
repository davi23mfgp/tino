import EstudoInfra from "./estudo-infra"

/** Infraestrutura (eletrodutos) da obra — aberta por Engenharia → Projetos → Projeto Controllares. */
export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  return <EstudoInfra obraId={id} />
}
