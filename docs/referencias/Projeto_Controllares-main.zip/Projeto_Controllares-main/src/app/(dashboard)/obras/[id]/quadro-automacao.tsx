"use client"

/**
 * Quadro de Automação da obra.
 * Seções: Keypads · Módulos (entradas/saídas) · IR · Rede.
 *
 * As quatro seções compartilham a mesma estrutura de módulo; muda o
 * vocabulário: saída (carga), emissor (IR) ou porta (switch de rede).
 * - A união de keypads é definida na aba Keypads ("ligar junto"). Cada
 *   conjunto unido vira UMA opção na entrada do módulo — a entrada escolhe
 *   da lista, não se digita mais o código na mão.
 * - "Juntar" = mesmo grupo (linhas em paralelo). Rede não junta.
 * - Importar por texto (notas do grupo / cola do Excel) e exportar CSV.
 */
import { useState, useEffect, useCallback, useRef } from "react"
import {
  Cpu, Plus, Trash2, ClipboardPaste, RefreshCw, Wifi, Radio, KeyRound, Layers,
  Download, Save, Link2, Pencil, Check, Upload,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { PageLoader } from "@/components/ui/bouncing-dots"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"

interface Keypad {
  id: string; codigo: string; ambiente: string | null; setor: string | null
  acabamento: string | null; medida: string | null
  teclas_automacao: number | null; pulsadores_compra: number | null
  ligar_junto: string | null; circuitos: string[]; observacao: string | null
}
interface Entrada { id: string; numero: string; keypads: string[]; grupo: string | null }
interface Saida {
  id: string; numero: string; descricao: string; circuito: string | null
  ambiente: string | null; tipo_carga: string | null; grupo: string | null
}
interface Modulo { id: string; nome: string; tipo: string | null; pavimento: string | null; capacidade: number | null; entradas: Entrada[]; saidas: Saida[] }
interface Quadro { id: string; nome: string; local: string | null; modulos: Modulo[] }
interface Ponto {
  id: string; tipo: string; codigo: string | null; ambiente: string | null
  equipamento: string | null; descricao: string | null; porta: string | null; ip: string | null; grupo: string | null
}
interface Resumo {
  total_keypads: number; total_pulsadores: number; total_teclas: number
  total_saidas: number; total_entradas: number
  por_ambiente: { ambiente: string; pulsadores: number; teclas: number; keypads: number }[]
}
interface Dados { keypads: Keypad[]; quadros: Quadro[]; pontos: Ponto[]; resumo: Resumo }

const SECOES = [
  { v: "teclas", l: "Keypads", Icon: KeyRound },
  { v: "modulos", l: "Módulos", Icon: Layers },
  { v: "ir", l: "IR", Icon: Radio },
  { v: "rede", l: "Rede", Icon: Wifi },
] as const
type SecaoV = (typeof SECOES)[number]["v"]

/** Equipamentos sugeridos por tipo de módulo — vira datalist, não trava digitação. */
const EQUIPAMENTOS: Record<string, string[]> = {
  IR: ["TV", "Receiver", "Set-top box", "Ar-condicionado", "Blu-ray", "Projetor", "Soundbar"],
  REDE: ["Switch", "Access Point", "Câmera", "NVR", "TV", "Controladora", "Roteador", "Rack"],
}

/**
 * Une os keypads ligados entre si (union-find) e devolve as opções que o
 * módulo pode receber numa entrada: cada conjunto ligado vira UMA opção,
 * e os keypads soltos entram individualmente.
 */
export function opcoesDeKeypad(keypads: Keypad[]) {
  const pai = new Map<string, string>()
  const acha = (x: string): string => {
    if (pai.get(x) === undefined || pai.get(x) === x) return x
    const r = acha(pai.get(x)!)
    pai.set(x, r)
    return r
  }
  const une = (a: string, b: string) => {
    const ra = acha(a), rb = acha(b)
    if (ra !== rb) pai.set(ra, rb)
  }

  const codigos = keypads.map(k => k.codigo.trim().toUpperCase()).filter(c => c && !c.startsWith("—"))
  for (const c of codigos) if (!pai.has(c)) pai.set(c, c)

  for (const k of keypads) {
    const origem = k.codigo.trim().toUpperCase()
    if (!origem || origem.startsWith("—")) continue
    // "KP01, KP05" ou "KP01 + KP05" — o campo aceita vários alvos.
    for (const alvo of String(k.ligar_junto ?? "").split(/[;,+/]+/).map(x => x.trim().toUpperCase()).filter(Boolean)) {
      if (!pai.has(alvo)) pai.set(alvo, alvo)
      une(origem, alvo)
    }
  }

  const grupos = new Map<string, string[]>()
  for (const c of new Set([...pai.keys()])) {
    const r = acha(c)
    grupos.set(r, [...(grupos.get(r) ?? []), c])
  }

  return [...grupos.values()]
    .map(membros => membros.sort((a, b) => a.localeCompare(b, "pt-BR", { numeric: true })))
    .sort((a, b) => a[0].localeCompare(b[0], "pt-BR", { numeric: true }))
    .map(membros => ({ valor: membros.join(" + "), membros, juntos: membros.length > 1 }))
}

export default function QuadroAutomacao({ obraId }: { obraId: string }) {
  const [d, setD] = useState<Dados | null>(null)
  const [secao, setSecao] = useState<SecaoV>("teclas")
  const [importOpen, setImportOpen] = useState<null | "teclas" | "modulos">(null)
  const [novoModOpen, setNovoModOpen] = useState(false)
  const [texto, setTexto] = useState("")
  const [quadroNome, setQuadroNome] = useState("")
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState("")
  const [lendoArquivo, setLendoArquivo] = useState(false)
  const arquivoRef = useRef<HTMLInputElement>(null)

  const load = useCallback(async () => {
    // no-store: sem isto o navegador podia servir uma resposta em cache e o
    // item recém-criado só aparecia depois de F5.
    const r = await fetch(`/api/obras/${obraId}/automacao`, { cache: "no-store" }).catch(() => null)
    if (r?.ok) { setD(await r.json()); return }
    // Falha passageira (rede/401) não deve apagar o que já estava na tela —
    // só mostra vazio na primeira carga, quando ainda não há nada pra perder.
    setD(prev => prev ?? { keypads: [], quadros: [], pontos: [], resumo: { total_keypads: 0, total_pulsadores: 0, total_teclas: 0, total_saidas: 0, total_entradas: 0, por_ambiente: [] } })
  }, [obraId])
  useEffect(() => { load() }, [load])

  const acao = useCallback(async (payload: Record<string, unknown>) => {
    setBusy(true); setMsg("")
    try {
      const r = await fetch(`/api/obras/${obraId}/automacao`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { setMsg(j.error ?? "Falha na operação."); return false }
      await load()
      return true
    } finally { setBusy(false) }
  }, [obraId, load])

  /** Extrai uma linha de célula (TSV) de uma row do ExcelJS. */
  function celulasDaRow(row: import("exceljs").Row): string {
    const celulas: string[] = []
    // row.values[0] é sempre undefined (ExcelJS é 1-indexado)
    const valores = Array.isArray(row.values) ? row.values.slice(1) : []
    for (const v of valores) {
      if (v == null) { celulas.push(""); continue }
      if (typeof v === "object" && "text" in (v as unknown as Record<string, unknown>)) {
        celulas.push(String((v as unknown as { text: unknown }).text ?? "")); continue
      }
      if (typeof v === "object" && "result" in (v as unknown as Record<string, unknown>)) {
        celulas.push(String((v as unknown as { result: unknown }).result ?? "")); continue
      }
      celulas.push(String(v))
    }
    return celulas.join("\t")
  }

  /* Reconhece o cabeçalho do Estudo de Teclas (mesmo teste do parser), pra
     não deixar o cabeçalho repetido de uma segunda aba virar linha de dado. */
  function pareceCabecalhoTeclas(linha: string): boolean {
    const n = linha.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()
    return n.includes("ambiente") && (n.includes("interrup") || n.includes("keypad") || n.includes("tecla"))
  }

  /* Lê .xlsx/.csv e transforma na mesma grade tabulada que o "colar do
     Excel" já aceita — não duplica o parser de teclas/módulos, só entrega o
     texto pro mesmo caminho. .xlsx via exceljs (já é dependência do
     projeto); .csv lido cru, trocando ';' por tab (exportação PT-BR do
     Excel separa colunas por ponto e vírgula, não por vírgula).

     Quando a planilha tem mais de uma aba, todas entram — cada aba além da
     primeira vira um bloco separado por uma linha só com o nome da aba, que
     o parser de teclas já lê como separador de pavimento/setor (mesmo
     mecanismo da linha "PAVIMENTO SUPERIOR" na planilha real). O cabeçalho
     de uma segunda aba não entra de novo, senão vira linha de dado errada. */
  async function importarArquivo(file: File) {
    setLendoArquivo(true); setMsg("")
    try {
      if (file.name.toLowerCase().endsWith(".csv")) {
        const bruto = await file.text()
        setTexto(bruto.includes("\t") ? bruto : bruto.replace(/;/g, "\t"))
        return
      }
      const ExcelJS = (await import("exceljs")).default
      const wb = new ExcelJS.Workbook()
      await wb.xlsx.load(await file.arrayBuffer())
      if (wb.worksheets.length === 0) { setMsg("Planilha vazia."); return }

      const blocos: string[] = []
      wb.worksheets.forEach((sheet, i) => {
        const linhasAba: string[] = []
        sheet.eachRow(row => linhasAba.push(celulasDaRow(row)))
        const semVazias = linhasAba.filter(l => l.replace(/\t/g, "").trim() !== "")
        if (!semVazias.length) return

        if (i === 0) { blocos.push(semVazias.join("\n")); return }

        // Abas seguintes: tira o cabeçalho repetido (só no modo teclas ele
        // existe de fato; no modo módulos a checagem simplesmente não bate).
        const dados = pareceCabecalhoTeclas(semVazias[0]) ? semVazias.slice(1) : semVazias
        if (!dados.length) return
        blocos.push(`${sheet.name}\n${dados.join("\n")}`)
      })
      setTexto(blocos.join("\n"))
    } catch {
      setMsg("Não consegui ler esse arquivo. Confirme que é .xlsx ou .csv.")
    } finally {
      setLendoArquivo(false)
    }
  }

  /* Modelo de planilha pra baixar e preencher por cima — mesmas colunas que
     o parser reconhece (mais uma linha de exemplo e uma de separador de
     pavimento, pra deixar claro como usar as duas). */
  async function baixarModeloTeclas() {
    const ExcelJS = (await import("exceljs")).default
    const wb = new ExcelJS.Workbook()
    const sheet = wb.addWorksheet("Estudo de Teclas")
    sheet.addRow(["AMBIENTES", "INTERRUPÇÃO", "CIRCUITOS", "ACABAMENTOS", "MEDIDAS", "QTD. TECLAS AUTOMAÇÃO", "COMPRA PULSADORES", "OBSERVAÇÃO"])
    sheet.getRow(1).font = { bold: true }
    sheet.addRow(["GARAGEM", "KP01", "", "PADRÃO", "4X2", 1, 1, ""])
    sheet.addRow(["GARAGEM", "KP02", "", "PADRÃO", "4X2", 0, 1, "LIGAR JUNTO KP01"])
    sheet.addRow(["PAVIMENTO SUPERIOR", "", "", "", "", "", "", ""])
    sheet.addRow(["CIRCULAÇÃO", "KP22", "", "PADRÃO", "4X2", 2, 2, ""])
    sheet.columns.forEach(c => { c.width = 20 })
    const buf = await wb.xlsx.writeBuffer()
    baixarBlob(buf, "modelo-estudo-de-teclas.xlsx")
  }

  async function baixarModeloModulos() {
    const ExcelJS = (await import("exceljs")).default
    const wb = new ExcelJS.Workbook()
    const sheet = wb.addWorksheet("Notas de módulos")
    const linhas = [
      "M-03", "Entradas", "01 a 02 (KP-22; KP-31; KP-32)", "",
      "Saidas", "01= Mini Spots Circulação", "02= Spot Sanca Living",
    ]
    linhas.forEach(l => sheet.addRow([l]))
    sheet.getColumn(1).width = 50
    const buf = await wb.xlsx.writeBuffer()
    baixarBlob(buf, "modelo-notas-de-modulos.xlsx")
  }

  function baixarBlob(buf: import("exceljs").Buffer, nome: string) {
    const blob = new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url; a.download = nome
    document.body.appendChild(a); a.click(); a.remove()
    URL.revokeObjectURL(url)
  }

  async function importar() {
    if (!texto.trim()) return
    const ok = importOpen === "teclas"
      ? await acao({ acao: "importar_teclas", texto })
      : await acao({ acao: "importar_modulos", texto, quadroNome })
    if (ok) { setImportOpen(null); setTexto(""); setQuadroNome("") }
  }

  if (!d) return <div className="py-16 flex justify-center"><PageLoader /></div>
  const tipoExport: string = secao

  // Módulos agrupados por pavimento. IR e Rede são módulos como os demais —
  // muda só o vocabulário (emissores / portas) e o que cada saída recebe.
  const todosModulos = d.quadros.flatMap(q => q.modulos.map(m => ({ ...m, quadroNome: q.nome })))
  const tipoDaSecao = secao === "ir" ? "IR" : secao === "rede" ? "REDE" : null
  const modulos = tipoDaSecao
    ? todosModulos.filter(m => m.tipo === tipoDaSecao)
    : todosModulos.filter(m => m.tipo !== "IR" && m.tipo !== "REDE")
  const pavimentos = [...new Set(modulos.map(m => m.pavimento || "Sem pavimento"))]

  // Opções que uma entrada de módulo pode receber (KPs soltos + uniões).
  const opcoesKp = opcoesDeKeypad(d.keypads)
  // Ambientes já conhecidos da obra, pra saída não virar digitação livre.
  const ambientes = [...new Set([
    ...d.keypads.map(k => k.ambiente ?? ""),
    ...todosModulos.flatMap(m => m.saidas.map(s => s.ambiente ?? "")),
  ].map(a => a.trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, "pt-BR"))

  const rotuloNovo = secao === "ir" ? "Novo módulo IR" : secao === "rede" ? "Novo switch" : "Novo módulo"

  return (
    <div className="bg-card rounded-xl border border-border p-4 md:p-6 space-y-4">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <h3 className="text-foreground font-medium flex items-center gap-2">
          <Cpu className="w-4 h-4 text-primary" /> Quadro de Automação
        </h3>
        {/* Um botão por linha no celular ocupava meia tela; aqui viram uma
            fileira compacta que rola. */}
        <div className="-mx-4 flex items-center gap-2 overflow-x-auto rolagem-toque px-4 md:mx-0 md:flex-wrap md:overflow-visible md:px-0">
          <Button size="sm" variant="outline" onClick={() => { setImportOpen("teclas"); setTexto("") }}
            className="shrink-0 gap-1.5">
            <ClipboardPaste className="w-3.5 h-3.5" /> <span className="whitespace-nowrap">Importar teclas</span>
          </Button>
          <Button size="sm" variant="outline" onClick={() => { setImportOpen("modulos"); setTexto("") }}
            className="shrink-0 gap-1.5">
            <ClipboardPaste className="w-3.5 h-3.5" /> <span className="whitespace-nowrap">Importar módulos</span>
          </Button>
          <a href={`/api/obras/${obraId}/automacao/exportar?tipo=${tipoExport}`}
            className="inline-flex h-8 shrink-0 items-center gap-1.5 rounded-xl border border-border px-3 text-sm text-foreground/80 hover:text-foreground">
            <Download className="w-3.5 h-3.5" /> Exportar
          </a>
        </div>
      </div>

      {/* Resumo */}
      {/* No celular os números viram uma faixa que rola: 5 cartões empilhados
          empurravam a tabela pra fora da primeira tela. */}
      <div className="-mx-4 flex gap-2 overflow-x-auto rolagem-toque px-4 pb-1 md:mx-0 md:grid md:grid-cols-5 md:overflow-visible md:px-0">
        {[
          { l: "Keypads", v: d.resumo.total_keypads },
          { l: "Pulsadores", v: d.resumo.total_pulsadores },
          { l: "Teclas autom.", v: d.resumo.total_teclas },
          { l: "Entradas", v: d.resumo.total_entradas },
          { l: "Saídas", v: d.resumo.total_saidas },
        ].map(x => (
          <div key={x.l} className="min-w-[92px] shrink-0 rounded-xl bg-muted px-3 py-2 md:min-w-0">
            <p className="text-[18px] font-bold text-foreground leading-none">{x.v}</p>
            <p className="text-[11px] text-muted-foreground mt-1 whitespace-nowrap">{x.l}</p>
          </div>
        ))}
      </div>

      {/* Seções, no celular fica em uma linha só que rola, sem quebrar em duas */}
      <div className="-mx-4 overflow-x-auto rolagem-toque px-4 md:mx-0 md:px-0">
        <div className="inline-flex w-max items-center gap-1 rounded-2xl bg-muted/60 p-1 md:w-fit">
        {SECOES.map(s => (
          <button key={s.v} onClick={() => setSecao(s.v)}
            className={`shrink-0 whitespace-nowrap px-3 py-1.5 rounded-xl text-xs font-medium transition-colors inline-flex items-center gap-1.5 ${
              secao === s.v ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
            }`}>
            <s.Icon className="w-3.5 h-3.5" /> {s.l}
          </button>
        ))}
        </div>
      </div>

      {msg && <p className="text-ios-red text-sm">{msg}</p>}

      {/* ── KEYPADS ── */}
      {secao === "teclas" && <TeclasTab keypads={d.keypads} onAcao={acao} busy={busy} />}

      {/* ── MÓDULOS · IR · REDE (mesma estrutura) ── */}
      {secao !== "teclas" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <p className="text-muted-foreground text-xs">
              {secao === "modulos" && "A entrada escolhe um keypad ou uma união feita na aba Keypads."}
              {secao === "ir" && "Cada saída é um emissor de IR. Junte os que dividem o mesmo emissor."}
              {secao === "rede" && "Cada saída é uma porta do switch. Portas de rede não se juntam."}
            </p>
            <Button size="sm" onClick={() => setNovoModOpen(true)} className="gap-1.5">
              <Plus className="w-4 h-4" /> {rotuloNovo}
            </Button>
          </div>
          {modulos.length === 0 ? (
            <p className="text-muted-foreground text-sm">
              {secao === "rede" ? "Nenhum switch cadastrado." : "Nenhum módulo aqui ainda."} Crie em “{rotuloNovo}”.
            </p>
          ) : pavimentos.map(pav => (
            <div key={pav} className="space-y-3">
              <p className="text-[11px] uppercase tracking-wide text-muted-fg border-b border-border/60 pb-1">{pav}</p>
              {modulos.filter(m => (m.pavimento || "Sem pavimento") === pav).map(m => (
                <ModuloEditor key={m.id} modulo={m} onAcao={acao} busy={busy}
                  opcoesKp={opcoesKp} ambientes={ambientes} />
              ))}
            </div>
          ))}
        </div>
      )}

      {/* Dialog: novo módulo */}
      <NovoModuloDialog open={novoModOpen} onOpenChange={setNovoModOpen} onAcao={acao} busy={busy}
        tipoFixo={tipoDaSecao} />

      {/* Dialog: importar */}
      <Dialog open={importOpen !== null} onOpenChange={o => { if (!o) setImportOpen(null) }}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{importOpen === "teclas" ? "Importar teclas (cola do Excel)" : "Importar notas de módulos"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 px-5 sm:px-6 py-4">
            {importOpen === "teclas" ? (
              /* As colunas em lista, não numa linha corrida: o texto antigo
                 emendava sete nomes numa frase só, e o placeholder repetia o
                 cabeçalho cru com tabulação, que quebrava em qualquer largura
                 e virava um bolo de palavras. */
              <div className="space-y-2">
                <p className="text-muted-foreground text-xs">
                  Selecione as células no Excel <b>com o cabeçalho</b> e cole abaixo.
                  <b> Substitui</b> o estudo atual.
                </p>
                <div className="rounded-xl border border-hairline bg-surface-2/50 p-3">
                  <p className="mb-2 text-[11px] font-medium uppercase tracking-[0.1em] text-muted-fg">
                    Colunas reconhecidas
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {["Ambientes", "Interrupção", "Circuitos", "Acabamentos", "Medidas", "Qtd. Teclas", "Compra Pulsadores"].map(c => (
                      <span key={c} className="rounded-full bg-background px-2.5 py-1 text-[11px] text-foreground">
                        {c}
                      </span>
                    ))}
                  </div>
                  <p className="mt-2.5 text-[11px] leading-relaxed text-muted-fg">
                    Em qualquer ordem. Também entende “LIGAR JUNTO KPxx” e a linha
                    solta com o nome do pavimento.
                  </p>
                </div>
              </div>
            ) : (
              <>
                <p className="text-muted-foreground text-xs">
                  Cole as notas do grupo. Faixas como <b>01 a 02 (KP-22; KP-31)</b> viram uma entrada por número,
                  com os keypads ligados juntos.
                </p>
                <div className="space-y-1.5">
                  <Label className="text-foreground/80">Nome do quadro</Label>
                  <Input value={quadroNome} onChange={e => setQuadroNome(e.target.value)}
                    placeholder="Ex: QDA Superior" className="bg-muted border-border text-foreground" />
                </div>
              </>
            )}
            <div className="flex flex-wrap items-center gap-2">
              <input ref={arquivoRef} type="file" accept=".xlsx,.csv" className="hidden"
                onChange={e => { const f = e.target.files?.[0]; if (f) importarArquivo(f); e.target.value = "" }} />
              <Button type="button" variant="outline" size="sm" className="gap-1.5" disabled={lendoArquivo}
                onClick={() => arquivoRef.current?.click()}>
                {lendoArquivo ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                Importar arquivo (.xlsx ou .csv)
              </Button>
              <Button type="button" variant="ghost" size="sm" className="gap-1.5 text-muted-foreground"
                onClick={() => importOpen === "teclas" ? baixarModeloTeclas() : baixarModeloModulos()}>
                <Download className="w-3.5 h-3.5" /> Baixar modelo
              </Button>
              <span className="text-muted-foreground text-xs">Planilha com mais de uma aba: todas entram. Ou cole abaixo.</span>
            </div>
            <textarea value={texto} onChange={e => setTexto(e.target.value)} rows={12}
              placeholder={importOpen === "teclas"
                ? "Cole aqui o que você copiou da planilha, com a linha do cabeçalho."
                : "M-03\nEntradas\n01 a 02 (KP-22; KP-31; KP-32)\n\nSaidas\n01= Mini Spots Circulação"}
              className="w-full rounded-xl bg-muted border border-border text-foreground text-xs font-mono p-3 focus:outline-none focus:ring-2 focus:ring-primary" />
          </div>
          <DialogFooter className="px-5 sm:px-6 pb-4 gap-2">
            <Button variant="outline" onClick={() => setImportOpen(null)}>Cancelar</Button>
            <Button onClick={importar} disabled={busy || !texto.trim()} className="gap-1.5">
              {busy ? <><RefreshCw className="w-4 h-4 animate-spin" /> Importando…</> : "Importar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

/* ══════════════ NOVO MÓDULO ══════════════ */
function NovoModuloDialog({ open, onOpenChange, onAcao, busy, tipoFixo }: {
  open: boolean; onOpenChange: (o: boolean) => void
  onAcao: (p: Record<string, unknown>) => Promise<boolean>; busy: boolean
  /** Nas abas IR e Rede o tipo já está decidido — não faz sentido perguntar. */
  tipoFixo?: string | null
}) {
  const vazio = { nome: "", tipo: tipoFixo ?? "RELAY", pavimento: "", modelo: "", qtd_entradas: "8", qtd_saidas: "12", capacidade: "" }
  const [f, setF] = useState(vazio)
  useEffect(() => { setF(v => ({ ...v, tipo: tipoFixo ?? (v.tipo === "IR" || v.tipo === "REDE" ? "RELAY" : v.tipo) })) }, [tipoFixo, open])

  const ehIR = f.tipo === "IR"
  const ehRede = f.tipo === "REDE"
  const semEntradas = ehIR || ehRede

  const titulo = ehIR ? "Novo módulo IR" : ehRede ? "Novo switch" : "Novo módulo"
  const rotuloSaidas = ehIR ? "Qtd. de emissores" : ehRede ? "Qtd. de portas" : "Qtd. saídas / retornos"

  async function criar() {
    if (!f.nome.trim()) return
    const ok = await onAcao({ acao: "criar_modulo", modulo: f })
    if (ok) { setF(vazio); onOpenChange(false) }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader><DialogTitle>{titulo}</DialogTitle></DialogHeader>
        <div className="space-y-4 px-5 sm:px-6 py-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-foreground/80">Nome *</Label>
              <Input value={f.nome} onChange={e => setF({ ...f, nome: e.target.value })}
                placeholder={ehIR ? "IR-01" : ehRede ? "SW-01" : "M-03"} className="bg-muted border-border text-foreground" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-foreground/80">Tipo</Label>
              {tipoFixo ? (
                <div className="h-10 px-3 rounded-xl bg-muted border border-border text-muted-foreground text-sm flex items-center">
                  {ehIR ? "IR" : "Rede"}
                </div>
              ) : (
                <select value={f.tipo} onChange={e => setF({ ...f, tipo: e.target.value })}
                  className="w-full h-10 px-3 rounded-xl bg-muted border border-border text-foreground text-sm">
                  <option value="RELAY">Relay</option>
                  <option value="DIMMER">Dimmer</option>
                </select>
              )}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-foreground/80">Pavimento</Label>
              <Input value={f.pavimento} onChange={e => setF({ ...f, pavimento: e.target.value })}
                placeholder="Térreo" className="bg-muted border-border text-foreground" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-foreground/80">Modelo</Label>
              <Input value={f.modelo} onChange={e => setF({ ...f, modelo: e.target.value })}
                placeholder="R12" className="bg-muted border-border text-foreground" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {!semEntradas && (
              <div className="space-y-1.5">
                <Label className="text-foreground/80">Qtd. entradas</Label>
                <Input type="number" min="0" max="64" value={f.qtd_entradas}
                  onChange={e => setF({ ...f, qtd_entradas: e.target.value })}
                  className="bg-muted border-border text-foreground" />
              </div>
            )}
            <div className="space-y-1.5">
              <Label className="text-foreground/80">{rotuloSaidas}</Label>
              <Input type="number" min="0" max="64" value={f.qtd_saidas}
                onChange={e => setF({ ...f, qtd_saidas: e.target.value })}
                className="bg-muted border-border text-foreground" />
            </div>
          </div>
          <p className="text-[11px] text-muted-foreground/60">
            As linhas numeradas são criadas em branco, é só preencher o nome de cada uma depois.
          </p>
        </div>
        <DialogFooter className="px-5 sm:px-6 pb-4 gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button onClick={criar} disabled={busy || !f.nome.trim()} className="gap-1.5">
            {busy ? <><RefreshCw className="w-4 h-4 animate-spin" /> Criando…</> : "Criar módulo"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ══════════════ EDITOR DO MÓDULO ══════════════ */
function ModuloEditor({ modulo, onAcao, busy, opcoesKp, ambientes }: {
  modulo: Modulo & { quadroNome?: string }
  onAcao: (p: Record<string, unknown>) => Promise<boolean>; busy: boolean
  opcoesKp: { valor: string; membros: string[]; juntos: boolean }[]
  ambientes: string[]
}) {
  const [saidas, setSaidas] = useState(modulo.saidas)
  const [entradas, setEntradas] = useState(modulo.entradas)
  const [sujo, setSujo] = useState(false)
  useEffect(() => { setSaidas(modulo.saidas); setEntradas(modulo.entradas); setSujo(false) }, [modulo])

  const ehIR = modulo.tipo === "IR"
  const ehRede = modulo.tipo === "REDE"
  const semEntradas = ehIR || ehRede
  // Rede não junta: cada porta é individual.
  const podeJuntarSaida = !ehRede
  const rotuloSaidas = ehIR ? "Emissores de IR" : ehRede ? "Portas do switch" : "Saídas / retornos"
  const equipamentos = EQUIPAMENTOS[modulo.tipo ?? ""] ?? []
  const listaEquipId = `equip-${modulo.id}`
  const listaAmbId = `amb-${modulo.id}`
  const setS = (i: number, patch: Partial<Saida>) => { setSaidas(p => p.map((s, j) => j === i ? { ...s, ...patch } : s)); setSujo(true) }
  const setE = (i: number, patch: Partial<Entrada>) => { setEntradas(p => p.map((e, j) => j === i ? { ...e, ...patch } : e)); setSujo(true) }

  /** Próximo grupo livre (G1, G2, …) para juntar linhas. */
  function proximoGrupo(usados: (string | null)[]) {
    const nums = usados.filter(Boolean).map(g => Number(String(g).replace(/\D/g, "")) || 0)
    return `G${Math.max(0, ...nums) + 1}`
  }

  async function salvar() {
    const ok = await onAcao({
      acao: "salvar_linhas", moduloId: modulo.id,
      saidas: saidas.map(s => ({ id: s.id, descricao: s.descricao, ambiente: s.ambiente, circuito: s.circuito, tipo_carga: s.tipo_carga, grupo: s.grupo })),
      entradas: entradas.map(e => ({ id: e.id, keypads: e.keypads, grupo: e.grupo })),
    })
    if (ok) setSujo(false)
  }

  return (
    <div className="border border-border rounded-2xl p-3 space-y-3">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <p className="text-foreground font-medium text-sm flex items-center gap-2">
          {modulo.nome}
          {modulo.tipo && <Badge variant="secondary" className="text-[10px]">{modulo.tipo}</Badge>}
          <span className="text-muted-foreground text-xs font-normal">
            {ehIR ? `${saidas.length} emissores`
              : ehRede ? `${saidas.length} portas`
              : `${entradas.length} entradas · ${saidas.length} saídas`}
          </span>
        </p>
        <div className="flex items-center gap-2">
          {sujo && (
            <Button size="sm" onClick={salvar} disabled={busy} className="gap-1.5 h-8">
              <Save className="w-3.5 h-3.5" /> Salvar
            </Button>
          )}
          <button onClick={() => onAcao({ acao: "excluir_modulo", moduloId: modulo.id })}
            className="text-muted-foreground/60 hover:text-ios-red" title="Excluir módulo">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Sugestões compartilhadas pelas linhas, datalist não impede digitar outro valor */}
      <datalist id={listaAmbId}>{ambientes.map(a => <option key={a} value={a} />)}</datalist>
      {equipamentos.length > 0 && (
        <datalist id={listaEquipId}>{equipamentos.map(e => <option key={e} value={e} />)}</datalist>
      )}

      <div className={`grid grid-cols-1 ${semEntradas ? "" : "lg:grid-cols-2"} gap-4`}>
        {/* Entradas: escolhidas na lista de keypads, não digitadas */}
        {!semEntradas && (
          <div className="space-y-1.5">
            <p className="text-[11px] uppercase tracking-wide text-muted-foreground">Entradas (KP)</p>
            {opcoesKp.length === 0 && (
              <p className="text-muted-foreground text-xs">
                Cadastre os keypads na aba <b>Keypads</b> para escolher aqui.
              </p>
            )}
            {entradas.length === 0 ? <p className="text-muted-foreground text-xs">Sem entradas.</p> : entradas.map((e, i) => {
              const atual = e.keypads.join(" + ")
              // Keypad gravado antes de existir na lista continua selecionável.
              const foraDaLista = atual && !opcoesKp.some(o => o.valor === atual)
              return (
                <div key={e.id} className="flex items-center gap-1.5">
                  <span className="font-mono text-xs text-muted-foreground w-6 flex-shrink-0">{e.numero}</span>
                  <select value={atual}
                    onChange={ev => setE(i, { keypads: ev.target.value ? ev.target.value.split(" + ") : [] })}
                    className="h-8 flex-1 min-w-0 px-2 rounded-xl bg-muted border border-border text-foreground text-xs">
                    <option value="">livre</option>
                    {foraDaLista && <option value={atual}>{atual}</option>}
                    {opcoesKp.map(o => (
                      <option key={o.valor} value={o.valor}>
                        {o.valor}{o.juntos ? "  (ligados juntos)" : ""}
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={() => setE(i, { grupo: e.grupo ? null : proximoGrupo(entradas.map(x => x.grupo)) })}
                    title={e.grupo ? `No grupo ${e.grupo}, clique para soltar` : "Juntar com outras entradas"}
                    className={`h-8 px-2 rounded-lg text-[10px] font-medium flex-shrink-0 border transition-colors ${
                      e.grupo ? "bg-ios-blue/15 text-ios-blue border-ios-blue/30" : "bg-muted border-border text-muted-foreground hover:text-foreground"
                    }`}>
                    {e.grupo ?? <Link2 className="w-3.5 h-3.5" />}
                  </button>
                </div>
              )
            })}
          </div>
        )}

        {/* Saídas · emissores de IR · portas do switch */}
        <div className="space-y-1.5">
          <p className="text-[11px] uppercase tracking-wide text-muted-foreground">{rotuloSaidas}</p>
          {/* No celular a linha vira duas: descrição em cima, equipamento e
              ambiente embaixo. Quatro campos lado a lado não cabiam. */}
          {saidas.length === 0 ? <p className="text-muted-foreground text-xs">Sem saídas.</p> : saidas.map((s, i) => (
            <div key={s.id} className="flex items-start gap-1.5 border-b border-hairline pb-1.5 last:border-0 md:border-0 md:pb-0">
              <span className="mt-2 w-6 flex-shrink-0 font-mono text-xs text-muted-foreground">{s.numero}</span>
              <div className="flex min-w-0 flex-1 flex-col gap-1.5 md:flex-row md:items-center">
                <Input value={s.descricao} onChange={ev => setS(i, { descricao: ev.target.value })}
                  placeholder={ehIR ? "TV Sala" : ehRede ? "AP Corredor" : "Mini Spots Circulação"}
                  className="h-8 text-xs bg-muted border-border md:flex-1" />
                <div className="flex gap-1.5">
                  {equipamentos.length > 0 && (
                    <Input list={listaEquipId} value={s.tipo_carga ?? ""}
                      onChange={ev => setS(i, { tipo_carga: ev.target.value })}
                      placeholder={ehRede ? "Dispositivo" : "Equipamento"}
                      className="h-8 flex-1 text-xs bg-muted border-border md:w-32 md:flex-initial md:flex-shrink-0" />
                  )}
                  <Input list={listaAmbId} value={s.ambiente ?? ""} onChange={ev => setS(i, { ambiente: ev.target.value })}
                    placeholder="Ambiente"
                    className="h-8 flex-1 text-xs bg-muted border-border md:w-28 md:flex-initial md:flex-shrink-0" />
                </div>
              </div>
              {podeJuntarSaida && (
                <button
                  onClick={() => setS(i, { grupo: s.grupo ? null : proximoGrupo(saidas.map(x => x.grupo)) })}
                  title={s.grupo ? `No grupo ${s.grupo}, clique para soltar` : "Juntar com outras saídas"}
                  className={`h-8 px-2 rounded-lg text-[10px] font-medium flex-shrink-0 border transition-colors ${
                    s.grupo ? "bg-ios-blue/15 text-ios-blue border-ios-blue/30" : "bg-muted border-border text-muted-foreground hover:text-foreground"
                  }`}>
                  {s.grupo ?? <Link2 className="w-3.5 h-3.5" />}
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
      <p className="text-[11px] text-muted-foreground/60">
        {podeJuntarSaida
          ? <>Clique no ícone de corrente para <b>juntar</b> linhas (mesmo grupo = em paralelo). Clique de novo para soltar.</>
          : <>Cada porta de rede é individual. Portas não se juntam.</>}
      </p>
    </div>
  )
}

/* ══════════════ ESTUDO DE TECLAS (editável) ══════════════ */
function TeclasTab({ keypads, onAcao, busy }: {
  keypads: Keypad[]; onAcao: (p: Record<string, unknown>) => Promise<boolean>; busy: boolean
}) {
  const [edit, setEdit] = useState<Keypad | null>(null)
  const [novo, setNovo] = useState(false)
  const vazio: Partial<Keypad> = { codigo: "", ambiente: "", setor: "", acabamento: "PADRÃO", medida: "4X2", teclas_automacao: 1, pulsadores_compra: 1, ligar_junto: "" }
  const [f, setF] = useState<Partial<Keypad>>(vazio)

  // "KP01, KP05" — o campo aceita vários alvos; a UI trata como conjunto.
  const juntoSelecionado = String(f.ligar_junto ?? "")
    .split(/[;,+/]+/).map(x => x.trim().toUpperCase()).filter(Boolean)
  const outrosCodigos = keypads
    .map(k => k.codigo.trim().toUpperCase())
    .filter(c => c && !c.startsWith("—") && c !== String(f.codigo ?? "").trim().toUpperCase())
    .sort((a, b) => a.localeCompare(b, "pt-BR", { numeric: true }))

  function alternarJunto(codigo: string) {
    const proximo = juntoSelecionado.includes(codigo)
      ? juntoSelecionado.filter(c => c !== codigo)
      : [...juntoSelecionado, codigo]
    setF(v => ({ ...v, ligar_junto: proximo.join(", ") }))
  }

  function abrir(k?: Keypad) {
    if (k) { setEdit(k); setF({ ...k }) } else { setEdit(null); setF(vazio) }
    setNovo(true)
  }
  async function salvar() {
    const ok = await onAcao({ acao: "salvar_keypad", keypad: { ...f, id: edit?.id } })
    if (ok) { setNovo(false); setEdit(null); setF(vazio) }
  }

  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <Button size="sm" onClick={() => abrir()} className="gap-1.5"><Plus className="w-4 h-4" /> Novo keypad</Button>
      </div>

      {keypads.length === 0 ? (
        <p className="text-muted-foreground text-sm">Nenhum keypad. Use “Importar teclas” pra colar o estudo do Excel.</p>
      ) : (
        <>
          {/* Celular: cartões. A tabela de 9 colunas só rolava lateralmente. */}
          <div className="space-y-2 md:hidden">
            {keypads.map(k => (
              <div key={k.id} className="rounded-2xl bg-surface-1 px-4 py-3">
                <div className="flex items-start gap-3">
                  <div className="min-w-0 flex-1">
                    <p className="flex items-center gap-2 text-sm font-medium text-foreground">
                      <span className="font-mono">{k.codigo.startsWith("—") ? "—" : k.codigo}</span>
                      {k.ligar_junto && (
                        <Badge variant="secondary" className="text-[10px]">→ {k.ligar_junto}</Badge>
                      )}
                    </p>
                    <p className="mt-0.5 truncate text-xs text-muted-fg">
                      {[k.ambiente, k.setor].filter(Boolean).join(" · ") || "sem ambiente"}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    <button onClick={() => abrir(k)} className="p-1.5 text-muted-foreground/60 hover:text-primary" title="Editar">
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button onClick={() => onAcao({ acao: "excluir_keypad", keypadId: k.id })}
                      className="p-1.5 text-muted-foreground/60 hover:text-ios-red" title="Excluir">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-muted-fg">
                  {k.acabamento && <span>{k.acabamento}</span>}
                  {k.medida && <span>{k.medida}</span>}
                  <span>{k.teclas_automacao ?? 0} teclas</span>
                  <span>{k.pulsadores_compra ?? 0} pulsadores</span>
                </div>
              </div>
            ))}
          </div>

          <div className="hidden overflow-x-auto md:block">
            <table className="w-full text-sm">
              <thead><tr className="text-muted-foreground text-xs border-b border-border/60">
                <th className="text-left py-2">Setor</th><th className="text-left py-2">Ambiente</th>
                <th className="text-left py-2">Keypad</th><th className="text-left py-2">Acab.</th>
                <th className="text-left py-2">Medida</th><th className="text-center py-2">Teclas</th>
                <th className="text-center py-2">Pulsad.</th><th className="text-left py-2">Ligar junto</th><th />
              </tr></thead>
              <tbody>
                {keypads.map(k => (
                  <tr key={k.id} className="border-b border-border/40">
                    <td className="py-2 text-muted-foreground text-xs">{k.setor ?? "—"}</td>
                    <td className="py-2 text-foreground">{k.ambiente ?? "—"}</td>
                    <td className="py-2 font-mono text-xs">{k.codigo.startsWith("—") ? "—" : k.codigo}</td>
                    <td className="py-2 text-muted-foreground text-xs">{k.acabamento ?? "—"}</td>
                    <td className="py-2 text-muted-foreground text-xs">{k.medida ?? "—"}</td>
                    <td className="py-2 text-center">{k.teclas_automacao ?? "—"}</td>
                    <td className="py-2 text-center">{k.pulsadores_compra ?? "—"}</td>
                    <td className="py-2">
                      {k.ligar_junto
                        ? <Badge variant="secondary" className="text-[10px]">→ {k.ligar_junto}</Badge>
                        : <span className="text-muted-foreground text-xs">—</span>}
                    </td>
                    <td className="py-2 text-right whitespace-nowrap">
                      <button onClick={() => abrir(k)} className="text-muted-foreground/60 hover:text-primary mr-2" title="Editar">
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => onAcao({ acao: "excluir_keypad", keypadId: k.id })}
                        className="text-muted-foreground/60 hover:text-ios-red" title="Excluir">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      <Dialog open={novo} onOpenChange={o => { if (!o) { setNovo(false); setEdit(null) } }}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{edit ? `Editar ${edit.codigo}` : "Novo keypad"}</DialogTitle></DialogHeader>
          <div className="space-y-4 px-5 sm:px-6 py-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-foreground/80">Keypad *</Label>
                <Input value={f.codigo ?? ""} onChange={e => setF({ ...f, codigo: e.target.value.toUpperCase() })}
                  placeholder="KP01" className="bg-muted border-border text-foreground" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-foreground/80">Ambiente</Label>
                <Input value={f.ambiente ?? ""} onChange={e => setF({ ...f, ambiente: e.target.value })}
                  placeholder="GARAGEM" className="bg-muted border-border text-foreground" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-foreground/80">Setor / pavimento</Label>
                <Input value={f.setor ?? ""} onChange={e => setF({ ...f, setor: e.target.value })}
                  placeholder="TÉRREO" className="bg-muted border-border text-foreground" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-foreground/80">Acabamento</Label>
                <Input value={f.acabamento ?? ""} onChange={e => setF({ ...f, acabamento: e.target.value })}
                  placeholder="PADRÃO" className="bg-muted border-border text-foreground" />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label className="text-foreground/80">Medida</Label>
                <Input value={f.medida ?? ""} onChange={e => setF({ ...f, medida: e.target.value })}
                  placeholder="4X2" className="bg-muted border-border text-foreground" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-foreground/80">Teclas</Label>
                <Input type="number" min="0" value={f.teclas_automacao ?? ""}
                  onChange={e => setF({ ...f, teclas_automacao: e.target.value === "" ? null : Number(e.target.value) })}
                  className="bg-muted border-border text-foreground" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-foreground/80">Pulsadores</Label>
                <Input type="number" min="0" value={f.pulsadores_compra ?? ""}
                  onChange={e => setF({ ...f, pulsadores_compra: e.target.value === "" ? null : Number(e.target.value) })}
                  className="bg-muted border-border text-foreground" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-foreground/80">Ligar junto com</Label>
              {/* A união é montada aqui: o módulo depois só escolhe o conjunto pronto. */}
              <div className="rounded-xl bg-muted border border-border max-h-56 overflow-y-auto divide-y divide-border/60">
                {outrosCodigos.length === 0 && (
                  <p className="text-muted-foreground/60 text-xs px-3 py-3">
                    Cadastre outros keypads para poder uni-los.
                  </p>
                )}
                {outrosCodigos.map(c => {
                  const marcado = juntoSelecionado.includes(c)
                  return (
                    <button key={c} type="button" onClick={() => alternarJunto(c)}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 text-left text-sm font-mono transition-colors ${
                        marcado ? "bg-ios-blue/10 text-ios-blue" : "text-foreground hover:bg-background"
                      }`}>
                      <span className={`w-4 h-4 rounded flex-shrink-0 border flex items-center justify-center ${
                        marcado ? "bg-ios-blue border-ios-blue" : "border-border"
                      }`}>
                        {marcado && <Check className="w-3 h-3 text-white" />}
                      </span>
                      {c}
                    </button>
                  )
                })}
              </div>
              <p className="text-[11px] text-muted-foreground/60">
                Keypads unidos viram <b>uma única opção</b> na entrada do módulo
                {juntoSelecionado.length > 0 && (
                  <>, aqui: <span className="font-mono text-foreground/80">
                    {[String(f.codigo ?? "").toUpperCase(), ...juntoSelecionado].filter(Boolean).join(" + ")}
                  </span></>
                )}.
              </p>
            </div>
          </div>
          <DialogFooter className="px-5 sm:px-6 pb-4 gap-2">
            <Button variant="outline" onClick={() => { setNovo(false); setEdit(null) }}>Cancelar</Button>
            <Button onClick={salvar} disabled={busy || !String(f.codigo ?? "").trim()} className="gap-1.5">
              {busy ? <><RefreshCw className="w-4 h-4 animate-spin" /> Salvando…</> : "Salvar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
