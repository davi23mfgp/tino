"use client"

/**
 * Peças comuns das ferramentas de Projetos (Estudo de keypads e Infraestrutura):
 * escolher a planta em Projetos ou no computador, recortar, roda do mouse e
 * gravar o que foi exportado como linha de Projetos (com versão R00, R01…).
 */
import { useRef } from "react"
import { Crop, FileUp, Map as MapIcon, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { proxiedImg } from "@/lib/img"

export interface Blueprint { data_arquivo: string; categoria: string; nome: string; versao: string; etapa: string; drive_url: string }
export interface Anexo { nome: string; url: string; ext?: string }

export const src = (u?: string | null) => (u ? (u.startsWith("data:") ? u : proxiedImg(u)) : "")
export const ehPlanta = (nome: string, url: string) => /\.(pdf|png|jpe?g|webp)(\?|$)/i.test(nome) || /\.(pdf|png|jpe?g|webp)(\?|$)/i.test(url)
export const hoje = () => new Date().toISOString().slice(0, 10)
/** Nome de arquivo em maiúsculas, sem acento, espaço nem traço sobrando: "KEYPADS-JOAO-SILVA". */
export const nomeArquivo = (...partes: string[]) =>
  partes.join("-").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^\w]+/g, "-").replace(/^-|-$/g, "").toUpperCase()

/* roda do mouse/touchpad: pinça ou Ctrl = zoom suave · mouse = 10% · dois dedos = anda */
export function roda(e: WheelEvent, zoom: (f: number) => void, andar: (dx: number, dy: number) => void) {
  e.preventDefault()
  if (e.ctrlKey) return zoom(Math.exp(Math.max(-40, Math.min(40, e.deltaY)) * 0.006))
  const mouse = e.deltaMode === 1 || (e.deltaX === 0 && Math.abs(e.deltaY) >= 50 && Number.isInteger(e.deltaY))
  if (mouse) zoom(e.deltaY > 0 ? 1.1 : 1 / 1.1)
  else andar(e.deltaX, e.deltaY)
}

/** Próxima versão (R00, R01…) de um arquivo com esse nome e categoria em Projetos. */
export function proximaVersao(lista: Blueprint[] | null, categoria: string, nome: string) {
  const mesmas = (lista ?? []).filter((b) => b.categoria === categoria && b.nome === nome)
  const ult = Math.max(-1, ...mesmas.map((b) => Number(String(b.versao).replace(/\D/g, "")) || 0))
  return mesmas.length ? `R${String(ult + 1).padStart(2, "0")}` : "R00"
}

/** Acrescenta uma linha em Projetos da obra (versão sobe sozinha pelo mesmo nome). */
export async function adicionarBlueprint(obraId: string, { categoria, nome, url }: { categoria: string; nome: string; url: string }) {
  const r = await fetch(`/api/obras/${obraId}`)
  const o = (await r.json()) as { projetos_blueprints: Blueprint[] | null }
  const lista = o.projetos_blueprints ?? []
  const versao = proximaVersao(lista, categoria, nome)
  const nova = [...lista, { data_arquivo: hoje(), categoria, nome, versao, etapa: "Em projeto", drive_url: url }]
  const p = await fetch(`/api/obras/${obraId}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ projetos_blueprints: nova }) })
  if (!p.ok) throw new Error("Não consegui gravar em Projetos.")
  return { versao, lista: nova }
}

/* ================= Escolher planta (de Projetos ou do computador) ================= */
export function EscolherPlanta({ obra, onEscolher, onArquivo }: { obra: { projetos_blueprints: Blueprint[] | null; anexos_projeto: Anexo[] | null }; onEscolher: (b: { nome: string; url: string }) => void; onArquivo: (f: File) => void }) {
  const arquivos = [
    ...(obra.projetos_blueprints ?? []).filter((b) => b.drive_url && ehPlanta(b.nome, b.drive_url)).map((b) => ({ nome: b.nome, url: b.drive_url, info: `${b.categoria} · ${b.versao || ""} ${b.data_arquivo || ""}` })),
    ...(obra.anexos_projeto ?? []).filter((a) => a.url && ehPlanta(a.nome, a.url)).map((a) => ({ nome: a.nome, url: a.url, info: "Anexo de projeto" })),
  ]
  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">PDF ou imagem que já está em Projetos desta obra:</p>
      <div className="max-h-72 overflow-auto rounded-xl border border-border">
        {arquivos.length ? arquivos.map((a, i) => (
          <button key={i} onClick={() => onEscolher(a)} className="flex w-full items-center gap-3 border-b border-border px-3 py-2.5 text-left last:border-0 hover:bg-muted">
            <MapIcon className="size-4 shrink-0 text-muted-foreground" />
            <span className="min-w-0 flex-1"><b className="block truncate text-sm font-medium">{a.nome}</b><span className="text-xs text-muted-foreground">{a.info}</span></span>
          </button>
        )) : <p className="p-4 text-center text-sm text-muted-foreground">Nenhuma planta em Projetos ainda.</p>}
      </div>
      <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-border p-3 text-sm hover:bg-muted">
        <FileUp className="size-4" />Subir do computador (PDF ou imagem)
        <input type="file" accept="application/pdf,image/*" hidden onChange={(ev) => { const f = ev.target.files?.[0]; if (f) onArquivo(f); ev.target.value = "" }} />
      </label>
      <p className="text-xs text-muted-foreground">O arquivo subido também fica em Projetos → Projeto de Obra.</p>
    </div>
  )
}

/* ================= Recorte ================= */
export function Recorte({ img, f, onMudar, onAuto, onCancelar, onAplicar }: {
  img: string; f: [number, number, number, number]; onMudar: (f: [number, number, number, number]) => void
  onAuto: () => void; onCancelar: () => void; onAplicar: () => void
}) {
  const ref = useRef<HTMLDivElement>(null)
  const arr = useRef<{ h: string; x: number; y: number; f: [number, number, number, number]; r: DOMRect } | null>(null)
  const alcas = ["nw", "n", "ne", "e", "se", "s", "sw", "w"]
  const posAlca: Record<string, string> = { nw: "left-0 top-0 cursor-nwse-resize", n: "left-1/2 top-0 cursor-ns-resize", ne: "left-full top-0 cursor-nesw-resize", e: "left-full top-1/2 cursor-ew-resize", se: "left-full top-full cursor-nwse-resize", s: "left-1/2 top-full cursor-ns-resize", sw: "left-0 top-full cursor-nesw-resize", w: "left-0 top-1/2 cursor-ew-resize" }
  return (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground">Arraste os cantos para deixar só o desenho. Legenda, carimbo e notas ficam de fora. A sugestão é do programa: confira.</p>
      <div className="flex justify-center rounded-xl bg-muted p-2">
        <div ref={ref} className="relative inline-block touch-none select-none overflow-hidden rounded-lg"
          onPointerDown={(ev) => {
            const t = ev.target as HTMLElement
            const h = t.dataset.h || (t.dataset.caixa ? "mover" : "")
            if (!h) return
            arr.current = { h, x: ev.clientX, y: ev.clientY, f: [...f] as [number, number, number, number], r: ref.current!.getBoundingClientRect() }
            ref.current!.setPointerCapture(ev.pointerId)
            ev.preventDefault()
          }}
          onPointerMove={(ev) => {
            const a = arr.current
            if (!a) return
            const dx = (ev.clientX - a.x) / a.r.width, dy = (ev.clientY - a.y) / a.r.height
            const n = [...a.f] as [number, number, number, number], cl = (v: number) => Math.max(0, Math.min(1, v)), M = 0.03
            if (a.h === "mover") {
              const w = n[2] - n[0], hh = n[3] - n[1]
              n[0] = Math.min(cl(a.f[0] + dx), 1 - w); n[1] = Math.min(cl(a.f[1] + dy), 1 - hh); n[2] = n[0] + w; n[3] = n[1] + hh
            } else {
              if (a.h.includes("w")) n[0] = Math.min(cl(a.f[0] + dx), n[2] - M)
              if (a.h.includes("e")) n[2] = Math.max(cl(a.f[2] + dx), n[0] + M)
              if (a.h.includes("n")) n[1] = Math.min(cl(a.f[1] + dy), n[3] - M)
              if (a.h.includes("s")) n[3] = Math.max(cl(a.f[3] + dy), n[1] + M)
            }
            onMudar(n)
          }}
          onPointerUp={() => { arr.current = null }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={img} alt="" draggable={false} className="pointer-events-none block max-h-[60vh] max-w-full" />
          <div data-caixa="1" className="absolute cursor-move border-2 border-white outline outline-1 outline-[#292929]"
            style={{ left: `${f[0] * 100}%`, top: `${f[1] * 100}%`, width: `${(f[2] - f[0]) * 100}%`, height: `${(f[3] - f[1]) * 100}%`, boxShadow: "0 0 0 9999px rgba(0,0,0,.5)" }}>
            {alcas.map((h) => <i key={h} data-h={h} className={`absolute -ml-2 -mt-2 size-4 rounded border-2 border-[#292929] bg-white ${posAlca[h]}`} />)}
          </div>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Button variant="outline" size="sm" onClick={onAuto}><Sparkles className="size-4" />Achar o desenho sozinho</Button>
        <Button variant="outline" size="sm" onClick={() => onMudar([0, 0, 1, 1])}>Folha inteira</Button>
        <span className="flex-1" />
        <Button variant="outline" onClick={onCancelar}>Cancelar</Button>
        <Button onClick={onAplicar}><Crop className="size-4" />Recortar</Button>
      </div>
    </div>
  )
}
