﻿"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import {
  Box, Camera, Cpu, FileStack, Paperclip, GanttChartSquare,
  Plus, Trash2, ExternalLink, Image as ImageIcon, Video, KeyRound,
  FileSpreadsheet, FileText, File as FileIcon, RefreshCw, ChevronRight, X, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import QuadroAutomacao from "./quadro-automacao"
import { proxiedImg } from "@/lib/img"
import Posicao2D from "./posicao-2d"

// ---------- Tipos ----------
interface EnvItem {
  id: string; quantidade: number
  product: { nome: string; sku: string; imagem_url?: string | null } | null
  kit: { nome: string } | null
  category: { nome: string } | null
  nome_snapshot?: string | null
  is_aditivo: boolean
}
interface Environment {
  id: string; nome: string
  proposalItems: EnvItem[]
  _count: { inspectionsMedia: number }
}
interface Vistoria {
  id: string; tipo: string; url: string; descricao: string | null
  environment_nome: string | null; createdAt: string
}
interface Engraving {
  id: string; descricao_botao: string; posicao: number; environment_nome: string | null
}
interface GanttTask {
  id: string; titulo: string; raia: string; data_inicio: string; data_fim: string
}
interface Blueprint {
  data_arquivo: string; categoria: string; nome: string; versao: string; etapa: string; drive_url: string
}
interface Anexo { nome: string; url: string; ext: string }
interface Quadro { nome: string; descricao: string }

interface Props {
  obraId: string
  environments: Environment[]
  initialProjetos: Blueprint[]
  initialAnexos: Anexo[]
  initialQuadros: Quadro[]
  onSyncAmbientes?: () => void
  /** Abre a aba Dimensionamento depois que a organizacao fecha. */
  onIrParaDimensionamento?: () => void
  // Sub-aba controlada pelo pai (dropdown da barra única). Se ausente, usa estado interno.
  activeSub?: string
  onSubChange?: (v: string) => void
}

const RAIAS = [
  { id: "CONSTRUTORA", label: "Construtora", color: "bg-amber-500" },
  { id: "EMPRESA", label: "Empresa", color: "bg-primary" },
  { id: "TERCEIROS", label: "Terceiros", color: "bg-purple-500" },
]

export default function EngenhariaTab({ obraId, environments, initialProjetos, initialAnexos, initialQuadros, onSyncAmbientes, onIrParaDimensionamento, activeSub, onSubChange }: Props) {
  const [envs, setEnvs] = useState<Environment[]>(environments)
  const [syncing, setSyncing] = useState(false)
  const [syncMsg, setSyncMsg] = useState<string | null>(null)

  async function sincronizar() {
    setSyncing(true)
    setSyncMsg(null)
    const res = await fetch(`/api/obras/${obraId}/sync-ambientes`, { method: "POST" })
    const data = await res.json()
    setSyncMsg(data.message)
    if (data.synced > 0) {
      // Recarrega ambientes
      const oRes = await fetch(`/api/obras/${obraId}`)
      if (oRes.ok) {
        const o = await oRes.json()
        setEnvs(o.environments || [])
      }
      onSyncAmbientes?.()
    }
    setSyncing(false)
  }

  /* Sincronizar era um botao, e quem abria a obra pela primeira vez via a tela
     vazia sem saber que precisava apertar. Roda sozinho ao abrir: a rota nao
     duplica ambiente, entao repetir e barato. */
  const jaSincronizou = useRef(false)
  useEffect(() => {
    if (jaSincronizou.current) return
    jaSincronizou.current = true
    sincronizar()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [obraId])

  return (
    <Tabs
      value={activeSub}
      defaultValue={activeSub ? undefined : "ambientes"}
      onValueChange={onSubChange}
    >
      {/* Barra interna removida: navegação agora vem do dropdown "Engenharia" da barra única */}
      <TabsContent value="ambientes" className="mt-0">
        <AmbientesGrid
          obraId={obraId}
          environments={envs}
          onSincronizar={sincronizar}
          syncing={syncing}
          onConcluir={onIrParaDimensionamento ?? (() => {})}
        />
      </TabsContent>
      <TabsContent value="vistorias" className="mt-4"><VistoriasTab obraId={obraId} environments={envs} /></TabsContent>
      <TabsContent value="quadros" className="mt-4">
        <div className="space-y-4">
          {/* Configuração do quadro: estudo de teclas, módulos, IR e rede */}
          <QuadroAutomacao obraId={obraId} />
          {/* Arquivos do quadro (QDA/engraving) seguem disponíveis */}
          <QuadrosEngravings obraId={obraId} environments={envs} initialQuadros={initialQuadros} />
        </div>
      </TabsContent>
      <TabsContent value="projetos" className="mt-4"><ProjetosTab obraId={obraId} initial={initialProjetos} /></TabsContent>
      <TabsContent value="posicao" className="mt-4">
        <Posicao2D obraId={obraId}
          itens={envs.flatMap(e => e.proposalItems.map(it => ({
            nome: it.product?.nome ?? it.kit?.nome ?? it.nome_snapshot ?? "Item",
            sku: it.product?.sku ?? null,
            imagem_url: it.product?.imagem_url ?? null,
          })))} />
      </TabsContent>
      <TabsContent value="anexos" className="mt-4"><AnexosTab obraId={obraId} initial={initialAnexos} /></TabsContent>
      <TabsContent value="gantt" className="mt-4"><GanttTabView obraId={obraId} /></TabsContent>
    </Tabs>
  )
}

// ================= URL or File Field =================
function UrlOrFileField({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [mode, setMode] = useState<"url" | "file">("url")
  const [uploading, setUploading] = useState(false)
  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]; if (!file) return
    setUploading(true)
    const fd = new FormData(); fd.append("file", file)
    const res = await fetch("/api/upload", { method: "POST", body: fd })
    if (res.ok) { const { url } = await res.json(); onChange(url) }
    setUploading(false); e.target.value = ""
  }
  return (
    <div className="space-y-1.5">
      <div className="flex gap-1 bg-muted rounded-xl p-0.5 w-fit">
        <button type="button" onClick={() => setMode("url")}
          className={`px-2 py-0.5 rounded text-xs transition-colors ${mode === "url" ? "bg-muted/70 text-foreground" : "text-muted-foreground hover:text-muted-foreground"}`}>URL</button>
        <button type="button" onClick={() => setMode("file")}
          className={`px-2 py-0.5 rounded text-xs transition-colors ${mode === "file" ? "bg-muted/70 text-foreground" : "text-muted-foreground hover:text-muted-foreground"}`}>Arquivo</button>
      </div>
      {mode === "url" ? (
        <input value={value} onChange={e => onChange(e.target.value)} placeholder="Link (Drive, OneDrive…)"
          className="h-8 w-full px-3 rounded-xl bg-muted border border-border text-foreground text-xs focus:outline-none focus:border-primary" />
      ) : (
        <div className="flex items-center gap-2">
          <label className={`flex items-center gap-1.5 h-8 px-3 rounded-xl border cursor-pointer text-xs transition-colors ${uploading ? "bg-muted/70 border-border text-muted-foreground" : "bg-muted border-border hover:border-primary text-muted-foreground hover:text-foreground"}`}>
            <Plus className="w-3.5 h-3.5" /> {uploading ? "Enviando..." : "Anexar"}
            <input type="file" className="hidden" disabled={uploading} onChange={handleFile} />
          </label>
          {value && <a href={value} target="_blank" rel="noreferrer" className="text-primary text-xs hover:text-primary truncate max-w-[140px]">Ver arquivo</a>}
        </div>
      )}
    </div>
  )
}

/**
 * Onde este item vai ser instalado.
 *
 * Campo de texto e não lista fechada: na hora de vender ninguém sabe ainda que
 * a caixa nº 3 vai na varanda, e uma lista de cômodos pronta só faria o técnico
 * escolher "o mais parecido". O `datalist` puxa os ambientes já escritos nesta
 * obra, que é o que evita "Suíte 2" e "suite 02" convivendo na mesma lista sem
 * proibir um nome novo.
 */
interface ProdutoAmbiente {
  id: string; quantidade: number; is_aditivo: boolean
  nome_snapshot?: string | null
  product: { nome: string; sku: string; imagem_url?: string | null } | null
  kit: { nome: string } | null
}
interface ObraAmbienteApi { id: string; nome: string; itens: ProdutoAmbiente[] }

const nomeProduto = (it: ProdutoAmbiente) => it.product?.nome ?? it.kit?.nome ?? it.nome_snapshot ?? "Item"

/**
 * Linha de produto dentro de um card de ambiente ou da fila de disponíveis.
 * O botão muda de sinal conforme o contexto: "+" adiciona (some da fila,
 * entra no ambiente), "×" remove (sai do ambiente, volta pra fila) — nunca os
 * dois ao mesmo tempo, pra não ter dúvida do que o clique faz.
 */
function LinhaProduto({ item, acao, onClick }: {
  item: ProdutoAmbiente
  acao: "adicionar" | "remover"
  onClick: () => void
}) {
  /* Quem organiza a obra reconhece o produto pela foto e pelo código, não por
     um nome truncado em letra miúda. A miniatura cresceu, o SKU ganhou linha
     própria e a quantidade virou pílula: é o mesmo dado de antes, legível. */
  const codigo = item.product?.sku ?? null
  return (
    <div className="flex items-center gap-3 rounded-2xl bg-surface-2/40 p-2 transition-colors hover:bg-surface-2/70">
      <div className="h-11 w-11 flex-shrink-0 overflow-hidden rounded-xl bg-background flex items-center justify-center border border-hairline">
        {item.product?.imagem_url ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={proxiedImg(item.product.imagem_url)} alt="" className="h-full w-full object-cover"
            onError={e => { (e.target as HTMLImageElement).style.display = "none" }} />
        ) : (
          <Box className="h-4 w-4 text-muted-foreground/40" />
        )}
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-[13.5px] font-medium leading-tight text-foreground">{nomeProduto(item)}</p>
        <div className="mt-0.5 flex items-center gap-1.5">
          {codigo && <span className="truncate font-mono text-[11px] text-muted-fg">{codigo}</span>}
          {item.is_aditivo && (
            <Badge variant="outline" className="flex-shrink-0 px-1.5 py-0 text-[10px]">aditivo</Badge>
          )}
        </div>
      </div>
      <span className="flex-shrink-0 rounded-full bg-background px-2 py-0.5 text-[11px] font-medium tabular-nums text-muted-fg">
        {item.quantidade}x
      </span>
      <button type="button" onClick={onClick}
        title={acao === "adicionar" ? "Adicionar a este ambiente" : "Tirar deste ambiente"}
        className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full transition-all active:scale-90 disabled:opacity-40 ${
          acao === "adicionar"
            ? "bg-primary text-primary-foreground hover:opacity-90"
            : "bg-background text-muted-fg hover:bg-destructive/10 hover:text-destructive"
        }`}>
        {acao === "adicionar" ? <Plus className="h-4 w-4" /> : <X className="h-3.5 w-3.5" />}
      </button>
    </div>
  )
}

/**
 * Um ambiente físico, em faixa de largura inteira.
 *
 * Era cartão estreito em grade de três colunas, e o nome do ambiente e o do
 * produto viviam cortados com reticências. Em faixa, o nome cabe e os produtos
 * ficam em duas colunas quando a tela permite. Adicionar produto abre o popup
 * do meio da tela, o mesmo de sempre, em vez de uma listinha apertada aqui
 * dentro.
 */
function CardAmbiente({ ambiente, onRenomear, onExcluir, onMover, onAdicionar }: {
  ambiente: ObraAmbienteApi
  onRenomear: (nome: string) => void
  onExcluir: () => void
  onMover: (itemId: string, paraAmbienteId: string | null) => void
  onAdicionar: () => void
}) {
  const [editandoNome, setEditandoNome] = useState(false)
  const [nome, setNome] = useState(ambiente.nome)

  useEffect(() => { setNome(ambiente.nome) }, [ambiente.nome])

  function confirmarNome() {
    setEditandoNome(false)
    const t = nome.trim()
    if (t && t !== ambiente.nome) onRenomear(t)
    else setNome(ambiente.nome)
  }

  return (
    <div className="rounded-[20px] border border-hairline bg-card p-4 shadow-sm sm:p-5">
      <div className="mb-3 flex items-center gap-3">
        {editandoNome ? (
          <input autoFocus value={nome} onChange={e => setNome(e.target.value)}
            onBlur={confirmarNome}
            onKeyDown={e => {
              if (e.key === "Enter") { e.preventDefault(); confirmarNome() }
              if (e.key === "Escape") { setNome(ambiente.nome); setEditandoNome(false) }
            }}
            className="h-9 min-w-0 flex-1 rounded-xl border border-primary bg-background px-3 text-[15px] font-semibold text-foreground outline-none" />
        ) : (
          <button type="button" onClick={() => setEditandoNome(true)}
            className="min-w-0 flex-1 truncate text-left text-[17px] font-semibold text-foreground transition-colors hover:text-primary">
            {ambiente.nome}
          </button>
        )}
        <span className="flex-shrink-0 rounded-full bg-surface-2 px-2.5 py-1 text-[11px] text-muted-fg">
          {ambiente.itens.length} {ambiente.itens.length === 1 ? "produto" : "produtos"}
        </span>
        <Button onClick={onAdicionar} size="sm" variant="outline" className="flex-shrink-0 gap-1.5">
          <Plus className="h-3.5 w-3.5" /> Produto
        </Button>
        <button type="button" onClick={onExcluir} title="Excluir ambiente"
          className="flex-shrink-0 text-muted-foreground/50 transition-colors hover:text-destructive">
          <Trash2 className="h-4 w-4" />
        </button>
      </div>

      {ambiente.itens.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-hairline py-5 text-center text-xs text-muted-fg">
          Nenhum produto ainda.
        </p>
      ) : (
        <div className="grid gap-1.5 lg:grid-cols-2">
          {ambiente.itens.map(it => (
            <LinhaProduto key={it.id} item={it} acao="remover" onClick={() => onMover(it.id, null)} />
          ))}
        </div>
      )}
    </div>
  )
}

/**
 * Popup para acoplar produtos a um ambiente.
 *
 * Um lugar só para três caminhos: logo depois de criar o ambiente, pelo botão
 * do card, e pelo alerta de produtos sem ambiente. O destino fica num seletor
 * no topo, então dá para distribuir vários produtos por ambientes diferentes
 * sem fechar e reabrir.
 */
function DialogProdutos({ aberto, onFechar, ambientes, semAmbiente, destinoInicial, onMover }: {
  aberto: boolean
  onFechar: () => void
  ambientes: ObraAmbienteApi[]
  semAmbiente: ProdutoAmbiente[]
  destinoInicial: string | null
  onMover: (itemId: string, paraAmbienteId: string | null) => void
}) {
  const [destino, setDestino] = useState<string>(destinoInicial ?? ambientes[0]?.id ?? "")
  const [busca, setBusca] = useState("")

  useEffect(() => {
    if (aberto) setDestino(destinoInicial ?? ambientes[0]?.id ?? "")
  }, [aberto, destinoInicial, ambientes])

  const filtrados = busca.trim()
    ? semAmbiente.filter(it => nomeProduto(it).toLowerCase().includes(busca.trim().toLowerCase()))
    : semAmbiente

  return (
    <Dialog open={aberto} onOpenChange={o => { if (!o) { onFechar(); setBusca("") } }}>
      <DialogContent className="max-w-2xl">
        <DialogHeader><DialogTitle>Produtos sem ambiente</DialogTitle></DialogHeader>
        <div className="space-y-3 px-5 py-4 sm:px-6">
          <div className="flex flex-wrap items-center gap-2">
            <Label className="text-sm text-foreground/80">Mandar para</Label>
            <select value={destino} onChange={e => setDestino(e.target.value)}
              className="h-9 min-w-[160px] flex-1 rounded-xl border border-border bg-muted px-3 text-sm text-foreground">
              {ambientes.map(a => <option key={a.id} value={a.id}>{a.nome}</option>)}
            </select>
          </div>

          <Input value={busca} onChange={e => setBusca(e.target.value)}
            placeholder="Buscar produto..." className="h-10" />

          <div className="max-h-[45vh] space-y-1.5 overflow-y-auto">
            {filtrados.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-fg">
                {semAmbiente.length === 0 ? "Todo produto já tem ambiente." : "Nada encontrado."}
              </p>
            ) : filtrados.map(it => (
              <LinhaProduto key={it.id} item={it} acao="adicionar"
                onClick={() => { if (destino) onMover(it.id, destino) }} />
            ))}
          </div>
        </div>
        <DialogFooter>
          <Button onClick={() => { onFechar(); setBusca("") }}>Concluir</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

// ================= Ambientes/Produtos =================
function AmbientesGrid({ obraId, environments, onSincronizar, syncing, onConcluir }: {
  obraId: string
  environments: Environment[]
  onSincronizar: () => void
  syncing: boolean
  /** Leva para o Dimensionamento depois que nada mais esta solto. */
  onConcluir: () => void
}) {
  const [ambientes, setAmbientes] = useState<ObraAmbienteApi[]>([])
  const [semAmbiente, setSemAmbiente] = useState<ProdutoAmbiente[]>([])
  const [loading, setLoading] = useState(true)
  const [criarOpen, setCriarOpen] = useState(false)
  const [novoNome, setNovoNome] = useState("")
  const [criando, setCriando] = useState(false)
  /* Popup de acoplar produto. `destino` é o ambiente que já vem escolhido:
     vem preenchido ao criar um ambiente ou pelo botão do card, e vazio quando
     se abre pelo alerta de pendência. */
  const [produtosOpen, setProdutosOpen] = useState<{ destino: string | null } | null>(null)
  const [erro, setErro] = useState("")
  /* Os ambientes que ESTA empresa mais usa, do mesmo jeito que a proposta faz
     com os sistemas: quem faz apartamento repete "Suíte 1", quem faz casa
     repete "Varanda". Digitar tudo de novo em cada obra é trabalho que o
     próprio histórico já sabe fazer. */
  const [frequentes, setFrequentes] = useState<string[]>([])

  const carregar = useCallback(async () => {
    const r = await fetch(`/api/obras/${obraId}/ambientes`)
    if (r.ok) {
      const d = await r.json()
      setAmbientes(d.ambientes ?? [])
      setSemAmbiente(d.semAmbiente ?? [])
    }
    setLoading(false)
  }, [obraId])

  // Recarrega quando a sincronização da proposta traz produtos novos.
  useEffect(() => { carregar() }, [carregar, environments])

  useEffect(() => {
    fetch("/api/ambientes/frequentes?de=obra", { cache: "no-store" })
      .then(r => r.ok ? r.json() : null)
      .then(d => { if (Array.isArray(d?.ambientes)) setFrequentes(d.ambientes) })
      // Falhou: o campo continua digitável, só sem atalho.
      .catch(() => {})
  }, [])

  /* Tela responde no clique, servidor confirma depois.
     Antes cada ação esperava a resposta do PATCH e AINDA recarregava a lista
     inteira antes de mexer em qualquer pixel: duas idas ao servidor entre o
     clique e o produto sair do lugar. Agora o estado local muda na hora e a
     requisição corre atrás; se ela falhar, o `carregar()` desfaz, que é o
     único momento em que a tela volta atrás. */
  async function criarAmbiente(nomeDireto?: string) {
    const nome = (nomeDireto ?? novoNome).trim()
    if (!nome) return
    setCriando(true)
    setErro("")
    try {
      const r = await fetch(`/api/obras/${obraId}/ambientes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome }),
      })
      if (!r.ok) { setErro((await r.json().catch(() => null))?.error ?? "Não consegui criar."); return }
      // O POST já devolve o ambiente criado: dá pra pendurar na lista sem
      // buscar tudo de novo.
      const criado = (await r.json().catch(() => null))?.ambiente
      if (criado) setAmbientes(a => [...a, { ...criado, itens: criado.itens ?? [] }])
      else await carregar()
      setNovoNome(""); setCriarOpen(false)
      /* Criar ambiente é meio do caminho: ninguém cria "Cozinha" para deixar
         vazia. O popup de produtos abre já apontando para ele. */
      if (criado?.id) setProdutosOpen({ destino: criado.id })
    } finally {
      setCriando(false)
    }
  }

  async function renomearAmbiente(id: string, nome: string) {
    setAmbientes(a => a.map(amb => amb.id === id ? { ...amb, nome } : amb))
    const r = await fetch(`/api/obras/${obraId}/ambientes/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nome }),
    })
    if (!r.ok) await carregar()
  }

  async function excluirAmbiente(id: string) {
    /* Sem confirmação de "tem certeza": o produto NÃO some (volta pra fila
       de sem ambiente, é SetNull no banco) — apagar o agrupamento é
       reversível na prática, não é apagar trabalho. */
    const alvo = ambientes.find(a => a.id === id)
    setAmbientes(a => a.filter(amb => amb.id !== id))
    if (alvo?.itens.length) setSemAmbiente(s => [...s, ...alvo.itens])
    const r = await fetch(`/api/obras/${obraId}/ambientes/${id}`, { method: "DELETE" })
    if (!r.ok) await carregar()
  }

  async function mover(itemId: string, paraAmbienteId: string | null) {
    // Acha o item onde quer que ele esteja e já o coloca no destino.
    const daFila = semAmbiente.find(i => i.id === itemId)
    const item = daFila ?? ambientes.flatMap(a => a.itens).find(i => i.id === itemId)
    if (!item) return

    setSemAmbiente(s => paraAmbienteId ? s.filter(i => i.id !== itemId) : [...s.filter(i => i.id !== itemId), item])
    setAmbientes(a => a.map(amb => ({
      ...amb,
      itens: amb.id === paraAmbienteId
        ? [...amb.itens.filter(i => i.id !== itemId), item]
        : amb.itens.filter(i => i.id !== itemId),
    })))

    const r = await fetch(`/api/obras/${obraId}/ambiente-item`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ itemId, obraAmbienteId: paraAmbienteId }),
    })
    if (!r.ok) await carregar()
  }

  const totalItens = environments.reduce((n, e) => n + e.proposalItems.length, 0)

  if (environments.length === 0) {
    return (
      <div className="bg-card rounded-xl border border-border p-10 text-center space-y-4">
        <p className="text-muted-foreground">Esta obra não tem produtos sincronizados.</p>
        <p className="text-muted-foreground/70 text-sm">A importação da proposta de origem roda sozinha ao abrir. Se nada veio, é porque esta obra não tem proposta ligada.</p>
        {/* Botao de reforco: a sincronizacao ja rodou, mas erro de rede deixa
            a tela vazia sem caminho de volta. */}
        <Button onClick={onSincronizar} disabled={syncing} variant="outline" className="gap-2">
          <RefreshCw className={`w-4 h-4 ${syncing ? "animate-spin" : ""}`} />
          {syncing ? "Sincronizando..." : "Tentar de novo"}
        </Button>
      </div>
    )
  }

  if (loading) return <div className="bg-card rounded-xl border border-border p-10 text-center text-muted-foreground text-sm">Carregando...</div>

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 flex-wrap">
        <Button onClick={() => setCriarOpen(true)} size="sm" className="gap-1.5">
          <Plus className="w-3.5 h-3.5" /> Adicionar Ambiente
        </Button>
        {/* A pendencia fica ao lado de quem a resolve. Flutuando no canto da
            tela ela cobria conteudo e ninguem ligava o alerta ao gesto de
            criar ambiente. Clicou, abre o popup pra distribuir. */}
        {semAmbiente.length > 0 && (
          <button type="button"
            onClick={() => {
              if (ambientes.length === 0) { setCriarOpen(true); return }
              setProdutosOpen({ destino: null })
            }}
            className="flex items-center gap-2 rounded-full border border-warning/40 bg-surface-1 px-3 py-1.5 transition-transform active:scale-95">
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-warning/15 text-[10px] font-bold text-warning">
              {semAmbiente.length}
            </span>
            <span className="text-[13px] font-medium text-foreground">
              {semAmbiente.length === 1 ? "produto sem ambiente" : "produtos sem ambiente"}
            </span>
          </button>
        )}
        {/* Salvar e o fim da organizacao: enquanto sobrar produto solto, o
            dimensionamento trabalharia em cima de meia obra. */}
        <Button onClick={onConcluir} disabled={semAmbiente.length > 0 || ambientes.length === 0}
          size="sm" variant={semAmbiente.length > 0 ? "outline" : "default"} className="ml-auto gap-1.5"
          title={semAmbiente.length > 0
            ? "Coloque todos os produtos em um ambiente para liberar"
            : "Libera o dimensionamento"}>
          <Check className="w-3.5 h-3.5" /> Salvar e liberar dimensionamento
        </Button>
        {syncing && (
          <span className="flex items-center gap-1.5 text-muted-foreground text-xs">
            <RefreshCw className="w-3 h-3 animate-spin" /> Sincronizando
          </span>
        )}
      </div>

      {/* Ambientes em faixa, um debaixo do outro: em grade de três colunas o
          nome do ambiente e o do produto viviam cortados. */}
      {ambientes.length === 0 ? (
        <div className="rounded-[20px] border border-dashed border-border bg-card p-8 text-center">
          <p className="text-muted-foreground text-sm">Nenhum ambiente criado ainda.</p>
          <p className="text-muted-foreground/70 text-xs mt-1">Crie o primeiro (&quot;Sala&quot;, &quot;Suíte 2&quot;...) para começar a ligar os produtos.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {ambientes.map(amb => (
            <CardAmbiente key={amb.id} ambiente={amb}
              onRenomear={nome => renomearAmbiente(amb.id, nome)}
              onExcluir={() => excluirAmbiente(amb.id)}
              onMover={mover}
              onAdicionar={() => setProdutosOpen({ destino: amb.id })}
            />
          ))}
        </div>
      )}

      {erro && <p className="text-destructive text-xs">{erro}</p>}

      <DialogProdutos
        aberto={produtosOpen !== null}
        onFechar={() => setProdutosOpen(null)}
        ambientes={ambientes}
        semAmbiente={semAmbiente}
        destinoInicial={produtosOpen?.destino ?? null}
        onMover={mover}
      />

      <Dialog open={criarOpen} onOpenChange={setCriarOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Novo ambiente</DialogTitle></DialogHeader>
          <div className="space-y-3 px-5 py-4 sm:px-6">
            <Input autoFocus value={novoNome} onChange={e => setNovoNome(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); criarAmbiente() } }}
              placeholder="Ex.: Sala, Suíte 2, Varanda..." className="h-11" />

            {/* Um toque cria: os nomes que já se repetem nas obras da casa. Os
                que esta obra já tem saem da lista, senão viram ambiente
                duplicado. */}
            {(() => {
              const usados = new Set(ambientes.map(a => a.nome.trim().toLowerCase()))
              const livres = frequentes.filter(f => !usados.has(f.trim().toLowerCase()))
              if (!livres.length) return null
              return (
                <div>
                  <p className="mb-2 text-[11px] font-medium uppercase tracking-[0.1em] text-muted-fg">
                    Usados com frequência
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {livres.map(nome => (
                      <button key={nome} type="button" disabled={criando}
                        onClick={() => criarAmbiente(nome)}
                        className="rounded-full border border-hairline bg-surface-2 px-3 py-1.5 text-[13px] text-foreground transition-colors hover:border-primary hover:text-primary disabled:opacity-40">
                        {nome}
                      </button>
                    ))}
                  </div>
                </div>
              )
            })()}

            {erro && <p className="text-destructive text-xs">{erro}</p>}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCriarOpen(false)}>Cancelar</Button>
            <Button onClick={() => criarAmbiente()} disabled={criando || !novoNome.trim()}>
              {criando ? "Criando..." : "Criar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ================= Vistorias =================
function VistoriasTab({ obraId, environments }: { obraId: string; environments: Environment[] }) {
  const [vistorias, setVistorias] = useState<Vistoria[]>([])
  const [envId, setEnvId] = useState("")
  const [tipo, setTipo] = useState("FOTO")
  const [desc, setDesc] = useState("")
  const [uploading, setUploading] = useState(false)

  const load = useCallback(async () => {
    const res = await fetch(`/api/obras/${obraId}/vistorias`)
    if (res.ok) setVistorias((await res.json()).vistorias)
  }, [obraId])
  useEffect(() => { load() }, [load])

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setUploading(true)
    const fd = new FormData(); fd.append("file", file)
    const res = await fetch("/api/upload", { method: "POST", body: fd })
    if (res.ok) {
      const { url } = await res.json()
      await fetch(`/api/obras/${obraId}/vistorias`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ environmentId: envId || null, tipo, url, descricao: desc || file.name }),
      })
      setDesc(""); load()
    }
    setUploading(false)
    e.target.value = ""
  }

  async function del(mediaId: string) {
    await fetch(`/api/obras/${obraId}/vistorias`, {
      method: "DELETE", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mediaId }),
    })
    load()
  }

  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-5">
      <h3 className="text-foreground font-medium flex items-center gap-2"><Camera className="w-4 h-4 text-primary" /> Vistorias de campo</h3>
      <div className="flex flex-wrap items-end gap-3 bg-muted/60 rounded-2xl p-4">
        <div className="space-y-1">
          <Label className="text-muted-foreground text-xs">Ambiente</Label>
          <select value={envId} onChange={e => setEnvId(e.target.value)}
            className="h-9 px-3 rounded-xl bg-muted border border-border text-foreground text-sm">
            <option value="">Geral</option>
            {environments.map(e => <option key={e.id} value={e.id}>{e.nome}</option>)}
          </select>
        </div>
        <div className="space-y-1">
          <Label className="text-muted-foreground text-xs">Tipo</Label>
          <select value={tipo} onChange={e => setTipo(e.target.value)}
            className="h-9 px-3 rounded-xl bg-muted border border-border text-foreground text-sm">
            <option value="FOTO">Foto</option>
            <option value="VIDEO">Vídeo</option>
          </select>
        </div>
        <div className="space-y-1 flex-1 min-w-[200px]">
          <Label className="text-muted-foreground text-xs">Descrição (opcional)</Label>
          <Input value={desc} onChange={e => setDesc(e.target.value)} placeholder="Ex: Fachada, sala..."
            className="bg-muted border-border text-foreground" />
        </div>
        <div className="space-y-1">
          <Label className="text-muted-foreground text-xs">Arquivo</Label>
          <label className={`flex items-center gap-2 h-9 px-3 rounded-xl border cursor-pointer text-sm transition-colors ${
            uploading ? "bg-muted/70 border-border text-muted-foreground" : "bg-primary hover:bg-primary/80 border-primary text-primary-foreground"
          }`}>
            <Plus className="w-4 h-4" />
            {uploading ? "Enviando..." : "Anexar arquivo"}
            <input type="file" accept="image/*,video/*,.pdf" className="hidden" onChange={handleFile} disabled={uploading} />
          </label>
        </div>
      </div>

      {vistorias.length === 0 ? (
        <p className="text-muted-foreground text-sm text-center py-6">Nenhuma vistoria registrada.</p>
      ) : (
        <div className="space-y-3 border-l-2 border-border/60 pl-4">
          {vistorias.map(v => (
            <div key={v.id} className="relative">
              <div className="absolute -left-[1.4rem] top-1.5 w-3 h-3 rounded-full bg-primary border-2 border-background" />
              <div className="flex items-center gap-3 bg-muted rounded-2xl p-3">
                {v.tipo === "VIDEO" ? <Video className="w-4 h-4 text-purple-400" /> : <ImageIcon className="w-4 h-4 text-primary" />}
                <div className="flex-1 min-w-0">
                  <a href={v.url} target="_blank" rel="noreferrer" className="text-foreground text-sm hover:text-primary truncate block">
                    {v.descricao || v.url}
                  </a>
                  <p className="text-muted-foreground text-xs">
                    {v.environment_nome || "Geral"} · {new Date(v.createdAt).toLocaleDateString("pt-BR")}
                  </p>
                </div>
                <Button size="sm" variant="ghost" onClick={() => del(v.id)} className="text-muted-foreground/70 hover:text-red-400 h-8 w-8 p-0">
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ================= Quadros & Engravings (simplificado — só anexos) =================
function QuadrosEngravings({ obraId, initialQuadros }: {
  obraId: string; environments: Environment[]; initialQuadros: Quadro[]
}) {
  // Mantém lista de quadros como anexos (nome + url de arquivo)
  const [quadros, setQuadros] = useState<Quadro[]>(initialQuadros)
  const [uploading, setUploading] = useState<"qda" | "eng" | null>(null)
  const [urlMode, setUrlMode] = useState<"qda" | "eng" | null>(null)
  const [urlInput, setUrlInput] = useState("")
  const [urlNome, setUrlNome] = useState("")

  async function save(list: Quadro[]) {
    setQuadros(list)
    await fetch(`/api/obras/${obraId}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ quadros: list }),
    })
  }

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>, tipo: "qda" | "eng") {
    const file = e.target.files?.[0]; if (!file) return
    setUploading(tipo)
    const fd = new FormData(); fd.append("file", file)
    const res = await fetch("/api/upload", { method: "POST", body: fd })
    if (res.ok) {
      const { url } = await res.json()
      await save([...quadros, { nome: `[${tipo === "qda" ? "QDA" : "Engraving"}] ${file.name}`, descricao: url }])
    }
    setUploading(null); e.target.value = ""
  }

  function addUrl(tipo: "qda" | "eng") {
    if (!urlInput.trim()) return
    const nome = urlNome.trim() || `[${tipo === "qda" ? "QDA" : "Engraving"}] Arquivo`
    save([...quadros, { nome, descricao: urlInput.trim() }])
    setUrlInput(""); setUrlNome(""); setUrlMode(null)
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      {/* QDA */}
      <div className="bg-card rounded-xl border border-border p-6 space-y-4">
        <h3 className="text-foreground font-medium flex items-center gap-2"><Cpu className="w-4 h-4 text-amber-400" /> Quadros Elétricos (QDA)</h3>
        <p className="text-muted-foreground text-xs">Arquivos do projetista (PDF, DWG, planilha…)</p>
        <div className="flex gap-2">
          <label className={`flex-1 flex items-center justify-center gap-2 h-9 px-3 rounded-xl border cursor-pointer text-sm transition-colors ${uploading === "qda" ? "bg-muted/70 border-border text-muted-foreground" : "bg-muted border-border hover:border-primary text-muted-foreground hover:text-foreground"}`}>
            <Plus className="w-4 h-4" /> {uploading === "qda" ? "Enviando..." : "Anexar arquivo"}
            <input type="file" className="hidden" disabled={!!uploading} onChange={e => handleFile(e, "qda")} />
          </label>
          <Button size="sm" variant="outline" onClick={() => { setUrlMode(urlMode === "qda" ? null : "qda"); setUrlInput(""); setUrlNome("") }}
            className="border-border text-muted-foreground hover:text-foreground text-xs px-3">URL</Button>
        </div>
        {urlMode === "qda" && (
          <div className="space-y-2 p-3 bg-muted/50 rounded-2xl border border-border">
            <Input value={urlNome} onChange={e => setUrlNome(e.target.value)} placeholder="Nome do arquivo" className="bg-muted border-border text-foreground text-sm" />
            <div className="flex gap-2">
              <Input value={urlInput} onChange={e => setUrlInput(e.target.value)} placeholder="https://..." className="bg-muted border-border text-foreground text-sm flex-1" />
              <Button size="sm" onClick={() => addUrl("qda")} disabled={!urlInput.trim()} className="bg-primary hover:bg-primary/80 text-primary-foreground">OK</Button>
            </div>
          </div>
        )}
        {quadros.filter(q => q.nome.startsWith("[QDA]")).length === 0 ? (
          <p className="text-muted-foreground/70 text-sm">Nenhum arquivo de QDA.</p>
        ) : (
          <div className="space-y-2">
            {quadros.map((q, i) => !q.nome.startsWith("[QDA]") ? null : (
              <div key={i} className="flex items-center gap-2 bg-muted rounded-2xl p-3">
                <FileText className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <a href={q.descricao} target="_blank" rel="noreferrer" className="flex-1 text-foreground text-sm hover:text-primary truncate">{q.nome.replace("[QDA] ", "")}</a>
                <Button size="sm" variant="ghost" onClick={() => save(quadros.filter((_, x) => x !== i))}
                  className="text-muted-foreground/70 hover:text-red-400 h-7 w-7 p-0"><Trash2 className="w-3.5 h-3.5" /></Button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Engravings */}
      <div className="bg-card rounded-xl border border-border p-6 space-y-4">
        <h3 className="text-foreground font-medium flex items-center gap-2"><KeyRound className="w-4 h-4 text-primary" /> Engravings de Keypads</h3>
        <p className="text-muted-foreground text-xs">Exportações do software de programação dos keypads</p>
        <div className="flex gap-2">
          <label className={`flex-1 flex items-center justify-center gap-2 h-9 px-3 rounded-xl border cursor-pointer text-sm transition-colors ${uploading === "eng" ? "bg-muted/70 border-border text-muted-foreground" : "bg-muted border-border hover:border-primary text-muted-foreground hover:text-foreground"}`}>
            <Plus className="w-4 h-4" /> {uploading === "eng" ? "Enviando..." : "Anexar arquivo"}
            <input type="file" className="hidden" disabled={!!uploading} onChange={e => handleFile(e, "eng")} />
          </label>
          <Button size="sm" variant="outline" onClick={() => { setUrlMode(urlMode === "eng" ? null : "eng"); setUrlInput(""); setUrlNome("") }}
            className="border-border text-muted-foreground hover:text-foreground text-xs px-3">URL</Button>
        </div>
        {urlMode === "eng" && (
          <div className="space-y-2 p-3 bg-muted/50 rounded-2xl border border-border">
            <Input value={urlNome} onChange={e => setUrlNome(e.target.value)} placeholder="Nome do arquivo" className="bg-muted border-border text-foreground text-sm" />
            <div className="flex gap-2">
              <Input value={urlInput} onChange={e => setUrlInput(e.target.value)} placeholder="https://..." className="bg-muted border-border text-foreground text-sm flex-1" />
              <Button size="sm" onClick={() => addUrl("eng")} disabled={!urlInput.trim()} className="bg-primary hover:bg-primary/80 text-primary-foreground">OK</Button>
            </div>
          </div>
        )}
        {quadros.filter(q => q.nome.startsWith("[Engraving]")).length === 0 ? (
          <p className="text-muted-foreground/70 text-sm">Nenhum arquivo de engraving.</p>
        ) : (
          <div className="space-y-2">
            {quadros.map((q, i) => !q.nome.startsWith("[Engraving]") ? null : (
              <div key={i} className="flex items-center gap-2 bg-muted rounded-2xl p-3">
                <FileText className="w-4 h-4 text-primary flex-shrink-0" />
                <a href={q.descricao} target="_blank" rel="noreferrer" className="flex-1 text-foreground text-sm hover:text-primary truncate">{q.nome.replace("[Engraving] ", "")}</a>
                <Button size="sm" variant="ghost" onClick={() => save(quadros.filter((_, x) => x !== i))}
                  className="text-muted-foreground/70 hover:text-red-400 h-7 w-7 p-0"><Trash2 className="w-3.5 h-3.5" /></Button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ================= Projetos (blueprints) =================
// As 3 categorias de projeto. Escolhe uma antes de ver/lançar os arquivos —
// tudo que entra aqui fica vinculado a esta obra.
const CATEGORIAS_PROJETO = [
  { v: "Projeto de Obra", desc: "Plantas e projetos da obra física." },
  { v: "Arquivo de Software", desc: "Programação de controladoras, firmware e configs." },
  { v: "Projeto Controllares", desc: "Áudio/vídeo, rede, automação e segurança." },
] as const

function ProjetosTab({ obraId, initial }: { obraId: string; initial: Blueprint[] }) {
  const [rows, setRows] = useState<Blueprint[]>(initial)
  const [cat, setCat] = useState<string | null>(null)
  const [f, setF] = useState<Blueprint>({ data_arquivo: "", categoria: "", nome: "", versao: "", etapa: "Em projeto", drive_url: "" })

  async function save(list: Blueprint[]) {
    setRows(list)
    await fetch(`/api/obras/${obraId}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ projetos_blueprints: list }),
    })
  }
  function add() {
    if (!f.nome.trim()) return
    save([...rows, { ...f, categoria: f.categoria || cat || "" }])
    setF({ data_arquivo: "", categoria: cat ?? "", nome: "", versao: "", etapa: "Em projeto", drive_url: "" })
  }

  // Tela inicial: escolhe a categoria de projeto
  if (!cat) {
    return (
      <div className="bg-card rounded-xl border border-border p-6 space-y-4">
        <h3 className="text-foreground font-medium flex items-center gap-2"><FileStack className="w-4 h-4 text-primary" /> Projetos desta obra</h3>
        {/* Lista agrupada iOS, com chevron: são pastas para entrar, não
            cartões de destaque lado a lado. */}
        <div className="divide-y divide-hairline overflow-hidden rounded-2xl bg-surface-1">
          {CATEGORIAS_PROJETO.map(c => {
            const qtd = rows.filter(r => r.categoria === c.v).length
            return (
              <button key={c.v} onClick={() => { setCat(c.v); setF(p => ({ ...p, categoria: c.v })) }}
                className="flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-muted">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-foreground">{c.v}</p>
                  <p className="mt-0.5 truncate text-xs text-muted-fg">{c.desc}</p>
                </div>
                <span className="shrink-0 text-xs tabular-nums text-muted-fg">
                  {qtd > 0 ? qtd : "—"}
                </span>
                <ChevronRight className="h-4 w-4 shrink-0 text-muted-fg" />
              </button>
            )
          })}
        </div>
      </div>
    )
  }

  const visiveis = rows.filter(r => r.categoria === cat)

  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-4">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <h3 className="text-foreground font-medium flex items-center gap-2"><FileStack className="w-4 h-4 text-primary" /> {cat}</h3>
        <button onClick={() => setCat(null)} className="text-primary text-sm hover:opacity-70">← Categorias</button>
      </div>
      {/* Ferramentas de projeto: o que elas exportam volta para esta lista
          (categoria Projeto Controllares, com versão R00, R01…). */}
      {cat === "Projeto Controllares" && (
        <div className="grid gap-2 sm:grid-cols-2">
          <a href={`/obras/${obraId}/keypads`}
            className="flex items-center gap-3 rounded-2xl border border-border bg-surface-1 p-3.5 transition-colors hover:bg-muted">
            <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-foreground text-background"><KeyRound className="size-5" /></span>
            <span className="min-w-0 flex-1">
              <span className="block text-sm font-medium text-foreground">Estudo de keypads</span>
              <span className="block truncate text-xs text-muted-fg">Marcar na planta, conferir e gerar a planilha</span>
            </span>
            <ChevronRight className="size-4 shrink-0 text-muted-fg" />
          </a>
          <a href={`/obras/${obraId}/infra`}
            className="flex items-center gap-3 rounded-2xl border border-border bg-surface-1 p-3.5 transition-colors hover:bg-muted">
            <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-foreground text-background"><GanttChartSquare className="size-5" /></span>
            <span className="min-w-0 flex-1">
              <span className="block text-sm font-medium text-foreground">Infraestrutura</span>
              <span className="block truncate text-xs text-muted-fg">Eletrodutos na planta e prancha A1 em PDF</span>
            </span>
            <ChevronRight className="size-4 shrink-0 text-muted-fg" />
          </a>
        </div>
      )}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-2">
        <Input type="date" max="9999-12-31" value={f.data_arquivo} onChange={e => setF({ ...f, data_arquivo: e.target.value })} className="bg-muted border-border text-foreground text-xs" />
        <select value={f.categoria} onChange={e => setF({ ...f, categoria: e.target.value })}
          className="bg-muted border border-border rounded-xl text-foreground text-xs h-9 px-2 outline-none">
          <option value="">Categoria…</option>
          <option value="Projeto de Obra">Projeto de Obra</option>
          <option value="Arquivo de Software">Arquivo de Software</option>
          <option value="Projeto Controllares">Projeto Controllares</option>
        </select>
        <Input value={f.nome} onChange={e => setF({ ...f, nome: e.target.value })} placeholder="Nome" className="bg-muted border-border text-foreground text-xs" />
        <Input value={f.versao} onChange={e => setF({ ...f, versao: e.target.value })} placeholder="Versão" className="bg-muted border-border text-foreground text-xs" />
        <Input value={f.etapa} onChange={e => setF({ ...f, etapa: e.target.value })} placeholder="Etapa" className="bg-muted border-border text-foreground text-xs" />
        <Button onClick={add} disabled={!f.nome.trim()} className="bg-primary hover:bg-primary/80 text-primary-foreground"><Plus className="w-4 h-4" /></Button>
      </div>
      <UrlOrFileField value={f.drive_url} onChange={v => setF({ ...f, drive_url: v })} />

      {visiveis.length === 0 ? <p className="text-muted-foreground text-sm">Nenhum arquivo nesta categoria.</p> : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="text-muted-foreground text-xs border-b border-border/60">
              <th className="text-left py-2">Data</th><th className="text-left py-2">Categoria</th>
              <th className="text-left py-2">Nome</th><th className="text-left py-2">Versão</th><th className="text-left py-2">Etapa</th>
              <th className="text-right py-2">Drive</th><th></th>
            </tr></thead>
            <tbody>
              {visiveis.map((r, i) => (
                <tr key={i} className="border-b border-border/60/50">
                  <td className="py-2 text-muted-foreground">{r.data_arquivo || "—"}</td>
                  <td className="py-2 text-muted-foreground">{r.categoria || "—"}</td>
                  <td className="py-2 text-foreground">{r.nome}</td>
                  <td className="py-2 text-muted-foreground">{r.versao || "—"}</td>
                  <td className="py-2"><Badge variant="secondary">{r.etapa || "—"}</Badge></td>
                  <td className="py-2 text-right">
                    {r.drive_url ? <a href={r.drive_url} target="_blank" rel="noreferrer" className="text-primary hover:text-primary inline-flex items-center gap-1 text-xs"><ExternalLink className="w-3 h-3" /> Acessar</a> : "—"}
                  </td>
                  <td className="py-2 text-right">
                    <Button size="sm" variant="ghost" onClick={() => save(rows.filter((_, x) => x !== i))}
                      className="text-muted-foreground/70 hover:text-red-400 h-7 w-7 p-0"><Trash2 className="w-3.5 h-3.5" /></Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

// ================= Anexos =================
function extIcon(ext: string) {
  const e = ext.toLowerCase()
  if (["xlsx", "xls", "csv"].includes(e)) return <FileSpreadsheet className="w-5 h-5 text-green-400" />
  if (["pdf"].includes(e)) return <FileText className="w-5 h-5 text-red-400" />
  if (["dwg", "dxf"].includes(e)) return <FileIcon className="w-5 h-5 text-amber-400" />
  return <FileIcon className="w-5 h-5 text-muted-foreground" />
}
function AnexosTab({ obraId, initial }: { obraId: string; initial: Anexo[] }) {
  const [anexos, setAnexos] = useState<Anexo[]>(initial)
  const [uploading, setUploading] = useState(false)
  const [titAnexo, setTitAnexo] = useState("")

  async function save(list: Anexo[]) {
    setAnexos(list)
    // anexos_projeto: repositório EXCLUSIVO do projeto/engenharia — não mistura com obra
    await fetch(`/api/obras/${obraId}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ anexos_projeto: list }),
    })
  }

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setUploading(true)
    const fd = new FormData(); fd.append("file", file)
    const res = await fetch("/api/upload", { method: "POST", body: fd })
    if (res.ok) {
      const { url, nome } = await res.json()
      const ext = file.name.includes(".") ? file.name.split(".").pop()! : "file"
      await save([...anexos, { nome: titAnexo.trim() || file.name || nome, url, ext }])
      setTitAnexo("")
    }
    setUploading(false)
    e.target.value = ""
  }

  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h3 className="text-foreground font-medium flex items-center gap-2"><Paperclip className="w-4 h-4 text-primary" /> Anexos do projeto</h3>
        <div className="flex items-center gap-2">
          <input value={titAnexo} onChange={e => setTitAnexo(e.target.value)}
            placeholder="Título (opcional)"
            className="h-9 px-3 rounded-xl bg-muted border border-border text-sm text-foreground outline-none focus:ring-2 focus:ring-primary w-44" />
          <label className={`flex items-center gap-2 h-9 px-4 rounded-xl border cursor-pointer text-sm transition-colors ${
            uploading ? "bg-muted/70 border-border text-muted-foreground" : "bg-primary hover:bg-primary/80 border-primary text-primary-foreground"
          }`}>
            <Plus className="w-4 h-4" />
            {uploading ? "Enviando..." : "Anexar arquivo"}
            <input type="file" className="hidden" onChange={handleFile} disabled={uploading} />
          </label>
        </div>
      </div>
      <p className="text-muted-foreground/70 text-xs">Aceita qualquer tipo de arquivo (PDF, DWG, planilhas, imagens…). Limite: 20 MB. Preencha o título para diferenciar; senão usa o nome do arquivo.</p>

      {anexos.length === 0 ? <p className="text-muted-foreground text-sm">Nenhum anexo.</p> : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {anexos.map((a, i) => (
            <div key={i} className="flex items-center gap-3 bg-muted rounded-2xl p-3">
              {extIcon(a.ext)}
              <a href={a.url} target="_blank" rel="noreferrer" className="flex-1 text-foreground text-sm hover:text-primary truncate">{a.nome}</a>
              <Button size="sm" variant="ghost" onClick={() => save(anexos.filter((_, x) => x !== i))}
                className="text-muted-foreground/70 hover:text-red-400 h-8 w-8 p-0"><Trash2 className="w-3.5 h-3.5" /></Button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ================= Cronograma / Gantt =================
const MESES_PT = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"]

function GanttTabView({ obraId }: { obraId: string }) {
  const [tasks, setTasks] = useState<GanttTask[]>([])
  const [titulo, setTitulo] = useState(""); const [raia, setRaia] = useState("EMPRESA")
  const [ini, setIni] = useState(""); const [fim, setFim] = useState("")
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)

  const load = useCallback(async () => {
    const res = await fetch(`/api/obras/${obraId}/gantt`)
    if (res.ok) setTasks((await res.json()).tasks)
  }, [obraId])
  useEffect(() => { load() }, [load])

  function resetForm() {
    setTitulo(""); setIni(""); setFim(""); setRaia("EMPRESA")
    setShowForm(false); setEditingId(null)
  }

  function openEdit(t: GanttTask) {
    setEditingId(t.id); setTitulo(t.titulo); setRaia(t.raia)
    setIni(t.data_inicio); setFim(t.data_fim); setShowForm(true)
  }

  async function add() {
    if (!titulo.trim() || !ini || !fim) return
    if (editingId) {
      await fetch(`/api/obras/${obraId}/gantt`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ taskId: editingId, titulo, raia, data_inicio: ini, data_fim: fim }),
      })
    } else {
      await fetch(`/api/obras/${obraId}/gantt`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ titulo, raia, data_inicio: ini, data_fim: fim }),
      })
    }
    resetForm(); load()
  }
  async function del(taskId: string) {
    await fetch(`/api/obras/${obraId}/gantt`, {
      method: "DELETE", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ taskId }),
    })
    if (editingId === taskId) resetForm()
    load()
  }

  // Calcular janela de meses visíveis
  const today = new Date()
  const allDates = tasks.flatMap(t => [new Date(t.data_inicio + "T00:00:00"), new Date(t.data_fim + "T00:00:00")])
  const minDate = allDates.length ? new Date(Math.min(...allDates.map(d => d.getTime()))) : new Date(today.getFullYear(), today.getMonth(), 1)
  const maxDate = allDates.length ? new Date(Math.max(...allDates.map(d => d.getTime()))) : new Date(today.getFullYear(), today.getMonth() + 5, 28)

  // Gerar array de meses entre min e max (com margem de 1 mês em cada lado)
  const startMonth = new Date(minDate.getFullYear(), minDate.getMonth() - 1, 1)
  const endMonth = new Date(maxDate.getFullYear(), maxDate.getMonth() + 2, 1)
  const months: { year: number; month: number; label: string; days: number }[] = []
  const cur = new Date(startMonth)
  while (cur < endMonth) {
    const days = new Date(cur.getFullYear(), cur.getMonth() + 1, 0).getDate()
    months.push({ year: cur.getFullYear(), month: cur.getMonth(), label: MESES_PT[cur.getMonth()], days })
    cur.setMonth(cur.getMonth() + 1)
  }

  // Total de dias no grid
  const gridStart = startMonth.getTime()
  const gridEnd = endMonth.getTime()
  const totalDays = (gridEnd - gridStart) / 86400000

  // Posição e largura em %
  const taskPos = (d: string) => {
    const ms = new Date(d + "T00:00:00").getTime() - gridStart
    return Math.max(0, Math.min(100, (ms / (totalDays * 86400000)) * 100))
  }
  const taskWidth = (a: string, b: string) => {
    const msA = new Date(a + "T00:00:00").getTime()
    const msB = new Date(b + "T23:59:59").getTime()
    return Math.max(0.5, ((msB - msA) / (totalDays * 86400000)) * 100)
  }

  // Hoje em %
  const todayPct = ((today.getTime() - gridStart) / (totalDays * 86400000)) * 100

  return (
    <div className="bg-card rounded-xl border border-border overflow-hidden">
      {/* Header barra */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-border">
        <h3 className="text-foreground font-semibold flex items-center gap-2"><GanttChartSquare className="w-4 h-4 text-primary" /> Cronograma</h3>
        <Button size="sm" onClick={() => { if (showForm) resetForm(); else setShowForm(true) }} className="bg-primary hover:bg-primary/80 text-primary-foreground gap-1.5 text-xs">
          <Plus className="w-3.5 h-3.5" /> Nova tarefa
        </Button>
      </div>

      {/* Formulário add/editar */}
      {showForm && (
        <div className="flex flex-wrap items-end gap-2 p-4 bg-muted/60 border-b border-border">
          <Input value={titulo} onChange={e => setTitulo(e.target.value)} placeholder="Nome da tarefa"
            className="bg-muted border-border text-foreground flex-1 min-w-[140px] h-8 text-sm" />
          <select value={raia} onChange={e => setRaia(e.target.value)}
            className="h-8 px-3 rounded-xl bg-muted border border-border text-foreground text-sm">
            {RAIAS.map(r => <option key={r.id} value={r.id}>{r.label}</option>)}
          </select>
          <Input type="date" max="9999-12-31" value={ini} onChange={e => setIni(e.target.value)} className="bg-muted border-border text-foreground h-8 text-sm" />
          <Input type="date" max="9999-12-31" value={fim} onChange={e => setFim(e.target.value)} className="bg-muted border-border text-foreground h-8 text-sm" />
          <Button onClick={add} disabled={!titulo.trim() || !ini || !fim} className="bg-primary hover:bg-primary/80 text-primary-foreground h-8 text-xs px-3">
            {editingId ? "Salvar" : "Adicionar"}
          </Button>
          {editingId && (
            <Button onClick={resetForm} variant="outline" className="h-8 text-xs px-3">Cancelar</Button>
          )}
        </div>
      )}

      {tasks.length === 0 ? (
        <div className="py-16 text-center">
          <GanttChartSquare className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground text-sm">Nenhuma tarefa no cronograma.</p>
          <p className="text-muted-foreground/70 text-xs mt-1">Clique em "Nova tarefa" para começar.</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          {/* Grid layout: coluna fixa (raia/label) + coluna scrollável (barras) */}
          <div style={{ minWidth: 700 }}>
            {/* Cabeçalho de meses */}
            <div className="flex border-b border-border">
              {/* Label col */}
              <div className="w-40 flex-shrink-0 px-4 py-2 border-r border-border">
                <span className="text-muted-foreground text-xs font-semibold uppercase tracking-wider">Responsável</span>
              </div>
              {/* Meses */}
              <div className="flex-1 relative flex">
                {months.map((m, i) => (
                  <div key={i} className="border-r border-border/50 px-2 py-2 text-center"
                    style={{ flex: m.days }}>
                    <span className="text-muted-foreground text-xs font-semibold">
                      {m.label} {months.length > 8 ? "" : m.year}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Raias */}
            {RAIAS.map(r => {
              const rTasks = tasks.filter(t => t.raia === r.id)
              return (
                <div key={r.id} className="border-b border-border/50 last:border-0">
                  {/* Linha de cabeçalho da raia */}
                  <div className="flex items-stretch">
                    <div className="w-40 flex-shrink-0 px-4 py-3 border-r border-border flex items-center gap-2">
                      <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${r.color}`} />
                      <span className="text-muted-foreground text-sm font-medium">{r.label}</span>
                    </div>
                    <div className="flex-1 relative min-h-[2.5rem]">
                      {/* Faixas de meses (fundo alternado) */}
                      <div className="absolute inset-0 flex pointer-events-none">
                        {months.map((m, i) => (
                          <div key={i} className={`border-r border-border/50 ${i % 2 === 0 ? "bg-white/[0.01]" : ""}`}
                            style={{ flex: m.days }} />
                        ))}
                      </div>
                      {/* Linha de hoje */}
                      {todayPct >= 0 && todayPct <= 100 && (
                        <div className="absolute top-0 bottom-0 w-px bg-primary/40 z-10 pointer-events-none"
                          style={{ left: `${todayPct}%` }} />
                      )}
                      {/* Tarefas */}
                      {rTasks.length === 0 ? (
                        <div className="flex items-center h-10 px-3">
                          <span className="text-muted-foreground text-xs">— sem tarefas</span>
                        </div>
                      ) : (
                        <div className="py-1.5 space-y-1.5 px-1 relative z-10">
                          {rTasks.map(t => (
                            <div key={t.id} className="flex items-center h-8 relative group">
                              <button type="button" onClick={() => openEdit(t)} title="Clique para editar"
                                className={`absolute h-7 ${r.color} rounded-2xl flex items-center px-3 overflow-hidden shadow-md transition-all group-hover:brightness-110 cursor-pointer text-left`}
                                style={{ left: `${taskPos(t.data_inicio)}%`, width: `${taskWidth(t.data_inicio, t.data_fim)}%` }}>
                                <span className="text-foreground text-xs font-medium truncate whitespace-nowrap">{t.titulo}</span>
                              </button>
                              {/* Botão delete (fora da barra, no hover) */}
                              <button onClick={() => del(t.id)}
                                className="absolute right-1 opacity-0 group-hover:opacity-100 transition-opacity z-20 w-5 h-5 rounded bg-card/80 flex items-center justify-center text-red-400 hover:text-red-300">
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )
            })}

            {/* Rodapé legenda */}
            <div className="flex items-center gap-6 px-4 py-3 border-t border-border bg-muted/30">
              {RAIAS.map(r => (
                <div key={r.id} className="flex items-center gap-1.5">
                  <span className={`w-3 h-3 rounded ${r.color}`} />
                  <span className="text-muted-foreground text-xs">{r.label}</span>
                </div>
              ))}
              <div className="flex items-center gap-1.5 ml-auto">
                <span className="w-px h-4 bg-primary/40 inline-block" />
                <span className="text-muted-foreground text-xs">Hoje</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
