"use client"

/**
 * Bloco de notas da obra, no formato do Google Keep: vários cartões em vez
 * de um textarea gigante.
 *
 * Guarda tudo como JSON dentro do mesmo campo `notas` que já existia — assim
 * não precisa de migração. Nota antiga (texto puro) é convertida na leitura,
 * sem perder nada do que já estava escrito.
 */
import { useState, useMemo } from "react"
import { Plus, Trash2, Pin, PinOff } from "lucide-react"

export interface Nota {
  id: string
  titulo: string
  texto: string
  cor: string
  fixada: boolean
  atualizadoEm: string
}

/** Cores de fundo dos cartões, no espírito do Keep. */
const CORES = [
  { v: "padrao", classe: "bg-surface-1" },
  { v: "amarelo", classe: "bg-ios-yellow/12" },
  { v: "verde", classe: "bg-ios-green/12" },
  { v: "azul", classe: "bg-ios-blue/12" },
  { v: "roxo", classe: "bg-ios-purple/12" },
  { v: "vermelho", classe: "bg-ios-red/12" },
]
const classeDaCor = (c: string) => CORES.find(x => x.v === c)?.classe ?? CORES[0].classe

/** Aceita o formato novo (JSON) e o antigo (texto puro). */
export function lerNotas(bruto: string | null | undefined): Nota[] {
  if (!bruto?.trim()) return []
  try {
    const j = JSON.parse(bruto)
    if (Array.isArray(j)) return j as Nota[]
  } catch {
    // Não é JSON: era o textarea único de antes.
  }
  return [{
    id: "legado",
    titulo: "",
    texto: bruto,
    cor: "padrao",
    fixada: false,
    atualizadoEm: new Date().toISOString(),
  }]
}

export function BlocoNotas({ valor, onChange }: {
  valor: string | null | undefined
  onChange: (novoJson: string) => void
}) {
  const notas = useMemo(() => lerNotas(valor), [valor])
  const [aberta, setAberta] = useState<string | null>(null)

  const salvar = (lista: Nota[]) => onChange(JSON.stringify(lista))

  function nova() {
    const n: Nota = {
      id: crypto.randomUUID(),
      titulo: "",
      texto: "",
      cor: "padrao",
      fixada: false,
      atualizadoEm: new Date().toISOString(),
    }
    salvar([n, ...notas])
    setAberta(n.id)
  }

  function editar(id: string, patch: Partial<Nota>) {
    salvar(notas.map(n => n.id === id ? { ...n, ...patch, atualizadoEm: new Date().toISOString() } : n))
  }

  function excluir(id: string) {
    salvar(notas.filter(n => n.id !== id))
    if (aberta === id) setAberta(null)
  }

  // Fixadas sempre no topo; depois, a mais recente primeiro.
  const ordenadas = [...notas].sort((a, b) => {
    if (a.fixada !== b.fixada) return a.fixada ? -1 : 1
    return (b.atualizadoEm ?? "").localeCompare(a.atualizadoEm ?? "")
  })

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-3 px-1">
        <div>
          <h3 className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-fg">Notas</h3>
          <p className="mt-0.5 text-xs text-muted-fg">Anotações internas, o cliente não vê.</p>
        </div>
        <button type="button" onClick={nova}
          className="flex h-9 items-center gap-1.5 rounded-full bg-foreground px-4 text-sm font-medium text-background transition-opacity hover:opacity-90 active:scale-[0.98]">
          <Plus className="h-4 w-4" /> Nova nota
        </button>
      </div>

      {ordenadas.length === 0 ? (
        <button type="button" onClick={nova}
          className="w-full rounded-2xl bg-surface-1 px-5 py-10 text-center transition-colors hover:bg-muted">
          <p className="text-sm font-medium text-foreground">Nenhuma nota ainda</p>
          <p className="mt-0.5 text-xs text-muted-fg">Toque para escrever a primeira.</p>
        </button>
      ) : (
        // Mosaico: cada nota ocupa a altura do próprio conteúdo.
        <div className="columns-1 gap-3 sm:columns-2 lg:columns-3 [&>*]:mb-3 [&>*]:break-inside-avoid">
          {ordenadas.map(n => {
            const estaAberta = aberta === n.id
            return (
              <div key={n.id}
                className={`group rounded-2xl ${classeDaCor(n.cor)} p-3.5 transition-shadow hover:shadow-sm`}>
                <div className="flex items-start gap-2">
                  <input
                    value={n.titulo}
                    onChange={e => editar(n.id, { titulo: e.target.value })}
                    onFocus={() => setAberta(n.id)}
                    placeholder="Título"
                    className="min-w-0 flex-1 bg-transparent text-sm font-semibold text-foreground outline-none placeholder:font-normal placeholder:text-muted-fg"
                  />
                  <button type="button" onClick={() => editar(n.id, { fixada: !n.fixada })}
                    title={n.fixada ? "Desafixar" : "Fixar no topo"}
                    className={`shrink-0 transition-colors ${n.fixada ? "text-ios-blue" : "text-muted-fg opacity-0 group-hover:opacity-100"}`}>
                    {n.fixada ? <Pin className="h-4 w-4" /> : <PinOff className="h-4 w-4" />}
                  </button>
                </div>

                <textarea
                  value={n.texto}
                  onChange={e => editar(n.id, { texto: e.target.value })}
                  onFocus={() => setAberta(n.id)}
                  placeholder="Escreva aqui…"
                  rows={estaAberta ? 8 : Math.min(8, Math.max(2, n.texto.split("\n").length))}
                  className="mt-1.5 w-full resize-none bg-transparent text-sm leading-relaxed text-foreground outline-none placeholder:text-muted-fg"
                />

                <div className="mt-1 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 opacity-0 transition-opacity group-hover:opacity-100">
                    {CORES.map(c => (
                      <button key={c.v} type="button" onClick={() => editar(n.id, { cor: c.v })}
                        title={c.v}
                        className={`h-4 w-4 rounded-full ring-1 ring-inset ring-black/10 ${c.classe} ${
                          n.cor === c.v ? "ring-2 ring-foreground/40" : ""
                        }`} />
                    ))}
                  </div>
                  <button type="button" onClick={() => excluir(n.id)} title="Excluir nota"
                    className="shrink-0 text-muted-fg opacity-0 transition-opacity hover:text-ios-red group-hover:opacity-100">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
