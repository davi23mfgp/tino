﻿"use client"

import { useState, useEffect, useCallback, use } from "react"
import { PageLoader } from "@/components/ui/bouncing-dots"
import { useRouter, useSearchParams } from "next/navigation"
import { MoreHorizontal,
  ArrowLeft, HardHat, Save, MapPin, Crosshair, ExternalLink, Plus, Trash2,
  KeyRound, Eye, EyeOff, Wrench, FileText, Calendar, RefreshCw, ShieldCheck, Paperclip, Pencil,
  Users, Building2, Ruler, UserCheck, X, ChevronDown, Check, Search,
} from "lucide-react"
import EngenhariaTab from "./engenharia-tab"
import { BlocoNotas } from "./bloco-notas"
import { ChecklistTecnico, type ChecklistTecnicoItem } from "@/components/checklist-tecnico"
import DimensionamentoObra from "./dimensionamento-obra"
import { ObraMobileSheet } from "./mobile-sheet"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent } from "@/components/ui/tabs"
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem,
} from "@/components/ui/dropdown-menu"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog"
import { useConfirmar } from "@/components/confirmar"
import { brl } from "@/lib/formato"

// Navegação única da obra: itens diretos + itens com submenu (dropdown)
type ObraSub = { v: string; l: string }
type ObraNavItem = { value: string; label: string; subs?: ObraSub[] }

const OBRA_NAV: ObraNavItem[] = [
  { value: "geral", label: "Resumo & Geral", subs: [
    { v: "dados", l: "Dados Gerais" }, { v: "notas", l: "Notas" }, { v: "tarefas", l: "Tarefas" },
    { v: "endereco", l: "Endereço & Logística" }, { v: "acessos", l: "Acesso Externo" }, { v: "relatorios", l: "Relatórios" },
  ] },
  { value: "agenda", label: "Agendamentos" },
  { value: "suporte", label: "Suporte", subs: [
    { v: "senhas", l: "Senhas" }, { v: "manutencoes", l: "Manutenções" }, { v: "consertos", l: "Consertos" },
  ] },
  { value: "engenharia", label: "Engenharia", subs: [
    { v: "ambientes", l: "Ambientes/Produtos" }, { v: "vistorias", l: "Vistorias" }, { v: "quadros", l: "Quadro de Automação" },
    { v: "projetos", l: "Projetos" }, { v: "anexos", l: "Anexos" }, { v: "gantt", l: "Cronograma" },
  ] },
  { value: "propostas", label: "Propostas" },
  { value: "dimensionamento", label: "Dimensionamento" },
]

const ETAPAS_OBRA = [
  "Nova obra", "Ampliação", "Em projeto", "Em tubulações",
  "Em cabeamentos", "Em instalação", "Em programação", "Em entrega",
]
const GRUPO_TIPOS = ["Nenhum", "Edifício", "Apto"]

interface UserLite { id: string; nome: string; email: string; role: string }
interface AcessoExterno { nome: string; papel: string; login?: string; senha?: string; validade?: string }
interface Agendamento { titulo: string; data: string; equipe?: string; google_event_id?: string }
interface RelatoriosConfig { vistorias: boolean; instalacao: boolean; manutencao: boolean; contatos: string[] }
interface Credencial {
  id: string; tipo_equipamento: string; login: string | null
  observacoes: string | null; createdAt: string
  anexo_url: string | null; tem_senha: boolean; tem_mac: boolean; tem_ip: boolean
}
interface Revelado { senha: string | null; mac: string | null; ip: string | null }
interface ParceiroLite {
  id: string; name: string; type: string; company_name: string | null; phone: string | null
}
interface Manutencao {
  id: string; titulo: string; descricao: string | null; status: string; createdAt: string
}

interface Obra {
  id: string; client_name: string; etapa: string | null
  data_inicio_garantia?: string | null
  telegram_chat_id?: string | null
  resp_tecnico_id: string | null
  respComercial: { nome: string } | null
  respTecnico: { nome: string } | null
  construtora: string | null
  previsao_inicio: string | null; previsao_finalizacao_instalacao: string | null; grupo_tipo: string | null
  colaboradores_ids: string[]; compra_liberada: boolean
  physical_progress_percentage?: number | null
  capa_url: string | null; foto_atual_url: string | null
  cep: string | null; rua: string | null; numero: string | null; bairro: string | null
  cidade: string | null; complemento: string | null; ponto_referencia: string | null
  address: string | null; latitude: number | null; longitude: number | null
  acessos_externos: AcessoExterno[] | null
  relatorios_config: RelatoriosConfig | null
  agendamentos: Agendamento[] | null
  projetos_blueprints: Blueprint[] | null
  anexos: Anexo[] | null
  anexos_projeto: Anexo[] | null
  checklist_tecnico: ChecklistTecnicoItem[] | null
  quadros: Quadro[] | null
  dimensionamento: Record<string, unknown> | null
  notas: string | null
  originProposal: { numero: string; dias_garantia?: number | null; anos_garantia?: number | null } | null
  environments: EngEnvironment[]
  proposals: PropostaLite[]
}

// Tipos auxiliares para a Aba Engenharia e Propostas
interface Blueprint { data_arquivo: string; categoria: string; nome: string; versao: string; etapa: string; drive_url: string }
interface Anexo { nome: string; url: string; ext: string }
interface Quadro { nome: string; descricao: string }
interface EngEnvironment {
  id: string; nome: string
  proposalItems: Array<{
    id: string; quantidade: number; is_aditivo: boolean
    product: { nome: string; sku: string; imagem_url?: string | null } | null
    kit: { nome: string } | null
    category: { nome: string } | null
  }>
  _count: { inspectionsMedia: number }
}
interface PropostaLite { id: string; numero: string; status: string; valor_total: number; createdAt: string }

export default function ObraPainelPage({ params }: { params: Promise<{ id: string }> }) {
  const confirmar = useConfirmar()
  const { id } = use(params)
  const router = useRouter()
  const searchParams = useSearchParams()

  const [obra, setObra] = useState<Obra | null>(null)
  const [form, setForm] = useState<Partial<Obra>>({})
  const [formOriginal, setFormOriginal] = useState("")
  const [users, setUsers] = useState<UserLite[]>([])
  const [enviandoRelatorio, setEnviandoRelatorio] = useState(false)
  const [relatorioMsg, setRelatorioMsg] = useState<{ tipo: "ok" | "erro"; texto: string } | null>(null)
  const [credenciais, setCredenciais] = useState<Credencial[]>([])
  const [manutencoes, setManutencoes] = useState<Manutencao[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [savedToast, setSavedToast] = useState(false)
  const [parceirosObra, setParceirosObra] = useState<ParceiroLite[]>([])
  const [todosParceiros, setTodosParceiros] = useState<ParceiroLite[]>([])
  const [parceirosOpen, setParceirosOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("geral")
  const [geralSub, setGeralSub] = useState("dados")
  const [suporteSub, setSuporteSub] = useState("senhas")
  const [engSub, setEngSub] = useState("ambientes")
  // Mobile: sheet resumido (mockup) por padrão; painel completo sob demanda
  const [mobileFull, setMobileFull] = useState(false)
  /* Guarda a saída pendente enquanto a pergunta está na tela. */
  const [confirmarSaida, setConfirmarSaida] = useState<null | { acao: () => void }>(null)

  // Exclusão de obra é só do ADMIN — o botão nem aparece para os outros.
  const [userRole, setUserRole] = useState("")
  useEffect(() => {
    fetch("/api/auth/me").then(r => r.ok ? r.json() : null)
      .then(d => setUserRole(d?.user?.role ?? "")).catch(() => {})
  }, [])
  const [confirmExcluirObra, setConfirmExcluirObra] = useState(false)
  const [excluindoObra, setExcluindoObra] = useState(false)
  const [erroExcluirObra, setErroExcluirObra] = useState("")

  async function excluirObra() {
    setExcluindoObra(true); setErroExcluirObra("")
    try {
      const r = await fetch(`/api/obras/${id}`, { method: "DELETE" })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { setErroExcluirObra(j.error || "Não foi possível excluir."); return }
      // /obras é a listagem crua de teste da Fase 5; a tela de verdade das
      // obras é o Operacional.
      router.push("/operacional")
    } catch {
      setErroExcluirObra("Falha de conexão.")
    } finally { setExcluindoObra(false) }
  }

  // Modo projeto (?modo=projeto, vindo do kanban de Projetos): visão enxuta —
  // só Resumo & Geral + Engenharia (que inclui Anexos). Obra completa fica fora.
  const modoProjeto = searchParams.get("modo") === "projeto"
  const nav = modoProjeto
    ? OBRA_NAV.filter(n => n.value === "geral" || n.value === "engenharia")
    : OBRA_NAV

  // Deep-link: ?tab=engenharia&sub=projetos abre direto a aba/sub-aba certa
  useEffect(() => {
    if (searchParams.get("modo") === "projeto") setMobileFull(true)
    const tab = searchParams.get("tab")
    const sub = searchParams.get("sub")
    if (!tab) return
    setActiveTab(tab)
    setMobileFull(true)
    if (sub) {
      if (tab === "geral") setGeralSub(sub)
      else if (tab === "suporte") setSuporteSub(sub)
      else if (tab === "engenharia") setEngSub(sub)
    }
  }, [searchParams])

  const loadCredenciais = useCallback(async () => {
    const res = await fetch(`/api/obras/${id}/credenciais`)
    if (res.ok) setCredenciais((await res.json()).credenciais || [])
  }, [id])

  const loadParceiros = useCallback(async () => {
    const res = await fetch(`/api/obras/${id}/parceiros`)
    if (res.ok) setParceirosObra((await res.json()).parceiros || [])
  }, [id])

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [oRes, uRes, cRes, mRes] = await Promise.all([
        fetch(`/api/obras/${id}`),
        fetch(`/api/usuarios`),
        fetch(`/api/obras/${id}/credenciais`),
        fetch(`/api/manutencoes?obraId=${id}`),
      ])
      if (!oRes.ok) { router.push("/operacional"); return }
      const o = await oRes.json()
      setObra(o)
      const carregado = {
        ...o,
        previsao_inicio: o.previsao_inicio ? o.previsao_inicio.split("T")[0] : "",
        previsao_finalizacao_instalacao: o.previsao_finalizacao_instalacao ? o.previsao_finalizacao_instalacao.split("T")[0] : "",
        colaboradores_ids: o.colaboradores_ids || [],
        acessos_externos: o.acessos_externos || [],
        agendamentos: o.agendamentos || [],
        relatorios_config: o.relatorios_config || { vistorias: false, instalacao: false, manutencao: false, contatos: [] },
      }
      setForm(carregado)
      // Cópia do que veio do servidor: é contra ela que "mudou algo?" é medido.
      setFormOriginal(JSON.stringify(carregado))
      setUsers((await uRes.json()).users || [])
      setCredenciais((await cRes.json()).credenciais || [])
      setManutencoes((await mRes.json()).tickets || [])
      // Parceiros vinculados
      const pRes = await fetch(`/api/obras/${id}/parceiros`)
      if (pRes.ok) setParceirosObra((await pRes.json()).parceiros || [])
    } finally {
      setLoading(false)
    }
  }, [id, router])

  useEffect(() => { load() }, [load])

  function set<K extends keyof Obra>(key: K, value: Obra[K]) {
    setForm(f => ({ ...f, [key]: value }))
  }

  async function salvar() {
    setSaving(true)
    try {
      // A Aba Engenharia salva esses campos por conta própria — não reenviar
      // aqui para não sobrescrever edições recentes com valores antigos.
      const { projetos_blueprints: _p, anexos: _a, quadros: _q, environments: _e, proposals: _pr, ...payload } = form
      void _p; void _a; void _q; void _e; void _pr
      const res = await fetch(`/api/obras/${id}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })
      if (res.ok) {
        setSavedToast(true)
        setTimeout(() => setSavedToast(false), 2500)
        await load()
      }
    } finally {
      setSaving(false)
    }
  }

  // ---- CEP autocomplete (ViaCEP) ----
  async function buscarCep(cep: string) {
    const limpo = cep.replace(/\D/g, "")
    if (limpo.length !== 8) return
    try {
      const res = await fetch(`https://viacep.com.br/ws/${limpo}/json/`)
      const d = await res.json()
      if (!d.erro) {
        setForm(f => ({
          ...f,
          rua: d.logradouro || f.rua,
          bairro: d.bairro || f.bairro,
          cidade: d.localidade ? `${d.localidade}/${d.uf}` : f.cidade,
        }))
      }
    } catch { /* offline: ignora */ }
  }

  // ---- GPS ----
  async function fixarGps() {
    if (!navigator.geolocation) { await confirmar({ titulo: "GPS não disponível neste navegador", apenasAviso: true }); return }
    navigator.geolocation.getCurrentPosition(
      pos => {
        set("latitude", pos.coords.latitude)
        set("longitude", pos.coords.longitude)
      },
      () => confirmar({ titulo: "Não foi possível obter a localização", apenasAviso: true }),
    )
  }

  // Geocode do endereço → lat/lng (Nominatim/OpenStreetMap, grátis, sem chave)
  const [geoBusca, setGeoBusca] = useState("")
  const [geoLoading, setGeoLoading] = useState(false)
  async function buscarEndereco() {
    const q = geoBusca.trim()
    if (!q) return
    setGeoLoading(true)
    try {
      const r = await fetch(`https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=br&addressdetails=1&q=${encodeURIComponent(q)}`, {
        headers: { "Accept-Language": "pt-BR" },
      })
      const arr = await r.json()
      if (Array.isArray(arr) && arr[0]) {
        set("latitude", parseFloat(arr[0].lat))
        set("longitude", parseFloat(arr[0].lon))
        if (arr[0].display_name && !form.address) set("address", arr[0].display_name)
      } else {
        await confirmar({
          titulo: "Endereço não encontrado",
          texto: "Tente ser mais específico: rua, número e cidade.",
          apenasAviso: true,
        })
      }
    } catch {
      await confirmar({ titulo: "Falha ao buscar o endereço.", apenasAviso: true })
    } finally { setGeoLoading(false) }
  }

  if (loading) return <div className="p-6 flex justify-center"><PageLoader /></div>
  if (!obra) return null

  const rc = form.relatorios_config as RelatoriosConfig

  /* Compara o formulário com a cópia carregada. JSON.stringify basta: os
     campos são dados simples e a ordem das chaves não muda entre os dois. */
  const temAlteracao = !!formOriginal && JSON.stringify(form) !== formOriginal

  /* Sair da obra com alteração pendente. A ação que o botão ia fazer fica
     guardada aqui e só acontece depois da resposta. */
  const sairDaObra = (acao: () => void) => {
    if (temAlteracao) setConfirmarSaida({ acao })
    else acao()
  }

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto space-y-5 pb-32 md:pb-28">
      {/* Toast de confirmação */}
      {savedToast && (
        <div className="fixed top-4 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 rounded-xl bg-ios-green px-5 py-3 text-sm font-medium text-background shadow-lg">
          <Save className="h-4 w-4" /> Alterações salvas!
        </div>
      )}

      {/* Sair com alteração pendente pergunta, no meio da tela.
          Antes um bloco flutuava no canto o tempo todo enquanto se digitava —
          ocupava espaço e não impedia nada: quem saía perdia o que escreveu do
          mesmo jeito. Agora o Salvar mora no cabeçalho, e a pergunta aparece
          só na hora em que ela importa. */}
      <Dialog open={!!confirmarSaida} onOpenChange={o => { if (!o) setConfirmarSaida(null) }}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Sair sem salvar?</DialogTitle></DialogHeader>
          <p className="px-5 pb-1 text-[13px] text-muted-fg sm:px-6">
            Você mexeu nesta obra e ainda não salvou. O que faço com as alterações?
          </p>
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setConfirmarSaida(null)}>Continuar editando</Button>
            <Button variant="outline" className="text-ios-red"
              onClick={() => { const ir = confirmarSaida?.acao; setConfirmarSaida(null); ir?.() }}>
              Descartar e sair
            </Button>
            <Button disabled={saving} className="gap-1.5"
              onClick={async () => {
                const ir = confirmarSaida?.acao
                await salvar()
                setConfirmarSaida(null)
                ir?.()
              }}>
              {saving ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />} Salvar e sair
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Cabeçalho, estilo iOS (topo tipo sheet no mobile). Salvar fica no topo. */}
      {(() => {
        const podeSalvar = mobileFull && activeTab !== "dimensionamento"
        return (
      <div>
        <div className="flex items-center justify-between md:hidden mb-3">
          <button onClick={() => sairDaObra(() => router.push("/operacional"))}
            className="text-ios-blue text-[15px] active:opacity-70">Voltar</button>
          <span className="text-[11px] uppercase tracking-widest text-muted-fg truncate max-w-[45%]">Obra · {obra.client_name}</span>
          <span className="w-10" />
        </div>
        <div className="flex items-start gap-3">
          <Button variant="ghost" size="icon" onClick={() => sairDaObra(() => router.push("/operacional"))}
            className="hidden md:flex text-muted-foreground hover:text-foreground h-8 w-8 flex-shrink-0 mt-1">
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex-1 min-w-0">
            <h1 className="text-[28px] md:text-xl font-bold md:font-semibold text-foreground tracking-tight leading-tight truncate">{obra.client_name}</h1>
            <div className="flex flex-wrap items-center gap-2 mt-1">
              <Badge variant="outline" className="text-xs font-normal">{obra.etapa || "Nova obra"}</Badge>
              {/* Garantia: só existe depois do check de instalação. Mostra o que
                  ainda resta, que é o que o time precisa saber ao atender. */}
              {(() => {
                const dias = obra.originProposal?.dias_garantia
                  ?? (obra.originProposal?.anos_garantia ? obra.originProposal.anos_garantia * 365 : null)
                if (!dias || !obra.data_inicio_garantia) return null
                const fim = new Date(obra.data_inicio_garantia)
                fim.setDate(fim.getDate() + dias)
                const restam = Math.ceil((fim.getTime() - Date.now()) / 86400000)
                const vigente = restam > 0
                return (
                  <Badge variant="outline"
                    className={`text-xs font-normal ${vigente ? "border-success/40 text-success" : "border-destructive/40 text-destructive"}`}
                    title={`Início em ${new Date(obra.data_inicio_garantia).toLocaleDateString("pt-BR")} · ${dias} dias`}>
                    {vigente ? `Garantia: ${restam} dias` : "Garantia encerrada"}
                  </Badge>
                )
              })()}
              <span className="text-muted-fg text-xs truncate">
                {obra.originProposal ? `Origem: ${obra.originProposal.numero}` : "Obra manual"}
                {obra.respComercial && ` · ${obra.respComercial.nome}`}
              </span>
            </div>
          </div>
          {/* Salvar mora aqui, junto do nome da obra, e só aparece quando há o
              que salvar. Antes vivia num bloco flutuante no canto da tela. */}
          {temAlteracao && activeTab !== "dimensionamento" && (
            <div className="flex flex-shrink-0 items-center gap-1.5">
              <Button variant="ghost" size="sm" className="h-9 text-muted-fg"
                onClick={() => { if (formOriginal) setForm(JSON.parse(formOriginal)) }}>
                Descartar
              </Button>
              <Button size="sm" className="h-9 gap-1.5" onClick={salvar} disabled={saving}>
                {saving ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />} Salvar
              </Button>
            </div>
          )}
          {/* Excluir sai do topo: é a ação mais destrutiva da tela e estava do
              mesmo tamanho e peso das outras. Vai para o menu, só do Admin. */}
          {userRole === "ADMIN" && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon"
                  className="hidden h-9 w-9 flex-shrink-0 border-border text-muted-foreground/70 hover:text-foreground md:inline-flex">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem onClick={() => setConfirmExcluirObra(true)}
                  className="text-ios-red focus:text-ios-red">
                  <Trash2 className="h-3.5 w-3.5" /> Excluir obra
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>
        )
      })()}

      {/* ══ MOBILE: sheet resumido no formato do mockup ══ */}
      {!mobileFull && (
        <div className="md:hidden">
          <ObraMobileSheet
            obraId={id}
            clientName={obra.client_name}
            etapa={obra.etapa}
            construtora={obra.construtora}
            address={obra.address}
            latitude={obra.latitude}
            longitude={obra.longitude}
            respTecnico={obra.respTecnico?.nome ?? null}
            previsaoInicio={(form.previsao_inicio as string) || null}
            progresso={obra.physical_progress_percentage}
            anexos={(form.anexos as Anexo[]) ?? obra.anexos ?? []}
            environments={obra.environments ?? []}
            proposals={obra.proposals ?? []}
            credenciais={credenciais}
            acessos={(form.acessos_externos as AcessoExterno[]) ?? []}
            parceiros={parceirosObra}
            onOpenFull={(tab, sub) => {
              setMobileFull(true)
              if (tab) setActiveTab(tab)
              if (sub) {
                if (tab === "geral") setGeralSub(sub)
                else if (tab === "suporte") setSuporteSub(sub)
                else if (tab === "engenharia") setEngSub(sub)
              }
            }}
          />
        </div>
      )}

      {/* ABAS PRINCIPAIS, barra única; itens com submenu abrem dropdown ao clicar */}
      <div className={mobileFull ? "" : "hidden md:block"}>
      {mobileFull && (
        <button onClick={() => setMobileFull(false)}
          className="md:hidden flex items-center gap-1 text-ios-blue text-[15px] mb-2 active:opacity-70">
          <ChevronDown className="w-4 h-4 rotate-90" /> Resumo da obra
        </button>
      )}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-2" style={{ scrollSnapType: "x mandatory" }}>
          {nav.map(item => {
            const active = activeTab === item.value
            const base = `px-4 py-2 rounded-full text-[13px] font-medium flex items-center gap-1 flex-shrink-0 transition-all whitespace-nowrap ${
              active
                ? "bg-surface-1 text-foreground shadow-sm shadow-black/20"
                : "text-muted-fg hover:text-foreground"
            }`

            if (!item.subs) {
              return (
                <button key={item.value} onClick={() => setActiveTab(item.value)} className={base}>
                  {item.label}
                </button>
              )
            }

            const subState: Record<string, [string, (v: string) => void]> = {
              geral: [geralSub, setGeralSub],
              suporte: [suporteSub, setSuporteSub],
              engenharia: [engSub, setEngSub],
            }
            const [curSub, setSub] = subState[item.value]
            const curLabel = item.subs.find(s => s.v === curSub)?.l

            return (
              <DropdownMenu key={item.value}>
                <DropdownMenuTrigger asChild>
                  <button className={base}>
                    {item.label}
                    {active && curLabel && (
                      <span className="hidden sm:inline text-muted-foreground/70 font-normal">· {curLabel}</span>
                    )}
                    <ChevronDown className="w-3.5 h-3.5 opacity-60" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-52">
                  {item.subs.map(s => (
                    <DropdownMenuItem
                      key={s.v}
                      onSelect={() => { setActiveTab(item.value); setSub(s.v) }}
                      className="gap-2 cursor-pointer"
                    >
                      <Check className={`w-3.5 h-3.5 ${active && curSub === s.v ? "opacity-100 text-primary" : "opacity-0"}`} />
                      {s.l}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            )
          })}
        </div>

        {/* ===================== ABA 1: RESUMO & GERAL ===================== */}
        <TabsContent value="geral" className="mt-4">
          <Tabs value={geralSub} onValueChange={setGeralSub}>
            {/* --- Dados Gerais --- */}
            <TabsContent value="dados" className="mt-4">
              <div className="bg-card rounded-xl border border-border p-4 md:p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field label="Nome da obra / cliente">
                  <Input value={form.client_name ?? ""} onChange={e => set("client_name", e.target.value)}
                    className="bg-muted border-border text-foreground" />
                </Field>
                <Field label="Etapa">
                  <div className="w-full h-9 px-3 rounded-xl bg-muted/50 border border-border text-muted-foreground text-sm flex items-center justify-between cursor-not-allowed">
                    <span>{obra.etapa ?? "Nova obra"}</span>
                    <span className="text-[10px] uppercase tracking-wide text-muted-foreground/60">via kanban</span>
                  </div>
                </Field>
                <Field label="Responsável Técnico">
                  <select value={form.resp_tecnico_id ?? ""} onChange={e => set("resp_tecnico_id", e.target.value)}
                    className="w-full h-9 px-3 rounded-xl bg-muted border border-border text-foreground text-sm">
                    <option value="">Não atribuído</option>
                    {users.map(u => <option key={u.id} value={u.id}>{u.nome}</option>)}
                  </select>
                </Field>
                <Field label="Responsável Comercial">
                  <Input disabled value={obra.respComercial?.nome ?? "—"}
                    className="bg-muted/50 border-border text-muted-foreground" />
                </Field>
                <Field label="Construtora">
                  <Input value={form.construtora ?? ""} onChange={e => set("construtora", e.target.value)}
                    className="bg-muted border-border text-foreground" />
                </Field>
                <Field label="Previsão início instalação">
                  <Input type="date" max="9999-12-31" value={(form.previsao_inicio as string) ?? ""}
                    onChange={e => set("previsao_inicio", e.target.value as unknown as string)}
                    className="bg-muted border-border text-foreground" />
                </Field>
                <Field label="Previsão finalização instalação">
                  <Input type="date" max="9999-12-31" value={(form.previsao_finalizacao_instalacao as string) ?? ""}
                    onChange={e => set("previsao_finalizacao_instalacao", e.target.value as unknown as string)}
                    className="bg-muted border-border text-foreground" />
                </Field>

                {/* Na célula que o grupo do Telegram deixou vaga, e na mesma
                    altura dos campos vizinhos: a explicação do que o estado
                    significa cabe no title, senão o bloco cresce duas linhas e
                    desalinha a grade inteira. */}
                <Field label="Compra liberada">
                  <div
                    title={form.compra_liberada
                      ? "Requisições de estoque liberadas para esta obra."
                      : "Bloqueada: requisições de estoque ficam travadas."}
                    className={`flex h-9 items-center gap-2.5 rounded-xl border px-3 transition-colors ${
                      form.compra_liberada
                        ? "border-green-500/30 bg-green-500/8"
                        : "border-border bg-muted"
                    }`}>
                    <Switch checked={!!form.compra_liberada} onCheckedChange={v => set("compra_liberada", v)} />
                    <span className={`text-sm ${
                      form.compra_liberada ? "text-green-600 dark:text-green-400" : "text-muted-foreground"
                    }`}>
                      {form.compra_liberada ? "Liberada" : "Bloqueada"}
                    </span>
                  </div>
                </Field>

                {/* Colaboradores, picklist: disponíveis → selecionados */}
                <div className="md:col-span-2 space-y-1">
                  <Label className="text-foreground/80 text-sm">Colaboradores</Label>
                  {(() => {
                    const selIds = form.colaboradores_ids || []
                    const disponiveis = users.filter(u => !selIds.includes(u.id))
                    const selecionados = users.filter(u => selIds.includes(u.id))
                    const addColab = (uid: string) => set("colaboradores_ids", [...selIds, uid])
                    const remColab = (uid: string) => set("colaboradores_ids", selIds.filter(x => x !== uid))
                    return (
                      <div className="space-y-2">
                        {/* Adiciona pelo select; os escolhidos viram chips removíveis */}
                        <select value="" disabled={disponiveis.length === 0}
                          onChange={e => { if (e.target.value) addColab(e.target.value) }}
                          className="w-full h-9 px-3 rounded-xl bg-muted border border-border text-foreground text-sm disabled:opacity-50">
                          <option value="">
                            {users.length === 0 ? "Nenhum usuário"
                              : disponiveis.length === 0 ? "Todos já adicionados"
                              : "Adicionar colaborador…"}
                          </option>
                          {disponiveis.map(u => <option key={u.id} value={u.id}>{u.nome}</option>)}
                        </select>
                        {selecionados.length === 0 ? (
                          <p className="text-muted-foreground text-xs">Nenhum colaborador na obra.</p>
                        ) : (
                          <div className="flex flex-wrap gap-1.5">
                            {selecionados.map(u => (
                              <span key={u.id} className="inline-flex items-center gap-1.5 pl-3 pr-2 py-1 rounded-full text-xs bg-foreground text-background">
                                {u.nome}
                                <button type="button" onClick={() => remColab(u.id)}
                                  className="opacity-70 hover:opacity-100" aria-label={`Remover ${u.nome}`}>✕</button>
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    )
                  })()}
                </div>

              </div>

              {/* --- Parceiros vinculados a esta obra --- */}
              <div className="bg-card rounded-xl border border-border p-5 space-y-3 mt-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-foreground font-medium flex items-center gap-2">
                    <Users className="w-4 h-4 text-sky-400" /> Parceiros desta Obra
                  </h3>
                  <Button size="sm" variant="outline"
                    onClick={async () => {
                      const res = await fetch("/api/parceiros")
                      if (res.ok) setTodosParceiros((await res.json()).parceiros)
                      setParceirosOpen(true)
                    }}
                    className="border-border text-foreground/80 hover:text-foreground gap-1.5 h-8">
                    <Plus className="w-3.5 h-3.5" /> Vincular Parceiro
                  </Button>
                </div>

                {parceirosObra.length === 0 ? (
                  <p className="text-muted-foreground/70 text-sm py-3 text-center">Nenhum parceiro vinculado</p>
                ) : (
                  <div className="space-y-2">
                    {parceirosObra.map(p => (
                      <div key={p.id} className="flex items-center justify-between gap-2 bg-muted rounded-2xl px-3 py-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <Users className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                          <div className="min-w-0">
                            <p className="text-foreground text-sm font-medium truncate">{p.name}</p>
                            <p className="text-muted-foreground text-xs">{p.type.replace("_", " ")}{p.company_name ? ` · ${p.company_name}` : ""}</p>
                          </div>
                        </div>
                        <div className="flex gap-1 flex-shrink-0">
                          <Button size="sm" variant="ghost"
                            onClick={() => router.push(`/parceiros/${p.id}`)}
                            className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground/70">
                            <ExternalLink className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="sm" variant="ghost"
                            onClick={async () => {
                              await fetch(`/api/obras/${id}/parceiros`, {
                                method: "DELETE",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({ parceiro_id: p.id }),
                              })
                              loadParceiros()
                            }}
                            className="h-7 w-7 p-0 text-muted-foreground hover:text-red-400">
                            <X className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Exclusão da obra, destrutiva, só ADMIN chega aqui */}
              <Dialog open={confirmExcluirObra} onOpenChange={o => { if (!o) { setConfirmExcluirObra(false); setErroExcluirObra("") } }}>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-ios-red/15">
                      <Trash2 className="h-6 w-6 text-ios-red" />
                    </div>
                    <DialogTitle className="text-center text-xl">Excluir esta obra?</DialogTitle>
                  </DialogHeader>
                  <div className="px-5 pb-2 text-center text-sm text-muted-foreground sm:px-6">
                    <p>
                      Ambientes, vistorias, quadros de automação, anexos e agendamentos desta obra
                      serão apagados. Não dá para desfazer.
                    </p>
                    <p className="mt-2">As propostas ligadas continuam existindo, apenas soltam o vínculo.</p>
                    {erroExcluirObra && <p className="mt-3 text-ios-red">{erroExcluirObra}</p>}
                  </div>
                  <DialogFooter className="gap-2 px-5 pb-4 sm:px-6">
                    <Button variant="outline" onClick={() => setConfirmExcluirObra(false)}>Cancelar</Button>
                    <Button onClick={excluirObra} disabled={excluindoObra}
                      className="gap-1.5 bg-ios-red text-background hover:bg-ios-red/90">
                      {excluindoObra ? <><RefreshCw className="h-4 w-4 animate-spin" /> Excluindo…</> : "Excluir obra"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              {/* Dialog: selecionar parceiro */}
              <Dialog open={parceirosOpen} onOpenChange={setParceirosOpen}>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Vincular Parceiro</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-2 max-h-80 overflow-y-auto">
                    {todosParceiros
                      .filter(p => !parceirosObra.some(po => po.id === p.id))
                      .map(p => (
                        <button key={p.id}
                          onClick={async () => {
                            await fetch(`/api/obras/${id}/parceiros`, {
                              method: "POST",
                              headers: { "Content-Type": "application/json" },
                              body: JSON.stringify({ parceiro_id: p.id }),
                            })
                            await loadParceiros()
                            setParceirosOpen(false)
                          }}
                          className="w-full text-left bg-muted hover:bg-muted/70 border border-border rounded-2xl px-3 py-2.5 transition-colors">
                          <p className="text-foreground text-sm font-medium">{p.name}</p>
                          <p className="text-muted-foreground text-xs">{p.type.replace("_", " ")}{p.company_name ? ` · ${p.company_name}` : ""}</p>
                        </button>
                      ))}
                    {todosParceiros.filter(p => !parceirosObra.some(po => po.id === p.id)).length === 0 && (
                      <p className="text-muted-foreground text-sm text-center py-6">
                        Todos os parceiros já estão vinculados ou não há parceiros cadastrados.
                      </p>
                    )}
                  </div>
                </DialogContent>
              </Dialog>
            </TabsContent>

            {/* --- Notas da Obra --- */}
            <TabsContent value="notas" className="mt-4">
              <BlocoNotas valor={form.notas} onChange={v => set("notas", v)} />
            </TabsContent>

            {/* --- Tarefas da Obra --- */}
            <TabsContent value="tarefas" className="mt-4 space-y-4">
              <ChecklistTecnico obraId={id} initial={(obra.checklist_tecnico as ChecklistTecnicoItem[]) ?? []} />
              <TarefasObraTab obraId={id} users={users} />
            </TabsContent>

            {/* --- Endereço & Logística --- */}
            <TabsContent value="endereco" className="mt-4">
              <div className="bg-card rounded-xl border border-border p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                <Field label="CEP">
                  <Input value={form.cep ?? ""} onChange={e => set("cep", e.target.value)}
                    onBlur={e => buscarCep(e.target.value)} placeholder="00000-000"
                    className="bg-muted border-border text-foreground" />
                </Field>
                <Field label="Rua" className="md:col-span-2">
                  <Input value={form.rua ?? ""} onChange={e => set("rua", e.target.value)}
                    className="bg-muted border-border text-foreground" />
                </Field>
                <Field label="Número">
                  <Input value={form.numero ?? ""} onChange={e => set("numero", e.target.value)}
                    className="bg-muted border-border text-foreground" />
                </Field>
                <Field label="Bairro">
                  <Input value={form.bairro ?? ""} onChange={e => set("bairro", e.target.value)}
                    className="bg-muted border-border text-foreground" />
                </Field>
                <Field label="Cidade">
                  <Input value={form.cidade ?? ""} onChange={e => set("cidade", e.target.value)}
                    className="bg-muted border-border text-foreground" />
                </Field>
                <Field label="Complemento">
                  <Input value={form.complemento ?? ""} onChange={e => set("complemento", e.target.value)}
                    className="bg-muted border-border text-foreground" />
                </Field>
                <Field label="Ponto de referência" className="md:col-span-2">
                  <Input value={form.ponto_referencia ?? ""} onChange={e => set("ponto_referencia", e.target.value)}
                    className="bg-muted border-border text-foreground" />
                </Field>

                <div className="md:col-span-3 border-t border-border pt-4 space-y-3">
                  <Label className="text-foreground/80 text-sm flex items-center gap-1.5">
                    <MapPin className="w-4 h-4" /> Localização (GPS)
                  </Label>
                  {/* Buscar por endereço → preenche lat/lng automaticamente */}
                  <div className="flex flex-wrap items-end gap-2">
                    <div className="flex-1 min-w-[240px] space-y-1">
                      <Label className="text-foreground/70 text-xs">Buscar por endereço</Label>
                      <Input value={geoBusca} onChange={e => setGeoBusca(e.target.value)}
                        onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); buscarEndereco() } }}
                        placeholder="Rua, número, bairro, cidade"
                        className="bg-muted border-border text-foreground" />
                    </div>
                    <Button type="button" onClick={buscarEndereco} disabled={geoLoading || !geoBusca.trim()}
                      className="gap-1.5">
                      {geoLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />} Localizar
                    </Button>
                  </div>
                  <div className="flex flex-wrap items-end gap-3">
                    <Field label="Latitude">
                      <Input value={form.latitude ?? ""} onChange={e => set("latitude", parseFloat(e.target.value))}
                        className="bg-muted border-border text-foreground w-40" />
                    </Field>
                    <Field label="Longitude">
                      <Input value={form.longitude ?? ""} onChange={e => set("longitude", parseFloat(e.target.value))}
                        className="bg-muted border-border text-foreground w-40" />
                    </Field>
                    <Button type="button" onClick={fixarGps} variant="outline"
                      className="border-border text-foreground/80 hover:text-foreground gap-1.5">
                      <Crosshair className="w-4 h-4" /> Fixar via GPS
                    </Button>
                    {form.latitude && form.longitude && (
                      <a href={`https://www.google.com/maps?q=${form.latitude},${form.longitude}`} target="_blank" rel="noreferrer"
                        className="text-sky-400 hover:text-sky-300 text-sm flex items-center gap-1">
                        <ExternalLink className="w-3.5 h-3.5" /> Abrir no Google Maps
                      </a>
                    )}
                  </div>
                </div>

                <Field label="Agrupamento Grupo/Tipo">
                  <select value={form.grupo_tipo ?? "Nenhum"} onChange={e => set("grupo_tipo", e.target.value)}
                    className="w-full h-9 px-3 rounded-xl bg-muted border border-border text-foreground text-sm">
                    {GRUPO_TIPOS.map(g => <option key={g} value={g}>{g}</option>)}
                  </select>
                </Field>
              </div>
            </TabsContent>

            {/* --- Acesso Externo --- */}
            <TabsContent value="acessos" className="mt-4">
              <AcessoExternoTab
                acessos={(form.acessos_externos as AcessoExterno[]) || []}
                onChange={list => set("acessos_externos", list as Obra["acessos_externos"])}
              />
            </TabsContent>

            {/* --- Relatórios Automáticos --- */}
            <TabsContent value="relatorios" className="mt-4">
              {/* Lista agrupada iOS: cada evento é uma linha com switch, e os
                  contatos entram como seleção marcada — sem checkbox nativo
                  nem pílulas soltas sem estado claro. */}
              <div className="space-y-5">
                <section className="space-y-2">
                  <div className="px-1">
                    <h3 className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-fg">
                      Enviar relatório quando houver
                    </h3>
                  </div>
                  <div className="divide-y divide-hairline overflow-hidden rounded-2xl bg-surface-1">
                    {([
                      ["vistorias", "Vistorias", "A cada vistoria registrada na obra"],
                      ["instalacao", "Instalações", "Ao concluir um atendimento de instalação"],
                      ["manutencao", "Manutenções", "Ao concluir um atendimento de manutenção"],
                    ] as const).map(([k, label, desc]) => {
                      const ligado = !!rc?.[k]
                      return (
                        <button key={k} type="button"
                          onClick={() => set("relatorios_config", { ...rc, [k]: !ligado })}
                          className="flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-muted">
                          <span className="min-w-0 flex-1">
                            <span className="block text-sm text-foreground">{label}</span>
                            <span className="block text-xs text-muted-fg">{desc}</span>
                          </span>
                          {/* Switch no padrão iOS */}
                          <span className={`relative h-6 w-10 shrink-0 rounded-full transition-colors ${
                            ligado ? "bg-ios-green" : "bg-muted-fg/30"
                          }`}>
                            <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow-sm transition-all ${
                              ligado ? "left-[18px]" : "left-0.5"
                            }`} />
                          </span>
                        </button>
                      )
                    })}
                  </div>
                  <p className="px-1 text-[11px] text-muted-fg">
                    Por enquanto isso só guarda a preferência, o disparo automático a cada evento
                    entra numa fase seguinte. O envio manual, aqui embaixo, já manda de verdade.
                  </p>
                </section>

                <section className="space-y-2">
                  <div className="flex items-baseline justify-between px-1">
                    <h3 className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-fg">
                      Quem recebe
                    </h3>
                    <span className="text-xs text-muted-fg">
                      {(rc?.contatos || []).length || "ninguém"} selecionado{(rc?.contatos || []).length === 1 ? "" : "s"}
                    </span>
                  </div>
                  <div className="divide-y divide-hairline overflow-hidden rounded-2xl bg-surface-1">
                    {users.map(u => {
                      const sel = (rc?.contatos || []).includes(u.id)
                      return (
                        <button key={u.id} type="button"
                          onClick={() => {
                            const cur = rc?.contatos || []
                            set("relatorios_config", { ...rc, contatos: sel ? cur.filter(x => x !== u.id) : [...cur, u.id] })
                          }}
                          className="flex w-full items-center gap-3 px-4 py-2.5 text-left transition-colors hover:bg-muted">
                          <span className="min-w-0 flex-1 text-sm text-foreground">{u.nome}</span>
                          {sel && <Check className="h-4 w-4 shrink-0 text-ios-blue" />}
                        </button>
                      )
                    })}
                  </div>
                </section>

                <section className="space-y-2">
                  {(() => {
                    /* O e-mail e a pessoa marcada são a mesma coisa — quem
                       está em "Quem recebe" já tem e-mail cadastrado no
                       próprio usuário, não existe destino solto pra digitar
                       aqui. */
                    const destinos = [...new Set(
                      users.filter(u => (rc?.contatos || []).includes(u.id)).map(u => u.email).filter(Boolean),
                    )]

                    async function enviarAgora() {
                      if (destinos.length === 0) return
                      setEnviandoRelatorio(true)
                      setRelatorioMsg(null)
                      try {
                        const r = await fetch(`/api/obras/${id}/relatorio/enviar`, {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          body: JSON.stringify({ emails: destinos }),
                        })
                        const j = await r.json().catch(() => null)
                        if (r.ok) setRelatorioMsg({ tipo: "ok", texto: `Enviado para ${destinos.length} destinatário${destinos.length === 1 ? "" : "s"}.` })
                        else setRelatorioMsg({ tipo: "erro", texto: j?.error || "Falha ao enviar." })
                      } catch {
                        setRelatorioMsg({ tipo: "erro", texto: "Falha ao enviar." })
                      } finally {
                        setEnviandoRelatorio(false)
                      }
                    }

                    return (
                      <div className="rounded-2xl bg-surface-1 p-4 space-y-2.5">
                        <p className="text-sm text-foreground">
                          {destinos.length > 0
                            ? `Manda agora, pros ${destinos.length} destinatário${destinos.length === 1 ? "" : "s"} marcados acima.`
                            : "Marque alguém em \"Quem recebe\" para poder enviar."}
                        </p>
                        <Button onClick={enviarAgora} disabled={enviandoRelatorio || destinos.length === 0} className="w-full">
                          {enviandoRelatorio ? "Enviando..." : "Enviar relatório agora"}
                        </Button>
                        {relatorioMsg && (
                          <p className={`text-xs ${relatorioMsg.tipo === "ok" ? "text-ios-green" : "text-ios-red"}`}>
                            {relatorioMsg.texto}
                          </p>
                        )}
                      </div>
                    )
                  })()}
                </section>
              </div>
            </TabsContent>
          </Tabs>
        </TabsContent>

        {/* ===================== ABA 2: AGENDAMENTOS ===================== */}
        <TabsContent value="agenda" className="mt-4">
          <AgendamentosTab
            obraId={id}
            eventos={(form.agendamentos as Agendamento[]) || []}
            onChange={list => set("agendamentos", list as Obra["agendamentos"])}
          />
        </TabsContent>

        {/* ===================== ABA 3: SUPORTE ===================== */}
        <TabsContent value="suporte" className="mt-4">
          <Tabs value={suporteSub} onValueChange={setSuporteSub}>
            <TabsContent value="senhas" className="mt-4">
              <SenhasTab obraId={id} credenciais={credenciais} onReload={loadCredenciais} />
            </TabsContent>

            <TabsContent value="manutencoes" className="mt-4">
              <ManutencaoTab obraId={id} manutencoes={manutencoes} onReload={async () => {
                const r = await fetch(`/api/manutencoes?obraId=${id}`)
                if (r.ok) setManutencoes((await r.json()).tickets || [])
              }} />
            </TabsContent>

            <TabsContent value="consertos" className="mt-4">
              <ConsertoTab obraId={id} />
            </TabsContent>
          </Tabs>
        </TabsContent>

        {/* ===================== ABA 4: ENGENHARIA ===================== */}
        <TabsContent value="engenharia" className="mt-4">
          <EngenhariaTab
            obraId={id}
            activeSub={engSub}
            onSubChange={setEngSub}
            environments={obra.environments || []}
            initialProjetos={(obra.projetos_blueprints as Blueprint[]) || []}
            initialAnexos={(obra.anexos_projeto as Anexo[]) || []}
            initialQuadros={(obra.quadros as Quadro[]) || []}
            onIrParaDimensionamento={() => setActiveTab("dimensionamento")}
          />
        </TabsContent>

        {/* ===================== ABA 5: PROPOSTAS ===================== */}
        <TabsContent value="propostas" className="mt-4">
          <div className="bg-card rounded-xl border border-border p-6 space-y-3">
            <h3 className="text-foreground font-medium flex items-center gap-2">
              <FileText className="w-4 h-4 text-sky-400" /> Propostas, revisões e aditivos
            </h3>
            {(obra.proposals || []).length === 0 ? (
              <p className="text-muted-foreground text-sm">Nenhuma proposta vinculada a esta obra.</p>
            ) : (
              <div className="space-y-2">
                {obra.proposals.map(p => (
                  <button key={p.id} onClick={() => router.push(`/propostas/${p.id}`)}
                    className="w-full flex items-center justify-between bg-muted hover:bg-muted/70 rounded-2xl p-3 text-left transition-colors">
                    <div className="flex items-center gap-2">
                      <span className="text-foreground text-sm font-medium">{p.numero}</span>
                      {obra.originProposal?.numero === p.numero && (
                        <Badge variant="outline" className="text-[10px]">origem</Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge variant={p.status === "ACEITA" ? "success" : "secondary"}>{p.status.replace(/_/g, " ")}</Badge>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        {/* ===================== ABA: DIMENSIONAMENTO ===================== */}
        <TabsContent value="dimensionamento" className="mt-4">
          {/* Novo (Bloco 10): itens por ambiente, params do cadastro do produto,
              checkbox p/ relatório. O antigo (DimensionamentoTab) foi aposentado. */}
          <DimensionamentoObra obraId={id} obraNome={obra.client_name} ehAdmin={userRole === "ADMIN"} />
        </TabsContent>
      </Tabs>
      </div>
    </div>
  )
}


// ============================================================
// Tarefas da Obra — sincronizam com a Agenda central (categoria OPERACIONAL)
// ============================================================
interface TarefaObra {
  id: string; titulo: string; descricao: string | null
  prioridade: "BAIXA" | "MEDIA" | "ALTA"
  categoria: string; concluida: boolean; dataVenc: string | null
  atribuido: { id: string; nome: string } | null
}

function TarefasObraTab({ obraId, users }: { obraId: string; users: UserLite[] }) {
  const [tarefas, setTarefas] = useState<TarefaObra[]>([])
  const [loading, setLoading] = useState(true)
  const [titulo, setTitulo] = useState("")
  const [prioridade, setPrioridade] = useState<"BAIXA" | "MEDIA" | "ALTA">("MEDIA")
  const [dataVenc, setDataVenc] = useState("")
  const [atribuidoA, setAtribuidoA] = useState("")
  const [saving, setSaving] = useState(false)
  const [delId, setDelId] = useState<string | null>(null)
  const [erro, setErro] = useState("")

  const carregar = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch(`/api/tarefas?obraId=${obraId}`)
      if (res.ok) setTarefas((await res.json()).tarefas || [])
      else setErro("Não foi possível carregar as tarefas. Reinicie o servidor de desenvolvimento.")
    } finally { setLoading(false) }
  }, [obraId])

  useEffect(() => { carregar() }, [carregar])

  async function adicionar() {
    if (!titulo.trim()) return
    setSaving(true)
    setErro("")
    try {
      const res = await fetch("/api/tarefas", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          titulo, prioridade, categoria: "OPERACIONAL", obraId,
          dataVenc: dataVenc || undefined, atribuidoA: atribuidoA || undefined,
        }),
      })
      if (res.ok) {
        const nova = await res.json()
        setTarefas(prev => [nova, ...prev])
        setTitulo(""); setPrioridade("MEDIA"); setDataVenc(""); setAtribuidoA("")
      } else {
        const msg = await res.json().catch(() => ({}))
        setErro(msg.error || "Falha ao criar tarefa. Reinicie o servidor de desenvolvimento.")
      }
    } catch {
      setErro("Erro de conexão ao criar a tarefa.")
    } finally { setSaving(false) }
  }

  async function toggle(t: TarefaObra) {
    await fetch(`/api/tarefas/${t.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ concluida: !t.concluida }),
    })
    setTarefas(prev => prev.map(x => x.id === t.id ? { ...x, concluida: !t.concluida } : x))
  }

  async function excluir() {
    if (!delId) return
    await fetch(`/api/tarefas/${delId}`, { method: "DELETE" })
    setTarefas(prev => prev.filter(t => t.id !== delId))
    setDelId(null)
  }

  const flagColor = (p: string) => p === "ALTA" ? "text-red-400" : p === "MEDIA" ? "text-yellow-400" : "text-muted-foreground"
  const venceu = (d: string | null) => d ? new Date(d) < new Date() : false

  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-foreground font-medium flex items-center gap-2">
          <Calendar className="w-4 h-4 text-sky-400" /> Tarefas desta obra
        </h3>
        <span className="text-xs text-muted-foreground">
          Aparecem na <span className="text-sky-400">Agenda central</span> como categoria Operacional
        </span>
      </div>

      {/* Form de adição rápida */}
      <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_auto_auto_auto] gap-2 items-end bg-muted/50 rounded-2xl p-3">
        <div className="space-y-1">
          <Label className="text-muted-foreground text-xs">Nova tarefa</Label>
          <Input value={titulo} onChange={e => setTitulo(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter") adicionar() }}
            placeholder="Ex: Levantar requisitos da 1ª revisão"
            className="bg-muted border-border text-foreground h-9" />
        </div>
        <div className="space-y-1">
          <Label className="text-muted-foreground text-xs">Prioridade</Label>
          <select value={prioridade} onChange={e => setPrioridade(e.target.value as "BAIXA" | "MEDIA" | "ALTA")}
            className="h-9 px-2 rounded-xl bg-muted border border-border text-foreground text-sm">
            <option value="BAIXA">Baixa</option>
            <option value="MEDIA">Média</option>
            <option value="ALTA">Alta</option>
          </select>
        </div>
        <div className="space-y-1">
          <Label className="text-muted-foreground text-xs">Prazo</Label>
          <Input type="date" max="9999-12-31" value={dataVenc} onChange={e => setDataVenc(e.target.value)}
            className="bg-muted border-border text-foreground h-9" />
        </div>
        <div className="space-y-1">
          <Label className="text-muted-foreground text-xs">Responsável</Label>
          <select value={atribuidoA} onChange={e => setAtribuidoA(e.target.value)}
            className="h-9 px-2 rounded-xl bg-muted border border-border text-foreground text-sm max-w-[140px]">
            <option value="">—</option>
            {users.map(u => <option key={u.id} value={u.id}>{u.nome}</option>)}
          </select>
        </div>
        <Button onClick={adicionar} disabled={saving || !titulo.trim()}
          className="bg-sky-600 hover:bg-sky-700 text-foreground h-9">
          <Plus className="w-4 h-4" />
        </Button>
      </div>

      {erro && (
        <div className="rounded-2xl bg-red-500/10 border border-red-500/30 px-3 py-2 text-sm text-red-300">
          {erro}
        </div>
      )}

      {/* Lista */}
      {loading ? (
        <p className="text-muted-foreground text-sm text-center py-6">Carregando...</p>
      ) : tarefas.length === 0 ? (
        <p className="text-muted-foreground text-sm text-center py-6">Nenhuma tarefa para esta obra ainda.</p>
      ) : (
        <div className="space-y-2">
          {tarefas.map(t => (
            <div key={t.id}
              className={`flex items-start gap-3 rounded-2xl p-3 ${
                t.concluida ? "bg-muted/30 opacity-60"
                : venceu(t.dataVenc) ? "bg-red-500/5 border border-red-500/20" : "bg-muted"
              }`}>
              <button onClick={() => toggle(t)} className="mt-0.5">
                {t.concluida
                  ? <ShieldCheck className="w-5 h-5 text-green-500" />
                  : <div className="w-5 h-5 rounded-full border-2 border-border hover:text-foreground/70 transition-colors" />}
              </button>
              <div className="flex-1 min-w-0">
                <p className={`text-sm font-medium ${t.concluida ? "line-through text-muted-foreground" : "text-foreground"}`}>
                  {t.titulo}
                </p>
                <div className="flex items-center flex-wrap gap-3 mt-1 text-xs text-muted-foreground">
                  <span className={flagColor(t.prioridade)}>● {t.prioridade}</span>
                  {t.dataVenc && (
                    <span className={venceu(t.dataVenc) && !t.concluida ? "text-red-400" : ""}>
                      {new Date(t.dataVenc).toLocaleDateString("pt-BR")}
                    </span>
                  )}
                  {t.atribuido && <span>→ {t.atribuido.nome}</span>}
                </div>
              </div>
              <button onClick={() => setDelId(t.id)} className="text-muted-foreground/70 hover:text-red-400 p-1">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}

      <Dialog open={!!delId} onOpenChange={o => !o && setDelId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Excluir Tarefa</DialogTitle></DialogHeader>
          <p className="text-foreground/80 text-sm">Tem certeza? A tarefa será removida também da Agenda.</p>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setDelId(null)} className="text-muted-foreground hover:text-foreground">Cancelar</Button>
            <Button onClick={excluir} className="bg-red-600 hover:bg-red-700 text-foreground">Excluir</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Helpers de UI
// ============================================================
function Field({ label, children, className = "" }: {
  label: string; children: React.ReactNode; className?: string
}) {
  return (
    <div className={`space-y-1 ${className}`}>
      <Label className="text-foreground/80 text-sm">{label}</Label>
      {children}
    </div>
  )
}

// ---- URL or File Input ----
function UrlOrFileInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [mode, setMode] = useState<"url" | "file">("url")
  const [uploading, setUploading] = useState(false)

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]; if (!file) return
    setUploading(true)
    const fd = new FormData(); fd.append("file", file)
    const res = await fetch("/api/upload", { method: "POST", body: fd })
    if (res.ok) { const { url } = await res.json(); onChange(url) }
    setUploading(false); e.target.value = ""
  }

  return (
    <div className="space-y-2">
      <div className="flex gap-1 bg-muted rounded-2xl p-0.5 w-fit">
        <button type="button" onClick={() => setMode("url")}
          className={`px-3 py-1 rounded-xl text-xs font-medium transition-colors ${mode === "url" ? "bg-muted/70 text-foreground" : "text-muted-foreground hover:text-foreground/80"}`}>URL</button>
        <button type="button" onClick={() => setMode("file")}
          className={`px-3 py-1 rounded-xl text-xs font-medium transition-colors ${mode === "file" ? "bg-muted/70 text-foreground" : "text-muted-foreground hover:text-foreground/80"}`}>Arquivo</button>
      </div>
      {mode === "url" ? (
        <Input value={value} onChange={e => onChange(e.target.value)}
          placeholder="https://..." className="bg-muted border-border text-foreground text-sm" />
      ) : (
        <div className="flex items-center gap-2">
          <label className={`flex-1 flex items-center gap-2 h-9 px-3 rounded-xl border cursor-pointer text-sm transition-colors ${uploading ? "bg-muted/70 border-border text-muted-foreground" : "bg-muted border-border hover:border-border text-foreground/80 hover:text-foreground"}`}>
            <Paperclip className="w-4 h-4" /> {uploading ? "Enviando..." : value ? "Trocar arquivo" : "Escolher arquivo"}
            <input type="file" className="hidden" accept="image/*,.pdf" disabled={uploading} onChange={handleFile} />
          </label>
          {value && <a href={value} target="_blank" rel="noreferrer" className="text-sky-400 text-xs hover:text-sky-300 truncate max-w-[120px]">Ver arquivo</a>}
        </div>
      )}
    </div>
  )
}

// ---- Manutenção Tab ----
const STATUS_MANUT: Record<string, string> = {
  NOVA: "Nova", EM_ANDAMENTO: "Em andamento", EM_CONFERENCIA: "Em conferência", CONCLUIDA: "Concluída",
}
function ManutencaoTab({ obraId, manutencoes, onReload }: {
  obraId: string; manutencoes: Manutencao[]; onReload: () => void
}) {
  const [open, setOpen] = useState(false)
  const [titulo, setTitulo] = useState("")
  const [descricao, setDescricao] = useState("")
  const [saving, setSaving] = useState(false)

  async function add() {
    if (!titulo.trim()) return
    setSaving(true)
    await fetch("/api/manutencoes", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ obraId, titulo, descricao }),
    })
    setTitulo(""); setDescricao(""); setOpen(false); onReload(); setSaving(false)
  }

  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-foreground font-medium flex items-center gap-2"><Wrench className="w-4 h-4 text-sky-400" /> Histórico de chamados</h3>
        <Button size="sm" onClick={() => setOpen(true)} className="bg-sky-600 hover:bg-sky-700 text-foreground gap-1.5">
          <Plus className="w-4 h-4" /> Novo chamado
        </Button>
      </div>
      {manutencoes.length === 0 ? (
        <p className="text-muted-foreground text-sm text-center py-6">Nenhum chamado para esta obra.</p>
      ) : (
        <div className="space-y-2">
          {manutencoes.map(m => (
            <div key={m.id} className="flex items-center justify-between bg-muted rounded-2xl p-3">
              <div>
                <p className="text-foreground text-sm">{m.titulo}</p>
                {m.descricao && <p className="text-muted-foreground text-xs">{m.descricao}</p>}
              </div>
              <Badge variant={m.status === "CONCLUIDA" ? "success" : "secondary"}>{STATUS_MANUT[m.status] ?? m.status}</Badge>
            </div>
          ))}
        </div>
      )}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Novo chamado de manutenção</DialogTitle></DialogHeader>
          <div className="space-y-3 px-5 sm:px-6 py-4">
            <Field label="Título *"><Input value={titulo} onChange={e => setTitulo(e.target.value)}
              className="bg-muted border-border text-foreground" placeholder="Ex: Trocar fonte de rack" /></Field>
            <Field label="Descrição"><Textarea value={descricao} onChange={e => setDescricao(e.target.value)}
              className="bg-muted border-border text-foreground text-sm" rows={3} placeholder="Detalhes do problema..." /></Field>
          </div>
          <DialogFooter className="gap-2 sm:gap-2">
            <Button variant="outline" onClick={() => setOpen(false)} className="border-border text-foreground/80 flex-1">Cancelar</Button>
            <Button onClick={add} disabled={!titulo.trim() || saving} className="bg-sky-600 hover:bg-sky-700 text-foreground flex-1">
              {saving ? "Salvando..." : "Criar chamado"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ---- Conserto Tab ----
interface Conserto { id: string; equipamento: string; problema: string; status: string; createdAt: string }
function ConsertoTab({ obraId }: { obraId: string }) {
  const [consertos, setConsertos] = useState<Conserto[]>([])
  const [open, setOpen] = useState(false)
  const [equip, setEquip] = useState("")
  const [problema, setProblema] = useState("")
  const [saving, setSaving] = useState(false)

  const load = useCallback(async () => {
    const r = await fetch(`/api/obras/${obraId}/consertos`)
    if (r.ok) setConsertos((await r.json()).consertos || [])
  }, [obraId])
  useEffect(() => { load() }, [load])

  async function add() {
    if (!equip.trim()) return
    setSaving(true)
    await fetch(`/api/obras/${obraId}/consertos`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ equipamento: equip, problema }),
    })
    setEquip(""); setProblema(""); setOpen(false); load(); setSaving(false)
  }

  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-foreground font-medium flex items-center gap-2"><Wrench className="w-4 h-4 text-amber-400" /> Consertos / Assistência Técnica</h3>
        <Button size="sm" onClick={() => setOpen(true)} className="bg-sky-600 hover:bg-sky-700 text-foreground gap-1.5">
          <Plus className="w-4 h-4" /> Solicitar conserto
        </Button>
      </div>
      {consertos.length === 0 ? (
        <p className="text-muted-foreground text-sm text-center py-6">Nenhum equipamento em assistência.</p>
      ) : (
        <div className="space-y-2">
          {consertos.map(c => (
            <div key={c.id} className="flex items-center justify-between bg-muted rounded-2xl p-3">
              <div>
                <p className="text-foreground text-sm font-medium">{c.equipamento}</p>
                {c.problema && <p className="text-muted-foreground text-xs">{c.problema}</p>}
                <p className="text-muted-foreground/70 text-xs mt-0.5">{new Date(c.createdAt).toLocaleDateString("pt-BR")}</p>
              </div>
              <Badge variant={c.status === "CONCLUIDO" ? "success" : "secondary"}>{c.status}</Badge>
            </div>
          ))}
        </div>
      )}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Solicitar conserto</DialogTitle></DialogHeader>
          <div className="space-y-3 px-5 sm:px-6 py-4">
            <Field label="Produto *"><Input value={equip} onChange={e => setEquip(e.target.value)}
              className="bg-muted border-border text-foreground" placeholder="Ex: Amplificador XYZ" /></Field>
          </div>
          <DialogFooter className="gap-2 sm:gap-2">
            <Button variant="outline" onClick={() => setOpen(false)} className="border-border text-foreground/80 flex-1">Cancelar</Button>
            <Button onClick={add} disabled={!equip.trim() || saving} className="bg-sky-600 hover:bg-sky-700 text-foreground flex-1">
              {saving ? "Salvando..." : "Registrar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ---- Acesso Externo ----
function AcessoExternoTab({ acessos, onChange }: {
  acessos: AcessoExterno[]; onChange: (list: AcessoExterno[]) => void
}) {
  const [open, setOpen] = useState(false)
  const [nome, setNome] = useState("")
  const [papel, setPapel] = useState("")
  const [login, setLogin] = useState("")
  const [senha, setSenha] = useState("")
  const [validade, setValidade] = useState("")
  const [showSenhas, setShowSenhas] = useState<Record<number, boolean>>({})

  function add() {
    if (!nome.trim() || !login.trim() || !senha.trim()) return
    onChange([...acessos, { nome, papel, login, senha, validade }])
    setNome(""); setPapel(""); setLogin(""); setSenha(""); setValidade(""); setOpen(false)
  }

  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-foreground font-medium">Acessos temporários para externos</h3>
          <p className="text-muted-foreground text-xs mt-0.5">Cada externo recebe login e senha próprios com acesso restrito a esta obra</p>
        </div>
        <Button size="sm" onClick={() => setOpen(true)} className="bg-sky-600 hover:bg-sky-700 text-foreground gap-1.5">
          <Plus className="w-4 h-4" /> Novo acesso
        </Button>
      </div>

      {acessos.length === 0 ? (
        <p className="text-muted-foreground text-sm py-6 text-center">Sem acessos cadastrados</p>
      ) : (
        <div className="space-y-2">
          {acessos.map((a, i) => (
            <div key={i} className="flex items-center justify-between bg-muted rounded-2xl p-3 gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-foreground text-sm font-medium">{a.nome}</p>
                  {a.papel && <span className="text-xs px-2 py-0.5 rounded-full bg-muted/70 text-muted-foreground">{a.papel}</span>}
                </div>
                <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                  <span>Login: <span className="text-foreground/80 font-mono">{a.login}</span></span>
                  {a.senha && (
                    <span className="flex items-center gap-1">
                      Senha: <span className="font-mono text-foreground/80">{showSenhas[i] ? a.senha : "••••••"}</span>
                      <button onClick={() => setShowSenhas(s => ({ ...s, [i]: !s[i] }))} className="text-muted-foreground/70 hover:text-foreground/80 ml-0.5">
                        {showSenhas[i] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      </button>
                    </span>
                  )}
                  {a.validade && <span>· até {a.validade}</span>}
                </div>
              </div>
              <Button size="sm" variant="ghost" onClick={() => onChange(acessos.filter((_, x) => x !== i))}
                className="text-muted-foreground/70 hover:text-red-400 h-8 w-8 p-0 flex-shrink-0">
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Novo acesso externo</DialogTitle></DialogHeader>
          <div className="space-y-3 px-5 sm:px-6 py-4">
            <Field label="Nome *"><Input value={nome} onChange={e => setNome(e.target.value)}
              className="bg-muted border-border text-foreground" placeholder="Ex: Arquiteto João" /></Field>
            <Field label="Papel / Função"><Input value={papel} onChange={e => setPapel(e.target.value)}
              className="bg-muted border-border text-foreground" placeholder="Ex: Arquiteto, Cliente, Construtora" /></Field>
            <Field label="Login *"><Input value={login} onChange={e => setLogin(e.target.value)}
              className="bg-muted border-border text-foreground font-mono" placeholder="usuario@email.com ou apelido" /></Field>
            <Field label="Senha *"><Input type="password" value={senha} onChange={e => setSenha(e.target.value)}
              className="bg-muted border-border text-foreground font-mono" placeholder="Senha de acesso" /></Field>
            <Field label="Válido até (opcional)"><Input type="date" max="9999-12-31" value={validade} onChange={e => setValidade(e.target.value)}
              className="bg-muted border-border text-foreground" /></Field>
          </div>
          <p className="text-muted-foreground/70 text-xs px-1">O externo só terá acesso aos dados desta obra específica.</p>
          <DialogFooter className="gap-2 sm:gap-2">
            <Button variant="outline" onClick={() => setOpen(false)}
              className="border-border text-foreground/80 flex-1">Cancelar</Button>
            <Button onClick={add} disabled={!nome.trim() || !login.trim() || !senha.trim()}
              className="bg-sky-600 hover:bg-sky-700 text-foreground flex-1">Criar acesso</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ---- Agendamentos ----
function AgendamentosTab({ obraId, eventos, onChange }: {
  obraId: string; eventos: Agendamento[]; onChange: (list: Agendamento[]) => void
}) {
  const [titulo, setTitulo] = useState("")
  const [data, setData] = useState("")
  const [equipe, setEquipe] = useState("")
  const [syncing, setSyncing] = useState(false)
  const [syncMsg, setSyncMsg] = useState<{ ok: boolean; text: string } | null>(null)
  const [publishing, setPublishing] = useState<number | null>(null)

  function add() {
    if (!titulo.trim() || !data) return
    onChange([...eventos, { titulo, data, equipe }].sort((a, b) => a.data.localeCompare(b.data)))
    setTitulo(""); setData(""); setEquipe("")
  }

  async function publicarNaAgenda(ev: Agendamento, idx: number) {
    setPublishing(idx)
    try {
      const res = await fetch("/api/tarefas", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          titulo: ev.titulo,
          descricao: ev.equipe ? `Equipe: ${ev.equipe}` : undefined,
          categoria: "OPERACIONAL",
          prioridade: "MEDIA",
          dataVenc: ev.data ? ev.data.slice(0, 10) : undefined,
          horaInicio: (ev as unknown as Record<string, string>).hora_inicio || undefined,
          horaFim: (ev as unknown as Record<string, string>).hora_fim || undefined,
          atribuido_role: "OPERACIONAL",
          obraId,
        }),
      })
      if (res.ok) {
        setSyncMsg({ ok: true, text: `"${ev.titulo}" publicado na Agenda ERP para toda a equipe Operacional!` })
      } else {
        const j = await res.json().catch(() => ({}))
        setSyncMsg({ ok: false, text: j.error || "Erro ao publicar na agenda" })
      }
    } finally {
      setPublishing(null)
      setTimeout(() => setSyncMsg(null), 5000)
    }
  }

  async function syncGoogle() {
    setSyncing(true)
    setSyncMsg(null)
    try {
      const res = await fetch(`/api/integracoes/google/sync-obra/${obraId}`, { method: "POST" })
      const data = await res.json()
      if (res.ok) {
        setSyncMsg({ ok: true, text: data.msg ?? `${data.sincronizados} agendamento(s) sincronizado(s) com Google Calendar!` })
      } else {
        setSyncMsg({ ok: false, text: data.error ?? "Erro ao sincronizar" })
      }
    } finally {
      setSyncing(false)
      setTimeout(() => setSyncMsg(null), 5000)
    }
  }

  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h3 className="text-foreground font-medium flex items-center gap-2">
          <Calendar className="w-4 h-4 text-sky-400" /> Calendário técnico
        </h3>
        <button
          type="button"
          onClick={syncGoogle}
          disabled={syncing || eventos.length === 0}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-sky-600/15 border border-sky-500/30 text-sky-400 hover:bg-sky-600/25 hover:text-sky-300 text-xs font-medium transition-all disabled:opacity-40"
        >
          {syncing
            ? <><RefreshCw className="w-3.5 h-3.5 animate-spin" /> Sincronizando...</>
            : <><Calendar className="w-3.5 h-3.5" /> Sync Google Calendar</>
          }
        </button>
      </div>

      {syncMsg && (
        <div className={`flex items-center gap-2 text-xs px-3 py-2 rounded-2xl border ${syncMsg.ok ? "bg-green-500/10 border-green-500/20 text-green-400" : "bg-red-500/10 border-red-500/20 text-red-400"}`}>
          {syncMsg.text}
        </div>
      )}

      {/* Form rápido */}
      <div className="flex flex-wrap items-end gap-3 bg-muted/60 rounded-2xl p-4">
        <Field label="Evento"><Input value={titulo} onChange={e => setTitulo(e.target.value)}
          placeholder="Ex: Passagem de cabos" className="bg-muted border-border text-foreground w-56" /></Field>
        <Field label="Data"><Input type="date" max="9999-12-31" value={data} onChange={e => setData(e.target.value)}
          className="bg-muted border-border text-foreground" /></Field>
        <Field label="Equipe"><Input value={equipe} onChange={e => setEquipe(e.target.value)}
          placeholder="Ex: Equipe A" className="bg-muted border-border text-foreground w-40" /></Field>
        <Button onClick={add} disabled={!titulo.trim() || !data} className="bg-sky-600 hover:bg-sky-700 text-foreground gap-1.5">
          <Plus className="w-4 h-4" /> Agendar
        </Button>
      </div>

      {eventos.length === 0 ? (
        <p className="text-muted-foreground text-sm text-center py-6">Nenhum agendamento.</p>
      ) : (
        <div className="space-y-2">
          {eventos.map((e, i) => (
            <div key={i} className="flex items-center gap-3 bg-muted rounded-2xl p-3">
              <div className="text-center bg-card rounded-2xl px-3 py-1.5 flex-shrink-0">
                <p className="text-sky-400 font-bold text-sm">{e.data.split("-").reverse().slice(0, 2).join("/")}</p>
                <p className="text-muted-foreground/70 text-[10px]">{e.data.split("-")[0]}</p>
              </div>
              <div className="flex-1">
                <p className="text-foreground text-sm">{e.titulo}</p>
                {e.equipe && <p className="text-muted-foreground text-xs">{e.equipe}</p>}
                {"google_event_id" in e && e.google_event_id && (
                  <span className="text-[10px] text-sky-500 flex items-center gap-1 mt-0.5">
                    <Calendar className="w-2.5 h-2.5" /> no Google Calendar
                  </span>
                )}
              </div>
              <button
                type="button"
                onClick={() => publicarNaAgenda(e, i)}
                disabled={publishing === i}
                title="Publicar na Agenda ERP para equipe Operacional"
                className="flex items-center gap-1 px-2 py-1 rounded-xl text-[10px] font-medium bg-orange-500/10 text-orange-300 border border-orange-500/20 hover:bg-orange-500/20 transition-colors disabled:opacity-40 flex-shrink-0">
                {publishing === i ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Calendar className="w-3 h-3" />}
                Agenda ERP
              </button>
              <Button size="sm" variant="ghost" onClick={() => onChange(eventos.filter((_, x) => x !== i))}
                className="text-muted-foreground/70 hover:text-red-400 h-8 w-8 p-0">
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ---- Senhas (cofre criptografado) ----
const EMPTY_CRED = { tipo: "", login: "", senha: "", mac: "", ip: "", anexo: "", obs: "" }

function SenhasTab({ obraId, credenciais, onReload }: {
  obraId: string; credenciais: Credencial[]; onReload: () => void
}) {
  const confirmar = useConfirmar()
  const [open, setOpen] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)
  const [f, setF] = useState({ ...EMPTY_CRED })
  const [saving, setSaving] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [revealed, setRevealed] = useState<Record<string, Revelado>>({})

  function abrirNova() {
    setEditId(null); setF({ ...EMPTY_CRED }); setOpen(true)
  }
  async function abrirEdicao(c: Credencial) {
    setEditId(c.id)
    // Começa com o que já temos (não-confidenciais)
    setF({ tipo: c.tipo_equipamento, login: c.login || "", senha: "", mac: "", ip: "", anexo: c.anexo_url || "", obs: c.observacoes || "" })
    setOpen(true)
    // Busca os valores confidenciais descriptografados para pré-preencher
    if (c.tem_senha || c.tem_mac || c.tem_ip) {
      const res = await fetch(`/api/obras/${obraId}/credenciais/${c.id}/revelar`)
      if (res.ok) {
        const d: Revelado = await res.json()
        setF(prev => ({ ...prev, senha: d.senha || "", mac: d.mac || "", ip: d.ip || "" }))
      }
    }
  }

  async function enviarArquivo(file: File) {
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append("file", file)
      const res = await fetch("/api/upload", { method: "POST", body: fd })
      if (res.ok) {
        const { url } = await res.json()
        setF(prev => ({ ...prev, anexo: url }))
      }
    } finally { setUploading(false) }
  }

  async function salvar() {
    if (!f.tipo.trim()) return
    setSaving(true)
    try {
      const payload = {
        tipo_equipamento: f.tipo, login: f.login, senha: f.senha,
        mac: f.mac, ip: f.ip, anexo_url: f.anexo, observacoes: f.obs,
      }
      const url = editId
        ? `/api/obras/${obraId}/credenciais/${editId}`
        : `/api/obras/${obraId}/credenciais`
      const res = await fetch(url, {
        method: editId ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })
      if (res.ok) { setOpen(false); onReload() }
    } finally { setSaving(false) }
  }

  async function excluir(credId: string) {
    if (!await confirmar({ titulo: "Excluir esta credencial?", perigo: true })) return
    const res = await fetch(`/api/obras/${obraId}/credenciais/${credId}`, { method: "DELETE" })
    if (res.ok) onReload()
  }

  async function revelar(credId: string) {
    if (revealed[credId]) {
      setRevealed(r => { const c = { ...r }; delete c[credId]; return c })
      return
    }
    const res = await fetch(`/api/obras/${obraId}/credenciais/${credId}/revelar`)
    if (res.ok) {
      const dados: Revelado = await res.json()
      setRevealed(r => ({ ...r, [credId]: dados }))
    }
  }

  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-foreground font-medium flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-green-400" /> Cofre de credenciais (criptografado)
        </h3>
        <Button size="sm" onClick={abrirNova} className="bg-sky-600 hover:bg-sky-700 text-foreground gap-1.5">
          <Plus className="w-4 h-4" /> Nova credencial
        </Button>
      </div>

      {credenciais.length === 0 ? (
        <p className="text-muted-foreground text-sm py-6 text-center">Nenhuma credencial cadastrada.</p>
      ) : (
        <div className="space-y-2">
          {credenciais.map(c => {
            const rv = revealed[c.id]
            return (
              <div key={c.id} className="bg-muted rounded-2xl p-3 flex items-center gap-3">
                <KeyRound className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                <div className="flex-1 min-w-0 space-y-0.5">
                  <p className="text-foreground text-sm">{c.tipo_equipamento}</p>
                  {(c.login || c.tem_senha) && (
                    <p className="text-muted-foreground text-xs">
                      {c.login && `login: ${c.login}`}
                      {c.login && c.tem_senha && " · "}
                      {c.tem_senha && <>senha: <span className="font-mono">{rv ? (rv.senha ?? "—") : "••••••••"}</span></>}
                    </p>
                  )}
                  {(c.tem_mac || c.tem_ip) && (
                    <p className="text-muted-foreground text-xs">
                      {c.tem_mac && <>MAC: <span className="font-mono">{rv ? (rv.mac ?? "—") : "••••••••"}</span></>}
                      {c.tem_mac && c.tem_ip && " · "}
                      {c.tem_ip && <>IP: <span className="font-mono">{rv ? (rv.ip ?? "—") : "••••••••"}</span></>}
                    </p>
                  )}
                  {c.anexo_url && (
                    <a href={c.anexo_url} target="_blank" rel="noreferrer"
                      className="text-sky-400 hover:text-sky-300 text-xs inline-flex items-center gap-1">
                      <Paperclip className="w-3 h-3" /> Anexo
                    </a>
                  )}
                  {c.observacoes && <p className="text-muted-foreground/70 text-xs">{c.observacoes}</p>}
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  {(c.tem_senha || c.tem_mac || c.tem_ip) && (
                    <Button size="sm" variant="ghost" onClick={() => revelar(c.id)}
                      className="text-muted-foreground hover:text-foreground gap-1.5 h-8">
                      {rv ? <><EyeOff className="w-3.5 h-3.5" /> Ocultar</> : <><Eye className="w-3.5 h-3.5" /> Revelar</>}
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" onClick={() => abrirEdicao(c)}
                    className="text-muted-foreground hover:text-foreground h-8 w-8 p-0" title="Editar">
                    <Pencil className="w-3.5 h-3.5" />
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => excluir(c.id)}
                    className="text-muted-foreground/70 hover:text-red-400 h-8 w-8 p-0" title="Excluir">
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>
            )
          })}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editId ? "Editar credencial" : "Nova credencial"}</DialogTitle></DialogHeader>
          <div className="space-y-3 px-5 sm:px-6 py-4">
            <Field label="Tipo de equipamento *"><Input value={f.tipo} onChange={e => setF({ ...f, tipo: e.target.value })}
              placeholder="Ex: Roteador, Câmera, Switch, Central Control4" className="bg-muted border-border text-foreground" /></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Login (opcional)"><Input value={f.login} onChange={e => setF({ ...f, login: e.target.value })}
                className="bg-muted border-border text-foreground" /></Field>
              <Field label="Senha (opcional)"><Input type="text" value={f.senha} onChange={e => setF({ ...f, senha: e.target.value })}
                placeholder={editId ? "manter atual" : ""} className="bg-muted border-border text-foreground font-mono" /></Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="MAC (confidencial)"><Input value={f.mac} onChange={e => setF({ ...f, mac: e.target.value })}
                placeholder="00:1A:2B:3C:4D:5E" className="bg-muted border-border text-foreground font-mono" /></Field>
              <Field label="IP (confidencial)"><Input value={f.ip} onChange={e => setF({ ...f, ip: e.target.value })}
                placeholder="192.168.1.10" className="bg-muted border-border text-foreground font-mono" /></Field>
            </div>
            <Field label="Anexar arquivo (opcional)">
              <div className="flex items-center gap-2">
                <input type="file" id="cred-file" className="hidden"
                  onChange={e => { const file = e.target.files?.[0]; if (file) enviarArquivo(file) }} />
                <label htmlFor="cred-file"
                  className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-muted border border-border text-foreground/80 hover:text-foreground text-sm">
                  <Paperclip className="w-4 h-4" /> {uploading ? "Enviando..." : "Escolher arquivo"}
                </label>
                {f.anexo && (
                  <span className="flex items-center gap-1.5 text-xs text-green-400">
                    <FileText className="w-3.5 h-3.5" /> Anexado
                    <button type="button" onClick={() => setF({ ...f, anexo: "" })}
                      className="text-muted-foreground hover:text-red-400"><Trash2 className="w-3 h-3" /></button>
                  </span>
                )}
              </div>
            </Field>
            <Field label="Notas / Observações"><Textarea value={f.obs} onChange={e => setF({ ...f, obs: e.target.value })}
              rows={2} placeholder="Anotações livres sobre este dispositivo..." className="bg-muted border-border text-foreground" /></Field>
            <p className="text-muted-foreground/70 text-xs flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" /> Senha, MAC e IP são criptografados (AES-256) antes de gravar.
            </p>
          </div>
          <DialogFooter className="gap-2 sm:gap-2">
            <Button variant="outline" onClick={() => setOpen(false)}
              className="border-border text-foreground/80 flex-1">Cancelar</Button>
            <Button onClick={salvar} disabled={!f.tipo.trim() || saving}
              className="bg-sky-600 hover:bg-sky-700 text-foreground flex-1">
              {saving ? "Salvando..." : "Salvar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
