﻿"use client"

import { useState, useEffect, useCallback } from "react"
import { PageLoader } from "@/components/ui/bouncing-dots"
import { HardHat, RefreshCw, Package, Box, ArrowRight } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

interface ObraItem {
  nome: string
  quantidade: number
  is_aditivo: boolean
}
interface ObraAmbiente {
  id: string
  nome: string
  itens: ObraItem[]
}
interface Obra {
  id: string
  client_name: string
  address: string | null
  etapa: string | null
  logistics_status: string
  physical_progress_percentage: number
  compra_liberada: boolean
  proposta_origem: string | null
  resp_comercial: string | null
  createdAt: string
  ambientes: ObraAmbiente[]
}

export default function ObrasRawPage() {
  const [obras, setObras] = useState<Obra[]>([])
  const [loading, setLoading] = useState(true)

  const fetchObras = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/obras")
      const data = await res.json()
      setObras(data.obras || [])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchObras() }, [fetchObras])

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <HardHat className="w-6 h-6 text-amber-400" /> Obras (listagem de teste)
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            {obras.length} obra{obras.length !== 1 ? "s" : ""} · listagem crua da Fase 5, a tela final vem na Fase 6
          </p>
        </div>
        <Button onClick={fetchObras} variant="outline"
          className="border-border text-muted-foreground/70 hover:text-white gap-1.5">
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} /> Atualizar
        </Button>
      </div>

      {loading ? (
        <div className="py-16 flex justify-center"><PageLoader /></div>
      ) : obras.length === 0 ? (
        <div className="text-center py-16 bg-background rounded-xl border border-border/30">
          <HardHat className="w-12 h-12 text-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">Nenhuma obra ainda.</p>
          <p className="text-muted-foreground text-sm mt-1">
            Aceite uma proposta (pelo link do cliente ou movendo no Kanban para &quot;Aceita&quot;) e ela aparece aqui.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {obras.map(obra => (
            <div key={obra.id} className="bg-background rounded-xl border border-border/30 overflow-hidden">
              {/* Cabeçalho da obra */}
              <div className="p-5 border-b border-border/20 flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h2 className="text-lg font-semibold text-white">{obra.client_name}</h2>
                  <p className="text-muted-foreground text-sm">{obra.address || "Sem endereço"}</p>
                  <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                    {obra.proposta_origem && (
                      <span className="flex items-center gap-1">
                        Origem: <span className="text-sky-400 font-medium">{obra.proposta_origem}</span>
                      </span>
                    )}
                    {obra.resp_comercial && <span>· Comercial: {obra.resp_comercial}</span>}
                  </div>
                  <p className="text-foreground text-[10px] font-mono mt-1">{obra.id}</p>
                </div>
                <div className="flex flex-col items-end gap-1.5">
                  <Badge variant="warning">{obra.etapa || "—"}</Badge>
                  <span className="text-xs text-muted-foreground">{obra.logistics_status}</span>
                  <span className="text-xs text-muted-foreground">Progresso: {obra.physical_progress_percentage}%</span>
                  <span className={`text-xs ${obra.compra_liberada ? "text-green-400" : "text-muted-foreground"}`}>
                    Compra {obra.compra_liberada ? "liberada" : "bloqueada"}
                  </span>
                </div>
              </div>

              {/* Ambientes espelhados */}
              <div className="p-5 space-y-3">
                <p className="text-muted-foreground text-xs uppercase tracking-wide flex items-center gap-1.5">
                  <Box className="w-3.5 h-3.5" /> Ambientes espelhados ({obra.ambientes.length})
                </p>
                {obra.ambientes.length === 0 ? (
                  <p className="text-muted-foreground text-sm">Nenhum ambiente espelhado.</p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {obra.ambientes.map(env => (
                      <div key={env.id} className="bg-card/60 rounded-2xl p-3">
                        <p className="text-white text-sm font-medium mb-2">{env.nome}</p>
                        {env.itens.length === 0 ? (
                          <p className="text-muted-foreground text-xs">Sem itens</p>
                        ) : (
                          <ul className="space-y-1">
                            {env.itens.map((it, i) => (
                              <li key={i} className="flex items-center gap-2 text-xs text-muted-foreground/70">
                                <Package className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                                <span className="flex-1">{it.nome}</span>
                                <span className="text-muted-foreground">x{it.quantidade}</span>
                                {it.is_aditivo && (
                                  <Badge variant="default" className="text-[10px] py-0 px-1.5">aditivo</Badge>
                                )}
                              </li>
                            ))}
                          </ul>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

