"use client"

/**
 * Infraestrutura (eletrodutos) — Obra → Engenharia → Projetos → Projeto Controllares.
 *
 * Desenhar primeiro, preencher depois: cada rota, ponto ou caixa abre a janela
 * de dados assim que é desenhada. A escala sai do "1:N" escrito no PDF e é
 * conferida pelas cotas (o programa mede; a IA só lê número de cota em planta
 * de imagem). "Prancha" gera o A1 em PDF e grava em Projetos com versão.
 */
import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from "react"
import Link from "next/link"
import {
  ArrowLeft, Box, Cable, Crop, FileDown, Loader2, Map as MapIcon, Maximize2, Minus, MousePointer2,
  Plus, Redo2, Ruler, Save, Square, Trash2, Undo2, X, Check,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  ALTURAS, CABOS, CAIXA_LOCAL, CAIXA_PONTO, CAIXA_TAM, COR, DIAMETROS, EQUIPAMENTOS, INSTALACAO, PAVIMENTOS, SISTEMAS, TIPOS,
  arrastarComRotas, cabosTexto, caminho, categoriaDe, centro, curvas, estudoInfraVazio, fmt, metros, normalizaEstudoInfra,
  novoIdItem, orto, pavVazio, reto, rotaAutomatica, snap, totais, unidade,
  type Caixa, type EstudoInfra, type P, type PavInfra, type PlantaPavInfra, type Ponto, type Rota,
} from "@/lib/projetos/infra"
import { camadaCotas, camadas, pranchaSvg } from "@/lib/projetos/infra-desenho"
import { conferirPorCotas, escalaDoTexto, mmPorPxDaEscala } from "@/lib/projetos/escala"
import { acharPlanta, carregarPlanta, cortarImagem, subirArquivo } from "@/lib/projetos/planta"
import { paraDataUrl, svgParaPdf } from "@/lib/projetos/prancha-pdf"
import { EscolherPlanta, Recorte, adicionarBlueprint, nomeArquivo, proximaVersao, roda, src, type Anexo, type Blueprint } from "../_projetos/comum"

type Ferramenta = "ligar" | "rota" | "cp" | "pt" | "sel" | "cal"
interface ObraDados {
  id: string; client_name: string; projetos_blueprints: Blueprint[] | null; anexos_projeto: Anexo[] | null
  estudo_infra: unknown; rua?: string | null; numero?: string | null; bairro?: string | null; cidade?: string | null
}

export default function EstudoInfra({ obraId }: { obraId: string }) {
  const [obra, setObra] = useState<ObraDados | null>(null)
  const [erro, setErro] = useState("")
  const [e, setE] = useState<EstudoInfra>(estudoInfraVazio())
  const [pav, setPav] = useState<string>("TÉRREO")
  const [ferr, setFerr] = useState<Ferramenta>("ligar")
  const [sel, setSel] = useState<string | null>(null)
  const [liga, setLiga] = useState<string | null>(null)
  const [rascunho, setRascunho] = useState<{ p: P[]; cur?: P } | null>(null)
  const [cal, setCal] = useState<{ a?: P } | null>(null)
  const [mouse, setMouse] = useState<P | null>(null)
  const [dados, setDados] = useState<{ id: string; novo: boolean } | null>(null)
  const [escolher, setEscolher] = useState(false)
  const [crop, setCrop] = useState<{ f: [number, number, number, number]; orig: { img: string; W: number; H: number } } | null>(null)
  const [prancha, setPrancha] = useState(false)
  const [verCotas, setVerCotas] = useState(false)
  const [ocupado, setOcupado] = useState("")
  const [aviso, setAviso] = useState("")
  const [salvo, setSalvo] = useState<"" | "salvando" | "ok">("")
  const carregou = useRef(false)
  const gravado = useRef("")
  const eRef = useRef(e)
  eRef.current = e
  const hist = useRef<EstudoInfra[]>([])
  const fut = useRef<EstudoInfra[]>([])
  const pdfDados = useRef<Record<string, { dados: ArrayBuffer | null; pxPorPt: number | null; imagem: string }>>({})

  const P = e.pavs[pav] ?? pavVazio()
  const planta = P.planta
  const U = planta ? unidade(planta.W) : 1

  /* ---------- carregar e gravar ---------- */
  useEffect(() => {
    ;(async () => {
      try {
        const r = await fetch(`/api/obras/${obraId}`)
        if (!r.ok) throw new Error("Não consegui abrir a obra.")
        const o = (await r.json()) as ObraDados
        setObra(o)
        const est = normalizaEstudoInfra(o.estudo_infra, o.client_name)
        if (!est.prancha.local) est.prancha.local = [o.rua, o.numero, o.bairro, o.cidade].filter(Boolean).join(", ").toUpperCase()
        gravado.current = JSON.stringify(normalizaEstudoInfra(o.estudo_infra, o.client_name))
        setE(est)
        carregou.current = true
        const primeiro = PAVIMENTOS.find((p) => est.pavs[p]?.planta)
        if (primeiro) setPav(primeiro)
      } catch (err) {
        setErro(err instanceof Error ? err.message : "Erro ao abrir.")
      }
    })()
  }, [obraId])

  useEffect(() => {
    const atual = JSON.stringify(e)
    if (!carregou.current || atual === gravado.current) return
    setSalvo("salvando")
    const t = setTimeout(async () => {
      const r = await fetch(`/api/obras/${obraId}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ estudo_infra: e }) }).catch(() => null)
      if (r?.ok) gravado.current = atual
      setSalvo(r?.ok ? "ok" : "")
    }, 800)
    return () => clearTimeout(t)
  }, [e, obraId])

  const marcar = useCallback(() => {
    hist.current.push(structuredClone(eRef.current))
    if (hist.current.length > 80) hist.current.shift()
    fut.current = []
  }, [])
  const mudar = useCallback((fn: (n: EstudoInfra) => void) => {
    setE((v) => { const n = structuredClone(v); fn(n); return n })
  }, [])
  const mudarPav = useCallback((fn: (p: PavInfra, n: EstudoInfra) => void) => {
    mudar((n) => { n.pavs[pav] ??= pavVazio(); fn(n.pavs[pav], n) })
  }, [mudar, pav])
  const desfazer = () => { const v = hist.current.pop(); if (v) { fut.current.push(structuredClone(eRef.current)); setE(v); setSel(null) } }
  const refazer = () => { const v = fut.current.pop(); if (v) { hist.current.push(structuredClone(eRef.current)); setE(v); setSel(null) } }
  const apagarSel = () => {
    if (!sel) return
    marcar()
    mudarPav((p) => { p.rotas = p.rotas.filter((r) => r.id !== sel); p.pts = p.pts.filter((x) => x.id !== sel); p.cps = p.cps.filter((c) => c.id !== sel) })
    setSel(null)
  }

  /* ---------- planta e escala ---------- */
  async function abrirPlanta(fonte: File | { url: string; nome: string }, origem: { nome: string; url: string } | null) {
    const tem = P.rotas.length + P.pts.length + P.cps.length
    if (tem && !confirm(`Este pavimento já tem ${tem} item(ns) desenhado(s). Eles continuam nas mesmas posições na planta nova; confira e arraste se precisar. Trocar a planta?`)) return
    setEscolher(false)
    setOcupado("Abrindo a planta…")
    try {
      const pl = await carregarPlanta(fonte instanceof File ? fonte : { url: src(fonte.url), nome: fonte.nome })
      setOcupado("Guardando a planta…")
      const url = await subirArquivo(pl.dataUrl, `infra-${pav.toLowerCase()}.jpg`)
      let orig = origem
      if (fonte instanceof File) {
        const urlArq = await subirArquivo(fonte, fonte.name)
        orig = { nome: fonte.name, url: urlArq }
        const { lista } = await adicionarBlueprint(obraId, { categoria: "Projeto de Obra", nome: fonte.name.replace(/\.[a-z0-9]+$/i, ""), url: urlArq })
        setObra((o) => (o ? { ...o, projetos_blueprints: lista } : o))
      }
      const N = pl.pxPorPt ? escalaDoTexto(pl.linhas) : null
      const nova: PlantaPavInfra = { origem: orig, img: url, W: pl.W, H: pl.H, orig: { img: url, W: pl.W, H: pl.H }, off: { x: 0, y: 0 }, salas: pl.salas, salasOrig: pl.salas, pxPorPt: pl.pxPorPt }
      marcar()
      mudarPav((p) => {
        const velha = p.planta
        if (velha?.orig) {
          const sx = nova.W / velha.orig.W, sy = nova.H / velha.orig.H
          const m = (q: P): P => [(q[0] + velha.off.x) * sx, (q[1] + velha.off.y) * sy]
          p.rotas.forEach((r) => (r.p = r.p.map(m)))
          p.pts.forEach((x) => { [x.x, x.y] = m([x.x, x.y]) })
          p.cps.forEach((c) => { [c.x, c.y] = m([c.x, c.y]) })
        }
        p.planta = nova
        p.nome = orig?.nome.replace(/\.[a-z0-9]+$/i, "") ?? p.nome
        p.escala = N && pl.pxPorPt
          ? { N, mmPorPx: mmPorPxDaEscala(N, pl.pxPorPt), fonte: `lida do PDF (ESCALA 1:${N})` }
          : { N: null, mmPorPx: null, fonte: "" }
      })
      pdfDados.current[pav] = { dados: pl.dados, pxPorPt: pl.pxPorPt, imagem: pl.dataUrl }
      setOcupado("")
      conferirEscala(pav, N)
      setTimeout(() => abrirRecorte(nova), 50)
    } catch (err) {
      setOcupado("")
      alert(err instanceof Error ? err.message : "Não consegui abrir a planta.")
    }
  }

  async function conferirEscala(p: string, N: number | null) {
    const fonte = pdfDados.current[p]
    if (!fonte) return
    mudar((n) => { n.pavs[p].escala.conferencia = { estado: "ok", fonte: "rodando" } })
    try {
      const r = await conferirPorCotas(fonte, async (folha) => {
        const resp = await fetch(`/api/obras/${obraId}/ler-cotas`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ img: folha }) })
        const j = await resp.json().catch(() => ({}))
        if (!resp.ok) throw new Error(j.error || "A IA não leu as cotas.")
        return j.l ?? {}
      })
      mudar((n) => {
        const esc = n.pavs[p].escala
        esc.cotas = r.cotas
        if (r.estado === "semcotas") { esc.conferencia = { estado: "semcotas", n: r.n, total: r.total, fonte: r.fonte }; return }
        const mm = 1000 / r.pxPorMetro!
        const base = { n: r.n, total: r.total, fonte: r.fonte, Nc: r.Nc ?? null, mmPorPx: mm }
        if (N && r.Nc === N) esc.conferencia = { estado: "ok", ...base }
        else if (N) esc.conferencia = { estado: "conflito", ...base }
        else { esc.mmPorPx = mm; esc.N = r.Nc ?? null; esc.fonte = "calculada pelas cotas"; esc.conferencia = { estado: "calculada", ...base } }
      })
    } catch (err) {
      mudar((n) => { n.pavs[p].escala.conferencia = { estado: "erro", msg: err instanceof Error ? err.message : "erro" } })
    }
  }

  async function abrirRecorte(pl = planta) {
    if (!pl?.orig) return
    const o = pl.orig
    const atual: [number, number, number, number] = [pl.off.x / o.W, pl.off.y / o.H, (pl.off.x + pl.W) / o.W, (pl.off.y + pl.H) / o.H]
    const cortada = pl.off.x || pl.off.y || pl.W !== o.W || pl.H !== o.H
    setCrop({ f: atual, orig: o })
    if (!cortada) { const f = await acharPlanta(src(o.img)); setCrop((c) => (c ? { ...c, f } : c)) }
  }

  async function aplicarRecorte(f: [number, number, number, number]) {
    if (!crop || !planta) return
    setOcupado("Recortando…")
    try {
      const r = await cortarImagem(src(crop.orig.img), f)
      const url = await subirArquivo(r.dataUrl, `infra-${pav.toLowerCase()}-recorte.jpg`)
      const dx = r.x - planta.off.x, dy = r.y - planta.off.y
      marcar()
      mudarPav((p) => {
        if (!p.planta) return
        p.rotas.forEach((rt) => (rt.p = rt.p.map(([x, y]) => [x - dx, y - dy] as P)))
        p.pts.forEach((x) => { x.x -= dx; x.y -= dy })
        p.cps.forEach((c) => { c.x -= dx; c.y -= dy })
        Object.assign(p.planta, { img: url, W: r.W, H: r.H, off: { x: r.x, y: r.y } })
      })
      setCrop(null)
    } catch (err) {
      alert(err instanceof Error ? err.message : "Não consegui recortar.")
    } finally {
      setOcupado("")
    }
  }

  /* ---------- desenhar ---------- */
  const novaRota = (p: P[], nome: string, de?: string) => {
    const id = novoIdItem(P.rotas, "R")
    const u = e.ult
    marcar()
    mudarPav((pv) => pv.rotas.push({ id, nome, p, d: u.d, tipo: u.tipo, inst: u.inst, sist: u.sist, cabos: u.cabos.map((c) => ({ ...c })), guia: u.guia, obs: "", de }))
    setSel(id)
    setDados({ id, novo: true })
  }
  const concluirRota = () => {
    if (!rascunho) return
    const p = reto(rascunho.p)
    const para = (rascunho as { para?: string }).para
    setRascunho(null)
    if (p.length >= 2) novaRota(p, para ?? "Trecho")
  }
  const trocarFerramenta = (f: Ferramenta) => {
    if (ferr === "rota" && f !== "rota") concluirRota()
    setFerr(f); setLiga(null); setCal(null)
  }

  function cliqueNaPlanta(q: P, alvo: string | null) {
    if (!planta) return
    if (ferr === "cal") {
      if (!cal?.a) return setCal({ a: q })
      const d = prompt("Medida real entre os dois pontos, em metros (ex.: 4,50)")
      const px = Math.hypot(q[0] - cal.a[0], q[1] - cal.a[1])
      const m = d ? parseFloat(d.replace(",", ".")) : NaN
      if (Number.isFinite(m) && m > 0 && px) {
        marcar()
        mudarPav((p) => { p.escala = { ...p.escala, mmPorPx: (m * 1000) / px, N: null, fonte: "calibrada pela cota marcada", conferencia: undefined } })
      }
      setCal(null); setFerr("sel")
      return
    }
    if (ferr === "sel") return setSel(alvo)
    if (ferr === "ligar") {
      const el = alvo && !alvo.startsWith("R") ? alvo : null
      if (!el) return
      if (!liga || liga === el) { setLiga(el); setSel(null); return }
      const r = rotaAutomatica(P, liga, el, U)
      if (r) novaRota(r.p, r.nome, r.de)
      if (!P.cps.find((c) => c.id === liga)) setLiga(null)
      return
    }
    if (ferr === "cp") {
      const id = novoIdItem(P.cps, "CP-")
      marcar()
      mudarPav((p) => p.cps.push({ id, x: q[0] - 18 * U, y: q[1] - 36 * U, w: 36 * U, h: 72 * U, tam: "30x30", local: "Parede", obs: "" }))
      setSel(id); setDados({ id, novo: true })
      return
    }
    if (ferr === "pt") {
      const id = novoIdItem(P.pts, "PT-")
      marcar()
      mudarPav((p) => p.pts.push({ id, x: q[0], y: q[1], d: "EQUIP. NOVO", equip: "Outro", alt: "", cx: "4x2", amb: "", obs: "" }))
      setSel(id); setDados({ id, novo: true })
      return
    }
    if (ferr === "rota") {
      const el = alvo && !alvo.startsWith("R") ? centro(P, alvo) : null
      if (!rascunho) return setRascunho({ p: [el ? [el.cx, el.cy] : q] })
      const ult = rascunho.p[rascunho.p.length - 1]
      if (el) {
        const p = reto([...rascunho.p, [el.cx, el.cy]])
        setRascunho(null)
        if (p.length >= 2) novaRota(p, alvo!)
        return
      }
      const o = orto(ult, q)
      if (o[0] !== ult[0] || o[1] !== ult[1]) setRascunho({ p: [...rascunho.p, o] })
    }
  }

  /* ---------- teclado ---------- */
  useEffect(() => {
    const h = (ev: KeyboardEvent) => {
      const alvo = ev.target instanceof Element ? ev.target : null
      if (dados || escolher || crop || prancha || alvo?.closest("input, textarea, select, [contenteditable=true]")) return
      const k = ev.key.toLowerCase()
      if (ev.key === "Escape") { if (rascunho) concluirRota(); else { setLiga(null); setCal(null); setSel(null) } return }
      if (ev.key === "Enter" && rascunho) { concluirRota(); return }
      if (ev.key === "Enter" && sel) { setDados({ id: sel, novo: false }); return }
      if (ev.key === "Backspace" && rascunho) { ev.preventDefault(); const p = rascunho.p.slice(0, -1); setRascunho(p.length ? { p } : null); return }
      if ((ev.ctrlKey || ev.metaKey) && k === "z") { ev.preventDefault(); if (ev.shiftKey) refazer(); else desfazer(); return }
      if ((ev.ctrlKey || ev.metaKey) && k === "y") { ev.preventDefault(); refazer(); return }
      if ((ev.key === "Delete" || ev.key === "Backspace") && sel) { ev.preventDefault(); apagarSel(); return }
      if (ev.ctrlKey || ev.metaKey || ev.altKey) return
      const f = ({ l: "ligar", r: "rota", c: "cp", p: "pt", v: "sel" } as Record<string, Ferramenta>)[k]
      if (f) trocarFerramenta(f)
    }
    window.addEventListener("keydown", h)
    return () => window.removeEventListener("keydown", h)
  })

  /* ---------- prancha ---------- */
  const nomeProjeto = `Infraestrutura – ${pav.charAt(0)}${pav.slice(1).toLowerCase()}`
  const revAuto = proximaVersao(obra?.projetos_blueprints ?? null, "Projeto Controllares", nomeProjeto)
  async function gerarPrancha(salvar: boolean) {
    if (!planta || !obra) return
    setOcupado("Montando a prancha…")
    try {
      const pr = { ...e.prancha }
      pr.titulo ||= `PLANTA ${pav} - INFRAESTRUTURA (ELETRODUTOS)`
      pr.tfolha ||= `INFRAESTRUTURA - ELETRODUTOS - PAVIMENTO ${pav}`
      pr.base ||= P.planta?.origem?.nome?.toUpperCase() ?? ""
      pr.rev ||= revAuto
      const [img, logo] = await Promise.all([paraDataUrl(src(planta.img)), paraDataUrl("/brand/logo-completo.png").catch(() => "")])
      const pdf = await svgParaPdf(pranchaSvg(P, pr, img, logo))
      const nome = nomeArquivo("INFRAESTRUTURA", pav, obra.client_name)
      if (salvar) {
        setOcupado("Salvando em Projetos…")
        const url = await subirArquivo(pdf, `${nome}.pdf`)
        const { versao, lista } = await adicionarBlueprint(obraId, { categoria: "Projeto Controllares", nome: nomeProjeto, url })
        setObra((o) => (o ? { ...o, projetos_blueprints: lista } : o))
        setAviso(`Prancha salva em Projetos → Projeto Controllares (${versao}).`)
        setPrancha(false)
      } else {
        const a = document.createElement("a")
        a.href = URL.createObjectURL(pdf)
        a.download = `${nome}.pdf`
        a.click()
      }
    } catch (err) {
      alert(err instanceof Error ? err.message : "Não consegui gerar a prancha.")
    } finally {
      setOcupado("")
    }
  }

  /* ---------- render ---------- */
  if (erro) return <div className="p-6 text-sm text-destructive">{erro}</div>
  if (!obra) return <div className="grid place-items-center p-10 text-muted-foreground"><Loader2 className="size-5 animate-spin" /></div>

  const item = dados ? P.rotas.find((r) => r.id === dados.id) ?? P.pts.find((x) => x.id === dados.id) ?? P.cps.find((c) => c.id === dados.id) : undefined
  const ferramentas: Array<[Ferramenta, string, typeof Cable, string]> = [
    ["ligar", "Ligar", Cable, "Ligar caixa a um ponto: a rota sai sozinha (L)"],
    ["rota", "Rota", Ruler, "Rota manual, canto por canto (R)"],
    ["cp", "Caixa", Box, "Caixa de passagem (C)"],
    ["pt", "Ponto", Square, "Ponto de equipamento (P)"],
    ["sel", "Mover", MousePointer2, "Selecionar e mover (V)"],
  ]

  return (
    <div className="space-y-3 p-3 sm:p-4">
      {/* Cabeçalho */}
      <div className="ios-card flex flex-wrap items-center justify-between gap-3 p-4">
        <div className="flex min-w-[12rem] flex-1 basis-0 items-center gap-3">
          <Link href={`/obras/${obraId}?tab=engenharia&sub=projetos`} className="grid size-10 shrink-0 place-items-center rounded-full bg-foreground/[0.06] hover:bg-foreground/[0.1]" title="Voltar para Projetos"><ArrowLeft className="size-[18px]" /></Link>
          <div className="min-w-0">
            <h1 className="truncate text-[20px] font-semibold leading-tight tracking-tight">Infraestrutura</h1>
            <p className="truncate text-[13px] text-muted-foreground">{obra.client_name} · eletrodutos{salvo === "salvando" ? " · salvando…" : salvo === "ok" ? " · salvo" : ""}</p>
          </div>
        </div>
        <Button onClick={() => setPrancha(true)} disabled={!planta}><FileDown className="size-4" />Prancha</Button>
      </div>

      {/* Planta + escala */}
      <div className="grid grid-cols-3 items-center gap-2 rounded-2xl border border-border bg-card p-2.5 sm:flex sm:flex-wrap">
        <select value={pav} onChange={(ev) => { setPav(ev.target.value); setSel(null); setRascunho(null); setLiga(null) }}
          className="col-span-3 h-9 rounded-xl border border-border bg-background px-2.5 text-xs font-semibold sm:col-span-1">
          {PAVIMENTOS.map((p) => <option key={p}>{p}</option>)}
        </select>
        <div className="col-span-3 min-w-0 flex-1 px-1">
          <p className="truncate text-sm font-medium">{planta ? (P.nome || "Planta") : "Sem planta neste pavimento"}</p>
          <LinhaEscala pav={P} verCotas={verCotas} onVerCotas={() => setVerCotas((v) => !v)}
            onUsar={() => { const c = P.escala.conferencia; if (!c?.mmPorPx) return; marcar(); mudarPav((p) => { p.escala = { ...p.escala, mmPorPx: c.mmPorPx!, N: c.Nc ?? p.escala.N, fonte: "pelas cotas", conferencia: { ...c, estado: "calculada" } } }) }}
            onManter={() => mudarPav((p) => { if (p.escala.conferencia) p.escala.conferencia.estado = "mantida" })}
            onMarcar={() => { trocarFerramenta("cal"); setCal({}) }} />
        </div>
        <Button size="sm" variant="outline" onClick={() => setEscolher(true)}><MapIcon className="size-4" />{planta ? "Trocar" : "Escolher planta"}</Button>
        {planta && <Button size="sm" variant="outline" onClick={() => abrirRecorte()}><Crop className="size-4" />Recortar</Button>}
      </div>
      {aviso && <div className="flex items-center gap-2 rounded-xl bg-foreground/[0.05] px-3 py-2 text-sm"><Check className="size-4" />{aviso}<button className="ml-auto text-muted-foreground" onClick={() => setAviso("")}><X className="size-4" /></button></div>}

      {/* Ferramentas */}
      <div className="grid grid-cols-4 gap-1.5 rounded-2xl border border-border bg-card p-2 sm:flex sm:flex-wrap sm:items-center">
        {ferramentas.map(([f, l, I, t]) => (
          <button key={f} title={t} onClick={() => trocarFerramenta(f)}
            className={`flex h-[52px] flex-col items-center justify-center gap-0.5 rounded-xl text-[11.5px] font-medium sm:h-9 sm:flex-row sm:gap-1.5 sm:px-3 sm:text-[13px] ${ferr === f ? "bg-foreground text-background" : "bg-foreground/[0.03] hover:bg-foreground/[0.07]"}`}>
            <I className="size-[18px] sm:size-4" />{l}
          </button>
        ))}
        <span className="hidden flex-1 sm:block" />
        {([["Desfazer", Undo2, desfazer, !hist.current.length], ["Refazer", Redo2, refazer, !fut.current.length], ["Apagar", Trash2, apagarSel, !sel]] as const).map(([l, I, fn, off]) => (
          <button key={l} onClick={fn} disabled={off} title={l}
            className="flex h-[52px] flex-col items-center justify-center gap-0.5 rounded-xl bg-foreground/[0.03] text-[11.5px] font-medium hover:bg-foreground/[0.07] disabled:opacity-35 sm:h-9 sm:w-9 sm:flex-row sm:px-0">
            <I className="size-[18px] sm:size-4" /><span className="sm:hidden">{l}</span>
          </button>
        ))}
      </div>

      <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_300px]">
        <Palco
          pav={P} U={U} ferr={ferr} sel={sel} liga={liga} rascunho={rascunho} cal={cal} mouse={mouse} verCotas={verCotas}
          onEscolher={() => setEscolher(true)}
          onMouse={(q, alvo) => {
            setMouse(q)
            if (ferr === "rota" && rascunho) {
              const C = alvo && !alvo.startsWith("R") ? centro(P, alvo) : null
              setRascunho({ ...rascunho, cur: C ? [C.cx, C.cy] : orto(rascunho.p[rascunho.p.length - 1], q) })
            }
          }}
          onClique={cliqueNaPlanta}
          onDuploClique={(alvo, vx) => {
            if (ferr === "rota" && rascunho) return concluirRota()
            if (vx != null && sel) {
              const r = P.rotas.find((x) => x.id === sel)
              if (r && vx > 0 && vx < r.p.length - 1) {
                marcar()
                mudarPav((p) => {
                  const rr = p.rotas.find((x) => x.id === sel)!
                  // Tirar o canto liga os vizinhos pelo outro "L"; numa escada isso some com uma curva, num "L" simples inverte o canto.
                  const [a, c, b] = [rr.p[vx - 1], rr.p[vx], rr.p[vx + 1]]
                  const outro: [number, number] = c[0] === b[0] && c[1] === a[1] ? [a[0], b[1]] : [b[0], a[1]]
                  rr.p.splice(vx, 1, ...(a[0] !== b[0] && a[1] !== b[1] ? [outro] : []))
                  rr.p = reto(rr.p)
                })
              }
              return
            }
            if (alvo && ferr === "sel") setDados({ id: alvo, novo: false })
          }}
          onDireito={() => { if (ferr === "rota" && rascunho) concluirRota(); else if (ferr === "ligar") setLiga(null) }}
          onInicioArrasto={marcar}
          onArrastaItem={(id, alvoCentro) => mudarPav((p) => {
            const C = centro(p, id)
            if (!C) return
            const nx = snap(alvoCentro[0], U), ny = snap(alvoCentro[1], U)
            arrastarComRotas(p, id, nx - C.cx, ny - C.cy, U)
          })}
          onArrastaCanto={(i, q) => mudarPav((p) => {
            const r = p.rotas.find((x) => x.id === sel)
            if (!r) return
            const v = r.p[i], a = r.p[i - 1], b = r.p[i + 1]
            const s: P = [snap(q[0], U), snap(q[1], U)]
            if (a && i - 1 > 0) { if (a[1] === v[1]) a[1] = s[1]; else a[0] = s[0] }
            if (b && i + 1 < r.p.length - 1) { if (b[1] === v[1]) b[1] = s[1]; else b[0] = s[0] }
            r.p[i] = s
          })}
          onFimArrasto={() => mudarPav((p) => { p.rotas.forEach((r) => (r.p = reto(r.p))) })}
        />
        <Painel pav={P} sel={sel} onSel={setSel} onEditar={(id) => setDados({ id, novo: false })} onApagar={apagarSel} />
      </div>

      {/* Janela de dados */}
      <Dialog open={!!dados && !!item} onOpenChange={(v) => !v && setDados(null)}>
        <DialogContent className="max-w-xl">
          {dados && item && (
            <JanelaDados key={dados.id} pav={P} item={item} novo={dados.novo} ult={e.ult}
              onSalvar={(novoItem, categoria) => {
                if (!dados.novo) marcar()
                mudar((n) => {
                  const p = n.pavs[pav]
                  const troca = <T extends { id: string }>(l: T[]) => l.map((x) => (x.id === dados.id ? (novoItem as unknown as T) : x))
                  p.rotas = troca(p.rotas); p.pts = troca(p.pts); p.cps = troca(p.cps)
                  if ("p" in novoItem) { const r = novoItem as Rota; n.ult = { ...n.ult, d: r.d, tipo: r.tipo, inst: r.inst, sist: r.sist, cabos: r.cabos.map((c) => ({ ...c })), guia: r.guia } }
                  if (categoria) n.ult.categoria = categoria
                })
                setDados(null)
              }}
              onApagar={() => { if (!dados.novo) marcar(); else hist.current.pop(); mudarPav((p) => { p.rotas = p.rotas.filter((r) => r.id !== dados.id); p.pts = p.pts.filter((x) => x.id !== dados.id); p.cps = p.cps.filter((c) => c.id !== dados.id) }); setSel(null); setDados(null) }}
              onCancelar={() => setDados(null)} />
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={escolher} onOpenChange={setEscolher}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Planta do pavimento {pav.toLowerCase()}</DialogTitle></DialogHeader>
          <EscolherPlanta obra={obra} onEscolher={(b) => abrirPlanta({ url: b.url, nome: b.nome }, { nome: b.nome, url: b.url })} onArquivo={(f) => abrirPlanta(f, null)} />
        </DialogContent>
      </Dialog>

      <Dialog open={!!crop} onOpenChange={(v) => !v && setCrop(null)}>
        <DialogContent className="max-w-5xl">
          <DialogHeader><DialogTitle>Recortar a planta</DialogTitle></DialogHeader>
          {crop && <Recorte img={src(crop.orig.img)} f={crop.f} onMudar={(f) => setCrop({ ...crop, f })}
            onAuto={async () => setCrop({ ...crop, f: await acharPlanta(src(crop.orig.img)) })}
            onCancelar={() => setCrop(null)} onAplicar={() => aplicarRecorte(crop.f)} />}
        </DialogContent>
      </Dialog>

      <Dialog open={prancha} onOpenChange={setPrancha}>
        <DialogContent className="max-w-3xl">
          <DialogHeader><DialogTitle>Prancha A1 · {pav.toLowerCase()}</DialogTitle></DialogHeader>
          <FormPrancha e={e} pav={pav} P={P} revAuto={revAuto} onMudar={(campo, v) => mudar((n) => { n.prancha = { ...n.prancha, [campo]: v.toUpperCase() } })}
            onSalvar={() => gerarPrancha(true)} onBaixar={() => gerarPrancha(false)} />
        </DialogContent>
      </Dialog>

      {ocupado && (
        <div className="fixed inset-0 z-[60] grid place-items-center bg-black/20 backdrop-blur-[2px]">
          <div className="flex items-center gap-2 rounded-2xl bg-card px-4 py-3 text-sm shadow-lg"><Loader2 className="size-4 animate-spin" />{ocupado}</div>
        </div>
      )}
    </div>
  )
}

/* ================= Escala ================= */
function LinhaEscala({ pav, verCotas, onVerCotas, onUsar, onManter, onMarcar }: {
  pav: PavInfra; verCotas: boolean; onVerCotas: () => void; onUsar: () => void; onManter: () => void; onMarcar: () => void
}) {
  const e = pav.escala, c = e.conferencia
  const link = "cursor-pointer underline underline-offset-2"
  const ver = e.cotas?.length ? <> · <span className={link} onClick={onVerCotas}>{verCotas ? "esconder" : "ver"} as cotas</span></> : null
  if (!pav.planta) return <p className="truncate text-xs text-muted-foreground">Escolha a planta em Projetos ou suba do computador</p>
  let corpo: React.ReactNode
  if (c?.fonte === "rodando") corpo = <><Loader2 className="mr-1 inline size-3 animate-spin" />Conferindo a escala pelas cotas…</>
  else if (c?.estado === "ok") corpo = <><b className="text-foreground">✓ Escala 1:{e.N}</b> conferida em {c.n} cotas {c.fonte}{ver}</>
  else if (c?.estado === "conflito") corpo = <span className="text-amber-600">A planta diz 1:{e.N}, mas {c.n} cotas indicam {c.Nc ? `1:${c.Nc}` : "outra escala"}. <span className={link} onClick={onUsar}>Usar {c.Nc ? `1:${c.Nc}` : "a das cotas"}</span> · <span className={link} onClick={onManter}>manter 1:{e.N}</span>{ver}</span>
  else if (c?.estado === "calculada") corpo = <><b className="text-foreground">✓ {e.N ? `Escala 1:${e.N} calculada` : "Medidas calibradas"}</b> por {c.n} cotas {c.fonte}{ver}</>
  else if (c?.estado === "mantida") corpo = <>Escala 1:{e.N} mantida · <span className="text-amber-600">as cotas indicavam {c.Nc ? `1:${c.Nc}` : "outra"}</span>{ver}</>
  else if (e.mmPorPx) corpo = <>Escala {e.N ? `1:${e.N} ` : ""}{e.fonte}{c?.estado === "semcotas" ? " · sem cotas suficientes para conferir" : ""}{c?.estado === "erro" ? ` · não conferi: ${c.msg}` : ""} · <span className={link} onClick={onMarcar}>conferir com uma cota</span>{ver}</>
  else corpo = <span className="text-amber-600">Sem escala na planta{c?.estado === "erro" ? ` (${c.msg})` : ""}. <span className={link} onClick={onMarcar}>Marcar uma cota</span> para medir os eletrodutos.</span>
  return <p className="truncate text-xs text-muted-foreground">{corpo}</p>
}

/* ================= Palco ================= */
function Palco(props: {
  pav: PavInfra; U: number; ferr: Ferramenta; sel: string | null; liga: string | null; rascunho: { p: P[]; cur?: P } | null
  cal: { a?: P } | null; mouse: P | null; verCotas: boolean
  onEscolher: () => void; onMouse: (q: P, alvo: string | null) => void; onClique: (q: P, alvo: string | null) => void
  onDuploClique: (alvo: string | null, vx: number | null) => void; onDireito: () => void
  onInicioArrasto: () => void; onArrastaItem: (id: string, centro: P) => void; onArrastaCanto: (i: number, q: P) => void; onFimArrasto: () => void
}) {
  const { pav, U } = props
  const planta = pav.planta
  const svgRef = useRef<SVGSVGElement>(null)
  const [vb, setVb] = useState({ x: 0, y: 0, w: 1000, h: 700 })
  const arr = useRef<{ tipo: "item" | "canto" | "fundo"; id?: string; i?: number; x0: number; y0: number; q0: P; c0?: P; vb0: typeof vb; mov: boolean; alvo: string | null } | null>(null)

  const ajustar = useCallback(() => {
    const el = svgRef.current
    if (!planta || !el) return
    const r = el.getBoundingClientRect(), a = planta.W / planta.H, b = r.width / Math.max(1, r.height)
    if (b > a) { const w = planta.H * b; setVb({ x: -(w - planta.W) / 2, y: 0, w, h: planta.H }) } else { const h = planta.W / b; setVb({ x: 0, y: -(h - planta.H) / 2, w: planta.W, h }) }
  }, [planta])
  useEffect(() => { ajustar() }, [ajustar, planta?.img])
  useEffect(() => { const f = () => ajustar(); window.addEventListener("resize", f); return () => window.removeEventListener("resize", f) }, [ajustar])

  const pos = (ev: { clientX: number; clientY: number }): P => {
    const el = svgRef.current!, pt = el.createSVGPoint()
    pt.x = ev.clientX; pt.y = ev.clientY
    const q = pt.matrixTransform(el.getScreenCTM()!.inverse())
    return [snap(q.x, U), snap(q.y, U)]
  }
  const limita = (v: typeof vb) => (planta ? { ...v, x: Math.min(planta.W - v.w / 2, Math.max(-v.w / 2, v.x)), y: Math.min(planta.H - v.h / 2, Math.max(-v.h / 2, v.y)) } : v)
  const zoom = (f: number, cx?: number, cy?: number) => setVb((v) => {
    if (!planta) return v
    const nw = Math.min(planta.W * 1.15, Math.max(planta.W / 14, v.w * f)), k = nw / v.w
    const x = cx ?? v.x + v.w / 2, y = cy ?? v.y + v.h / 2
    return limita({ x: x - (x - v.x) * k, y: y - (y - v.y) * k, w: v.w * k, h: v.h * k })
  })
  useEffect(() => {
    const el = svgRef.current
    if (!el) return
    const h = (ev: WheelEvent) => roda(ev, (f) => { const [x, y] = pos(ev); zoom(f, x, y) }, (dx, dy) => setVb((v) => { const f = v.w / el.getBoundingClientRect().width; return limita({ ...v, x: v.x + dx * f, y: v.y + dy * f }) }))
    el.addEventListener("wheel", h, { passive: false })
    return () => el.removeEventListener("wheel", h)
  })

  // Símbolos e textos nunca ficam menores que ~1 px de tela por unidade: com a planta
  // inteira no celular eles sumiriam. Aproximando, voltam ao tamanho da prancha.
  const pxTela = vb.w / (svgRef.current?.getBoundingClientRect().width || 1000)
  const Uv = Math.round(Math.max(U, 0.8 * pxTela) * 20) / 20
  const desenho = useMemo(() => (planta ? camadas(pav, Uv, { interativo: true, sel: props.sel, liga: props.liga, ferramenta: props.ferr }) : ""), [pav, Uv, props.sel, props.liga, props.ferr, planta])
  const cotasSvg = useMemo(() => (planta && props.verCotas && pav.escala.cotas?.length ? camadaCotas(pav.escala.cotas, planta.off, U) : ""), [planta, props.verCotas, pav.escala.cotas, U])

  if (!planta) {
    return (
      <div className="grid min-h-[60vh] place-items-center rounded-2xl border border-dashed border-border bg-card p-6 text-center">
        <div className="space-y-3"><MapIcon className="mx-auto size-8 text-muted-foreground" /><p className="font-medium">Sem planta neste pavimento</p>
          <p className="text-sm text-muted-foreground">Use um arquivo que já está em Projetos ou suba do computador.</p><Button onClick={props.onEscolher}>Escolher planta</Button></div>
      </div>
    )
  }

  const dica: Record<Ferramenta, string> = {
    ligar: props.liga ? `Ligando a partir de ${props.liga}: clique no destino` : "Ligar: clique numa caixa (ou ponto) e depois no destino",
    rota: props.rascunho ? `Rota com ${props.rascunho.p.length} canto(s): clique para continuar · Enter, Esc ou duplo clique concluem · Backspace volta` : "Rota: clique onde começa e vá clicando nos cantos",
    cp: "Caixa: clique onde ela fica", pt: "Ponto: clique onde fica o equipamento",
    sel: "Mover: arraste caixas, pontos e cantos · duplo clique abre os dados",
    cal: props.cal?.a ? "Escala: clique na outra ponta da cota" : "Escala: clique numa ponta de uma cota conhecida",
  }
  const alvoDe = (t: EventTarget | null) => (t instanceof Element ? t.closest("[data-sel]")?.getAttribute("data-sel") ?? null : null)
  const ligaC = props.ferr === "ligar" && props.liga ? centro(pav, props.liga) : null

  return (
    <div className="relative overflow-hidden rounded-2xl border border-border bg-white">
      <svg ref={svgRef} viewBox={`${vb.x} ${vb.y} ${vb.w} ${vb.h}`}
        className={`block h-[60vh] w-full touch-none select-none lg:h-[calc(100vh-300px)] ${props.ferr === "sel" ? "cursor-default" : "cursor-crosshair"}`}
        onContextMenu={(ev) => { ev.preventDefault(); props.onDireito() }}
        onDoubleClick={(ev) => { const vx = (ev.target as Element).closest("[data-vx]")?.getAttribute("data-vx"); props.onDuploClique(alvoDe(ev.target), vx != null ? +vx : null) }}
        onPointerDown={(ev) => {
          if (ev.button !== 0 && ev.button !== 1) return
          const t = ev.target as Element
          const vx = t.closest("[data-vx]")?.getAttribute("data-vx")
          const alvo = alvoDe(ev.target)
          const q = pos(ev)
          let tipo: "item" | "canto" | "fundo" = "fundo"
          if (ev.button === 0 && props.ferr === "sel" && vx != null && props.sel) tipo = "canto"
          else if (ev.button === 0 && props.ferr === "sel" && alvo && !alvo.startsWith("R")) tipo = "item"
          const C = tipo === "item" ? centro(pav, alvo!) : null
          arr.current = { tipo, id: alvo ?? undefined, i: vx != null ? +vx : undefined, x0: ev.clientX, y0: ev.clientY, q0: q, c0: C ? [C.cx, C.cy] : undefined, vb0: vb, mov: false, alvo }
          ;(ev.currentTarget as Element).setPointerCapture(ev.pointerId)
        }}
        onPointerMove={(ev) => {
          const a = arr.current
          if (!a) { props.onMouse(pos(ev), alvoDe(ev.target)); return }
          if (!a.mov && Math.hypot(ev.clientX - a.x0, ev.clientY - a.y0) < 5) return
          if (!a.mov && a.tipo !== "fundo") props.onInicioArrasto()
          a.mov = true
          const q = pos(ev)
          if (a.tipo === "item" && a.id && a.c0) props.onArrastaItem(a.id, [a.c0[0] + q[0] - a.q0[0], a.c0[1] + q[1] - a.q0[1]])
          else if (a.tipo === "canto" && a.i != null) props.onArrastaCanto(a.i, q)
          else { const f = a.vb0.w / svgRef.current!.getBoundingClientRect().width; setVb(limita({ ...a.vb0, x: a.vb0.x - (ev.clientX - a.x0) * f, y: a.vb0.y - (ev.clientY - a.y0) * f })) }
        }}
        onPointerUp={(ev) => {
          const a = arr.current
          arr.current = null
          if (!a) return
          if (a.mov) { if (a.tipo !== "fundo") props.onFimArrasto(); return }
          if (ev.button === 0) props.onClique(a.q0, a.alvo)
        }}>
        <image href={src(planta.img)} x={0} y={0} width={planta.W} height={planta.H} />
        <g dangerouslySetInnerHTML={{ __html: cotasSvg + desenho }} />
        {props.rascunho && props.rascunho.p.length > 0 && (
          <g style={{ pointerEvents: "none" }}>
            <path d={caminho([...props.rascunho.p, ...(props.rascunho.cur ? [props.rascunho.cur] : [])], 14 * U)} fill="none" stroke="#111" strokeWidth={2.4 * U} strokeDasharray={`${8 * U} ${6 * U}`} />
            {props.rascunho.p.map((q, i) => <circle key={i} cx={q[0]} cy={q[1]} r={4 * U} fill="#111" />)}
          </g>
        )}
        {ligaC && props.mouse && <path d={`M${ligaC.cx} ${ligaC.cy}L${props.mouse[0]} ${ligaC.cy}L${props.mouse[0]} ${props.mouse[1]}`} fill="none" stroke="#111" strokeWidth={2 * U} strokeDasharray={`${6 * U} ${6 * U}`} opacity={0.6} style={{ pointerEvents: "none" }} />}
        {props.cal?.a && (
          <g style={{ pointerEvents: "none" }}>
            <circle cx={props.cal.a[0]} cy={props.cal.a[1]} r={6 * U} fill="#10b981" />
            {props.mouse && <line x1={props.cal.a[0]} y1={props.cal.a[1]} x2={props.mouse[0]} y2={props.mouse[1]} stroke="#10b981" strokeWidth={2 * U} strokeDasharray={`${6 * U} ${4 * U}`} />}
          </g>
        )}
      </svg>
      <div className="absolute right-3 top-3 flex flex-col gap-0.5 rounded-2xl border border-border bg-card p-1 shadow-md">
        <button className="grid size-8 place-items-center rounded-lg hover:bg-muted" onClick={() => zoom(1 / 1.3)} title="Aproximar"><Plus className="size-4" /></button>
        <button className="grid size-8 place-items-center rounded-lg hover:bg-muted" onClick={() => zoom(1.3)} title="Afastar"><Minus className="size-4" /></button>
        <button className="grid size-8 place-items-center rounded-lg hover:bg-muted" onClick={ajustar} title="Planta inteira"><Maximize2 className="size-4" /></button>
      </div>
      <div className="pointer-events-none absolute bottom-3 left-3 right-14 rounded-xl bg-[#1d1d1f]/85 px-3 py-1.5 text-xs text-white">{dica[props.ferr]} <span className="opacity-60">· arraste o fundo para andar · roda/pinça aproxima</span></div>
    </div>
  )
}

/* ================= Painel ================= */
function Painel({ pav, sel, onSel, onEditar, onApagar }: { pav: PavInfra; sel: string | null; onSel: (id: string) => void; onEditar: (id: string) => void; onApagar: () => void }) {
  const r = pav.rotas.find((x) => x.id === sel), p = pav.pts.find((x) => x.id === sel), c = pav.cps.find((x) => x.id === sel)
  const kv = (l: Array<[string, string | undefined]>) => (
    <div className="grid grid-cols-[90px_1fr] gap-x-2 gap-y-1 text-[12.5px]">{l.filter(([, v]) => v).map(([k, v]) => <Fragment key={k}><span className="text-muted-foreground">{k}</span><span>{v}</span></Fragment>)}</div>
  )
  const { eletroduto, cabos } = totais(pav)
  const itens: Array<[string, string, string]> = [
    ...pav.cps.map((x) => [x.id, `Caixa ${x.tam || ""}`, "#1f1f1f"] as [string, string, string]),
    ...pav.rotas.map((x) => { const m = metros(x, pav.escala); return [x.id, `${x.nome} · Ø ${x.d}${m != null ? " · " + fmt(m) + " m" : ""}`, COR[x.d] ?? "#555"] as [string, string, string] }),
    ...pav.pts.map((x) => [x.id, x.equip && x.equip !== "Outro" ? x.equip : x.d, "#ff9e1a"] as [string, string, string]),
  ]
  const tit = "mb-2 block text-[11px] font-semibold uppercase tracking-wide text-muted-foreground"
  return (
    <aside className="space-y-3 lg:max-h-[calc(100vh-300px)] lg:overflow-auto">
      <section className="rounded-2xl border border-border bg-card p-3.5">
        <span className={tit}>Selecionado</span>
        {r ? <div className="space-y-2"><p className="text-sm"><b>{r.id}</b> · eletroduto{metros(r, pav.escala) != null ? ` · ${fmt(metros(r, pav.escala)!)} m` : ""}</p>{kv([["Destino", r.nome], ["Diâmetro", r.d], ["Tipo", r.tipo], ["Instalação", r.inst], ["Sistema", r.sist], ["Cabos", cabosTexto(r) || "—"], ["Curvas", String(curvas(r))], ["Arame guia", r.guia ? "sim" : "não"], ["Obs.", r.obs]])}</div>
          : p ? <div className="space-y-2"><p className="text-sm"><b>{p.id}</b> · ponto</p>{kv([["Equipamento", p.equip], ["Descrição", p.d], ["Ambiente", p.amb], ["Altura", p.alt], ["Caixa", p.cx], ["Obs.", p.obs]])}</div>
          : c ? <div className="space-y-2"><p className="text-sm"><b>{c.id}</b> · caixa de passagem</p>{kv([["Tamanho", c.tam], ["Local", c.local], ["Obs.", c.obs]])}</div>
          : <p className="text-xs text-muted-foreground">Nada selecionado. Use Mover e clique num item, ou clique na lista.</p>}
        {sel && (r || p || c) && <div className="mt-2.5 flex gap-1.5"><Button size="sm" variant="outline" onClick={() => onEditar(sel)}>Editar dados</Button><Button size="sm" variant="ghost" className="text-destructive" onClick={onApagar}>Apagar</Button></div>}
      </section>
      <section className="rounded-2xl border border-border bg-card p-3.5">
        <span className={tit}>Projeto · {pav.rotas.length} rotas · {pav.cps.length} caixas · {pav.pts.length} pontos</span>
        <div className="max-h-[300px] space-y-0.5 overflow-auto">
          {itens.length ? itens.map(([id, t, cor]) => (
            <button key={id} onClick={() => onSel(id)} onDoubleClick={() => onEditar(id)}
              className={`flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-[12.5px] ${sel === id ? "bg-foreground/[0.07]" : "hover:bg-foreground/[0.04]"}`}>
              <span className="size-2.5 shrink-0 rounded-[3px]" style={{ background: cor }} /><b className="shrink-0">{id}</b><span className="truncate">{t}</span>
            </button>
          )) : <p className="rounded-xl border border-dashed border-border p-4 text-center text-xs text-muted-foreground">Nada desenhado ainda.</p>}
        </div>
        <div className="mt-2.5 border-t border-border pt-2.5 text-[12.5px] leading-relaxed">
          {pav.escala.mmPorPx ? (Object.keys(eletroduto).length ? <>
            <b>Eletroduto</b>{Object.entries(eletroduto).map(([k, m]) => <div key={k}>{k}: <b>{fmt(m)} m</b></div>)}
            {Object.keys(cabos).length > 0 && <><b className="mt-1 block">Cabos</b>{Object.entries(cabos).map(([k, m]) => <div key={k}>{k}: <b>{fmt(m)} m</b></div>)}</>}
          </> : null) : <span className="text-muted-foreground">Sem escala, não dá para somar os metros.</span>}
        </div>
      </section>
    </aside>
  )
}

/* ================= Janela de dados (rota, ponto, caixa) ================= */
type Item = Rota | Ponto | Caixa
function JanelaDados({ pav, item, novo, ult, onSalvar, onApagar, onCancelar }: {
  pav: PavInfra; item: Item; novo: boolean; ult: EstudoInfra["ult"]
  onSalvar: (i: Item, categoria?: string) => void; onApagar: () => void; onCancelar: () => void
}) {
  const [v, setV] = useState<Item>(structuredClone(item))
  const ehRota = "p" in v, ehPonto = "equip" in v
  const r = v as Rota, p = v as Ponto, c = v as Caixa
  const [outro, setOutro] = useState(ehRota ? r.cabos.filter((x) => !CABOS.includes(x.t)).map((x) => `${x.q > 1 ? x.q + "× " : ""}${x.t}`).join(", ") : "")
  const [cat, setCat] = useState(ehPonto ? categoriaDe(p.equip) ?? ult.categoria : ult.categoria)
  const [busca, setBusca] = useState("")
  const chip = (on: boolean) => `inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[12.5px] font-medium ${on ? "border-foreground bg-foreground text-background" : "border-border bg-card hover:bg-muted"}`
  const titulo = ehRota ? `${novo ? "Nova rota" : "Rota"} ${v.id}` : ehPonto ? `${novo ? "Novo ponto" : "Ponto"} ${v.id}` : `${novo ? "Nova caixa" : "Caixa"} ${v.id}`
  const m = ehRota ? metros(r, pav.escala) : null
  const lb = "text-xs font-medium text-muted-foreground"
  const salvar = () => {
    if (ehRota) {
      const extras = outro.split(",").map((s) => s.trim()).filter(Boolean).map((s) => { const mm = s.match(/^(\d+)\s*[×x]\s*(.+)$/i); return mm ? { t: mm[2], q: +mm[1] } : { t: s, q: 1 } })
      onSalvar({ ...r, nome: (r.nome || "").toUpperCase(), cabos: [...r.cabos.filter((x) => CABOS.includes(x.t)), ...extras] })
    } else if (ehPonto) onSalvar({ ...p, d: (p.d || "").toUpperCase(), amb: (p.amb || "").toUpperCase() }, cat)
    else onSalvar(c)
  }
  const visiveis = useMemo(() => {
    if (!ehPonto) return []
    const t = busca.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "")
    const todos = Object.values(EQUIPAMENTOS).flat()
    return t ? todos.filter((x) => x.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").includes(t)) : EQUIPAMENTOS[cat] ?? []
  }, [busca, cat, ehPonto])
  const escolherEquip = (eq: string) => setV((ant) => {
    const pp = ant as Ponto
    const auto = !pp.d || pp.d === "EQUIP. NOVO" || Object.values(EQUIPAMENTOS).flat().some((x) => x.toUpperCase() === pp.d)
    return { ...pp, equip: eq, d: eq !== "Outro" && auto ? eq.toUpperCase() : pp.d }
  })

  return (
    <form className="space-y-4" onSubmit={(ev) => { ev.preventDefault(); salvar() }}>
      <DialogHeader><DialogTitle>{titulo}</DialogTitle>{ehRota && <p className="text-xs text-muted-foreground">{m != null ? `${fmt(m)} m · ` : ""}{curvas(r)} curvas</p>}</DialogHeader>
      <div className="max-h-[62vh] space-y-4 overflow-auto pr-1">
        {ehRota && <>
          <label className="block space-y-1"><span className={lb}>Destino / nome</span><Input value={r.nome} onChange={(ev) => setV((ant) => ({ ...(ant as Rota), nome: ev.target.value }))} /></label>
          <div className="space-y-1.5"><span className={lb}>Diâmetro</span><div className="flex flex-wrap gap-1.5">{DIAMETROS.map((d) => <button type="button" key={d.d} className={chip(r.d === d.d)} onClick={() => setV((ant) => ({ ...(ant as Rota), d: d.d }))}><span className="size-2.5 rounded-[3px]" style={{ background: d.cor }} />{d.d}<span className="opacity-60">{d.mm}</span></button>)}</div></div>
          {([["Tipo de eletroduto", "tipo", TIPOS], ["Instalação", "inst", INSTALACAO], ["Sistema", "sist", SISTEMAS]] as const).map(([l, k, ops]) => (
            <div key={k} className="space-y-1.5"><span className={lb}>{l}</span><div className="flex flex-wrap gap-1.5">{ops.map((o) => <button type="button" key={o} className={chip(r[k] === o)} onClick={() => setV((ant) => ({ ...(ant as Rota), [k]: o }))}>{o}</button>)}</div></div>
          ))}
          <div className="space-y-1.5"><span className={lb}>Cabos que passam (toque no nome para incluir; − + mudam a quantidade)</span>
            <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">{CABOS.map((t) => {
              const q = r.cabos.find((x) => x.t === t)?.q ?? 0
              const muda = (n: number) => setV((ant) => { const rr = ant as Rota; return { ...rr, cabos: [...rr.cabos.filter((x) => x.t !== t), ...(n > 0 ? [{ t, q: Math.min(48, n) }] : [])] } })
              return (
                <div key={t} className={`flex items-center justify-between gap-2 rounded-xl border px-2.5 py-1 text-[12.5px] font-medium ${q ? "border-foreground bg-foreground/[0.04]" : "border-border"}`}>
                  <span className="cursor-pointer" onClick={() => muda(q ? 0 : 1)}>{t}</span>
                  <span className="flex items-center gap-1"><button type="button" className="grid size-6 place-items-center rounded-md border border-border" onClick={() => muda(q - 1)}>−</button><span className="w-5 text-center">{q}</span><button type="button" className="grid size-6 place-items-center rounded-md border border-border" onClick={() => muda(q + 1)}>+</button></span>
                </div>
              )
            })}</div>
          </div>
          <label className="block space-y-1"><span className={lb}>Outro cabo</span><Input value={outro} placeholder="ex.: 2× Cabo de sensor" onChange={(ev) => setOutro(ev.target.value)} /></label>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={r.guia} onChange={(ev) => setV((ant) => ({ ...(ant as Rota), guia: ev.target.checked }))} />Deixar arame guia</label>
          <label className="block space-y-1"><span className={lb}>Observação</span><Input value={r.obs} onChange={(ev) => setV((ant) => ({ ...(ant as Rota), obs: ev.target.value }))} /></label>
        </>}
        {ehPonto && <>
          <div className="space-y-2"><span className={lb}>Equipamento</span>
            <div className="flex flex-wrap gap-0.5 rounded-xl bg-foreground/[0.06] p-1">{Object.keys(EQUIPAMENTOS).map((k) => <button type="button" key={k} onClick={() => { setCat(k); setBusca("") }} className={`flex-1 whitespace-nowrap rounded-lg px-2 py-1.5 text-[12px] font-medium ${!busca && cat === k ? "bg-card shadow-sm" : "text-muted-foreground"}`}>{k}</button>)}</div>
            <Input value={busca} placeholder="Buscar em todos (ex.: câmera, rede)…" onChange={(ev) => setBusca(ev.target.value)}
              onKeyDown={(ev) => { if (ev.key === "Enter") { ev.preventDefault(); if (visiveis[0]) { escolherEquip(visiveis[0]); setCat(categoriaDe(visiveis[0]) ?? cat); setBusca("") } } }} />
            <div className="flex flex-wrap gap-1.5">{[...visiveis, "Outro"].map((o) => <button type="button" key={o} className={chip(p.equip === o)} onClick={() => { escolherEquip(o); if (categoriaDe(o)) setCat(categoriaDe(o)!) }}>{o}</button>)}</div>
            {busca && !visiveis.length && <p className="text-xs text-muted-foreground">Nada com esse nome. Use &quot;Outro&quot; e escreva na descrição.</p>}
          </div>
          <label className="block space-y-1"><span className={lb}>Descrição (aparece na planta)</span><Input value={p.d} onChange={(ev) => setV((ant) => ({ ...(ant as Ponto), d: ev.target.value }))} /></label>
          <label className="block space-y-1"><span className={lb}>Ambiente</span><Input value={p.amb} placeholder="ex.: SALA DE JANTAR" onChange={(ev) => setV((ant) => ({ ...(ant as Ponto), amb: ev.target.value }))} /></label>
          {([["Altura de instalação", "alt", ALTURAS], ["Caixa no ponto", "cx", CAIXA_PONTO]] as const).map(([l, k, ops]) => (
            <div key={k} className="space-y-1.5"><span className={lb}>{l}</span><div className="flex flex-wrap gap-1.5">{ops.map((o) => <button type="button" key={o} className={chip(p[k] === o)} onClick={() => setV((ant) => ({ ...(ant as Ponto), [k]: o }))}>{o}</button>)}</div></div>
          ))}
          <label className="block space-y-1"><span className={lb}>Observação</span><Input value={p.obs} onChange={(ev) => setV((ant) => ({ ...(ant as Ponto), obs: ev.target.value }))} /></label>
        </>}
        {!ehRota && !ehPonto && <>
          {([["Tamanho", "tam", CAIXA_TAM], ["Local", "local", CAIXA_LOCAL]] as const).map(([l, k, ops]) => (
            <div key={k} className="space-y-1.5"><span className={lb}>{l}</span><div className="flex flex-wrap gap-1.5">{ops.map((o) => <button type="button" key={o} className={chip(c[k] === o)} onClick={() => setV((ant) => ({ ...(ant as Caixa), [k]: o }))}>{o}</button>)}</div></div>
          ))}
          <label className="block space-y-1"><span className={lb}>Observação</span><Input value={c.obs} onChange={(ev) => setV((ant) => ({ ...(ant as Caixa), obs: ev.target.value }))} /></label>
        </>}
      </div>
      <div className="flex items-center gap-2 border-t border-border pt-3">
        <Button type="button" variant="ghost" className="text-destructive" onClick={onApagar}>{novo ? "Descartar" : "Apagar"}</Button>
        <span className="flex-1" />
        <Button type="button" variant="outline" onClick={onCancelar}>Cancelar</Button>
        <Button type="submit"><Save className="size-4" />Salvar</Button>
      </div>
    </form>
  )
}

/* ================= Prancha ================= */
function FormPrancha({ e, pav, P, revAuto, onMudar, onSalvar, onBaixar }: {
  e: EstudoInfra; pav: string; P: PavInfra; revAuto: string; onMudar: (campo: keyof EstudoInfra["prancha"], v: string) => void; onSalvar: () => void; onBaixar: () => void
}) {
  const pr = e.prancha
  const campos: Array<[keyof EstudoInfra["prancha"], string, string]> = [
    ["titulo", "Título da planta", `PLANTA ${pav} - INFRAESTRUTURA (ELETRODUTOS)`],
    ["tfolha", "Título do carimbo", `INFRAESTRUTURA - ELETRODUTOS - PAVIMENTO ${pav}`],
    ["obra", "Obra", ""], ["prop", "Proprietário", ""], ["local", "Local", ""], ["rev", "Revisão", `${revAuto} (automática)`],
    ["base", "Base (planta de origem)", P.planta?.origem?.nome?.toUpperCase() ?? ""],
  ]
  const preview = useMemo(() => (P.planta ? pranchaSvg(P, { ...pr, titulo: pr.titulo || campos[0][2], tfolha: pr.tfolha || campos[1][2], base: pr.base || campos[6][2], rev: pr.rev || revAuto }, src(P.planta.img), "/brand/logo-completo.png") : ""),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [P, pr, pav, revAuto])
  return (
    <div className="space-y-3">
      <div className="overflow-hidden rounded-xl border border-border bg-white" dangerouslySetInnerHTML={{ __html: preview.replace("<svg ", '<svg style="width:100%;height:auto;display:block" ') }} />
      <div className="grid gap-2 sm:grid-cols-2">
        {campos.map(([k, l, ph]) => (
          <label key={k} className={`space-y-1 ${k === "local" || k === "base" ? "sm:col-span-2" : ""}`}><span className="text-xs font-medium text-muted-foreground">{l}</span>
            <Input value={pr[k]} placeholder={ph} onChange={(ev) => onMudar(k, ev.target.value)} /></label>
        ))}
      </div>
      <div className="flex flex-wrap items-center gap-2 border-t border-border pt-3">
        <p className="flex-1 text-xs text-muted-foreground">Sai em A1 com legenda, lista de material (+10% de sobra), notas e carimbo.</p>
        <Button variant="outline" onClick={onBaixar}><FileDown className="size-4" />Baixar PDF</Button>
        <Button onClick={onSalvar}><Save className="size-4" />Salvar em Projetos</Button>
      </div>
    </div>
  )
}
