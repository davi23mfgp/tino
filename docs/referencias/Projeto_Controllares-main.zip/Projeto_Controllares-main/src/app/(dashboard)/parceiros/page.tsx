﻿"use client"

import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
import { Percent,
  Users, Plus, Search, Pencil, Trash2, RefreshCw,
  Building2, HardHat, Ruler, UserCheck, Wrench, Mail, Phone,
  ChevronUp, ChevronDown, ExternalLink,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { EmptyState } from "@/components/ui/empty-state"
import { CabecalhoPagina } from "@/components/ui/cabecalho-pagina"
import { CartaoMetrica, FaixaMetricas } from "@/components/ui/cartao-metrica"
import { BarraFiltros } from "@/components/ui/barra-filtros"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog"
import { useMemoriaDeFiltro } from "@/hooks/usar-memoria-filtro"
import { CampoMascarado } from "@/components/ui/campo-mascarado"

type PartnerType = "ARQUITETO" | "CONSTRUTORA" | "DESIGNER" | "ENGENHEIRO_CIVIL" | "MESTRE_OBRA"
type SortKey = "name" | "type" | "company_name" | "total_obras" | "comissao_percentual"
type SortDir = "asc" | "desc"

const TYPE_LABEL: Record<PartnerType, string> = {
  ARQUITETO: "Arquiteto",
  CONSTRUTORA: "Construtora",
  DESIGNER: "Designer",
  ENGENHEIRO_CIVIL: "Eng. Civil",
  MESTRE_OBRA: "Mestre de Obra",
}

const TYPE_LABEL_FULL: Record<PartnerType, string> = {
  ARQUITETO: "Arquiteto",
  CONSTRUTORA: "Construtora",
  DESIGNER: "Designer de Interiores",
  ENGENHEIRO_CIVIL: "Engenheiro Civil",
  MESTRE_OBRA: "Mestre de Obra",
}

const TYPE_ICON: Record<PartnerType, React.ComponentType<{ className?: string }>> = {
  ARQUITETO: Ruler,
  CONSTRUTORA: Building2,
  DESIGNER: UserCheck,
  ENGENHEIRO_CIVIL: HardHat,
  MESTRE_OBRA: Wrench,
}

const TYPE_COLOR: Record<PartnerType, string> = {
  ARQUITETO: "text-sky-500 bg-sky-500/10",
  CONSTRUTORA: "text-orange-500 bg-orange-500/10",
  DESIGNER: "text-purple-500 bg-purple-500/10",
  ENGENHEIRO_CIVIL: "text-amber-500 bg-amber-500/10",
  MESTRE_OBRA: "text-green-500 bg-green-500/10",
}

interface Parceiro {
  id: string
  name: string
  type: PartnerType
  email: string | null
  phone: string | null
  company_name: string | null
  phone_responsavel: string | null
  email_especificador: string | null
  observacoes: string | null
  comissao_percentual: number
  total_obras: number
}

const EMPTY_FORM = {
  name: "", type: "" as PartnerType | "",
  email: "", phone: "", company_name: "",
  phone_responsavel: "", email_especificador: "", observacoes: "",
  comissao_percentual: "",
}

function SortIcon({ col, sort }: { col: SortKey; sort: { key: SortKey; dir: SortDir } }) {
  if (sort.key !== col) return <ChevronUp className="w-3 h-3 opacity-20" />
  return sort.dir === "asc"
    ? <ChevronUp className="w-3 h-3 text-primary" />
    : <ChevronDown className="w-3 h-3 text-primary" />
}

export default function ParceirosPage() {
  const router = useRouter()
  const [parceiros, setParceiros] = useState<Parceiro[]>([])
  const [loading, setLoading] = useState(true)
  const [busca, setBusca] = useMemoriaDeFiltro("parceiros:busca", "")
  const [filtroTipo, setFiltroTipo] = useMemoriaDeFiltro<PartnerType | "">("parceiros:tipo", "")
  const [sort, setSort] = useMemoriaDeFiltro<{ key: SortKey; dir: SortDir }>("parceiros:ordem", { key: "name", dir: "asc" })

  const [open, setOpen] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)
  const [form, setForm] = useState({ ...EMPTY_FORM })
  const [saving, setSaving] = useState(false)
  const [deletingId, setDeletingId] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/parceiros")
      if (res.ok) setParceiros((await res.json()).parceiros)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  function abrirNovo() {
    setEditId(null)
    setForm({ ...EMPTY_FORM })
    setOpen(true)
  }

  function abrirEdicao(p: Parceiro, e: React.MouseEvent) {
    e.stopPropagation()
    setEditId(p.id)
    setForm({
      name: p.name,
      type: p.type,
      email: p.email ?? "",
      phone: p.phone ?? "",
      company_name: p.company_name ?? "",
      phone_responsavel: p.phone_responsavel ?? "",
      email_especificador: p.email_especificador ?? "",
      observacoes: p.observacoes ?? "",
      comissao_percentual: String(p.comissao_percentual ?? ""),
    })
    setOpen(true)
  }

  async function salvar() {
    if (!form.name.trim() || !form.type) return
    setSaving(true)
    try {
      const url = editId ? `/api/parceiros/${editId}` : "/api/parceiros"
      const method = editId ? "PATCH" : "POST"
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      })
      if (res.ok) { setOpen(false); load() }
    } finally {
      setSaving(false)
    }
  }

  async function excluir(id: string, e: React.MouseEvent) {
    e.stopPropagation()
    setDeletingId(id)
    try {
      const res = await fetch(`/api/parceiros/${id}`, { method: "DELETE" })
      if (res.ok) load()
    } finally {
      setDeletingId(null)
    }
  }

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setForm(prev => ({ ...prev, [k]: e.target.value }))

  function toggleSort(key: SortKey) {
    setSort(prev => prev.key === key
      ? { key, dir: prev.dir === "asc" ? "desc" : "asc" }
      : { key, dir: "asc" }
    )
  }

  const filtrados = parceiros.filter(p => {
    const q = busca.toLowerCase()
    const matchBusca = !q || p.name.toLowerCase().includes(q) || (p.company_name ?? "").toLowerCase().includes(q) || (p.email ?? "").toLowerCase().includes(q)
    const matchTipo = !filtroTipo || p.type === filtroTipo
    return matchBusca && matchTipo
  })

  const sorted = [...filtrados].sort((a, b) => {
    let av: string | number = a[sort.key] ?? ""
    let bv: string | number = b[sort.key] ?? ""
    if (typeof av === "string") av = av.toLowerCase()
    if (typeof bv === "string") bv = bv.toLowerCase()
    if (av < bv) return sort.dir === "asc" ? -1 : 1
    if (av > bv) return sort.dir === "asc" ? 1 : -1
    return 0
  })

  // Stats por tipo
  const stats = (Object.keys(TYPE_LABEL) as PartnerType[]).map(t => ({
    type: t,
    count: parceiros.filter(p => p.type === t).length,
  })).filter(s => s.count > 0)

  const totalObras = parceiros.reduce((a, p) => a + (p.total_obras ?? 0), 0)
  const comissaoMedia = parceiros.length
    ? parceiros.reduce((a, p) => a + Number(p.comissao_percentual ?? 0), 0) / parceiros.length
    : 0
  /* O tipo mais frequente diz que rede é essa — uma base de arquitetos pede
     um trabalho diferente de uma base de construtoras. */
  const maisComum = (stats.length
    ? stats.reduce((a, b) => (a.count >= b.count ? a : b)).type
    : "ARQUITETO") as PartnerType

  const thClass = "px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wide whitespace-nowrap cursor-pointer select-none hover:text-foreground transition-colors"

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto space-y-5">
      {/* Header */}
      <CabecalhoPagina
        icone={Users}
        titulo="Parceiros"
        contexto={`${parceiros.length} cadastrado${parceiros.length !== 1 ? "s" : ""}`}
        acao={
          <Button onClick={abrirNovo} size="sm" className="h-9 w-9 flex-shrink-0 p-0 md:w-auto md:px-3">
            <Plus className="h-4 w-4 md:mr-1.5" /> <span className="hidden md:inline">Novo parceiro</span>
          </Button>
        }
      />

      <FaixaMetricas>
        <CartaoMetrica icone={Users} rotulo="Ativos" valor={parceiros.length} nota="Na rede" />
        <CartaoMetrica icone={HardHat} rotulo="Obras indicadas" valor={totalObras} nota="Somando todos" />
        <CartaoMetrica icone={Percent} rotulo="Comissão média"
          valor={parceiros.length ? `${comissaoMedia.toFixed(1)}%` : "—"} nota="Sobre a venda" />
        <CartaoMetrica icone={TYPE_ICON[maisComum] ?? Users} rotulo="Mais comum"
          valor={parceiros.length ? TYPE_LABEL[maisComum] : "—"}
          nota={parceiros.length ? `${parceiros.filter(p => p.type === maisComum).length} cadastrados` : "Nenhum ainda"} />
      </FaixaMetricas>

      <BarraFiltros
        busca={busca}
        aoBuscar={setBusca}
        placeholder="Buscar por nome, empresa ou e-mail..."
        valor={filtroTipo || "TODOS"}
        aoTrocar={v => setFiltroTipo(v === "TODOS" ? "" : (v as PartnerType))}
        opcoes={[
          { valor: "TODOS", rotulo: "Todos" },
          ...stats.map(st => ({ valor: st.type as string, rotulo: TYPE_LABEL[st.type] })),
        ]}
      />

      {/* Table */}
      {loading ? (
        <div className="text-center text-muted-foreground py-16">Carregando parceiros...</div>
      ) : sorted.length === 0 ? (
        <EmptyState icon={Users}
          title={busca || filtroTipo ? "Nenhum parceiro encontrado" : "Nenhum parceiro cadastrado"}
          subtitle={busca || filtroTipo ? "Ajuste os filtros de busca." : "Cadastre parceiros para vincular a obras e indicações."} />
      ) : (
        <>
        {/* MOBILE: cards */}
        <div className="md:hidden space-y-2.5">
          {sorted.map(p => {
            const Icon = TYPE_ICON[p.type]
            return (
              <div key={p.id} onClick={() => router.push(`/parceiros/${p.id}`)}
                className="ios-card p-4 active:opacity-70 transition-opacity">
                <div className="flex items-start gap-3">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${TYPE_COLOR[p.type]}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[15px] font-semibold text-foreground leading-tight truncate">{p.name}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{TYPE_LABEL_FULL[p.type]}{p.company_name ? ` · ${p.company_name}` : ""}</p>
                    <div className="flex flex-col gap-0.5 mt-1.5">
                      {p.email && <span className="flex items-center gap-1.5 text-xs text-muted-foreground"><Mail className="w-3 h-3 flex-shrink-0" /><span className="truncate">{p.email}</span></span>}
                      {p.phone && <span className="flex items-center gap-1.5 text-xs text-muted-foreground"><Phone className="w-3 h-3 flex-shrink-0" />{p.phone}</span>}
                    </div>
                    <div className="flex items-center gap-3 mt-2 text-xs">
                      <span className="text-muted-foreground">{p.total_obras} obra{p.total_obras !== 1 ? "s" : ""}</span>
                      {p.comissao_percentual > 0 && <span className="text-green-600 dark:text-green-400 font-medium">{p.comissao_percentual}% comissão</span>}
                    </div>
                  </div>
                  <div className="flex flex-col gap-1 flex-shrink-0" onClick={e => e.stopPropagation()}>
                    <button onClick={e => abrirEdicao(p, e)} className="w-8 h-8 flex items-center justify-center rounded-2xl text-muted-foreground active:bg-muted"><Pencil className="w-4 h-4" /></button>
                    <button onClick={e => excluir(p.id, e)} disabled={deletingId === p.id} className="w-8 h-8 flex items-center justify-center rounded-2xl text-muted-foreground active:bg-muted">
                      {deletingId === p.id ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* DESKTOP: tabela */}
        <div className="hidden md:block border border-border rounded-xl overflow-hidden bg-card">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-border bg-muted/30">
                <tr>
                  <th className={thClass} onClick={() => toggleSort("name")}>
                    <span className="flex items-center gap-1">Nome <SortIcon col="name" sort={sort} /></span>
                  </th>
                  <th className={thClass} onClick={() => toggleSort("type")}>
                    <span className="flex items-center gap-1">Tipo <SortIcon col="type" sort={sort} /></span>
                  </th>
                  <th className={thClass} onClick={() => toggleSort("company_name")}>
                    <span className="flex items-center gap-1">Empresa <SortIcon col="company_name" sort={sort} /></span>
                  </th>
                  <th className={thClass}>Contato</th>
                  <th className={thClass} onClick={() => toggleSort("total_obras")}>
                    <span className="flex items-center gap-1">Obras <SortIcon col="total_obras" sort={sort} /></span>
                  </th>
                  <th className={thClass} onClick={() => toggleSort("comissao_percentual")}>
                    <span className="flex items-center gap-1">Comissão <SortIcon col="comissao_percentual" sort={sort} /></span>
                  </th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wide">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {sorted.map(p => {
                  const Icon = TYPE_ICON[p.type]
                  return (
                    <tr
                      key={p.id}
                      onClick={() => router.push(`/parceiros/${p.id}`)}
                      className="hover:bg-muted/30 cursor-pointer transition-colors group"
                    >
                      {/* Name */}
                      <td className="px-4 py-3.5">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-2xl flex items-center justify-center flex-shrink-0 ${TYPE_COLOR[p.type]}`}>
                            <Icon className="w-3.5 h-3.5" />
                          </div>
                          <div>
                            <p className="font-medium text-foreground group-hover:text-primary transition-colors leading-none">{p.name}</p>
                            {p.observacoes && (
                              <p className="text-muted-foreground/60 text-xs mt-0.5 truncate max-w-[180px]">{p.observacoes}</p>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Type */}
                      <td className="px-4 py-3.5">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-xl text-xs font-medium ${TYPE_COLOR[p.type]}`}>
                          {TYPE_LABEL_FULL[p.type]}
                        </span>
                      </td>

                      {/* Company */}
                      <td className="px-4 py-3.5 text-muted-foreground">
                        {p.company_name || <span className="text-muted-foreground/30">—</span>}
                      </td>

                      {/* Contact */}
                      <td className="px-4 py-3.5">
                        <div className="space-y-0.5">
                          {p.email && (
                            <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                              <Mail className="w-3 h-3 flex-shrink-0" />
                              <span className="truncate max-w-[160px]">{p.email}</span>
                            </p>
                          )}
                          {p.phone && (
                            <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                              <Phone className="w-3 h-3 flex-shrink-0" />{p.phone}
                            </p>
                          )}
                          {!p.email && !p.phone && <span className="text-muted-foreground/30 text-xs">—</span>}
                        </div>
                      </td>

                      {/* Obras */}
                      <td className="px-4 py-3.5">
                        <span className={`text-sm font-medium ${p.total_obras > 0 ? "text-foreground" : "text-muted-foreground/40"}`}>
                          {p.total_obras}
                        </span>
                      </td>

                      {/* Comissão */}
                      <td className="px-4 py-3.5">
                        {p.comissao_percentual > 0 ? (
                          <span className="text-green-600 dark:text-green-400 text-sm font-medium">
                            {p.comissao_percentual}%
                          </span>
                        ) : (
                          <span className="text-muted-foreground/30 text-sm">—</span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-3.5">
                        <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button size="sm" variant="ghost"
                            onClick={e => abrirEdicao(p, e)}
                            className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground">
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="sm" variant="ghost"
                            onClick={e => excluir(p.id, e)}
                            disabled={deletingId === p.id}
                            className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive">
                            {deletingId === p.id
                              ? <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                              : <Trash2 className="w-3.5 h-3.5" />}
                          </Button>
                          <Button size="sm" variant="ghost"
                            onClick={e => { e.stopPropagation(); router.push(`/parceiros/${p.id}`) }}
                            className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground">
                            <ExternalLink className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          {/* Table footer */}
          <div className="px-4 py-2.5 border-t border-border/50 bg-muted/20 flex items-center justify-between">
            <p className="text-xs text-muted-foreground">
              {sorted.length} de {parceiros.length} parceiro{parceiros.length !== 1 ? "s" : ""}
            </p>
            <p className="text-xs text-muted-foreground">
              Clique na linha para ver histórico
            </p>
          </div>
        </div>
        </>
      )}

      {/* Dialog criar/editar */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editId ? "Editar Parceiro" : "Novo Parceiro"}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 px-5 sm:px-6 py-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <label className="text-xs text-muted-foreground mb-1 block">Nome *</label>
                <input value={form.name} onChange={set("name")}
                  className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
                  placeholder="Nome completo" />
              </div>

              <div className="col-span-2">
                <label className="text-xs text-muted-foreground mb-1 block">Tipo *</label>
                <select value={form.type} onChange={set("type")}
                  className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30">
                  <option value="">Selecione o tipo</option>
                  {(Object.keys(TYPE_LABEL_FULL) as PartnerType[]).map(t => (
                    <option key={t} value={t}>{TYPE_LABEL_FULL[t]}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs text-muted-foreground mb-1 block">E-mail</label>
                <input value={form.email} onChange={set("email")} type="email"
                  className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
                  placeholder="email@exemplo.com" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Telefone</label>
                <CampoMascarado mascara="telefone" estilo="proprio" value={form.phone}
                  onValorChange={v => setForm(f => ({ ...f, phone: v }))}
                  className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
                  placeholder="(11) 9 9999-9999" />
              </div>

              <div className="col-span-2">
                <label className="text-xs text-muted-foreground mb-1 block">Empresa / Escritório</label>
                <input value={form.company_name} onChange={set("company_name")}
                  className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
                  placeholder="Nome da empresa" />
              </div>

              <div className="col-span-2 border-t border-border/40 pt-3">
                <p className="text-xs text-muted-foreground mb-2 uppercase tracking-wide font-medium">Contato de campo</p>
              </div>

              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Tel. Encarregado</label>
                <CampoMascarado mascara="telefone" estilo="proprio" value={form.phone_responsavel}
                  onValorChange={v => setForm(f => ({ ...f, phone_responsavel: v }))}
                  className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
                  placeholder="(11) 9 9999-9999" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">E-mail Especificador</label>
                <input value={form.email_especificador} onChange={set("email_especificador")} type="email"
                  className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
                  placeholder="especificador@escritorio.com" />
              </div>

              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Comissão (%)</label>
                <div className="relative">
                  <input value={form.comissao_percentual} onChange={set("comissao_percentual")} type="number" min="0" max="100" step="0.1"
                    className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 pr-8 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
                    placeholder="0" />
                  <span className="absolute right-3 top-2 text-muted-foreground text-sm">%</span>
                </div>
              </div>

              <div className="col-span-2">
                <label className="text-xs text-muted-foreground mb-1 block">Observações</label>
                <textarea value={form.observacoes} onChange={set("observacoes")} rows={3}
                  className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 resize-none"
                  placeholder="Notas internas sobre este parceiro..." />
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setOpen(false)} disabled={saving}>
              Cancelar
            </Button>
            <Button onClick={salvar} disabled={saving || !form.name.trim() || !form.type}>
              {saving ? <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Salvando...</> : "Salvar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
