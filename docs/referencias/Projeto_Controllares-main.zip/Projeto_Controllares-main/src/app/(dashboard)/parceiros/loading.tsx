export default function Loading() {
  return (
    <div className="flex flex-col gap-4 p-5 animate-pulse">
      <div className="flex items-center justify-between">
        <div className="h-7 w-28 bg-muted rounded-xl" />
        <div className="h-9 w-28 bg-muted rounded-xl" />
      </div>
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="h-16 bg-card rounded-2xl border border-border" />
      ))}
    </div>
  )
}
