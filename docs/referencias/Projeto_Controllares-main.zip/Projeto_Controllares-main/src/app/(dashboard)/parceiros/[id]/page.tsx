﻿"use client"

import { useState, useEffect, useCallback, use } from "react"
import { useRouter } from "next/navigation"
import {
  ArrowLeft, Building2, HardHat, Ruler, UserCheck, Wrench,
  Mail, Phone, Pencil, Save, RefreshCw, ExternalLink,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CampoMascarado } from "@/components/ui/campo-mascarado"

type PartnerType = "ARQUITETO" | "CONSTRUTORA" | "DESIGNER" | "ENGENHEIRO_CIVIL" | "MESTRE_OBRA"

const TYPE_LABEL: Record<PartnerType, string> = {
  ARQUITETO: "Arquiteto",
  CONSTRUTORA: "Construtora",
  DESIGNER: "Designer de Interiores",
  ENGENHEIRO_CIVIL: "Engenheiro Civil",
  MESTRE_OBRA: "Mestre de Obra",
}

const TYPE_ICON: Record<PartnerType, React.ComponentType<{ className?: string }>> = {
  ARQUITETO: Ruler,
  CONSTRUTORA: Building2,
  DESIGNER: UserCheck,
  ENGENHEIRO_CIVIL: HardHat,
  MESTRE_OBRA: Wrench,
}

const ETAPA_COLOR: Record<string, string> = {
  "Nova obra": "bg-muted text-muted-foreground/70",
  "Em Projeto": "bg-sky-900/50 text-sky-300",
  "Em Cabeamentos": "bg-amber-900/50 text-amber-300",
  "Em Instalação": "bg-blue-900/50 text-blue-300",
  "Em Programação": "bg-purple-900/50 text-purple-300",
  "Em Comissionamento": "bg-orange-900/50 text-orange-300",
  "Finalizada": "bg-green-900/50 text-green-300",
  "Pausada": "bg-red-900/50 text-red-300",
}

interface ObraVinculada {
  id: string
  client_name: string
  etapa: string | null
  cidade: string | null
  logistics_status: string
  createdAt: string
}

interface Parceiro {
  id: string
  name: string
  type: PartnerType
  email: string | null
  phone: string | null
  company_name: string | null
  phone_responsavel: string | null
  email_especificador: string | null
  observacoes: string | null
  obras: ObraVinculada[]
}

export default function ParceiroDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const router = useRouter()
  const [parceiro, setParceiro] = useState<Parceiro | null>(null)
  const [loading, setLoading] = useState(true)
  const [editMode, setEditMode] = useState(false)
  const [form, setForm] = useState<Partial<Parceiro>>({})
  const [saving, setSaving] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch(`/api/parceiros/${id}`)
      if (!res.ok) { router.push("/parceiros"); return }
      const data = await res.json()
      setParceiro(data)
      setForm(data)
    } finally {
      setLoading(false)
    }
  }, [id, router])

  useEffect(() => { load() }, [load])

  async function salvar() {
    setSaving(true)
    try {
      const res = await fetch(`/api/parceiros/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      })
      if (res.ok) { setEditMode(false); load() }
    } finally {
      setSaving(false)
    }
  }

  const set = (k: keyof Parceiro) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setForm(prev => ({ ...prev, [k]: e.target.value }))

  if (loading) return <div className="p-6 text-center text-muted-foreground">Carregando parceiro...</div>
  if (!parceiro) return null

  const Icon = TYPE_ICON[parceiro.type]

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-start gap-3">
        <Button variant="ghost" onClick={() => router.push("/parceiros")}
          className="text-muted-foreground hover:text-white h-9 w-9 p-0 flex-shrink-0">
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-card">
              <Icon className="w-5 h-5 text-sky-400" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">{parceiro.name}</h1>
              <p className="text-muted-foreground text-sm">{TYPE_LABEL[parceiro.type]}
                {parceiro.company_name && ` · ${parceiro.company_name}`}
              </p>
            </div>
          </div>
        </div>
        <Button
          variant="outline"
          onClick={() => editMode ? salvar() : setEditMode(true)}
          disabled={saving}
          className="border-border text-muted-foreground/70 hover:text-white gap-1.5"
        >
          {saving
            ? <><RefreshCw className="w-4 h-4 animate-spin" /> Salvando...</>
            : editMode
              ? <><Save className="w-4 h-4" /> Salvar</>
              : <><Pencil className="w-4 h-4" /> Editar</>
          }
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Dados do parceiro */}
        <div className="bg-background border border-border/30 rounded-xl p-5 space-y-4">
          <h2 className="text-white font-medium">Informações de Contato</h2>

          {editMode ? (
            <div className="space-y-3">
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Nome</label>
                <input value={form.name ?? ""} onChange={set("name")}
                  className="w-full bg-card border border-border rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-sky-500" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">E-mail</label>
                <input value={form.email ?? ""} onChange={set("email")} type="email"
                  className="w-full bg-card border border-border rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-sky-500" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Telefone</label>
                <CampoMascarado mascara="telefone" estilo="proprio" value={form.phone ?? ""}
                  onValorChange={v => setForm(f => ({ ...f, phone: v }))}
                  className="w-full bg-card border border-border rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-sky-500" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Empresa</label>
                <input value={form.company_name ?? ""} onChange={set("company_name")}
                  className="w-full bg-card border border-border rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-sky-500" />
              </div>
            </div>
          ) : (
            <div className="space-y-2.5 text-sm">
              {parceiro.email && (
                <div className="flex items-center gap-2 text-muted-foreground/70">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  <a href={`mailto:${parceiro.email}`} className="hover:text-sky-400">{parceiro.email}</a>
                </div>
              )}
              {parceiro.phone && (
                <div className="flex items-center gap-2 text-muted-foreground/70">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  {parceiro.phone}
                </div>
              )}
              {!parceiro.email && !parceiro.phone && (
                <p className="text-muted-foreground">Nenhum contato cadastrado</p>
              )}
            </div>
          )}

          <div className="border-t border-border/30 pt-4 space-y-3">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Contato de Campo</p>
            {editMode ? (
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Tel. Encarregado</label>
                  <CampoMascarado mascara="telefone" estilo="proprio" value={form.phone_responsavel ?? ""}
                    onValorChange={v => setForm(f => ({ ...f, phone_responsavel: v }))}
                    className="w-full bg-card border border-border rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-sky-500"
                    placeholder="(11) 9 9999-9999" />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">E-mail Especificador</label>
                  <input value={form.email_especificador ?? ""} onChange={set("email_especificador")} type="email"
                    className="w-full bg-card border border-border rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-sky-500" />
                </div>
              </div>
            ) : (
              <div className="space-y-2 text-sm">
                {parceiro.phone_responsavel && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Phone className="w-3.5 h-3.5 text-muted-foreground" />
                    Encarregado: {parceiro.phone_responsavel}
                  </div>
                )}
                {parceiro.email_especificador && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Mail className="w-3.5 h-3.5 text-muted-foreground" />
                    Especificador: {parceiro.email_especificador}
                  </div>
                )}
                {!parceiro.phone_responsavel && !parceiro.email_especificador && (
                  <p className="text-muted-foreground text-xs">Não cadastrado</p>
                )}
              </div>
            )}
          </div>

          {(editMode || parceiro.observacoes) && (
            <div className="border-t border-border/30 pt-4">
              <p className="text-xs text-muted-foreground uppercase tracking-wide mb-2">Observações</p>
              {editMode ? (
                <textarea value={form.observacoes ?? ""} onChange={set("observacoes")} rows={3}
                  className="w-full bg-card border border-border rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-sky-500 resize-none"
                  placeholder="Notas internas..." />
              ) : (
                <p className="text-muted-foreground text-sm">{parceiro.observacoes}</p>
              )}
            </div>
          )}
        </div>

        {/* Histórico de obras */}
        <div className="bg-background border border-border/30 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-white font-medium">Obras Vinculadas</h2>
            <span className="text-xs text-muted-foreground bg-card px-2 py-1 rounded-full">
              {parceiro.obras.length} {parceiro.obras.length === 1 ? "obra" : "obras"}
            </span>
          </div>

          {parceiro.obras.length === 0 ? (
            <p className="text-muted-foreground text-sm py-6 text-center">Nenhuma obra vinculada ainda</p>
          ) : (
            <div className="space-y-2.5">
              {parceiro.obras.map(o => {
                const etapaBadge = ETAPA_COLOR[o.etapa ?? "Nova obra"] ?? "bg-muted text-muted-foreground/70"
                return (
                  <div key={o.id}
                    className="flex items-center justify-between gap-2 p-3 bg-card rounded-lg border border-border/20 hover:border-border/30 transition-colors">
                    <div className="min-w-0">
                      <p className="text-white text-sm font-medium truncate">{o.client_name}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className={`text-xs px-2 py-0.5 rounded-full ${etapaBadge}`}>
                          {o.etapa ?? "Nova obra"}
                        </span>
                        {o.cidade && <span className="text-muted-foreground text-xs">{o.cidade}</span>}
                      </div>
                    </div>
                    <Button size="sm" variant="ghost"
                      onClick={() => router.push(`/obras/${o.id}`)}
                      className="h-7 w-7 p-0 text-muted-foreground hover:text-sky-400 flex-shrink-0">
                      <ExternalLink className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
