﻿"use client"

import { useState, useEffect, useCallback } from "react"
import { Pencil, LifeBuoy, Bug, HelpCircle, Lightbulb, Plus, RefreshCw, CheckCircle2, Clock, XCircle, Loader2, Trash2, MessageSquare, ChevronDown, LogIn, LogOut, ShieldCheck } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { CabecalhoPagina } from "@/components/ui/cabecalho-pagina"
import { CartaoMetrica, FaixaMetricas } from "@/components/ui/cartao-metrica"
import { usarAtualizacaoAutomatica } from "@/lib/usar-atualizacao-automatica"
import { useConfirmar } from "@/components/confirmar"

type Tipo = "ERRO" | "FAQ" | "SUGESTAO"
type Status = "ABERTO" | "EM_ANALISE" | "RESOLVIDO" | "FECHADO"

interface Item {
  id: string
  tipo: Tipo
  titulo: string
  descricao: string
  status: Status
  resposta?: string | null
  createdAt: string
  user?: { nome: string }
}

const TIPO_META: Record<Tipo, { label: string; icon: React.ReactNode; color: string }> = {
  ERRO:     { label: "Erro",     icon: <Bug className="w-4 h-4" />,          color: "text-red-400" },
  FAQ:      { label: "FAQ",      icon: <HelpCircle className="w-4 h-4" />,   color: "text-sky-400" },
  SUGESTAO: { label: "Sugestão", icon: <Lightbulb className="w-4 h-4" />,    color: "text-amber-400" },
}

const STATUS_META: Record<Status, { label: string; icon: React.ReactNode; color: string }> = {
  ABERTO:     { label: "Aberto",      icon: <Clock className="w-3.5 h-3.5" />,        color: "text-muted-foreground bg-card" },
  EM_ANALISE: { label: "Em análise",  icon: <Loader2 className="w-3.5 h-3.5" />,      color: "text-amber-400 bg-amber-950" },
  RESOLVIDO:  { label: "Resolvido",   icon: <CheckCircle2 className="w-3.5 h-3.5" />, color: "text-green-400 bg-green-950" },
  FECHADO:    { label: "Fechado",     icon: <XCircle className="w-3.5 h-3.5" />,      color: "text-muted-foreground bg-background" },
}

// FAQ fixo do produto — sempre visível na aba FAQ

export default function SuportePage() {
  const confirmar = useConfirmar()
  const [aba, setAba] = useState<Tipo | "todos">("todos")
  const [faq, setFaq] = useState<{ id: string; pergunta: string; resposta: string }[]>([])
  const [faqOpen, setFaqOpen] = useState(false)
  const [faqEditando, setFaqEditando] = useState<{ id: string } | null>(null)
  const [faqForm, setFaqForm] = useState({ pergunta: "", resposta: "" })
  const [faqSalvando, setFaqSalvando] = useState(false)
  const [itens, setItens] = useState<Item[]>([])
  const [loading, setLoading] = useState(true)
  const [role, setRole] = useState<string>("")

  const [novoOpen, setNovoOpen] = useState(false)
  const [novoTipo, setNovoTipo] = useState<Tipo>("ERRO")
  const [novoTitulo, setNovoTitulo] = useState("")
  const [novoDesc, setNovoDesc] = useState("")
  const [saving, setSaving] = useState(false)

  const [respostaOpen, setRespostaOpen] = useState(false)
  const [respostaItem, setRespostaItem] = useState<Item | null>(null)
  const [respostaTexto, setRespostaTexto] = useState("")
  const [respostaStatus, setRespostaStatus] = useState<Status>("EM_ANALISE")

  /** @param silencioso não liga o loader — usado pela atualização automática. */
  const load = useCallback(async (silencioso = false) => {
    if (!silencioso) setLoading(true)
    const r = await fetch(`/api/suporte?tipo=${aba}`, { cache: "no-store" })
    if (r.ok) setItens(await r.json())
    if (!silencioso) setLoading(false)
  }, [aba])

  // Chamado novo e resposta do Admin chegam sem a tela saber.
  usarAtualizacaoAutomatica(() => load(true), { intervaloMs: 3_000 })

  useEffect(() => {
    fetch("/api/auth/me").then(r => r.json()).then(d => setRole(d?.user?.role ?? ""))
    load()
  }, [load])

  const isAdmin = role === "ADMIN"

  async function salvarNovo() {
    if (!novoTitulo.trim()) return
    setSaving(true)
    await fetch("/api/suporte", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tipo: novoTipo, titulo: novoTitulo, descricao: novoDesc }),
    })
    setSaving(false)
    setNovoOpen(false)
    setNovoTitulo("")
    setNovoDesc("")
    load()
  }

  async function salvarResposta() {
    if (!respostaItem) return
    setSaving(true)
    await fetch("/api/suporte", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: respostaItem.id, status: respostaStatus, resposta: respostaTexto }),
    })
    setSaving(false)
    setRespostaOpen(false)
    load()
  }

  async function excluir(id: string) {
    if (!await confirmar({ titulo: "Excluir este item?", perigo: true })) return
    await fetch(`/api/suporte?id=${id}`, { method: "DELETE" })
    load()
  }

  function abrirResposta(item: Item) {
    setRespostaItem(item)
    setRespostaTexto(item.resposta ?? "")
    setRespostaStatus(item.status)
    setRespostaOpen(true)
  }

  const filtrados = aba === "todos" ? itens : itens.filter(i => i.tipo === aba)

  const carregarFaq = useCallback(async () => {
    const r = await fetch("/api/faq", { cache: "no-store" })
    if (r.ok) setFaq((await r.json()).itens ?? [])
  }, [])

  // Só busca quando a aba abre: é conteúdo estático, não precisa carregar junto
  // com os chamados em toda visita à tela.
  useEffect(() => { if (aba === "FAQ") carregarFaq() }, [aba, carregarFaq])

  async function salvarFaq() {
    if (!faqForm.pergunta.trim() || !faqForm.resposta.trim()) return
    setFaqSalvando(true)
    try {
      const r = await fetch("/api/faq", {
        method: faqEditando ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...(faqEditando ? { id: faqEditando.id } : {}), ...faqForm }),
      })
      if (!r.ok) {
        const j = await r.json().catch(() => ({}))
        await confirmar({ titulo: j.error || "Não foi possível salvar.", apenasAviso: true })
        return
      }
      setFaqOpen(false)
      carregarFaq()
    } finally { setFaqSalvando(false) }
  }

  async function excluirFaq(id: string) {
    if (!await confirmar({ titulo: "Excluir esta pergunta?", perigo: true })) return
    await fetch(`/api/faq?id=${id}`, { method: "DELETE" })
    carregarFaq()
  }

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-6">
      <CabecalhoPagina
        icone={LifeBuoy}
        titulo="Suporte"
        contexto={`${itens.filter(i => i.status === "ABERTO" || i.status === "EM_ANALISE").length} em aberto`}
        acao={
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => load()} className="h-9 w-9 border-border p-0">
              <RefreshCw className="h-4 w-4" />
            </Button>
            <Button size="sm" onClick={() => setNovoOpen(true)} className="h-9">
              <Plus className="mr-1 h-4 w-4" /> Reportar
            </Button>
          </div>
        }
      />

      <FaixaMetricas>
        <CartaoMetrica icone={Clock} rotulo="Abertos"
          valor={itens.filter(i => i.status === "ABERTO").length} nota="Aguardando análise" />
        <CartaoMetrica icone={Loader2} rotulo="Em análise"
          valor={itens.filter(i => i.status === "EM_ANALISE").length} nota="Sendo tratados" />
        <CartaoMetrica icone={CheckCircle2} rotulo="Resolvidos"
          valor={itens.filter(i => i.status === "RESOLVIDO").length} nota="Encerrados" />
        <CartaoMetrica icone={HelpCircle} rotulo="No FAQ"
          valor={faq.length || "—"} nota="Perguntas respondidas" />
      </FaixaMetricas>

      <Tabs value={aba} onValueChange={v => setAba(v as Tipo | "todos")}>
        <TabsList className="bg-surface-3 rounded-xl p-1 h-10 overflow-x-auto no-scrollbar justify-start max-w-full">
          <TabsTrigger value="todos" className="rounded-lg h-8 px-3 text-[13px] flex-shrink-0 data-[state=active]:bg-surface-1 data-[state=active]:shadow-sm data-[state=active]:shadow-black/20 text-muted-fg data-[state=active]:text-foreground">Todos</TabsTrigger>
          <TabsTrigger value="ERRO" className="rounded-lg h-8 px-3 text-[13px] flex-shrink-0 data-[state=active]:bg-surface-1 data-[state=active]:shadow-sm data-[state=active]:shadow-black/20 text-muted-fg data-[state=active]:text-ios-red">Erros</TabsTrigger>
          <TabsTrigger value="FAQ" className="rounded-lg h-8 px-3 text-[13px] flex-shrink-0 data-[state=active]:bg-surface-1 data-[state=active]:shadow-sm data-[state=active]:shadow-black/20 text-muted-fg data-[state=active]:text-ios-blue">FAQ</TabsTrigger>
          <TabsTrigger value="SUGESTAO" className="rounded-lg h-8 px-3 text-[13px] flex-shrink-0 data-[state=active]:bg-surface-1 data-[state=active]:shadow-sm data-[state=active]:shadow-black/20 text-muted-fg data-[state=active]:text-ios-yellow">Sugestões</TabsTrigger>
        </TabsList>

        {/* ── FAQ da empresa: conteúdo do banco, editável pelo Admin ── */}
        {aba === "FAQ" && (
          <div className="mt-4 space-y-2">
            <div className="flex items-center justify-between gap-3 px-1">
              <p className="text-[11px] uppercase tracking-widest text-muted-fg">Perguntas frequentes</p>
              {isAdmin && (
                <Button size="sm" variant="outline" className="h-8 gap-1.5"
                  onClick={() => { setFaqEditando(null); setFaqForm({ pergunta: "", resposta: "" }); setFaqOpen(true) }}>
                  <Plus className="h-3.5 w-3.5" /> Adicionar
                </Button>
              )}
            </div>

            {faq.length === 0 ? (
              <p className="rounded-2xl border border-dashed border-border p-6 text-center text-sm text-muted-fg">
                Nenhuma pergunta cadastrada ainda.
              </p>
            ) : faq.map(f => (
              <details key={f.id} className="group overflow-hidden rounded-2xl border border-hairline bg-surface-1">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-4 py-3.5 text-[14px] font-medium text-foreground">
                  {f.pergunta}
                  <ChevronDown className="h-4 w-4 flex-shrink-0 text-muted-fg transition-transform group-open:rotate-180" />
                </summary>
                <div className="px-4 pb-4">
                  <p className="whitespace-pre-line text-[14px] leading-relaxed text-muted-fg">{f.resposta}</p>
                  {isAdmin && (
                    <div className="mt-3 flex gap-1 border-t border-hairline pt-3">
                      <Button size="sm" variant="ghost" className="h-7 gap-1.5 px-2.5 text-[12px] text-muted-fg"
                        onClick={() => { setFaqEditando(f); setFaqForm({ pergunta: f.pergunta, resposta: f.resposta }); setFaqOpen(true) }}>
                        <Pencil className="h-3.5 w-3.5" /> Editar
                      </Button>
                      <Button size="sm" variant="ghost" className="h-7 gap-1.5 px-2.5 text-[12px] text-muted-fg hover:text-ios-red"
                        onClick={() => excluirFaq(f.id)}>
                        <Trash2 className="h-3.5 w-3.5" /> Excluir
                      </Button>
                    </div>
                  )}
                </div>
              </details>
            ))}
            <p className="px-1 pt-3 text-[11px] uppercase tracking-widest text-muted-fg">Perguntas da equipe</p>
          </div>
        )}

        <TabsContent value={aba} className="mt-4">
          {loading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : filtrados.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <MessageSquare className="w-10 h-10 mx-auto mb-3 opacity-30" />
              <p>Nenhum item encontrado</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filtrados.map(item => {
                const tm = TIPO_META[item.tipo]
                const sm = STATUS_META[item.status]
                return (
                  <div key={item.id}
                    className="rounded-xl border border-border bg-card/50 p-4 space-y-2">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className={tm.color}>{tm.icon}</span>
                        <span className="font-medium text-white truncate">{item.titulo}</span>
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium ${sm.color}`}>
                          {sm.icon}{sm.label}
                        </span>
                      </div>
                      <div className="flex gap-1 flex-shrink-0">
                        {isAdmin && (
                          <>
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-sky-400"
                              onClick={() => abrirResposta(item)}>
                              <MessageSquare className="w-3.5 h-3.5" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-red-400"
                              onClick={() => excluir(item.id)}>
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </>
                        )}
                      </div>
                    </div>

                    {item.descricao && (
                      <p className="text-sm text-muted-foreground leading-relaxed">{item.descricao}</p>
                    )}

                    {item.resposta && (
                      <div className="rounded-2xl bg-green-950/40 border border-green-800/30 px-3 py-2">
                        <p className="text-xs text-green-400 font-medium mb-0.5">Resposta:</p>
                        <p className="text-sm text-muted-foreground/70">{item.resposta}</p>
                      </div>
                    )}

                    <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                      <span>{item.user?.nome ?? "—"}</span>
                      <span>{new Date(item.createdAt).toLocaleDateString("pt-BR")}</span>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Dialog: Novo item */}
      <Dialog open={faqOpen} onOpenChange={setFaqOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{faqEditando ? "Editar pergunta" : "Nova pergunta"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 px-5 py-4 sm:px-6">
            <div className="space-y-1.5">
              <Label>Pergunta *</Label>
              <Input value={faqForm.pergunta}
                onChange={e => setFaqForm(f => ({ ...f, pergunta: e.target.value }))}
                placeholder="Escreva como a pessoa perguntaria" />
            </div>
            <div className="space-y-1.5">
              <Label>Resposta *</Label>
              <Textarea rows={7} value={faqForm.resposta}
                onChange={e => setFaqForm(f => ({ ...f, resposta: e.target.value }))}
                placeholder="Diga o caminho: onde clicar, o que preencher, o que esperar." />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setFaqOpen(false)}>Cancelar</Button>
            <Button onClick={salvarFaq} disabled={faqSalvando || !faqForm.pergunta.trim() || !faqForm.resposta.trim()}>
              {faqSalvando ? "Salvando..." : "Salvar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={novoOpen} onOpenChange={setNovoOpen}>
        <DialogContent className="max-w-md bg-background border-border text-white">
          <DialogHeader>
            <DialogTitle>Novo item de suporte</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 px-5 sm:px-6 py-4">
            <div className="space-y-1.5">
              <Label>Tipo</Label>
              <div className="flex gap-2">
                {(["ERRO", "FAQ", "SUGESTAO"] as Tipo[]).map(t => {
                  const m = TIPO_META[t]
                  return (
                    <button key={t} onClick={() => setNovoTipo(t)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-2xl border text-sm transition-colors ${
                        novoTipo === t
                          ? "border-sky-500 bg-sky-950 text-white"
                          : "border-border text-muted-foreground hover:border-slate-500"
                      }`}>
                      <span className={m.color}>{m.icon}</span>{m.label}
                    </button>
                  )
                })}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Título *</Label>
              <Input value={novoTitulo} onChange={e => setNovoTitulo(e.target.value)}
                placeholder="Resumo em uma frase" className="bg-card border-border" />
            </div>
            <div className="space-y-1.5">
              <Label>Descrição</Label>
              <Textarea value={novoDesc} onChange={e => setNovoDesc(e.target.value)}
                placeholder="Detalhes, passos para reproduzir, contexto…"
                rows={4} className="bg-card border-border resize-none" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setNovoOpen(false)}>Cancelar</Button>
            <Button onClick={salvarNovo} disabled={saving || !novoTitulo.trim()}
              className="bg-sky-600 hover:bg-sky-500">
              {saving ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null}
              Enviar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog: Resposta ADMIN */}
      <Dialog open={respostaOpen} onOpenChange={setRespostaOpen}>
        <DialogContent className="max-w-md bg-background border-border text-white">
          <DialogHeader>
            <DialogTitle>Responder / atualizar status</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 px-5 sm:px-6 py-4">
            <div className="space-y-1.5">
              <Label>Status</Label>
              <div className="flex flex-wrap gap-2">
                {(["ABERTO", "EM_ANALISE", "RESOLVIDO", "FECHADO"] as Status[]).map(s => {
                  const m = STATUS_META[s]
                  return (
                    <button key={s} onClick={() => setRespostaStatus(s)}
                      className={`flex items-center gap-1 px-3 py-1 rounded-2xl border text-xs transition-colors ${
                        respostaStatus === s
                          ? "border-sky-500 bg-sky-950 text-white"
                          : "border-border text-muted-foreground hover:border-slate-500"
                      }`}>
                      {m.label}
                    </button>
                  )
                })}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Resposta para o usuário</Label>
              <Textarea value={respostaTexto} onChange={e => setRespostaTexto(e.target.value)}
                placeholder="Explique a solução, status ou próximos passos…"
                rows={4} className="bg-card border-border resize-none" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setRespostaOpen(false)}>Cancelar</Button>
            <Button onClick={salvarResposta} disabled={saving} className="bg-sky-600 hover:bg-sky-500">
              {saving ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null}
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

