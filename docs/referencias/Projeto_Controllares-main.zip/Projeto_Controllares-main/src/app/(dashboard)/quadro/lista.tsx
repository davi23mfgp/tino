"use client"

import { useState, useRef, useEffect } from "react"
import { useDraggable, useDroppable } from "@dnd-kit/core"
import {
  Plus, X, MoreHorizontal, ChevronsLeftRight, ChevronsRightLeft,
  Flag, CalendarDays, HardHat, Check, Archive, Copy, Trash2,
} from "lucide-react"
import { CORES_LISTA, corLista } from "./cores"

export interface Coluna {
  id: string; nome: string; ordem: number; final: boolean
  cor: string | null; recolhida: boolean
}

export interface Tarefa {
  id: string
  titulo: string
  descricao: string | null
  prioridade: "BAIXA" | "MEDIA" | "ALTA" | "URGENTE"
  concluida: boolean
  dataVenc: string | null
  colunaId: string | null
  atribuido: { id: string; nome: string } | null
  criador: { id: string; nome: string } | null
  obra: { id: string; client_name: string } | null
}

const COR_PRIORIDADE: Record<Tarefa["prioridade"], string> = {
  BAIXA: "text-white/45",
  MEDIA: "text-sky-300",
  ALTA: "text-amber-300",
  URGENTE: "text-red-300",
}

/** Iniciais para o avatar do responsável, como no Trello. */
function iniciais(nome: string) {
  const p = nome.trim().split(/\s+/)
  return ((p[0]?.[0] ?? "") + (p.length > 1 ? p[p.length - 1][0] : "")).toUpperCase()
}

export function Cartao({ tarefa, aoAbrir, aoExcluir }: {
  tarefa: Tarefa; aoAbrir: () => void; aoExcluir?: () => void
}) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({ id: tarefa.id })

  /* O cartão arrastado precisa CONTINUAR VISÍVEL e seguir o cursor.
     Antes ele sumia: o dnd-kit tira o elemento do fluxo e, sem transform e sem
     z-index, ele ficava atrás da própria lista. */
  const style = transform
    ? {
        transform: `translate3d(${transform.x}px, ${transform.y}px, 0) rotate(3deg)`,
        zIndex: 999,
        position: "relative" as const,
      }
    : undefined

  const venc = tarefa.dataVenc ? new Date(tarefa.dataVenc) : null
  const hoje = new Date(); hoje.setHours(0, 0, 0, 0)
  const atrasada = !!venc && venc < hoje && !tarefa.concluida

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...listeners}
      {...attributes}
      onClick={() => { if (!isDragging) aoAbrir() }}
      className={`select-none rounded-lg border border-white/10 bg-[#22272b] px-3 py-2 shadow-sm ${
        isDragging
          ? "cursor-grabbing opacity-95 shadow-2xl ring-2 ring-sky-400/60"
          : "cursor-pointer hover:border-white/25"
      }`}
    >
      <div className="group/cartao flex items-start gap-2">
        <p className={`min-w-0 flex-1 text-[13px] leading-snug ${tarefa.concluida ? "text-white/40 line-through" : "text-white/90"}`}>
          {tarefa.titulo}
        </p>
        {/* Excluir aparece no hover do cartão, como no Trello: visível o tempo
            todo, competiria com o alvo principal, que é abrir e arrastar. */}
        {aoExcluir && (
          <button type="button" title="Excluir cartão"
            onPointerDown={e => e.stopPropagation()}
            onClick={e => { e.stopPropagation(); aoExcluir() }}
            className="shrink-0 rounded p-0.5 text-white/40 opacity-0 hover:bg-white/10 hover:text-red-300 group-hover/cartao:opacity-100">
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        )}
      </div>

      {(venc || tarefa.atribuido || tarefa.obra || tarefa.prioridade !== "MEDIA") && (
        <div className="mt-2 flex flex-wrap items-center gap-1.5">
          {venc && (
            <span className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[11px] ${
              atrasada ? "bg-red-500/20 text-red-200" : "bg-white/8 text-white/60"
            }`}>
              <CalendarDays className="h-3 w-3" />
              {venc.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" })}
            </span>
          )}
          {tarefa.prioridade !== "MEDIA" && (
            <span className={`inline-flex items-center gap-1 text-[11px] ${COR_PRIORIDADE[tarefa.prioridade]}`}>
              <Flag className="h-3 w-3" /> {tarefa.prioridade.toLowerCase()}
            </span>
          )}
          {tarefa.obra && (
            <span className="inline-flex min-w-0 items-center gap-1 text-[11px] text-white/50">
              <HardHat className="h-3 w-3 shrink-0" />
              <span className="max-w-[110px] truncate">{tarefa.obra.client_name}</span>
            </span>
          )}
          {tarefa.atribuido && (
            <span title={tarefa.atribuido.nome}
              className="ml-auto grid h-6 w-6 place-items-center rounded-full bg-sky-700 text-[10px] font-bold text-white">
              {iniciais(tarefa.atribuido.nome)}
            </span>
          )}
        </div>
      )}
    </div>
  )
}

export function Lista({
  coluna, tarefas, aoMudar, aoApagar, aoCriarTarefa, aoAbrirTarefa, aoExcluirTarefa,
}: {
  coluna: Coluna
  tarefas: Tarefa[]
  aoMudar: (dados: Record<string, unknown>) => void
  aoApagar: () => void
  aoCriarTarefa: (titulo: string) => void
  aoAbrirTarefa: (t: Tarefa) => void
  aoExcluirTarefa: (t: Tarefa) => void
}) {
  const { setNodeRef, isOver } = useDroppable({ id: coluna.id })
  const cor = corLista(coluna.cor)

  const [menu, setMenu] = useState(false)
  const [corAberta, setCorAberta] = useState(false)
  const [editando, setEditando] = useState(false)
  const [nome, setNome] = useState(coluna.nome)
  const [novo, setNovo] = useState(false)
  const [titulo, setTitulo] = useState("")
  const menuRef = useRef<HTMLDivElement>(null)

  useEffect(() => { setNome(coluna.nome) }, [coluna.nome])

  /* Menu fecha ao clicar fora, como qualquer menu. Sem isto ficam três
     abertos ao mesmo tempo e o quadro vira uma pilha de caixas. */
  useEffect(() => {
    if (!menu) return
    const fora = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenu(false); setCorAberta(false)
      }
    }
    document.addEventListener("mousedown", fora)
    return () => document.removeEventListener("mousedown", fora)
  }, [menu])

  if (coluna.recolhida) {
    return (
      <div ref={setNodeRef}
        className={`flex w-11 shrink-0 flex-col items-center gap-3 rounded-xl py-3 ${cor.fundo} ${
          isOver ? "ring-2 ring-sky-400/60" : ""
        }`}>
        <button type="button" onClick={() => aoMudar({ recolhida: false })}
          title="Expandir lista" className={`${cor.texto} opacity-70 hover:opacity-100`}>
          <ChevronsLeftRight className="h-4 w-4" />
        </button>
        <span className={`rounded bg-black/30 px-1.5 text-[11px] font-bold ${cor.texto}`}>{tarefas.length}</span>
        <span className={`[writing-mode:vertical-rl] text-[13px] font-semibold ${cor.texto}`}>{coluna.nome}</span>
      </div>
    )
  }

  return (
    <div ref={setNodeRef}
      className={`flex max-h-full w-[272px] shrink-0 flex-col rounded-xl ${cor.fundo} ${
        isOver ? "ring-2 ring-sky-400/60" : ""
      }`}>
      {/* Cabeçalho: nome vira campo ao clicar, como no Trello. */}
      <div className={`relative flex items-center gap-1 rounded-t-xl px-2 py-2 ${cor.topo}`}>
        {editando ? (
          <input autoFocus value={nome}
            onChange={e => setNome(e.target.value)}
            onFocus={e => e.currentTarget.select()}
            onBlur={() => { setEditando(false); if (nome.trim() && nome !== coluna.nome) aoMudar({ nome: nome.trim() }) }}
            onKeyDown={e => {
              if (e.key === "Enter") e.currentTarget.blur()
              if (e.key === "Escape") { setNome(coluna.nome); setEditando(false) }
            }}
            className="min-w-0 flex-1 rounded border-2 border-sky-500 bg-[#22272b] px-2 py-1 text-[13px] font-semibold text-white outline-none" />
        ) : (
          <button type="button" onClick={() => setEditando(true)}
            className={`min-w-0 flex-1 truncate rounded px-2 py-1 text-left text-[13px] font-semibold ${cor.texto}`}>
            {coluna.nome}
          </button>
        )}

        <span className={`rounded px-1.5 text-[11px] font-bold opacity-60 ${cor.texto}`}>{tarefas.length}</span>
        {coluna.final && (
          <span title="Tarefa que cai aqui conta como concluída"
            className="rounded bg-emerald-500/25 px-1.5 text-[10px] font-semibold text-emerald-200">fim</span>
        )}

        <button type="button" onClick={() => aoMudar({ recolhida: true })} title="Recolher lista"
          className={`rounded p-1 opacity-60 hover:bg-black/20 hover:opacity-100 ${cor.texto}`}>
          <ChevronsRightLeft className="h-4 w-4" />
        </button>
        <button type="button" onClick={() => setMenu(v => !v)} title="Ações da lista"
          className={`rounded p-1 opacity-60 hover:bg-black/20 hover:opacity-100 ${cor.texto}`}>
          <MoreHorizontal className="h-4 w-4" />
        </button>

        {menu && (
          <div ref={menuRef}
            className="absolute right-1 top-11 z-40 w-64 rounded-lg border border-white/10 bg-[#282e33] p-2 shadow-2xl">
            <div className="relative mb-1 flex items-center justify-center border-b border-white/10 pb-2">
              <p className="text-[13px] font-semibold text-white/80">Ações da lista</p>
              <button type="button" onClick={() => { setMenu(false); setCorAberta(false) }}
                className="absolute right-0 text-white/50 hover:text-white"><X className="h-3.5 w-3.5" /></button>
            </div>

            <button type="button" onClick={() => { setMenu(false); setNovo(true) }}
              className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-[13px] text-white/80 hover:bg-white/10">
              <Plus className="h-3.5 w-3.5" /> Adicionar cartão
            </button>
            <button type="button" onClick={() => { setMenu(false); setEditando(true) }}
              className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-[13px] text-white/80 hover:bg-white/10">
              <Copy className="h-3.5 w-3.5" /> Renomear lista
            </button>
            {!coluna.final && (
              <button type="button" onClick={() => { setMenu(false); aoMudar({ final: true }) }}
                className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-[13px] text-white/80 hover:bg-white/10">
                <Check className="h-3.5 w-3.5" /> Marcar como lista de conclusão
              </button>
            )}

            <div className="mt-1 border-t border-white/10 pt-1">
              <button type="button" onClick={() => setCorAberta(v => !v)}
                className="flex w-full items-center justify-between rounded px-2 py-1.5 text-left text-[13px] text-white/80 hover:bg-white/10">
                Alterar cor da lista
                <span className={`h-4 w-4 rounded ${cor.amostra}`} />
              </button>
              {corAberta && (
                <div className="px-2 pb-2 pt-1">
                  <div className="grid grid-cols-5 gap-1.5">
                    {CORES_LISTA.filter(c => c.id !== "cinza").map(c => (
                      <button key={c.id} type="button" title={c.nome}
                        onClick={() => { aoMudar({ cor: c.id }); setCorAberta(false); setMenu(false) }}
                        className={`grid h-8 place-items-center rounded ${c.amostra}`}>
                        {(coluna.cor ?? "cinza") === c.id && <Check className="h-4 w-4 text-white" />}
                      </button>
                    ))}
                  </div>
                  <button type="button"
                    onClick={() => { aoMudar({ cor: null }); setCorAberta(false); setMenu(false) }}
                    className="mt-2 flex w-full items-center justify-center gap-1.5 rounded border border-white/10 py-1.5 text-[12px] text-white/70 hover:bg-white/10">
                    <X className="h-3 w-3" /> Remover cor
                  </button>
                </div>
              )}
            </div>

            <div className="mt-1 border-t border-white/10 pt-1">
              {/* Arquivar guarda; apagar some. São ações diferentes e ficam
                  separadas de propósito. */}
              <button type="button" onClick={() => { setMenu(false); aoMudar({ arquivada: true }) }}
                className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-[13px] text-white/80 hover:bg-white/10">
                <Archive className="h-3.5 w-3.5" /> Arquivar esta lista
              </button>
              <button type="button" onClick={() => { setMenu(false); aoApagar() }}
                className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-[13px] text-red-300 hover:bg-white/10">
                <Trash2 className="h-3.5 w-3.5" /> Apagar lista
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="flex-1 space-y-2 overflow-y-auto px-2 pb-1">
        {tarefas.map(t => (
          <Cartao key={t.id} tarefa={t}
            aoAbrir={() => aoAbrirTarefa(t)}
            aoExcluir={() => aoExcluirTarefa(t)} />
        ))}
      </div>

      <div className="p-2">
        {novo ? (
          <div className="space-y-2">
            <textarea autoFocus value={titulo} rows={3}
              onChange={e => setTitulo(e.target.value)}
              onKeyDown={e => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  if (titulo.trim()) { aoCriarTarefa(titulo.trim()); setTitulo("") }
                }
                if (e.key === "Escape") { setNovo(false); setTitulo("") }
              }}
              placeholder="Insira um título ou cole um link"
              className="w-full resize-none rounded-lg border border-white/10 bg-[#22272b] px-3 py-2 text-[13px] text-white outline-none placeholder:text-white/40 focus:border-sky-500" />
            <div className="flex items-center gap-2">
              <button type="button"
                onClick={() => { if (titulo.trim()) { aoCriarTarefa(titulo.trim()); setTitulo("") } }}
                className="rounded bg-sky-500 px-3 py-1.5 text-[13px] font-semibold text-white hover:bg-sky-400">
                Adicionar cartão
              </button>
              <button type="button" onClick={() => { setNovo(false); setTitulo("") }}
                className="rounded p-1.5 text-white/60 hover:bg-white/10 hover:text-white">
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        ) : (
          <button type="button" onClick={() => setNovo(true)}
            className={`flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-[13px] opacity-70 hover:bg-black/20 hover:opacity-100 ${cor.texto}`}>
            <Plus className="h-4 w-4" /> Adicionar um cartão
          </button>
        )}
      </div>
    </div>
  )
}
