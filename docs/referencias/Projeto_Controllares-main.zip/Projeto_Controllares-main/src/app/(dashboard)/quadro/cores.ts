/**
 * Paleta do quadro, no desenho do Trello.
 *
 * A lista inteira é tingida, não só uma faixa no topo: é o que faz o olho achar
 * a coluna certa antes de ler o nome. Os tons são sólidos e escuros porque a
 * plataforma é escura — a paleta clara do Trello sobre fundo preto vira mancha.
 *
 * `id` é o que vai para o banco. Trocar a cor depois não pode exigir reescrever
 * linha, então nada de CSS gravado.
 */
export interface CorLista {
  id: string
  nome: string
  /** Fundo da lista inteira. */
  fundo: string
  /** Cabeçalho, um passo mais forte que o corpo. */
  topo: string
  /** Amostra quadrada do seletor de cor. */
  amostra: string
  /** Texto sobre a lista tingida. */
  texto: string
}

export const CORES_LISTA: CorLista[] = [
  { id: "cinza",    nome: "Sem cor",  fundo: "bg-surface-1/70",   topo: "bg-transparent",     amostra: "bg-muted-foreground/40", texto: "text-foreground" },
  { id: "verde",    nome: "Verde",    fundo: "bg-emerald-950/70", topo: "bg-emerald-900/40",  amostra: "bg-emerald-600",  texto: "text-emerald-50" },
  { id: "amarelo",  nome: "Amarelo",  fundo: "bg-yellow-950/70",  topo: "bg-yellow-900/40",   amostra: "bg-yellow-600",   texto: "text-yellow-50" },
  { id: "laranja",  nome: "Laranja",  fundo: "bg-orange-950/70",  topo: "bg-orange-900/40",   amostra: "bg-orange-600",   texto: "text-orange-50" },
  { id: "vermelho", nome: "Vermelho", fundo: "bg-red-950/70",     topo: "bg-red-900/40",      amostra: "bg-red-600",      texto: "text-red-50" },
  { id: "roxo",     nome: "Roxo",     fundo: "bg-purple-950/70",  topo: "bg-purple-900/40",   amostra: "bg-purple-600",   texto: "text-purple-50" },
  { id: "azul",     nome: "Azul",     fundo: "bg-blue-950/70",    topo: "bg-blue-900/40",     amostra: "bg-blue-600",     texto: "text-blue-50" },
  { id: "ciano",    nome: "Ciano",    fundo: "bg-cyan-950/70",    topo: "bg-cyan-900/40",     amostra: "bg-cyan-600",     texto: "text-cyan-50" },
  { id: "lima",     nome: "Lima",     fundo: "bg-lime-950/70",    topo: "bg-lime-900/40",     amostra: "bg-lime-600",     texto: "text-lime-50" },
  { id: "rosa",     nome: "Rosa",     fundo: "bg-pink-950/70",    topo: "bg-pink-900/40",     amostra: "bg-pink-600",     texto: "text-pink-50" },
]

export const corLista = (id: string | null | undefined): CorLista =>
  CORES_LISTA.find(c => c.id === id) ?? CORES_LISTA[0]

/** Fundos do quadro. O Trello põe foto; aqui é gradiente, que não pesa. */
export const FUNDOS: { id: string; nome: string; classe: string }[] = [
  { id: "grafite", nome: "Grafite", classe: "from-zinc-900 via-zinc-950 to-black" },
  { id: "oceano",  nome: "Oceano",  classe: "from-sky-950 via-slate-950 to-black" },
  { id: "violeta", nome: "Violeta", classe: "from-violet-950 via-zinc-950 to-black" },
  { id: "floresta", nome: "Floresta", classe: "from-emerald-950 via-zinc-950 to-black" },
  { id: "brasa",   nome: "Brasa",   classe: "from-orange-950 via-zinc-950 to-black" },
]

export const fundoQuadro = (id: string | null | undefined) =>
  FUNDOS.find(f => f.id === id) ?? FUNDOS[0]
