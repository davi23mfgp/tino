import type { Metadata } from "next"

/* Só título de aba: a página é componente de cliente e no App Router
   componente de cliente não exporta `metadata`. */
export const metadata: Metadata = { title: "Quadro" }

export default function Layout({ children }: { children: React.ReactNode }) {
  return children
}
