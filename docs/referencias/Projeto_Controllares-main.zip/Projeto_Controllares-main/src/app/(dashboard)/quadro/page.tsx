"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import {
  DndContext, DragOverlay, PointerSensor, pointerWithin,
  useSensor, useSensors, type DragEndEvent, type DragStartEvent,
} from "@dnd-kit/core"
import {
  Plus, X, Filter, Star, LayoutGrid, ChevronDown, Search, Trash2, Archive,
} from "lucide-react"
import { showToast } from "@/components/ui/toast"
import { Lista, Cartao, type Coluna, type Tarefa } from "./lista"
import { FUNDOS, fundoQuadro } from "./cores"
import { useMemoriaDeFiltro } from "@/hooks/usar-memoria-filtro"

/* Quadro no desenho do Trello.
   O que faz um quadro parecer o Trello não é a coluna com cartão: é a lista
   inteira tingida, o nome que vira campo ao clicar, o menu de ações da lista,
   o painel de filtro que desce pela direita e a barra de quadros embaixo. */

interface Quadro {
  id: string; nome: string; fundo: string; favorito: boolean
}

export default function QuadroPage() {
  const [quadros, setQuadros] = useState<Quadro[]>([])
  const [quadroId, setQuadroId] = useState<string | null>(null)
  const [colunas, setColunas] = useState<Coluna[]>([])
  const [tarefas, setTarefas] = useState<Tarefa[]>([])
  const [carregando, setCarregando] = useState(true)
  const [euId, setEuId] = useState<string | null>(null)
  const [arrastando, setArrastando] = useState<Tarefa | null>(null)
  /* Excluir cartão passa por confirmação. Não há lixeira nem desfazer: o
     cartão sai do banco, e um clique errado num cartão pequeno é fácil. */
  const [excluir, setExcluir] = useState<Tarefa | null>(null)

  const [novaLista, setNovaLista] = useState(false)
  const [nomeLista, setNomeLista] = useState("")
  const [painel, setPainel] = useState<"" | "filtro" | "menu" | "quadros">("")
  const [editandoNome, setEditandoNome] = useState(false)
  const [nomeQuadro, setNomeQuadro] = useState("")

  // Filtros, iguais aos do Trello.
  const [busca, setBusca] = useMemoriaDeFiltro("quadro:busca", "")
  const [soMinhas, setSoMinhas] = useState(false)
  const [semResponsavel, setSemResponsavel] = useState(false)
  const [status, setStatus] = useMemoriaDeFiltro<"" | "concluidas" | "abertas">("quadro:status", "")
  const [prazo, setPrazo] = useState<"" | "sem-data" | "atrasadas" | "semana">("")

  const quadro = quadros.find(q => q.id === quadroId) ?? null

  const carregarQuadros = useCallback(async () => {
    const r = await fetch("/api/quadro", { cache: "no-store" })
    const j = await r.json().catch(() => ({}))
    const lista: Quadro[] = j.quadros ?? []
    setQuadros(lista)
    setQuadroId(atual => atual && lista.some(q => q.id === atual) ? atual : (lista[0]?.id ?? null))
  }, [])

  const carregar = useCallback(async (id: string) => {
    const [rc, rt] = await Promise.all([
      fetch(`/api/quadro/colunas?quadroId=${id}`, { cache: "no-store" }),
      fetch(`/api/tarefas?quadro=true&quadroId=${id}`, { cache: "no-store" }),
    ])
    setColunas((await rc.json().catch(() => ({}))).colunas ?? [])
    setTarefas((await rt.json().catch(() => ({}))).tarefas ?? [])
    setCarregando(false)
  }, [])

  useEffect(() => { carregarQuadros() }, [carregarQuadros])
  useEffect(() => { if (quadroId) carregar(quadroId) }, [quadroId, carregar])
  useEffect(() => {
    fetch("/api/auth/me").then(r => r.ok ? r.json() : null)
      .then(d => setEuId(d?.user?.id ?? null)).catch(() => {})
  }, [])

  const sensores = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }))

  const semAcento = (t: string) =>
    t.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()
  const termo = semAcento(busca.trim())
  const hoje = new Date(); hoje.setHours(0, 0, 0, 0)
  const emUmaSemana = new Date(hoje); emUmaSemana.setDate(hoje.getDate() + 7)

  const visiveis = tarefas.filter(t => {
    if (soMinhas && euId && t.atribuido?.id !== euId) return false
    if (semResponsavel && t.atribuido) return false
    if (status === "concluidas" && !t.concluida) return false
    if (status === "abertas" && t.concluida) return false
    if (termo && !semAcento(`${t.titulo} ${t.descricao ?? ""} ${t.atribuido?.nome ?? ""} ${t.obra?.client_name ?? ""}`).includes(termo)) return false
    if (prazo) {
      const v = t.dataVenc ? new Date(t.dataVenc) : null
      if (prazo === "sem-data" && v) return false
      if (prazo === "atrasadas" && (!v || v >= hoje)) return false
      if (prazo === "semana" && (!v || v < hoje || v > emUmaSemana)) return false
    }
    return true
  })

  const filtrosAtivos = [soMinhas, semResponsavel, !!status, !!prazo, !!termo].filter(Boolean).length
  const primeira = colunas[0]?.id ?? null
  const daColuna = (id: string) => visiveis.filter(t => (t.colunaId ?? primeira) === id)

  async function mudarColuna(id: string, dados: Record<string, unknown>) {
    setColunas(prev => prev.map(c => c.id === id ? { ...c, ...dados } as Coluna : c))
    await fetch("/api/quadro/colunas", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, ...dados }),
    }).catch(() => {})
    if (quadroId) carregar(quadroId)
  }

  async function apagarColuna(id: string) {
    const r = await fetch(`/api/quadro/colunas?id=${id}`, { method: "DELETE" })
    const j = await r.json().catch(() => ({}))
    if (!r.ok) { showToast(j.error || "Não foi possível apagar.", { variant: "error" }); return }
    showToast(`Lista apagada. Os cartões foram para "${j.movidasPara}".`, { variant: "success" })
    if (quadroId) carregar(quadroId)
  }

  async function criarLista() {
    const nome = nomeLista.trim()
    if (!nome || !quadroId) return
    setNomeLista("")
    await fetch("/api/quadro/colunas", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nome, quadroId }),
    })
    carregar(quadroId)
  }

  async function criarTarefa(colunaId: string, titulo: string) {
    const r = await fetch("/api/tarefas", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ titulo, colunaId }),
    })
    if (r.ok && quadroId) carregar(quadroId)
    else if (!r.ok) showToast("Não foi possível criar o cartão.", { variant: "error" })
  }

  async function excluirTarefa() {
    if (!excluir) return
    const alvo = excluir
    setExcluir(null)
    setTarefas(prev => prev.filter(t => t.id !== alvo.id))
    const r = await fetch(`/api/tarefas/${alvo.id}`, { method: "DELETE" }).catch(() => null)
    if (!r?.ok) {
      const j = await r?.json().catch(() => ({}))
      showToast(j?.error || "Não foi possível excluir o cartão.", { variant: "error" })
      if (quadroId) carregar(quadroId)
    }
  }

  async function moverTarefa(tarefaId: string, colunaId: string) {
    const antes = tarefas
    setTarefas(prev => prev.map(t => t.id === tarefaId ? { ...t, colunaId } : t))
    const r = await fetch(`/api/tarefas/${tarefaId}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ colunaId }),
    }).catch(() => null)
    if (!r?.ok) { setTarefas(antes); showToast("Não foi possível mover o cartão.", { variant: "error" }) }
    else if (quadroId) carregar(quadroId)
  }

  function aoIniciar(e: DragStartEvent) {
    setArrastando(tarefas.find(t => t.id === String(e.active.id)) ?? null)
  }
  function aoSoltar(e: DragEndEvent) {
    setArrastando(null)
    const destino = String(e.over?.id ?? "")
    if (!destino) return
    const t = tarefas.find(x => x.id === String(e.active.id))
    if (!t || (t.colunaId ?? primeira) === destino) return
    moverTarefa(t.id, destino)
  }

  async function mudarQuadro(dados: Record<string, unknown>) {
    if (!quadroId) return
    await fetch("/api/quadro", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: quadroId, ...dados }),
    })
    carregarQuadros()
  }

  async function criarQuadro() {
    const nome = prompt("Nome do quadro")?.trim()
    if (!nome) return
    const r = await fetch("/api/quadro", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nome }),
    })
    const j = await r.json().catch(() => ({}))
    if (r.ok) { await carregarQuadros(); setQuadroId(j.id); setPainel("") }
  }

  async function arquivarQuadro() {
    const r = await fetch(`/api/quadro?id=${quadroId}`, { method: "DELETE" })
    const j = await r.json().catch(() => ({}))
    if (!r.ok) { showToast(j.error || "Não foi possível arquivar.", { variant: "error" }); return }
    setPainel(""); setQuadroId(null); carregarQuadros()
  }

  const fundo = fundoQuadro(quadro?.fundo)

  return (
    <div className={`flex h-[calc(100vh-4rem)] flex-col bg-gradient-to-br ${fundo.classe}`}>
      {/* Cabeçalho do quadro */}
      <header className="flex shrink-0 flex-wrap items-center gap-2 border-b border-white/10 bg-black/25 px-4 py-2.5 backdrop-blur">
        {editandoNome ? (
          <input autoFocus value={nomeQuadro}
            onChange={e => setNomeQuadro(e.target.value)}
            onFocus={e => e.currentTarget.select()}
            onBlur={() => { setEditandoNome(false); if (nomeQuadro.trim()) mudarQuadro({ nome: nomeQuadro.trim() }) }}
            onKeyDown={e => { if (e.key === "Enter") e.currentTarget.blur(); if (e.key === "Escape") setEditandoNome(false) }}
            className="rounded border-2 border-sky-500 bg-black/40 px-2 py-1 text-[17px] font-bold text-white outline-none" />
        ) : (
          <button type="button"
            onClick={() => { setNomeQuadro(quadro?.nome ?? ""); setEditandoNome(true) }}
            className="rounded px-2 py-1 text-[17px] font-bold text-white hover:bg-white/10">
            {quadro?.nome ?? "Quadro"}
          </button>
        )}

        <button type="button" onClick={() => mudarQuadro({ favorito: !quadro?.favorito })}
          title={quadro?.favorito ? "Remover dos favoritos" : "Marcar com estrela"}
          className="rounded p-1.5 text-white/70 hover:bg-white/10">
          <Star className={`h-4 w-4 ${quadro?.favorito ? "fill-amber-400 text-amber-400" : ""}`} />
        </button>

        <div className="ml-auto flex items-center gap-1.5">
          <button type="button" onClick={() => setPainel(p => p === "filtro" ? "" : "filtro")}
            className={`inline-flex items-center gap-1.5 rounded px-2.5 py-1.5 text-[13px] ${
              filtrosAtivos ? "bg-sky-500 text-white" : "text-white/80 hover:bg-white/10"
            }`}>
            <Filter className="h-3.5 w-3.5" /> Filtro
            {filtrosAtivos > 0 && <span className="rounded-full bg-black/30 px-1.5 text-[11px]">{filtrosAtivos}</span>}
          </button>
          <button type="button" onClick={() => setPainel(p => p === "menu" ? "" : "menu")}
            className="rounded p-1.5 text-white/80 hover:bg-white/10" title="Menu do quadro">
            <LayoutGrid className="h-4 w-4" />
          </button>
        </div>
      </header>

      <div className="relative flex min-h-0 flex-1">
        {/* Listas */}
        <DndContext sensors={sensores} collisionDetection={pointerWithin}
          onDragStart={aoIniciar} onDragEnd={aoSoltar}>
          <div className="flex min-h-0 flex-1 gap-3 overflow-x-auto p-3">
            {carregando ? (
              <p className="p-6 text-sm text-white/60">Carregando...</p>
            ) : (
              <>
                {colunas.map(c => (
                  <Lista key={c.id} coluna={c} tarefas={daColuna(c.id)}
                    aoMudar={dados => mudarColuna(c.id, dados)}
                    aoApagar={() => apagarColuna(c.id)}
                    aoCriarTarefa={titulo => criarTarefa(c.id, titulo)}
                    aoAbrirTarefa={() => {}}
                    aoExcluirTarefa={t => setExcluir(t)} />
                ))}

                <div className="w-[272px] shrink-0">
                  {novaLista ? (
                    <div className="rounded-xl bg-[#101204] p-2">
                      <input autoFocus value={nomeLista}
                        onChange={e => setNomeLista(e.target.value)}
                        onKeyDown={e => {
                          if (e.key === "Enter") criarLista()
                          if (e.key === "Escape") { setNovaLista(false); setNomeLista("") }
                        }}
                        placeholder="Insira o nome da lista..."
                        className="w-full rounded-lg border-2 border-sky-500 bg-[#22272b] px-3 py-2 text-[13px] text-white outline-none placeholder:text-white/40" />
                      <div className="mt-2 flex items-center gap-2">
                        <button type="button" onClick={criarLista}
                          className="rounded bg-sky-500 px-3 py-1.5 text-[13px] font-semibold text-white hover:bg-sky-400">
                          Adicionar lista
                        </button>
                        <button type="button" onClick={() => { setNovaLista(false); setNomeLista("") }}
                          className="rounded p-1.5 text-white/60 hover:bg-white/10 hover:text-white">
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button type="button" onClick={() => setNovaLista(true)}
                      className="flex w-full items-center gap-2 rounded-xl bg-white/10 px-3 py-2.5 text-[13px] font-medium text-white/90 backdrop-blur hover:bg-white/20">
                      <Plus className="h-4 w-4" /> Adicionar outra lista
                    </button>
                  )}
                </div>
              </>
            )}
          </div>

          {/* O cartão arrastado sob o cursor. Sem o overlay, o dnd-kit tira o
              elemento do fluxo e ele some atrás da lista. */}
          <DragOverlay dropAnimation={null}>
            {arrastando && (
              <div className="w-[248px] rotate-3 opacity-95">
                <Cartao tarefa={arrastando} aoAbrir={() => {}} />
              </div>
            )}
          </DragOverlay>
        </DndContext>

        {/* Painel lateral: filtro ou menu, como no Trello */}
        {painel === "filtro" && (
          <aside className="w-[330px] shrink-0 overflow-y-auto border-l border-white/10 bg-[#282e33] p-4">
            <div className="relative mb-4 flex items-center justify-center">
              <p className="text-[15px] font-semibold text-white">Filtro</p>
              <button type="button" onClick={() => setPainel("")}
                className="absolute right-0 text-white/60 hover:text-white"><X className="h-4 w-4" /></button>
            </div>

            <p className="mb-1.5 text-[12px] font-semibold text-white/80">Palavra-chave</p>
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-white/40" />
              <input value={busca} onChange={e => setBusca(e.target.value)}
                placeholder="Insira uma palavra-chave..."
                className="w-full rounded border border-white/20 bg-[#22272b] py-2 pl-9 pr-3 text-[13px] text-white outline-none placeholder:text-white/40 focus:border-sky-500" />
            </div>
            <p className="mb-4 mt-1.5 text-[11px] text-white/50">Pesquise por título, responsável ou obra.</p>

            <p className="mb-1.5 text-[12px] font-semibold text-white/80">Membros</p>
            <Caixa marcada={semResponsavel} aoMudar={setSemResponsavel} rotulo="Sem responsável" />
            <Caixa marcada={soMinhas} aoMudar={setSoMinhas} rotulo="Cartões atribuídos a mim" />

            <p className="mb-1.5 mt-4 text-[12px] font-semibold text-white/80">Situação</p>
            <Caixa marcada={status === "concluidas"} rotulo="Marcado como concluído"
              aoMudar={v => setStatus(v ? "concluidas" : "")} />
            <Caixa marcada={status === "abertas"} rotulo="Não marcado como concluído"
              aoMudar={v => setStatus(v ? "abertas" : "")} />

            <p className="mb-1.5 mt-4 text-[12px] font-semibold text-white/80">Data de entrega</p>
            <Caixa marcada={prazo === "sem-data"} rotulo="Sem datas" aoMudar={v => setPrazo(v ? "sem-data" : "")} />
            <Caixa marcada={prazo === "atrasadas"} rotulo="Atrasado" aoMudar={v => setPrazo(v ? "atrasadas" : "")} />
            <Caixa marcada={prazo === "semana"} rotulo="Entrega em uma semana" aoMudar={v => setPrazo(v ? "semana" : "")} />

            {filtrosAtivos > 0 && (
              <button type="button"
                onClick={() => { setBusca(""); setSoMinhas(false); setSemResponsavel(false); setStatus(""); setPrazo("") }}
                className="mt-4 w-full rounded border border-white/20 py-2 text-[13px] text-white/80 hover:bg-white/10">
                Limpar todos os filtros
              </button>
            )}
          </aside>
        )}

        {painel === "menu" && (
          <aside className="w-[330px] shrink-0 overflow-y-auto border-l border-white/10 bg-[#282e33] p-4">
            <div className="relative mb-4 flex items-center justify-center">
              <p className="text-[15px] font-semibold text-white">Menu</p>
              <button type="button" onClick={() => setPainel("")}
                className="absolute right-0 text-white/60 hover:text-white"><X className="h-4 w-4" /></button>
            </div>

            <p className="mb-2 text-[12px] font-semibold text-white/80">Alterar tela de fundo</p>
            <div className="grid grid-cols-3 gap-2">
              {FUNDOS.map(f => (
                <button key={f.id} type="button" onClick={() => mudarQuadro({ fundo: f.id })}
                  className={`h-14 rounded-lg bg-gradient-to-br ${f.classe} ${
                    (quadro?.fundo ?? "grafite") === f.id ? "ring-2 ring-sky-400" : "ring-1 ring-white/10"
                  }`} title={f.nome} />
              ))}
            </div>

            <div className="mt-5 border-t border-white/10 pt-3">
              <button type="button" onClick={arquivarQuadro}
                className="flex w-full items-center gap-2 rounded px-2 py-2 text-left text-[13px] text-white/80 hover:bg-white/10">
                <Archive className="h-4 w-4" /> Arquivar este quadro
              </button>
            </div>
          </aside>
        )}
      </div>

      {/* Confirmação de exclusão. O texto repete o título do cartão: "tem
          certeza?" sem dizer de quê é o caminho para apagar o errado. */}
      {excluir && (
        <div className="fixed inset-0 z-[60] grid place-items-center bg-black/60 p-4"
          onClick={() => setExcluir(null)}>
          <div onClick={e => e.stopPropagation()}
            className="w-full max-w-sm rounded-xl border border-white/10 bg-[#282e33] p-5 shadow-2xl">
            <p className="text-[15px] font-semibold text-white">Excluir cartão</p>
            <p className="mt-2 text-[13px] leading-relaxed text-white/70">
              &ldquo;{excluir.titulo}&rdquo; será apagado. Não há como desfazer.
            </p>
            <div className="mt-4 flex justify-end gap-2">
              <button type="button" onClick={() => setExcluir(null)}
                className="rounded px-3 py-1.5 text-[13px] text-white/80 hover:bg-white/10">
                Cancelar
              </button>
              <button type="button" onClick={excluirTarefa}
                className="rounded bg-red-500 px-3 py-1.5 text-[13px] font-semibold text-white hover:bg-red-400">
                Excluir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Barra de quadros, embaixo, como no Trello */}
      <BarraQuadros
        quadros={quadros} atual={quadroId} aberta={painel === "quadros"}
        aoAbrir={() => setPainel(p => p === "quadros" ? "" : "quadros")}
        aoTrocar={id => { setQuadroId(id); setPainel(""); setCarregando(true) }}
        aoCriar={criarQuadro}
      />
    </div>
  )
}

function Caixa({ marcada, rotulo, aoMudar }: {
  marcada: boolean; rotulo: string; aoMudar: (v: boolean) => void
}) {
  return (
    <label className="flex cursor-pointer items-center gap-2.5 rounded px-1 py-1.5 hover:bg-white/5">
      <input type="checkbox" checked={marcada} onChange={e => aoMudar(e.target.checked)}
        className="h-4 w-4 accent-sky-500" />
      <span className="text-[13px] text-white/85">{rotulo}</span>
    </label>
  )
}

function BarraQuadros({ quadros, atual, aberta, aoAbrir, aoTrocar, aoCriar }: {
  quadros: Quadro[]; atual: string | null; aberta: boolean
  aoAbrir: () => void; aoTrocar: (id: string) => void; aoCriar: () => void
}) {
  const ref = useRef<HTMLDivElement>(null)

  return (
    <div className="relative shrink-0 border-t border-white/10 bg-black/40 px-3 py-2 backdrop-blur">
      {aberta && (
        <div ref={ref}
          className="absolute bottom-full left-3 mb-2 w-80 rounded-xl border border-white/10 bg-[#282e33] p-2 shadow-2xl">
          <p className="px-2 py-1.5 text-[12px] font-semibold text-white/60">Seus quadros</p>
          {quadros.map(q => (
            <button key={q.id} type="button" onClick={() => aoTrocar(q.id)}
              className={`flex w-full items-center gap-2 rounded px-2 py-2 text-left text-[13px] ${
                q.id === atual ? "bg-sky-500/20 text-white" : "text-white/80 hover:bg-white/10"
              }`}>
              <span className={`h-6 w-8 rounded bg-gradient-to-br ${fundoQuadro(q.fundo).classe}`} />
              <span className="min-w-0 flex-1 truncate">{q.nome}</span>
              {q.favorito && <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />}
            </button>
          ))}
          <button type="button" onClick={aoCriar}
            className="mt-1 flex w-full items-center gap-2 rounded border-t border-white/10 px-2 py-2 pt-3 text-left text-[13px] text-white/80 hover:bg-white/10">
            <Plus className="h-4 w-4" /> Criar quadro
          </button>
        </div>
      )}

      <button type="button" onClick={aoAbrir}
        className="inline-flex items-center gap-2 rounded px-2.5 py-1.5 text-[13px] font-medium text-white/85 hover:bg-white/10">
        <LayoutGrid className="h-4 w-4" /> Mudar de quadros
        <ChevronDown className={`h-3.5 w-3.5 transition-transform ${aberta ? "rotate-180" : ""}`} />
      </button>
    </div>
  )
}
