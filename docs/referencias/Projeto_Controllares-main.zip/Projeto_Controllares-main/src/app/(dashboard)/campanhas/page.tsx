"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Megaphone, CalendarClock, Percent, Archive, Tag, Plus, Trash2, RefreshCw } from "lucide-react"
import { CabecalhoPagina } from "@/components/ui/cabecalho-pagina"
import { CartaoMetrica, FaixaMetricas } from "@/components/ui/cartao-metrica"
import { BarraFiltros } from "@/components/ui/barra-filtros"
import { Bloco, LinhaProgresso } from "@/components/ui/bloco-lista"
import { useConfirmar } from "@/components/confirmar"
import { useMemoriaDeFiltro } from "@/hooks/usar-memoria-filtro"
import { brl } from "@/lib/formato"

const fmtData = (s: string) => new Date(s).toLocaleDateString("pt-BR")

interface Campanha {
  id: string; nome: string; inicio: string; fim: string
  tipo: "PERCENTUAL" | "VALOR"; valor: number; ativo: boolean
  produtoIds: string[]; categoriaIds: string[]; kitIds: string[]
}
interface Categoria { id: string; nome: string }

export default function CampanhasPage() {
  const confirmar = useConfirmar()
  const [campanhas, setCampanhas] = useState<Campanha[]>([])
  const [cats, setCats] = useState<Categoria[]>([])
  const [loading, setLoading] = useState(true)
  const [busca, setBusca] = useMemoriaDeFiltro("campanhas:busca", "")
  const [aba, setAba] = useMemoriaDeFiltro<"TODAS" | "VIGENTES" | "AGENDADAS" | "ENCERRADAS">("campanhas:aba", "TODAS")
  const [open, setOpen] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    nome: "", inicio: "", fim: "", tipo: "PERCENTUAL" as "PERCENTUAL" | "VALOR",
    valor: "", categoriaIds: [] as string[],
  })

  async function load() {
    setLoading(true)
    const [c, cat] = await Promise.all([
      fetch("/api/campanhas").then(r => r.json()).catch(() => ({ campanhas: [] })),
      fetch("/api/categorias").then(r => r.json()).catch(() => ({ categories: [] })),
    ])
    setCampanhas(c.campanhas || [])
    setCats((cat.categories || []).map((x: Categoria) => ({ id: x.id, nome: x.nome })))
    setLoading(false)
  }
  useEffect(() => { load() }, [])

  function novo() {
    setEditId(null)
    setForm({ nome: "", inicio: "", fim: "", tipo: "PERCENTUAL", valor: "", categoriaIds: [] })
    setOpen(true)
  }

  function editar(c: Campanha) {
    setEditId(c.id)
    setForm({
      nome: c.nome,
      inicio: c.inicio.slice(0, 10),
      fim: c.fim.slice(0, 10),
      tipo: c.tipo,
      valor: String(c.valor),
      categoriaIds: c.categoriaIds ?? [],
    })
    setOpen(true)
  }

  async function salvar() {
    setSaving(true)
    try {
      const res = await fetch(editId ? `/api/campanhas/${editId}` : "/api/campanhas", {
        method: editId ? "PATCH" : "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, valor: Number(form.valor) || 0 }),
      })
      if (res.ok) { setOpen(false); await load() }
      else { const e = await res.json().catch(() => ({})); await confirmar({ titulo: e?.error || "Falha ao salvar.", apenasAviso: true }) }
    } finally { setSaving(false) }
  }

  async function toggleAtivo(c: Campanha) {
    await fetch(`/api/campanhas/${c.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ativo: !c.ativo }),
    })
    await load()
  }
  async function excluir(c: Campanha) {
    if (!await confirmar({ titulo: `Excluir a campanha "${c.nome}"?`, perigo: true })) return
    await fetch(`/api/campanhas/${c.id}`, { method: "DELETE" })
    await load()
  }

  const agora = Date.now()
  const vigente = (c: Campanha) => c.ativo && new Date(c.inicio).getTime() <= agora && new Date(c.fim).getTime() >= agora

  const vigentes = campanhas.filter(vigente)
  const agendadas = campanhas.filter(c => c.ativo && !vigente(c))
  const encerradas = campanhas.filter(c => !c.ativo)

  /* Busca e filtro se somam: escolher "Vigentes" e digitar estreitam a mesma
     lista. Sem os dois, achar uma campanha antiga exigia rolar tudo. */
  const visiveis = campanhas.filter(c => {
    const termo = busca.trim().toLowerCase()
    if (termo && !c.nome.toLowerCase().includes(termo)) return false
    if (aba === "VIGENTES") return vigente(c)
    if (aba === "AGENDADAS") return c.ativo && !vigente(c)
    if (aba === "ENCERRADAS") return !c.ativo
    return true
  })

  return (
    <div className="mx-auto max-w-[1560px] space-y-3 p-4 sm:space-y-4 sm:p-6">
      <CabecalhoPagina
        icone={Megaphone}
        titulo="Campanhas"
        contexto={`${vigentes.length} vigente${vigentes.length === 1 ? "" : "s"} agora`}
        acao={
          <Button onClick={novo} size="sm" className="h-9 shrink-0 gap-1.5">
            <Plus className="h-4 w-4" /> Nova campanha
          </Button>
        }
      />

      <FaixaMetricas>
        <CartaoMetrica icone={Tag} rotulo="Vigentes" valor={vigentes.length} nota="Descontando agora" />
        <CartaoMetrica icone={CalendarClock} rotulo="Agendadas" valor={agendadas.length} nota="Ainda não começaram" />
        <CartaoMetrica icone={Percent} rotulo="Maior desconto"
          valor={vigentes.length
            ? (() => {
                const m = vigentes.reduce((a, b) => (a.tipo === "PERCENTUAL" ? a.valor : 0) >= (b.tipo === "PERCENTUAL" ? b.valor : 0) ? a : b)
                return m.tipo === "PERCENTUAL" ? `${m.valor}%` : brl(m.valor)
              })()
            : "—"}
          nota="Entre as vigentes" />
        <CartaoMetrica icone={Archive} rotulo="Inativas" valor={encerradas.length} nota="Fora do ar" />
      </FaixaMetricas>

      <BarraFiltros
        busca={busca}
        aoBuscar={setBusca}
        placeholder="Buscar campanha..."
        valor={aba}
        aoTrocar={setAba}
        opcoes={[
          { valor: "TODAS", rotulo: "Todas" },
          { valor: "VIGENTES", rotulo: "Vigentes" },
          { valor: "AGENDADAS", rotulo: "Agendadas" },
          { valor: "ENCERRADAS", rotulo: "Encerradas" },
        ] as const}
      />

      {loading ? (
        <p className="text-muted-foreground text-sm">Carregando...</p>
      ) : visiveis.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
          {campanhas.length ? "Nenhuma campanha com esse filtro." : "Nenhuma campanha cadastrada."}
        </div>
      ) : (
        /* "Desempenho" com barra: a pergunta de toda campanha é quanto da
           vigência já passou, e a barra responde antes de ler as datas. */
        <Bloco titulo="Desempenho">
          <div className="space-y-2">
            {visiveis.map(c => {
              const ini = new Date(c.inicio).getTime()
              const fim = new Date(c.fim).getTime()
              const decorrido = fim > ini ? ((agora - ini) / (fim - ini)) * 100 : 0
              return (
                <LinhaProgresso
                  key={c.id}
                  titulo={c.nome}
                  contexto={`${fmtData(c.inicio)} a ${fmtData(c.fim)} · ${
                    c.categoriaIds.length > 0 ? `${c.categoriaIds.length} categoria(s)` : "todas as categorias"
                  }${c.produtoIds.length > 0 ? ` · ${c.produtoIds.length} produto(s)` : ""}`}
                  destaque={c.tipo === "PERCENTUAL" ? `${c.valor}%` : brl(c.valor)}
                  etiqueta={vigente(c) ? "Vigente" : c.ativo ? "Agendada" : "Inativa"}
                  progresso={c.ativo ? decorrido : undefined}
                  acoes={
                    <>
                      <button onClick={() => editar(c)}
                        className="h-7 rounded-full px-2.5 text-[11px] font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground">
                        Editar
                      </button>
                      <button onClick={() => toggleAtivo(c)}
                        className="h-7 rounded-full px-2.5 text-[11px] font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground">
                        {c.ativo ? "Desativar" : "Ativar"}
                      </button>
                      <button onClick={() => excluir(c)} title="Excluir"
                        className="flex h-7 w-7 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted hover:text-ios-red">
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </>
                  }
                />
              )
            })}
          </div>
        </Bloco>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editId ? "Editar campanha" : "Nova campanha"}</DialogTitle></DialogHeader>
          <div className="space-y-4 px-5 sm:px-6 py-4">
            <div className="space-y-1.5">
              <Label className="text-foreground/80">Nome *</Label>
              <Input value={form.nome} onChange={e => setForm(f => ({ ...f, nome: e.target.value }))}
                placeholder="Ex: Black Friday" className="bg-muted border-border text-foreground" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-foreground/80">Início *</Label>
                <Input type="date" value={form.inicio} onChange={e => setForm(f => ({ ...f, inicio: e.target.value }))} className="bg-muted border-border text-foreground" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-foreground/80">Fim *</Label>
                <Input type="date" value={form.fim} onChange={e => setForm(f => ({ ...f, fim: e.target.value }))} className="bg-muted border-border text-foreground" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-foreground/80">Tipo</Label>
                <select value={form.tipo} onChange={e => setForm(f => ({ ...f, tipo: e.target.value as "PERCENTUAL" | "VALOR" }))}
                  className="w-full h-10 px-3 rounded-xl bg-muted border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary">
                  <option value="PERCENTUAL">Percentual (%)</option>
                  <option value="VALOR">Valor fixo (R$)</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-foreground/80">{form.tipo === "PERCENTUAL" ? "Desconto (%)" : "Desconto (R$)"}</Label>
                <Input type="number" min="0" step="0.01" value={form.valor}
                  onChange={e => setForm(f => ({ ...f, valor: e.target.value }))} placeholder="0" className="bg-muted border-border text-foreground" />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-foreground/80">Categorias elegíveis *</Label>
              <select value="" onChange={e => {
                const v = e.target.value
                if (!v) return
                if (v === "__todas__") setForm(f => ({ ...f, categoriaIds: cats.map(c => c.id) }))
                else setForm(f => f.categoriaIds.includes(v) ? f : { ...f, categoriaIds: [...f.categoriaIds, v] })
              }} className="w-full h-10 px-3 rounded-xl bg-muted border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary">
                <option value="">Adicionar categoria…</option>
                <option value="__todas__">Todas as categorias</option>
                {cats.filter(c => !form.categoriaIds.includes(c.id)).map(c => (
                  <option key={c.id} value={c.id}>{c.nome}</option>
                ))}
              </select>
              {form.categoriaIds.length > 0 && (
                <div className="flex flex-wrap gap-2 pt-1">
                  {form.categoriaIds.map(id => {
                    const nome = cats.find(c => c.id === id)?.nome ?? id
                    return (
                      <span key={id} className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs bg-foreground text-background">
                        {nome}
                        <button type="button" onClick={() => setForm(f => ({ ...f, categoriaIds: f.categoriaIds.filter(x => x !== id) }))}>×</button>
                      </span>
                    )
                  })}
                </div>
              )}
              <p className="text-[11px] text-muted-foreground/60">Escolha ao menos uma. O desconto vale só para itens dessas categorias e não acumula com outras campanhas.</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
            <Button onClick={salvar} disabled={saving || !form.nome.trim() || !form.inicio || !form.fim || !form.valor || form.categoriaIds.length === 0}>
              {saving ? <><RefreshCw className="w-4 h-4 animate-spin" /> Salvando...</> : editId ? "Salvar alterações" : "Criar campanha"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
