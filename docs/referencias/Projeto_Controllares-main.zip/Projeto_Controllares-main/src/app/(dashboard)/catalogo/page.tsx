﻿"use client"

import { PageLoader } from "@/components/ui/bouncing-dots"
import { useState, useEffect, useCallback, useRef } from "react"
import { CheckCircle2, Package, Search, Plus, Pencil, ImageOff, Eye, EyeOff, RefreshCw, Trash2, Building2, Upload, Download, X, ChevronDown, ArrowUpDown } from "lucide-react"
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell
} from "@/components/ui/table"
import { Switch } from "@/components/ui/switch"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { EmptyState } from "@/components/ui/empty-state"
import { showToast } from "@/components/ui/toast"
import { proxiedImg } from "@/lib/img"
import { CabecalhoPagina } from "@/components/ui/cabecalho-pagina"
import { CartaoMetrica, FaixaMetricas } from "@/components/ui/cartao-metrica"
import { useConfirmar } from "@/components/confirmar"
import { useMemoriaDeFiltro } from "@/hooks/usar-memoria-filtro"
import { brl } from "@/lib/formato"
import { CampoMascarado } from "@/components/ui/campo-mascarado"


// Tipos de aplicação prontos; qualquer outro valor vira "Outro (digitar)".
const TIPOS_APLICACAO = ["Teto", "Marcenaria", "Rack", "Quadro de automação", "Área externa"]

/* mm do banco -> cm da tela, sem sujeira de ponto flutuante (257,18 / 10 dava
   25,717999…). 4 casas cobrem qualquer medida gravada com até 0,001 mm. */
const mmParaCm = (mm: number) => String(Number((mm / 10).toFixed(4)))

// Status simples: Inativo só quando o GERAL está desativado.
// "Inativo p/ proposta" não muda o status — só some da busca de propostas
// (os switches Proposta/Geral já mostram o detalhe).
function nivelStatus(p: { status: string; inativo_proposta?: boolean }): { label: string; variant: "success" | "secondary" | "warning" } {
  if (p.status === "INATIVO") return { label: "Inativo", variant: "secondary" }
  return { label: "Ativo", variant: "success" }
}

interface Product {
  id: string
  sku: string
  nome: string
  nome_cliente: string | null
  marca: string | null
  preco_custo: number
  markup_padrao: number
  preco_venda: number
  imposto_st: number
  status: "ATIVO" | "INATIVO"
  inativo_proposta: boolean
  ncm: string | null
  cest: string | null
  origem: string | null
  unidade: string | null
  gtin: string | null
  aliquota_ipi: number | null
  cst_pis: string | null
  aliquota_pis: number | null
  cst_cofins: string | null
  aliquota_cofins: number | null
  cst_icms: string | null
  aliquota_icms: number | null
  imagem_url: string | null
  supplierId: string | null
  estoque_qtd?: number | null
  estoque_minimo?: number | null
  tipo_aplicacao?: string | null
  formato_medida?: string | null
  largura_mm?: number | null
  altura_mm?: number | null
  profundidade_mm?: number | null
  garantia_meses?: number | null
  garantia_dias?: number | null
  especificacoes?: string | null
  supplier?: { id: string; nome: string } | null
  category?: { id: string; nome: string } | null
}

interface Supplier {
  id: string
  nome: string
  prefixo: string
  _count?: { products: number }
}

interface FormState {
  sku: string
  nome: string
  nome_cliente: string
  marca: string
  preco_custo: string
  markup_padrao: string
  preco_venda: string
  imposto_st: string
  status: string
  inativo_proposta: boolean
  ncm: string
  cest: string
  origem: string
  unidade: string
  gtin: string
  aliquota_ipi: string
  cst_pis: string
  aliquota_pis: string
  cst_cofins: string
  aliquota_cofins: string
  cst_icms: string
  aliquota_icms: string
  imagem_url: string
  supplierId: string
  estoque_qtd: string
  estoque_minimo: string
  tipo_aplicacao: string
  formato_medida: string
  largura_mm: string // exibido em cm
  altura_mm: string  // exibido em cm
  profundidade_mm: string // exibido em cm
  garantia_dias: string
  especificacoes: string
}

const emptyForm: FormState = {
  sku: "", nome: "", nome_cliente: "", marca: "", preco_custo: "", markup_padrao: "", preco_venda: "", imposto_st: "0", status: "ATIVO", inativo_proposta: false, ncm: "", cest: "", origem: "", unidade: "", gtin: "", aliquota_ipi: "", cst_pis: "", aliquota_pis: "", cst_cofins: "", aliquota_cofins: "", cst_icms: "", aliquota_icms: "", imagem_url: "", supplierId: "", estoque_qtd: "", estoque_minimo: "", tipo_aplicacao: "", formato_medida: "", largura_mm: "", altura_mm: "", profundidade_mm: "", garantia_dias: "", especificacoes: ""
}

// ---- Parser de CSV simples (lida com aspas, vírgula e ponto-e-vírgula) ----
function parseCSV(texto: string): Record<string, string>[] {
  const linhas = texto.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n").filter(l => l.trim())
  if (linhas.length < 2) return []
  const sep = (linhas[0].match(/;/g)?.length ?? 0) > (linhas[0].match(/,/g)?.length ?? 0) ? ";" : ","

  function splitLinha(linha: string): string[] {
    const out: string[] = []
    let cur = "", aspas = false
    for (let i = 0; i < linha.length; i++) {
      const c = linha[i]
      if (c === '"') { if (aspas && linha[i + 1] === '"') { cur += '"'; i++ } else aspas = !aspas }
      else if (c === sep && !aspas) { out.push(cur); cur = "" }
      else cur += c
    }
    out.push(cur)
    return out.map(s => s.trim())
  }

  const headers = splitLinha(linhas[0]).map(h => h.toLowerCase().replace(/[^a-z_]/g, ""))
  return linhas.slice(1).map(linha => {
    const valores = splitLinha(linha)
    const obj: Record<string, string> = {}
    headers.forEach((h, i) => { obj[h] = valores[i] ?? "" })
    return obj
  })
}

/* Mapeia cabeçalhos variados para os campos do produto.
   Cobria só 7 campos (sku/nome/marca/custo/markup/venda/imagem) — o resto do
   modelo baixado (peso, dimensão, ficha, fiscal, estoque...) chegava até
   aqui e morria calado: a API aceita tudo isso, mas se não sai daqui não tem
   como chegar lá. Quem preenchia o modelo inteiro do fornecedor via só nome
   e preço entrarem, o resto sumindo sem aviso nenhum. */
function mapearLinha(row: Record<string, string>) {
  const get = (...chaves: string[]) => { for (const k of chaves) if (row[k]) return row[k]; return "" }
  // Fallback: qualquer coluna cujo VALOR seja uma URL http(s) vira imagem,
  // independente do nome do cabeçalho no CSV.
  const urlPorValor = Object.values(row).find(v => /^https?:\/\/\S+/i.test((v ?? "").trim())) ?? ""
  return {
    nome: get("nome", "produto", "descricao", "descrio", "name"),
    marca: get("marca", "brand", "fabricante"),
    preco_custo: get("preco_custo", "precocusto", "custo", "cost", "preo_custo", "preocusto"),
    markup_padrao: get("markup_padrao", "markup", "margem"),
    preco_venda: get("preco_venda", "precovenda", "venda", "preco", "preo_venda", "preovenda", "valor"),
    imagem_url: get("imagem_url", "imagemurl", "imagem", "imagemproduto", "urlimagem", "imagem_produto", "url_imagem", "image", "imageurl", "img", "imgurl", "foto", "fotourl", "foto_url", "link", "linkimagem", "url") || urlPorValor.trim(),
    sku: get("sku", "codigo", "cdigo", "code"),
    // A partir daqui, o cabeçalho do CSV já normalizado (minúsculo, só
    // a-z e "_") bate exatamente com o nome da coluna do modelo — sem
    // apelido porque não tem ambiguidade de nome como custo/venda têm.
    nome_cliente: get("nome_cliente", "nomecliente"),
    unidade: get("unidade", "un"),
    categoria: get("categoria"),
    descricao: get("descricao", "descrio"),
    especificacoes: get("especificacoes", "ficha_tecnica", "fichatecnica", "ficha"),
    imposto_st: get("imposto_st", "impostost", "credito_st", "creditost"),
    desconto_padrao: get("desconto_padrao", "descontopadrao", "desconto"),
    ncm: get("ncm"),
    cest: get("cest"),
    origem: get("origem"),
    gtin: get("gtin", "ean", "codigo_barras", "codigobarras"),
    cst_icms: get("cst_icms", "csticms"),
    aliquota_icms: get("aliquota_icms", "aliquotaicms"),
    aliquota_ipi: get("aliquota_ipi", "aliquotaipi"),
    cst_pis: get("cst_pis", "cstpis"),
    aliquota_pis: get("aliquota_pis", "aliquotapis"),
    cst_cofins: get("cst_cofins", "cstcofins"),
    aliquota_cofins: get("aliquota_cofins", "aliquotacofins"),
    // Peso e dimensão: o motivo direto do pedido — vinham no modelo, iam
    // pro lixo antes de chegar na API.
    peso_kg: get("peso_kg", "pesokg", "peso"),
    largura_mm: get("largura_mm", "larguramm", "largura"),
    altura_mm: get("altura_mm", "alturamm", "altura"),
    profundidade_mm: get("profundidade_mm", "profundidademm", "profundidade"),
    medidas_raw: get("medidas_raw", "medidasraw", "medidas", "dimensoes", "dimensao"),
    ficha_fonte_url: get("ficha_fonte_url", "fichafonteurl", "fonte_ficha", "fontedaficha"),
    tipo_aplicacao: get("tipo_aplicacao", "tipoaplicacao"),
    formato_medida: get("formato_medida", "formatomedida"),
    garantia_dias: get("garantia_dias", "garantiadias", "garantia"),
    estoque_qtd: get("estoque_qtd", "estoqueqtd", "estoque", "quantidade"),
    estoque_minimo: get("estoque_minimo", "estoqueminimo"),
  }
}

// Preview de imagem com feedback de carregamento/erro (via proxy do servidor)
function ImagePreview({ url }: { url: string }) {
  const [status, setStatus] = useState<"loading" | "ok" | "error">("loading")
  const [motivo, setMotivo] = useState("")

  useEffect(() => { setStatus(url ? "loading" : "error"); setMotivo("") }, [url])

  /* Quando falha, pergunta ao proxy o que aconteceu. "Verifique se e a URL
     direta" e chute: o caso comum e o arquivo ter sido removido do servidor
     (404), e sem o motivo real a pessoa fica conferindo uma URL que esta
     escrita corretamente. */
  async function descobrirMotivo() {
    setStatus("error")
    try {
      const r = await fetch(proxiedImg(url))
      if (r.status === 404) { setMotivo("Imagem nao existe mais nesse endereco (404)."); return }
      const j = await r.json().catch(() => null)
      setMotivo(j?.error || `A origem respondeu ${r.status}.`)
    } catch {
      setMotivo("Nao foi possivel acessar o endereco.")
    }
  }

  if (!url) {
    return (
      <div className="w-14 h-14 rounded-2xl bg-muted border border-border flex items-center justify-center flex-shrink-0">
        <ImageOff className="w-5 h-5 text-muted-foreground/50" />
      </div>
    )
  }

  return (
    <div className="flex items-center gap-2 flex-shrink-0">
      <div className="relative w-14 h-14 rounded-2xl border border-border bg-muted overflow-hidden flex items-center justify-center">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={proxiedImg(url)}
          alt="preview"
          className={`w-full h-full object-cover ${status === "ok" ? "" : "opacity-0"}`}
          onLoad={() => setStatus("ok")}
          onError={descobrirMotivo}
        />
        {status === "loading" && <RefreshCw className="w-4 h-4 text-muted-foreground/60 animate-spin absolute" />}
        {status === "error" && <ImageOff className="w-5 h-5 text-red-400/70 absolute" />}
      </div>
      {status === "error" && (
        <span className="max-w-[200px] text-xs leading-tight text-red-400">
          {motivo || "Não carregou."}
        </span>
      )}
      {status === "ok" && <span className="text-green-400 text-xs">Imagem válida</span>}
    </div>
  )
}

// Campo de imagem: alterna entre colar URL ou anexar arquivo, com preview
function ImageUrlOrUploadField({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [mode, setMode] = useState<"url" | "file">("url")
  const [uploading, setUploading] = useState(false)
  const [uploadError, setUploadError] = useState("")

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setUploadError("")
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append("file", file)
      const res = await fetch("/api/upload", { method: "POST", body: fd })
      const data = await res.json().catch(() => ({}))
      if (res.ok && data.url) {
        onChange(data.url)
      } else {
        setUploadError(data.error || "Falha no upload. Tente outro arquivo.")
      }
    } catch {
      setUploadError("Falha no upload.")
    } finally {
      setUploading(false)
      e.target.value = ""
    }
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <Label className="text-foreground/80">Imagem do Produto</Label>
        <div className="flex gap-1 bg-muted rounded-xl p-0.5">
          <button type="button" onClick={() => setMode("url")}
            className={`px-2.5 py-0.5 rounded-lg text-xs transition-colors ${mode === "url" ? "bg-muted/80 text-foreground" : "text-muted-foreground/60 hover:text-foreground/80"}`}>URL</button>
          <button type="button" onClick={() => setMode("file")}
            className={`px-2.5 py-0.5 rounded-lg text-xs transition-colors ${mode === "file" ? "bg-muted/80 text-foreground" : "text-muted-foreground/60 hover:text-foreground/80"}`}>Anexar arquivo</button>
        </div>
      </div>

      <div className="flex gap-3 items-start">
        {mode === "url" ? (
          <Input value={value} onChange={e => onChange(e.target.value)}
            className="bg-muted border-border text-foreground flex-1" placeholder="https://.../imagem.jpg" />
        ) : (
          <div className="flex-1 flex items-center gap-2">
            <label className={`flex items-center gap-1.5 h-10 px-4 rounded-xl border cursor-pointer text-sm transition-colors ${uploading ? "bg-muted/80 border-border/70 text-muted-foreground" : "bg-muted border-border hover:border-primary/60 text-foreground/80 hover:text-foreground"}`}>
              {uploading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              {uploading ? "Enviando..." : "Escolher arquivo"}
              <input type="file" accept="image/*" className="hidden" disabled={uploading} onChange={handleFile} />
            </label>
            {value && !uploading && <span className="text-green-400 text-xs">Arquivo carregado</span>}
            {value && (
              <button type="button" onClick={() => onChange("")}
                className="text-muted-foreground/60 hover:text-red-400 text-xs">remover</button>
            )}
          </div>
        )}
        <ImagePreview url={value} />
      </div>

      {uploadError && <p className="text-red-400 text-xs">{uploadError}</p>}

      <p className="text-muted-foreground/50 text-xs">
        {mode === "url"
          ? <>Cole a URL <strong>direta do arquivo de imagem</strong> (.jpg/.png/.webp) — não o link da página. Botão direito na imagem → &quot;Copiar endereço da imagem&quot;.</>
          : <>Envie um arquivo do seu computador (PNG, JPG, WEBP). Forma mais garantida de exibir a imagem.</>}
      </p>
    </div>
  )
}

export default function CatalogoPage() {
  const confirmar = useConfirmar()
  const [products, setProducts] = useState<Product[]>([])
  // Filtro de disponibilidade: "" | ATIVO | INATIVO_PROPOSTA | INATIVO_GERAL
  const [filtroNivel, setFiltroNivel] = useMemoriaDeFiltro<string>("catalogo:nivel", "")

  // Ordenação por coluna (clique no cabeçalho alterna ↑/↓)
  const [sortCol, setSortCol] = useMemoriaDeFiltro<"sku" | "nome" | "marca" | "preco_venda" | "">("catalogo:ordemCol", "")
  const [sortDir, setSortDir] = useMemoriaDeFiltro<"asc" | "desc">("catalogo:ordemDir", "asc")
  function toggleSort(col: typeof sortCol) {
    if (sortCol === col) setSortDir(d => d === "asc" ? "desc" : "asc")
    else { setSortCol(col); setSortDir("asc") }
    /* Volta pro começo: a ordem muda o catálogo inteiro, e continuar na página 7
       da ordem anterior mostra um trecho do meio sem relação com o clique. */
    setPage(1)
  }
  /* A ordenação vem pronta do servidor — ordenar de novo aqui só reordenaria os
     itens desta página, que foi exatamente o defeito. */
  const productsOrdenados = products
  const [total, setTotal] = useState(0)
  const [ativos, setAtivos] = useState(0)
  const [pages, setPages] = useState(1)
  const [page, setPage] = useState(1)
  const [perPage, setPerPage] = useState(20)
  const [search, setSearch] = useMemoriaDeFiltro("catalogo:busca", "")
  const [searchInput, setSearchInput] = useMemoriaDeFiltro("catalogo:buscaDigitada", "")
  const [loading, setLoading] = useState(false)
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Product | null>(null)
  const [form, setForm] = useState<FormState>(emptyForm)
  const [saving, setSaving] = useState(false)
  const [showCusto, setShowCusto] = useState(false)
  const [skuLoading, setSkuLoading] = useState(false)
  // Produto composto (Bloco 4): componentes ocultos
  const [comps, setComps] = useState<{ componenteId: string; quantidade: number; nome: string; sku: string; preco_custo: number; inativo_proposta: boolean }[]>([])
  const [compTotal, setCompTotal] = useState(0)
  const [compBusca, setCompBusca] = useState("")
  const [compRes, setCompRes] = useState<{ id: string; nome: string; sku: string }[]>([])
  const [erroForm, setErroForm] = useState("")

  // Confirmação de exclusão moderna
  const [deleteTarget, setDeleteTarget] = useState<Product | null>(null)
  const [deleting, setDeleting] = useState(false)

  // Seleção múltipla (Gmail-style)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [bulkDeleting, setBulkDeleting] = useState(false)
  const [bulkConfirmOpen, setBulkConfirmOpen] = useState(false)

  // Inline edit (duplo clique na tabela)
  type InlineNumField = 'preco_custo' | 'markup_padrao' | 'preco_venda'
  type InlineStrField = 'nome' | 'marca' | 'sku'
  type InlineField = InlineNumField | InlineStrField
  const [inlineEdit, setInlineEdit] = useState<{ id: string; field: InlineField; value: string } | null>(null)

  async function saveInline(ie = inlineEdit) {
    if (!ie) return
    setInlineEdit(null)
    const numFields: InlineField[] = ['preco_custo', 'markup_padrao', 'preco_venda']
    const isNum = numFields.includes(ie.field)
    let payload: Record<string, string | number>
    if (isNum) {
      const num = parseFloat(ie.value.replace(',', '.'))
      if (isNaN(num) || num < 0) return
      payload = { [ie.field]: num }
      setProducts(ps => ps.map(p => p.id === ie.id ? { ...p, [ie.field]: num } : p))
    } else {
      if (!ie.value.trim()) return
      payload = { [ie.field]: ie.value.trim() }
      setProducts(ps => ps.map(p => p.id === ie.id ? { ...p, [ie.field]: ie.value.trim() } : p))
    }
    const res = await fetch(`/api/produtos/${ie.id}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })
    if (!res.ok) {
      const j = await res.json().catch(() => ({}))
      showToast(j.error || 'Falha ao salvar a alteração.', { variant: 'error' })
    }
    fetchProducts()
  }

  function InlineCell({ p, field, display, type = 'text', className, width = 'w-28' }: {
    p: Product; field: InlineField; display: string; type?: 'text' | 'number'; className?: string; width?: string
  }) {
    const active = inlineEdit?.id === p.id && inlineEdit.field === field
    if (active) return (
      <input autoFocus type={type} step={type === 'number' ? '0.01' : undefined} min={type === 'number' ? '0' : undefined}
        className={`${width} bg-muted border border-primary/40 text-foreground text-sm rounded-xl px-2 py-0.5 focus:outline-none focus:ring-1 focus:ring-primary`}
        value={inlineEdit!.value}
        onChange={e => setInlineEdit(ie => ie ? { ...ie, value: e.target.value } : ie)}
        onBlur={() => saveInline()}
        onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); saveInline() } if (e.key === 'Escape') setInlineEdit(null) }}
      />
    )
    // Duplo clique REMOVIDO: mudava dado sem querer. Edição só pelo lápis (modal).
    return <span className={className ?? ''}>{display}</span>
  }

  // Fornecedores
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [filtroSupplier, setFiltroSupplier] = useMemoriaDeFiltro<string>("catalogo:fornecedor", "")
  const [marcaMenuOpen, setMarcaMenuOpen] = useState(false)
  const [marcaBusca, setMarcaBusca] = useState("")
  const [fornOpen, setFornOpen] = useState(false)

  // Importação
  const [importOpen, setImportOpen] = useState(false)

  const fetchSuppliers = useCallback(async () => {
    const res = await fetch("/api/fornecedores")
    if (res.ok) setSuppliers((await res.json()).fornecedores || [])
  }, [])

  const fetchProducts = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch(`/api/produtos?search=${encodeURIComponent(search)}&page=${page}&limit=${perPage}${filtroSupplier ? `&supplierId=${filtroSupplier}` : ""}${filtroNivel ? `&nivel=${filtroNivel}` : ""}${sortCol ? `&sort=${sortCol}&dir=${sortDir}` : ""}`)
      if (!res.ok) { console.error("produtos API error", res.status); return }
      const text = await res.text()
      if (!text) { console.error("produtos API returned empty body"); return }
      const data = JSON.parse(text)
      setProducts(data.products || [])
      setTotal(data.total || 0)
      setAtivos(data.ativos || 0)
      setPages(data.pages || 1)
    } finally {
      setLoading(false)
    }
  }, [search, page, perPage, filtroSupplier, filtroNivel, sortCol, sortDir])

  useEffect(() => { fetchProducts() }, [fetchProducts])
  useEffect(() => { fetchSuppliers() }, [fetchSuppliers])

  // Exporta o catálogo em CSV (respeita busca/marca/disponibilidade atuais).
  const [exportando, setExportando] = useState(false)
  async function exportarCsv() {
    setExportando(true)
    try {
      const qs = new URLSearchParams({ limit: "10000", page: "1" })
      if (search) qs.set("search", search)
      if (filtroSupplier) qs.set("supplierId", filtroSupplier)
      if (filtroNivel) qs.set("nivel", filtroNivel)
      const res = await fetch(`/api/produtos?${qs}`)
      if (!res.ok) { await confirmar({ titulo: "Falha ao exportar.", apenasAviso: true }); return }
      const { products: lista } = await res.json() as { products: Product[] }

      const cab = ["SKU", "Nome", "Nome na proposta", "Marca", "Categoria", "Fornecedor",
        "Preço de custo", "Markup (%)", "Imposto ST (%)", "Preço de venda", "NCM",
        "Estoque atual", "Estoque mínimo", "Garantia (dias)", "Status", "Inativo p/ proposta"]
      // Aspas duplicadas + prefixo seguro: evita quebrar colunas e injeção de fórmula no Excel.
      const cel = (v: unknown) => {
        const s = v == null ? "" : String(v)
        return `"${(/^[=+\-@]/.test(s) ? "'" + s : s).replace(/"/g, '""')}"`
      }
      const linhas = lista.map(p => [
        p.sku, p.nome, p.nome_cliente ?? "", p.marca ?? "", p.category?.nome ?? "", p.supplier?.nome ?? "",
        Number(p.preco_custo).toFixed(2), p.markup_padrao ?? 0, p.imposto_st ?? 0,
        Number(p.preco_venda).toFixed(2), p.ncm ?? "",
        p.estoque_qtd ?? "", p.estoque_minimo ?? "", p.garantia_dias ?? "",
        p.status === "ATIVO" ? "Ativo" : "Inativo", p.inativo_proposta ? "Sim" : "Não",
      ].map(cel).join(";"))

      // BOM p/ o Excel abrir acentuação certa; ";" é o separador padrão pt-BR.
      const csv = "﻿" + [cab.map(cel).join(";"), ...linhas].join("\r\n")
      const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8;" }))
      const a = document.createElement("a")
      a.href = url
      a.download = `catalogo-${new Date().toISOString().slice(0, 10)}.csv`
      a.click()
      URL.revokeObjectURL(url)
    } finally { setExportando(false) }
  }

  // Debounce search
  useEffect(() => {
    const t = setTimeout(() => { setSearch(searchInput); setPage(1) }, 300)
    return () => clearTimeout(t)
  }, [searchInput])

  // Auto-calc preco_venda: custo * (1 + st/100) * (1 + markup/100)
  useEffect(() => {
    const custo  = parseFloat(form.preco_custo)
    const st     = parseFloat(form.imposto_st) || 0
    const markup = parseFloat(form.markup_padrao)
    if (!isNaN(custo) && !isNaN(markup)) {
      const base = custo * (1 + st / 100)
      setForm(f => ({ ...f, preco_venda: (base * (1 + markup / 100)).toFixed(2) }))
    }
  }, [form.preco_custo, form.imposto_st, form.markup_padrao])

  function openNew() {
    setEditing(null)
    setErroForm("")
    setForm({ ...emptyForm, supplierId: filtroSupplier || "" })
    setOpen(true)
    if (filtroSupplier) buscarProximoSku(filtroSupplier)
  }

  // Busca o próximo SKU automático ao escolher o fornecedor
  async function buscarProximoSku(supplierId: string) {
    if (!supplierId) return
    setSkuLoading(true)
    try {
      const res = await fetch(`/api/produtos/next-sku?supplierId=${supplierId}`)
      if (res.ok) {
        const { sku, marca } = await res.json()
        setForm(f => ({ ...f, sku, marca: f.marca || marca }))
      }
    } finally {
      setSkuLoading(false)
    }
  }

  function onSupplierChange(supplierId: string) {
    setForm(f => ({ ...f, supplierId }))
    if (supplierId && !editing) buscarProximoSku(supplierId)
  }

  function openEdit(p: Product) {
    setEditing(p)
    setErroForm("")
    // Abre avançadas se produto tiver campos preenchidos lá
    setForm({
      sku: p.sku,
      nome: p.nome,
      nome_cliente: p.nome_cliente || "",
      marca: p.marca || "",
      preco_custo: String(p.preco_custo),
      markup_padrao: String(p.markup_padrao),
      preco_venda: String(p.preco_venda),
      imposto_st: String(p.imposto_st ?? 0),
      status: p.status,
      inativo_proposta: p.inativo_proposta ?? false,
      ncm: p.ncm || "",
      cest: p.cest || "",
      origem: p.origem || "",
      unidade: p.unidade || "",
      gtin: p.gtin || "",
      aliquota_ipi: p.aliquota_ipi != null ? String(p.aliquota_ipi) : "",
      cst_pis: p.cst_pis || "",
      aliquota_pis: p.aliquota_pis != null ? String(p.aliquota_pis) : "",
      cst_cofins: p.cst_cofins || "",
      aliquota_cofins: p.aliquota_cofins != null ? String(p.aliquota_cofins) : "",
      cst_icms: p.cst_icms || "",
      aliquota_icms: p.aliquota_icms != null ? String(p.aliquota_icms) : "",
      imagem_url: p.imagem_url || "",
      supplierId: p.supplierId || "",
      estoque_qtd: p.estoque_qtd != null ? String(p.estoque_qtd) : "",
      estoque_minimo: p.estoque_minimo != null ? String(p.estoque_minimo) : "",
      tipo_aplicacao: p.tipo_aplicacao || "",
      formato_medida: p.formato_medida || "",
      largura_mm: p.largura_mm != null ? mmParaCm(p.largura_mm) : "",
      altura_mm: p.altura_mm != null ? mmParaCm(p.altura_mm) : "",
      profundidade_mm: p.profundidade_mm != null ? mmParaCm(p.profundidade_mm) : "",
      garantia_dias: p.garantia_dias != null ? String(p.garantia_dias)
        : p.garantia_meses != null ? String(p.garantia_meses * 30) : "",
      especificacoes: p.especificacoes || "",
    })
    setComps([]); setCompTotal(0); setCompBusca(""); setCompRes([])
    loadComps(p.id)
    setOpen(true)
  }

  async function loadComps(produtoId: string) {
    const r = await fetch(`/api/produtos/${produtoId}/componentes`).catch(() => null)
    if (!r?.ok) return
    const d = await r.json()
    setComps(d.componentes || [])
    setCompTotal(d.total_custo || 0)
  }
  async function addComp(componenteId: string, nome: string, sku: string) {
    if (!editing) return
    await fetch(`/api/produtos/${editing.id}/componentes`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ componenteId, quantidade: 1 }),
    })
    setCompBusca(""); setCompRes([])
    await loadComps(editing.id)
  }
  async function remComp(componenteId: string) {
    if (!editing) return
    await fetch(`/api/produtos/${editing.id}/componentes?componenteId=${componenteId}`, { method: "DELETE" })
    await loadComps(editing.id)
  }

  // busca de itens para vincular como componente (inclui inativo_proposta)
  useEffect(() => {
    if (!open || !editing || compBusca.trim().length < 2) { setCompRes([]); return }
    const t = setTimeout(async () => {
      const r = await fetch(`/api/produtos?search=${encodeURIComponent(compBusca.trim())}&limit=15`).catch(() => null)
      if (!r?.ok) { setCompRes([]); return }
      const d = await r.json()
      const arr = (d.products || []) as { id: string; nome: string; sku: string }[]
      setCompRes(arr.filter(p => p.id !== editing.id && !comps.some(c => c.componenteId === p.id)))
    }, 250)
    return () => clearTimeout(t)
  }, [compBusca, open, editing, comps])

  /* Medida: o banco guarda mm, a tela mostra cm. Dividir e multiplicar por 10 em
     ponto flutuante mexia no valor sem ninguém tocar (257,18 virava 257,17999…).
     Se o campo continua exatamente como foi carregado, volta o valor original do
     banco; se foi digitado, arredonda para 0,01 mm (3 casas em cm). */
  function cmParaMm(cm: string, original?: number | null): number | null {
    if (cm === "") return null
    if (original != null && cm === mmParaCm(original)) return original
    return Math.round(Number(cm) * 1000) / 100
  }

  async function handleSave() {
    setSaving(true)
    setErroForm("")
    try {
      const payload = {
        sku: form.sku,
        nome: form.nome,
        nome_cliente: form.nome_cliente || null,
        marca: form.marca || null,
        preco_custo: parseFloat(form.preco_custo),
        markup_padrao: parseFloat(form.markup_padrao) || 0,
        preco_venda: parseFloat(form.preco_venda),
        imposto_st: parseFloat(form.imposto_st) || 0,
        status: form.status,
        inativo_proposta: form.inativo_proposta,
        ncm: form.ncm || null,
        cest: form.cest || null,
        origem: form.origem || null,
        unidade: form.unidade || null,
        gtin: form.gtin || null,
        aliquota_ipi: form.aliquota_ipi === "" ? null : Number(form.aliquota_ipi),
        cst_pis: form.cst_pis || null,
        aliquota_pis: form.aliquota_pis === "" ? null : Number(form.aliquota_pis),
        cst_cofins: form.cst_cofins || null,
        aliquota_cofins: form.aliquota_cofins === "" ? null : Number(form.aliquota_cofins),
        cst_icms: form.cst_icms || null,
        aliquota_icms: form.aliquota_icms === "" ? null : Number(form.aliquota_icms),
        imagem_url: form.imagem_url || null,
        supplierId: form.supplierId || null,
        // estoque_qtd NÃO vai no payload: saldo só muda via módulo Estoque
        // (movimentação/inventário), que grava a trilha de auditoria.
        estoque_minimo: form.estoque_minimo === "" ? null : Number(form.estoque_minimo),
        tipo_aplicacao: form.tipo_aplicacao || null,
        formato_medida: form.formato_medida || null,
        largura_mm: cmParaMm(form.largura_mm, editing?.largura_mm),
        altura_mm: cmParaMm(form.altura_mm, editing?.altura_mm),
        profundidade_mm: cmParaMm(form.profundidade_mm, editing?.profundidade_mm),
        garantia_dias: form.garantia_dias === "" ? null : Number(form.garantia_dias),
        especificacoes: form.especificacoes || null,
      }
      const res = editing
        ? await fetch(`/api/produtos/${editing.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) })
        : await fetch("/api/produtos", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) })
      if (!res.ok) {
        const j = await res.json().catch(() => ({}))
        // 401 aqui é sessão vencida (o login vale 7 dias e a aba ficou aberta).
        // "Não autorizado" solto fazia parecer falta de permissão no produto.
        setErroForm(res.status === 401
          ? "Sua sessão expirou. Entre de novo em outra aba e clique em Salvar: o que você preencheu continua aqui."
          : j.error || "Falha ao salvar.")
        return
      }
      setOpen(false)
      fetchProducts()
      fetchSuppliers()
    } finally {
      setSaving(false)
    }
  }

  async function confirmDeleteProduct() {
    if (!deleteTarget) return
    setDeleting(true)
    await fetch(`/api/produtos/${deleteTarget.id}`, { method: "DELETE" })
    setDeleteTarget(null)
    setDeleting(false)
    setSelected(s => { const n = new Set(s); n.delete(deleteTarget.id); return n })
    fetchProducts(); fetchSuppliers()
  }

  async function handleBulkDelete() {
    setBulkDeleting(true)
    await Promise.all([...selected].map(id => fetch(`/api/produtos/${id}`, { method: "DELETE" })))
    setSelected(new Set()); setBulkConfirmOpen(false); setBulkDeleting(false)
    fetchProducts(); fetchSuppliers()
  }

  function toggleSelect(id: string) {
    setSelected(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n })
  }

  function toggleSelectAll() {
    const currentIds = products.map(p => p.id)
    const allCurrentSelected = currentIds.every(id => selected.has(id))
    setSelected(s => {
      const n = new Set(s)
      if (allCurrentSelected) currentIds.forEach(id => n.delete(id))
      else currentIds.forEach(id => n.add(id))
      return n
    })
  }

  async function toggleStatus(p: Product) {
    await fetch(`/api/produtos/${p.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: p.status === "ATIVO" ? "INATIVO" : "ATIVO" })
    })
    fetchProducts()
  }

  async function toggleInativoProposta(p: Product) {
    await fetch(`/api/produtos/${p.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ inativo_proposta: !p.inativo_proposta })
    })
    fetchProducts()
  }

  /* `ativos` vem do servidor, contado sobre o filtro inteiro.
     Antes era `products.filter(...)`, que é só a página carregada: com 100
     itens por página o painel dizia "100 ativos" e "1195 inativos" num
     catálogo com 1294 ativos — parecia que o catálogo tinha sido desativado.
     O comentário antigo já dizia que o número era do catálogo inteiro; a
     linha abaixo dele é que não fazia isso. */

  return (
    <div className="mx-auto max-w-[1560px] space-y-3 p-4 sm:space-y-4 sm:p-6">
      <CabecalhoPagina
        icone={Package}
        titulo="Catálogo"
        contexto={`${total} produto${total !== 1 ? "s" : ""} cadastrado${total !== 1 ? "s" : ""}`}
        acao={
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowCusto(v => !v)}
            title={showCusto ? "Ocultar preço de custo" : "Mostrar preço de custo"}
            className={`flex items-center justify-center w-10 h-10 md:w-auto md:h-auto md:px-3 md:py-2 rounded-xl text-sm border transition-colors flex-shrink-0 ${
              showCusto
                ? "bg-amber-500/10 border-amber-500/50 text-amber-400"
                : "bg-muted border-border text-muted-foreground hover:text-foreground"
            }`}
          >
            {showCusto ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
          </button>
          <Button variant="outline" onClick={() => setFornOpen(true)}
            className="hidden md:inline-flex border-border text-foreground/80 hover:text-foreground">
            <Building2 className="w-4 h-4 mr-2" /> Fornecedores
          </Button>
          <Button variant="outline" onClick={() => setImportOpen(true)}
            className="hidden md:inline-flex border-border text-foreground/80 hover:text-foreground">
            <Upload className="w-4 h-4 mr-2" /> Importar
          </Button>
          <Button variant="outline" onClick={exportarCsv} disabled={exportando}
            className="hidden md:inline-flex border-border text-foreground/80 hover:text-foreground">
            {exportando
              ? <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Exportando…</>
              : <><Download className="w-4 h-4 mr-2" /> Exportar</>}
          </Button>
          {/* Mobile: ícones compactos para Fornecedores/Importar */}
          <button onClick={() => setFornOpen(true)} title="Fornecedores"
            className="md:hidden flex items-center justify-center w-10 h-10 rounded-xl border border-border bg-muted text-muted-foreground active:opacity-70 flex-shrink-0">
            <Building2 className="w-4 h-4" />
          </button>
          <button onClick={() => setImportOpen(true)} title="Importar"
            className="md:hidden flex items-center justify-center w-10 h-10 rounded-xl border border-border bg-muted text-muted-foreground active:opacity-70 flex-shrink-0">
            <Upload className="w-4 h-4" />
          </button>
          <button onClick={exportarCsv} disabled={exportando} title="Exportar CSV"
            className="md:hidden flex items-center justify-center w-10 h-10 rounded-xl border border-border bg-muted text-muted-foreground active:opacity-70 flex-shrink-0 disabled:opacity-50">
            {exportando ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
          </button>
          <Button onClick={openNew} className="bg-primary hover:bg-primary/90 text-primary-foreground flex-1 md:flex-none">
            <Plus className="w-4 h-4 mr-2" /> <span className="md:inline">Novo</span><span className="hidden md:inline">&nbsp;Produto</span>
          </Button>
        </div>
        }
      />

      <FaixaMetricas>
        <CartaoMetrica icone={Package} rotulo="Produtos" valor={total} nota="No catálogo" />
        <CartaoMetrica icone={CheckCircle2} rotulo="Ativos" valor={ativos} nota="Disponíveis para venda" />
        <CartaoMetrica icone={Building2} rotulo="Marcas" valor={suppliers.length} nota="Fornecedores" />
        <CartaoMetrica icone={EyeOff} rotulo="Inativos" valor={total - ativos} nota="Fora das propostas" />
      </FaixaMetricas>

      {/* Filtro por marca, dropdown com busca (evita paredão de chips) */}
      {suppliers.length > 0 && (() => {
        const marcaAtiva = suppliers.find(s => s.id === filtroSupplier)
        const ordenadas = [...suppliers].sort((a, b) => (b._count?.products ?? 0) - (a._count?.products ?? 0))
        const filtradas = ordenadas.filter(s => s.nome.toLowerCase().includes(marcaBusca.toLowerCase()))
        return (
          <div className="relative w-fit">
            <button onClick={() => setMarcaMenuOpen(o => !o)}
              className={`flex items-center gap-2 h-9 px-3.5 rounded-xl text-[13px] font-medium border transition-colors ${
                marcaAtiva ? "bg-ios-blue/10 text-ios-blue border-ios-blue/30" : "bg-surface-2 text-foreground border-hairline hover:bg-surface-3"
              }`}>
              <span>{marcaAtiva ? marcaAtiva.nome : "Todas as marcas"}</span>
              {marcaAtiva && <span className="opacity-60">{marcaAtiva._count?.products ?? 0}</span>}
              <ChevronDown className={`w-4 h-4 transition-transform ${marcaMenuOpen ? "rotate-180" : ""}`} />
            </button>
            {marcaAtiva && (
              <button onClick={() => { setFiltroSupplier(""); setPage(1) }}
                className="ml-2 text-[12px] text-muted-fg hover:text-foreground">limpar</button>
            )}
            {marcaMenuOpen && (
              <>
                <div className="fixed inset-0 z-20" onClick={() => setMarcaMenuOpen(false)} />
                <div className="absolute left-0 top-full mt-1.5 z-30 w-[260px] max-w-[85vw] rounded-2xl border border-hairline bg-surface-1 shadow-lg shadow-black/30 overflow-hidden">
                  <div className="p-2 border-b border-hairline">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-fg" />
                      <input autoFocus value={marcaBusca} onChange={e => setMarcaBusca(e.target.value)}
                        placeholder="Buscar marca..."
                        className="w-full h-9 pl-8 pr-3 rounded-xl bg-surface-2 border border-hairline text-[14px] text-foreground placeholder:text-muted-fg outline-none" />
                    </div>
                  </div>
                  <div className="max-h-72 overflow-y-auto p-1">
                    <button onClick={() => { setFiltroSupplier(""); setPage(1); setMarcaMenuOpen(false); setMarcaBusca("") }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-[14px] ${filtroSupplier === "" ? "bg-ios-blue/10 text-ios-blue" : "text-foreground hover:bg-white/5"}`}>
                      Todas as marcas
                    </button>
                    {filtradas.map(s => (
                      <button key={s.id} onClick={() => { setFiltroSupplier(s.id); setPage(1); setMarcaMenuOpen(false); setMarcaBusca("") }}
                        className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-[14px] ${filtroSupplier === s.id ? "bg-ios-blue/10 text-ios-blue" : "text-foreground hover:bg-white/5"}`}>
                        <span className="truncate">{s.nome}</span>
                        <span className="text-[12px] text-muted-fg ml-2 flex-shrink-0">{s._count?.products ?? 0}</span>
                      </button>
                    ))}
                    {filtradas.length === 0 && <p className="text-center text-[13px] text-muted-fg py-4">Nenhuma marca</p>}
                  </div>
                </div>
              </>
            )}
          </div>
        )
      })()}

      <div className="flex gap-2 flex-wrap items-center">
        <div className="relative flex-1 min-w-[220px] max-w-sm">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Buscar por nome, SKU, marca..."
            value={searchInput}
            onChange={e => setSearchInput(e.target.value)}
            className="pl-9 bg-muted border-border text-foreground placeholder:text-muted-foreground/60"
          />
        </div>
        {/* Filtro de disponibilidade, os 3 níveis na barra de listagem */}
        <div className="flex p-0.5 rounded-xl bg-surface-2 gap-0.5 flex-shrink-0">
          {([
            ["", "Todos"],
            ["ATIVO", "Ativos"],
            ["INATIVO_PROPOSTA", "Proposta"],
            ["INATIVO_GERAL", "Geral"],
          ] as const).map(([v, label]) => (
            <button key={v} onClick={() => { setFiltroNivel(v); setPage(1) }}
              className={`px-3 py-1.5 text-[12px] font-medium rounded-[10px] transition-all whitespace-nowrap ${
                filtroNivel === v ? "bg-surface-1 text-foreground shadow-sm shadow-black/20" : "text-muted-fg hover:text-foreground"
              }`}>
              {label}
            </button>
          ))}
        </div>
        {/* Ordenar, só no mobile: no desktop clica no cabeçalho da tabela,
            mas a tabela some no mobile (vira lista de cards) e levava a
            ordenação junto — sem jeito nenhum de ordenar crescente/decrescente
            lá. */}
        <div className="md:hidden">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-1.5 h-9 px-3 rounded-xl bg-surface-2 border border-hairline text-[13px] font-medium text-foreground flex-shrink-0">
                <ArrowUpDown className="w-3.5 h-3.5" />
                {sortCol ? `${{ sku: "SKU", nome: "Nome", marca: "Marca", preco_venda: "Preço" }[sortCol]} ${sortDir === "asc" ? "↑" : "↓"}` : "Ordenar"}
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {([["nome", "Nome"], ["sku", "SKU"], ["marca", "Marca"], ["preco_venda", "Preço de venda"]] as const).map(([col, label]) => (
                <DropdownMenuItem key={col} onClick={() => toggleSort(col)}>
                  {label}
                  {sortCol === col && <span className="ml-auto text-ios-blue">{sortDir === "asc" ? "Crescente ↑" : "Decrescente ↓"}</span>}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Barra de seleção múltipla (aparece quando há itens selecionados) */}
      {selected.size > 0 && (
        <div className="flex items-center gap-3 px-4 py-2.5 rounded-xl bg-primary/10 border border-primary/20">
          <span className="text-primary text-sm font-medium">{selected.size} selecionado{selected.size > 1 ? "s" : ""}</span>
          <Button size="sm" variant="outline" onClick={() => setSelected(new Set())}
            className="border-border text-foreground/80 hover:text-foreground h-7 text-xs">Limpar seleção</Button>
          <Button size="sm" onClick={() => setBulkConfirmOpen(true)}
            className="bg-red-600/80 hover:bg-red-600 text-foreground h-7 text-xs gap-1.5 ml-auto">
            <Trash2 className="w-3.5 h-3.5" /> Excluir {selected.size} produto{selected.size > 1 ? "s" : ""}
          </Button>
        </div>
      )}

      {/* ── MOBILE: lista de cards ── */}
      <div className="md:hidden space-y-2.5">
        {loading ? (
          <PageLoader />
        ) : products.length === 0 ? (
          <EmptyState icon={Package} title="Nenhum produto" subtitle="Cadastre ou importe um CSV para começar." />
        ) : productsOrdenados.map(p => (
          <div key={p.id}
            className={`flex items-center gap-3 rounded-[20px] border p-4 transition-colors ${
              selected.has(p.id) ? "bg-ios-blue/5 border-ios-blue/30" : "bg-surface-1 border-hairline"
            }`}>
            <input type="checkbox" checked={selected.has(p.id)} onChange={() => toggleSelect(p.id)}
              className="w-4 h-4 accent-ios-blue cursor-pointer flex-shrink-0" />
            {/* Thumb */}
            <div className="w-14 h-14 rounded-2xl bg-surface-2 flex items-center justify-center flex-shrink-0 overflow-hidden">
              {p.imagem_url ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={proxiedImg(p.imagem_url)} alt={p.nome} className="w-full h-full object-cover"
                  onError={e => { (e.target as HTMLImageElement).style.display = "none"; (e.target as HTMLImageElement).nextElementSibling?.classList.remove("hidden") }} />
              ) : null}
              <ImageOff className={`w-5 h-5 text-muted-foreground/50 ${p.imagem_url ? "hidden" : ""}`} />
            </div>
            {/* Info */}
            <div className="flex-1 min-w-0">
              <p className="text-[15px] font-medium text-foreground leading-tight">{p.nome}</p>
              <p className="text-[13px] text-muted-fg font-mono mt-0.5">{p.sku}{p.marca ? ` · ${p.marca}` : ""}</p>
              <div className="flex items-center gap-2 mt-1.5">
                <span className="text-[15px] font-semibold text-foreground">{brl(Number(p.preco_venda))}</span>
                {showCusto && <span className="text-xs text-muted-fg">custo {brl(Number(p.preco_custo))}</span>}
                {(() => { const n = nivelStatus(p); return <Badge variant={n.variant} className="ml-auto text-[10px] whitespace-nowrap">{n.label}</Badge> })()}
              </div>
            </div>
            {/* Ações */}
            <div className="flex flex-col gap-1 flex-shrink-0">
              <button onClick={() => openEdit(p)} className="w-8 h-8 flex items-center justify-center rounded-2xl text-muted-foreground hover:text-foreground active:bg-muted">
                <Pencil className="w-4 h-4" />
              </button>
              <button onClick={() => setDeleteTarget(p)} className="w-8 h-8 flex items-center justify-center rounded-2xl text-muted-foreground hover:text-red-400 active:bg-muted">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* ── DESKTOP: tabela ── */}
      <div className="hidden md:block rounded-xl border border-border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="border-border hover:bg-transparent">
              {/* Checkbox selecionar tudo */}
              <TableHead className="w-10 pl-4">
                <input type="checkbox"
                  checked={products.length > 0 && products.every(p => selected.has(p.id))}
                  ref={el => { if (el) el.indeterminate = products.some(p => selected.has(p.id)) && !products.every(p => selected.has(p.id)) }}
                  onChange={toggleSelectAll}
                  className="w-4 h-4 accent-primary cursor-pointer" />
              </TableHead>
              <TableHead className="text-muted-foreground w-16">Img</TableHead>
              {([["sku", "SKU"], ["nome", "Nome"], ["marca", "Marca"]] as const).map(([col, label]) => (
                <TableHead key={col} className="text-muted-foreground cursor-pointer select-none hover:text-foreground transition-colors"
                  onClick={() => toggleSort(col)}>
                  {label}{sortCol === col && <span className="ml-1 text-ios-blue">{sortDir === "asc" ? "↑" : "↓"}</span>}
                </TableHead>
              ))}
              {showCusto && <TableHead className="text-amber-400">Custo</TableHead>}
              {showCusto && <TableHead className="text-amber-400">Markup</TableHead>}
              <TableHead className="text-muted-foreground cursor-pointer select-none hover:text-foreground transition-colors"
                onClick={() => toggleSort("preco_venda")}>
                Preço de Venda{sortCol === "preco_venda" && <span className="ml-1 text-ios-blue">{sortDir === "asc" ? "↑" : "↓"}</span>}
              </TableHead>
              <TableHead className="text-muted-foreground">Status</TableHead>
              <TableHead className="text-muted-foreground text-center">Proposta</TableHead>
              <TableHead className="text-muted-foreground text-center">Geral</TableHead>
              <TableHead className="text-muted-foreground text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={showCusto ? 10 : 8}><PageLoader /></TableCell>
              </TableRow>
            ) : products.length === 0 ? (
              <TableRow>
                <TableCell colSpan={showCusto ? 10 : 8} className="p-0">
                  <EmptyState icon={Package} title="Nenhum produto" subtitle="Cadastre um produto ou importe um CSV para começar." />
                </TableCell>
              </TableRow>
            ) : productsOrdenados.map(p => (
              <TableRow key={p.id} className={`border-border/50 hover:bg-muted/30 transition-colors ${selected.has(p.id) ? "bg-primary/5" : ""}`}>
                <TableCell className="pl-4">
                  <input type="checkbox" checked={selected.has(p.id)} onChange={() => toggleSelect(p.id)}
                    className="w-4 h-4 accent-primary cursor-pointer" />
                </TableCell>
                <TableCell>
                  {p.imagem_url ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={proxiedImg(p.imagem_url)} alt={p.nome}
                      className="w-10 h-10 rounded object-cover"
                      onError={e => { (e.target as HTMLImageElement).style.display = "none"; (e.target as HTMLImageElement).nextElementSibling?.classList.remove("hidden") }}
                    />
                  ) : null}
                  <div className={`w-10 h-10 rounded bg-muted flex items-center justify-center ${p.imagem_url ? "hidden" : ""}`}>
                    <ImageOff className="w-4 h-4 text-muted-foreground/50" />
                  </div>
                </TableCell>
                <TableCell className="text-foreground/80 font-mono text-xs"><InlineCell p={p} field="sku" display={p.sku} width="w-20" /></TableCell>
                <TableCell className="text-foreground font-medium max-w-[220px]"><InlineCell p={p} field="nome" display={p.nome} width="w-48" /></TableCell>
                <TableCell className="text-muted-foreground"><InlineCell p={p} field="marca" display={p.marca || "—"} width="w-28" /></TableCell>
                {showCusto && <TableCell className="text-amber-300"><InlineCell p={p} field="preco_custo" display={brl(Number(p.preco_custo))} /></TableCell>}
                {showCusto && <TableCell className="text-amber-300"><InlineCell p={p} field="markup_padrao" display={`${Number(p.markup_padrao).toFixed(1)}%`} /></TableCell>}
                <TableCell className="text-emerald-400 font-medium"><InlineCell p={p} field="preco_venda" display={brl(Number(p.preco_venda))} /></TableCell>
                <TableCell>
                  {(() => { const n = nivelStatus(p); return <Badge variant={n.variant} className="whitespace-nowrap">{n.label}</Badge> })()}
                </TableCell>
                <TableCell className="text-center">
                  <Switch checked={!p.inativo_proposta} onCheckedChange={() => toggleInativoProposta(p)}
                    disabled={p.status === "INATIVO"} title="Ativo para proposta" />
                </TableCell>
                <TableCell className="text-center">
                  <Switch checked={p.status === "ATIVO"} onCheckedChange={() => toggleStatus(p)}
                    title="Ativo geral" />
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button size="sm" variant="ghost" onClick={() => openEdit(p)} className="text-muted-foreground hover:text-foreground h-8 w-8 p-0">
                      <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => setDeleteTarget(p)} className="text-muted-foreground hover:text-red-400 h-8 w-8 p-0">
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Modal de confirmação de exclusão individual */}
      <Dialog open={!!deleteTarget} onOpenChange={o => !o && setDeleteTarget(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-400">
              <Trash2 className="w-5 h-5" /> Excluir produto
            </DialogTitle>
          </DialogHeader>
          <p className="px-5 py-4 text-sm text-foreground/80 sm:px-6">
            Tem certeza que deseja excluir <span className="text-foreground font-semibold">&quot;{deleteTarget?.nome}&quot;</span>?
            <span className="block mt-1 text-muted-foreground/60 text-xs">Esta ação não pode ser desfeita.</span>
          </p>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)} disabled={deleting}
              className="border-border text-foreground/80">Cancelar</Button>
            <Button onClick={confirmDeleteProduct} disabled={deleting}
              className="bg-red-600 hover:bg-red-700 text-foreground">
              {deleting ? "Excluindo..." : "Excluir"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de confirmação de exclusão em massa */}
      <Dialog open={bulkConfirmOpen} onOpenChange={setBulkConfirmOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-400">
              <Trash2 className="w-5 h-5" /> Excluir {selected.size} produto{selected.size > 1 ? "s" : ""}
            </DialogTitle>
          </DialogHeader>
          <p className="px-5 py-4 text-sm text-foreground/80 sm:px-6">
            Tem certeza que deseja excluir <span className="text-foreground font-semibold">{selected.size} produto{selected.size > 1 ? "s" : ""}</span> selecionado{selected.size > 1 ? "s" : ""}?
            <span className="block mt-1 text-muted-foreground/60 text-xs">Esta ação não pode ser desfeita.</span>
          </p>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setBulkConfirmOpen(false)} disabled={bulkDeleting}
              className="border-border text-foreground/80">Cancelar</Button>
            <Button onClick={handleBulkDelete} disabled={bulkDeleting}
              className="bg-red-600 hover:bg-red-700 text-foreground">
              {bulkDeleting ? "Excluindo..." : `Excluir ${selected.size}`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="flex items-center justify-between gap-4 flex-wrap">
        {/* Itens por página, lista suspensa */}
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <label htmlFor="perPage">Itens por página:</label>
          <select id="perPage" value={perPage}
            onChange={e => { setPerPage(Number(e.target.value)); setPage(1) }}
            className="h-8 pl-2.5 pr-7 rounded-xl bg-muted/60 border border-hairline text-foreground text-sm focus:outline-none focus:ring-1 focus:ring-primary/30 cursor-pointer">
            {[10, 20, 30, 40, 50, 100].map(n => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>
        </div>

        {/* Paginação */}
        {pages > 1 && (
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>
              Anterior
            </Button>
            <span className="text-muted-foreground text-sm">Página {page} de {pages}</span>
            <Button variant="outline" size="sm" disabled={page >= pages} onClick={() => setPage(p => p + 1)}>
              Próxima
            </Button>
          </div>
        )}

        {/* Total */}
        <span className="text-sm text-muted-foreground">{total} produto{total !== 1 ? "s" : ""} no total</span>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="w-[calc(100vw-32px)] sm:max-w-3xl mx-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Editar Produto" : "Novo Produto"}</DialogTitle>
          </DialogHeader>
          <div className="overflow-y-auto max-h-[calc(90vh-140px)]">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 px-5 sm:px-6 py-3">
            <div className="col-span-2 sm:col-span-3 space-y-1">
              <Label className="text-foreground/80">Fornecedor / Marca</Label>
              <div className="flex gap-2">
                <select value={form.supplierId} onChange={e => onSupplierChange(e.target.value)}
                  className="flex h-10 w-full rounded-xl border border-border bg-muted text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary">
                  <option value="">Selecione um fornecedor</option>
                  {suppliers.map(s => <option key={s.id} value={s.id}>{s.nome}</option>)}
                </select>
                <button type="button" onClick={() => setFornOpen(true)}
                  className="flex-shrink-0 h-10 px-3 rounded-xl border border-border bg-muted text-muted-foreground hover:text-foreground text-sm flex items-center gap-1">
                  <Plus className="w-4 h-4" /> Novo
                </button>
              </div>
              {form.supplierId && <p className="text-xs text-muted-foreground/60">O SKU é gerado automaticamente e a marca usa o nome do fornecedor.</p>}
            </div>
            <div className="space-y-1">
              <Label className="text-foreground/80">SKU *</Label>
              <div className="relative">
                <Input value={form.sku} onChange={e => setForm(f => ({ ...f, sku: e.target.value }))}
                  className="bg-muted border-border text-foreground pr-8" placeholder="Selecione o fornecedor" />
                {skuLoading && <RefreshCw className="w-4 h-4 text-muted-foreground/60 animate-spin absolute right-2.5 top-3" />}
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-foreground/80">Marca</Label>
              <Input value={form.marca} onChange={e => setForm(f => ({ ...f, marca: e.target.value }))}
                className="bg-muted border-border text-foreground" placeholder="Auto (nome do fornecedor)" />
            </div>
            <div className="col-span-2 sm:col-span-3 space-y-1">
              <Label className="text-foreground/80">Modelo *</Label>
              <Input value={form.nome} onChange={e => setForm(f => ({ ...f, nome: e.target.value }))}
                className="bg-muted border-border text-foreground" placeholder="Ex: Switch 16 portas Hikvision DS-3E0516HP" />
            </div>
            <div className="space-y-1">
              <Label className="text-foreground/80">Preço de Custo (R$) *</Label>
              <Input type="number" step="0.01" min="0" value={form.preco_custo}
                onChange={e => setForm(f => ({ ...f, preco_custo: e.target.value }))}
                className="bg-muted border-border text-foreground" placeholder="0,00" />
            </div>
            <div className="space-y-1">
              <Label className="text-foreground/80">Markup Padrão (%)</Label>
              <Input type="number" step="0.1" min="0" value={form.markup_padrao}
                onChange={e => setForm(f => ({ ...f, markup_padrao: e.target.value }))}
                className="bg-muted border-border text-foreground" placeholder="0" />
            </div>
            {/* Escadinha de cálculo */}
            {(Number(form.preco_custo) > 0) && (
              <div className="col-span-2 sm:col-span-3 rounded-2xl bg-muted/40 border border-border px-3 py-2.5 text-xs">
                {(() => {
                  const custo      = Number(form.preco_custo) || 0
                  const st         = Number(form.imposto_st)  || 0
                  const markup     = Number(form.markup_padrao) || 0
                  const stValor    = custo * (st / 100)
                  const custoComST = custo + stValor
                  const venda      = custoComST * (1 + markup / 100)
                  const fmt = (v: number) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })
                  return (
                    <div className="flex items-center gap-2 flex-wrap text-foreground/80">
                      <span>Custo <strong className="text-foreground">{fmt(custo)}</strong></span>
                      {st > 0 && <>
                        <span className="text-muted-foreground/60">→</span>
                        <span>+ST {st}% <strong className="text-emerald-400">{fmt(stValor)}</strong></span>
                        <span className="text-muted-foreground/60">→</span>
                        <span>Base <strong className="text-foreground">{fmt(custoComST)}</strong></span>
                      </>}
                      {markup > 0 && <>
                        <span className="text-muted-foreground/60">→</span>
                        <span>+{markup}% <strong className="text-primary">{fmt(venda)}</strong></span>
                      </>}
                    </div>
                  )
                })()}
              </div>
            )}
            <div className="space-y-1">
              <Label className="text-foreground/80">Preço de Venda (R$)</Label>
              <Input type="number" step="0.01" min="0" value={form.preco_venda}
                onChange={e => setForm(f => ({ ...f, preco_venda: e.target.value }))}
                className="bg-muted border-border text-foreground" placeholder="Auto-calculado" />
            </div>
            {/* Disponibilidade, 3 níveis num único controle:
                Ativo · Inativo p/ proposta (segue como componente) · Inativo geral */}
            <div className="space-y-1">
              <Label className="text-foreground/80">Disponibilidade</Label>
              <select
                value={form.status === "INATIVO" ? "INATIVO_GERAL" : form.inativo_proposta ? "INATIVO_PROPOSTA" : "ATIVO"}
                onChange={e => {
                  const v = e.target.value
                  setForm(f => ({
                    ...f,
                    status: v === "INATIVO_GERAL" ? "INATIVO" : "ATIVO",
                    inativo_proposta: v === "INATIVO_PROPOSTA",
                  }))
                }}
                className="flex h-10 w-full rounded-xl border border-border bg-muted text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary">
                <option value="ATIVO">Ativo</option>
                <option value="INATIVO_PROPOSTA">Inativo p/ proposta</option>
                <option value="INATIVO_GERAL">Inativo geral</option>
              </select>
              <p className="text-[10px] text-muted-foreground/60">
                {form.status === "INATIVO" ? "Desabilitado em tudo."
                  : form.inativo_proposta ? "Some da busca de propostas; segue como componente."
                  : "Disponível em tudo."}
              </p>
            </div>

            <div className="space-y-1">
              <Label className="text-foreground/80">NCM</Label>
              <Input value={form.ncm} onChange={e => setForm(f => ({ ...f, ncm: e.target.value }))}
                className="bg-muted border-border text-foreground" placeholder="0000.00.00" maxLength={10} />
              <p className="text-[10px] text-muted-foreground/60">Obrigatório para nota fiscal</p>
            </div>
            <div className="space-y-1">
              <Label className="text-foreground/80">Imposto ST (%)</Label>
              <Input type="number" step="0.01" min="0" max="100" value={form.imposto_st}
                onChange={e => setForm(f => ({ ...f, imposto_st: e.target.value }))}
                className="bg-muted border-border text-foreground" placeholder="0" />
            </div>

            {/* Fiscal completo, recolhido porque só interessa na hora da NF-e.
                O que ficar em branco aqui chega vazio no Olist. */}
            <details className="sm:col-span-2 lg:col-span-3 rounded-xl border border-border bg-muted/30 px-3 py-2">
              <summary className="cursor-pointer text-xs text-muted-foreground">
                Dados fiscais (PIS, COFINS, ICMS, IPI, CEST, origem…)
              </summary>
              <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
                <div className="space-y-1">
                  <Label className="text-foreground/80">CEST</Label>
                  <Input value={form.cest} onChange={e => setForm(f => ({ ...f, cest: e.target.value }))}
                    className="bg-muted border-border text-foreground" placeholder="00.000.00" maxLength={10} />
                </div>
                <div className="space-y-1">
                  <Label className="text-foreground/80">Origem</Label>
                  <select value={form.origem} onChange={e => setForm(f => ({ ...f, origem: e.target.value }))}
                    className="h-10 w-full rounded-xl border border-border bg-muted px-3 text-sm text-foreground">
                    <option value="">—</option>
                    <option value="0">0 · Nacional</option>
                    <option value="1">1 · Importação direta</option>
                    <option value="2">2 · Mercado interno</option>
                    <option value="3">3 · Nacional, importação &gt; 40%</option>
                    <option value="4">4 · Produção conforme processos básicos</option>
                    <option value="5">5 · Nacional, importação &lt;= 40%</option>
                    <option value="6">6 · Importação direta sem similar</option>
                    <option value="7">7 · Mercado interno sem similar</option>
                    <option value="8">8 · Nacional, importação &gt; 70%</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <Label className="text-foreground/80">Unidade</Label>
                  <Input value={form.unidade} onChange={e => setForm(f => ({ ...f, unidade: e.target.value.toUpperCase() }))}
                    className="bg-muted border-border text-foreground" placeholder="UN" maxLength={6} />
                </div>
                <div className="space-y-1">
                  <Label className="text-foreground/80">GTIN / EAN</Label>
                  <Input value={form.gtin} onChange={e => setForm(f => ({ ...f, gtin: e.target.value }))}
                    className="bg-muted border-border text-foreground" placeholder="7891234567890" maxLength={14} />
                </div>
                <div className="space-y-1">
                  <Label className="text-foreground/80">CST/CSOSN ICMS</Label>
                  <Input value={form.cst_icms} onChange={e => setForm(f => ({ ...f, cst_icms: e.target.value }))}
                    className="bg-muted border-border text-foreground" placeholder="00 ou 102" maxLength={4} />
                </div>
                <div className="space-y-1">
                  <Label className="text-foreground/80">Alíquota ICMS (%)</Label>
                  <Input type="number" step="0.01" min="0" max="100" value={form.aliquota_icms}
                    onChange={e => setForm(f => ({ ...f, aliquota_icms: e.target.value }))}
                    className="bg-muted border-border text-foreground" placeholder="—" />
                </div>
                <div className="space-y-1">
                  <Label className="text-foreground/80">Alíquota IPI (%)</Label>
                  <Input type="number" step="0.01" min="0" max="100" value={form.aliquota_ipi}
                    onChange={e => setForm(f => ({ ...f, aliquota_ipi: e.target.value }))}
                    className="bg-muted border-border text-foreground" placeholder="—" />
                </div>
                <div className="space-y-1">
                  <Label className="text-foreground/80">CST PIS</Label>
                  <Input value={form.cst_pis} onChange={e => setForm(f => ({ ...f, cst_pis: e.target.value }))}
                    className="bg-muted border-border text-foreground" placeholder="01" maxLength={3} />
                </div>
                <div className="space-y-1">
                  <Label className="text-foreground/80">Alíquota PIS (%)</Label>
                  <Input type="number" step="0.01" min="0" max="100" value={form.aliquota_pis}
                    onChange={e => setForm(f => ({ ...f, aliquota_pis: e.target.value }))}
                    className="bg-muted border-border text-foreground" placeholder="1.65" />
                </div>
                <div className="space-y-1">
                  <Label className="text-foreground/80">CST COFINS</Label>
                  <Input value={form.cst_cofins} onChange={e => setForm(f => ({ ...f, cst_cofins: e.target.value }))}
                    className="bg-muted border-border text-foreground" placeholder="01" maxLength={3} />
                </div>
                <div className="space-y-1">
                  <Label className="text-foreground/80">Alíquota COFINS (%)</Label>
                  <Input type="number" step="0.01" min="0" max="100" value={form.aliquota_cofins}
                    onChange={e => setForm(f => ({ ...f, aliquota_cofins: e.target.value }))}
                    className="bg-muted border-border text-foreground" placeholder="7.60" />
                </div>
              </div>
            </details>
            <div className="space-y-1">
              <Label className="text-foreground/80">Garantia (dias)</Label>
              <Input type="number" min="0" max="3650" value={form.garantia_dias}
                onChange={e => setForm(f => ({ ...f, garantia_dias: e.target.value }))}
                className="bg-muted border-border text-foreground" placeholder="—" />
              <p className="text-[10px] text-muted-foreground/60">
                Puxada para a proposta automaticamente. Conta a partir do check de instalação da obra.
              </p>
            </div>
            <div className="space-y-1">
              <Label className="text-foreground/80">Estoque atual</Label>
              {/* Somente leitura: o saldo é do módulo Estoque (entradas/saídas
                  e inventário). Editar aqui furaria a trilha de auditoria. */}
              <Input readOnly disabled value={form.estoque_qtd || "—"}
                className="bg-muted/40 border-border text-muted-foreground cursor-not-allowed" />
              <p className="text-[10px] text-muted-foreground/60">Ajuste em Estoque → Movimentar</p>
            </div>
            <div className="space-y-1">
              <Label className="text-foreground/80">Estoque mínimo (alerta)</Label>
              <Input type="number" min="0" value={form.estoque_minimo}
                onChange={e => setForm(f => ({ ...f, estoque_minimo: e.target.value }))}
                className="bg-muted border-border text-foreground" placeholder="—" />
            </div>
            {/* Dimensionamento no produto (Bloco 12) */}
            <div className="space-y-1">
              <Label className="text-foreground/80">Tipo de aplicação</Label>
              <select
                value={form.tipo_aplicacao && !TIPOS_APLICACAO.includes(form.tipo_aplicacao) ? "__outro__" : form.tipo_aplicacao}
                onChange={e => setForm(f => ({ ...f, tipo_aplicacao: e.target.value }))}
                className="flex h-10 w-full rounded-xl border border-border bg-muted text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary">
                <option value="">—</option>
                <option value="Teto">Teto</option>
                <option value="Marcenaria">Marcenaria</option>
                <option value="Rack">Rack</option>
                <option value="Quadro de automação">Quadro de automação</option>
                <option value="Área externa">Área externa</option>
                <option value="__outro__">Outro (digitar)…</option>
              </select>
              {/* "Outro": campo livre para a pessoa criar o tipo que precisar */}
              {(form.tipo_aplicacao === "__outro__" || (form.tipo_aplicacao && !TIPOS_APLICACAO.includes(form.tipo_aplicacao))) && (
                <Input autoFocus
                  value={form.tipo_aplicacao === "__outro__" ? "" : form.tipo_aplicacao}
                  onChange={e => setForm(f => ({ ...f, tipo_aplicacao: e.target.value }))}
                  placeholder="Digite o tipo de aplicação"
                  className="bg-muted border-border text-foreground mt-1.5" />
              )}
            </div>
            <div className="space-y-1">
              <Label className="text-foreground/80">Formato</Label>
              <select value={form.formato_medida}
                onChange={e => {
                  const v = e.target.value
                  setForm(f => ({ ...f, formato_medida: v, ...(v === "Quadrado" && f.altura_mm ? { largura_mm: f.altura_mm } : {}) }))
                }}
                className="flex h-10 w-full rounded-xl border border-border bg-muted text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary">
                <option value="">—</option>
                <option value="Circulo">Círculo (Ø)</option>
                {/* Caixa de embutir é o caso mais comum do catálogo: o que
                    decide a obra é o recorte redondo E a profundidade atrás do
                    forro. Com só o diâmetro, a medida que reprova a instalação
                    ficava de fora. */}
                <option value="Cilindro">Cilindro (Ø × profundidade)</option>
                <option value="Quadrado">Quadrado</option>
                <option value="Retangulo">Retângulo</option>
                <option value="Linear">Linear (comprimento)</option>
                {/* O rótulo diz "Padrão" porque é a forma que serve a
                    qualquer produto de caixa — não é a sobra dos outros
                    formatos. O valor gravado continua "Outros" para não
                    invalidar o que já está no catálogo. */}
                <option value="Outros">Padrão (L × A × C)</option>
              </select>
            </div>
            {/* Medidas conforme o formato (em cm) */}
            {form.formato_medida === "Circulo" && (
              <div className="space-y-1">
                <Label className="text-foreground/80">Diâmetro (cm)</Label>
                <CampoMascarado mascara="cm" value={form.largura_mm}
                  onValorChange={v => setForm(f => ({ ...f, largura_mm: v }))}
                  className="bg-muted border-border text-foreground" placeholder="—" />
              </div>
            )}
            {form.formato_medida === "Cilindro" && (
              <>
                <div className="space-y-1">
                  <Label className="text-foreground/80">Diâmetro (cm)</Label>
                  <CampoMascarado mascara="cm" value={form.largura_mm}
                    onValorChange={v => setForm(f => ({ ...f, largura_mm: v }))}
                    className="bg-muted border-border text-foreground" placeholder="—" />
                </div>
                <div className="space-y-1">
                  <Label className="text-foreground/80">Profundidade (cm)</Label>
                  <CampoMascarado mascara="cm" value={form.profundidade_mm}
                    onValorChange={v => setForm(f => ({ ...f, profundidade_mm: v }))}
                    className="bg-muted border-border text-foreground" placeholder="—" />
                </div>
              </>
            )}
            {form.formato_medida === "Linear" && (
              <div className="space-y-1">
                {/* Comprimento é a profundidade do sistema (mesmo campo do "C" no Padrão L × A × C). */}
                <Label className="text-foreground/80">Comprimento (cm)</Label>
                <CampoMascarado mascara="cm" value={form.profundidade_mm}
                  onValorChange={v => setForm(f => ({ ...f, profundidade_mm: v }))}
                  className="bg-muted border-border text-foreground" placeholder="—" />
              </div>
            )}
            {form.formato_medida === "Quadrado" && (
              <div className="space-y-1">
                <Label className="text-foreground/80">Lado (cm)</Label>
                <CampoMascarado mascara="cm" value={form.largura_mm}
                  onValorChange={v => setForm(f => ({ ...f, largura_mm: v, altura_mm: v }))}
                  className="bg-muted border-border text-foreground" placeholder="—" />
                <p className="text-[10px] text-muted-foreground/60">Altura = largura (travado)</p>
              </div>
            )}
            {form.formato_medida === "Retangulo" && (
              <>
                <div className="space-y-1">
                  <Label className="text-foreground/80">Largura (cm)</Label>
                  <CampoMascarado mascara="cm" value={form.largura_mm}
                    onValorChange={v => setForm(f => ({ ...f, largura_mm: v }))}
                    className="bg-muted border-border text-foreground" placeholder="—" />
                </div>
                <div className="space-y-1">
                  <Label className="text-foreground/80">Altura (cm)</Label>
                  <CampoMascarado mascara="cm" value={form.altura_mm}
                    onValorChange={v => setForm(f => ({ ...f, altura_mm: v }))}
                    className="bg-muted border-border text-foreground" placeholder="—" />
                </div>
              </>
            )}
            {/* Medida já preenchida que o formato escolhido não mostra. Muito
                produto foi cadastrado em "Padrão" e depois marcado como
                Retângulo ou Círculo: o comprimento/profundidade continuava no
                banco, mas sumia da tela, e quem editava não sabia que existia. */}
            {(() => {
              const usados: Record<string, string[]> = {
                Circulo: ["largura_mm"], Cilindro: ["largura_mm", "profundidade_mm"], Linear: ["profundidade_mm"],
                Quadrado: ["largura_mm", "altura_mm"], Retangulo: ["largura_mm", "altura_mm"],
              }
              const vis = usados[form.formato_medida]
              if (!vis) return null
              const rotulo: Record<string, string> = { largura_mm: "Largura (cm)", altura_mm: "Altura (cm)", profundidade_mm: "Profundidade (cm)" }
              const ocultos = (["largura_mm", "altura_mm", "profundidade_mm"] as const)
                .filter(k => !vis.includes(k) && form[k] !== "" && form[k] != null)
              return ocultos.map(k => (
                <div key={k} className="space-y-1">
                  <Label className="text-foreground/80">{rotulo[k]}</Label>
                  <CampoMascarado mascara="cm" value={form[k]}
                    onValorChange={v => setForm(f => ({ ...f, [k]: v }))}
                    className="bg-muted border-border text-foreground" placeholder="—" />
                  <p className="text-[10px] text-amber-400/80">Já preenchido; este formato não usa. Apague se não servir.</p>
                </div>
              ))
            })()}
            {/* Padrão: largura, altura e comprimento independentes. */}
            {form.formato_medida === "Outros" && (
              <>
                <div className="space-y-1">
                  <Label className="text-foreground/80">Largura (cm)</Label>
                  <CampoMascarado mascara="cm" value={form.largura_mm}
                    onValorChange={v => setForm(f => ({ ...f, largura_mm: v }))}
                    className="bg-muted border-border text-foreground" placeholder="—" />
                </div>
                <div className="space-y-1">
                  <Label className="text-foreground/80">Altura (cm)</Label>
                  <CampoMascarado mascara="cm" value={form.altura_mm}
                    onValorChange={v => setForm(f => ({ ...f, altura_mm: v }))}
                    className="bg-muted border-border text-foreground" placeholder="—" />
                </div>
                <div className="space-y-1">
                  <Label className="text-foreground/80">Comprimento (cm)</Label>
                  <CampoMascarado mascara="cm" value={form.profundidade_mm}
                    onValorChange={v => setForm(f => ({ ...f, profundidade_mm: v }))}
                    className="bg-muted border-border text-foreground" placeholder="—" />
                </div>
              </>
            )}

            <div className="space-y-1 col-span-2 sm:col-span-3">
              <Label className="text-foreground/80 flex items-center gap-1.5">
                Nome exibido na proposta
                <span className="text-[10px] text-muted-foreground/60 font-normal">(sem marca nem modelo)</span>
              </Label>
              <Input value={form.nome_cliente} onChange={e => setForm(f => ({ ...f, nome_cliente: e.target.value }))}
                className="bg-muted border-border text-foreground" placeholder="Ex: Switch 16 portas, Controladora..." />
            </div>
            <div className="space-y-1 col-span-2 sm:col-span-3">
              <Label className="text-foreground/80">Especificações técnicas</Label>
              <textarea value={form.especificacoes} onChange={e => setForm(f => ({ ...f, especificacoes: e.target.value }))}
                rows={3} className="flex w-full rounded-xl border border-border bg-muted text-foreground text-sm p-3 focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="Consumo, alcance, capacidade, tensão. Entra no dimensionamento e na proposta." />
            </div>
            {/* Produto composto, componentes ocultos (Bloco 4). Só ao editar. */}
            {editing && (
              <div className="col-span-2 sm:col-span-3 space-y-2 rounded-2xl border border-border bg-muted/30 p-3">
                <div className="flex items-center justify-between">
                  <Label className="text-foreground/80">Componentes (produto composto)</Label>
                  {compTotal > 0 && (
                    <span className="text-[11px] text-muted-foreground">Custo dos componentes: {brl(compTotal)}</span>
                  )}
                </div>
                <p className="text-[10px] text-muted-foreground/60">
                  Itens vinculados entram no custo/estoque interno, mas não aparecem separados na proposta do cliente.
                </p>
                {comps.length > 0 && (
                  <div className="space-y-1">
                    {comps.map(c => (
                      <div key={c.componenteId} className="flex items-center justify-between px-3 py-1.5 rounded-xl bg-muted border border-border text-sm">
                        <span className="truncate">
                          {c.nome} <span className="text-muted-foreground text-xs font-mono">[{c.sku}]</span>
                          {c.inativo_proposta && <span className="ml-2 text-[10px] text-ios-orange">oculto</span>}
                          <span className="ml-2 text-muted-foreground text-xs">× {c.quantidade}</span>
                        </span>
                        <button type="button" onClick={() => remComp(c.componenteId)} className="text-ios-red text-xs flex-shrink-0 ml-2">Remover</button>
                      </div>
                    ))}
                  </div>
                )}
                <div className="relative">
                  <Input value={compBusca} onChange={e => setCompBusca(e.target.value)}
                    className="bg-muted border-border text-foreground" placeholder="Buscar item para vincular (nome ou SKU)..." />
                  {compRes.length > 0 && (
                    <div className="absolute z-10 left-0 right-0 mt-1 max-h-44 overflow-y-auto rounded-xl border border-border bg-card shadow-lg divide-y divide-border">
                      {compRes.map(r => (
                        <button key={r.id} type="button" onClick={() => addComp(r.id, r.nome, r.sku)}
                          className="w-full text-left px-3 py-2 text-sm hover:bg-muted transition-colors">
                          {r.nome} <span className="text-muted-foreground text-xs font-mono">[{r.sku}]</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            <div className="col-span-2 sm:col-span-3">
              <ImageUrlOrUploadField value={form.imagem_url} onChange={v => setForm(f => ({ ...f, imagem_url: v }))} />
            </div>

            {erroForm && (
              <div className="col-span-2 sm:col-span-3 rounded-2xl bg-red-500/10 border border-red-500/30 px-3 py-2 text-sm text-red-300">{erroForm}</div>
            )}
          </div>
          </div>{/* fim scroll wrapper */}
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground">Cancelar</Button>
            <Button onClick={handleSave} disabled={saving || !form.sku || !form.nome || !form.preco_custo}
              className="bg-primary hover:bg-primary/90 text-primary-foreground">
              {saving ? "Salvando..." : "Salvar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Só os fornecedores são aguardados. `fetchProducts` é a consulta
          pesada da página, com todos os filtros, e disparada junto atrasava a
          única lista que o modal precisa — a de trás está tampada pelo modal
          de qualquer forma, e recarrega sozinha depois. */}
      <FornecedoresDialog open={fornOpen} onOpenChange={setFornOpen} suppliers={suppliers}
        onChange={async () => { await fetchSuppliers(); fetchProducts() }} />
      <ImportDialog open={importOpen} onOpenChange={setImportOpen} suppliers={suppliers} onDone={() => { fetchProducts(); fetchSuppliers() }} />
    </div>
  )
}

// ============================================================
// Dialog: Gerenciar Fornecedores
// ============================================================
function FornecedoresDialog({ open, onOpenChange, suppliers, onChange }: {
  open: boolean
  onOpenChange: (v: boolean) => void
  suppliers: Supplier[]
  /* Aguardável de propósito: a linha só sai do modo de edição depois que a
     lista voltou do servidor. Solto, o `onChange` deixava a linha voltar ao
     modo leitura lendo o estado antigo — o nome anterior reaparecia e parecia
     que o salvamento tinha falhado. */
  onChange: () => Promise<void> | void
}) {
  const [nome, setNome] = useState("")
  const [prefixo, setPrefixo] = useState("")
  const [saving, setSaving] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)
  const [editNome, setEditNome] = useState("")
  const [editPrefixo, setEditPrefixo] = useState("")
  const [salvandoEdit, setSalvandoEdit] = useState(false)
  const [erroEdit, setErroEdit] = useState("")
  const [busca, setBusca] = useState("")

  /* Busca sem acento: "Ubiquiti" e "Sonus Faber" convivem com "Integração"
     e "Iluminação" na mesma lista, e quem digita "integracao" não achava
     nada. Também casa pelo prefixo — é por ele que o SKU é lido. */
  const semAcento = (s: string) =>
    s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase()

  const termo = semAcento(busca.trim())
  const visiveis = termo
    ? suppliers.filter(s => semAcento(`${s.nome} ${s.prefixo}`).includes(termo))
    : suppliers

  async function criar() {
    if (!nome.trim()) return
    setSaving(true)
    try {
      await fetch("/api/fornecedores", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ nome, prefixo }) })
      /* Limpa o filtro junto: com um termo ativo, o fornecedor recém-criado
         quase sempre cai fora dele e parece que o cadastro não funcionou. */
      setNome(""); setPrefixo(""); setBusca("")
      onChange()
    } finally { setSaving(false) }
  }

  /**
   * Renomear fornecedor é lento por um bom motivo: o PATCH não mexe só no
   * cadastro. Ele reescreve a marca de TODOS os produtos daquele fornecedor
   * (há um com 135 aqui) e, se o prefixo mudar, renumera os SKUs numa
   * transação de duas fases. A demora é legítima; o que estava errado era a
   * tela não dizer nada e ainda fechar antes da hora.
   */
  async function salvarEdit(id: string) {
    if (salvandoEdit) return
    setSalvandoEdit(true)
    setErroEdit("")
    try {
      const r = await fetch(`/api/fornecedores/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome: editNome, prefixo: editPrefixo }),
      })
      if (!r.ok) {
        /* Erro fechava em silêncio, como se tivesse dado certo. A edição fica
           aberta com o que foi digitado: obrigar a redigitar o nome inteiro
           por causa de um prefixo repetido é o caminho para desistir. */
        const j = await r.json().catch(() => ({}))
        setErroEdit(j.error || "Não foi possível salvar. Tente de novo.")
        return
      }
      // Só sai da edição depois que a lista chegou, senão a linha volta com o
      // nome antigo e troca sozinha segundos depois.
      await onChange()
      setEditId(null)
    } catch {
      setErroEdit("Falha de conexão ao salvar.")
    } finally { setSalvandoEdit(false) }
  }

  const [fornDelTarget, setFornDelTarget] = useState<Supplier | null>(null)
  const [fornDeleting, setFornDeleting] = useState(false)

  async function excluirConfirmed() {
    if (!fornDelTarget) return
    setFornDeleting(true)
    await fetch(`/api/fornecedores/${fornDelTarget.id}`, { method: "DELETE" })
    setFornDelTarget(null); setFornDeleting(false)
    onChange()
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle className="flex items-center gap-2"><Building2 className="w-5 h-5 text-primary" /> Fornecedores / Marcas</DialogTitle></DialogHeader>

        {/* Novo fornecedor */}
        <div className="flex gap-2 items-end border-b border-hairline pb-4 px-5 sm:px-6">
          <div className="flex-1 space-y-1">
            <Label className="text-foreground/80 text-xs">Nome do fornecedor *</Label>
            <Input value={nome} onChange={e => setNome(e.target.value)} placeholder="Ex: Control4"
              className="bg-muted border-border text-foreground h-9" />
          </div>
          <div className="w-28 space-y-1">
            <Label className="text-foreground/80 text-xs">Prefixo SKU</Label>
            <Input value={prefixo} onChange={e => setPrefixo(e.target.value.toUpperCase())} placeholder="Auto"
              className="bg-muted border-border text-foreground h-9 font-mono" />
          </div>
          <Button onClick={criar} disabled={saving || !nome.trim()} className="bg-primary hover:bg-primary/90 text-primary-foreground h-9">
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        {/* Filtro: a lista passa de cem marcas e rolar até "Ubiquiti" a cada
            importação era o caminho mais longo até o lápis de editar. */}
        {suppliers.length > 8 && (
          <div className="px-5 sm:px-6 pt-3 pb-3">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Filtrar fornecedor ou prefixo..."
                value={busca}
                onChange={e => setBusca(e.target.value)}
                className="pl-9 pr-9 bg-muted border-border text-foreground placeholder:text-muted-foreground/60 h-9"
              />
              {busca && (
                <button onClick={() => setBusca("")} aria-label="Limpar filtro"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground w-6 h-6 flex items-center justify-center rounded-lg hover:bg-muted">
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* Lista */}
        <div className="space-y-2 max-h-72 overflow-auto px-5 sm:px-6 pb-2">
          {suppliers.length === 0 ? (
            <p className="text-muted-foreground/60 text-sm text-center py-6">Nenhum fornecedor cadastrado ainda.</p>
          ) : visiveis.length === 0 ? (
            <p className="text-muted-foreground/60 text-sm text-center py-6">
              Nenhum fornecedor com &quot;{busca}&quot;.
            </p>
          ) : visiveis.map(s => (
            <div key={s.id} className="flex items-center gap-3 bg-surface-1 border border-hairline rounded-2xl px-4 py-3">
              {editId === s.id ? (
                <div className="flex-1 min-w-0 space-y-2">
                  <div className="flex items-center gap-3">
                    <Input value={editNome} disabled={salvandoEdit} autoFocus
                      onChange={e => setEditNome(e.target.value)}
                      onKeyDown={e => {
                        if (e.key === "Enter") { e.preventDefault(); salvarEdit(s.id) }
                        if (e.key === "Escape") { e.preventDefault(); setEditId(null); setErroEdit("") }
                      }}
                      className="bg-muted border-border text-foreground h-8 flex-1" />
                    <Input value={editPrefixo} disabled={salvandoEdit}
                      onChange={e => setEditPrefixo(e.target.value.toUpperCase())}
                      onKeyDown={e => {
                        if (e.key === "Enter") { e.preventDefault(); salvarEdit(s.id) }
                        if (e.key === "Escape") { e.preventDefault(); setEditId(null); setErroEdit("") }
                      }}
                      className="bg-muted border-border text-foreground h-8 w-24 font-mono" />
                    <Button size="sm" onClick={() => salvarEdit(s.id)} disabled={salvandoEdit}
                      className="rounded-full h-8 gap-1.5">
                      {salvandoEdit ? <><RefreshCw className="h-3.5 w-3.5 animate-spin" /> Salvando</> : "OK"}
                    </Button>
                    <button disabled={salvandoEdit}
                      onClick={() => { setEditId(null); setErroEdit("") }}
                      className="text-muted-foreground hover:text-foreground disabled:opacity-40"><X className="w-4 h-4" /></button>
                  </div>
                  {/* Sem este aviso, a espera de vários segundos parece
                      travamento e a pessoa salva de novo. */}
                  {salvandoEdit && (
                    <p className="text-[12px] text-muted-foreground">
                      Atualizando os {s._count?.products ?? 0} produtos deste fornecedor
                      {editPrefixo !== s.prefixo ? " e renumerando os SKUs" : ""}…
                    </p>
                  )}
                  {erroEdit && <p className="text-[12px] text-ios-red">{erroEdit}</p>}
                </div>
              ) : (
                <>
                  <div className="flex-1 min-w-0">
                    <p className="text-foreground font-medium text-[14px] truncate">{s.nome}</p>
                    <p className="text-[12px] text-muted-fg mt-0.5">
                      <span className="font-mono">{s.prefixo}-</span>
                      <span className="mx-1.5 text-muted-fg/40">·</span>
                      {s._count?.products ?? 0} {(s._count?.products ?? 0) === 1 ? "item" : "itens"}
                    </p>
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <button onClick={() => { setEditId(s.id); setEditNome(s.nome); setEditPrefixo(s.prefixo) }}
                      className="text-muted-foreground hover:text-foreground w-9 h-9 flex items-center justify-center rounded-xl hover:bg-muted active:bg-muted"><Pencil className="w-4 h-4" /></button>
                    <button onClick={() => setFornDelTarget(s)} className="text-muted-foreground hover:text-red-400 w-9 h-9 flex items-center justify-center rounded-xl hover:bg-muted active:bg-muted"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      </DialogContent>

      {/* Confirmação exclusão fornecedor */}
      <Dialog open={!!fornDelTarget} onOpenChange={o => !o && setFornDelTarget(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-400">
              <Trash2 className="w-5 h-5" /> Excluir fornecedor
            </DialogTitle>
          </DialogHeader>
          <p className="px-5 py-4 text-sm text-foreground/80 sm:px-6">
            Excluir <span className="text-foreground font-semibold">&quot;{fornDelTarget?.nome}&quot;</span>?
            <span className="block mt-1 text-muted-foreground/60 text-xs">Os produtos continuam no catálogo, mas ficam sem fornecedor.</span>
          </p>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setFornDelTarget(null)} disabled={fornDeleting}
              className="border-border text-foreground/80">Cancelar</Button>
            <Button onClick={excluirConfirmed} disabled={fornDeleting}
              className="bg-red-600 hover:bg-red-700 text-foreground">
              {fornDeleting ? "Excluindo..." : "Excluir"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Dialog>
  )
}

// ============================================================
// Dialog: Importar produtos via CSV
// ============================================================
// ---- Tabela editável com colunas redimensionáveis por drag ----
type ImportLinha = ReturnType<typeof mapearLinha>
function ResizableImportTable({ linhas, editLinha, removeLinha }: {
  linhas: ImportLinha[]
  editLinha: (idx: number, field: keyof ImportLinha, value: string) => void
  removeLinha: (idx: number) => void
}) {
  const COLS = [
    { key: "sku",         label: "SKU",     align: "left",  init: 90  },
    { key: "nome",        label: "Nome *",  align: "left",  init: 170 },
    { key: "marca",       label: "Marca",   align: "left",  init: 110 },
    { key: "preco_custo", label: "Custo",   align: "right", init: 80  },
    { key: "markup_padrao",label: "Markup%",align: "right", init: 80  },
    { key: "preco_venda", label: "Venda",   align: "right", init: 80  },
    { key: "imagem_url",  label: "URL Imagem", align: "left", init: 150 },
  ] as const

  const [widths, setWidths] = useState<number[]>(COLS.map(c => c.init))
  const dragging = useRef<{ col: number; startX: number; startW: number } | null>(null)

  const onHandleMouseDown = useCallback((colIdx: number, e: React.MouseEvent) => {
    e.preventDefault()
    dragging.current = { col: colIdx, startX: e.clientX, startW: widths[colIdx] }
    const onMove = (mv: MouseEvent) => {
      if (!dragging.current) return
      const delta = mv.clientX - dragging.current.startX
      const newW = Math.max(50, dragging.current.startW + delta)
      setWidths(prev => prev.map((w, i) => i === dragging.current!.col ? newW : w))
    }
    const onUp = () => { dragging.current = null; window.removeEventListener("mousemove", onMove); window.removeEventListener("mouseup", onUp) }
    window.addEventListener("mousemove", onMove)
    window.addEventListener("mouseup", onUp)
  }, [widths])

  return (
    <div className="max-h-64 overflow-auto rounded-2xl border border-border">
      <table style={{ tableLayout: "fixed", width: widths.reduce((a, w) => a + w, 0) + 28 }} className="text-xs">
        <colgroup>
          {widths.map((w, i) => <col key={i} style={{ width: w }} />)}
          <col style={{ width: 28 }} />
        </colgroup>
        <thead className="bg-muted text-muted-foreground sticky top-0 z-10">
          <tr>
            {COLS.map((col, ci) => (
              <th key={col.key} className={`relative px-2 py-2 border-r border-border/60 select-none ${col.align === "right" ? "text-right" : "text-left"}`}>
                {col.label}
                {/* drag handle */}
                <div
                  onMouseDown={e => onHandleMouseDown(ci, e)}
                  className="absolute right-0 top-0 bottom-0 w-2 cursor-col-resize hover:bg-primary/30 transition-colors"
                  title="Arraste para redimensionar"
                />
              </th>
            ))}
            <th className="w-7" />
          </tr>
        </thead>
        <tbody>
          {linhas.map((l, i) => (
            <tr key={i} className="border-t border-border/50 hover:bg-muted/50">
              <td className="px-1 py-1 overflow-hidden">
                <input value={l.sku} onChange={e => editLinha(i, "sku", e.target.value)}
                  placeholder="auto"
                  className="w-full bg-transparent border border-transparent hover:border-border/70 focus:border-primary rounded px-1.5 py-0.5 text-foreground/80 font-mono outline-none placeholder:text-muted-foreground/50" />
              </td>
              <td className="px-1 py-1 overflow-hidden">
                <input value={l.nome} onChange={e => editLinha(i, "nome", e.target.value)}
                  className="w-full bg-transparent border border-transparent hover:border-border/70 focus:border-primary rounded px-1.5 py-0.5 text-foreground outline-none" />
              </td>
              <td className="px-1 py-1 overflow-hidden">
                <input value={l.marca} onChange={e => editLinha(i, "marca", e.target.value)}
                  className="w-full bg-transparent border border-transparent hover:border-border/70 focus:border-primary rounded px-1.5 py-0.5 text-foreground/80 outline-none" />
              </td>
              <td className="px-1 py-1 overflow-hidden">
                <input value={l.preco_custo} onChange={e => editLinha(i, "preco_custo", e.target.value)}
                  className="w-full bg-transparent border border-transparent hover:border-border/70 focus:border-primary rounded px-1.5 py-0.5 text-foreground/80 text-right outline-none" />
              </td>
              <td className="px-1 py-1 overflow-hidden">
                <input value={l.markup_padrao} onChange={e => editLinha(i, "markup_padrao", e.target.value)}
                  className="w-full bg-transparent border border-transparent hover:border-border/70 focus:border-primary rounded px-1.5 py-0.5 text-foreground/80 text-right outline-none" />
              </td>
              <td className="px-1 py-1 overflow-hidden">
                <input value={l.preco_venda} onChange={e => editLinha(i, "preco_venda", e.target.value)}
                  placeholder="auto"
                  className="w-full bg-transparent border border-transparent hover:border-border/70 focus:border-primary rounded px-1.5 py-0.5 text-foreground/80 text-right outline-none placeholder:text-muted-foreground/50" />
              </td>
              <td className="px-1 py-1 overflow-hidden">
                <input value={l.imagem_url} onChange={e => editLinha(i, "imagem_url", e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-transparent border border-transparent hover:border-border/70 focus:border-primary rounded px-1.5 py-0.5 text-foreground/70 outline-none placeholder:text-muted-foreground/40" />
              </td>
              <td className="px-1 py-1 text-center">
                <button onClick={() => removeLinha(i)} className="text-muted-foreground/50 hover:text-red-400 transition-colors">
                  <X className="w-3.5 h-3.5" />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function ImportDialog({ open, onOpenChange, suppliers, onDone }: {
  open: boolean
  onOpenChange: (v: boolean) => void
  suppliers: Supplier[]
  onDone: () => void
}) {
  const [supplierId, setSupplierId] = useState("")
  const [linhas, setLinhas] = useState<ReturnType<typeof mapearLinha>[]>([])
  const [importing, setImporting] = useState(false)
  const [resultado, setResultado] = useState<{ criados: number; ignoradas: string[]; ajustadas?: string[]; fornecedoresCriados?: string[] } | null>(null)
  const [dragging, setDragging] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  function reset() {
    setLinhas([]); setResultado(null); setSupplierId(""); setDragging(false); if (fileRef.current) fileRef.current.value = ""
  }

  function editLinha(idx: number, field: keyof ReturnType<typeof mapearLinha>, value: string) {
    setLinhas(prev => prev.map((l, i) => i === idx ? { ...l, [field]: value } : l))
  }

  function removeLinha(idx: number) {
    setLinhas(prev => prev.filter((_, i) => i !== idx))
  }

  async function processFile(file: File) {
    const texto = await file.text()
    const rows = parseCSV(texto).map(mapearLinha).filter(r => r.nome)
    setLinhas(rows)
    setResultado(null)
  }

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (file) processFile(file)
  }

  function onDrop(e: React.DragEvent) {
    e.preventDefault(); setDragging(false)
    const file = e.dataTransfer.files[0]
    if (file && (file.name.endsWith(".csv") || file.type.includes("csv") || file.type.includes("text"))) processFile(file)
  }

  async function confirmar() {
    setImporting(true)
    try {
      const res = await fetch("/api/produtos/import", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ supplierId: supplierId || null, linhas }),
      })
      const j = await res.json()
      if (res.ok) { setResultado(j); onDone() }
      else showToast(j.error || "Falha ao importar.", { variant: "error" })
    } finally { setImporting(false) }
  }

  function baixarModelo() {
    /* O modelo traz TODAS as colunas aceitas, na ordem do cadastro. Quem só
       tem nome e preço apaga o resto; quem tem a ficha do fornecedor sobe tudo
       de uma vez, em vez de abrir mil e quinhentos produtos depois. */
    const colunas = [
      "sku", "nome", "nome_cliente", "marca", "unidade", "categoria", "descricao", "especificacoes",
      "preco_custo", "markup_padrao", "preco_venda", "imposto_st", "desconto_padrao",
      "ncm", "cest", "origem", "gtin", "cst_icms", "aliquota_icms", "aliquota_ipi",
      "cst_pis", "aliquota_pis", "cst_cofins", "aliquota_cofins",
      "peso_kg", "largura_mm", "altura_mm", "profundidade_mm", "medidas_raw", "ficha_fonte_url",
      "tipo_aplicacao", "formato_medida", "garantia_dias", "estoque_qtd", "estoque_minimo", "imagem_url",
    ]
    const exemplo = [
      "MEU-SKU-01", "Amplificador Triad Mini", "Amplificador de audio", "Control4", "UN", "Home Cinema",
      "Observacoes internas", "8 canais, 50 W por canal",
      "100.00", "40", "", "0", "0",
      "85182900", "", "0", "", "", "", "",
      "", "", "", "",
      "3.4", "430", "44", "300", "430 x 300 x 44 mm (L x P x A)", "https://exemplo.com/ficha",
      "Marcenaria", "Retangulo", "365", "0", "1", "https://exemplo.com/foto.jpg",
    ]
    const linhaVazia = colunas.map(c => c === "nome" ? "Produto so com nome e preco" : c === "preco_custo" ? "50" : c === "markup_padrao" ? "30" : "")
    const escapar = (v: string) => v.includes(",") ? `"${v}"` : v
    const QUEBRA = String.fromCharCode(10)
    const csv = [colunas.join(","), exemplo.map(escapar).join(","), linhaVazia.map(escapar).join(",")].join(QUEBRA) + QUEBRA
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" })
    const a = document.createElement("a")
    a.href = URL.createObjectURL(blob)
    a.download = "modelo-produtos.csv"
    a.click()
  }

  return (
    <Dialog open={open} onOpenChange={v => { onOpenChange(v); if (!v) reset() }}>
      <DialogContent className="max-w-2xl">
        <DialogHeader><DialogTitle className="flex items-center gap-2"><Upload className="w-5 h-5 text-primary" /> Importar produtos (CSV)</DialogTitle></DialogHeader>

        {resultado ? (
          <div className="space-y-3 px-5 sm:px-6 py-4">
            <div className="rounded-2xl bg-green-500/10 border border-green-500/30 px-4 py-3 text-green-300">
              {resultado.criados} produto(s) importado(s) com sucesso!
            </div>
            {resultado.fornecedoresCriados && resultado.fornecedoresCriados.length > 0 && (
              <div className="rounded-2xl bg-ios-green/10 border border-ios-green/30 px-4 py-3 text-ios-green text-sm">
                <p className="font-medium mb-1">{resultado.fornecedoresCriados.length} fornecedor(es)/marca(s) criado(s):</p>
                <p className="text-xs">{resultado.fornecedoresCriados.join(", ")}</p>
              </div>
            )}
            {resultado.ajustadas && resultado.ajustadas.length > 0 && (
              <div className="rounded-2xl bg-ios-blue/10 border border-ios-blue/30 px-4 py-3 text-ios-blue text-sm">
                <p className="font-medium mb-1">{resultado.ajustadas.length} SKU(s) ajustado(s) para não repetir:</p>
                <ul className="list-disc list-inside text-xs space-y-0.5">{resultado.ajustadas.map((m, i) => <li key={i}>{m}</li>)}</ul>
              </div>
            )}
            {resultado.ignoradas.length > 0 && (
              <div className="rounded-2xl bg-amber-500/10 border border-amber-500/30 px-4 py-3 text-amber-300 text-sm">
                <p className="font-medium mb-1">{resultado.ignoradas.length} linha(s) ignorada(s):</p>
                <ul className="list-disc list-inside text-xs space-y-0.5">{resultado.ignoradas.map((m, i) => <li key={i}>{m}</li>)}</ul>
              </div>
            )}
            <Button onClick={() => { reset() }} className="bg-primary hover:bg-primary/90 text-primary-foreground w-full">Importar outro arquivo</Button>
          </div>
        ) : (
          <div className="space-y-4 px-5 sm:px-6 py-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-foreground/80 text-xs">Fornecedor (gera o SKU e a marca)</Label>
                <select value={supplierId} onChange={e => setSupplierId(e.target.value)}
                  className="flex h-9 w-full rounded-xl border border-border bg-muted px-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary">
                  <option value="">Sem fornecedor</option>
                  {suppliers.map(s => <option key={s.id} value={s.id}>{s.nome}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <Label className="text-foreground/80 text-xs">Modelo de planilha</Label>
                <button onClick={baixarModelo}
                  className="flex items-center justify-center gap-1.5 h-9 w-full rounded-xl border border-border bg-muted text-muted-foreground hover:text-foreground text-sm">
                  <Download className="w-4 h-4" /> Baixar modelo CSV
                </button>
              </div>
            </div>

            <label
              onDragOver={e => { e.preventDefault(); setDragging(true) }}
              onDragLeave={() => setDragging(false)}
              onDrop={onDrop}
              className={`flex items-center gap-3 border-2 border-dashed rounded-xl px-4 py-3 cursor-pointer transition-colors ${dragging ? "border-primary bg-primary/10" : "border-border hover:border-primary/60"}`}>
              <Upload className="w-6 h-6 text-muted-foreground/60 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-foreground/80 text-sm font-medium">Clique ou arraste o CSV aqui</p>
                <p className="text-muted-foreground/60 text-xs">
                  Só <span className="text-muted-foreground">nome</span> é obrigatório. Aceita o cadastro
                  inteiro: preço, ficha técnica, medidas, peso, dados fiscais, categoria, garantia e estoque —
                  baixe o modelo para ver todas as colunas. Coluna que faltar fica vazia no produto.
                </p>
              </div>
              <input ref={fileRef} type="file" accept=".csv,text/csv" className="hidden" onChange={onFile} />
            </label>

            {linhas.length > 0 && (
              <>
                <p className="text-muted-foreground text-xs">
                  Revise e edite os dados antes de importar. Clique em qualquer célula para editar.
                  {" "}A tabela mostra só as colunas principais, peso, dimensão, ficha técnica, fiscal e
                  estoque que vieram na planilha vão junto mesmo sem aparecer aqui.
                </p>
                <ResizableImportTable linhas={linhas} editLinha={editLinha} removeLinha={removeLinha} />
                <p className="text-muted-foreground/60 text-xs">{linhas.length} produto(s) prontos para importar. O SKU será gerado automaticamente.</p>
                <Button onClick={confirmar} disabled={importing} className="bg-primary hover:bg-primary/90 text-primary-foreground w-full">
                  {importing ? "Importando..." : `Importar ${linhas.length} produto(s)`}
                </Button>
              </>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}


