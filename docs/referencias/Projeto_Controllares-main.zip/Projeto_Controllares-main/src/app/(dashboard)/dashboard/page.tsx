﻿"use client"

import { useState, useEffect, useMemo } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { ArrowUpRight,
  FileText, Calendar, CheckCircle, Clock, Plus,
  Flag, AlertCircle, HardHat, ClipboardList, TrendingUp, CalendarDays,
} from "lucide-react"
import { Input } from "@/components/ui/input"
import { MonthPicker } from "@/components/month-picker"
import { CartaoMetrica, FaixaMetricas } from "@/components/ui/cartao-metrica"
import { brl } from "@/lib/formato"
import {
  XAxis, YAxis, Tooltip, ResponsiveContainer,
  BarChart, Bar, CartesianGrid,
} from "recharts"


/**
 * As três séries do faturamento, na ordem em que vão empilhadas.
 *
 * A ordem não é estética. Verde e vermelho é justamente o par que mais gente
 * não separa, e amarelo colado no vermelho é o segundo pior; intercalar o verde
 * entre eles é o arranjo em que as três se distinguem nos dois temas. Lida de
 * baixo para cima ela também conta a história certa: o que venceu e não foi
 * pago, o que venceu e foi, o que ainda nem venceu.
 */
const SERIES_FATURAMENTO = [
  { chave: "atrasado" as const,  rotulo: "Atrasado",  cor: "hsl(var(--fin-atrasado))" },
  { chave: "recebido" as const,  rotulo: "Recebido",  cor: "hsl(var(--fin-recebido))" },
  { chave: "a_receber" as const, rotulo: "A receber", cor: "hsl(var(--fin-areceber))" },
]

/**
 * Tooltip do faturamento.
 *
 * O padrão do Recharts lista as séries com valor 0 junto das outras, e num mês
 * em que só houve recebimento isso vira duas linhas de "R$ 0" competindo com a
 * única que interessa. Aqui some o que é zero e aparece o total do mês, que é a
 * conta que a pessoa faria de cabeça olhando a barra.
 */
function TooltipFaturamento(
  { active, payload, label }: {
    active?: boolean
    payload?: { dataKey?: string | number; value?: number }[]
    label?: string
  },
) {
  if (!active || !payload?.length) return null
  const total = payload.reduce((s, p) => s + Number(p.value ?? 0), 0)
  const linhas = SERIES_FATURAMENTO
    .map(serie => ({
      serie,
      valor: Number(payload.find(p => p.dataKey === serie.chave)?.value ?? 0),
    }))
    .filter(l => l.valor > 0)
    .reverse()   // de cima para baixo, como aparecem na barra

  return (
    <div className="rounded-xl border border-border bg-card px-3 py-2 text-xs shadow-lg">
      <p className="font-medium text-foreground mb-1.5">{label}</p>
      {linhas.map(l => (
        <p key={l.serie.chave} className="flex items-center gap-2 text-muted-foreground">
          <span className="w-2 h-2 rounded-sm shrink-0" style={{ background: l.serie.cor }} />
          <span className="flex-1">{l.serie.rotulo}</span>
          <span className="tabular-nums text-foreground">{brl(l.valor)}</span>
        </p>
      ))}
      {linhas.length > 1 && (
        <p className="mt-1.5 pt-1.5 border-t border-border flex items-center gap-2 text-muted-foreground">
          <span className="w-2 shrink-0" />
          <span className="flex-1">Total</span>
          <span className="tabular-nums font-medium text-foreground">{brl(total)}</span>
        </p>
      )}
    </div>
  )
}

interface DashboardMetrics {
  hoje: number
  mes: number
  fechadas: number
  pendentes: number
  pipeline: Array<{ status: string; count: number }>
  faturamento: Array<{ mes: string; recebido: number; atrasado: number; a_receber: number }>
}

interface Tarefa {
  id: string
  titulo: string
  prioridade: "BAIXA" | "MEDIA" | "ALTA"
  categoria: string
  dataVenc: string | null
  concluida: boolean
  atribuido: { nome: string } | null
  obra: { client_name: string } | null
  horaInicio?: string | null
  horaFim?: string | null
  /** Veio do Google Calendar, não da tabela de tarefas. */
  doGoogle?: boolean
}

// ─── Metric Card ─────────────────────────────────────────────────────────────

// ─── Constants ────────────────────────────────────────────────────────────────

const STATUS_LABELS: Record<string, string> = {
  RASCUNHO: "Rascunho",
  ENVIADA: "Enviada",
  LIDA: "Lida",
  EM_REVISAO: "Em Revisão",
  ACEITA: "Aceita",
  EM_FATURAMENTO: "Em Faturamento",
  EM_CONTRATO: "Contrato",
  CONCLUIDA: "Concluída",
  CANCELADA: "Cancelada",
  PROPOSTA_PERDIDA: "Perdida",
}

const STATUS_COLORS: Record<string, string> = {
  RASCUNHO: "#8a8a8a",
  ENVIADA: "#38bdf8",
  LIDA: "#818cf8",
  EM_REVISAO: "#fbbf24",
  ACEITA: "#4ade80",
  EM_FATURAMENTO: "#2dd4bf",
  EM_CONTRATO: "#a78bfa",
  CONCLUIDA: "#22c55e",
  CANCELADA: "#f87171",
  PROPOSTA_PERDIDA: "#f87171",
}

type TarefaAba = "hoje" | "semana" | "mes"

/** Mesmas cores da tela de Agenda, para o ponto do dia bater com o evento lá. */
const CAT_DOT: Record<string, string> = {
  GERAL: "bg-slate-400",
  ADMIN: "bg-purple-400",
  FINANCEIRO: "bg-emerald-400",
  OPERACIONAL: "bg-orange-400",
  COMERCIAL: "bg-sky-400",
  ENGENHARIA: "bg-indigo-400",
}

/**
 * Mini-calendário do mês: cada dia mostra um ponto por categoria de tarefa.
 * Clicar num dia filtra a lista ao lado.
 */
function MiniCalendario({ tarefas, selecionado, onSelecionar }: {
  tarefas: Tarefa[]
  selecionado: string
  onSelecionar: (dia: string) => void
}) {
  const hoje = new Date()
  const ano = hoje.getFullYear()
  const mes = hoje.getMonth()
  const primeiro = new Date(ano, mes, 1)
  const diasNoMes = new Date(ano, mes + 1, 0).getDate()
  // Segunda como primeiro dia da semana (domingo = 0 vira 6).
  const deslocamento = (primeiro.getDay() + 6) % 7
  const hojeIso = isoDate(hoje)

  const porDia = new Map<string, Set<string>>()
  for (const t of tarefas) {
    const d = t.dataVenc?.slice(0, 10)
    if (!d) continue
    if (!porDia.has(d)) porDia.set(d, new Set())
    porDia.get(d)!.add(t.doGoogle ? "AGENDA" : (t.categoria || "GERAL"))
  }

  const celulas: (number | null)[] = [
    ...Array.from({ length: deslocamento }, () => null),
    ...Array.from({ length: diasNoMes }, (_, i) => i + 1),
  ]

  return (
    <div className="border-b border-border/60 px-3 pb-3 pt-2">
      <div className="mb-1.5 grid grid-cols-7 gap-0.5">
        {["S", "T", "Q", "Q", "S", "S", "D"].map((d, i) => (
          <span key={i} className="text-center text-[10px] text-muted-fg">{d}</span>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-0.5">
        {celulas.map((dia, i) => {
          if (dia === null) return <span key={`v${i}`} />
          const iso = `${ano}-${String(mes + 1).padStart(2, "0")}-${String(dia).padStart(2, "0")}`
          const cats = [...(porDia.get(iso) ?? [])]
          const ehHoje = iso === hojeIso
          const ativo = selecionado === iso
          return (
            <button key={iso} onClick={() => onSelecionar(ativo ? "" : iso)}
              className={`flex aspect-square flex-col items-center justify-center rounded-lg text-[11px] transition-colors ${
                ativo ? "bg-foreground text-background"
                  : ehHoje ? "bg-ios-blue/15 font-semibold text-ios-blue"
                    : "text-muted-foreground hover:bg-muted"
              }`}>
              <span className="tabular-nums leading-none">{dia}</span>
              <span className="mt-0.5 flex h-1 items-center gap-0.5">
                {cats.slice(0, 3).map(c => (
                  <span key={c}
                    className={`h-1 w-1 rounded-full ${
                      c === "AGENDA" ? "bg-ios-blue" : (CAT_DOT[c] ?? "bg-slate-400")
                    } ${ativo ? "opacity-90" : ""}`} />
                ))}
              </span>
            </button>
          )
        })}
      </div>
    </div>
  )
}

function isoDate(d: Date) {
  return d.toISOString().slice(0, 10)
}

function startOfWeek(d: Date): Date {
  const day = d.getDay()
  const diff = day === 0 ? -6 : 1 - day
  return new Date(d.getFullYear(), d.getMonth(), d.getDate() + diff)
}

function endOfWeek(d: Date): Date {
  const mon = startOfWeek(d)
  return new Date(mon.getTime() + 6 * 86_400_000)
}

// ─── TarefaRow ────────────────────────────────────────────────────────────────

function TarefaRow({ t }: { t: Tarefa }) {
  const today = isoDate(new Date())
  const vencida = !!(t.dataVenc && t.dataVenc.slice(0, 10) < today)
  return (
    <Link href="/agenda"
      className={`flex items-center gap-3 p-2.5 rounded-xl border transition-colors hover:border-border spring-fade ${
        vencida ? "border-destructive/20 bg-destructive/5" : "border-border/50 bg-muted/30"
      }`}>
      {/* Compromisso do Google usa ícone de calendário: prioridade não se
          aplica a ele, e a distinção evita confundir com tarefa do sistema. */}
      {t.doGoogle ? (
        <CalendarDays className="w-3 h-3 flex-shrink-0 text-ios-blue" />
      ) : (
        <Flag className={`w-3 h-3 flex-shrink-0 ${
          t.prioridade === "ALTA" ? "text-red-500" : t.prioridade === "MEDIA" ? "text-amber-500" : "text-muted-foreground/40"
        }`} />
      )}
      <span className="flex-1 text-sm text-foreground truncate">
        {t.horaInicio && <span className="text-muted-foreground tabular-nums">{t.horaInicio} </span>}
        {t.titulo}
      </span>
      {t.obra && (
        <span className="text-xs text-orange-500/70 truncate max-w-[90px] hidden sm:block">
          {t.obra.client_name}
        </span>
      )}
      {t.dataVenc && (
        <span className={`text-xs flex items-center gap-1 flex-shrink-0 ${vencida ? "text-destructive" : "text-muted-foreground"}`}>
          {vencida && <AlertCircle className="w-3 h-3" />}
          {new Date(t.dataVenc.slice(0, 10) + "T00:00:00").toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })}
        </span>
      )}
    </Link>
  )
}

// ─── Main Dashboard ───────────────────────────────────────────────────────────

export default function DashboardPage() {
  const router = useRouter()
  const [role, setRole] = useState<string | null>(null)
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null)
  const [firstName, setFirstName] = useState("")
  const [loading, setLoading] = useState(true)
  const [filterCliente, setFilterCliente] = useState("")
  const [filterObra, setFilterObra] = useState("")
  const [diaSelecionado, setDiaSelecionado] = useState("")
  const [filterMes, setFilterMes] = useState("")
  const [tarefas, setTarefas] = useState<Tarefa[]>([])
  const [tarefaAba, setTarefaAba] = useState<TarefaAba>("hoje")

  useEffect(() => {
    // A agenda mistura tarefas do sistema com compromissos do Google Calendar.
    // O painel só lia as tarefas, então um compromisso marcado para hoje não
    // aparecia aqui — só na tela de Agenda.
    const hoje = new Date()
    const ini = new Date(hoje.getFullYear(), hoje.getMonth(), 1).toISOString()
    const fim = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0, 23, 59, 59).toISOString()

    Promise.all([
      fetch("/api/dashboard").then(r => r.json()),
      fetch("/api/auth/me").then(r => r.json()),
      fetch("/api/tarefas?concluida=false&limit=100").then(r => r.ok ? r.json() : { tarefas: [] }),
      fetch(`/api/integracoes/google/events?start=${ini}&end=${fim}`)
        .then(r => r.ok ? r.json() : { eventos: [] }).catch(() => ({ eventos: [] })),
    ]).then(([dash, me, tf, gc]) => {
      const userRole: string = me?.user?.role ?? ""
      setRole(userRole)
      if (userRole === "INSTALADOR") { router.replace("/minha-area"); return }
      setMetrics(dash)
      if (me?.user?.nome) setFirstName(me.user.nome.split(" ")[0])

      // Compromissos do Google entram na mesma lista, no formato de tarefa,
      // para caírem nos mesmos filtros de hoje/semana/mês.
      const doGoogle: Tarefa[] = (gc?.eventos ?? []).map((e: {
        id: string; titulo: string; data: string; horaInicio: string | null; horaFim: string | null
      }) => ({
        id: `gcal-${e.id}`,
        titulo: e.titulo,
        prioridade: "MEDIA",
        categoria: "GERAL",
        concluida: false,
        dataVenc: e.data,
        horaInicio: e.horaInicio,
        horaFim: e.horaFim,
        obra: null,
        atribuido: null,
        doGoogle: true,
      })) as Tarefa[]

      setTarefas([...(tf.tarefas || []), ...doGoogle])
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [router])

  // ─── Tarefas filtradas por aba + cliente ─────────────────────────────────

  const today = isoDate(new Date())
  const monStr = isoDate(startOfWeek(new Date()))
  const sunStr = isoDate(endOfWeek(new Date()))
  const mesAtual = today.slice(0, 7)

  const tarefasHoje = useMemo(
    () => tarefas.filter(t => t.dataVenc?.slice(0, 10) === today),
    [tarefas, today]
  )
  const tarefasSemana = useMemo(
    () => tarefas.filter(t => { const d = t.dataVenc?.slice(0, 10); return !!d && d >= monStr && d <= sunStr }),
    [tarefas, monStr, sunStr]
  )
  const tarefasMes = useMemo(
    () => tarefas.filter(t => { const d = t.dataVenc?.slice(0, 10); return !d || d.slice(0, 7) === mesAtual }),
    [tarefas, mesAtual]
  )

  const tarefasPorAba = tarefaAba === "hoje" ? tarefasHoje : tarefaAba === "semana" ? tarefasSemana : tarefasMes

  // Obras que têm ao menos uma tarefa — viram os atalhos de filtro.
  const obrasComTarefa = useMemo(
    () => [...new Set(tarefas.map(t => t.obra?.client_name).filter(Boolean) as string[])]
      .sort((a, b) => a.localeCompare(b, "pt-BR")),
    [tarefas]
  )

  const tarefasFiltradas = useMemo(() => {
    // Dia escolhido no calendário tem prioridade sobre a aba hoje/semana/mês.
    let lista = diaSelecionado
      ? tarefas.filter(t => t.dataVenc?.slice(0, 10) === diaSelecionado)
      : tarefasPorAba
    if (filterObra) lista = lista.filter(t => t.obra?.client_name === filterObra)
    if (!filterCliente.trim()) return lista
    const q = filterCliente.toLowerCase()
    return lista.filter(t =>
      t.titulo.toLowerCase().includes(q) ||
      (t.obra?.client_name ?? "").toLowerCase().includes(q)
    )
  }, [tarefasPorAba, tarefas, filterCliente, filterObra, diaSelecionado])

  // ─── Pipeline ────────────────────────────────────────────────────────────

  const faturamento = metrics?.faturamento ?? []
  const totalRecebido = faturamento.reduce((t, m) => t + m.recebido, 0)
  const totalFaturamento = faturamento.reduce(
    (t, m) => t + m.recebido + m.atrasado + m.a_receber, 0)
  const semFaturamento = totalFaturamento === 0

  const pipelineData = (metrics?.pipeline ?? []).map(p => ({
    /* Fallback era `p.status.replace(/_/g, " ")`, que devolvia o enum em
       caixa alta e sem acento — "CONCLUIDA" no meio de "Contrato" e
       "Rascunho". Se algum status novo escapar do mapa, pelo menos sai
       capitalizado e não grita. */
    status: STATUS_LABELS[p.status]
      ?? p.status.replace(/_/g, " ").toLowerCase().replace(/^./, c => c.toUpperCase()),
    statusRaw: p.status,
    count: p.count,
    fill: STATUS_COLORS[p.status] ?? "#64748b",
  }))

  // ─── Skeleton ────────────────────────────────────────────────────────────

  if (loading) {
    return (
      <div className="p-6 space-y-6 animate-pulse">
        <div className="h-7 bg-muted rounded-xl w-56" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-24 ios-card" />
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 space-y-4">
            <div className="h-56 ios-card" />
            <div className="h-56 ios-card" />
          </div>
          <div className="h-[28rem] ios-card" />
        </div>
      </div>
    )
  }

  // ─── Operacional (RT / Eng.) ──────────────────────────────────────────────

  if (role === "RESPONSAVEL_TECNICO" || role === "ENGENHEIRO_PROJETOS") {
    return (
      <DashboardOperacional
        firstName={firstName}
        tarefas={tarefas}
        tarefaAba={tarefaAba}
        setTarefaAba={setTarefaAba}
      />
    )
  }

  const todayLabel = new Date().toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" })

  return (
    <div className="p-4 md:p-6 space-y-4 md:space-y-5 pb-20">

      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold text-foreground">Olá, {firstName || "usuário"}</h1>
          <p className="text-muted-foreground text-sm mt-0.5 capitalize">{todayLabel}</p>
        </div>
        <Link href="/propostas/nova"
          className="ios-tap flex items-center gap-2 h-9 px-4 rounded-full bg-primary hover:bg-primary/90 text-primary-foreground text-sm font-medium flex-shrink-0 shadow-sm">
          <Plus className="w-4 h-4" />
          Nova Proposta
        </Link>
      </div>

      {/* Metric Cards, clicáveis, cor por tipo */}
      <FaixaMetricas>
        <CartaoMetrica
          rotulo="Hoje"
          valor={metrics?.hoje ?? 0}
          icone={FileText}
          href="/propostas"
        />
        <CartaoMetrica
          rotulo="No Mês"
          valor={metrics?.mes ?? 0}
          icone={Calendar}
          href={`/propostas?mes=${today.slice(0, 7)}`}
        />
        <CartaoMetrica
          rotulo="Fechadas"
          valor={metrics?.fechadas ?? 0}
          icone={CheckCircle}
          href="/propostas?status=ACEITA"
        />
        <CartaoMetrica
          rotulo="Pendentes"
          valor={metrics?.pendentes ?? 0}
          icone={Clock}
          href="/propostas?status=ENVIADA"
        />
      </FaixaMetricas>

      {/* Bento grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

        {/* Charts, 2/3 */}
        <div className="lg:col-span-2 space-y-4">

          {/* Pipeline */}
          <div className="ios-card p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-muted-foreground/50" strokeWidth={1.5} />
                <h3 className="font-semibold text-foreground text-sm">Pipeline de Vendas</h3>
              </div>
              <Link href="/propostas" className="text-xs text-muted-foreground hover:text-foreground transition-colors">
                Ver propostas →
              </Link>
            </div>
            {/* Barras horizontais: o nome do estágio fica legível sem girar o
                texto, e a contagem aparece ao lado — mais direto que o gráfico
                de colunas, que só mostrava o número passando o mouse. */}
            {pipelineData.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-40 gap-2">
                <ClipboardList className="w-8 h-8 text-muted-foreground/20" />
                <p className="text-muted-foreground text-sm">Nenhum dado disponível</p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {pipelineData.map(d => {
                  const maior = Math.max(...pipelineData.map(x => x.count), 1)
                  const pct = Math.max(4, (d.count / maior) * 100)
                  return (
                    <Link key={d.status} href={`/propostas?status=${d.statusRaw}`}
                      className="group flex items-center gap-3">
                      <span className="w-28 shrink-0 truncate text-xs text-muted-foreground">{d.status}</span>
                      <span className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                        <span className="block h-full rounded-full transition-all duration-500"
                          style={{ width: `${pct}%`, backgroundColor: d.fill }} />
                      </span>
                      <span className="w-7 shrink-0 text-right text-sm font-semibold tabular-nums text-foreground">
                        {d.count}
                      </span>
                    </Link>
                  )
                })}
              </div>
            )}
          </div>

          {/* Faturamento */}
          <div className="ios-card p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold text-foreground text-sm">Faturamento Mensal</h3>
                {/* O total dos seis meses no cabeçalho: quem abre o painel quer
                    um número antes de querer a distribuição. */}
                <p className="text-xs text-muted-foreground mt-0.5">
                  {brl(totalFaturamento)} em 6 meses · {brl(totalRecebido)} recebido
                </p>
              </div>
              <MonthPicker value={filterMes} onChange={setFilterMes} placeholder="Todos os meses" />
            </div>

            {/* Legenda antes do gráfico, sempre visível.
                Três séries não podem se distinguir só pela cor — verde e
                vermelho são justamente o par que mais gente não separa. O nome
                ao lado do quadradinho resolve isso, e a mesma informação
                aparece de novo no tooltip. */}
            <div className="flex flex-wrap gap-x-4 gap-y-1 mb-3">
              {SERIES_FATURAMENTO.map(s => (
                <span key={s.chave} className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                  <span className="w-2.5 h-2.5 rounded-sm" style={{ background: s.cor }} />
                  {s.rotulo}
                </span>
              ))}
            </div>

            {semFaturamento ? (
              <div className="flex flex-col items-center justify-center h-40 gap-2">
                <Calendar className="w-8 h-8 text-muted-foreground/20" />
                <p className="text-muted-foreground text-sm">Nenhum dado disponível</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={210}>
                <BarChart data={metrics?.faturamento ?? []} margin={{ top: 8, right: 8, left: -12, bottom: 4 }} barCategoryGap="28%">
                  <CartesianGrid horizontal vertical={false} stroke="hsl(var(--border))" strokeOpacity={0.4} />
                  <XAxis
                    dataKey="mes"
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                    axisLine={false}
                    tickLine={false}
                    width={52}
                    tickFormatter={v => v >= 1000 ? `${(v / 1000).toFixed(0)}k` : String(v)}
                  />
                  <Tooltip
                    /* Realce da coluna inteira, não uma linha vertical: com
                       barra, o alvo do cursor é o mês. */
                    cursor={{ fill: "hsl(var(--foreground))", fillOpacity: 0.06 }}
                    content={<TooltipFaturamento />}
                  />
                  {/* Barra empilhada: a altura é o total do mês e cada faixa
                      mostra de que ele é feito. Canto arredondado só na última
                      série, que é a que fecha o topo da pilha. */}
                  {SERIES_FATURAMENTO.map((serie, i) => (
                    <Bar
                      key={serie.chave}
                      dataKey={serie.chave}
                      stackId="fat"
                      fill={serie.cor}
                      maxBarSize={56}
                      radius={i === SERIES_FATURAMENTO.length - 1 ? [5, 5, 0, 0] : undefined}
                    />
                  ))}
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Tasks panel, 1/3 */}
        <div className="ios-card overflow-hidden flex flex-col">
          <div className="flex items-center justify-between px-5 py-4 border-b border-border/60">
            <div>
              <h3 className="font-semibold text-foreground text-sm">Tarefas</h3>
              <p className="text-muted-foreground text-[11px] mt-0.5">
                {tarefasHoje.length} hoje · {tarefasSemana.length} semana
              </p>
            </div>
            <Link href="/agenda" className="text-[11px] text-muted-foreground hover:text-foreground transition-colors">
              Ver agenda →
            </Link>
          </div>

          <MiniCalendario tarefas={tarefas} selecionado={diaSelecionado} onSelecionar={setDiaSelecionado} />

          {/* Tabs */}
          <div className="flex border-b border-border/60">
            {(["hoje", "semana", "mes"] as TarefaAba[]).map(aba => {
              const labels = { hoje: "Hoje", semana: "Semana", mes: "Mês" }
              const counts = { hoje: tarefasHoje.length, semana: tarefasSemana.length, mes: tarefasMes.length }
              return (
                <button key={aba} onClick={() => setTarefaAba(aba)}
                  className={`flex-1 py-2 text-xs font-medium transition-all border-b-2 flex items-center justify-center gap-1 ${
                    tarefaAba === aba
                      ? "border-foreground text-foreground"
                      : "border-transparent text-muted-foreground hover:text-foreground"
                  }`}>
                  {labels[aba]}
                  {counts[aba] > 0 && (
                    <span className={`text-[10px] rounded-full px-1 tabular-nums ${
                      tarefaAba === aba ? "bg-foreground/10" : "bg-muted"
                    }`}>
                      {counts[aba]}
                    </span>
                  )}
                </button>
              )
            })}
          </div>

          {/* Lista */}
          <div className="flex-1 overflow-y-auto p-3 space-y-1" style={{ scrollbarWidth: "none" }}>
            {tarefasFiltradas.length === 0 ? (
              <div className="text-center py-10">
                <CheckCircle className="w-7 h-7 text-muted-foreground/20 mx-auto mb-2" />
                <p className="text-muted-foreground text-xs">
                  {filterCliente ? "Nenhuma tarefa para esse filtro" : "Sem tarefas"}
                </p>
              </div>
            ) : (
              <>
                {tarefasFiltradas.slice(0, 12).map(t => <TarefaRow key={t.id} t={t} />)}
                {tarefasFiltradas.length > 12 && (
                  <Link href="/agenda" className="block text-center text-xs text-muted-foreground hover:text-foreground py-2 transition-colors">
                    +{tarefasFiltradas.length - 12} mais
                  </Link>
                )}
              </>
            )}
          </div>

          {/* Filtro: seletor de obra (as obras que têm tarefa) + busca livre.
              Antes só dava para digitar, então era preciso lembrar o nome. */}
          <div className="space-y-2 border-t border-border/60 px-3 pb-3 pt-2">
            {obrasComTarefa.length > 0 && (
              <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 no-scrollbar">
                <button onClick={() => setFilterObra("")}
                  className={`h-7 shrink-0 rounded-full px-3 text-[11px] font-medium transition-colors ${
                    filterObra === "" ? "bg-foreground text-background" : "bg-muted text-muted-fg hover:text-foreground"
                  }`}>
                  Todas
                </button>
                {obrasComTarefa.map(nome => (
                  <button key={nome} onClick={() => setFilterObra(nome)}
                    className={`h-7 shrink-0 whitespace-nowrap rounded-full px-3 text-[11px] font-medium transition-colors ${
                      filterObra === nome ? "bg-foreground text-background" : "bg-muted text-muted-fg hover:text-foreground"
                    }`}>
                    {nome}
                  </button>
                ))}
              </div>
            )}
            <Input
              placeholder="Filtrar tarefa ou cliente..."
              value={filterCliente}
              onChange={e => setFilterCliente(e.target.value)}
              className="h-8 text-xs"
            />
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Dashboard Operacional ────────────────────────────────────────────────────

function DashboardOperacional({ firstName, tarefas, tarefaAba, setTarefaAba }: {
  firstName: string
  tarefas: Tarefa[]
  tarefaAba: TarefaAba
  setTarefaAba: (a: TarefaAba) => void
}) {
  const [obras, setObras] = useState<Array<{
    id: string
    client_name: string
    etapa: string | null
    physical_progress_percentage: number
    logistics_status: string
    pendencia_ambiente: boolean
  }>>([])

  useEffect(() => {
    fetch("/api/obras")
      .then(r => r.ok ? r.json() : { obras: [] })
      .then(d => setObras(d.obras ?? []))
  }, [])

  const hoje = isoDate(new Date())
  const monStr = isoDate(startOfWeek(new Date()))
  const sunStr = isoDate(endOfWeek(new Date()))

  const tarefasHoje = useMemo(
    () => tarefas.filter(t => t.dataVenc?.slice(0, 10) === hoje),
    [tarefas, hoje]
  )
  const tarefasAtrasadas = useMemo(
    () => tarefas.filter(t => t.dataVenc && t.dataVenc.slice(0, 10) < hoje),
    [tarefas, hoje]
  )
  const tarefasSemana = useMemo(
    () => tarefas.filter(t => { const d = t.dataVenc?.slice(0, 10); return !!d && d >= monStr && d <= sunStr }),
    [tarefas, monStr, sunStr]
  )

  const listaAtual = tarefaAba === "hoje" ? tarefasHoje : tarefaAba === "semana" ? tarefasSemana : tarefas

  return (
    <div className="p-5 md:p-6 space-y-5 md:space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground tracking-tight flex items-center gap-2">
          <HardHat className="w-6 h-6 text-amber-500" /> Olá, {firstName || "usuário"}
        </h1>
        <p className="text-muted-foreground mt-1 text-[15px]">Painel Operacional</p>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="ios-card p-4 text-center spring-pop">
          <p className="text-3xl font-black text-amber-500">{obras.length}</p>
          <p className="text-muted-foreground text-xs mt-1">Obras ativas</p>
        </div>
        <div className="ios-card p-4 text-center spring-pop">
          <p className="text-3xl font-black text-primary">{tarefasHoje.length}</p>
          <p className="text-muted-foreground text-xs mt-1">Tarefas hoje</p>
        </div>
        <div className="ios-card p-4 text-center spring-pop">
          <p className="text-3xl font-black text-destructive">{tarefasAtrasadas.length}</p>
          <p className="text-muted-foreground text-xs mt-1">Atrasadas</p>
        </div>
      </div>

      {obras.length > 0 && (
        <div className="ios-card p-4 space-y-3">
          <h2 className="text-[13px] font-semibold uppercase tracking-wider text-muted-foreground/60 flex items-center gap-2">
            <HardHat className="w-3.5 h-3.5 text-amber-500" /> Suas obras
          </h2>
          <div className="space-y-1.5">
            {obras.slice(0, 5).map(o => (
              <Link key={o.id} href={`/obras/${o.id}`}
                className="flex items-center gap-3 p-3 rounded-xl border border-border/60 bg-muted/30 hover:bg-muted/60 transition-colors active:scale-[0.99]">
                <div className="flex-1 min-w-0 flex items-center gap-2">
                  {/* Produto sincronizado da proposta sem ambiente físico
                      atribuído. Isso é obrigatório — o aviso fica até
                      alguém organizar em Engenharia · Ambientes/Produtos. */}
                  {o.pendencia_ambiente && (
                    <span title="Tem produto sem ambiente definido, organize em Engenharia · Ambientes/Produtos">
                      <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0" />
                    </span>
                  )}
                  <div className="min-w-0">
                    <p className="text-[14px] text-foreground truncate font-medium">{o.client_name}</p>
                    <p className="text-xs text-muted-foreground">{o.etapa ?? "-"}</p>
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-xs text-primary font-semibold">{o.physical_progress_percentage}%</p>
                  <p className="text-[10px] text-muted-foreground">{o.logistics_status}</p>
                </div>
              </Link>
            ))}
          </div>
          {obras.length > 5 && (
            <Link href="/operacional" className="text-xs text-primary hover:text-primary/80 font-medium">
              Ver todas ({obras.length}) →
            </Link>
          )}
        </div>
      )}

      <div className="ios-card p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-[13px] font-semibold uppercase tracking-wider text-muted-foreground/60 flex items-center gap-2">
            <ClipboardList className="w-3.5 h-3.5 text-primary" /> Tarefas
          </h2>
          <div className="flex gap-1 bg-muted rounded-2xl p-0.5">
            {(["hoje", "semana", "mes"] as TarefaAba[]).map(a => (
              <button key={a} onClick={() => setTarefaAba(a)}
                className={`text-xs px-2.5 py-1 rounded-xl transition-all ${
                  tarefaAba === a ? "bg-card shadow-sm text-foreground font-medium" : "text-muted-foreground hover:text-foreground"
                }`}>
                {a === "hoje" ? "Hoje" : a === "semana" ? "Pendentes" : "Todas"}
              </button>
            ))}
          </div>
        </div>
        {listaAtual.length === 0 ? (
          <p className="text-muted-foreground text-sm py-4 text-center">Nenhuma tarefa neste período</p>
        ) : (
          <div className="space-y-1.5">
            {listaAtual.slice(0, 8).map(t => <TarefaRow key={t.id} t={t} />)}
          </div>
        )}
        <Link href="/agenda" className="text-xs text-primary hover:text-primary/80 block pt-1 font-medium">
          Ver agenda completa →
        </Link>
      </div>
    </div>
  )
}
