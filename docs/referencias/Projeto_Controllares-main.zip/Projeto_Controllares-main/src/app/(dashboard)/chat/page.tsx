"use client"

import { useEffect, useMemo, useRef, useState } from "react"
import { ArrowLeft, Check, CheckCheck, Mic, Paperclip, Send, Square, Play, Pause, Search, ClipboardList, ChevronDown, RefreshCw } from "lucide-react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { MOCK_CONVERSATIONS, type ChatConversation, type ChatMessage, type HandoffSummary } from "@/lib/chat-mock"
import type { WacrmConversation, WacrmMessage } from "@/lib/wacrm"

const HORA = (iso: string) => new Date(iso).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })

/** Conversa do wacrm → forma que a tela já sabia desenhar (era o mock). */
function paraChatConversation(c: WacrmConversation): ChatConversation {
  const nome = c.contact?.name?.trim() || c.contact?.phone || "Sem nome"
  return {
    id: c.id,
    contactName: nome,
    contactPhone: c.contact?.phone ?? "",
    avatarInitial: nome.charAt(0).toUpperCase(),
    setor: c.status === "open" ? "Em aberto" : c.status === "pending" ? "Pendente" : "Fechada",
    lastMessage: c.last_message_text ?? "",
    lastMessageAt: c.last_message_at ? HORA(c.last_message_at) : "",
    unread: c.unread_count ?? 0,
    messages: [],
  }
}

function paraChatMessage(m: WacrmMessage): ChatMessage {
  const contentType: ChatMessage["contentType"] =
    m.content_type === "audio" ? "audio" : m.content_type === "text" ? "text" : "text"
  return {
    id: m.id,
    direction: m.direction,
    contentType,
    text: m.content_text ?? undefined,
    status: m.status === "read" ? "read" : m.status === "delivered" ? "delivered" : "sent",
    createdAt: HORA(m.created_at),
    _previewUrl: m.content_type === "audio" ? (m.media_url ?? undefined) : undefined,
  }
}

/**
 * Chat — conectado ao wacrm de verdade via `/api/chat/*` (que usa
 * `src/lib/wacrm.ts` no servidor; a API key do wacrm nunca chega aqui).
 * Layout mobile-first porque é onde mais vai ser usado: lista em tela
 * cheia, toca numa conversa e a conversa some a lista (padrão WhatsApp),
 * volta com a seta.
 */
export default function ChatPage() {
  const [conversas, setConversas] = useState<ChatConversation[]>([])
  const [selecionadaId, setSelecionadaId] = useState<string | null>(null)
  const [busca, setBusca] = useState("")
  const [carregando, setCarregando] = useState(true)
  const [usandoMock, setUsandoMock] = useState(false)

  /* Enquanto o wacrm não estiver configurado (WACRM_API_URL/WACRM_API_KEY),
     cai no dado fictício em vez de mostrar tela de erro — é o que a pessoa
     pediu pra manter "por enquanto que está assim". Quando as variáveis
     existirem de verdade, isso troca sozinho pro dado real, sem precisar
     mexer em código de novo. */
  async function carregarConversas() {
    setCarregando(true)
    try {
      const r = await fetch("/api/chat/conversations", { cache: "no-store" })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { setConversas(MOCK_CONVERSATIONS); setUsandoMock(true); return }
      setConversas((j.data ?? []).map(paraChatConversation))
      setUsandoMock(false)
    } catch {
      setConversas(MOCK_CONVERSATIONS)
      setUsandoMock(true)
    } finally {
      setCarregando(false)
    }
  }
  useEffect(() => { carregarConversas() }, [])

  const selecionada = useMemo(
    () => conversas.find((c) => c.id === selecionadaId) ?? null,
    [conversas, selecionadaId],
  )

  const filtradas = useMemo(() => {
    const q = busca.trim().toLowerCase()
    if (!q) return conversas
    return conversas.filter(
      (c) => c.contactName.toLowerCase().includes(q) || c.setor.toLowerCase().includes(q),
    )
  }, [conversas, busca])

  return (
    <div className="flex h-[calc(100dvh-var(--header-h,0px))] min-h-0 overflow-hidden rounded-[var(--radius-lg)] border border-border bg-card md:h-[calc(100dvh-7rem)]">
      {/* Lista de conversas, some no mobile quando uma conversa está aberta. */}
      <aside
        className={cn(
          "flex w-full flex-col border-border md:w-[340px] md:shrink-0 md:border-r",
          selecionada && "hidden md:flex",
        )}
      >
        <div className="flex items-center justify-between border-b border-border px-4 py-3.5">
          <h1 className="text-[15px] font-semibold">Chat</h1>
          {carregando ? (
            <RefreshCw className="h-3.5 w-3.5 animate-spin text-muted-foreground" />
          ) : usandoMock ? (
            <Badge variant="secondary" className="text-[11px] font-normal text-muted-foreground">
              pré-visualização
            </Badge>
          ) : null}
        </div>
        <div className="border-b border-border p-2.5">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              placeholder="Buscar conversa"
              className="h-9 pl-9 text-[13px]"
            />
          </div>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto">
          {filtradas.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelecionadaId(c.id)}
              className={cn(
                "flex w-full items-start gap-3 border-b border-border/60 px-4 py-3 text-left transition-colors hover:bg-accent",
                selecionadaId === c.id && "bg-accent",
              )}
            >
              <Avatar className="h-11 w-11 shrink-0">
                <AvatarFallback className="text-[13px]">{c.avatarInitial}</AvatarFallback>
              </Avatar>
              <div className="min-w-0 flex-1">
                <div className="flex items-baseline justify-between gap-2">
                  <span className="truncate text-[13.5px] font-medium">{c.contactName}</span>
                  <span className="shrink-0 text-[11px] text-muted-foreground">{c.lastMessageAt}</span>
                </div>
                <div className="mt-0.5 flex items-center justify-between gap-2">
                  <span className="truncate text-[12.5px] text-muted-foreground">{c.lastMessage}</span>
                  {c.unread > 0 && (
                    <span className="flex h-5 min-w-5 shrink-0 items-center justify-center rounded-full bg-primary px-1.5 text-[10.5px] font-semibold text-primary-foreground">
                      {c.unread}
                    </span>
                  )}
                </div>
                <span className="mt-1 inline-block rounded-full bg-secondary px-2 py-0.5 text-[10.5px] text-secondary-foreground">
                  {c.setor}
                </span>
              </div>
            </button>
          ))}
        </div>
      </aside>

      {/* Painel da conversa. */}
      <section className={cn("flex min-h-0 flex-1 flex-col", !selecionada && "hidden md:flex")}>
        {selecionada ? (
          <Thread conversa={selecionada} onVoltar={() => setSelecionadaId(null)} usandoMock={usandoMock} />
        ) : (
          <div className="flex flex-1 items-center justify-center text-[13px] text-muted-foreground">
            Selecione uma conversa
          </div>
        )}
      </section>
    </div>
  )
}

function Thread({ conversa, onVoltar, usandoMock }: { conversa: ChatConversation; onVoltar: () => void; usandoMock: boolean }) {
  const [mensagens, setMensagens] = useState<ChatMessage[]>(usandoMock ? conversa.messages : [])
  const [carregandoMsgs, setCarregandoMsgs] = useState(!usandoMock)
  const [texto, setTexto] = useState("")
  const [enviando, setEnviando] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (usandoMock) { setMensagens(conversa.messages); return }
    let cancelado = false
    setCarregandoMsgs(true)
    fetch(`/api/chat/conversations/${conversa.id}/messages`, { cache: "no-store" })
      .then((r) => r.json())
      .then((j) => {
        if (cancelado) return
        // A API devolve mais recente primeiro; a tela mostra mais antiga primeiro.
        const lista = (j.data ?? []).slice().reverse().map(paraChatMessage)
        setMensagens(lista)
      })
      .finally(() => { if (!cancelado) setCarregandoMsgs(false) })
    return () => { cancelado = true }
  }, [conversa.id, usandoMock, conversa.messages])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight })
  }, [mensagens])

  async function enviarTexto() {
    const t = texto.trim()
    if (!t || !conversa.contactPhone || enviando) return
    setTexto("")
    setEnviando(true)
    const otimista: ChatMessage = {
      id: `local-${Date.now()}`,
      direction: "outbound",
      contentType: "text",
      text: t,
      status: "sent",
      createdAt: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
    }
    setMensagens((prev) => [...prev, otimista])
    if (usandoMock) { setEnviando(false); return }
    try {
      const r = await fetch(`/api/chat/conversations/${conversa.id}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ to: conversa.contactPhone, text: t }),
      })
      if (!r.ok) {
        const j = await r.json().catch(() => ({}))
        setMensagens((prev) => prev.filter((m) => m.id !== otimista.id))
        setTexto(t)
        alert(j.error ?? "Não consegui enviar a mensagem.")
      }
    } catch {
      setMensagens((prev) => prev.filter((m) => m.id !== otimista.id))
      setTexto(t)
      alert("Falha de conexão ao enviar.")
    } finally {
      setEnviando(false)
    }
  }

  function enviarAudio(durationSec: number, blobUrl: string) {
    setMensagens((prev) => [
      ...prev,
      {
        id: `local-${Date.now()}`,
        direction: "outbound",
        contentType: "audio",
        audioDurationSec: durationSec,
        status: "sent",
        createdAt: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
        _previewUrl: blobUrl,
      },
    ])
  }

  return (
    <>
      <div className="flex items-center gap-3 border-b border-border px-3 py-2.5 md:px-4">
        <Button variant="ghost" size="icon" className="md:hidden" onClick={onVoltar}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <Avatar className="h-9 w-9">
          <AvatarFallback className="text-[12px]">{conversa.avatarInitial}</AvatarFallback>
        </Avatar>
        <div className="min-w-0 flex-1">
          <div className="truncate text-[13.5px] font-medium">{conversa.contactName}</div>
          <div className="truncate text-[11.5px] text-muted-foreground">{conversa.contactPhone}</div>
        </div>
        <Badge variant="secondary" className="text-[11px] font-normal">
          {conversa.setor}
        </Badge>
      </div>

      {conversa.handoffSummary && <HandoffSummaryBanner resumo={conversa.handoffSummary} />}

      <div
        ref={scrollRef}
        className="min-h-0 flex-1 overflow-y-auto px-3 py-4 md:px-6"
        style={{
          backgroundImage:
            "radial-gradient(circle at 1px 1px, hsl(var(--border)) 1px, transparent 0)",
          backgroundSize: "22px 22px",
          backgroundColor: "hsl(var(--background))",
        }}
      >
        <div className="mx-auto flex max-w-2xl flex-col gap-1.5">
          {mensagens.map((m) => (
            <Bubble key={m.id} m={m} />
          ))}
        </div>
      </div>

      <Composer onEnviarTexto={enviarTexto} texto={texto} onTextoChange={setTexto} onEnviarAudio={enviarAudio} />
    </>
  )
}

/**
 * O que a migration 042 (reset de visibilidade) mais tira do atendente:
 * contexto de um atendimento anterior seu com o mesmo cliente. Isso
 * reaparece aqui porque foi gerado por IA e salvo (handoff_summaries) no
 * exato momento em que a conversa saiu das suas mãos — antes do reset
 * apagar o histórico da sua visão.
 */
function HandoffSummaryBanner({ resumo }: { resumo: HandoffSummary }) {
  const [aberto, setAberto] = useState(true)
  return (
    <div className="border-b border-amber-500/25 bg-amber-500/[0.07] px-3 py-2.5 md:px-4">
      <button
        onClick={() => setAberto((v) => !v)}
        className="flex w-full items-center gap-2 text-left"
      >
        <ClipboardList className="h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
        <span className="flex-1 text-[12.5px] font-medium text-amber-700 dark:text-amber-400">
          Você já atendeu esse contato antes ({resumo.fromSetor} · {resumo.periodo}), resumo salvo
        </span>
        <ChevronDown className={cn("h-4 w-4 shrink-0 text-amber-600 transition-transform dark:text-amber-400", aberto && "rotate-180")} />
      </button>
      {aberto && (
        <p className="mt-1.5 pl-6 text-[12.5px] leading-snug text-muted-foreground">{resumo.texto}</p>
      )}
    </div>
  )
}

function Bubble({ m }: { m: ChatMessage & { _previewUrl?: string } }) {
  const outbound = m.direction === "outbound"
  return (
    <div className={cn("flex", outbound ? "justify-end" : "justify-start")}>
      <div
        className={cn(
          "max-w-[78%] rounded-[16px] px-3 py-2 shadow-sm",
          outbound
            ? "rounded-br-[4px] bg-primary text-primary-foreground"
            : "rounded-bl-[4px] border border-border bg-card",
        )}
      >
        {m.contentType === "text" && (
          <p className="whitespace-pre-wrap text-[13.5px] leading-snug">{m.text}</p>
        )}
        {m.contentType === "audio" && (
          <AudioBubble outbound={outbound} durationSec={m.audioDurationSec ?? 0} src={m._previewUrl} />
        )}
        {m.contentType === "menu" && <MenuBubble text={m.text} options={m.menuOptions ?? []} />}
        <div
          className={cn(
            "mt-1 flex items-center justify-end gap-1 text-[10px]",
            outbound ? "text-primary-foreground/70" : "text-muted-foreground",
          )}
        >
          {m.createdAt}
          {outbound &&
            (m.status === "read" ? (
              <CheckCheck className="h-3.5 w-3.5 text-sky-300" />
            ) : m.status === "delivered" ? (
              <CheckCheck className="h-3.5 w-3.5" />
            ) : (
              <Check className="h-3.5 w-3.5" />
            ))}
        </div>
      </div>
    </div>
  )
}

/** Bolha de áudio: WAV/OGG gravado de verdade toca aqui; as fictícias do
 *  mock mostram a onda + duração, mas sem fonte real pra tocar. */
/** Como o WhatsApp renderiza um `send_list` de automação: texto em cima,
 *  botão único "Selecione uma opção" que abre a lista — aqui já mostrada
 *  aberta, pra deixar claro o que o cliente vê sem precisar tocar. */
function MenuBubble({ text, options }: { text?: string; options: string[] }) {
  return (
    <div className="min-w-[220px] py-0.5">
      {text && <p className="mb-2 whitespace-pre-wrap text-[13.5px] leading-snug">{text}</p>}
      <div className="overflow-hidden rounded-[10px] border border-border/70">
        {options.map((opt, i) => (
          <div
            key={opt}
            className={cn(
              "flex items-center gap-2.5 px-3 py-2 text-[13px]",
              i > 0 && "border-t border-border/70",
            )}
          >
            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-[11px] font-semibold text-primary">
              {i + 1}
            </span>
            {opt}
          </div>
        ))}
      </div>
    </div>
  )
}

function AudioBubble({ outbound, durationSec, src }: { outbound: boolean; durationSec: number; src?: string }) {
  const audioRef = useRef<HTMLAudioElement>(null)
  const [tocando, setTocando] = useState(false)

  function alternar() {
    if (!src || !audioRef.current) return
    if (tocando) {
      audioRef.current.pause()
    } else {
      audioRef.current.play()
    }
    setTocando(!tocando)
  }

  const barras = useMemo(
    () => Array.from({ length: 24 }, (_, i) => 6 + ((i * 37) % 14)),
    [],
  )

  return (
    <div className="flex items-center gap-2 py-0.5">
      <button
        onClick={alternar}
        disabled={!src}
        className={cn(
          "flex h-8 w-8 shrink-0 items-center justify-center rounded-full",
          outbound ? "bg-primary-foreground/20" : "bg-primary/10",
          !src && "opacity-50",
        )}
      >
        {tocando ? <Pause className="h-3.5 w-3.5" /> : <Play className="ml-0.5 h-3.5 w-3.5" />}
      </button>
      <div className="flex h-6 items-center gap-[2px]">
        {barras.map((h, i) => (
          <span
            key={i}
            className={cn("w-[2.5px] rounded-full", outbound ? "bg-primary-foreground/50" : "bg-primary/40")}
            style={{ height: `${h}px` }}
          />
        ))}
      </div>
      <span className="shrink-0 text-[11px] tabular-nums opacity-80">
        {String(Math.floor(durationSec / 60)).padStart(2, "0")}:{String(durationSec % 60).padStart(2, "0")}
      </span>
      {src && <audio ref={audioRef} src={src} onEnded={() => setTocando(false)} className="hidden" />}
    </div>
  )
}

function Composer({
  texto,
  onTextoChange,
  onEnviarTexto,
  onEnviarAudio,
}: {
  texto: string
  onTextoChange: (v: string) => void
  onEnviarTexto: () => void
  onEnviarAudio: (durationSec: number, blobUrl: string) => void
}) {
  const [gravando, setGravando] = useState(false)
  const [segundos, setSegundos] = useState(0)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  async function iniciarGravacao() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const recorder = new MediaRecorder(stream)
      chunksRef.current = []
      recorder.ondataavailable = (e) => chunksRef.current.push(e.data)
      recorder.start()
      mediaRecorderRef.current = recorder
      setGravando(true)
      setSegundos(0)
      timerRef.current = setInterval(() => setSegundos((s) => s + 1), 1000)
    } catch {
      // Sem permissão de microfone — mensagem simples em vez de travar a tela.
      alert("Não consegui acessar o microfone. Permita o acesso pro navegador e tente de novo.")
    }
  }

  function pararGravacao(cancelar: boolean) {
    const recorder = mediaRecorderRef.current
    if (!recorder) return
    if (timerRef.current) clearInterval(timerRef.current)

    recorder.onstop = () => {
      recorder.stream.getTracks().forEach((t) => t.stop())
      if (!cancelar && chunksRef.current.length > 0) {
        const blob = new Blob(chunksRef.current, { type: "audio/webm" })
        const url = URL.createObjectURL(blob)
        onEnviarAudio(segundos, url)
      }
      setGravando(false)
      setSegundos(0)
    }
    recorder.stop()
  }

  return (
    <div className="flex items-end gap-2 border-t border-border p-2.5 md:p-3">
      {gravando ? (
        <div className="flex flex-1 items-center gap-2 rounded-[var(--radius)] border border-border bg-secondary/50 px-3 py-2.5">
          <span className="h-2.5 w-2.5 shrink-0 animate-pulse rounded-full bg-destructive" />
          <span className="text-[13px] tabular-nums text-muted-foreground">
            Gravando… {String(Math.floor(segundos / 60)).padStart(2, "0")}:{String(segundos % 60).padStart(2, "0")}
          </span>
          <div className="flex-1" />
          <Button variant="ghost" size="sm" onClick={() => pararGravacao(true)}>
            Cancelar
          </Button>
        </div>
      ) : (
        <>
          <Button variant="ghost" size="icon" className="shrink-0" title="Anexar (ainda não conectado)">
            <Paperclip className="h-4.5 w-4.5" />
          </Button>
          <Input
            value={texto}
            onChange={(e) => onTextoChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault()
                onEnviarTexto()
              }
            }}
            placeholder="Digite uma mensagem"
            className="h-11 flex-1"
          />
        </>
      )}

      {gravando ? (
        <Button size="icon" className="h-11 w-11 shrink-0 rounded-full" onClick={() => pararGravacao(false)}>
          <Square className="h-4 w-4" />
        </Button>
      ) : texto.trim() ? (
        <Button size="icon" className="h-11 w-11 shrink-0 rounded-full" onClick={onEnviarTexto}>
          <Send className="h-4.5 w-4.5" />
        </Button>
      ) : (
        <Button
          size="icon"
          variant="secondary"
          className="h-11 w-11 shrink-0 rounded-full"
          onClick={iniciarGravacao}
          title="Gravar áudio"
        >
          <Mic className="h-4.5 w-4.5" />
        </Button>
      )}
    </div>
  )
}
