"use client"

/**
 * Painel do DONO DO SITE — autoriza empresas novas.
 * Só quem está em PLATFORM_OWNER_EMAIL vê a lista (API retorna 403 caso contrário).
 */
import { useState, useEffect, useCallback } from "react"
import { ShieldCheck, Check, X, RefreshCw, Building2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useConfirmar } from "@/components/confirmar"

interface Pend { id: string; nome: string; email: string; empresa: string; cnpj: string; criadoEm: string }

export default function PlataformaPage() {
  const confirmar = useConfirmar()
  const [pend, setPend] = useState<Pend[]>([])
  const [erro, setErro] = useState("")
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    const r = await fetch("/api/plataforma").catch(() => null)
    if (!r) { setErro("Erro de conexão."); setLoading(false); return }
    if (r.status === 403) { setErro("Acesso restrito ao dono do site."); setLoading(false); return }
    const d = await r.json()
    setPend(d.pendentes || []); setLoading(false)
  }, [])
  useEffect(() => { load() }, [load])

  async function decidir(id: string, acao: "APROVAR" | "RECUSAR") {
    if (acao === "RECUSAR" && !await confirmar({ titulo: "Recusar e apagar essa empresa recém-cadastrada?", perigo: true })) return
    setBusy(id)
    try {
      await fetch("/api/plataforma", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: id, acao }),
      })
      await load()
    } finally { setBusy(null) }
  }

  if (erro) return <p className="text-center text-ios-red py-16">{erro}</p>

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-5">
      <div>
        <p className="text-[11px] uppercase tracking-widest text-muted-fg">Dono do site</p>
        <h1 className="text-2xl font-bold text-foreground flex items-center gap-2 tracking-tight">
          <ShieldCheck className="w-6 h-6 text-ios-blue" /> Autorização de empresas
        </h1>
        <p className="text-sm text-muted-fg mt-0.5">Empresas cadastradas aguardando sua liberação para acessar o sistema.</p>
      </div>

      {loading ? (
        <p className="text-muted-fg text-sm">Carregando...</p>
      ) : pend.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-10 text-center text-muted-fg text-sm">
          Nenhuma empresa aguardando aprovação.
        </div>
      ) : (
        <div className="space-y-2">
          {pend.map(p => (
            <div key={p.id} className="bg-surface-1 border border-hairline rounded-2xl p-4 flex items-center justify-between gap-3 flex-wrap">
              <div className="min-w-0 flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-ios-blue/10 flex items-center justify-center flex-shrink-0">
                  <Building2 className="w-5 h-5 text-ios-blue" />
                </div>
                <div className="min-w-0">
                  <p className="text-foreground font-medium truncate">{p.empresa} <span className="text-muted-fg text-xs font-mono">· {p.cnpj}</span></p>
                  <p className="text-muted-fg text-xs">Admin: {p.nome}, {p.email}</p>
                  <p className="text-muted-fg/70 text-[11px]">Cadastrado em {new Date(p.criadoEm).toLocaleString("pt-BR")}</p>
                </div>
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <Button size="sm" disabled={busy === p.id} onClick={() => decidir(p.id, "APROVAR")} className="gap-1.5 bg-ios-green hover:bg-ios-green/90 text-background">
                  {busy === p.id ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />} Aprovar
                </Button>
                <Button size="sm" variant="outline" disabled={busy === p.id} onClick={() => decidir(p.id, "RECUSAR")} className="gap-1.5 text-ios-red">
                  <X className="w-4 h-4" /> Recusar
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
