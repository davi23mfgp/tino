﻿"use client"

import { useState, useEffect, useCallback } from "react"
import { PageLoader } from "@/components/ui/bouncing-dots"
import { useRouter } from "next/navigation"
import {
  HardHat, MapPin, Calendar, ChevronRight, CheckCircle2, AlertTriangle, ClipboardList, Camera,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { CameraVistoria } from "@/components/camera-vistoria"

interface Agendamento { titulo: string; data: string; equipe?: string }

interface ObraInstalador {
  id: string
  client_name: string
  cidade: string | null
  etapa: string | null
  physical_progress_percentage: number
  logistics_status: string
  agendamentos: Agendamento[] | null
  environments: Array<{
    id: string
    nome: string
    proposalItems: Array<{
      id: string
      quantidade: number
      product: { nome: string; sku: string } | null
      kit: { nome: string } | null
    }>
  }>
}

export default function MinhaAreaPage() {
  const router = useRouter()
  const [obras, setObras] = useState<ObraInstalador[]>([])
  const [loading, setLoading] = useState(true)
  const [cameraObraId, setCameraObraId] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/obras")
      if (res.ok) {
        const { obras: lista } = await res.json()
        // Busca os dados completos de cada obra (agendamentos, ambientes)
        const detalhes = await Promise.all(
          lista.map((o: { id: string }) => fetch(`/api/obras/${o.id}`).then(r => r.ok ? r.json() : null))
        )
        setObras(detalhes.filter(Boolean))
      }
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  // Próximos agendamentos (todos, ordenados por data)
  const proximosAgendamentos = obras
    .flatMap(o => (o.agendamentos ?? []).map(a => ({ ...a, obra: o.client_name, obraId: o.id })))
    .filter(a => a.data >= new Date().toISOString().split("T")[0])
    .sort((a, b) => a.data.localeCompare(b.data))
    .slice(0, 5)

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
          <HardHat className="w-6 h-6 text-amber-400" /> Minha Área
        </h1>
        <p className="text-muted-foreground text-sm mt-1">Obras em que você está alocado</p>
      </div>

      {loading ? (
        <div className="py-20 flex justify-center"><PageLoader /></div>
      ) : obras.length === 0 ? (
        <div className="text-center text-muted-foreground py-20">
          <HardHat className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>Você não está alocado em nenhuma obra ainda.</p>
          <p className="text-sm mt-1">Peça ao responsável técnico para adicioná-lo como colaborador.</p>
        </div>
      ) : (
        <>
          {/* Próximos agendamentos */}
          {proximosAgendamentos.length > 0 && (
            <div className="bg-background border border-border/30 rounded-xl p-5 space-y-3">
              <h2 className="text-white font-medium flex items-center gap-2">
                <Calendar className="w-4 h-4 text-sky-400" /> Próximos Agendamentos
              </h2>
              <div className="space-y-2">
                {proximosAgendamentos.map((a, i) => (
                  <div key={i} className="flex items-center justify-between gap-3 bg-card rounded-2xl px-3 py-2.5">
                    <div className="min-w-0">
                      <p className="text-white text-sm font-medium">{a.titulo}</p>
                      <p className="text-muted-foreground text-xs">{a.obra}</p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
                      <span className="text-muted-foreground text-xs">{a.data}</span>
                      <Button size="sm" variant="ghost" onClick={() => router.push(`/obras/${a.obraId}`)}
                        className="h-7 w-7 p-0 text-muted-foreground hover:text-sky-400">
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Lista de obras */}
          <div className="space-y-4">
            {obras.map(o => {
              const pct = Math.min(100, Math.max(0, o.physical_progress_percentage ?? 0))
              const liberado = o.logistics_status === "LIBERADO_INSTALACAO"
              const totalItens = o.environments.reduce((s, e) => s + e.proposalItems.length, 0)

              return (
                <div key={o.id} className="bg-background border border-border/30 rounded-xl p-5 space-y-4">
                  {/* Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <h3 className="text-white font-semibold text-lg">{o.client_name}</h3>
                      {o.cidade && (
                        <p className="text-muted-foreground text-sm flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3.5 h-3.5" /> {o.cidade}
                        </p>
                      )}
                    </div>
                    <Button size="sm" onClick={() => router.push(`/obras/${o.id}`)}
                      className="bg-sky-600 hover:bg-sky-700 text-white gap-1.5 flex-shrink-0">
                      Abrir <ChevronRight className="w-3.5 h-3.5" />
                    </Button>
                  </div>

                  {/* Status */}
                  <div className="flex items-center gap-3 flex-wrap">
                    <span className="text-xs bg-card text-muted-foreground/70 px-3 py-1 rounded-full">
                      {o.etapa ?? "Nova obra"}
                    </span>
                    <span className={`text-xs flex items-center gap-1 px-3 py-1 rounded-full ${liberado
                      ? "bg-green-500/15 text-green-400"
                      : "bg-amber-500/15 text-amber-400"}`}>
                      {liberado
                        ? <><CheckCircle2 className="w-3.5 h-3.5" /> Material liberado</>
                        : <><AlertTriangle className="w-3.5 h-3.5" /> Aguardando material</>
                      }
                    </span>
                  </div>

                  {/* Progresso */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Progresso físico</span>
                      <span className="text-muted-foreground/70 font-medium">{pct}%</span>
                    </div>
                    <div className="h-2 bg-card rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${pct >= 80 ? "bg-green-500" : pct >= 40 ? "bg-sky-500" : "bg-amber-500"}`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>

                  {/* Ambientes resumidos */}
                  {o.environments.length > 0 && (
                    <div className="border-t border-border/20 pt-3">
                      <p className="text-muted-foreground text-xs flex items-center gap-1 mb-2">
                        <ClipboardList className="w-3.5 h-3.5" />
                        {o.environments.length} ambiente{o.environments.length !== 1 ? "s" : ""} · {totalItens} item{totalItens !== 1 ? "s" : ""}
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {o.environments.slice(0, 6).map(env => (
                          <span key={env.id} className="text-xs bg-card text-muted-foreground px-2 py-1 rounded">
                            {env.nome} ({env.proposalItems.length})
                          </span>
                        ))}
                        {o.environments.length > 6 && (
                          <span className="text-xs text-muted-foreground px-2 py-1">
                            +{o.environments.length - 6} mais
                          </span>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Próximos agendamentos desta obra */}
                  {(o.agendamentos ?? []).filter(a => a.data >= new Date().toISOString().split("T")[0]).length > 0 && (
                    <div className="border-t border-border/20 pt-3 space-y-1.5">
                      <p className="text-muted-foreground text-xs uppercase tracking-wide mb-2">Próximos agendamentos</p>
                      {(o.agendamentos ?? [])
                        .filter(a => a.data >= new Date().toISOString().split("T")[0])
                        .slice(0, 3)
                        .map((a, i) => (
                          <div key={i} className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground/70">{a.titulo}</span>
                            <span className="text-muted-foreground text-xs flex items-center gap-1">
                              <Calendar className="w-3 h-3" /> {a.data}
                            </span>
                          </div>
                        ))}
                    </div>
                  )}

                  {/* Câmera de vistoria */}
                  <div className="border-t border-border/20 pt-3">
                    {cameraObraId === o.id ? (
                      <CameraVistoria
                        obraId={o.id}
                        onSaved={() => setTimeout(() => setCameraObraId(null), 3000)}
                      />
                    ) : (
                      <Button variant="outline" size="sm"
                        onClick={() => setCameraObraId(o.id)}
                        className="w-full border-border text-muted-foreground hover:text-white gap-2">
                        <Camera className="w-4 h-4" /> Registrar vistoria (foto)
                      </Button>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </>
      )}
    </div>
  )
}

