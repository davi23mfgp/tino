export default function Loading() {
  return (
    <div className="flex flex-col gap-4 p-5 animate-pulse">
      <div className="flex items-center gap-4">
        <div className="h-16 w-16 bg-muted rounded-2xl" />
        <div className="flex flex-col gap-2">
          <div className="h-5 w-36 bg-muted rounded-xl" />
          <div className="h-4 w-24 bg-muted rounded-xl" />
        </div>
      </div>
      {Array.from({ length: 3 }).map((_, i) => (
        <div key={i} className="h-32 bg-card rounded-2xl border border-border" />
      ))}
    </div>
  )
}
