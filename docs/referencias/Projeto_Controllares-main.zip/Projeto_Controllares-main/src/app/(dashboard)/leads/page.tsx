"use client"
import { formatarTelefone, formatarDocumento, formatarCEP } from "@/lib/documento"

import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
import { DndContext, closestCenter, useDraggable, useDroppable, type DragEndEvent, type DragStartEvent } from "@dnd-kit/core"
import { Sparkles, PhoneCall, TrendingUp, Target, Plus, Phone, Mail, Trash2, ArrowRight, User, ChevronRight, GripVertical, FileText, BadgeCheck, CalendarClock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { EmptyState } from "@/components/ui/empty-state"
import { showToast } from "@/components/ui/toast"
import { CabecalhoPagina } from "@/components/ui/cabecalho-pagina"
import { CartaoMetrica, FaixaMetricas } from "@/components/ui/cartao-metrica"
import { BarraFiltros } from "@/components/ui/barra-filtros"
import { usarAtualizacaoAutomatica } from "@/lib/usar-atualizacao-automatica"
import {
  Dialog, DialogContent, DialogHeader, DialogBody, DialogFooter, DialogTitle,
} from "@/components/ui/dialog"
import { HistoricoLead } from "@/components/leads/historico-lead"
import { FichaLead } from "@/components/leads/ficha-lead"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { TEMPERATURAS } from "@/lib/lead-ficha"
import { useMemoriaDeFiltro } from "@/hooks/usar-memoria-filtro"
import { CampoMascarado } from "@/components/ui/campo-mascarado"

import { brlSemCentavos as brl } from "@/lib/formato"

type LeadStatus =
  | "NOVO" | "CONTATADO" | "QUALIFICADO" | "ELABORANDO_PROPOSTA"
  | "PROPOSTA_ENVIADA" | "GANHO" | "PERDIDO"

/* O funil tem dois donos.
   Até "Criação de Proposta" quem decide é o VENDEDOR: ele liga, visita e
   resolve se vale montar o orçamento. De "Proposta Enviada" em diante quem
   anda é o DOCUMENTO — saiu para o cliente, e o próximo passo é a resposta
   dele. Antes as duas coisas ficavam na mesma coluna, e o quadro dizia que o
   cliente tinha recebido uma proposta que ainda estava sendo escrita. */
const COLUNAS: { id: LeadStatus; label: string; dot: string; bt: string }[] = [
  { id: "NOVO",                label: "Novo",                dot: "bg-ios-blue",   bt: "border-t-ios-blue" },
  { id: "CONTATADO",           label: "Contatado",           dot: "bg-ios-teal",   bt: "border-t-ios-teal" },
  { id: "QUALIFICADO",         label: "Qualificado",         dot: "bg-ios-purple", bt: "border-t-ios-purple" },
  { id: "ELABORANDO_PROPOSTA", label: "Criação de Proposta", dot: "bg-ios-yellow", bt: "border-t-ios-yellow" },
  { id: "PROPOSTA_ENVIADA",    label: "Proposta Enviada",    dot: "bg-ios-orange", bt: "border-t-ios-orange" },
  { id: "GANHO",               label: "Ganho",               dot: "bg-ios-green",  bt: "border-t-ios-green" },
  { id: "PERDIDO",             label: "Perdido",             dot: "bg-ios-red",    bt: "border-t-ios-red" },
]

const ORIGENS = [
  { v: "INDICACAO", l: "Indicação" }, { v: "SITE", l: "Site" }, { v: "PARCEIRO", l: "Parceiro" },
  { v: "INSTAGRAM", l: "Instagram" }, { v: "OUTRO", l: "Outro" },
]

interface ProjetoLead {
  id: string
  nome: string
  posicao: number
  status: LeadStatus
  propostas: { id: string; numero: string; status: string }[]
}

/**
 * Os negócios de um mesmo cliente, dentro do card do funil.
 *
 * Só mostra o que já existe (nome, proposta vinculada, excluir). Criar
 * projeto novo saiu daqui: acontece só dentro da wizard de mudança de fase
 * (Qualificado → Criação de Proposta), que já pergunta "tem mais de um
 * projeto?" — ter um segundo botão de criar direto no card duplicava a
 * pergunta e confundia qual caminho usar.
 */
function ProjetosDoLead({ lead, onExcluir, onProposta }: {
  lead: Lead
  onExcluir: (projetoId: string) => void
  onProposta: (projeto: ProjetoLead) => void
}) {
  const projetos = lead.projetos ?? []
  if (!projetos.length) return null

  return (
    <div className="mt-2.5 space-y-1" onClick={e => e.stopPropagation()}>
      {projetos.map(p => {
        const proposta = p.propostas[0]
        return (
          <div key={p.id} className="flex items-center gap-1.5 rounded-lg bg-surface-2/60 px-2 py-1">
            <span className="min-w-0 flex-1 truncate text-[11px] text-foreground">{p.nome}</span>
            {proposta ? (
              <span className="flex-shrink-0 rounded-full bg-ios-blue/10 px-1.5 py-0.5 text-[10px] font-medium text-ios-blue">
                {proposta.numero}
              </span>
            ) : (
              <button onClick={() => onProposta(p)}
                className="flex flex-shrink-0 items-center gap-0.5 rounded-full bg-ios-blue/10 px-1.5 py-0.5 text-[10px] font-medium text-ios-blue active:opacity-70">
                <ArrowRight className="h-2.5 w-2.5" /> Proposta
              </button>
            )}
            {/* Sem proposta, some sem cerimônia. Com proposta, a rota recusa e
                explica — apagar aqui desligaria um documento que pode já estar
                com o cliente. */}
            <button onClick={() => onExcluir(p.id)} title="Excluir projeto"
              className="flex-shrink-0 text-muted-fg/60 hover:text-ios-red">
              <Trash2 className="h-3 w-3" />
            </button>
          </div>
        )
      })}
    </div>
  )
}

interface Lead {
  id: string; nome: string; telefone: string | null; email: string | null
  origem: string; origem_detalhe: string | null
  partnerId: string | null; partner?: { id: string; name: string } | null
  valor_estimado: string | number | null; observacoes: string | null
  status: LeadStatus; proposalId: string | null; createdAt: string
  /* Negocios independentes do mesmo cliente (construtora com quatro
     apartamentos, comprador com a casa e a praia). Vazio e o caso comum. */
  projetos?: ProjetoLead[]
  /* Cadastro do cliente, conferido numa proposta e devolvido para cá. É o que
     faz o próximo negócio dessa mesma pessoa já nascer preenchido. */
  fat_razao_social: string | null; fat_documento: string | null
  fat_ie: string | null; fat_email: string | null
  fat_cep: string | null; fat_logradouro: string | null; fat_numero: string | null
  fat_complemento: string | null; fat_bairro: string | null
  fat_cidade: string | null; fat_uf: string | null
  fat_confirmado_em: string | null; fat_origem_proposta: string | null
  /* Ficha: o estado da negociação, que a linha do tempo não responde. */
  resumo: string | null
  proximo_passo: string | null; proximo_passo_em: string | null
  temperatura: string | null
  tipo_imovel: string | null; etapa_obra: string | null
  previsao_mudanca: string | null
  metragem: number | null; ambientes_previstos: number | null
  sistemas: string[]
  orcamento_declarado: string | number | null
  decisor: string | null; concorrentes: string | null; endereco_obra: string | null
}

const FORM_VAZIO = {
  nome: "", telefone: "", email: "", origem: "INDICACAO", origem_detalhe: "",
  partnerId: "", valor_estimado: "", observacoes: "", historico: "",
}

/* Tipos de parceiro, para o cadastro rápido de dentro do lead. Mesmos valores
   do enum PartnerType — o cadastro completo continua em Parceiros. */
const TIPOS_PARCEIRO = [
  { v: "ARQUITETO", l: "Arquiteto" },
  { v: "DESIGNER", l: "Designer" },
  { v: "CONSTRUTORA", l: "Construtora" },
  { v: "ENGENHEIRO_CIVIL", l: "Engenheiro civil" },
  { v: "MESTRE_OBRA", l: "Mestre de obra" },
]

export default function LeadsPage() {
  const router = useRouter()
  const [leads, setLeads] = useState<Lead[]>([])
  const [loading, setLoading] = useState(true)
  const [buscaLead, setBuscaLead] = useMemoriaDeFiltro("leads:busca", "")
  const [filtroLead, setFiltroLead] = useMemoriaDeFiltro<"TODOS" | "NOVO" | "CONTATADO" | "QUALIFICADO" | "ELABORANDO_PROPOSTA">("leads:status", "TODOS")
  const [colAtiva, setColAtiva] = useState<LeadStatus>("NOVO")

  const [open, setOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [parceiros, setParceiros] = useState<{ id: string; name: string; type?: string }[]>([])
  const [novoParceiro, setNovoParceiro] = useState(false)
  const [pForm, setPForm] = useState({ name: "", type: "ARQUITETO", phone: "" })
  const [pSalvando, setPSalvando] = useState(false)

  /* Quem é o usuário. Serve para o texto do aviso, não para esconder o botão:
     esconder fazia a função parecer inexistente para quem está com o perfil
     errado na conta. */
  const [meuRole, setMeuRole] = useState("")
  useEffect(() => {
    fetch("/api/auth/me", { cache: "no-store" })
      .then(r => r.ok ? r.json() : null)
      .then(j => setMeuRole(j?.user?.role ?? ""))
      .catch(() => {})
  }, [])

  useEffect(() => {
    fetch("/api/parceiros", { cache: "no-store" })
      .then(r => r.ok ? r.json() : null)
      .then(d => setParceiros(d?.parceiros ?? d?.partners ?? (Array.isArray(d) ? d : [])))
      .catch(() => {})
  }, [])

  /* Cadastro rápido, de dentro do lead: a indicação chega no meio de uma
     conversa, e mandar a pessoa abrir Parceiros, cadastrar e voltar é o
     caminho para ela marcar "Outro" e seguir — perdendo a informação de quem
     indicou, que é o motivo de o campo existir. */
  async function criarParceiro() {
    if (!pForm.name.trim()) return
    setPSalvando(true)
    try {
      const r = await fetch("/api/parceiros", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: pForm.name.trim(), type: pForm.type, phone: pForm.phone || null }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { showToast(j.error || "Falha ao cadastrar o parceiro.", { variant: "error" }); return }
      const criado = j.parceiro ?? j.partner ?? j
      setParceiros(l => [{ id: criado.id, name: criado.name, type: criado.type }, ...l])
      setForm(f => ({ ...f, partnerId: criado.id }))
      setNovoParceiro(false)
      setPForm({ name: "", type: "ARQUITETO", phone: "" })
    } finally { setPSalvando(false) }
  }
  const [form, setForm] = useState(FORM_VAZIO)
  const [editing, setEditing] = useState<Lead | null>(null)
  const [delTarget, setDelTarget] = useState<Lead | null>(null)
  const [pendingMove, setPendingMove] = useState<{ lead: Lead; status: LeadStatus; projeto?: ProjetoLead } | null>(null)
  /* Por que o lead se moveu. Vale para qualquer fase e é o campo mais útil em
     "Perdido": "achou caro" e "sumiu" pedem abordagens diferentes na hora de
     retomar, e sem isso o funil só sabe dizer que a negociação acabou. */
  const [motivoMovimento, setMotivoMovimento] = useState("")

  /* Qualificado → Criação de Proposta é decisão em cadeia, não um "mover e
     pronto": primeiro se sabe se tem mais de um projeto, só depois se sabe
     se dá pra rascunhar agora e de qual. Pergunta binária a cada passo — sem
     campo de comentário aqui, esse fluxo é sim/não, o comentário é o dialog
     genérico de mudar fase. */
  type PassoProposta = "pergunta_projetos" | "pergunta_rascunho_unico" | "criar_projetos" | "pergunta_rascunho_multi" | "escolher_projeto_multi"
  const [passoProposta, setPassoProposta] = useState<PassoProposta>("pergunta_projetos")
  const [novosNomesProjetos, setNovosNomesProjetos] = useState<string[]>([])
  const [nomeProjetoAtual, setNomeProjetoAtual] = useState("")
  const [projetosCriados, setProjetosCriados] = useState<ProjetoLead[]>([])
  const ehFluxoDeProposta = pendingMove?.status === "ELABORANDO_PROPOSTA" && !pendingMove.projeto

  useEffect(() => {
    if (pendingMove?.status === "ELABORANDO_PROPOSTA") {
      setPassoProposta("pergunta_projetos")
      setNovosNomesProjetos([])
      setNomeProjetoAtual("")
      setProjetosCriados([])
    }
  }, [pendingMove])

  const fetchLeads = useCallback(async () => {
    const r = await fetch("/api/leads", { cache: "no-store" })
    if (r.ok) setLeads((await r.json()).leads ?? [])
    setLoading(false)
  }, [])
  useEffect(() => { fetchLeads() }, [fetchLeads])

  async function salvar() {
    if (!form.nome.trim()) return
    setSaving(true)
    try {
      const url = editing ? `/api/leads/${editing.id}` : "/api/leads"
      const r = await fetch(url, {
        method: editing ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      })
      if (!r.ok) { const j = await r.json().catch(() => ({})); showToast(j.error || "Falha ao salvar.", { variant: "error" }); return }
      showToast(editing ? "Lead atualizado." : "Lead criado.", { variant: "success" })
      setOpen(false); setForm(FORM_VAZIO); setEditing(null)
      fetchLeads()
    } finally { setSaving(false) }
  }

  async function mover(lead: Lead, status: LeadStatus, motivo?: string) {
    setLeads(prev => prev.map(l => l.id === lead.id ? { ...l, status } : l))
    const r = await fetch(`/api/leads/${lead.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      // O motivo não muda o lead: vira a linha do histórico daquele movimento.
      body: JSON.stringify({ status, motivo: motivo?.trim() || undefined }),
    })
    if (!r.ok) { showToast("Falha ao mover lead.", { variant: "error" }); fetchLeads() }
  }

  /** Move o cartão de UM projeto (lead com 2+ projetos, cada um com seu
   *  próprio cartão no funil) — não mexe em Lead.status. */
  async function moverProjeto(lead: Lead, projeto: ProjetoLead, status: LeadStatus, motivo?: string) {
    setLeads(prev => prev.map(l => l.id !== lead.id ? l : {
      ...l, projetos: (l.projetos ?? []).map(p => p.id === projeto.id ? { ...p, status } : p),
    }))
    const r = await fetch(`/api/leads/${lead.id}/projetos/${projeto.id}/status`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status, motivo: motivo?.trim() || undefined }),
    })
    if (!r.ok) { showToast("Falha ao mover projeto.", { variant: "error" }); fetchLeads() }
  }

  async function confirmarMovimentoPendente() {
    if (!pendingMove) return
    const { lead, status, projeto } = pendingMove
    const motivo = motivoMovimento
    setPendingMove(null)
    setMotivoMovimento("")
    if (projeto) await moverProjeto(lead, projeto, status, motivo)
    else await mover(lead, status, motivo)
  }

  async function excluir() {
    if (!delTarget) return
    const r = await fetch(`/api/leads/${delTarget.id}`, { method: "DELETE" })
    if (!r.ok) {
      const j = await r.json().catch(() => ({}))
      showToast(j.error || "Falha ao excluir.", { variant: "error" })
      return
    }
    setDelTarget(null)
    showToast("Lead excluído.", { variant: "success" })
    fetchLeads()
  }

  /* Abrir a proposta move o lead para "Criação de Proposta", não para
     "Proposta Enviada": o documento ainda vai ser montado, e pode levar dias.
     Quem marca "enviada" é a própria proposta ao ser salva — quando existe de
     verdade algo que o cliente pode receber. */
  function converterEmProposta(lead: Lead) {
    if (lead.status !== "ELABORANDO_PROPOSTA" && lead.status !== "PROPOSTA_ENVIADA") {
      mover(lead, "ELABORANDO_PROPOSTA")
    }
    router.push(`/propostas/nova?cliente=${encodeURIComponent(lead.nome)}&lead=${lead.id}`)
  }

  /* A proposta de UM projeto do cliente.
     Pula o kanban de propor no geral: a pessoa ja decidiu de qual dos
     negocios dela e este documento, e o wizard nasce amarrado nele. */
  function converterProjetoEmProposta(lead: Lead, projeto: ProjetoLead) {
    if (lead.status !== "ELABORANDO_PROPOSTA" && lead.status !== "PROPOSTA_ENVIADA") {
      mover(lead, "ELABORANDO_PROPOSTA")
    }
    router.push(
      `/propostas/nova?cliente=${encodeURIComponent(lead.nome)}&lead=${lead.id}` +
      `&projeto=${projeto.id}&projetoNome=${encodeURIComponent(projeto.nome)}`,
    )
  }

  async function excluirProjeto(lead: Lead, projetoId: string) {
    const r = await fetch(`/api/leads/${lead.id}/projetos`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ projetoId }),
    })
    if (r.ok) fetchLeads()
    else showToast((await r.json().catch(() => null))?.error ?? "Nao consegui excluir.", { variant: "error" })
  }

  /* Cria todos os nomes digitados de uma vez e devolve os ids — é o que a
     tela precisa pra oferecer "de qual projeto?" no passo seguinte sem
     esperar o fetchLeads() (que so chega depois, numa segunda leva). */
  async function criarProjetosEmLote(lead: Lead, nomes: string[]): Promise<ProjetoLead[]> {
    const criados: ProjetoLead[] = []
    for (const nome of nomes) {
      const r = await fetch(`/api/leads/${lead.id}/projetos`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome }),
      })
      if (r.ok) {
        const j = await r.json()
        criados.push({ id: j.projeto.id, nome: j.projeto.nome, posicao: criados.length, status: j.projeto.status ?? "ELABORANDO_PROPOSTA", propostas: [] })
      }
    }
    fetchLeads()
    return criados
  }

  /* Só muda a fase, sem abrir a proposta — o "não" de cada pergunta do
     fluxo Qualificado → Criação de Proposta cai aqui. */
  async function confirmarSoAFase() {
    if (!pendingMove) return
    const { lead, status } = pendingMove
    setPendingMove(null)
    await mover(lead, status)
  }

  function abrirEdicao(l: Lead) {
    setEditing(l)
    setForm({
      nome: l.nome, telefone: l.telefone ?? "", email: l.email ?? "",
      origem: l.origem, origem_detalhe: l.origem_detalhe ?? "",
      partnerId: l.partnerId ?? "",
      valor_estimado: l.valor_estimado != null ? String(l.valor_estimado) : "",
      observacoes: l.observacoes ?? "",
      // Só vale no cadastro: no lead que já existe a escrita é pela linha do tempo.
      historico: "",
    })
    setOpen(true)
  }

  /* O quadro mostra cartões, não leads. Lead com 0 ou 1 projeto é o cartão
     dele mesmo (como sempre foi). Lead com 2+ projetos vira um cartão POR
     projeto — dragId é o id do projeto, não do lead, porque cada um anda
     sozinho pelo funil (um pode fechar, outro morrer; puxar um puxaria o
     outro junto se ainda fossem o mesmo cartão). */
  type ItemQuadro = { dragId: string; lead: Lead; projeto: ProjetoLead | null; status: LeadStatus }
  const itensQuadro: ItemQuadro[] =
    leads.flatMap((l): ItemQuadro[] => {
      const projetos = l.projetos ?? []
      if (projetos.length >= 2) {
        return projetos.map((p): ItemQuadro => ({ dragId: p.id, lead: l, projeto: p, status: p.status }))
      }
      return [{ dragId: l.id, lead: l, projeto: null, status: l.status }]
    })

  const porStatus = COLUNAS.reduce((acc, c) => {
    acc[c.id] = itensQuadro.filter(it => it.status === c.id)
    return acc
  }, {} as Record<LeadStatus, typeof itensQuadro>)

  const totalPipeline = leads
    .filter(l => !["GANHO", "PERDIDO"].includes(l.status))
    .reduce((s, l) => s + Number(l.valor_estimado ?? 0), 0)

  /* Conversão só conta o que já teve desfecho. Dividir pelo total de leads
     mostraria a taxa caindo toda vez que alguém cadastra um lead novo, o que
     não diz nada sobre a qualidade do funil. */
  const decididos = porStatus.GANHO.length + porStatus.PERDIDO.length
  const conversao = decididos ? Math.round((porStatus.GANHO.length / decididos) * 100) : 0

  /* Busca e filtro estreitam o quadro, não os números do topo: as métricas
     falam do funil inteiro, senão "Novos: 0" ao buscar um nome assustaria à toa. */
  const porStatusVisivel = COLUNAS.reduce((acc, c) => {
    const termo = buscaLead.trim().toLowerCase()
    acc[c.id] = porStatus[c.id].filter(it => {
      if (filtroLead !== "TODOS" && it.status !== filtroLead) return false
      if (!termo) return true
      return [it.lead.nome, it.lead.email, it.lead.telefone].some(v => (v ?? "").toLowerCase().includes(termo))
    })
    return acc
  }, {} as Record<LeadStatus, typeof itensQuadro>)

  // Drag & drop — arrasta o lead para qualquer coluna (movimento livre)
  const [dragId, setDragId] = useState<string | null>(null)
  /* Lead novo entra pelo site e pelo CRM sem ninguém abrir a tela, e outra
     pessoa move o card ao mesmo tempo. Pausa durante o arraste: trocar a
     lista no meio faz o card sumir da mão. */
  usarAtualizacaoAutomatica(fetchLeads, { pausado: !!dragId })

  function onDragStart(e: DragStartEvent) { setDragId(String(e.active.id)) }
  function onDragEnd(e: DragEndEvent) {
    setDragId(null)
    const draggedId = String(e.active.id)
    const destino = e.over?.id as LeadStatus | undefined
    if (!destino || !COLUNAS.some(c => c.id === destino)) return
    const item = itensQuadro.find(it => it.dragId === draggedId)
    if (!item || item.status === destino) return

    /* PERDIDO sempre exige motivo; ELABORANDO_PROPOSTA (só cartão de lead
       inteiro — projeto já nasce nessa fase e nunca volta pra ela) abre a
       wizard de projetos. Os dois têm que passar pelo popup mesmo vindo de
       arraste — arrastar chamava mover() direto antes, pulando o popup. */
    if (item.projeto) {
      if (destino === "PERDIDO") { setPendingMove({ lead: item.lead, status: destino, projeto: item.projeto }); return }
      moverProjeto(item.lead, item.projeto, destino)
      return
    }
    if (destino === "PERDIDO" || destino === "ELABORANDO_PROPOSTA") {
      setPendingMove({ lead: item.lead, status: destino })
      return
    }
    mover(item.lead, destino)
  }

  const LeadDrag = ({ dragId, children }: { dragId: string; children: React.ReactNode }) => {
    const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({ id: dragId })
    /* O cartão arrastado passa POR CIMA das colunas, como no kanban de
       propostas. Sem o z-index ele desliza por trás da coluna vizinha, e a
       opacidade baixa ainda o transformava num fantasma atrás do quadro: no
       meio do arraste não dava para ver o que estava sendo movido. */
    const style = transform ? {
      transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
      zIndex: 50,
      position: "relative" as const,
      boxShadow: isDragging ? "0 18px 40px -12px rgba(0,0,0,.55)" : undefined,
    } : undefined
    return (
      <div ref={setNodeRef} style={style} className="relative">
        <button {...listeners} {...attributes} onClick={e => e.stopPropagation()}
          className="absolute top-3 right-3 z-10 text-muted-foreground/40 hover:text-muted-foreground cursor-grab active:cursor-grabbing p-1 touch-none" title="Arrastar">
          <GripVertical className="w-3.5 h-3.5" />
        </button>
        {children}
      </div>
    )
  }

  const ColunaDrop = ({ id, children }: { id: LeadStatus; children: React.ReactNode }) => {
    const { setNodeRef, isOver } = useDroppable({ id })
    /* A coluna rola por dentro quando tem lead demais, mas `overflow` recorta
       o que passa da borda, e era isso que cortava o cartão arrastado: ele
       sumia atrás da coluna vizinha por mais z-index que tivesse. Durante o
       arraste a coluna para de recortar; a rolagem volta quando solta. */
    const arrastando = !!dragId
    return (
      <div ref={setNodeRef}
        className={`flex-1 space-y-2 min-h-[160px] rounded-b-xl p-2 border border-hairline transition-colors ${
          arrastando ? "overflow-visible" : "overflow-y-auto"
        } ${
          isOver ? "bg-ios-blue/[0.06] ring-1 ring-ios-blue/40" : "bg-surface-2/20"
        }`}>
        {children}
      </div>
    )
  }

  /* `projeto` presente = este cartão representa UM projeto do lead (lead com
     2+ projetos, cada um com caminho próprio no funil — um pode fechar,
     outro morrer, não fazia sentido os dois arrastarem o mesmo cartão). Sem
     `projeto`, é o cartão do lead inteiro, como sempre foi. */
  const LeadCard = ({ l, projeto }: { l: Lead; projeto?: ProjetoLead | null }) => {
    const status = projeto?.status ?? l.status
    const proposta = projeto?.propostas[0]
    return (
    <div onClick={() => abrirEdicao(l)}
      className="bg-surface-1 rounded-2xl p-4 border border-hairline cursor-pointer hover:bg-surface-2 transition-colors">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0 flex-1">
          <p className="flex items-center gap-1.5 text-[15px] font-semibold text-foreground leading-tight pr-5">
            {/* A temperatura no card responde "para quem eu ligo primeiro
                hoje?" — pergunta que a coluna do funil não responde: tem
                "Qualificado" parado há dois meses e "Novo" querendo fechar. */}
            {l.temperatura && (
              <span title={TEMPERATURAS.find(t => t.id === l.temperatura)?.label}
                className={`h-2 w-2 flex-shrink-0 rounded-full ${TEMPERATURAS.find(t => t.id === l.temperatura)?.cor ?? ""}`} />
            )}
            <span className="truncate">{l.nome}{projeto ? ` · ${projeto.nome}` : ""}</span>
          </p>
          {/* "Outro" sozinho não informa nada, o que interessa é qual outro. */}
          <p className="text-[12px] text-muted-fg mt-0.5">
            {ORIGENS.find(o => o.v === l.origem)?.l ?? l.origem}
            {l.origem === "OUTRO" && l.origem_detalhe ? `: ${l.origem_detalhe}` : ""}
            {l.origem === "PARCEIRO" && l.partner ? `: ${l.partner.name}` : ""}
          </p>
        </div>
        {l.valor_estimado != null && Number(l.valor_estimado) > 0 && (
          <span className="text-[14px] font-semibold text-foreground flex-shrink-0">{brl(Number(l.valor_estimado))}</span>
        )}
      </div>
      {(l.telefone || l.email) && (
        <div className="flex items-center gap-3 mt-2 text-[12px] text-muted-fg min-w-0">
          {l.telefone && <span className="flex items-center gap-1 flex-shrink-0"><Phone className="w-3 h-3" />{formatarTelefone(l.telefone)}</span>}
          {l.email && <span className="flex items-center gap-1 truncate min-w-0"><Mail className="w-3 h-3 flex-shrink-0" /><span className="truncate">{l.email}</span></span>}
        </div>
      )}
      {/* O combinado, no card.

          Sem isto o compromisso vivia dentro da ficha: quem passa o olho no
          quadro de manhã não abre dez leads para descobrir qual deles pediu
          para ser chamado hoje. Vencido fica vermelho, porque o cliente já
          está esperando. */}
      {l.proximo_passo && (
        <div className={`mt-2 flex items-start gap-1.5 rounded-[10px] px-2 py-1.5 text-[11px] ${
          l.proximo_passo_em && new Date(l.proximo_passo_em) < new Date(new Date().toDateString())
            ? "bg-ios-red/[0.08] text-ios-red"
            : "bg-surface-2/60 text-muted-fg"
        }`}>
          <CalendarClock className="mt-px h-3 w-3 flex-shrink-0" />
          <span className="min-w-0 flex-1 truncate">{l.proximo_passo}</span>
          {l.proximo_passo_em && (
            <span className="flex-shrink-0 tabular-nums">
              {new Date(l.proximo_passo_em).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })}
            </span>
          )}
        </div>
      )}

      {/* Projetos do cliente — só quando este cartão é do lead inteiro (não
          de um projeto específico, que já é o recorte). A partir de
          Qualificado ele já sabe dizer quantos negócios são; com 2+ eles
          ganham cartão próprio (itensQuadro) e este bloco nem aparece mais
          aqui, porque cada um já tem o seu. */}
      {!projeto && ["QUALIFICADO", "ELABORANDO_PROPOSTA", "PROPOSTA_ENVIADA", "GANHO"].includes(l.status) && (
        <ProjetosDoLead
          lead={l}
          onExcluir={pid => excluirProjeto(l, pid)}
          onProposta={proj => converterProjetoEmProposta(l, proj)}
        />
      )}

      <div className="flex flex-wrap gap-1.5 mt-3 items-center" onClick={e => e.stopPropagation()}>
        {/* Com projetos na mesa (cartão do lead inteiro, 1 só projeto ainda),
            propor "para o cliente" perde sentido — a proposta é sempre de um
            deles, o botão fica dentro de ProjetosDoLead. Num cartão DE
            projeto, a proposta é a dele mesmo. */}
        {!["GANHO", "PERDIDO"].includes(status) && !projeto && !(l.projetos?.length) && (
          <button onClick={() => converterEmProposta(l)}
            className="flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-medium bg-ios-blue/10 text-ios-blue active:opacity-70 flex-shrink-0">
            <ArrowRight className="w-3 h-3" /> Proposta
          </button>
        )}
        {projeto && (
          proposta ? (
            <span className="flex-shrink-0 rounded-full bg-ios-blue/10 px-2.5 h-7 inline-flex items-center text-[11px] font-medium text-ios-blue">
              {proposta.numero}
            </span>
          ) : (
            <button onClick={() => converterProjetoEmProposta(l, projeto)}
              className="flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-medium bg-ios-blue/10 text-ios-blue active:opacity-70 flex-shrink-0">
              <ArrowRight className="w-3 h-3" /> Proposta
            </button>
          )
        )}
        {/* Seta pra PRÓXIMA fase e pra ANTERIOR (não lista todas). Move com
            confirmação. Sem arrastar no mobile, "voltar" por botão é o único
            jeito de desfazer uma fase marcada errado sem abrir no desktop. */}
        {(() => {
          const fluxo = COLUNAS.filter(c => c.id !== "PERDIDO")
          const idx = fluxo.findIndex(c => c.id === status)
          const proxima = idx >= 0 && idx < fluxo.length - 1 ? fluxo[idx + 1] : null
          const anterior = idx > 0 ? fluxo[idx - 1] : null
          return (
            <>
              {/* Voltar uma fase é botão só no mobile: no desktop se arrasta o
                  cartão pra qualquer coluna, e o botão vira repetição. */}
              {anterior && (
                <button onClick={() => setPendingMove({ lead: l, status: anterior.id, projeto: projeto ?? undefined })}
                  className="md:hidden flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-medium bg-muted text-muted-fg active:bg-muted/70 flex-shrink-0">
                  <ChevronRight className="w-3 h-3 rotate-180" /> {anterior.label}
                </button>
              )}
              {proxima && (
                <button onClick={() => setPendingMove({ lead: l, status: proxima.id, projeto: projeto ?? undefined })}
                  className="flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-medium bg-muted text-foreground active:bg-muted/70 flex-shrink-0">
                  <span className={`w-1.5 h-1.5 rounded-full ${proxima.dot}`} /> {proxima.label} <ChevronRight className="w-3 h-3" />
                </button>
              )}
            </>
          )
        })()}
        {status !== "PERDIDO" && status !== "GANHO" && (
          <button onClick={() => setPendingMove({ lead: l, status: "PERDIDO", projeto: projeto ?? undefined })}
            className="px-2 h-7 text-[11px] text-muted-fg hover:text-ios-red flex-shrink-0">Perdido</button>
        )}
        {/* Ganho/Perdido: reabrir (volta pra Qualificado) */}
        {(status === "PERDIDO" || status === "GANHO") && (
          <button onClick={() => setPendingMove({ lead: l, status: "QUALIFICADO", projeto: projeto ?? undefined })}
            className="flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-medium bg-muted text-foreground active:bg-muted/70 flex-shrink-0">
            <ChevronRight className="w-3 h-3 rotate-180" /> Reabrir
          </button>
        )}
        {/* Num cartão de projeto, a lixeira apaga o PROJETO (o lead continua,
            com os outros); num cartão de lead inteiro, apaga o lead. O botão
            aparece para todos; quem decide é o servidor. */}
        {projeto ? (
          <button onClick={() => excluirProjeto(l, projeto.id)} title="Excluir projeto"
            className="flex items-center px-2 h-7 rounded-full text-muted-foreground hover:text-ios-red active:opacity-70 flex-shrink-0 ml-auto">
            <Trash2 className="w-3 h-3" />
          </button>
        ) : (
          <button onClick={() => setDelTarget(l)} title="Excluir lead"
            className="flex items-center px-2 h-7 rounded-full text-muted-foreground hover:text-ios-red active:opacity-70 flex-shrink-0 ml-auto">
            <Trash2 className="w-3 h-3" />
          </button>
        )}
      </div>
    </div>
    )
  }

  /* Os campos do cadastro, uma vez só.

     Eles aparecem no lead novo (tela inteira) e na aba "Contato" do lead que
     já existe. Escritos duas vezes, o campo novo entra num lugar e falta no
     outro — e ninguém descobre até alguém reclamar que o parceiro sumiu ao
     editar. */
  const camposDoLead = (
    <>
            <div className="space-y-1.5">
              <Label>Nome *</Label>
              <Input value={form.nome} onChange={e => setForm(f => ({ ...f, nome: e.target.value }))} placeholder="Nome do contato ou empresa" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Telefone</Label>
                <CampoMascarado mascara="telefone" value={form.telefone} placeholder="(11) 9..."
                  onValorChange={v => setForm(f => ({ ...f, telefone: v }))} />
              </div>
              <div className="space-y-1.5">
                <Label>E-mail</Label>
                <Input value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="contato@..." />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Origem</Label>
                <select value={form.origem}
                  onChange={e => setForm(f => ({
                    ...f, origem: e.target.value,
                    // Saiu de "Outro": o detalhe não pertence mais a nada.
                    origem_detalhe: e.target.value === "OUTRO" ? f.origem_detalhe : "",
                    // Idem para o parceiro: manter creditaria uma indicação
                    // que deixou de existir.
                    partnerId: e.target.value === "PARCEIRO" ? f.partnerId : "",
                  }))}
                  className="flex h-11 w-full rounded-[16px] border border-border bg-background/60 px-3 text-[15px] text-foreground focus:outline-none">
                  {ORIGENS.map(o => <option key={o.v} value={o.v}>{o.l}</option>)}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label>Valor estimado</Label>
                <Input type="number" min="0" value={form.valor_estimado}
                  onChange={e => setForm(f => ({ ...f, valor_estimado: e.target.value }))} placeholder="R$" />
              </div>
            </div>
            {/* Qual "Outro".

                "Outro" sozinho não diz nada: em pouco tempo é a maior fatia do
                relatório de origem e ninguém sabe do que ela é feita. O texto
                fica num campo próprio, e `origem` continua "OUTRO" — jogar
                texto livre ali quebraria o agrupamento das análises, cada
                resposta virando uma fatia de um. */}
            {/* Qual parceiro indicou.

                Vínculo e não texto: é por ele que se sabe quem indicou mais e
                quanto de comissão cada arquiteto gerou. Digitado à mão,
                "Studio X" e "studio x" viram dois parceiros no relatório.

                O cadastro rápido existe porque a indicação chega no meio de
                uma conversa: mandar a pessoa abrir Parceiros, cadastrar e
                voltar é o caminho para ela escolher "Outro" e seguir. */}
            {form.origem === "PARCEIRO" && (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <Label>Parceiro que indicou</Label>
                  {!novoParceiro && (
                    <button type="button" onClick={() => setNovoParceiro(true)}
                      className="text-xs text-muted-fg underline underline-offset-2 hover:text-foreground">
                      Cadastrar novo
                    </button>
                  )}
                </div>

                {novoParceiro ? (
                  <div className="space-y-2 rounded-[16px] border border-border bg-background/40 p-3">
                    <Input autoFocus value={pForm.name} placeholder="Nome do parceiro"
                      onChange={e => setPForm(f => ({ ...f, name: e.target.value }))} />
                    <div className="grid grid-cols-2 gap-2">
                      <select value={pForm.type} onChange={e => setPForm(f => ({ ...f, type: e.target.value }))}
                        className="flex h-11 w-full rounded-[16px] border border-border bg-background/60 px-3 text-[15px] text-foreground focus:outline-none">
                        {TIPOS_PARCEIRO.map(t => <option key={t.v} value={t.v}>{t.l}</option>)}
                      </select>
                      <CampoMascarado mascara="telefone" value={pForm.phone} placeholder="Telefone"
                        onValorChange={v => setPForm(f => ({ ...f, phone: v }))} />
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" onClick={criarParceiro} disabled={pSalvando || !pForm.name.trim()}>
                        {pSalvando ? "Salvando..." : "Salvar parceiro"}
                      </Button>
                      <Button size="sm" variant="secondary" onClick={() => setNovoParceiro(false)}>Cancelar</Button>
                    </div>
                    <p className="text-[11px] text-muted-fg">
                      Entra no cadastro de Parceiros. Comissão e demais dados podem ser
                      completados lá depois.
                    </p>
                  </div>
                ) : (
                  <select value={form.partnerId}
                    onChange={e => setForm(f => ({ ...f, partnerId: e.target.value }))}
                    className="flex h-11 w-full rounded-[16px] border border-border bg-background/60 px-3 text-[15px] text-foreground focus:outline-none">
                    <option value="">Escolher parceiro</option>
                    {parceiros.map(pt => (
                      <option key={pt.id} value={pt.id}>
                        {pt.name}{pt.type ? ` · ${TIPOS_PARCEIRO.find(t => t.v === pt.type)?.l ?? pt.type}` : ""}
                      </option>
                    ))}
                  </select>
                )}
              </div>
            )}
            {form.origem === "OUTRO" && (
              <div className="space-y-1.5">
                <Label>Qual outro?</Label>
                <Input autoFocus value={form.origem_detalhe}
                  onChange={e => setForm(f => ({ ...f, origem_detalhe: e.target.value }))}
                  placeholder="Ex: feira, arquiteto, cliente antigo, anúncio no rádio" />
              </div>
            )}
            <div className="space-y-1.5">
              <Label>Observações</Label>
              <textarea value={form.observacoes} onChange={e => setForm(f => ({ ...f, observacoes: e.target.value }))}
                rows={2} placeholder="Contexto, interesse, próximo passo..."
                className="flex w-full rounded-[16px] border border-border bg-background/60 px-4 py-2.5 text-[15px] text-foreground placeholder:text-muted-foreground focus:outline-none resize-none" />
            </div>

            {/* Histórico de abertura, no próprio cadastro.

                Quem cadastra é quem acabou de falar com o cliente — é ali que
                ainda se lembra da obra, do prazo e do que ele já tem em casa.
                Sem um campo aqui, isso viraria "escrevo depois", e daqui a seis
                meses o cadastro é um telefone sem nenhuma pista de por que
                aquela pessoa ligou. O texto entra como a primeira linha da
                linha do tempo, com autor e data — e não se apaga. */}
            {!editing && (
              <div className="space-y-1.5">
                <Label className="flex items-center gap-2">
                  Histórico inicial
                  <span className="text-[11px] font-normal text-muted-fg">fica registrado, não se apaga</span>
                </Label>
                <textarea value={form.historico} onChange={e => setForm(f => ({ ...f, historico: e.target.value }))}
                  rows={4} placeholder="Como chegou, o que procura, ambiente, prazo, orçamento comentado, quem decide..."
                  className="flex w-full rounded-[16px] border border-border bg-background/60 px-4 py-2.5 text-[15px] text-foreground placeholder:text-muted-foreground focus:outline-none resize-none" />
                <p className="text-[11px] text-muted-fg">
                  É o que outra pessoa vai ler antes de voltar a esse cliente. Depois de criado,
                  cada novo registro entra na linha do tempo do lead.
                </p>
              </div>
            )}
    </>
  )

  return (
    <div className="p-4 md:p-6 flex flex-col gap-4 h-full min-h-0">
      {/* Header */}
      <CabecalhoPagina
        icone={Target}
        titulo="Leads"
        contexto={
          <>
            {leads.length} no funil
            {totalPipeline > 0 && <> · {brl(totalPipeline)} em aberto</>}
          </>
        }
        acao={
          <div className="flex items-center gap-2">
            {/* O alternador Funil / Contatos saiu: a lista de contatos era a
                mesma carteira que Clientes mostra, com menos informação e uma
                tabela a manter em dobro. Duas telas para a mesma pergunta
                divergem no dia em que alguém melhora só uma. Leads mostra o
                funil; a carteira fica em Clientes. */}
            <Button onClick={() => { setEditing(null); setForm(FORM_VAZIO); setOpen(true) }}>
              <Plus className="mr-1 h-4 w-4" /> Novo lead
            </Button>
          </div>
        }
      />

      <FaixaMetricas>
        <CartaoMetrica icone={Sparkles} rotulo="Novos" valor={porStatus.NOVO.length} nota="Ainda sem contato" />
        <CartaoMetrica icone={PhoneCall} rotulo="Em contato" valor={porStatus.CONTATADO.length} nota="Conversa aberta" />
        <CartaoMetrica icone={Target} rotulo="Qualificados" valor={porStatus.QUALIFICADO.length} nota="Prontos para proposta" />
        <CartaoMetrica icone={FileText} rotulo="Em elaboração" valor={porStatus.ELABORANDO_PROPOSTA.length} nota="Proposta sendo montada" />
        <CartaoMetrica icone={TrendingUp} rotulo="Conversão" valor={decididos ? `${conversao}%` : "—"}
          nota={decididos ? `${porStatus.GANHO.length} de ${decididos} fechados` : "Nenhum desfecho ainda"} />
      </FaixaMetricas>

      <BarraFiltros
        busca={buscaLead}
        aoBuscar={setBuscaLead}
        placeholder="Buscar por nome, e-mail ou telefone..."
        valor={filtroLead}
        aoTrocar={setFiltroLead}
        opcoes={[
          { valor: "TODOS", rotulo: "Todos" },
          { valor: "NOVO", rotulo: "Novos" },
          { valor: "CONTATADO", rotulo: "Em contato" },
          { valor: "QUALIFICADO", rotulo: "Qualificados" },
          { valor: "ELABORANDO_PROPOSTA", rotulo: "Em elaboração" },
        ] as const}
      />


      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-40 rounded-3xl bg-white/[0.06] animate-pulse" />)}
        </div>
      ) : leads.length === 0 ? (
        <EmptyState icon={Target} title="Nenhum lead ainda" subtitle="Cadastre contatos comerciais e acompanhe o funil até virar proposta."
          action={<Button onClick={() => { setEditing(null); setForm(FORM_VAZIO); setOpen(true) }}>Criar primeiro lead</Button>} />
      ) : (
        <>
          {/* DESKTOP: colunas com drag & drop livre */}
          <DndContext collisionDetection={closestCenter} onDragStart={onDragStart} onDragEnd={onDragEnd}>
            <div className="hidden md:flex gap-3 overflow-x-auto pb-4 flex-1 min-h-0">
              {COLUNAS.map(col => (
                <div key={col.id} className="flex flex-col min-w-[230px] max-w-[280px] flex-1">
                  <div className={`flex items-center justify-between mb-2 px-3 py-2 rounded-t-xl border-t-[3px] ${col.bt} bg-surface-2/60`}>
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${col.dot}`} />
                      <h3 className="font-semibold text-sm text-foreground">{col.label}</h3>
                    </div>
                    <span className="bg-background/60 text-muted-foreground text-xs rounded-full px-2 py-0.5 font-medium tabular-nums">
                      {porStatusVisivel[col.id].length}
                    </span>
                  </div>
                  <ColunaDrop id={col.id}>
                    {porStatusVisivel[col.id].map(it => (
                      <LeadDrag key={it.dragId} dragId={it.dragId}><LeadCard l={it.lead} projeto={it.projeto} /></LeadDrag>
                    ))}
                    {porStatusVisivel[col.id].length === 0 && (
                      <div className="flex items-center justify-center h-20 text-muted-foreground/30 text-xs">Arraste aqui</div>
                    )}
                  </ColunaDrop>
                </div>
              ))}
            </div>
            </DndContext>

          {/* MOBILE: pills + lista */}
          <div className="md:hidden flex-1 flex flex-col min-h-0">
            <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2 flex-shrink-0">
              {COLUNAS.map(col => {
                const active = col.id === colAtiva
                return (
                  <button key={col.id} onClick={() => setColAtiva(col.id)}
                    className={`flex items-center gap-1.5 px-3 h-9 rounded-full text-[13px] font-medium border flex-shrink-0 transition-all ${
                      active ? "bg-surface-1 text-foreground border-hairline shadow-sm shadow-black/20" : "bg-transparent text-muted-fg border-hairline"
                    }`}>
                    <span className={`w-2 h-2 rounded-full ${col.dot}`} />
                    {col.label}
                    <span className={`tabular-nums ${active ? "opacity-80" : "opacity-50"}`}>{porStatusVisivel[col.id].length}</span>
                  </button>
                )
              })}
            </div>
            <div className="flex-1 overflow-y-auto space-y-2.5 pt-1 pb-4">
              {porStatusVisivel[colAtiva].length === 0 ? (
                <div className="flex items-center justify-center h-32 text-muted-foreground/40 text-sm">Nenhum lead aqui</div>
              ) : porStatusVisivel[colAtiva].map(it => <LeadCard key={it.dragId} l={it.lead} projeto={it.projeto} />)}
            </div>
          </div>
        </>
      )}

      {/* Dialog criar/editar */}
      <Dialog open={open} onOpenChange={v => { setOpen(v); if (!v) { setEditing(null); setForm(FORM_VAZIO) } }}>
        <DialogContent className={editing ? "max-w-3xl" : "max-w-md"}>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <User className="w-5 h-5 text-ios-blue" /> {editing ? "Editar Lead" : "Novo Lead"}
            </DialogTitle>
          </DialogHeader>
          <DialogBody className={editing ? "" : "space-y-3"}>
            {/* Editando, a ficha manda: quem reabre um lead quer saber onde
                parou, não corrigir o telefone. Os campos do cadastro seguem a
                um clique, na aba ao lado. No lead NOVO não há abas — não existe
                ficha nem histórico de um contato que ainda não foi salvo. */}
            {editing ? (
              <Tabs defaultValue="ficha">
                <TabsList className="bg-surface-2">
                  <TabsTrigger value="ficha">Ficha</TabsTrigger>
                  <TabsTrigger value="contato">Contato</TabsTrigger>
                  <TabsTrigger value="historico">Histórico</TabsTrigger>
                </TabsList>

                <TabsContent value="ficha" className="mt-4 max-h-[62vh] overflow-y-auto pr-1">
                  <FichaLead leadId={editing.id} valores={editing} aoSalvar={fetchLeads} />
                </TabsContent>

                <TabsContent value="contato" className="mt-4 max-h-[62vh] space-y-3 overflow-y-auto pr-1">
                  {camposDoLead}
                {editing.fat_documento && (
                  <div className="rounded-[18px] border border-hairline bg-surface-2/30 p-3.5">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="flex items-center gap-2 text-[13px] font-semibold text-foreground">
                        <BadgeCheck className="h-4 w-4 text-ios-green" /> Cadastro do cliente
                      </h4>
                      <span className="text-[10px] uppercase tracking-wide text-muted-fg">
                        {formatarDocumento(editing.fat_documento).length > 14 ? "PJ" : "PF"}
                      </span>
                    </div>
                    <dl className="mt-2 space-y-1 text-[12px]">
                      <div className="flex gap-2">
                        <dt className="w-24 flex-shrink-0 text-muted-fg">Documento</dt>
                        <dd className="text-foreground">{formatarDocumento(editing.fat_documento)}</dd>
                      </div>
                      {editing.fat_razao_social && (
                        <div className="flex gap-2">
                          <dt className="w-24 flex-shrink-0 text-muted-fg">Nome</dt>
                          <dd className="min-w-0 break-words text-foreground">{editing.fat_razao_social}</dd>
                        </div>
                      )}
                      {editing.fat_ie && (
                        <div className="flex gap-2">
                          <dt className="w-24 flex-shrink-0 text-muted-fg">IE</dt>
                          <dd className="text-foreground">{editing.fat_ie}</dd>
                        </div>
                      )}
                      {editing.fat_email && (
                        <div className="flex gap-2">
                          <dt className="w-24 flex-shrink-0 text-muted-fg">E-mail</dt>
                          <dd className="min-w-0 break-words text-foreground">{editing.fat_email}</dd>
                        </div>
                      )}
                      {editing.fat_logradouro && (
                        <div className="flex gap-2">
                          <dt className="w-24 flex-shrink-0 text-muted-fg">Endereço</dt>
                          <dd className="min-w-0 break-words text-foreground">
                            {editing.fat_logradouro}, {editing.fat_numero}
                            {editing.fat_complemento ? `, ${editing.fat_complemento}` : ""}
                            {editing.fat_bairro ? ` · ${editing.fat_bairro}` : ""}
                            <br />
                            {editing.fat_cidade}/{editing.fat_uf}
                            {editing.fat_cep ? ` · ${formatarCEP(editing.fat_cep)}` : ""}
                          </dd>
                        </div>
                      )}
                    </dl>
                    <p className="mt-2 border-t border-hairline pt-2 text-[11px] text-muted-fg">
                      {editing.fat_confirmado_em
                        ? `Conferido em ${new Date(editing.fat_confirmado_em).toLocaleDateString("pt-BR")}`
                        : "Vindo da proposta"}
                      {editing.fat_origem_proposta ? ` · ${editing.fat_origem_proposta}` : ""}
                      {" · "}edita-se na proposta, para o contrato e a nota não divergirem.
                    </p>
                  </div>
                )}
                </TabsContent>

                <TabsContent value="historico" className="mt-4">
                  <HistoricoLead leadId={editing.id} />
                </TabsContent>
              </Tabs>
            ) : camposDoLead}
          </DialogBody>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setOpen(false)}>Cancelar</Button>
            <Button onClick={salvar} disabled={saving || !form.nome.trim()}>
              {saving ? "Salvando..." : editing ? "Salvar" : "Criar lead"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Confirmação de exclusão */}
      <Dialog open={!!delTarget} onOpenChange={o => !o && setDelTarget(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Excluir lead</DialogTitle></DialogHeader>
          <DialogBody>
            <p className="text-sm text-muted-foreground">
              Excluir <span className="font-medium text-foreground">{delTarget?.nome}</span>?
              O histórico da conversa e os contatos do projeto vão junto, e não há como desfazer.
            </p>
            {/* Quem não é Admin descobre a regra ANTES de clicar, com o caminho
                alternativo escrito. Depois do clique, seria só um erro. */}
            {meuRole !== "ADMIN" && (
              <p className="mt-3 rounded-xl bg-warning/10 px-3 py-2 text-[13px] text-warning">
                Só o Admin exclui. Para tirar do funil sem perder a conversa,
                mova o lead para &ldquo;Perdido&rdquo;.
              </p>
            )}
          </DialogBody>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setDelTarget(null)}>Cancelar</Button>
            <Button variant="destructive" onClick={excluir}><Trash2 className="w-4 h-4 mr-1" /> Excluir</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Confirmação de mudança de fase, Qualificado → Criação de Proposta
          tem um fluxo próprio (perguntas em cadeia), o resto usa o genérico
          com o campo de comentário. */}
      <Dialog open={!!pendingMove} onOpenChange={o => { if (!o) { setPendingMove(null); setMotivoMovimento("") } }}>
        <DialogContent className="max-w-sm">
          {ehFluxoDeProposta ? (
            <>
              <DialogHeader><DialogTitle>Criação de Proposta</DialogTitle></DialogHeader>
              <DialogBody className="space-y-3">
                {passoProposta === "pergunta_projetos" && (
                  <p className="text-sm text-foreground">
                    <span className="font-medium">{pendingMove?.lead.nome}</span> tem mais de um projeto?
                  </p>
                )}
                {passoProposta === "pergunta_rascunho_unico" && (
                  <p className="text-sm text-foreground">Quer montar o rascunho da proposta agora?</p>
                )}
                {passoProposta === "criar_projetos" && (
                  <div className="space-y-2.5">
                    <p className="text-sm text-foreground">Nomeie os projetos dele:</p>
                    <div className="flex gap-2">
                      <Input value={nomeProjetoAtual} onChange={e => setNomeProjetoAtual(e.target.value)}
                        onKeyDown={e => {
                          if (e.key !== "Enter") return
                          e.preventDefault()
                          const nome = nomeProjetoAtual.trim()
                          if (!nome) return
                          setNovosNomesProjetos(a => [...a, nome])
                          setNomeProjetoAtual("")
                        }}
                        placeholder="Ex.: Cobertura" autoFocus />
                      <Button type="button" variant="outline" onClick={() => {
                        const nome = nomeProjetoAtual.trim()
                        if (!nome) return
                        setNovosNomesProjetos(a => [...a, nome])
                        setNomeProjetoAtual("")
                      }}>Adicionar</Button>
                    </div>
                    {novosNomesProjetos.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {novosNomesProjetos.map((nome, i) => (
                          <span key={i} className="inline-flex items-center gap-1.5 rounded-full bg-surface-1 px-3 py-1 text-xs text-foreground">
                            {nome}
                            <button type="button" onClick={() => setNovosNomesProjetos(a => a.filter((_, x) => x !== i))}
                              className="text-muted-fg hover:text-ios-red">×</button>
                          </span>
                        ))}
                      </div>
                    )}
                    <p className="text-[11px] text-muted-fg">Pelo menos dois, já que ele disse que tem mais de um.</p>
                  </div>
                )}
                {passoProposta === "pergunta_rascunho_multi" && (
                  <div className="space-y-2.5">
                    <p className="text-sm text-foreground">Quer montar o rascunho de algum projeto agora?</p>
                  </div>
                )}
                {passoProposta === "escolher_projeto_multi" && (
                  <div className="space-y-2.5">
                    <p className="text-sm text-foreground">De qual projeto?</p>
                    <div className="space-y-1.5">
                      {projetosCriados.map(proj => (
                        <button key={proj.id} type="button"
                          onClick={() => {
                            if (!pendingMove) return
                            const lead = pendingMove.lead
                            setPendingMove(null)
                            converterProjetoEmProposta(lead, proj)
                          }}
                          className="flex w-full items-center justify-between rounded-xl border border-border px-3.5 py-2.5 text-left text-sm text-foreground hover:border-primary hover:bg-muted transition-colors">
                          {proj.nome}
                          <ArrowRight className="w-3.5 h-3.5 text-muted-fg" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </DialogBody>
              <DialogFooter>
                {passoProposta === "pergunta_projetos" && (
                  <>
                    <Button variant="secondary" onClick={() => setPassoProposta("pergunta_rascunho_unico")}>Não</Button>
                    <Button onClick={() => setPassoProposta("criar_projetos")}>Sim</Button>
                  </>
                )}
                {passoProposta === "pergunta_rascunho_unico" && (
                  <>
                    <Button variant="secondary" onClick={confirmarSoAFase}>Não</Button>
                    <Button onClick={() => {
                      if (!pendingMove) return
                      const lead = pendingMove.lead
                      setPendingMove(null)
                      converterEmProposta(lead)
                    }}>Sim</Button>
                  </>
                )}
                {passoProposta === "criar_projetos" && (
                  <>
                    <Button variant="secondary" onClick={() => setPassoProposta("pergunta_projetos")}>Voltar</Button>
                    <Button
                      disabled={novosNomesProjetos.length < 2}
                      onClick={async () => {
                        if (!pendingMove) return
                        const criados = await criarProjetosEmLote(pendingMove.lead, novosNomesProjetos)
                        setProjetosCriados(criados)
                        setPassoProposta("pergunta_rascunho_multi")
                      }}>
                      Continuar
                    </Button>
                  </>
                )}
                {passoProposta === "pergunta_rascunho_multi" && (
                  <>
                    <Button variant="secondary" onClick={confirmarSoAFase}>Não</Button>
                    <Button onClick={() => setPassoProposta("escolher_projeto_multi")}>Sim</Button>
                  </>
                )}
                {passoProposta === "escolher_projeto_multi" && (
                  <Button variant="secondary" onClick={() => setPassoProposta("pergunta_rascunho_multi")}>Voltar</Button>
                )}
              </DialogFooter>
            </>
          ) : (
            <>
              <DialogHeader><DialogTitle>Mudar fase do lead</DialogTitle></DialogHeader>
              <DialogBody className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Mover <span className="text-foreground font-medium">
                    {pendingMove?.lead.nome}{pendingMove?.projeto ? ` · ${pendingMove.projeto.nome}` : ""}
                  </span> para{" "}
                  <span className="text-foreground font-medium">{COLUNAS.find(c => c.id === pendingMove?.status)?.label}</span>?
                </p>
                <div className="space-y-1.5">
                  <Label>
                    {pendingMove?.status === "PERDIDO" ? "Por que perdeu?" : "Comentário (opcional)"}
                  </Label>
                  <textarea value={motivoMovimento} onChange={e => setMotivoMovimento(e.target.value)}
                    rows={2}
                    placeholder={pendingMove?.status === "PERDIDO"
                      ? "Achou caro, fechou com outro, adiou a obra..."
                      : "O que fez a negociação avançar"}
                    className="flex w-full rounded-[16px] border border-border bg-background/60 px-4 py-2.5 text-[14px] text-foreground placeholder:text-muted-foreground focus:outline-none resize-none" />
                  <p className="text-[11px] text-muted-fg">Entra no histórico do lead junto com a mudança de fase.</p>
                </div>
              </DialogBody>
              <DialogFooter>
                <Button variant="secondary" onClick={() => { setPendingMove(null); setMotivoMovimento("") }}>Cancelar</Button>
                <Button onClick={confirmarMovimentoPendente}>Confirmar</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
