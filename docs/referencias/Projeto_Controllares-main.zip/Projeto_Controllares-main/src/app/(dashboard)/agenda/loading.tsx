export default function Loading() {
  return (
    <div className="flex flex-col gap-0 animate-pulse h-full">
      <div className="flex items-center justify-between px-5 py-3 border-b border-border">
        <div className="h-7 w-36 bg-muted rounded-xl" />
        <div className="flex gap-2">
          <div className="h-8 w-24 bg-muted rounded-xl" />
          <div className="h-8 w-24 bg-muted rounded-xl" />
        </div>
      </div>
      <div className="flex-1 p-5">
        <div className="grid grid-cols-7 gap-1">
          {Array.from({ length: 35 }).map((_, i) => (
            <div key={i} className="h-20 bg-card rounded-xl border border-border" />
          ))}
        </div>
      </div>
    </div>
  )
}
