﻿"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import {
  CalendarDays, Plus, Trash2, CheckCircle2, Circle,
  ChevronLeft, ChevronRight, AlertCircle, Flag, HardHat, CalendarCheck, RefreshCw,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { useConfirmar } from "@/components/confirmar"
import { useMemoriaDeFiltro } from "@/hooks/usar-memoria-filtro"

type Prioridade = "BAIXA" | "MEDIA" | "ALTA"
type Categoria = "GERAL" | "ADMIN" | "FINANCEIRO" | "OPERACIONAL" | "COMERCIAL" | "ENGENHARIA"
type Vista = "mes" | "semana" | "lista"

interface Tarefa {
  id: string
  titulo: string
  descricao: string | null
  prioridade: Prioridade
  categoria: Categoria
  concluida: boolean
  dataVenc: string | null
  horaInicio: string | null
  horaFim: string | null
  createdAt: string
  google_event_id: string | null
  atribuido_role: string | null
  checklist?: { texto: string; feito: boolean }[] | null
  criador: { id: string; nome: string }
  atribuido: { id: string; nome: string } | null
  obra: { id: string; client_name: string } | null
}

interface Usuario { id: string; nome: string; role: string }
interface ObraLite { id: string; client_name: string }

interface GoogleEvent {
  id: string
  titulo: string
  data: string
  horaInicio: string | null
  horaFim: string | null
  local: string | null
  descricao: string | null
  link: string | null
  colorId: string | null
}

// Google Calendar colorId → CSS color hex
const GCAL_COLORS: Record<string, string> = {
  "1": "#7986CB", "2": "#33B679", "3": "#8E24AA", "4": "#E67C73",
  "5": "#F6BF26", "6": "#F4511E", "7": "#039BE5", "8": "#616161",
  "9": "#3F51B5", "10": "#0B8043", "11": "#D50000",
}
function gcalStyle(colorId: string | null): React.CSSProperties {
  // Sem colorId = cor padrão do calendário do usuário; azul neutro
  // (verde confundia com a categoria Financeiro do site).
  const hex = GCAL_COLORS[colorId ?? ""] ?? "#039BE5"
  return { backgroundColor: hex + "30", borderLeftColor: hex, color: hex + "ee" }
}

const CATEGORIA_META: Record<Categoria, { label: string; badge: string; dot: string; chip: string }> = {
  GERAL:       { label: "Geral",       badge: "bg-slate-500/20 text-muted-foreground/70 border-slate-500/30",   dot: "bg-slate-400",   chip: "bg-slate-500/20 text-slate-200 border-l-2 border-slate-400" },
  ADMIN:       { label: "Admin",       badge: "bg-purple-500/20 text-purple-300 border-purple-500/30", dot: "bg-purple-400",  chip: "bg-purple-500/20 text-purple-100 border-l-2 border-purple-400" },
  FINANCEIRO:  { label: "Financeiro",  badge: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30", dot: "bg-emerald-400", chip: "bg-emerald-500/20 text-emerald-100 border-l-2 border-emerald-400" },
  OPERACIONAL: { label: "Operacional", badge: "bg-orange-500/20 text-orange-300 border-orange-500/30", dot: "bg-orange-400",  chip: "bg-orange-500/20 text-orange-100 border-l-2 border-orange-400" },
  COMERCIAL:   { label: "Comercial",   badge: "bg-sky-500/20 text-sky-300 border-sky-500/30",         dot: "bg-sky-400",     chip: "bg-sky-500/20 text-sky-100 border-l-2 border-sky-400" },
  ENGENHARIA:  { label: "Engenharia",  badge: "bg-indigo-500/20 text-indigo-300 border-indigo-500/30", dot: "bg-indigo-400",  chip: "bg-indigo-500/20 text-indigo-100 border-l-2 border-indigo-400" },
}

const CATEGORIAS: Categoria[] = ["GERAL", "ADMIN", "FINANCEIRO", "OPERACIONAL", "COMERCIAL", "ENGENHARIA"]
const WEEKDAYS = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"]

function flagColor(p: Prioridade) {
  if (p === "ALTA") return "text-red-400"
  if (p === "MEDIA") return "text-yellow-400"
  return "text-muted-foreground"
}

// ---- Date helpers (date-only, evitam fuso) ----
const ymd = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`
const tarefaYmd = (t: Tarefa) => (t.dataVenc ? t.dataVenc.slice(0, 10) : null)
const startOfMonth = (d: Date) => new Date(d.getFullYear(), d.getMonth(), 1)
const startOfWeek = (d: Date) => { const x = new Date(d); x.setDate(d.getDate() - d.getDay()); x.setHours(0, 0, 0, 0); return x }
const addDays = (d: Date, n: number) => { const x = new Date(d); x.setDate(d.getDate() + n); return x }
const addMonths = (d: Date, n: number) => new Date(d.getFullYear(), d.getMonth() + n, 1)
const isVencidaYmd = (s: string | null) => (s ? s < ymd(new Date()) : false)

export default function AgendaPage() {
  const confirmar = useConfirmar()
  const [tarefas, setTarefas] = useState<Tarefa[]>([])
  const [usuarios, setUsuarios] = useState<Usuario[]>([])
  const [obras, setObras] = useState<ObraLite[]>([])
  const [loading, setLoading] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)
  const [googleEventos, setGoogleEventos] = useState<GoogleEvent[]>([])
  const [googleConectado, setGoogleConectado] = useState(false)
  const [mostrarGoogle, setMostrarGoogle] = useState(true)
  const [googleFeitos, setGoogleFeitos] = useState<Set<string>>(new Set()) // dismissed localmente
  const [syncing, setSyncing] = useState(false)
  const [lastSync, setLastSync] = useState<Date | null>(null)
  const syncRangeRef = useRef<{ start: string; end: string } | null>(null)

  // Vista e navegação
  const [vista, setVista] = useState<Vista>("mes")
  const [refDate, setRefDate] = useState(new Date())

  // Filtros
  const [filtroCategoria, setFiltroCategoria] = useMemoriaDeFiltro<Categoria | "TODAS">("agenda:categoria", "TODAS")
  const [filtroResponsavel, setFiltroResponsavel] = useMemoriaDeFiltro<string>("agenda:responsavel", "TODOS")
  const [ocultarConcluidas, setOcultarConcluidas] = useState(true)

  // Create dialog
  const [createOpen, setCreateOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({ titulo: "", descricao: "", prioridade: "MEDIA" as Prioridade, categoria: "GERAL" as Categoria, dataVenc: "", horaInicio: "", horaFim: "", atribuidoA: "", atribuido_role: "", obraId: "" })
  const [erro, setErro] = useState("")

  // Detail/edit dialog
  const [sel, setSel] = useState<Tarefa | null>(null)
  const [editForm, setEditForm] = useState({ titulo: "", descricao: "", prioridade: "MEDIA" as Prioridade, categoria: "GERAL" as Categoria, dataVenc: "", horaInicio: "", horaFim: "", atribuidoA: "", atribuido_role: "" })
  const [editSaving, setEditSaving] = useState(false)

  const fetchTarefas = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/tarefas")
      if (res.ok) setTarefas((await res.json()).tarefas || [])
    } finally {
      setLoading(false)
    }
  }, [])

  const fetchUsuarios = useCallback(async () => {
    const res = await fetch("/api/usuarios")
    if (res.ok) setUsuarios((await res.json()).users || [])
  }, [])

  const fetchObras = useCallback(async () => {
    const res = await fetch("/api/obras")
    if (res.ok) {
      const data = await res.json()
      setObras((data.obras || []).map((o: ObraLite) => ({ id: o.id, client_name: o.client_name })))
    }
  }, [])

  const fetchMe = useCallback(async () => {
    const res = await fetch("/api/auth/me")
    if (res.ok) setIsAdmin((await res.json()).user?.role === "ADMIN")
  }, [])

  const fetchGoogleEventos = useCallback(async (start: string, end: string) => {
    const res = await fetch(`/api/integracoes/google/events?start=${start}&end=${end}`)
    if (!res.ok) return
    const data = await res.json()
    setGoogleConectado(!!data.conectado)
    setGoogleEventos(data.eventos ?? [])
    setLastSync(new Date())
  }, [])

  const syncGoogleNow = useCallback(async () => {
    if (!syncRangeRef.current) return
    setSyncing(true)
    try {
      await fetchGoogleEventos(syncRangeRef.current.start, syncRangeRef.current.end)
    } finally {
      setSyncing(false)
    }
  }, [fetchGoogleEventos])

  // Calcula o range visível e busca eventos do Google
  useEffect(() => {
    let start: Date, end: Date
    if (vista === "mes") {
      start = startOfWeek(startOfMonth(refDate))
      end = addDays(start, 41)
    } else if (vista === "semana") {
      start = startOfWeek(refDate)
      end = addDays(start, 6)
    } else {
      start = new Date(); start.setDate(1); start.setMonth(start.getMonth() - 1)
      end = addDays(start, 90)
    }
    const s = ymd(start), e = ymd(end)
    syncRangeRef.current = { start: s, end: e }
    fetchGoogleEventos(s, e)
  }, [vista, refDate, fetchGoogleEventos])

  // Auto-sync a cada 5 minutos
  useEffect(() => {
    const id = setInterval(() => { syncGoogleNow() }, 5 * 60 * 1000)
    return () => clearInterval(id)
  }, [syncGoogleNow])

  useEffect(() => { fetchMe(); fetchTarefas(); fetchUsuarios(); fetchObras() }, [fetchMe, fetchTarefas, fetchUsuarios, fetchObras])

  // ---- Mutations ----
  async function toggleConcluida(t: Tarefa) {
    await fetch(`/api/tarefas/${t.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ concluida: !t.concluida }),
    })
    setTarefas(prev => prev.map(x => x.id === t.id ? { ...x, concluida: !t.concluida } : x))
    setSel(s => s && s.id === t.id ? { ...s, concluida: !t.concluida } : s)
  }

  async function handleCreate() {
    if (!form.titulo.trim()) return
    setSaving(true); setErro("")
    try {
      const res = await fetch("/api/tarefas", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          titulo: form.titulo, descricao: form.descricao || undefined,
          prioridade: form.prioridade, categoria: form.categoria,
          dataVenc: form.dataVenc || undefined,
          horaInicio: form.horaInicio || undefined, horaFim: form.horaFim || undefined,
          atribuidoA: form.atribuidoA || undefined,
          atribuido_role: form.atribuido_role || undefined,
          obraId: form.obraId || undefined,
        }),
      })
      if (res.ok) {
        const nova = await res.json()
        setTarefas(prev => [nova, ...prev])
        setCreateOpen(false)
        setForm({ titulo: "", descricao: "", prioridade: "MEDIA", categoria: "GERAL", dataVenc: "", horaInicio: "", horaFim: "", atribuidoA: "", atribuido_role: "", obraId: "" })
        // Pós-salvar: oferece envio ao Google Agenda (só faz sentido com data)
        if (nova.dataVenc) setGooglePrompt(nova)
      } else {
        const msg = await res.json().catch(() => ({}))
        setErro(msg.error || "Falha ao criar tarefa. Reinicie o servidor de desenvolvimento.")
      }
    } catch {
      setErro("Erro de conexão ao criar a tarefa.")
    } finally {
      setSaving(false)
    }
  }

  function abrirTarefa(t: Tarefa) {
    setSel(t)
    setEditForm({
      titulo: t.titulo, descricao: t.descricao || "",
      prioridade: t.prioridade, categoria: t.categoria,
      dataVenc: t.dataVenc ? t.dataVenc.slice(0, 10) : "",
      horaInicio: t.horaInicio || "", horaFim: t.horaFim || "",
      atribuidoA: t.atribuido?.id || "",
      atribuido_role: t.atribuido_role || "",
    })
  }

  async function handleUpdate() {
    if (!sel || !editForm.titulo.trim()) return
    setEditSaving(true)
    try {
      const res = await fetch(`/api/tarefas/${sel.id}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          titulo: editForm.titulo, descricao: editForm.descricao,
          prioridade: editForm.prioridade, categoria: editForm.categoria,
          dataVenc: editForm.dataVenc || null,
          horaInicio: editForm.horaInicio || null, horaFim: editForm.horaFim || null,
          atribuidoA: editForm.atribuidoA || null,
          atribuido_role: editForm.atribuido_role || null,
        }),
      })
      if (res.ok) {
        const upd = await res.json()
        setTarefas(prev => prev.map(x => x.id === upd.id ? upd : x))
        setSel(null)
      }
    } finally {
      setEditSaving(false)
    }
  }

  async function handleDelete() {
    if (!sel) return
    await fetch(`/api/tarefas/${sel.id}`, { method: "DELETE" })
    setTarefas(prev => prev.filter(t => t.id !== sel.id))
    setSel(null)
  }

  // Checklist do agendamento — salva a cada alteração (otimista)
  const [novoItemCheck, setNovoItemCheck] = useState("")
  async function salvarChecklist(t: Tarefa, lista: { texto: string; feito: boolean }[]) {
    setSel(s => s && s.id === t.id ? { ...s, checklist: lista } : s)
    setTarefas(prev => prev.map(x => x.id === t.id ? { ...x, checklist: lista } : x))
    await fetch(`/api/tarefas/${t.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ checklist: lista }),
    })
  }

  const [pushingGoogle, setPushingGoogle] = useState(false)
  // Popup pós-criação: "enviar para o Google Agenda?"
  const [googlePrompt, setGooglePrompt] = useState<Tarefa | null>(null)
  const [googlePromptBusy, setGooglePromptBusy] = useState(false)
  async function confirmarEnvioGoogle() {
    if (!googlePrompt) return
    setGooglePromptBusy(true)
    try {
      const res = await fetch(`/api/integracoes/google/push-tarefa/${googlePrompt.id}`, { method: "POST" })
      const j = await res.json().catch(() => ({}))
      if (res.ok) {
        setTarefas(prev => prev.map(t => t.id === googlePrompt.id ? { ...t, google_event_id: j.google_event_id } : t))
      } else {
        await confirmar({ titulo: j.error || "Falha ao enviar para o Google.", apenasAviso: true })
      }
      setGooglePrompt(null)
    } finally {
      setGooglePromptBusy(false)
    }
  }
  async function enviarParaGoogle() {
    if (!sel) return
    setPushingGoogle(true)
    try {
      const res = await fetch(`/api/integracoes/google/push-tarefa/${sel.id}`, { method: "POST" })
      const j = await res.json().catch(() => ({}))
      if (res.ok) {
        setTarefas(prev => prev.map(t => t.id === sel.id ? { ...t, google_event_id: j.google_event_id } : t))
        setSel(s => s ? { ...s, google_event_id: j.google_event_id } : s)
      } else {
        await confirmar({ titulo: j.error || "Falha ao enviar para o Google.", apenasAviso: true })
      }
    } finally {
      setPushingGoogle(false)
    }
  }

  async function removerDoGoogle() {
    if (!sel) return
    setPushingGoogle(true)
    try {
      await fetch(`/api/integracoes/google/push-tarefa/${sel.id}`, { method: "DELETE" })
      setTarefas(prev => prev.map(t => t.id === sel.id ? { ...t, google_event_id: null } : t))
      setSel(s => s ? { ...s, google_event_id: null } : s)
    } finally {
      setPushingGoogle(false)
    }
  }

  // ---- Filtros aplicados ----
  const visiveis = tarefas.filter(t => {
    if (filtroCategoria !== "TODAS" && t.categoria !== filtroCategoria) return false
    if (isAdmin && filtroResponsavel !== "TODOS") {
      if (filtroResponsavel === "SEM") { if (t.atribuido) return false }
      else if (t.atribuido?.id !== filtroResponsavel) return false
    }
    if (ocultarConcluidas && t.concluida) return false
    return true
  })

  const pendentes = visiveis.filter(t => !t.concluida).length
  const vencidas = visiveis.filter(t => !t.concluida && isVencidaYmd(tarefaYmd(t))).length

  // Mapa data -> tarefas
  const porDia: Record<string, Tarefa[]> = {}
  visiveis.forEach(t => {
    const k = tarefaYmd(t)
    if (!k) return
    if (!porDia[k]) porDia[k] = []
    porDia[k].push(t)
  })

  // Mapa data -> eventos Google (oculta quando há filtro de categoria ativo)
  // Esconde eventos que são ESPELHO de tarefas do site (enviadas ao Google) —
  // senão a mesma coisa aparece duas vezes no calendário.
  const idsEspelhados = new Set(tarefas.map(t => t.google_event_id).filter(Boolean))
  const googleVisiveis = mostrarGoogle && filtroCategoria === "TODAS"
    ? googleEventos.filter(ev => !idsEspelhados.has(ev.id))
    : []
  const googlePorDia: Record<string, GoogleEvent[]> = {}
  googleVisiveis.forEach(ev => {
    if (!ev.data) return
    if (!googlePorDia[ev.data]) googlePorDia[ev.data] = []
    googlePorDia[ev.data].push(ev)
  })

  // Rótulo do período
  const periodoLabel = vista === "mes"
    ? refDate.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })
    : vista === "semana"
      ? (() => {
          const ini = startOfWeek(refDate); const fim = addDays(ini, 6)
          const mesIni = ini.toLocaleDateString("pt-BR", { month: "short" })
          const mesFim = fim.toLocaleDateString("pt-BR", { month: "short" })
          return `${ini.getDate()} ${mesIni} – ${fim.getDate()} ${mesFim} ${fim.getFullYear()}`
        })()
      : "Todas as tarefas"

  function navegar(dir: -1 | 1) {
    if (vista === "mes") setRefDate(d => addMonths(d, dir))
    else if (vista === "semana") setRefDate(d => addDays(d, dir * 7))
  }

  function novoNoDia(dateStr: string) {
    setForm(f => ({ ...f, dataVenc: dateStr }))
    setErro("")
    setCreateOpen(true)
  }

  return (
    <div className="flex flex-col h-[calc(100vh-3.5rem)]">
      {/* Toolbar */}
      <div className="px-4 md:px-5 py-3 border-b border-border bg-card/50 backdrop-blur-sm space-y-2.5 md:space-y-0 md:flex md:items-center md:gap-3 md:flex-wrap">
        {/* Linha 1: mês + navegação + Nova */}
        <div className="flex items-center gap-2 md:contents">
          <h1 className="text-[15px] font-semibold text-foreground mr-1 hidden md:block">Agenda</h1>

          <Button variant="outline" size="sm" onClick={() => setRefDate(new Date())} className="h-8 flex-shrink-0 md:order-none order-2">
            Hoje
          </Button>

          {vista !== "lista" && (
            <div className="flex items-center md:order-none order-1">
              <button onClick={() => navegar(-1)} className="p-1.5 rounded-2xl hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button onClick={() => navegar(1)} className="p-1.5 rounded-2xl hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          )}

          <span className="text-foreground font-semibold capitalize md:min-w-[160px] text-[17px] md:text-base flex-1 md:flex-none truncate">{periodoLabel}</span>

          <span className="hidden md:inline text-xs text-muted-foreground">
            {isAdmin ? "Todas da empresa" : "Minhas tarefas"} · {pendentes} pendente{pendentes !== 1 ? "s" : ""}
            {vencidas > 0 && <span className="ml-1 text-destructive">· {vencidas} vencida{vencidas !== 1 ? "s" : ""}</span>}
          </span>

          <div className="md:flex-1 hidden md:block" />

          {/* Nova Tarefa, só ícone no mobile */}
          <Button onClick={() => { setForm(f => ({ ...f, dataVenc: ymd(refDate) })); setErro(""); setCreateOpen(true) }}
            size="sm" className="h-9 w-9 md:h-8 md:w-auto p-0 md:px-3 flex-shrink-0 md:order-last order-3">
            <Plus className="w-4 h-4 md:mr-1" /> <span className="hidden md:inline">Nova Tarefa</span>
          </Button>
        </div>

        {/* Linha 2: seletor de vista + google */}
        <div className="flex items-center gap-2 md:contents">
          <div className="flex rounded-xl bg-surface-3 p-1 flex-1 md:flex-none gap-0.5">
            {(["mes", "semana", "lista"] as const).map(v => (
              <button key={v} onClick={() => setVista(v)}
                className={`flex-1 md:flex-none px-3 py-1.5 md:py-1 rounded-lg text-xs font-medium transition-all duration-150 ${
                  vista === v ? "bg-surface-1 text-foreground shadow-sm shadow-black/20" : "text-muted-fg hover:text-foreground"
                }`}>
                {v === "mes" ? "Mês" : v === "semana" ? "Semana" : "Lista"}
              </button>
            ))}
          </div>

          {googleConectado ? (
            <div className="flex items-center gap-1 flex-shrink-0">
              <button
                onClick={() => setMostrarGoogle(v => !v)}
                className={`flex items-center gap-1.5 px-3 h-9 md:h-8 rounded-xl text-xs font-medium border transition-colors ${
                  mostrarGoogle
                    ? "bg-green-500/10 text-green-600 dark:text-green-300 border-green-500/30 hover:bg-green-500/20"
                    : "bg-transparent text-muted-foreground border-border hover:text-foreground"
                }`}>
                <CalendarCheck className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Google Agenda</span>
              </button>
              <button onClick={syncGoogleNow} disabled={syncing}
                title={lastSync ? `Última sync: ${lastSync.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}` : "Sincronizar"}
                className="h-9 w-9 md:h-8 md:w-8 flex items-center justify-center rounded-xl border border-border text-muted-foreground hover:text-green-500 hover:border-green-500/40 disabled:opacity-50 transition-colors">
                <RefreshCw className={`w-3.5 h-3.5 ${syncing ? "animate-spin" : ""}`} />
              </button>
            </div>
          ) : (
            <a href="/api/integracoes/google/auth"
              className="flex items-center gap-1.5 px-3 h-9 md:h-8 rounded-xl text-xs font-medium border border-border bg-transparent text-muted-foreground hover:text-green-500 hover:border-green-500/40 transition-colors flex-shrink-0 whitespace-nowrap">
              <CalendarCheck className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Conectar Google Agenda</span>
              <span className="sm:hidden">Google</span>
            </a>
          )}
        </div>
      </div>

      {/* Filtros */}
      <div className="flex items-center gap-2 md:flex-wrap px-4 md:px-5 py-2 border-b border-border/50 bg-muted/10 overflow-x-auto md:overflow-visible no-scrollbar">
        <button
          onClick={() => setFiltroCategoria("TODAS")}
          className={`flex-shrink-0 px-2.5 py-1 rounded-full text-xs font-medium border transition-colors ${
            filtroCategoria === "TODAS" ? "bg-muted text-foreground border-border" : "bg-transparent text-muted-foreground border-border/50 hover:text-foreground"
          }`}>
          Todas categorias
        </button>
        {CATEGORIAS.map(c => (
          <button key={c} onClick={() => setFiltroCategoria(c)}
            className={`flex-shrink-0 px-2.5 py-1 rounded-full text-xs font-medium border transition-colors flex items-center gap-1.5 ${
              filtroCategoria === c ? CATEGORIA_META[c].badge : "bg-transparent text-muted-foreground border-border/50 hover:text-foreground"
            }`}>
            <span className={`w-2 h-2 rounded-full ${CATEGORIA_META[c].dot}`} />
            {CATEGORIA_META[c].label}
          </button>
        ))}

        <div className="flex-1 hidden md:block" />

        <label className="hidden md:flex items-center gap-1.5 text-xs text-muted-foreground cursor-pointer select-none">
          <input type="checkbox" checked={ocultarConcluidas} onChange={e => setOcultarConcluidas(e.target.checked)}
            className="accent-primary" />
          Ocultar concluídas
        </label>

        {isAdmin && (
          <select value={filtroResponsavel} onChange={e => setFiltroResponsavel(e.target.value)}
            className="hidden md:block h-8 px-2 rounded-xl bg-muted/50 border border-border text-foreground text-xs focus:outline-none focus:ring-1 focus:ring-primary/30">
            <option value="TODOS">Todos os colaboradores</option>
            <option value="SEM">Sem responsável</option>
            {usuarios.map(u => <option key={u.id} value={u.id}>{u.nome}</option>)}
          </select>
        )}
      </div>

      {/* Conteúdo */}
      <div className="flex-1 overflow-auto">
        {loading ? (
          <div className="text-center py-20 text-muted-foreground">Carregando...</div>
        ) : vista === "mes" ? (
          <MonthGrid refDate={refDate} porDia={porDia} googlePorDia={googlePorDia} onDayClick={novoNoDia} onTaskClick={abrirTarefa} onToggle={toggleConcluida} />
        ) : vista === "semana" ? (
          <WeekView refDate={refDate} porDia={porDia} googlePorDia={googlePorDia} onDayClick={novoNoDia} onTaskClick={abrirTarefa} onToggle={toggleConcluida} />
        ) : (
          <ListView
            tarefas={visiveis}
            googleEventos={ocultarConcluidas ? googleVisiveis.filter(ev => !googleFeitos.has(ev.id)) : googleVisiveis}
            googleFeitos={googleFeitos}
            onToggleGoogle={id => setGoogleFeitos(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n })}
            onTaskClick={abrirTarefa}
            onToggle={toggleConcluida}
            usuarios={usuarios}
            obras={obras}
            onImportGoogle={ev => {
              setForm(f => ({
                ...f,
                titulo: ev.titulo,
                descricao: ev.descricao ?? "",
                dataVenc: ev.data ?? "",
                horaInicio: ev.horaInicio ?? "",
                horaFim: ev.horaFim ?? "",
                categoria: "OPERACIONAL",
              }))
              setCreateOpen(true)
            }}
          />
        )}
      </div>

      {/* Create dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Nova Tarefa</DialogTitle></DialogHeader>
          <div className="space-y-4 px-5 sm:px-6 py-4">
            <div className="space-y-1">
              <Label className="text-sm">Título *</Label>
              <Input value={form.titulo} onChange={e => setForm(f => ({ ...f, titulo: e.target.value }))}
                className="" placeholder="O que precisa ser feito?" />
            </div>
            <div className="space-y-1">
              <Label className="text-sm">Descrição</Label>
              <Textarea value={form.descricao} onChange={e => setForm(f => ({ ...f, descricao: e.target.value }))}
                className="bg-card border-border text-white resize-none" rows={2} placeholder="Detalhes (opcional)" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label className="text-sm">Categoria</Label>
                <select value={form.categoria} onChange={e => setForm(f => ({ ...f, categoria: e.target.value as Categoria }))}
                  className="flex h-10 w-full rounded-xl border border-border bg-muted/50 px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/30">
                  {CATEGORIAS.map(c => <option key={c} value={c}>{CATEGORIA_META[c].label}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <Label className="text-sm">Prioridade</Label>
                <select value={form.prioridade} onChange={e => setForm(f => ({ ...f, prioridade: e.target.value as Prioridade }))}
                  className="flex h-10 w-full rounded-xl border border-border bg-muted/50 px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/30">
                  <option value="BAIXA">Baixa</option><option value="MEDIA">Média</option><option value="ALTA">Alta</option>
                </select>
              </div>
              <div className="space-y-1">
                <Label className="text-sm">Prazo</Label>
                <Input type="date" max="9999-12-31" value={form.dataVenc} onChange={e => setForm(f => ({ ...f, dataVenc: e.target.value }))}
                  className="" />
              </div>
              <div className="space-y-1 col-span-2">
                <Label className="text-sm">Enviar para</Label>
                <div className="grid grid-cols-2 gap-2">
                  {/* Destinatário: pessoa específica */}
                  <div>
                    <p className="text-[11px] text-muted-foreground mb-1">Pessoa específica</p>
                    <select value={form.atribuidoA} onChange={e => setForm(f => ({ ...f, atribuidoA: e.target.value, atribuido_role: e.target.value ? "" : f.atribuido_role }))}
                      className="flex h-9 w-full rounded-xl border border-border bg-muted/50 px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/30">
                      <option value="">Ninguém</option>
                      {usuarios.map(u => <option key={u.id} value={u.id}>{u.nome} ({u.role})</option>)}
                    </select>
                  </div>
                  {/* Destinatário: role inteiro */}
                  <div>
                    <p className="text-[11px] text-muted-foreground mb-1">Setor / perfil inteiro</p>
                    <select value={form.atribuido_role} onChange={e => setForm(f => ({ ...f, atribuido_role: e.target.value, atribuidoA: e.target.value ? "" : f.atribuidoA }))}
                      className="flex h-9 w-full rounded-xl border border-border bg-muted/50 px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/30">
                      <option value="">Não enviar para setor</option>
                      <option value="OPERACIONAL">Operacional (técnicos + responsáveis)</option>
                      <option value="FINANCEIRO">Financeiro</option>
                      <option value="COMERCIAL">Comercial (vendedores)</option>
                      <option value="ENGENHARIA">Engenharia</option>
                      <option value="ADMIN">Admin</option>
                    </select>
                  </div>
                </div>
                {(form.atribuidoA || form.atribuido_role) && (
                  <p className="text-[11px] text-sky-400 mt-1">
                    {form.atribuidoA
                      ? `Enviado para: ${usuarios.find(u => u.id === form.atribuidoA)?.nome}`
                      : `Visível para todos do setor ${form.atribuido_role}`}
                  </p>
                )}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label className="text-sm">Hora início</Label>
                <Input type="time" value={form.horaInicio} onChange={e => setForm(f => ({ ...f, horaInicio: e.target.value }))}
                  className="" />
              </div>
              <div className="space-y-1">
                <Label className="text-sm">Hora fim</Label>
                <Input type="time" value={form.horaFim} onChange={e => setForm(f => ({ ...f, horaFim: e.target.value }))}
                  className="" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground -mt-1">Sem hora início = tarefa de dia inteiro.</p>
            <div className="space-y-1">
              <Label className="text-sm">Vincular a uma obra (opcional)</Label>
              <select value={form.obraId}
                onChange={e => setForm(f => ({ ...f, obraId: e.target.value, categoria: e.target.value && f.categoria === "GERAL" ? "OPERACIONAL" : f.categoria }))}
                className="flex h-10 w-full rounded-xl border border-border bg-muted/50 px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/30">
                <option value="">Nenhuma (tarefa avulsa)</option>
                {obras.map(o => <option key={o.id} value={o.id}>{o.client_name}</option>)}
              </select>
            </div>
            {erro && (
              <div className="rounded-2xl bg-red-500/10 border border-red-500/30 px-3 py-2 text-sm text-red-300">{erro}</div>
            )}
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setCreateOpen(false)}>Cancelar</Button>
            <Button onClick={handleCreate} disabled={saving || !form.titulo.trim()}>
              {saving ? "Salvando..." : "Criar Tarefa"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Detail / edit dialog */}
      <Dialog open={!!sel} onOpenChange={o => !o && setSel(null)}>
        <DialogContent className="max-w-md">
          {sel && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded-full border text-[10px] font-medium ${CATEGORIA_META[sel.categoria].badge}`}>
                    {CATEGORIA_META[sel.categoria].label}
                  </span>
                  {sel.obra && (
                    <span className="text-orange-300 text-xs flex items-center gap-1">
                      <HardHat className="w-3.5 h-3.5" /> {sel.obra.client_name}
                    </span>
                  )}
                  {sel.atribuido_role && (
                    <span className="text-sky-300 text-[10px] px-1.5 py-0.5 rounded-full border border-sky-500/30 bg-sky-500/10">
                      → {sel.atribuido_role}
                    </span>
                  )}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 px-5 sm:px-6 py-4">
                <div className="space-y-1">
                  <Label className="text-sm">Título</Label>
                  <Input value={editForm.titulo} onChange={e => setEditForm(f => ({ ...f, titulo: e.target.value }))}
                    className="" />
                </div>
                <div className="space-y-1">
                  <Label className="text-sm">Descrição</Label>
                  <Textarea value={editForm.descricao} onChange={e => setEditForm(f => ({ ...f, descricao: e.target.value }))}
                    className="bg-card border-border text-white resize-none" rows={2} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label className="text-sm">Categoria</Label>
                    <select value={editForm.categoria} onChange={e => setEditForm(f => ({ ...f, categoria: e.target.value as Categoria }))}
                      className="flex h-10 w-full rounded-xl border border-border bg-muted/50 px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/30">
                      {CATEGORIAS.map(c => <option key={c} value={c}>{CATEGORIA_META[c].label}</option>)}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-sm">Prioridade</Label>
                    <select value={editForm.prioridade} onChange={e => setEditForm(f => ({ ...f, prioridade: e.target.value as Prioridade }))}
                      className="flex h-10 w-full rounded-xl border border-border bg-muted/50 px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/30">
                      <option value="BAIXA">Baixa</option><option value="MEDIA">Média</option><option value="ALTA">Alta</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-sm">Prazo</Label>
                    <Input type="date" max="9999-12-31" value={editForm.dataVenc} onChange={e => setEditForm(f => ({ ...f, dataVenc: e.target.value }))}
                      className="" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-sm">Pessoa</Label>
                    <select value={editForm.atribuidoA} onChange={e => setEditForm(f => ({ ...f, atribuidoA: e.target.value, atribuido_role: e.target.value ? "" : f.atribuido_role }))}
                      className="flex h-10 w-full rounded-xl border border-border bg-muted/50 px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/30">
                      <option value="">Ninguém</option>
                      {usuarios.map(u => <option key={u.id} value={u.id}>{u.nome}</option>)}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-sm">Setor / role</Label>
                    <select value={editForm.atribuido_role} onChange={e => setEditForm(f => ({ ...f, atribuido_role: e.target.value, atribuidoA: e.target.value ? "" : f.atribuidoA }))}
                      className="flex h-10 w-full rounded-xl border border-border bg-muted/50 px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/30">
                      <option value="">Não enviar para setor</option>
                      <option value="OPERACIONAL">Operacional</option>
                      <option value="FINANCEIRO">Financeiro</option>
                      <option value="COMERCIAL">Comercial</option>
                      <option value="ENGENHARIA">Engenharia</option>
                      <option value="ADMIN">Admin</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label className="text-sm">Hora início</Label>
                    <Input type="time" value={editForm.horaInicio} onChange={e => setEditForm(f => ({ ...f, horaInicio: e.target.value }))}
                      className="" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-sm">Hora fim</Label>
                    <Input type="time" value={editForm.horaFim} onChange={e => setEditForm(f => ({ ...f, horaFim: e.target.value }))}
                      className="" />
                  </div>
                </div>
                {/* Checklist do agendamento */}
                <div className="space-y-1.5">
                  <Label className="text-sm">Checklist</Label>
                  {(sel.checklist ?? []).map((item, i) => (
                    <div key={i} className="flex items-center gap-2 group">
                      <button onClick={() => salvarChecklist(sel, (sel.checklist ?? []).map((x, j) => j === i ? { ...x, feito: !x.feito } : x))}
                        className={`w-5 h-5 rounded-md border flex items-center justify-center flex-shrink-0 transition-colors ${
                          item.feito ? "bg-ios-green border-ios-green text-background" : "border-border hover:border-ios-green/50"
                        }`}>
                        {item.feito && <CheckCircle2 className="w-3.5 h-3.5" />}
                      </button>
                      <span className={`flex-1 text-sm ${item.feito ? "line-through text-muted-foreground/50" : "text-foreground"}`}>{item.texto}</span>
                      <button onClick={() => salvarChecklist(sel, (sel.checklist ?? []).filter((_, j) => j !== i))}
                        className="opacity-0 group-hover:opacity-100 text-muted-foreground/50 hover:text-ios-red transition-opacity">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                  <div className="flex gap-2">
                    <Input value={novoItemCheck} onChange={e => setNovoItemCheck(e.target.value)}
                      onKeyDown={e => {
                        if (e.key === "Enter" && novoItemCheck.trim()) {
                          salvarChecklist(sel, [...(sel.checklist ?? []), { texto: novoItemCheck.trim(), feito: false }])
                          setNovoItemCheck("")
                        }
                      }}
                      placeholder="Adicionar item... (Enter)" className="h-9 text-sm" />
                  </div>
                </div>

                <button onClick={() => toggleConcluida(sel)}
                  className={`w-full flex items-center justify-center gap-2 py-2 rounded-2xl text-sm font-medium transition-colors ${
                    sel.concluida ? "bg-green-500/10 text-green-600 dark:text-green-300 hover:bg-green-500/20" : "bg-muted text-muted-foreground hover:bg-muted/80"
                  }`}>
                  {sel.concluida ? <CheckCircle2 className="w-4 h-4" /> : <Circle className="w-4 h-4" />}
                  {sel.concluida ? "Concluída" : "Marcar como concluída"}
                </button>

                {/* Google Calendar */}
                {googleConectado && (
                  sel.google_event_id ? (
                    <div className="flex items-center gap-2">
                      <span className="flex-1 flex items-center justify-center gap-2 py-2 rounded-2xl text-sm font-medium bg-green-600/20 text-green-300">
                        <CalendarCheck className="w-4 h-4" /> No Google Agenda
                      </span>
                      <button onClick={removerDoGoogle} disabled={pushingGoogle}
                        className="px-3 py-2 rounded-2xl text-xs text-red-400 hover:bg-red-500/10 disabled:opacity-50">
                        Remover
                      </button>
                    </div>
                  ) : (
                    <button onClick={enviarParaGoogle} disabled={pushingGoogle || !editForm.dataVenc}
                      className="w-full flex items-center justify-center gap-2 py-2 rounded-2xl text-sm font-medium bg-green-600/15 text-green-300 hover:bg-green-600/25 disabled:opacity-50">
                      <CalendarCheck className="w-4 h-4" />
                      {pushingGoogle ? "Enviando..." : "Enviar para Google Agenda"}
                    </button>
                  )
                )}

                <p className="text-xs text-muted-foreground">Criada por {sel.criador.nome}</p>
              </div>
              <DialogFooter className="flex items-center justify-between sm:justify-between">
                <Button variant="ghost" onClick={handleDelete} className="text-red-400 hover:text-red-300 hover:bg-red-500/10">
                  <Trash2 className="w-4 h-4 mr-1" /> Excluir
                </Button>
                <div className="flex gap-2">
                  <Button variant="ghost" onClick={() => setSel(null)}>Fechar</Button>
                  <Button onClick={handleUpdate} disabled={editSaving || !editForm.titulo.trim()}>
                    {editSaving ? "Salvando..." : "Salvar"}
                  </Button>
                </div>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Popup pós-criação: enviar ao Google Agenda? */}
      <Dialog open={!!googlePrompt} onOpenChange={o => !o && setGooglePrompt(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Enviar para o Google Agenda?</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">
            Tarefa <b className="text-foreground">{googlePrompt?.titulo}</b> salva.
            Quer espelhar no seu Google Agenda com a cor da categoria?
          </p>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setGooglePrompt(null)} disabled={googlePromptBusy}>
              Agora não
            </Button>
            <Button onClick={confirmarEnvioGoogle} disabled={googlePromptBusy}>
              {googlePromptBusy ? "Enviando..." : "Enviar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Vista de Mês — grade estilo Google Agenda
// ============================================================
function MonthGrid({ refDate, porDia, googlePorDia, onDayClick, onTaskClick, onToggle }: {
  refDate: Date
  porDia: Record<string, Tarefa[]>
  googlePorDia: Record<string, GoogleEvent[]>
  onDayClick: (d: string) => void
  onTaskClick: (t: Tarefa) => void
  onToggle: (t: Tarefa) => void
}) {
  const gridStart = startOfWeek(startOfMonth(refDate))
  const hoje = ymd(new Date())
  const cells = Array.from({ length: 42 }, (_, i) => addDays(gridStart, i))
  const [selectedDay, setSelectedDay] = useState<string>(hoje)

  const selTarefas = porDia[selectedDay] || []
  const selEventos = googlePorDia[selectedDay] || []
  const selLabel = (() => {
    const [y, m, d] = selectedDay.split("-").map(Number)
    return new Date(y, m - 1, d).toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" })
  })()

  return (
    <>
      {/* ── DESKTOP: grade com chips ── */}
      <div className="hidden md:flex flex-col h-full min-h-[520px]">
        <div className="grid grid-cols-7 border-b border-border">
          {WEEKDAYS.map(d => (
            <div key={d} className="text-center text-xs font-medium text-muted-foreground py-2">{d}</div>
          ))}
        </div>
        <div className="grid grid-cols-7 grid-rows-6 flex-1">
          {cells.map((cell, i) => {
            const key = ymd(cell)
            const doMes = cell.getMonth() === refDate.getMonth()
            const ehHoje = key === hoje
            const tarefasDia = porDia[key] || []
            const gEventos = googlePorDia[key] || []
            const totalItens = tarefasDia.length + gEventos.length
            const MAX = 4
            return (
              <div key={i}
                onClick={() => onDayClick(key)}
                className={`border-b border-r border-border/50 p-1 overflow-hidden cursor-pointer transition-colors hover:bg-muted/20 ${
                  doMes ? "bg-transparent" : "bg-muted/10"
                }`}>
                <div className="flex justify-end">
                  <span className={`text-xs w-6 h-6 flex items-center justify-center rounded-full ${
                    ehHoje ? "bg-primary text-primary-foreground font-semibold" : doMes ? "text-foreground/80" : "text-muted-foreground/40"
                  }`}>
                    {cell.getDate()}
                  </span>
                </div>
                <div className="space-y-0.5 mt-0.5">
                  {tarefasDia.slice(0, MAX).map(t => (
                    <button key={t.id}
                      onClick={e => { e.stopPropagation(); onTaskClick(t) }}
                      className={`w-full text-left px-1.5 py-0.5 rounded text-[11px] truncate flex items-center gap-1 ${CATEGORIA_META[t.categoria].chip} ${
                        t.concluida ? "opacity-50 line-through" : ""
                      }`}>
                      <span onClick={e => { e.stopPropagation(); onToggle(t) }}
                        className="flex-shrink-0 hover:scale-110 transition-transform">
                        {t.concluida ? <CheckCircle2 className="w-3 h-3" /> : <Circle className="w-3 h-3 opacity-60" />}
                      </span>
                      {t.horaInicio && <span className="opacity-70 tabular-nums flex-shrink-0">{t.horaInicio}</span>}
                      <span className="truncate">{t.titulo}</span>
                    </button>
                  ))}
                  {gEventos.slice(0, Math.max(0, MAX - tarefasDia.length)).map(ev => (
                    <a key={ev.id} href={ev.link ?? "#"} target="_blank" rel="noreferrer"
                      onClick={e => e.stopPropagation()}
                      style={gcalStyle(ev.colorId)}
                      className="w-full text-left px-1.5 py-0.5 rounded text-[11px] truncate flex items-center gap-1 border-l-2">
                      <CalendarCheck className="w-3 h-3 flex-shrink-0 opacity-80" />
                      {ev.horaInicio && <span className="opacity-70 tabular-nums flex-shrink-0">{ev.horaInicio}</span>}
                      <span className="truncate">{ev.titulo}</span>
                    </a>
                  ))}
                  {totalItens > MAX && (
                    <div className="text-[10px] text-muted-foreground px-1.5">+{totalItens - MAX} mais</div>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* ── MOBILE: grade com dots + painel do dia ── */}
      <div className="md:hidden flex flex-col">
        <div className="grid grid-cols-7 px-2 pt-2">
          {WEEKDAYS.map(d => (
            <div key={d} className="text-center text-[11px] font-medium text-muted-foreground/60 pb-1.5">{d}</div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-0.5 px-2 pb-3">
          {cells.map((cell, i) => {
            const key = ymd(cell)
            const doMes = cell.getMonth() === refDate.getMonth()
            const ehHoje = key === hoje
            const ehSel = key === selectedDay
            const tarefasDia = porDia[key] || []
            const gEventos = googlePorDia[key] || []
            const dots = [
              ...tarefasDia.map(t => CATEGORIA_META[t.categoria].dot),
              ...(gEventos.length ? ["bg-green-500"] : []),
            ].slice(0, 3)
            return (
              <button key={i} onClick={() => setSelectedDay(key)}
                className={`aspect-square flex flex-col items-center justify-center rounded-xl relative transition-colors ${
                  ehSel ? "bg-primary/15" : "active:bg-muted/40"
                }`}>
                <span className={`text-[15px] flex items-center justify-center w-8 h-8 rounded-full ${
                  ehHoje ? "bg-primary text-primary-foreground font-semibold" : ehSel ? "text-primary font-semibold" : doMes ? "text-foreground/90" : "text-muted-foreground/30"
                }`}>
                  {cell.getDate()}
                </span>
                <div className="flex items-center gap-0.5 h-1.5 mt-0.5">
                  {dots.map((dot, j) => <span key={j} className={`w-1 h-1 rounded-full ${dot}`} />)}
                </div>
              </button>
            )
          })}
        </div>

        {/* Painel do dia selecionado */}
        <div className="border-t border-border px-4 pt-3 pb-4 space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-[15px] font-semibold text-foreground capitalize">{selLabel}</p>
            <button onClick={() => onDayClick(selectedDay)}
              className="flex items-center gap-1 text-xs text-primary font-medium active:opacity-70">
              <Plus className="w-3.5 h-3.5" /> Tarefa
            </button>
          </div>
          {selTarefas.length === 0 && selEventos.length === 0 ? (
            <p className="text-sm text-muted-foreground/60 py-6 text-center">Nenhum compromisso neste dia</p>
          ) : (
            <div className="space-y-1.5">
              {selTarefas.map(t => (
                <button key={t.id} onClick={() => onTaskClick(t)}
                  className={`w-full flex items-center gap-2.5 rounded-xl border border-border bg-card p-3 text-left active:opacity-70 ${t.concluida ? "opacity-50" : ""}`}>
                  <span onClick={e => { e.stopPropagation(); onToggle(t) }} className="flex-shrink-0">
                    {t.concluida ? <CheckCircle2 className="w-5 h-5 text-primary" /> : <Circle className="w-5 h-5 text-muted-foreground/40" />}
                  </span>
                  <span className={`w-2 h-2 rounded-full flex-shrink-0 ${CATEGORIA_META[t.categoria].dot}`} />
                  <div className="flex-1 min-w-0">
                    <p className={`text-[15px] text-foreground leading-tight ${t.concluida ? "line-through" : ""}`}>{t.titulo}</p>
                    {t.horaInicio && <p className="text-xs text-muted-foreground tabular-nums mt-0.5">{t.horaInicio}{t.horaFim ? ` – ${t.horaFim}` : ""}</p>}
                  </div>
                </button>
              ))}
              {selEventos.map(ev => (
                <a key={ev.id} href={ev.link ?? "#"} target="_blank" rel="noreferrer"
                  className="w-full flex items-center gap-2.5 rounded-xl border border-border bg-card p-3 active:opacity-70">
                  <CalendarCheck className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-[15px] text-foreground leading-tight truncate">{ev.titulo}</p>
                    {ev.horaInicio && <p className="text-xs text-muted-foreground tabular-nums mt-0.5">{ev.horaInicio}</p>}
                  </div>
                </a>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  )
}

// ============================================================
// Vista de Semana — grade de horas estilo Google Agenda
// ============================================================
const HOUR_H = 48 // altura de cada faixa de hora (px)
const minutosDe = (hhmm: string) => {
  const [h, m] = hhmm.split(":").map(Number)
  return (h || 0) * 60 + (m || 0)
}

// Distribui tarefas sobrepostas em colunas (como Google Agenda)
function layoutColumns(tasks: Tarefa[]) {
  const sorted = [...tasks].sort((a, b) => minutosDe(a.horaInicio!) - minutosDe(b.horaInicio!))
  const col: number[] = new Array(sorted.length).fill(0)
  const colEnd: number[] = [] // horário de fim de cada coluna

  for (let i = 0; i < sorted.length; i++) {
    const start = minutosDe(sorted[i].horaInicio!)
    const end = sorted[i].horaFim ? minutosDe(sorted[i].horaFim!) : start + 60
    let c = 0
    while (c < colEnd.length && colEnd[c] > start) c++
    col[i] = c
    colEnd[c] = end
  }

  // Para cada tarefa, descobre quantas colunas o seu grupo ocupa
  const totalCols: number[] = new Array(sorted.length).fill(1)
  for (let i = 0; i < sorted.length; i++) {
    const si = minutosDe(sorted[i].horaInicio!)
    const ei = sorted[i].horaFim ? minutosDe(sorted[i].horaFim!) : si + 60
    let maxCol = col[i]
    for (let j = 0; j < sorted.length; j++) {
      if (i === j) continue
      const sj = minutosDe(sorted[j].horaInicio!)
      const ej = sorted[j].horaFim ? minutosDe(sorted[j].horaFim!) : sj + 60
      if (si < ej && sj < ei) maxCol = Math.max(maxCol, col[j])
    }
    totalCols[i] = maxCol + 1
  }

  return sorted.map((t, i) => ({ task: t, col: col[i], totalCols: totalCols[i] }))
}

function WeekView({ refDate, porDia, googlePorDia, onDayClick, onTaskClick, onToggle }: {
  refDate: Date
  porDia: Record<string, Tarefa[]>
  googlePorDia: Record<string, GoogleEvent[]>
  onDayClick: (d: string) => void
  onTaskClick: (t: Tarefa) => void
  onToggle: (t: Tarefa) => void
}) {
  const ini = startOfWeek(refDate)
  const hoje = ymd(new Date())
  const agora = new Date()
  const dias = Array.from({ length: 7 }, (_, i) => addDays(ini, i))
  const horas = Array.from({ length: 24 }, (_, h) => h)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = 7 * HOUR_H
  }, [])

  return (
    <div className="flex flex-col h-full min-h-[520px]">
      {/* Cabeçalho dos dias */}
      <div className="grid sticky top-0 z-10 bg-background/95 backdrop-blur-sm" style={{ gridTemplateColumns: "3rem repeat(7, 1fr)" }}>
        <div className="border-b border-r border-border" />
        {dias.map((cell, i) => {
          const ehHoje = ymd(cell) === hoje
          return (
            <div key={i} className={`text-center py-2 border-b border-r border-border ${ehHoje ? "bg-primary/5" : ""}`}>
              <div className="text-[11px] text-muted-foreground uppercase">{WEEKDAYS[cell.getDay()]}</div>
              <div className={`text-lg font-semibold mx-auto w-9 h-9 flex items-center justify-center rounded-full ${
                ehHoje ? "bg-primary text-primary-foreground" : "text-foreground/80"
              }`}>{cell.getDate()}</div>
            </div>
          )
        })}
      </div>

      {/* Linha "dia inteiro" */}
      <div className="grid border-b border-border" style={{ gridTemplateColumns: "3rem repeat(7, 1fr)" }}>
        <div className="text-[10px] text-muted-foreground flex items-center justify-end pr-1 border-r border-border">dia todo</div>
        {dias.map((cell, i) => {
          const key = ymd(cell)
          const allDay = (porDia[key] || []).filter(t => !t.horaInicio)
          const gAllDay = (googlePorDia[key] || []).filter(ev => !ev.horaInicio)
          return (
            <div key={i} onClick={() => onDayClick(key)}
              className="border-r border-border/30 p-1 min-h-[28px] space-y-0.5 cursor-pointer hover:bg-muted/10">
              {allDay.map(t => (
                <button key={t.id} onClick={e => { e.stopPropagation(); onTaskClick(t) }}
                  className={`w-full text-left px-1.5 py-0.5 rounded text-[11px] truncate flex items-center gap-1 ${CATEGORIA_META[t.categoria].chip} ${t.concluida ? "opacity-50 line-through" : ""}`}>
                  <span className="truncate">{t.titulo}</span>
                </button>
              ))}
              {gAllDay.map(ev => (
                <a key={ev.id} href={ev.link ?? "#"} target="_blank" rel="noreferrer"
                  onClick={e => e.stopPropagation()}
                  style={gcalStyle(ev.colorId)}
                  className="w-full text-left px-1.5 py-0.5 rounded text-[11px] truncate flex items-center gap-1 border-l-2">
                  <CalendarCheck className="w-3 h-3 flex-shrink-0 opacity-80" />
                  <span className="truncate">{ev.titulo}</span>
                </a>
              ))}
            </div>
          )
        })}
      </div>

      {/* Grade de horas */}
      <div ref={scrollRef} className="flex-1 overflow-auto">
        <div className="grid relative" style={{ gridTemplateColumns: "3rem repeat(7, 1fr)" }}>
          {/* Coluna de horas */}
          <div className="border-r border-border">
            {horas.map(h => (
              <div key={h} style={{ height: HOUR_H }} className="relative">
                <span className="absolute -top-2 right-1 text-[10px] text-muted-foreground tabular-nums">
                  {h === 0 ? "" : `${String(h).padStart(2, "0")}:00`}
                </span>
              </div>
            ))}
          </div>

          {/* Colunas dos dias */}
          {dias.map((cell, di) => {
            const key = ymd(cell)
            const ehHoje = key === hoje
            const comHora = (porDia[key] || []).filter(t => t.horaInicio)
            const layouts = layoutColumns(comHora)
            const gComHora = (googlePorDia[key] || []).filter(ev => ev.horaInicio)

            return (
              <div key={di} className="border-r border-border/30 relative"
                onClick={() => onDayClick(key)}>
                {/* linhas de hora */}
                {horas.map(h => (
                  <div key={h} style={{ height: HOUR_H }} className="border-b border-border/30" />
                ))}

                {/* indicador de agora */}
                {ehHoje && (
                  <div className="absolute left-0 right-0 z-20 pointer-events-none"
                    style={{ top: (minutosDe(`${agora.getHours()}:${agora.getMinutes()}`) / 60) * HOUR_H }}>
                    <div className="h-px bg-red-500 relative">
                      <div className="absolute -left-1 -top-1 w-2 h-2 rounded-full bg-red-500" />
                    </div>
                  </div>
                )}

                {/* eventos do Google Calendar */}
                {gComHora.map(ev => {
                  const inicio = minutosDe(ev.horaInicio!)
                  const fim = ev.horaFim ? minutosDe(ev.horaFim) : inicio + 60
                  return (
                    <a key={ev.id} href={ev.link ?? "#"} target="_blank" rel="noreferrer"
                      onClick={e => e.stopPropagation()}
                      style={{ top: (inicio / 60) * HOUR_H, height: Math.max(18, ((fim - inicio) / 60) * HOUR_H - 2), left: "50%", width: "calc(50% - 2px)", ...gcalStyle(ev.colorId) }}
                      className="absolute z-10 rounded px-1 py-0.5 text-left text-[11px] overflow-hidden border-l-2">
                      <div className="flex items-center gap-1">
                        <CalendarCheck className="w-3 h-3 flex-shrink-0 opacity-80" />
                        <span className="truncate font-medium">{ev.titulo}</span>
                      </div>
                      <div className="text-[10px] opacity-70 tabular-nums">{ev.horaInicio}{ev.horaFim ? `–${ev.horaFim}` : ""}</div>
                    </a>
                  )
                })}

                {/* blocos de tarefas com colunas para sobreposição */}
                {layouts.map(({ task: t, col: c, totalCols: tc }) => {
                  const inicio = minutosDe(t.horaInicio!)
                  const fim = t.horaFim ? minutosDe(t.horaFim) : inicio + 60
                  const top = (inicio / 60) * HOUR_H
                  const altura = Math.max(18, ((fim - inicio) / 60) * HOUR_H - 2)
                  const widthPct = 100 / tc
                  const leftPct = c * widthPct
                  return (
                    <button key={t.id} onClick={e => { e.stopPropagation(); onTaskClick(t) }}
                      style={{
                        top,
                        height: altura,
                        left: `calc(${leftPct}% + 1px)`,
                        width: `calc(${widthPct}% - 2px)`,
                      }}
                      className={`absolute z-10 rounded px-1 py-0.5 text-left text-[11px] overflow-hidden ${CATEGORIA_META[t.categoria].chip} ${t.concluida ? "opacity-50 line-through" : ""}`}>
                      <div className="flex items-center gap-1">
                        <button onClick={e => { e.stopPropagation(); onToggle(t) }} className="flex-shrink-0">
                          {t.concluida ? <CheckCircle2 className="w-3 h-3" /> : <Circle className="w-3 h-3 opacity-60" />}
                        </button>
                        <span className="truncate font-medium">{t.titulo}</span>
                      </div>
                      <div className="text-[10px] opacity-70 tabular-nums">{t.horaInicio}{t.horaFim ? `–${t.horaFim}` : ""}</div>
                    </button>
                  )
                })}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

// ============================================================
// Vista de Lista
// ============================================================
function ListView({ tarefas, googleEventos, googleFeitos, onToggleGoogle, onTaskClick, onToggle, usuarios, obras, onImportGoogle }: {
  tarefas: Tarefa[]
  googleEventos: GoogleEvent[]
  googleFeitos: Set<string>
  onToggleGoogle: (id: string) => void
  onTaskClick: (t: Tarefa) => void
  onToggle: (t: Tarefa) => void
  usuarios: Usuario[]
  obras: ObraLite[]
  onImportGoogle: (ev: GoogleEvent) => void
}) {
  const ordenadas = [...tarefas].sort((a, b) => {
    if (a.concluida !== b.concluida) return a.concluida ? 1 : -1
    const da = tarefaYmd(a) || "9999"; const db = tarefaYmd(b) || "9999"
    return da.localeCompare(db)
  })

  if (ordenadas.length === 0 && googleEventos.length === 0) {
    return (
      <div className="text-center py-20">
        <CheckCircle2 className="w-10 h-10 text-muted-foreground/20 mx-auto mb-3" />
        <p className="text-muted-foreground text-sm">Nenhuma tarefa</p>
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto p-5 space-y-2">
      {googleEventos.sort((a, b) => (a.data + (a.horaInicio ?? "")).localeCompare(b.data + (b.horaInicio ?? ""))).map(ev => {
        const feito = googleFeitos.has(ev.id)
        return (
          <div key={ev.id}
            style={feito ? {} : { borderColor: (GCAL_COLORS[ev.colorId ?? ""] ?? "#22c55e") + "40", backgroundColor: (GCAL_COLORS[ev.colorId ?? ""] ?? "#22c55e") + "10" }}
            className={`rounded-xl border p-3 flex items-start gap-3 transition-colors ${feito ? "border-border/30 bg-muted/10 opacity-40" : ""}`}>
            <button onClick={() => onToggleGoogle(ev.id)} title={feito ? "Desmarcar" : "Marcar como feito"}
              className="mt-0.5 flex-shrink-0 hover:scale-110 transition-transform">
              {feito
                ? <CheckCircle2 className="w-5 h-5 text-muted-foreground" />
                : <Circle className="w-5 h-5 text-muted-foreground hover:text-foreground" />}
            </button>
            <div className="flex-1 min-w-0">
              <div className={`font-medium text-sm ${feito ? "line-through text-muted-foreground" : "text-foreground"}`}>{ev.titulo}</div>
              <div className="text-xs text-muted-foreground mt-1 flex items-center gap-2 flex-wrap">
                <span style={{ color: (GCAL_COLORS[ev.colorId ?? ""] ?? "#22c55e") + "cc", borderColor: (GCAL_COLORS[ev.colorId ?? ""] ?? "#22c55e") + "40", backgroundColor: (GCAL_COLORS[ev.colorId ?? ""] ?? "#22c55e") + "15" }}
                  className="text-[10px] font-medium px-1.5 py-0.5 rounded border">Google</span>
                {ev.data && <span>{new Date(ev.data + "T12:00:00").toLocaleDateString("pt-BR")}</span>}
                {ev.horaInicio && <span className="tabular-nums">{ev.horaInicio}{ev.horaFim ? `–${ev.horaFim}` : ""}</span>}
                {ev.local && <span className="truncate">{ev.local}</span>}
              </div>
            </div>
            <div className="flex items-center gap-1.5 flex-shrink-0 mt-0.5">
              {!feito && (
                <button onClick={() => onImportGoogle(ev)}
                  title="Importar e atribuir a um colaborador"
                  className="text-xs bg-sky-600/20 hover:bg-sky-600/40 text-sky-400 px-2 py-0.5 rounded border border-sky-500/20 transition-colors whitespace-nowrap">
                  + Importar
                </button>
              )}
              {ev.link && (
                <a href={ev.link} target="_blank" rel="noreferrer" title="Abrir no Google Calendar"
                  className="text-muted-foreground hover:text-green-400">
                  <CalendarCheck className="w-4 h-4" />
                </a>
              )}
            </div>
          </div>
        )
      })}
      {ordenadas.map(t => {
        const venceu = isVencidaYmd(tarefaYmd(t))
        return (
          <div key={t.id}
            className={`rounded-xl border p-3 flex items-start gap-3 transition-colors cursor-pointer ${
              t.concluida ? "border-border/30 bg-card/40 opacity-60"
              : venceu ? "border-destructive/20 bg-destructive/5" : "border-border bg-card hover:border-border/80 shadow-sm"
            }`}
            onClick={() => onTaskClick(t)}>
            <button onClick={e => { e.stopPropagation(); onToggle(t) }} className="mt-0.5 flex-shrink-0">
              {t.concluida ? <CheckCircle2 className="w-5 h-5 text-green-500" /> : <Circle className="w-5 h-5 text-muted-foreground hover:text-primary" />}
            </button>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <Flag className={`w-3.5 h-3.5 flex-shrink-0 ${flagColor(t.prioridade)}`} />
                <span className={`font-medium text-sm ${t.concluida ? "line-through text-muted-foreground" : "text-foreground"}`}>{t.titulo}</span>
              </div>
              <div className="flex items-center flex-wrap gap-2 mt-1.5 text-xs text-muted-foreground">
                <span className={`px-1.5 py-0.5 rounded-full border text-[10px] font-medium ${CATEGORIA_META[t.categoria].badge}`}>
                  {CATEGORIA_META[t.categoria].label}
                </span>
                {t.obra && <span className="text-orange-300/80 flex items-center gap-1"><HardHat className="w-3 h-3" /> {t.obra.client_name}</span>}
                {t.dataVenc && (
                  <span className={venceu && !t.concluida ? "text-red-400 flex items-center gap-1" : ""}>
                    {venceu && !t.concluida && <AlertCircle className="w-3 h-3" />}
                    {new Date(t.dataVenc).toLocaleDateString("pt-BR")}
                    {t.horaInicio && <span className="ml-1 tabular-nums">{t.horaInicio}{t.horaFim ? `–${t.horaFim}` : ""}</span>}
                  </span>
                )}
                {t.atribuido && <span>→ {t.atribuido.nome}</span>}
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}

