﻿"use client"

import { useState, useEffect, useCallback } from "react"
import { Package, Wallet, Boxes, Layers, Plus, Trash2, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { EmptyState } from "@/components/ui/empty-state"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Switch } from "@/components/ui/switch"
import { CabecalhoPagina } from "@/components/ui/cabecalho-pagina"
import { CartaoMetrica, FaixaMetricas } from "@/components/ui/cartao-metrica"
import { BarraFiltros } from "@/components/ui/barra-filtros"
import { CartaoGrade } from "@/components/ui/bloco-lista"
import { useConfirmar } from "@/components/confirmar"
import { useMemoriaDeFiltro } from "@/hooks/usar-memoria-filtro"
import { brl } from "@/lib/formato"


interface Product {
  id: string
  sku: string
  nome: string
  preco_custo: number
  preco_venda: number
  status: string
  marca?: string | null
  categoryId?: string | null
  supplierId?: string | null
  supplier?: { id: string; nome: string } | null
}

interface Categoria { id: string; nome: string }

interface KitItem {
  productId: string
  quantidade: number
  markup_especifico?: number | null   // % — sobrepõe o markup global
  desconto_unitario?: number | null   // R$ por unidade
  product?: Product
}

interface Kit {
  id: string
  nome: string
  descricao: string | null
  markup_global: number | null
  desconto: number | null
  items: Array<{ id: string; productId: string; quantidade: number; product: Product }>
}

export default function KitsPage() {
  const confirmar = useConfirmar()
  const [kits, setKits] = useState<Kit[]>([])
  const [busca, setBusca] = useMemoriaDeFiltro("kits:busca", "")
  const [faixa, setFaixa] = useState<"TODOS" | "PEQUENO" | "MEDIO" | "GRANDE">("TODOS")
  const [editandoId, setEditandoId] = useState<string | null>(null)
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(false)
  const [open, setOpen] = useState(false)
  const [saving, setSaving] = useState(false)

  const [nome, setNome] = useState("")
  const [descricao, setDescricao] = useState("")
  const [useMarkup, setUseMarkup] = useState(true)
  const [markupGlobal, setMarkupGlobal] = useState("")
  const [desconto, setDesconto] = useState("")
  const [items, setItems] = useState<KitItem[]>([])
  const [productSearch, setProductSearch] = useState("")
  const [showDropdown, setShowDropdown] = useState(false)
  const [categorias, setCategorias] = useState<Categoria[]>([])
  const [catFiltro, setCatFiltro] = useState("")
  const [fornecedorFiltro, setFornecedorFiltro] = useState("")

  useEffect(() => {
    fetch("/api/categorias").then(r => r.ok ? r.json() : null)
      .then(d => { if (d?.categories) setCategorias(d.categories.map((c: Categoria) => ({ id: c.id, nome: c.nome }))) })
      .catch(() => {})
  }, [])

  const fetchKits = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/kits")
      const data = await res.json()
      setKits(data.kits || [])
    } finally {
      setLoading(false)
    }
  }, [])

  const fetchProducts = useCallback(async () => {
    // limit alto o bastante pra nunca truncar o catálogo — bug: categorias
    // com produtos "além" do corte de 100 simplesmente não apareciam no Kit.
    const res = await fetch("/api/produtos?limit=5000")
    const data = await res.json()
    setProducts((data.products || []).filter((p: Product) => p.status === "ATIVO"))
  }, [])

  useEffect(() => { fetchKits() }, [fetchKits])
  useEffect(() => { fetchProducts() }, [fetchProducts])

  function openNew() {
    setEditandoId(null)
    setNome(""); setDescricao(""); setMarkupGlobal(""); setDesconto("")
    setUseMarkup(true); setItems([]); setProductSearch("")
    setOpen(true)
  }

  /* Editar existia na API (PATCH /api/kits/[id]) mas não na tela: corrigir um
     kit exigia excluir e montar de novo, item por item. */
  function openEdit(kit: Kit) {
    setEditandoId(kit.id)
    setNome(kit.nome)
    setDescricao(kit.descricao ?? "")
    setUseMarkup(kit.markup_global != null)
    setMarkupGlobal(kit.markup_global != null ? String(kit.markup_global) : "")
    setDesconto(kit.desconto != null ? String(kit.desconto) : "")
    setItems(kit.items.map(i => ({
      productId: i.productId,
      quantidade: i.quantidade,
      product: i.product,
    })))
    setProductSearch("")
    setOpen(true)
  }

  function addProduct(p: Product) {
    const exists = items.find(i => i.productId === p.id)
    if (exists) {
      setItems(items.map(i => i.productId === p.id ? { ...i, quantidade: i.quantidade + 1 } : i))
    } else {
      setItems([...items, { productId: p.id, quantidade: 1, product: p }])
    }
    setProductSearch("")
    setShowDropdown(false)
  }

  function removeItem(productId: string) {
    setItems(items.filter(i => i.productId !== productId))
  }

  function updateQty(productId: string, qty: number) {
    setItems(items.map(i => i.productId === productId ? { ...i, quantidade: Math.max(1, qty) } : i))
  }

  const totalCusto = items.reduce((sum, i) => {
    const p = i.product || products.find(pr => pr.id === i.productId)
    return sum + (p ? Number(p.preco_custo) * i.quantidade : 0)
  }, 0)

  // Venda por item: markup específico > markup global; desconto R$/un abate no fim.
  const vendaItem = (i: KitItem) => {
    const p = i.product || products.find(pr => pr.id === i.productId)
    if (!p) return 0
    const mk = i.markup_especifico ?? (useMarkup ? (parseFloat(markupGlobal) || 0) : 0)
    const unit = Number(p.preco_custo) * (1 + mk / 100) - (i.desconto_unitario ?? 0)
    return Math.max(0, unit) * i.quantidade
  }
  const totalVendaItens = items.reduce((s, i) => s + vendaItem(i), 0)
  const precoFinal = useMarkup
    ? totalVendaItens
    : totalVendaItens - (parseFloat(desconto) || 0)

  function updateItemCampo(productId: string, campo: "markup_especifico" | "desconto_unitario", valor: string) {
    setItems(prev => prev.map(i => i.productId === productId
      ? { ...i, [campo]: valor === "" ? null : parseFloat(valor) || 0 }
      : i))
  }

  async function handleSave() {
    if (!nome) return
    setSaving(true)
    try {
      await fetch(editandoId ? `/api/kits/${editandoId}` : "/api/kits", {
        method: editandoId ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nome,
          descricao: descricao || null,
          markup_global: useMarkup ? parseFloat(markupGlobal) || null : null,
          desconto: !useMarkup ? parseFloat(desconto) || null : null,
          items: items.map(i => ({
            productId: i.productId, quantidade: i.quantidade,
            markup_especifico: i.markup_especifico ?? null,
            desconto_unitario: i.desconto_unitario ?? null,
          })),
        })
      })
      setOpen(false)
      fetchKits()
    } finally {
      setSaving(false)
    }
  }

  async function deleteKit(id: string) {
    if (!await confirmar({ titulo: "Excluir este kit?", perigo: true })) return
    await fetch(`/api/kits/${id}`, { method: "DELETE" })
    fetchKits()
  }

  const fornecedoresDisponiveis = [...new Map(products.filter(p => p.supplier).map(p => [p.supplier!.id, p.supplier!])).values()]
  const fornecedorNome = fornecedoresDisponiveis.find(f => f.id === fornecedorFiltro)?.nome ?? ""
  const q = productSearch.toLowerCase()
  const filteredProducts = products.filter(p =>
    (!catFiltro || p.categoryId === catFiltro) &&
    // Casa por supplierId OU por marca (itens importados sem vínculo de fornecedor)
    (!fornecedorFiltro || p.supplierId === fornecedorFiltro || (p.marca ?? "").toLowerCase() === fornecedorNome.toLowerCase()) &&
    (!q || p.nome.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q) || (p.marca ?? "").toLowerCase().includes(q))
  ).slice(0, 50) // era 8 — cortava itens da categoria

  /* Preço final do kit: markup sobre o custo, ou custo menos desconto. A regra
     vive aqui porque o cartão, o resumo e o total do topo precisam do mesmo
     número — calcular em três lugares é como eles divergem. */
  const precoDoKit = (kit: Kit) => {
    const custo = kit.items.reduce((sum, i) => sum + Number(i.product?.preco_custo || 0) * i.quantidade, 0)
    return kit.markup_global != null ? custo * (1 + kit.markup_global / 100) : custo - (kit.desconto || 0)
  }

  const totalItens = kits.reduce((s, k) => s + k.items.length, 0)
  const ticketMedio = kits.length ? kits.reduce((s, k) => s + precoDoKit(k), 0) / kits.length : 0
  const maiorKit = kits.length
    ? kits.reduce((a, b) => (a.items.length >= b.items.length ? a : b))
    : null

  /* Faixa por quantidade de itens: é o que separa um kit de tomada de um
     projeto inteiro, e o dado já existe — não precisa de campo novo. */
  const visiveis = kits.filter(k => {
    const termo = busca.trim().toLowerCase()
    if (termo && !k.nome.toLowerCase().includes(termo) && !(k.descricao ?? "").toLowerCase().includes(termo)) return false
    const n = k.items.length
    if (faixa === "PEQUENO") return n <= 5
    if (faixa === "MEDIO") return n >= 6 && n <= 15
    if (faixa === "GRANDE") return n >= 16
    return true
  })

  return (
    <div className="mx-auto max-w-[1560px] space-y-3 p-4 sm:space-y-4 sm:p-6">
      <CabecalhoPagina
        icone={Layers}
        titulo="Kits"
        contexto={`${kits.length} configurado${kits.length === 1 ? "" : "s"}`}
        acao={
          <Button onClick={openNew} size="sm" className="h-9 gap-1.5">
            <Plus className="h-4 w-4" /> <span className="hidden sm:inline">Novo kit</span>
          </Button>
        }
      />

      <FaixaMetricas>
        <CartaoMetrica icone={Layers} rotulo="Kits" valor={kits.length} nota="Cadastrados" />
        <CartaoMetrica icone={Package} rotulo="Maior kit"
          valor={maiorKit ? `${maiorKit.items.length} itens` : "—"}
          nota={maiorKit?.nome ?? "Nenhum kit ainda"} />
        <CartaoMetrica icone={Wallet} rotulo="Ticket médio"
          valor={kits.length ? brl(ticketMedio) : "—"} nota="Preço final médio" />
        <CartaoMetrica icone={Boxes} rotulo="Itens" valor={totalItens} nota="Somando todos os kits" />
      </FaixaMetricas>

      <BarraFiltros
        busca={busca}
        aoBuscar={setBusca}
        placeholder="Buscar kit..."
        valor={faixa}
        aoTrocar={setFaixa}
        opcoes={[
          { valor: "TODOS", rotulo: "Todos" },
          { valor: "PEQUENO", rotulo: "Até 5 itens" },
          { valor: "MEDIO", rotulo: "6 a 15" },
          { valor: "GRANDE", rotulo: "16+" },
        ] as const}
      />

      {loading ? (
        <div className="py-20 text-center text-muted-foreground">Carregando kits...</div>
      ) : visiveis.length === 0 ? (
        <EmptyState icon={Layers} title={kits.length ? "Nenhum kit com esse filtro" : "Nenhum kit cadastrado"}
          subtitle={kits.length ? "Ajuste a busca ou escolha outro tamanho." : "Agrupe produtos que sempre saem juntos e monte a proposta em um clique."}
          action={kits.length ? undefined : <Button onClick={openNew}>Criar primeiro kit</Button>} />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:gap-4 md:grid-cols-2 xl:grid-cols-3">
          {visiveis.map(kit => (
            <CartaoGrade
              key={kit.id}
              icone={Layers}
              canto={brl(precoDoKit(kit))}
              titulo={kit.nome}
              contexto={`${kit.items.length} item${kit.items.length === 1 ? "" : "s"}${kit.descricao ? ` · ${kit.descricao}` : ""}`}
              acoes={
                <>
                  <Button size="sm" variant="outline" className="flex-1" onClick={() => openEdit(kit)}>
                    Editar
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => deleteKit(kit.id)}
                    className="h-8 w-8 shrink-0 p-0 text-muted-foreground hover:text-ios-red">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </>
              }
            />
          ))}
        </div>
      )}


      {/* Modal Novo Kit */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg w-full mx-4 max-h-[90vh] overflow-y-auto">
          <DialogHeader className="pb-4 border-b border-border/50">
            <DialogTitle className="text-foreground text-lg font-semibold">{editandoId ? "Editar kit" : "Novo kit"}</DialogTitle>
          </DialogHeader>

          <div className="space-y-5 px-5 sm:px-6 py-4">
            {/* Nome */}
            <div className="space-y-2">
              <Label className="text-foreground/80 text-[14px] font-medium">Nome *</Label>
              <Input
                value={nome}
                onChange={e => setNome(e.target.value)}
                className="h-[48px] px-4 rounded-xl bg-muted border-border text-foreground"
                placeholder="Nome do kit"
              />
            </div>

            {/* Descrição */}
            <div className="space-y-2">
              <Label className="text-foreground/80 text-[14px] font-medium">Descrição</Label>
              <Textarea
                value={descricao}
                onChange={e => setDescricao(e.target.value)}
                className="min-h-[80px] p-4 rounded-xl bg-muted border-border text-foreground resize-none"
                placeholder="Descrição opcional..."
                rows={2}
              />
            </div>

            {/* Busca de produtos */}
            <div className="space-y-2">
              <Label className="text-foreground/80 text-[14px] font-medium">Adicionar Produtos</Label>
              {/* Filtro por categoria, dropdown (pills cortavam nomes longos no mobile) */}
              {categorias.length > 0 && (
                <select value={catFiltro}
                  onChange={e => { setCatFiltro(e.target.value); if (e.target.value) setShowDropdown(true) }}
                  className="w-full h-10 px-3 rounded-xl bg-muted border border-border text-foreground text-sm outline-none focus:ring-1 focus:ring-ios-blue/40">
                  <option value="">Todas as categorias</option>
                  {categorias.map(c => (
                    <option key={c.id} value={c.id}>{c.nome}</option>
                  ))}
                </select>
              )}
              {fornecedoresDisponiveis.length > 0 && (
                <select value={fornecedorFiltro}
                  onChange={e => { setFornecedorFiltro(e.target.value); if (e.target.value) setShowDropdown(true) }}
                  className="w-full h-10 px-3 rounded-xl bg-muted border border-border text-foreground text-sm outline-none focus:ring-1 focus:ring-ios-blue/40">
                  <option value="">Todos os fornecedores</option>
                  {fornecedoresDisponiveis.map(f => (
                    <option key={f.id} value={f.id}>{f.nome}</option>
                  ))}
                </select>
              )}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50 pointer-events-none" />
                <Input
                  value={productSearch}
                  onChange={e => { setProductSearch(e.target.value); setShowDropdown(true) }}
                  onFocus={() => setShowDropdown(true)}
                  className="h-[48px] pl-10 pr-4 rounded-xl bg-muted border-border text-foreground"
                  placeholder="Buscar produto por nome ou SKU..."
                />
                {showDropdown && (productSearch || catFiltro || fornecedorFiltro) && filteredProducts.length > 0 && (
                  <div className="absolute z-50 top-full left-0 right-0 mt-1.5 bg-card border border-border rounded-xl shadow-lg overflow-hidden">
                    {filteredProducts.map(p => (
                      <button key={p.id} type="button"
                        onClick={() => addProduct(p)}
                        className="w-full text-left px-4 py-2.5 hover:bg-muted/60 flex justify-between items-center transition-colors border-b border-border/40 last:border-0">
                        <div className="min-w-0">
                          <span className="text-foreground text-sm font-medium truncate block">{p.nome}</span>
                          <span className="text-muted-foreground text-xs">{p.sku}</span>
                        </div>
                        <span className="text-muted-foreground text-xs flex-shrink-0 ml-2">{brl(Number(p.preco_custo))}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Itens adicionados */}
            {items.length > 0 && (
              <div className="space-y-2">
                <Label className="text-foreground/80 text-[14px] font-medium">
                  Itens do Kit ({items.length})
                </Label>
                <div className="space-y-2">
                  {items.map(item => {
                    const p = item.product || products.find(pr => pr.id === item.productId)
                    return (
                      <div key={item.productId} className="bg-surface-2/60 rounded-xl p-3 border border-hairline space-y-2">
                        <div className="flex items-center gap-3">
                          <div className="flex-1 min-w-0">
                            <p className="text-foreground text-sm font-medium truncate">{p?.nome}</p>
                            <p className="text-muted-foreground text-xs">Custo {brl(Number(p?.preco_custo || 0))} / un</p>
                          </div>
                          <Input
                            type="number"
                            min="1"
                            value={item.quantidade}
                            onChange={e => updateQty(item.productId, parseInt(e.target.value))}
                            className="w-16 bg-card border-border text-foreground text-center h-8 rounded-xl px-2"
                          />
                          <span className="text-foreground font-semibold text-sm w-24 text-right flex-shrink-0">
                            {brl(vendaItem(item))}
                          </span>
                          <Button size="sm" variant="ghost" onClick={() => removeItem(item.productId)}
                            className="text-muted-foreground/40 hover:text-destructive h-7 w-7 p-0 flex-shrink-0">
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                        {/* Avançado por item: margem/desconto sobrepõem o global */}
                        <div className="flex items-center gap-2 pl-0.5">
                          <span className="text-[11px] text-muted-fg flex-shrink-0">Margem %</span>
                          <input type="number" step="0.1" placeholder={useMarkup ? (markupGlobal || "global") : "0"}
                            value={item.markup_especifico ?? ""}
                            onChange={e => updateItemCampo(item.productId, "markup_especifico", e.target.value)}
                            className="w-20 h-7 px-2 rounded-lg bg-card border border-hairline text-foreground text-[12px] text-right outline-none focus:border-ios-blue/50" />
                          <span className="text-[11px] text-muted-fg flex-shrink-0 ml-2">Desc. R$/un</span>
                          <input type="number" step="0.01" placeholder="0"
                            value={item.desconto_unitario ?? ""}
                            onChange={e => updateItemCampo(item.productId, "desconto_unitario", e.target.value)}
                            className="w-24 h-7 px-2 rounded-lg bg-card border border-hairline text-foreground text-[12px] text-right outline-none focus:border-ios-blue/50" />
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {/* Toggle markup / desconto */}
            <div className="border-t border-border/50 pt-4 space-y-4">
              <div className="flex items-center gap-3">
                <Switch checked={useMarkup} onCheckedChange={setUseMarkup} />
                <Label className="text-foreground/80 text-sm">
                  {useMarkup ? "Usar Markup Global (%)" : "Usar Desconto (R$)"}
                </Label>
              </div>

              {useMarkup ? (
                <div className="space-y-2">
                  <Label className="text-muted-foreground text-xs font-medium">Markup Global (%)</Label>
                  <Input
                    type="number"
                    step="0.1"
                    value={markupGlobal}
                    onChange={e => setMarkupGlobal(e.target.value)}
                    className="h-[48px] px-4 rounded-xl bg-muted border-border text-foreground w-40"
                    placeholder="0"
                  />
                </div>
              ) : (
                <div className="space-y-2">
                  <Label className="text-muted-foreground text-xs font-medium">Desconto (R$)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={desconto}
                    onChange={e => setDesconto(e.target.value)}
                    className="h-[48px] px-4 rounded-xl bg-muted border-border text-foreground w-40"
                    placeholder="0,00"
                  />
                </div>
              )}

              {/* Resumo de preço */}
              <div className="bg-muted/40 rounded-xl border border-border p-4 space-y-2 text-sm">
                <div className="flex justify-between text-muted-foreground">
                  <span>Custo Total dos Itens</span>
                  <span>{brl(totalCusto)}</span>
                </div>
                <div className="flex justify-between text-foreground font-semibold text-base border-t border-border/50 pt-2">
                  <span>Preço Final do Kit</span>
                  <span className="text-emerald-500 dark:text-emerald-400">{brl(precoFinal)}</span>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter className="pt-4 border-t border-border/50 gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}
              className="text-muted-foreground hover:text-foreground">
              Cancelar
            </Button>
            <Button onClick={handleSave} disabled={saving || !nome}
              className="bg-primary hover:bg-primary/90 text-primary-foreground">
              {saving ? "Salvando..." : "Salvar Kit"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
