"use client"

/**
 * Clientes — a carteira, entre o funil e os parceiros.
 *
 * Não é uma tabela nova: é o mesmo cadastro do lead, filtrado por quem já tem
 * documento conferido ou negócio ganho. Duplicar a pessoa numa tabela própria
 * criaria dois cadastros da mesma empresa que divergem no dia em que alguém
 * corrige o endereço num só — e aí ninguém sabe qual foi para o contrato.
 *
 * A pergunta que a tela responde é a da carteira, não a do funil: quem já
 * comprou, quanto, e há quanto tempo ninguém fala com essa pessoa.
 */

import { useCallback, useEffect, useMemo, useState } from "react"
import Link from "next/link"
import {
  Contact, Search, Building2, User, Phone, Mail, MapPin, FileText,
  AlertCircle, Wallet, CalendarClock, ExternalLink, Trash2,
} from "lucide-react"
import { Input } from "@/components/ui/input"
import { EmptyState } from "@/components/ui/empty-state"
import { CabecalhoPagina } from "@/components/ui/cabecalho-pagina"
import { CartaoMetrica, FaixaMetricas } from "@/components/ui/cartao-metrica"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogBody, DialogTitle } from "@/components/ui/dialog"
import { HistoricoLead } from "@/components/leads/historico-lead"
import { FichaLead, type FichaValores } from "@/components/leads/ficha-lead"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { formatarTelefone, formatarDocumento, formatarCEP } from "@/lib/documento"
import { useMemoriaDeFiltro } from "@/hooks/usar-memoria-filtro"
import { brlSemCentavos as brl } from "@/lib/formato"


interface PropostaResumo {
  id: string; numero: string; status: string; valor_total: number; createdAt: string
}

interface Cliente {
  id: string; nome: string; nome_funil: string
  documento: string | null; tipo: "PF" | "PJ" | null
  telefone: string | null; email: string | null
  cidade: string | null; uf: string | null; ie: string | null
  cep: string | null; logradouro: string | null; numero: string | null
  complemento: string | null; bairro: string | null
  origem: string; parceiro: string | null; status: string
  cadastro_completo: boolean; confirmado_em: string | null; origem_proposta: string | null
  observacoes: string | null
  propostas: number; propostas_fechadas: number; valor_fechado: number
  lista_propostas: PropostaResumo[]
  ultima_proposta: PropostaResumo | null
  ultimo_contato: string | null
  criado_em: string
  ficha: FichaValores
}

/** Há quantos dias — a conta que diz se o cliente esfriou. */
function diasDesde(iso: string | null) {
  if (!iso) return null
  return Math.floor((Date.now() - new Date(iso).getTime()) / 86_400_000)
}

const dataCurta = (iso: string) =>
  new Date(iso).toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "2-digit" })

export default function ClientesPage() {
  const [clientes, setClientes] = useState<Cliente[]>([])
  const [carregando, setCarregando] = useState(true)
  const [busca, setBusca] = useMemoriaDeFiltro("clientes:busca", "")
  const [filtro, setFiltro] = useMemoriaDeFiltro<"TODOS" | "PF" | "PJ" | "INCOMPLETOS">("clientes:tipo", "TODOS")
  const [aberto, setAberto] = useState<Cliente | null>(null)
  const [excluir, setExcluir] = useState<Cliente | null>(null)
  const [excluindo, setExcluindo] = useState(false)
  const [erroExcluir, setErroExcluir] = useState("")

  /* Cliente e lead são o MESMO cadastro: excluir aqui chama a rota do lead.
     Uma rota própria de cliente daria dois caminhos para apagar a mesma linha,
     com duas regras de permissão que um dia divergiriam. */
  async function confirmarExclusao() {
    if (!excluir) return
    setExcluindo(true); setErroExcluir("")
    try {
      const r = await fetch(`/api/leads/${excluir.id}`, { method: "DELETE" })
      if (!r.ok) {
        const j = await r.json().catch(() => ({}))
        setErroExcluir(j.error || "Não foi possível excluir.")
        return
      }
      setExcluir(null); setAberto(null); carregar()
    } finally { setExcluindo(false) }
  }

  const carregar = useCallback(async () => {
    const r = await fetch("/api/clientes", { cache: "no-store" })
    if (r.ok) setClientes((await r.json()).clientes ?? [])
    setCarregando(false)
  }, [])
  useEffect(() => { carregar() }, [carregar])

  /* Busca na memória: a carteira cabe na tela e filtrar aqui responde a cada
     tecla, sem uma ida ao servidor por letra digitada. */
  const visiveis = useMemo(() => {
    const termo = busca.trim().toLowerCase()
    const digitos = termo.replace(/\D/g, "")
    return clientes.filter(c => {
      if (filtro === "PF" && c.tipo !== "PF") return false
      if (filtro === "PJ" && c.tipo !== "PJ") return false
      if (filtro === "INCOMPLETOS" && c.cadastro_completo) return false
      if (!termo) return true
      return (
        [c.nome, c.nome_funil, c.email, c.cidade].some(v => (v ?? "").toLowerCase().includes(termo)) ||
        (!!digitos && [c.documento, c.telefone].some(v => (v ?? "").includes(digitos)))
      )
    })
  }, [clientes, busca, filtro])

  const carteira = clientes.reduce((s, c) => s + c.valor_fechado, 0)
  const incompletos = clientes.filter(c => !c.cadastro_completo).length

  const Selo = ({ c }: { c: Cliente }) => (
    <span className={`flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full ${
      c.tipo === "PJ" ? "bg-ios-purple/10 text-ios-purple" : "bg-ios-blue/10 text-ios-blue"
    }`}>
      {c.tipo === "PJ" ? <Building2 className="h-4 w-4" /> : <User className="h-4 w-4" />}
    </span>
  )

  return (
    <div className="flex h-full min-h-0 flex-col gap-4 p-4 md:p-6">
      <CabecalhoPagina
        icone={Contact}
        titulo="Clientes"
        contexto={<>{clientes.length} na carteira{carteira > 0 && <> · {brl(carteira)} fechados</>}</>}
      />

      <FaixaMetricas>
        <CartaoMetrica icone={Contact} rotulo="Clientes" valor={clientes.length} nota="Com cadastro ou negócio fechado" />
        <CartaoMetrica icone={Wallet} rotulo="Fechado" valor={brl(carteira)} nota="Somando as propostas aceitas" />
        <CartaoMetrica icone={Building2} rotulo="Empresas" valor={clientes.filter(c => c.tipo === "PJ").length} nota="Faturamento em CNPJ" />
        {/* Cadastro pela metade não gera contrato, é o número que diz quanto
            trabalho vai travar na hora de faturar, antes de travar. */}
        <CartaoMetrica icone={AlertCircle} rotulo="Cadastro incompleto" valor={incompletos}
          nota={incompletos ? "Trava o contrato" : "Todos completos"} />
      </FaixaMetricas>

      <div className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-[220px] flex-1 max-w-md">
          <Search className="absolute left-3 top-3.5 h-4 w-4 text-muted-fg" />
          <Input className="pl-9" value={busca} onChange={e => setBusca(e.target.value)}
            placeholder="Nome, CPF/CNPJ, telefone, e-mail ou cidade..." />
        </div>
        <div className="flex items-center gap-1 rounded-2xl bg-surface-2/60 p-1">
          {([
            ["TODOS", "Todos"], ["PF", "Pessoa física"], ["PJ", "Empresas"], ["INCOMPLETOS", "Incompletos"],
          ] as const).map(([v, l]) => (
            <button key={v} onClick={() => setFiltro(v)}
              className={`rounded-xl px-3 py-1.5 text-xs font-medium transition-colors ${
                filtro === v ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              }`}>
              {l}
            </button>
          ))}
        </div>
      </div>

      {carregando ? (
        <div className="space-y-2">
          {[0, 1, 2, 3].map(i => <div key={i} className="h-20 animate-pulse rounded-2xl bg-white/[0.05]" />)}
        </div>
      ) : clientes.length === 0 ? (
        <EmptyState icon={Contact} title="Nenhum cliente ainda"
          subtitle="Um lead vira cliente quando os dados de faturamento são preenchidos numa proposta, ou quando o negócio é ganho." />
      ) : visiveis.length === 0 ? (
        <div className="flex h-32 items-center justify-center text-sm text-muted-foreground/50">
          Nenhum cliente com esse filtro.
        </div>
      ) : (
        <div className="min-h-0 flex-1 space-y-2 overflow-y-auto pb-4">
          {visiveis.map(c => {
            const dias = diasDesde(c.ultimo_contato)
            return (
              <button key={c.id} onClick={() => setAberto(c)}
                className="flex w-full items-center gap-3 rounded-2xl border border-hairline bg-surface-1 p-4 text-left transition-colors hover:bg-surface-2">
                <Selo c={c} />

                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                    <p className="truncate text-[15px] font-semibold text-foreground">{c.nome}</p>
                    {c.documento && (
                      <span className="rounded-full bg-surface-2 px-2 py-0.5 font-mono text-[11px] text-muted-fg">
                        {formatarDocumento(c.documento)}
                      </span>
                    )}
                    {!c.cadastro_completo && (
                      <span className="flex items-center gap-1 rounded-full bg-ios-orange/10 px-2 py-0.5 text-[11px] text-ios-orange">
                        <AlertCircle className="h-3 w-3" /> cadastro incompleto
                      </span>
                    )}
                  </div>
                  <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[12px] text-muted-fg">
                    {c.telefone && <span className="flex items-center gap-1"><Phone className="h-3 w-3" />{formatarTelefone(c.telefone)}</span>}
                    {c.email && <span className="flex min-w-0 items-center gap-1"><Mail className="h-3 w-3 flex-shrink-0" /><span className="truncate">{c.email}</span></span>}
                    {c.cidade && <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{c.cidade}{c.uf ? `/${c.uf}` : ""}</span>}
                  </div>
                </div>

                <div className="hidden flex-shrink-0 text-right sm:block">
                  {c.valor_fechado > 0 && (
                    <p className="text-[14px] font-semibold text-foreground">{brl(c.valor_fechado)}</p>
                  )}
                  <p className="text-[11px] text-muted-fg">
                    {c.propostas} proposta{c.propostas === 1 ? "" : "s"}
                    {c.propostas_fechadas > 0 && ` · ${c.propostas_fechadas} fechada${c.propostas_fechadas === 1 ? "" : "s"}`}
                  </p>
                  {/* Silêncio longo é o que faz a carteira parar de render. */}
                  {dias != null && (
                    <p className={`text-[11px] ${dias > 90 ? "text-ios-orange" : "text-muted-foreground/60"}`}>
                      {dias === 0 ? "contato hoje" : `há ${dias} dia${dias === 1 ? "" : "s"} sem contato`}
                    </p>
                  )}
                </div>
              </button>
            )
          })}
        </div>
      )}

      {/* Ficha do cliente: cadastro, propostas e a mesma linha do tempo do lead
          — a conversa não se reparte por tela. */}
      <Dialog open={!!aberto} onOpenChange={o => !o && setAberto(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="flex min-w-0 items-center gap-2">
              {aberto?.tipo === "PJ" ? <Building2 className="h-5 w-5 text-ios-purple" /> : <User className="h-5 w-5 text-ios-blue" />}
              <span className="truncate">{aberto?.nome}</span>
            </DialogTitle>
          </DialogHeader>
          {aberto && (
            <DialogBody>
              <Tabs defaultValue="dossie">
                <TabsList className="bg-surface-2">
                  <TabsTrigger value="dossie">Dossiê</TabsTrigger>
                  <TabsTrigger value="ficha">Ficha</TabsTrigger>
                  <TabsTrigger value="historico">Histórico</TabsTrigger>
                </TabsList>

                <TabsContent value="dossie" className="mt-4 max-h-[62vh] space-y-4 overflow-y-auto pr-1">
                <div className="rounded-[18px] border border-hairline bg-surface-2/30 p-3.5">
                  <h4 className="text-[13px] font-semibold text-foreground">Cadastro</h4>
                  <dl className="mt-2 space-y-1 text-[12px]">
                    {([
                      ["Documento", aberto.documento ? formatarDocumento(aberto.documento) : null],
                      ["Inscr. estadual", aberto.ie],
                      ["Nome no funil", aberto.nome_funil !== aberto.nome ? aberto.nome_funil : null],
                      ["Telefone", aberto.telefone ? formatarTelefone(aberto.telefone) : null],
                      ["E-mail", aberto.email],
                      ["Endereço", aberto.logradouro
                        ? `${aberto.logradouro}, ${aberto.numero ?? "s/n"}${aberto.complemento ? `, ${aberto.complemento}` : ""}${aberto.bairro ? ` · ${aberto.bairro}` : ""}`
                        : null],
                      ["Cidade", aberto.cidade ? `${aberto.cidade}${aberto.uf ? `/${aberto.uf}` : ""}${aberto.cep ? ` · ${formatarCEP(aberto.cep)}` : ""}` : null],
                      ["Indicado por", aberto.parceiro],
                    ] as const).filter(([, v]) => !!v).map(([k, v]) => (
                      <div key={k} className="flex gap-2">
                        <dt className="w-28 flex-shrink-0 text-muted-fg">{k}</dt>
                        <dd className="min-w-0 break-words text-foreground">{v}</dd>
                      </div>
                    ))}
                  </dl>
                  <p className="mt-2 border-t border-hairline pt-2 text-[11px] text-muted-fg">
                    {aberto.confirmado_em
                      ? `Conferido em ${dataCurta(aberto.confirmado_em)}${aberto.origem_proposta ? ` · ${aberto.origem_proposta}` : ""}`
                      : "Cadastro ainda não conferido em contrato"}
                    {" · "}edita-se na proposta, para o contrato e a nota não divergirem.
                  </p>
                </div>

                <div className="space-y-1.5">
                  <h4 className="px-1 text-[13px] font-semibold text-foreground">
                    Propostas ({aberto.lista_propostas.length})
                  </h4>
                  {aberto.lista_propostas.length === 0 ? (
                    <p className="px-1 text-[12px] text-muted-fg">Nenhuma proposta ainda.</p>
                  ) : aberto.lista_propostas.map(p => (
                    <Link key={p.id} href={`/propostas/${p.id}`}
                      className="flex items-center gap-2.5 rounded-[14px] border border-hairline bg-surface-1 px-3 py-2 transition-colors hover:bg-surface-2">
                      <FileText className="h-3.5 w-3.5 flex-shrink-0 text-muted-fg" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-medium text-foreground">{p.numero}</p>
                        <p className="text-[11px] text-muted-fg">
                          {p.status.replace(/_/g, " ").toLowerCase()} · {dataCurta(p.createdAt)}
                        </p>
                      </div>
                      <span className="flex-shrink-0 text-[13px] font-semibold text-foreground">{brl(p.valor_total)}</span>
                      <ExternalLink className="h-3 w-3 flex-shrink-0 text-muted-foreground/40" />
                    </Link>
                  ))}
                </div>

                  <Link href="/leads"
                    className="flex items-center gap-1.5 px-1 text-[12px] text-ios-blue hover:underline">
                    <CalendarClock className="h-3.5 w-3.5" /> Ver no funil de leads
                  </Link>
                </TabsContent>

                {/* Mesma ficha do lead, e de propósito: cliente e lead são o
                    mesmo cadastro. Duas fichas seriam duas verdades sobre a
                    mesma obra. */}
                <TabsContent value="ficha" className="mt-4 max-h-[62vh] overflow-y-auto pr-1">
                  <FichaLead leadId={aberto.id} valores={aberto.ficha} aoSalvar={carregar} />
                </TabsContent>

                <TabsContent value="historico" className="mt-4">
                  <HistoricoLead leadId={aberto.id} titulo="Histórico do cliente" />
                </TabsContent>
              </Tabs>

              {/* Excluir o cliente é excluir o LEAD: é o mesmo cadastro visto
                  de outro ângulo. Fica no rodapé da ficha, longe do que se usa
                  todo dia, e o aviso diz o que vai junto — histórico, contatos
                  e o vínculo com as propostas. */}
              <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-hairline pt-4">
                <p className="text-[12px] text-muted-fg">
                  Excluir apaga o cadastro, o histórico e os contatos.
                  {aberto.propostas > 0 && ` As ${aberto.propostas} proposta(s) continuam, sem cliente vinculado.`}
                </p>
                <Button variant="destructive" size="sm" className="gap-1.5"
                  onClick={() => setExcluir(aberto)}>
                  <Trash2 className="h-3.5 w-3.5" /> Excluir cliente
                </Button>
              </div>
            </DialogBody>
          )}
        </DialogContent>
      </Dialog>

      {/* Confirmação em diálogo próprio: pedir "tem certeza?" dentro da ficha
          aberta esconderia o aviso atrás do que está sendo lido. */}
      <Dialog open={!!excluir} onOpenChange={o => !o && setExcluir(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Excluir {excluir?.nome}?</DialogTitle>
          </DialogHeader>
          <DialogBody>
            <p className="text-[13px] leading-relaxed text-muted-foreground">
              O cadastro sai do funil e da carteira, junto com o histórico da
              conversa e os contatos do projeto. Não há como desfazer.
            </p>
            {!!excluir?.propostas && (
              <p className="mt-2 text-[13px] text-warning">
                {excluir.propostas} proposta(s) deste cliente continuam no sistema,
                mas ficam sem cadastro vinculado.
              </p>
            )}
            {erroExcluir && <p className="mt-3 text-[13px] text-ios-red">{erroExcluir}</p>}
            <div className="mt-5 flex justify-end gap-2">
              <Button variant="secondary" onClick={() => setExcluir(null)}>Cancelar</Button>
              <Button variant="destructive" disabled={excluindo} onClick={confirmarExclusao}>
                {excluindo ? "Excluindo..." : "Excluir"}
              </Button>
            </div>
          </DialogBody>
        </DialogContent>
      </Dialog>
    </div>
  )
}
