"use client"

/**
 * Análises & Estatísticas — BI executivo da empresa inteira (só ADMIN).
 *
 * Organizado em abas em vez de um rolo único: eram 17 blocos numa página só,
 * e ninguém rolava até o fim. Cada aba responde uma pergunta de negócio.
 *
 * Só a apresentação mudou — a origem dos dados (/api/analises) e o RBAC
 * continuam os mesmos.
 */
import { useState, useEffect } from "react"
import {
  BarChart3, TrendingUp, Users, Wrench, Package, Target, Layers, HardHat,
  AlertTriangle, Percent, CircleDollarSign, Wallet, ShoppingCart, Boxes,
  Trophy, PackageX, CalendarClock, ArrowDownRight, ArrowUpRight, Building2,
} from "lucide-react"
import { PageLoader } from "@/components/ui/bouncing-dots"
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell,
  LineChart, Line, CartesianGrid, AreaChart, Area, PieChart, Pie,
} from "recharts"
import { useMemoriaDeFiltro } from "@/hooks/usar-memoria-filtro"
import { brlSemCentavos as brl, brlCurto, num, pct } from "@/lib/formato"


/* ─── Tipos (espelham /api/analises) ─────────────────────────────────────── */

interface Rank { nome: string; total: number; aceitas: number; valor: number; conversao: number; ticket: number }
interface Dados {
  comercial: {
    funil: { status: string; qtd: number; valor: number }[]
    total_propostas: number; aceitas: number; conversao: number
    ticket_medio: number; valor_aceito: number; pipeline_aberto: number
    ranking_vendedores: Rank[]
    motivos_perda: { motivo: string; qtd: number; valor: number }[]
    valor_perdido: number
    serie_mensal: { mes: string; criadas: number; aceitas: number; valor: number }[]
  }
  produtos: {
    mais_vendidos: { nome: string; sku: string; categoria: string; qtd: number; faturamento: number }[]
    maior_faturamento: { nome: string; sku: string; qtd: number; faturamento: number }[]
    categorias: { nome: string; qtd: number; faturamento: number }[]
    curva_abc: { nome: string; faturamento: number; classe: string }[]
    margem_top: { nome: string; sku: string; margem: number; pct: number }[]
    margem_baixa: { nome: string; sku: string; margem: number; pct: number }[]
    parados: { nome: string; sku: string }[]
  }
  clientes: { top: { nome: string; valor: number; propostas: number }[]; novos: number; recorrentes: number; total: number; ticket_medio: number }
  financeiro: {
    a_receber: number; atrasado: number; recebido_mes: number; inadimplencia: number
    aging: { d0_30: number; d31_60: number; d61_90: number; d90mais: number }
    dre: { receita: number; custo: number; margem_bruta: number; margem_pct: number }
  }
  manutencao: {
    por_status: Record<string, number>; total: number
    obras_mais_chamados: { obra: string; qtd: number }[]
    faturados: number; custeados: number; valor_faturado: number; valor_custeado: number; taxa_faturamento: number
  }
  estoque: {
    valor_custo: number; valor_venda: number
    movimentos_30d: { tipo: string; qtd: number; lancamentos: number }[]
    abaixo_minimo: { nome: string; sku: string; saldo: number | null; minimo: number | null }[]
    categorias: { nome: string; valor: number }[]
  }
  obras: {
    por_etapa: { etapa: string; qtd: number }[]
    atrasadas: number; lista_atrasadas: { obra: string; dias: number }[]
    progresso_medio: number; total: number
  }
  time: { tarefas_concluidas: { nome: string; qtd: number }[]; carga_aberta: { nome: string; qtd: number }[]; logins_semana: number }
}

const STATUS_LABEL: Record<string, string> = {
  RASCUNHO: "Rascunho", ENVIADA: "Enviada", LIDA: "Lida", EM_REVISAO: "Em revisão",
  ACEITA: "Aceita", EM_FATURAMENTO: "Em faturamento", EM_CONTRATO: "Contrato", PROPOSTA_PERDIDA: "Perdida", CANCELADA: "Cancelada",
  NOVA: "Nova", AGUARDANDO: "Aguardando", EM_ANDAMENTO: "Em andamento", EM_CONFERENCIA: "Em conferência", CONCLUIDA: "Concluída",
}

/* Séries lidas dos tokens: trocar o tema troca os gráficos junto. */
const COR = {
  azul: "hsl(var(--chart-1))",
  c2: "hsl(var(--chart-2))",
  c3: "hsl(var(--chart-3))",
  c4: "hsl(var(--chart-4))",
  c5: "hsl(var(--chart-5))",
  perigo: "hsl(var(--danger))",
  grade: "hsl(var(--foreground) / 0.08)",
  eixo: "hsl(var(--muted-foreground))",
}
const ESCALA = [COR.azul, COR.c2, COR.c3, COR.c4, COR.c5]

type Tom = "neutro" | "azul" | "ok" | "atencao" | "risco"

const TOM_TEXTO: Record<Tom, string> = {
  neutro: "text-foreground", azul: "text-primary",
  ok: "text-success", atencao: "text-warning", risco: "text-danger",
}
const TOM_FUNDO: Record<Tom, string> = {
  neutro: "bg-foreground/10 text-foreground", azul: "bg-primary/15 text-primary",
  ok: "bg-success/15 text-success", atencao: "bg-warning/15 text-warning", risco: "bg-danger/15 text-danger",
}

/* ─── Primitivos ─────────────────────────────────────────────────────────── */

function Painel({ titulo, subtitulo, icon: Icon, className, children }: {
  titulo: string; subtitulo?: string
  icon?: React.ElementType; className?: string; children: React.ReactNode
}) {
  return (
    <section className={`ios-card p-4 sm:p-5 ${className ?? ""}`}>
      <header className="flex min-w-0 items-center gap-3">
        {Icon && (
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl bg-primary/15 text-primary">
            <Icon className="h-[17px] w-[17px]" strokeWidth={2.2} />
          </div>
        )}
        <div className="min-w-0">
          <h2 className="truncate text-[15px] font-semibold tracking-tight text-foreground">{titulo}</h2>
          {subtitulo && <p className="truncate text-[12px] text-muted-foreground">{subtitulo}</p>}
        </div>
      </header>
      <div className="mt-4">{children}</div>
    </section>
  )
}

function Kpi({ label, valor, dica, icon: Icon, tom = "neutro", tendencia }: {
  label: string; valor: string; dica?: string
  icon: React.ElementType; tom?: Tom; tendencia?: "sobe" | "desce"
}) {
  return (
    <div className="ios-card ios-tap min-h-[112px] p-4">
      <div className="flex items-start justify-between gap-2">
        <div className={`grid h-9 w-9 shrink-0 place-items-center rounded-2xl ${TOM_FUNDO[tom]}`}>
          <Icon className="h-[17px] w-[17px]" strokeWidth={2.2} />
        </div>
        {tendencia === "sobe" && <ArrowUpRight className="h-4 w-4 shrink-0 text-success" />}
        {tendencia === "desce" && <ArrowDownRight className="h-4 w-4 shrink-0 text-danger" />}
      </div>
      <p className="mt-4 truncate text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">{label}</p>
      <p className={`mt-1 truncate text-[22px] font-semibold leading-none tracking-tight tabular-nums sm:text-[26px] ${TOM_TEXTO[tom]}`}>
        {valor}
      </p>
      {dica && <p className="mt-1.5 truncate text-[11px] text-muted-foreground">{dica}</p>}
    </div>
  )
}

const GradeKpi = ({ children }: { children: React.ReactNode }) => (
  <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">{children}</div>
)

function Etiqueta({ children, tom = "neutro" }: { children: React.ReactNode; tom?: Tom }) {
  return (
    <span className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold tabular-nums ${TOM_FUNDO[tom]}`}>
      {children}
    </span>
  )
}

const Medidor = ({ valor }: { valor: number }) => (
  <div className="medidor mt-2"><span style={{ width: `${Math.max(0, Math.min(100, valor))}%` }} /></div>
)

/** Linha de lista: rótulo à esquerda, número à direita, barra embaixo. */
function Linha({ rotulo, sub, direita, progresso }: {
  rotulo: string; sub?: string; direita: React.ReactNode; progresso?: number
}) {
  return (
    <div className="ios-soft p-3.5">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
        <div className="min-w-0">
          <p className="truncate text-[13px] font-semibold text-foreground">{rotulo}</p>
          {sub && <p className="mt-0.5 truncate text-[11px] text-muted-foreground">{sub}</p>}
        </div>
        <div className="flex shrink-0 items-center gap-2">{direita}</div>
      </div>
      {progresso !== undefined && <Medidor valor={progresso} />}
    </div>
  )
}

function Grafico({ altura = 260, children }: { altura?: number; children: React.ReactElement }) {
  return (
    <div className="w-full" style={{ height: altura }}>
      <ResponsiveContainer width="100%" height="100%">{children}</ResponsiveContainer>
    </div>
  )
}

function Dica({ active, payload, label, dinheiro }: {
  active?: boolean
  payload?: { name?: string; value?: number | string; color?: string }[]
  label?: string | number; dinheiro?: boolean
}) {
  if (!active || !payload?.length) return null
  return (
    <div className="ios-soft min-w-[140px] px-3 py-2 text-[12px] shadow-xl">
      {label !== undefined && <p className="mb-1 font-semibold text-foreground">{label}</p>}
      {payload.map((p, i) => (
        <p key={i} className="flex items-center justify-between gap-3 text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full" style={{ backgroundColor: p.color }} />
            {p.name}
          </span>
          <span className="font-semibold tabular-nums text-foreground">
            {dinheiro ? brl(Number(p.value)) : num(Number(p.value))}
          </span>
        </p>
      ))}
    </div>
  )
}

const eixoX = { tick: { fill: COR.eixo, fontSize: 11 }, axisLine: false, tickLine: false } as const
const semDados = <p className="py-6 text-center text-[13px] text-muted-foreground">Sem dados no período.</p>

/* ─── Abas ───────────────────────────────────────────────────────────────── */

const ABAS = [
  { id: "comercial", label: "Comercial", icon: Target },
  { id: "produtos", label: "Produtos", icon: Boxes },
  { id: "clientes", label: "Clientes", icon: Users },
  { id: "financeiro", label: "Financeiro", icon: Wallet },
  { id: "obras", label: "Obras", icon: Building2 },
  { id: "operacao", label: "Operação", icon: Wrench },
] as const
type AbaId = (typeof ABAS)[number]["id"]

/* ─── Tela ───────────────────────────────────────────────────────────────── */

export default function AnalisesPage() {
  const [d, setD] = useState<Dados | null>(null)
  const [erro, setErro] = useState("")
  const [aba, setAba] = useMemoriaDeFiltro<AbaId>("analises:aba", "comercial")

  useEffect(() => {
    fetch("/api/analises").then(async r => {
      if (r.ok) setD(await r.json())
      else setErro((await r.json().catch(() => ({})))?.error || "Erro ao carregar.")
    }).catch(() => setErro("Erro de conexão."))
  }, [])

  if (erro) return <p className="py-16 text-center text-danger">{erro}</p>
  if (!d) return <div className="py-24"><PageLoader /></div>

  return (
    <div className="mx-auto w-full max-w-[1560px] p-3 pb-10 sm:p-5">
      <header className="ios-card flex items-center gap-3 p-4 sm:p-5">
        <div className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-primary/15 text-primary">
          <BarChart3 className="h-[18px] w-[18px]" strokeWidth={2.2} />
        </div>
        <div className="min-w-0">
          <h1 className="truncate text-[19px] font-semibold tracking-tight text-foreground sm:text-[22px]">Análises</h1>
          <p className="truncate text-[12px] text-muted-foreground">
            Inteligência de negócio · últimos 180 dias · dados ao vivo
          </p>
        </div>
      </header>

      {/* Trilho rolável: as 6 abas nunca são cortadas nem empurram a página. */}
      <nav className="ios-segment sem-barra mt-3 flex gap-1 overflow-x-auto p-1 sm:mt-4">
        {ABAS.map(a => {
          const ativa = a.id === aba
          return (
            <button
              key={a.id}
              type="button"
              onClick={() => setAba(a.id)}
              aria-current={ativa ? "page" : undefined}
              className={`ios-tap flex h-9 shrink-0 items-center gap-1.5 rounded-full px-3.5 text-[13px] font-semibold ${
                ativa
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-foreground/[0.06] hover:text-foreground"
              }`}
            >
              <a.icon className="h-4 w-4" strokeWidth={2.2} />
              {a.label}
            </button>
          )
        })}
      </nav>

      <div className="mt-3 space-y-3 sm:mt-4 sm:space-y-4">
        {aba === "comercial" && <Comercial d={d.comercial} />}
        {aba === "produtos" && <Produtos d={d.produtos} />}
        {aba === "clientes" && <Clientes d={d.clientes} />}
        {aba === "financeiro" && <Financeiro d={d.financeiro} />}
        {aba === "obras" && <Obras d={d.obras} />}
        {aba === "operacao" && <Operacao manutencao={d.manutencao} estoque={d.estoque} time={d.time} />}
      </div>
    </div>
  )
}

/* ─── Aba: Comercial ─────────────────────────────────────────────────────── */

function Comercial({ d }: { d: Dados["comercial"] }) {
  const maxFunil = Math.max(...d.funil.map(f => f.qtd), 1)
  const maxVend = Math.max(...d.ranking_vendedores.map(v => v.valor), 1)

  return (
    <>
      <GradeKpi>
        <Kpi label="Propostas" valor={num(d.total_propostas)} dica={`${num(d.aceitas)} aceitas`} icon={Layers} />
        <Kpi label="Conversão" valor={pct(d.conversao)} dica="das propostas" icon={Percent} tom="azul" />
        <Kpi label="Ticket médio" valor={brl(d.ticket_medio)} dica="por aceita" icon={CircleDollarSign} />
        <Kpi label="Valor aceito" valor={brl(d.valor_aceito)} dica={`Pipeline ${brl(d.pipeline_aberto)}`} icon={TrendingUp} tom="ok" />
      </GradeKpi>

      <div className="grid grid-cols-1 gap-3 sm:gap-4 xl:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
        <Painel titulo="Evolução mensal" subtitulo="Valor aceito e volume de propostas" icon={TrendingUp}>
          {d.serie_mensal.length === 0 ? semDados : (
            <>
              <Grafico altura={250}>
                <AreaChart data={d.serie_mensal} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                  <defs>
                    <linearGradient id="gradValor" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={COR.azul} stopOpacity={0.45} />
                      <stop offset="100%" stopColor={COR.azul} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke={COR.grade} vertical={false} />
                  <XAxis dataKey="mes" {...eixoX} />
                  <YAxis {...eixoX} tickFormatter={(v: number) => brlCurto(v)} width={62} />
                  <Tooltip content={<Dica dinheiro />} cursor={{ stroke: COR.grade }} />
                  <Area type="monotone" dataKey="valor" name="Valor" stroke={COR.azul} strokeWidth={2.4} fill="url(#gradValor)" />
                </AreaChart>
              </Grafico>
              <div className="mt-3 h-[130px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={d.serie_mensal} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                    <CartesianGrid stroke={COR.grade} vertical={false} />
                    <XAxis dataKey="mes" {...eixoX} />
                    <YAxis {...eixoX} width={62} allowDecimals={false} />
                    <Tooltip content={<Dica />} cursor={{ stroke: COR.grade }} />
                    <Line type="monotone" dataKey="criadas" name="Criadas" stroke={COR.c2} strokeWidth={2} dot={false} />
                    <Line type="monotone" dataKey="aceitas" name="Aceitas" stroke={COR.azul} strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </>
          )}
        </Painel>

        <Painel titulo="Funil de propostas" subtitulo="Quantidade e valor por status" icon={Target}>
          {d.funil.length === 0 ? semDados : (
            <div className="space-y-2.5">
              {d.funil.map(f => (
                <Linha
                  key={f.status}
                  rotulo={STATUS_LABEL[f.status] ?? f.status}
                  progresso={(f.qtd / maxFunil) * 100}
                  direita={
                    <>
                      <span className="text-[12px] tabular-nums text-muted-foreground">{num(f.qtd)}</span>
                      <Etiqueta tom={f.status === "ACEITA" ? "ok" : f.status === "PROPOSTA_PERDIDA" ? "risco" : "neutro"}>
                        {brl(f.valor)}
                      </Etiqueta>
                    </>
                  }
                />
              ))}
            </div>
          )}
        </Painel>
      </div>

      <Painel titulo="Ranking de vendedores" subtitulo="Desempenho no período" icon={Trophy}>
        {d.ranking_vendedores.length === 0 ? semDados : (
          <div className="space-y-2.5">
            {d.ranking_vendedores.map((v, i) => (
              <div key={v.nome} className="ios-soft p-3.5">
                <div className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3">
                  <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-foreground/10 text-[12px] font-semibold tabular-nums text-muted-foreground">
                    {i + 1}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-[14px] font-semibold text-foreground">{v.nome}</p>
                    <p className="mt-0.5 truncate text-[11px] text-muted-foreground">
                      {num(v.aceitas)} de {num(v.total)} · ticket {brl(v.ticket)}
                    </p>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-1.5">
                    <span className="text-[13px] font-semibold tabular-nums text-foreground">{brl(v.valor)}</span>
                    <Etiqueta tom={v.conversao >= 25 ? "ok" : v.conversao > 0 ? "azul" : "neutro"}>{pct(v.conversao)}</Etiqueta>
                  </div>
                </div>
                <Medidor valor={(v.valor / maxVend) * 100} />
              </div>
            ))}
          </div>
        )}
      </Painel>

      <Painel titulo="Motivos de perda" subtitulo={`${brl(d.valor_perdido)} perdidos no período`} icon={AlertTriangle}>
        {d.motivos_perda.length === 0 ? semDados : (
          <Grafico altura={Math.max(200, d.motivos_perda.length * 46)}>
            <BarChart data={d.motivos_perda} layout="vertical" margin={{ top: 4, right: 12, left: 4, bottom: 4 }}>
              <CartesianGrid stroke={COR.grade} horizontal={false} />
              <XAxis type="number" {...eixoX} tickFormatter={(v: number) => brlCurto(v)} />
              <YAxis type="category" dataKey="motivo" {...eixoX} width={128} />
              <Tooltip content={<Dica dinheiro />} cursor={{ fill: "hsl(var(--foreground) / 0.04)" }} />
              <Bar dataKey="valor" name="Valor" radius={[0, 8, 8, 0]} barSize={16}>
                {d.motivos_perda.map((_, i) => <Cell key={i} fill={ESCALA[Math.min(i, 4)]} />)}
              </Bar>
            </BarChart>
          </Grafico>
        )}
      </Painel>
    </>
  )
}

/* ─── Aba: Produtos ──────────────────────────────────────────────────────── */

function Produtos({ d }: { d: Dados["produtos"] }) {
  const totalFat = d.categorias.reduce((s, c) => s + c.faturamento, 0)
  const maxProd = Math.max(...d.mais_vendidos.map(p => p.qtd), 1)
  const maxFat = Math.max(...d.maior_faturamento.map(p => p.faturamento), 1)
  const classeTom = (c: string): Tom => (c === "A" ? "azul" : c === "B" ? "neutro" : "atencao")

  const abc = ["A", "B", "C"].map(cl => ({
    name: `Classe ${cl}`,
    value: d.curva_abc.filter(i => i.classe === cl).reduce((s, i) => s + i.faturamento, 0),
  })).filter(x => x.value > 0)

  return (
    <>
      <GradeKpi>
        <Kpi label="Faturamento" valor={brl(totalFat)} dica="todas as categorias" icon={CircleDollarSign} tom="azul" />
        <Kpi label="Classe A" valor={num(d.curva_abc.filter(i => i.classe === "A").length)} dica="produtos de maior peso" icon={Layers} tom="ok" />
        <Kpi label="Margem baixa" valor={num(d.margem_baixa.length)} dica="abaixo de 15%" icon={ArrowDownRight} tom="atencao" />
        <Kpi label="Sem giro" valor={num(d.parados.length)} dica="produtos parados" icon={PackageX} tom="atencao" />
      </GradeKpi>

      <div className="grid grid-cols-1 gap-3 sm:gap-4 xl:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)]">
        <Painel titulo="Faturamento por categoria" icon={Boxes}>
          {d.categorias.length === 0 ? semDados : (
            <Grafico altura={280}>
              <BarChart data={d.categorias} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
                <CartesianGrid stroke={COR.grade} vertical={false} />
                <XAxis dataKey="nome" {...eixoX} interval={0} height={48} angle={-14} textAnchor="end" />
                <YAxis {...eixoX} tickFormatter={(v: number) => brlCurto(v)} width={62} />
                <Tooltip content={<Dica dinheiro />} cursor={{ fill: "hsl(var(--foreground) / 0.04)" }} />
                <Bar dataKey="faturamento" name="Faturamento" radius={[8, 8, 0, 0]} barSize={30}>
                  {d.categorias.map((_, i) => <Cell key={i} fill={ESCALA[Math.min(i, 4)]} />)}
                </Bar>
              </BarChart>
            </Grafico>
          )}
        </Painel>

        <Painel titulo="Curva ABC" subtitulo="Concentração de faturamento" icon={Percent}>
          {abc.length === 0 ? semDados : (
            <>
              <Grafico altura={220}>
                <PieChart>
                  <Tooltip content={<Dica dinheiro />} />
                  <Pie data={abc} dataKey="value" nameKey="name" innerRadius={56} outerRadius={90} paddingAngle={3} stroke="none">
                    {abc.map((_, i) => <Cell key={i} fill={[COR.azul, COR.c2, COR.c4][i]} />)}
                  </Pie>
                </PieChart>
              </Grafico>
              <div className="mt-2 space-y-2">
                {d.curva_abc.slice(0, 5).map(i => (
                  <Linha
                    key={i.nome}
                    rotulo={i.nome}
                    direita={
                      <>
                        <span className="text-[12px] font-semibold tabular-nums text-foreground">{brl(i.faturamento)}</span>
                        <Etiqueta tom={classeTom(i.classe)}>{i.classe}</Etiqueta>
                      </>
                    }
                  />
                ))}
              </div>
            </>
          )}
        </Painel>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:gap-4 xl:grid-cols-2">
        <Painel titulo="Mais vendidos" subtitulo="Por quantidade" icon={ShoppingCart}>
          {d.mais_vendidos.length === 0 ? semDados : (
            <div className="space-y-2.5">
              {d.mais_vendidos.map(p => (
                <Linha
                  key={p.sku}
                  rotulo={p.nome}
                  sub={`${p.sku} · ${p.categoria}`}
                  progresso={(p.qtd / maxProd) * 100}
                  direita={
                    <>
                      <span className="text-[12px] tabular-nums text-muted-foreground">{num(p.qtd)}</span>
                      <Etiqueta tom="azul">{brl(p.faturamento)}</Etiqueta>
                    </>
                  }
                />
              ))}
            </div>
          )}
        </Painel>

        <Painel titulo="Maior faturamento" subtitulo="Por receita gerada" icon={CircleDollarSign}>
          {d.maior_faturamento.length === 0 ? semDados : (
            <div className="space-y-2.5">
              {d.maior_faturamento.map(p => (
                <Linha
                  key={p.sku}
                  rotulo={p.nome}
                  sub={`${p.sku} · ${num(p.qtd)} un.`}
                  progresso={(p.faturamento / maxFat) * 100}
                  direita={<span className="text-[13px] font-semibold tabular-nums text-foreground">{brl(p.faturamento)}</span>}
                />
              ))}
            </div>
          )}
        </Painel>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:gap-4 xl:grid-cols-2">
        <Painel titulo="Maiores margens" subtitulo="Melhor rentabilidade do catálogo" icon={TrendingUp}>
          {d.margem_top.length === 0 ? semDados : (
            <div className="space-y-2.5">
              {d.margem_top.map(m => (
                <Linha
                  key={m.sku}
                  rotulo={m.nome}
                  sub={m.sku}
                  progresso={m.pct}
                  direita={
                    <>
                      <span className="text-[12px] font-semibold tabular-nums text-foreground">{brl(m.margem)}</span>
                      <Etiqueta tom={m.pct >= 50 ? "ok" : "azul"}>{pct(m.pct)}</Etiqueta>
                    </>
                  }
                />
              ))}
            </div>
          )}
        </Painel>

        <Painel titulo="Margens baixas" subtitulo="Abaixo de 15%, revisar preço" icon={AlertTriangle}>
          {d.margem_baixa.length === 0 ? semDados : (
            <div className="space-y-2.5">
              {d.margem_baixa.map(m => (
                <Linha
                  key={m.sku}
                  rotulo={m.nome}
                  sub={m.sku}
                  progresso={m.pct}
                  direita={
                    <>
                      <span className="text-[12px] font-semibold tabular-nums text-foreground">{brl(m.margem)}</span>
                      <Etiqueta tom="risco">{pct(m.pct)}</Etiqueta>
                    </>
                  }
                />
              ))}
            </div>
          )}
        </Painel>
      </div>

      {d.parados.length > 0 && (
        <Painel titulo="Produtos parados" subtitulo="Sem venda no período" icon={PackageX}>
          <div className="space-y-2.5">
            {d.parados.map(p => (
              <Linha key={p.sku} rotulo={p.nome} sub={p.sku} direita={<Etiqueta tom="atencao">Sem giro</Etiqueta>} />
            ))}
          </div>
        </Painel>
      )}
    </>
  )
}

/* ─── Aba: Clientes ──────────────────────────────────────────────────────── */

function Clientes({ d }: { d: Dados["clientes"] }) {
  const maxCli = Math.max(...d.top.map(c => c.valor), 1)
  const pctNovos = d.total ? (d.novos / d.total) * 100 : 0
  const composicao = [
    { name: "Novos", value: d.novos },
    { name: "Recorrentes", value: d.recorrentes },
  ].filter(x => x.value > 0)

  return (
    <>
      <GradeKpi>
        <Kpi label="Clientes" valor={num(d.total)} dica="base ativa" icon={Users} />
        <Kpi label="Novos" valor={num(d.novos)} dica={`${pct(pctNovos)} da base`} icon={ArrowUpRight} tom="azul" />
        <Kpi label="Recorrentes" valor={num(d.recorrentes)} dica="voltaram a comprar" icon={Trophy} tom="ok" />
        <Kpi label="Ticket médio" valor={brl(d.ticket_medio)} dica="por cliente" icon={CircleDollarSign} />
      </GradeKpi>

      <div className="grid grid-cols-1 gap-3 sm:gap-4 xl:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)]">
        <Painel titulo="Top clientes" subtitulo="Por valor contratado" icon={Trophy}>
          {d.top.length === 0 ? semDados : (
            <div className="space-y-2.5">
              {d.top.map((c, i) => (
                <div key={c.nome} className="ios-soft p-3.5">
                  <div className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3">
                    <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-foreground/10 text-[12px] font-semibold tabular-nums text-muted-foreground">
                      {i + 1}
                    </span>
                    <div className="min-w-0">
                      <p className="truncate text-[14px] font-semibold text-foreground">{c.nome}</p>
                      <p className="mt-0.5 truncate text-[11px] text-muted-foreground">{num(c.propostas)} propostas</p>
                    </div>
                    <span className="shrink-0 text-[13px] font-semibold tabular-nums text-foreground">{brl(c.valor)}</span>
                  </div>
                  <Medidor valor={(c.valor / maxCli) * 100} />
                </div>
              ))}
            </div>
          )}
        </Painel>

        <Painel titulo="Composição da base" subtitulo="Novos × recorrentes" icon={Users}>
          {composicao.length === 0 ? semDados : (
            <>
              <Grafico altura={230}>
                <PieChart>
                  <Tooltip content={<Dica />} />
                  <Pie data={composicao} dataKey="value" nameKey="name" innerRadius={60} outerRadius={92} paddingAngle={3} stroke="none">
                    {composicao.map((_, i) => <Cell key={i} fill={[COR.azul, COR.c2][i]} />)}
                  </Pie>
                </PieChart>
              </Grafico>
              <div className="grid grid-cols-2 gap-3">
                <div className="ios-soft p-3">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Novos</p>
                  <p className="mt-1 text-[20px] font-semibold tabular-nums text-primary">{num(d.novos)}</p>
                </div>
                <div className="ios-soft p-3">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Recorrentes</p>
                  <p className="mt-1 text-[20px] font-semibold tabular-nums text-foreground">{num(d.recorrentes)}</p>
                </div>
              </div>
            </>
          )}
        </Painel>
      </div>
    </>
  )
}

/* ─── Aba: Financeiro ────────────────────────────────────────────────────── */

function Financeiro({ d }: { d: Dados["financeiro"] }) {
  const aging = [
    { faixa: "0–30 dias", valor: d.aging.d0_30 },
    { faixa: "31–60 dias", valor: d.aging.d31_60 },
    { faixa: "61–90 dias", valor: d.aging.d61_90 },
    { faixa: "90+ dias", valor: d.aging.d90mais },
  ]
  const totalAging = aging.reduce((s, a) => s + a.valor, 0) || 1

  return (
    <>
      <GradeKpi>
        <Kpi label="A receber" valor={brl(d.a_receber)} dica="títulos em aberto" icon={Wallet} tom="azul" />
        <Kpi label="Atrasado" valor={brl(d.atrasado)} dica={d.atrasado > 0 ? "vencidos" : "nada vencido"} icon={AlertTriangle} tom={d.atrasado > 0 ? "risco" : "neutro"} />
        <Kpi label="Recebido no mês" valor={brl(d.recebido_mes)} dica="baixas confirmadas" icon={CircleDollarSign} tom="ok" />
        <Kpi label="Inadimplência" valor={pct(d.inadimplencia)} dica="sobre a carteira" icon={Percent} tom={d.inadimplencia > 10 ? "risco" : "atencao"} />
      </GradeKpi>

      <div className="grid grid-cols-1 gap-3 sm:gap-4 xl:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]">
        <Painel titulo="Aging de recebíveis" subtitulo="Distribuição por faixa de vencimento" icon={CalendarClock}>
          <Grafico altura={250}>
            <BarChart data={aging} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
              <CartesianGrid stroke={COR.grade} vertical={false} />
              <XAxis dataKey="faixa" {...eixoX} />
              <YAxis {...eixoX} tickFormatter={(v: number) => brlCurto(v)} width={62} />
              <Tooltip content={<Dica dinheiro />} cursor={{ fill: "hsl(var(--foreground) / 0.04)" }} />
              <Bar dataKey="valor" name="Valor" radius={[8, 8, 0, 0]} barSize={38}>
                <Cell fill={COR.azul} />
                <Cell fill={COR.c2} />
                <Cell fill={COR.c3} />
                <Cell fill={COR.perigo} />
              </Bar>
            </BarChart>
          </Grafico>
          <div className="mt-3 space-y-2">
            {aging.map((a, i) => (
              <Linha
                key={a.faixa}
                rotulo={a.faixa}
                progresso={(a.valor / totalAging) * 100}
                direita={
                  <span className={`text-[13px] font-semibold tabular-nums ${i === 3 ? "text-danger" : "text-foreground"}`}>
                    {brl(a.valor)}
                  </span>
                }
              />
            ))}
          </div>
        </Painel>

        <Painel titulo="DRE simplificado" subtitulo="Resultado das propostas aceitas" icon={BarChart3}>
          <div className="space-y-2.5">
            {([
              { label: "Receita", valor: d.dre.receita, tom: "neutro" as Tom },
              { label: "Custo", valor: -d.dre.custo, tom: "risco" as Tom },
              { label: "Margem bruta", valor: d.dre.margem_bruta, tom: "ok" as Tom },
            ]).map(l => (
              <div key={l.label} className="ios-soft grid min-h-[56px] grid-cols-[minmax(0,1fr)_auto] items-center gap-3 p-3.5">
                <p className="truncate text-[13px] font-semibold text-foreground">{l.label}</p>
                <span className={`shrink-0 text-[15px] font-semibold tabular-nums ${TOM_TEXTO[l.tom]}`}>{brl(l.valor)}</span>
              </div>
            ))}
            <div className="ios-soft p-4">
              <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Margem sobre receita</p>
              <p className="mt-1 text-[30px] font-semibold leading-none tracking-tight tabular-nums text-primary">
                {pct(d.dre.margem_pct)}
              </p>
              <Medidor valor={d.dre.margem_pct} />
            </div>
          </div>
        </Painel>
      </div>
    </>
  )
}

/* ─── Aba: Obras ─────────────────────────────────────────────────────────── */

function Obras({ d }: { d: Dados["obras"] }) {
  const maxEtapa = Math.max(...d.por_etapa.map(e => e.qtd), 1)
  const emAndamento = d.por_etapa.filter(e => e.etapa !== "CONCLUIDA" && e.etapa !== "Entregue").reduce((s, e) => s + e.qtd, 0)

  return (
    <>
      <GradeKpi>
        <Kpi label="Obras" valor={num(d.total)} dica="no período" icon={Building2} />
        <Kpi label="Em andamento" valor={num(emAndamento)} dica="fora de concluída" icon={Layers} tom="azul" />
        <Kpi label="Atrasadas" valor={num(d.atrasadas)} dica="fora do prazo" icon={AlertTriangle} tom={d.atrasadas > 0 ? "risco" : "neutro"} />
        <Kpi label="Progresso médio" valor={pct(d.progresso_medio)} dica="execução" icon={Percent} tom="ok" />
      </GradeKpi>

      <div className="grid grid-cols-1 gap-3 sm:gap-4 xl:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]">
        <Painel titulo="Obras por etapa" icon={HardHat}>
          {d.por_etapa.length === 0 ? semDados : (
            <div className="space-y-2.5">
              {d.por_etapa.map(e => (
                <Linha
                  key={e.etapa}
                  rotulo={STATUS_LABEL[e.etapa] ?? e.etapa}
                  progresso={(e.qtd / maxEtapa) * 100}
                  direita={<span className="text-[13px] font-semibold tabular-nums text-foreground">{num(e.qtd)}</span>}
                />
              ))}
            </div>
          )}
        </Painel>

        <Painel titulo="Obras atrasadas" subtitulo={`${num(d.atrasadas)} fora do prazo`} icon={AlertTriangle}>
          {d.lista_atrasadas.length === 0 ? (
            <p className="py-6 text-center text-[13px] text-success">Nenhuma obra atrasada.</p>
          ) : (
            <div className="space-y-2.5">
              {d.lista_atrasadas.map(o => (
                <Linha
                  key={o.obra}
                  rotulo={o.obra}
                  direita={<Etiqueta tom={o.dias >= 10 ? "risco" : "atencao"}>{o.dias} {o.dias === 1 ? "dia" : "dias"}</Etiqueta>}
                />
              ))}
            </div>
          )}
          <div className="ios-soft mt-3 p-4">
            <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Progresso médio da carteira</p>
            <p className="mt-1 text-[30px] font-semibold leading-none tracking-tight tabular-nums text-primary">{pct(d.progresso_medio)}</p>
            <Medidor valor={d.progresso_medio} />
          </div>
        </Painel>
      </div>
    </>
  )
}

/* ─── Aba: Operação (manutenção · estoque · time) ────────────────────────── */

function Operacao({ manutencao, estoque, time }: {
  manutencao: Dados["manutencao"]; estoque: Dados["estoque"]; time: Dados["time"]
}) {
  const statusManut = Object.entries(manutencao.por_status)
  const maxManut = Math.max(...statusManut.map(([, q]) => q), 1)
  const maxCham = Math.max(...manutencao.obras_mais_chamados.map(o => o.qtd), 1)
  const maxEstCat = Math.max(...estoque.categorias.map(c => c.valor), 1)
  const maxTar = Math.max(...time.tarefas_concluidas.map(t => t.qtd), 1)
  const maxCarga = Math.max(...time.carga_aberta.map(t => t.qtd), 1)

  return (
    <>
      <GradeKpi>
        <Kpi label="Chamados" valor={num(manutencao.total)} dica={`${pct(manutencao.taxa_faturamento)} faturados`} icon={Wrench} />
        <Kpi label="Faturado em manutenção" valor={brl(manutencao.valor_faturado)} dica={`Custo ${brl(manutencao.valor_custeado)}`} icon={CircleDollarSign} tom="ok" />
        <Kpi label="Estoque (custo)" valor={brl(estoque.valor_custo)} dica={`Venda ${brl(estoque.valor_venda)}`} icon={Package} tom="azul" />
        <Kpi label="Abaixo do mínimo" valor={num(estoque.abaixo_minimo.length)} dica="risco de ruptura" icon={PackageX} tom={estoque.abaixo_minimo.length > 0 ? "atencao" : "neutro"} />
      </GradeKpi>

      <div className="grid grid-cols-1 gap-3 sm:gap-4 xl:grid-cols-2">
        <Painel titulo="Manutenção por status" icon={Wrench}>
          {statusManut.length === 0 ? semDados : (
            <div className="space-y-2.5">
              {statusManut.map(([st, qtd]) => (
                <Linha
                  key={st}
                  rotulo={STATUS_LABEL[st] ?? st}
                  progresso={(qtd / maxManut) * 100}
                  direita={<span className="text-[13px] font-semibold tabular-nums text-foreground">{num(qtd)}</span>}
                />
              ))}
            </div>
          )}
        </Painel>

        <Painel titulo="Obras com mais chamados" subtitulo="Onde a manutenção se concentra" icon={AlertTriangle}>
          {manutencao.obras_mais_chamados.length === 0 ? semDados : (
            <div className="space-y-2.5">
              {manutencao.obras_mais_chamados.map(o => (
                <Linha
                  key={o.obra}
                  rotulo={o.obra}
                  progresso={(o.qtd / maxCham) * 100}
                  direita={<Etiqueta tom={o.qtd >= 5 ? "atencao" : "neutro"}>{num(o.qtd)}</Etiqueta>}
                />
              ))}
            </div>
          )}
        </Painel>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:gap-4 xl:grid-cols-2">
        <Painel titulo="Estoque por categoria" subtitulo="Valor imobilizado" icon={Boxes}>
          {estoque.categorias.length === 0 ? semDados : (
            <div className="space-y-2.5">
              {estoque.categorias.map(c => (
                <Linha
                  key={c.nome}
                  rotulo={c.nome}
                  progresso={(c.valor / maxEstCat) * 100}
                  direita={<span className="text-[13px] font-semibold tabular-nums text-foreground">{brl(c.valor)}</span>}
                />
              ))}
            </div>
          )}
        </Painel>

        <Painel titulo="Ruptura de estoque" subtitulo="Itens abaixo do mínimo" icon={PackageX}>
          {estoque.abaixo_minimo.length === 0 ? (
            <p className="py-6 text-center text-[13px] text-success">Nenhum item abaixo do mínimo.</p>
          ) : (
            <div className="space-y-2.5">
              {estoque.abaixo_minimo.map(i => (
                <Linha
                  key={i.sku}
                  rotulo={i.nome}
                  sub={i.sku}
                  direita={<Etiqueta tom="risco">{num(i.saldo ?? 0)} / {num(i.minimo ?? 0)}</Etiqueta>}
                />
              ))}
            </div>
          )}
        </Painel>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:gap-4 xl:grid-cols-2">
        <Painel titulo="Tarefas concluídas" subtitulo={`${num(time.logins_semana)} acessos na semana`} icon={Trophy}>
          {time.tarefas_concluidas.length === 0 ? semDados : (
            <div className="space-y-2.5">
              {time.tarefas_concluidas.map(t => (
                <Linha
                  key={t.nome}
                  rotulo={t.nome}
                  progresso={(t.qtd / maxTar) * 100}
                  direita={<Etiqueta tom="ok">{num(t.qtd)}</Etiqueta>}
                />
              ))}
            </div>
          )}
        </Painel>

        <Painel titulo="Carga em aberto" subtitulo="Tarefas pendentes por pessoa" icon={Layers}>
          {time.carga_aberta.length === 0 ? semDados : (
            <div className="space-y-2.5">
              {time.carga_aberta.map(t => (
                <Linha
                  key={t.nome}
                  rotulo={t.nome}
                  progresso={(t.qtd / maxCarga) * 100}
                  direita={<Etiqueta tom={t.qtd >= 10 ? "atencao" : "azul"}>{num(t.qtd)}</Etiqueta>}
                />
              ))}
            </div>
          )}
        </Painel>
      </div>
    </>
  )
}
