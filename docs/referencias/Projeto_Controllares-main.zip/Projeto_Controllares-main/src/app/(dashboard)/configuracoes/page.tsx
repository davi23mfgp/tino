﻿"use client"

import { proxiedImg } from "@/lib/img"
import { useState, useEffect, useCallback } from "react"
import { FileText, ChevronLeft,
  Users, Plus, Pencil, Trash2, RefreshCw, ShieldCheck, Eye, EyeOff,
  Building2, Settings, Save, Upload, X, CheckCheck, Link2, Unlink, Calendar, HardDrive, ChevronDown,
  ShieldAlert, CircleCheck, CircleAlert, CircleX, ExternalLink, Mic,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { AdminView } from "./admin-view"
import { CabecalhoPagina } from "@/components/ui/cabecalho-pagina"
import { BackupsTab } from "./backups-tab"
import { ConhecimentoTab } from "./conhecimento-tab"
import { TelegramGruposTab } from "./telegram-grupos"
import { Bloco } from "@/components/ui/bloco-lista"
import { useConfirmar } from "@/components/confirmar"

// ============================================================
// Tipos e constantes
// ============================================================
type Role =
  | "ADMIN" | "VENDEDOR" | "FINANCEIRO"
  | "RESPONSAVEL_TECNICO" | "INSTALADOR" | "ENGENHEIRO_PROJETOS"

const ROLE_LABEL: Record<Role, string> = {
  ADMIN: "Administrador",
  VENDEDOR: "Vendedor",
  FINANCEIRO: "Financeiro",
  RESPONSAVEL_TECNICO: "Responsável Técnico",
  INSTALADOR: "Instalador",
  ENGENHEIRO_PROJETOS: "Engenheiro de Projetos",
}

const ROLE_DESC: Record<Role, string> = {
  ADMIN: "Acesso total, todas as telas e configurações",
  VENDEDOR: "Propostas, catálogo, kits e pipeline comercial",
  FINANCEIRO: "Contas a receber, parcelas e faturamento",
  RESPONSAVEL_TECNICO: "Dashboard operacional filtrado pelas obras sob sua responsabilidade",
  INSTALADOR: "Obras em que está alocado, vistorias e agendamentos (sem valores comerciais)",
  ENGENHEIRO_PROJETOS: "Kanban de projetos e aba de engenharia das obras",
}

const ROLE_COLOR: Record<Role, string> = {
  ADMIN: "text-red-400 bg-red-500/10",
  VENDEDOR: "text-sky-400 bg-sky-500/10",
  FINANCEIRO: "text-green-400 bg-green-500/10",
  RESPONSAVEL_TECNICO: "text-amber-400 bg-amber-500/10",
  INSTALADOR: "text-orange-400 bg-orange-500/10",
  ENGENHEIRO_PROJETOS: "text-purple-400 bg-purple-500/10",
}

interface Usuario {
  id: string
  nome: string
  email: string
  role: Role
  roles?: Role[]
  status?: string
  createdAt: string
}

interface Empresa {
  id: string
  nome_empresa: string
  cnpj_cpf: string
  logo_url: string | null
  logo_proposta_url: string | null
  endereco_base: string | null
  email_contato: string | null
  telefone_contato: string | null
  desconto_maximo: number | null
  pluga_api_token: string | null
  contaazul_client_id: string | null
  contaazul_client_secret: string | null
  tiny_api_token: string | null
  google_client_id: string | null
  google_client_secret: string | null
  telegram_bot_token: string | null
  whatsapp_numero: string | null
  whatsapp_apikey: string | null
  whatsapp_extras: string | null
  notificar_equipe_whatsapp?: boolean
  integracoes_ativas?: string | null
  canal_avisos?: string | null
  evolution_url: string | null
  evolution_instance: string | null
  evolution_apikey: string | null
}

/* Catálogo de integrações da tela.

   `padrao` é o que aparece numa conta que nunca escolheu nada: as que a
   Controllares usa hoje. O resto começa guardado — estão escritas no sistema,
   mas não são de todo mundo. */
const INTEGRACOES: { id: string; nome: string; desc: string; padrao: boolean }[] = [
  { id: "olist",     nome: "Olist ERP",        desc: "Pedidos, catálogo, estoque e notas", padrao: true },
  { id: "telegram",  nome: "Telegram",         desc: "Avisos de proposta e grupos de obra", padrao: true },
  { id: "whatsapp",  nome: "WhatsApp",         desc: "Avisos por CallMeBot ou Evolution",  padrao: true },
  { id: "drive",     nome: "Google Drive",     desc: "Backups e base de conhecimento",     padrao: true },
  { id: "calendar",  nome: "Google Calendar",  desc: "Agendamentos de obra",               padrao: true },
  { id: "plaud",     nome: "Plaud",            desc: "Transcrição de reuniões",            padrao: false },
  { id: "pluga",     nome: "Pluga.co",         desc: "Automações entre sistemas",          padrao: false },
  { id: "contaazul", nome: "ContaAzul",        desc: "Financeiro e emissão fiscal",        padrao: false },
]
const INTEGRACOES_PADRAO = INTEGRACOES.filter(i => i.padrao).map(i => i.id)

const EMPTY_USER_FORM = { nome: "", email: "", senha: "", role: "VENDEDOR" as Role, roles: [] as Role[] }

// ============================================================
// Campo de texto reutilizável
// ============================================================
/**
 * Miolo de configuração que fica fechado até alguém precisar dele.
 *
 * Integração se configura uma vez e se usa todo dia. Deixar token, sincronismo
 * e opções sempre abertos faz a aba inteira virar rolagem, e o que importa no
 * dia a dia — se está conectado — some no meio. Fechado, o cabeçalho de cada
 * integração continua visível e o resto sai da frente.
 */
function Recolhivel({ titulo, children, resumo }: {
  titulo: string
  children: React.ReactNode
  /** Uma linha visível mesmo fechado, quando há algo que não pode esperar. */
  resumo?: string
}) {
  const [aberto, setAberto] = useState(false)
  return (
    <div className="rounded-xl border border-hairline bg-surface-1">
      <button type="button" onClick={() => setAberto(a => !a)}
        className="flex w-full items-center justify-between gap-3 px-4 py-2.5 text-left">
        <span className="min-w-0">
          <span className="block text-[13px] text-foreground">{titulo}</span>
          {!!resumo && !aberto && (
            <span className="block text-[12px] text-muted-foreground">{resumo}</span>
          )}
        </span>
        <ChevronDown className={`h-4 w-4 shrink-0 text-muted-foreground transition-transform ${aberto ? "rotate-180" : ""}`} />
      </button>
      {aberto && <div className="space-y-4 border-t border-hairline p-4">{children}</div>}
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-xs text-muted-foreground mb-1 block">{label}</label>
      {children}
    </div>
  )
}

function TextInput({ value, onChange, placeholder, disabled, type = "text" }: {
  value: string; onChange?: (v: string) => void
  placeholder?: string; disabled?: boolean; type?: string
}) {
  return (
    <input
      type={type}
      value={value}
      onChange={e => onChange?.(e.target.value)}
      placeholder={placeholder}
      disabled={disabled}
      className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30 disabled:opacity-40"
    />
  )
}

// ============================================================
// Página principal
// ============================================================
export default function ConfiguracoesPage() {
  const confirmar = useConfirmar()
  // ---- Usuários ----
  const [usuarios, setUsuarios] = useState<Usuario[]>([])
  const [loadingUsers, setLoadingUsers] = useState(true)
  const [userOpen, setUserOpen] = useState(false)
  const [editUserId, setEditUserId] = useState<string | null>(null)
  const [userForm, setUserForm] = useState({ ...EMPTY_USER_FORM })
  const [showSenha, setShowSenha] = useState(false)
  const [savingUser, setSavingUser] = useState(false)
  const [deletingId, setDeletingId] = useState<string | null>(null)
  const [userErro, setUserErro] = useState("")

  // ---- Convites de colaborador ----
  const [convites, setConvites] = useState<{ id: string; email: string; role: string; token: string; expiresAt: string; usedAt?: string | null }[]>([])
  const [convEmail, setConvEmail] = useState("")
  const [convRole, setConvRole] = useState("VENDEDOR")
  const [avisoAdmin, setAvisoAdmin] = useState(false)
  const [convErro, setConvErro] = useState("")
  const [convEnviando, setConvEnviando] = useState(false)
  const [convLinkCopiado, setConvLinkCopiado] = useState<string | null>(null)

  const loadConvites = useCallback(async () => {
    const r = await fetch("/api/usuarios/convites")
    if (r.ok) setConvites((await r.json()).invites || [])
  }, [])

  async function criarConvite() {
    setConvErro(""); setConvEnviando(true)
    try {
      const r = await fetch("/api/usuarios/convites", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: convEmail, role: convRole }),
      })
      const j = await r.json()
      if (!r.ok) { setConvErro(j.error || "Erro ao criar convite."); return }
      setConvEmail("")
      await navigator.clipboard.writeText(j.link).catch(() => {})
      setConvLinkCopiado(j.emailEnviado ? "E-mail enviado! Link também copiado." : "Link copiado, envie ao colaborador.")
      setTimeout(() => setConvLinkCopiado(null), 5000)
      loadConvites()
    } finally { setConvEnviando(false) }
  }

  function copiarLinkConvite(token: string) {
    const link = `${location.origin}/convite/${token}`
    navigator.clipboard.writeText(link).catch(() => {})
    setConvLinkCopiado("Link copiado!")
    setTimeout(() => setConvLinkCopiado(null), 3000)
  }

  // ---- 2FA (conta do ADMIN logado) ----
  const [tfaEnabled, setTfaEnabled] = useState<boolean | null>(null)
  const [tfaQr, setTfaQr] = useState<string | null>(null)
  const [tfaCodigo, setTfaCodigo] = useState("")
  const [tfaErro, setTfaErro] = useState("")
  const [tfaBusy, setTfaBusy] = useState(false)
  const [tfaDesativando, setTfaDesativando] = useState(false)

  useEffect(() => {
    fetch("/api/auth/2fa/setup").then(r => r.ok ? r.json() : null)
      .then(d => { if (d) setTfaEnabled(!!d.enabled) })
  }, [])

  async function tfaIniciar() {
    setTfaErro(""); setTfaBusy(true)
    try {
      const r = await fetch("/api/auth/2fa/setup", { method: "POST" })
      const j = await r.json()
      if (!r.ok) { setTfaErro(j.error || "Erro ao iniciar 2FA."); return }
      setTfaQr(j.qr); setTfaCodigo("")
    } finally { setTfaBusy(false) }
  }

  async function tfaConfirmar() {
    setTfaErro(""); setTfaBusy(true)
    try {
      const r = await fetch("/api/auth/2fa/confirm", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ codigo: tfaCodigo }),
      })
      const j = await r.json()
      if (!r.ok) { setTfaErro(j.error || "Código inválido."); return }
      setTfaEnabled(true); setTfaQr(null); setTfaCodigo("")
    } finally { setTfaBusy(false) }
  }

  async function tfaDesativar() {
    setTfaErro(""); setTfaBusy(true)
    try {
      const r = await fetch("/api/auth/2fa/disable", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ codigo: tfaCodigo }),
      })
      const j = await r.json()
      if (!r.ok) { setTfaErro(j.error || "Código inválido."); return }
      setTfaEnabled(false); setTfaDesativando(false); setTfaCodigo("")
    } finally { setTfaBusy(false) }
  }

  // ---- Empresa ----
  const [empresa, setEmpresa] = useState<Empresa | null>(null)
  const [empresaForm, setEmpresaForm] = useState({
    nome_empresa: "", cnpj_cpf: "", endereco_base: "", email_contato: "", telefone_contato: "",
    desconto_maximo: "10",
  })
  const [savingEmpresa, setSavingEmpresa] = useState(false)
  const [empresaSaved, setEmpresaSaved] = useState(false)
  const [aba, setAba] = useState<string | null>(null)

  // ---- Espelho do catálogo no Olist ----
  const [catalogo, setCatalogo] = useState<{ nossos: number; noOlist: number; faltando: number } | null>(null)
  const [conferindoCatalogo, setConferindoCatalogo] = useState(false)
  const [enviandoCatalogo, setEnviandoCatalogo] = useState(false)
  const [enviadosCatalogo, setEnviadosCatalogo] = useState(0)
  const [erroCatalogo, setErroCatalogo] = useState("")

  const [enviandoEstoque, setEnviandoEstoque] = useState(false)
  const [erroEstoque, setErroEstoque] = useState("")
  const [resultadoEstoque, setResultadoEstoque] = useState<
    { enviados: unknown[]; semCadastro: string[]; falhas: { sku: string; erro: string }[] } | null
  >(null)

  async function enviarEstoque() {
    setEnviandoEstoque(true); setErroEstoque(""); setResultadoEstoque(null)
    try {
      const r = await fetch("/api/integracoes/olist/estoque", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      })
      const j = await r.json()
      if (!r.ok) { setErroEstoque(j.error || "Não foi possível espelhar o saldo."); return }
      setResultadoEstoque(j)
      if (j.falhas?.length) {
        setErroEstoque(`${j.falhas.length} falha(s). Primeira: ${j.falhas[0].sku}, ${j.falhas[0].erro}`)
      }
    } catch { setErroEstoque("Falha de conexão ao espelhar o saldo.") }
    finally { setEnviandoEstoque(false) }
  }

  async function conferirCatalogo() {
    setConferindoCatalogo(true); setErroCatalogo("")
    try {
      const r = await fetch("/api/integracoes/olist/catalogo", { cache: "no-store" })
      const j = await r.json()
      if (!r.ok) { setErroCatalogo(j.error || "Não foi possível conferir."); return }
      setCatalogo(j)
    } catch { setErroCatalogo("Falha de conexão ao conferir o catálogo.") }
    finally { setConferindoCatalogo(false) }
  }

  /* Envia em lotes até acabar. A v2 aceita um produto por requisição e o
     catálogo tem centenas: numa chamada só o tempo da função estouraria. */
  async function enviarCatalogo() {
    setEnviandoCatalogo(true); setErroCatalogo(""); setEnviadosCatalogo(0)
    try {
      let restantes = 1
      let enviados = 0
      while (restantes > 0) {
        const r = await fetch("/api/integracoes/olist/catalogo", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ lote: 20 }),
        })
        const j = await r.json()
        if (!r.ok) { setErroCatalogo(j.error || "Falha ao enviar."); break }
        enviados += (j.criados?.length ?? 0)
        setEnviadosCatalogo(enviados)
        if (j.falhas?.length) {
          setErroCatalogo(`${j.falhas.length} falha(s). Primeira: ${j.falhas[0].sku}, ${j.falhas[0].erro}`)
        }
        // Nada criado e nada restando: para, para não repetir à toa.
        if (!j.criados?.length && !j.restantes) break
        restantes = j.restantes ?? 0
        /* Respiro entre lotes: o teto do Olist é por minuto, não por chamada.
           Se veio bloqueio, espera o minuto virar antes de tentar de novo —
           insistir em seguida só prolonga o bloqueio. */
        if (restantes > 0) await new Promise(r => setTimeout(r, j.bloqueado ? 60_000 : 3_000))
      }
      await conferirCatalogo()
    } catch { setErroCatalogo("Falha de conexão ao enviar o catálogo.") }
    finally { setEnviandoCatalogo(false) }
  }
  /* Kits e fornecedores seguem o mesmo desenho do catálogo: conferir antes de
     enviar, e enviar em lotes. O que muda é só a rota e o rótulo. */
  type ResumoEspelho = { nossos: number; faltando: number; aviso?: string | null }
  const [kits, setKits] = useState<ResumoEspelho | null>(null)
  const [fornecedores, setFornecedores] = useState<ResumoEspelho | null>(null)
  const [ocupado, setOcupado] = useState("")
  const [erroEspelho, setErroEspelho] = useState("")

  async function conferirEspelho(rota: "kits" | "fornecedores") {
    setOcupado(`conferir-${rota}`); setErroEspelho("")
    try {
      const r = await fetch(`/api/integracoes/olist/${rota}`, { cache: "no-store" })
      const j = await r.json()
      if (!r.ok) { setErroEspelho(j.error || "Não foi possível conferir."); return }
      if (rota === "kits") setKits(j); else setFornecedores(j)
    } catch { setErroEspelho("Falha de conexão ao conferir.") }
    finally { setOcupado("") }
  }

  async function enviarEspelho(rota: "kits" | "fornecedores") {
    setOcupado(`enviar-${rota}`); setErroEspelho("")
    try {
      let restantes = 1
      while (restantes > 0) {
        const r = await fetch(`/api/integracoes/olist/${rota}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ lote: rota === "kits" ? 10 : 20 }),
        })
        const j = await r.json()
        if (!r.ok) { setErroEspelho(j.error || "Falha ao enviar."); break }
        if (j.falhas?.length) {
          const f = j.falhas[0]
          setErroEspelho(`${j.falhas.length} falha(s). Primeira: ${f.kit ?? f.nome}, ${f.erro}`)
        }
        if (!j.criados?.length && !j.restantes) break
        restantes = j.restantes ?? 0
        // Bloqueio é por minuto: insistir em seguida só prolonga.
        if (restantes > 0) await new Promise(x => setTimeout(x, j.bloqueado ? 60_000 : 3_000))
      }
      await conferirEspelho(rota)
    } catch { setErroEspelho("Falha de conexão ao enviar.") }
    finally { setOcupado("") }
  }

  /* Painel de segurança. Só o Admin: a lista mostra o que ainda falta, e é
     exatamente o mapa que alguém de fora usaria para saber por onde entrar. */
  type ItemSeguranca = {
    chave: string; titulo: string; detalhe: string
    estado: "ok" | "atencao" | "falta" | "externo"
    evidencia: string; acao?: string
  }
  const [ehAdmin, setEhAdmin] = useState(false)
  const [seguranca, setSeguranca] = useState<ItemSeguranca[] | null>(null)
  const [medidoEm, setMedidoEm] = useState("")
  const [carregandoSeg, setCarregandoSeg] = useState(false)
  const [erroSeg, setErroSeg] = useState("")

  useEffect(() => {
    fetch("/api/auth/me")
      .then(r => r.ok ? r.json() : null)
      .then(d => setEhAdmin(d?.user?.role === "ADMIN"))
      .catch(() => {})
  }, [])

  const carregarSeguranca = useCallback(async () => {
    setCarregandoSeg(true); setErroSeg("")
    try {
      const r = await fetch("/api/seguranca/status", { cache: "no-store" })
      const j = await r.json()
      if (!r.ok) { setErroSeg(j.error || "Não foi possível medir agora."); return }
      setSeguranca(j.itens); setMedidoEm(j.medidoEm)
    } catch { setErroSeg("Falha de conexão ao medir.") }
    finally { setCarregandoSeg(false) }
  }, [])

  // Mede ao abrir a aba, não ao carregar a página: a checagem faz uma
  // requisição ao próprio site e não vale pagar isso em toda visita.
  /* Segunda porta do painel. Ser Admin não basta: o código do autenticador é
     pedido na hora de entrar, porque o risco real é a sessão do Admin já aberta
     numa máquina com o técnico do lado. */
  const [liberado, setLiberado] = useState(false)
  const [temSegundoFator, setTemSegundoFator] = useState(true)
  const [codigoSistema, setCodigoSistema] = useState("")
  const [erroPorta, setErroPorta] = useState("")
  const [abrindoPorta, setAbrindoPorta] = useState(false)

  type Anomalia = { chave: string; titulo: string; gravidade: string; detalhe: string; ocorrencias: number }
  type Evento = {
    id: string; tipo: string; gravidade: string; descricao: string
    email: string | null; ip: string | null; rota: string | null; createdAt: string
  }
  type Vigia = {
    anomalias: Anomalia[]
    lugaresNovos: { email: string; ip: string; quando: string; agente: string }[]
    eventos: Evento[]
    contasEstranhas: { id: string; nome: string; email: string; role: string; status: string }[]
    bloqueios: { chave: string; tentativas: number; bloqueadoAte: string }[]
  }
  const [vigia, setVigia] = useState<Vigia | null>(null)
  const [carregandoVigia, setCarregandoVigia] = useState(false)

  const conferirPorta = useCallback(async () => {
    const r = await fetch("/api/sistema/acesso", { cache: "no-store" })
    if (!r.ok) return
    const j = await r.json()
    setLiberado(!!j.liberado)
    setTemSegundoFator(!!j.temSegundoFator)
  }, [])

  async function abrirPorta() {
    setAbrindoPorta(true); setErroPorta("")
    try {
      const r = await fetch("/api/sistema/acesso", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ codigo: codigoSistema }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) {
        setErroPorta(j.error || "Não foi possível entrar.")
        if (j.faltaSegundoFator) setTemSegundoFator(false)
        return
      }
      setCodigoSistema(""); setLiberado(true)
    } catch { setErroPorta("Falha de conexão.") }
    finally { setAbrindoPorta(false) }
  }

  async function sairDoPainel() {
    await fetch("/api/sistema/acesso", { method: "DELETE" }).catch(() => {})
    setLiberado(false); setVigia(null); setSeguranca(null)
  }

  const carregarVigia = useCallback(async () => {
    setCarregandoVigia(true)
    try {
      const r = await fetch("/api/sistema/vigia", { cache: "no-store" })
      if (r.status === 401) { setLiberado(false); return }
      if (!r.ok) return
      setVigia(await r.json())
    } catch { /* a tela mostra o que já tem */ }
    finally { setCarregandoVigia(false) }
  }, [])

  useEffect(() => {
    if (aba === "sistema" && ehAdmin) conferirPorta()
  }, [aba, ehAdmin, conferirPorta])

  useEffect(() => {
    if (aba === "sistema" && liberado && !seguranca) carregarSeguranca()
    if (aba === "sistema" && liberado && !vigia) carregarVigia()
  }, [aba, liberado, seguranca, vigia, carregarSeguranca, carregarVigia])

  /* Enriquecimento do catálogo. Fica na aba Sistema porque gasta cota de busca
     e reescreve campo de produto — não é operação de rotina. */
  type EstadoFicha = {
    total: number; pendentes: number; encontradas: number; semFonte: number
    marcas: { marca: string; pendentes: number }[]
  }
  const [ficha, setFicha] = useState<EstadoFicha | null>(null)
  const [enriquecendo, setEnriquecendo] = useState(false)
  const [progressoFicha, setProgressoFicha] = useState("")
  const [erroFicha, setErroFicha] = useState("")

  const conferirFichas = useCallback(async () => {
    setErroFicha("")
    try {
      const r = await fetch("/api/catalogo/enriquecer", { cache: "no-store" })
      const j = await r.json()
      if (!r.ok) { setErroFicha(j.error || "Não foi possível conferir."); return }
      setFicha(j)
    } catch { setErroFicha("Falha de conexão.") }
  }, [])

  /* Roda em lotes até a fila esvaziar. Cada produto custa uma busca web mais
     uma chamada ao modelo, então o lote é pequeno e a aba precisa ficar
     aberta — mesmo desenho do espelho do catálogo no Olist. */
  async function enriquecerFichas() {
    setEnriquecendo(true); setErroFicha(""); setProgressoFicha("")
    try {
      let achadas = 0, sem = 0, restam = 1
      while (restam > 0) {
        const r = await fetch("/api/catalogo/enriquecer", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ tamanho: 8 }),
        })
        const j = await r.json()
        if (!r.ok) { setErroFicha(j.error || "Falha ao enriquecer."); break }
        achadas += j.encontrados ?? 0
        sem += j.semFonte ?? 0
        restam = j.restantes ?? 0
        setProgressoFicha(`${achadas} com ficha · ${sem} sem fonte · ${restam} na fila`)
        if (!j.processados) break
        await new Promise(x => setTimeout(x, 1500))
      }
      await conferirFichas()
    } catch { setErroFicha("Falha de conexão.") }
    finally { setEnriquecendo(false) }
  }

  useEffect(() => {
    if (aba === "sistema" && liberado && !ficha) conferirFichas()
  }, [aba, liberado, ficha, conferirFichas])

  /* Plaud — a conta do gravador de reunião.
     A conexão é por consentimento no navegador, como a do Google: o token
     alcança toda a conta Plaud, e isso é conversa gravada dentro da casa de
     cliente. Quem autoriza precisa ver o que está autorizando. */
  const [plaud, setPlaud] = useState<{
    configurado: boolean; conectado: boolean
    expiraEm: string | null; ultimoSync: string | null; reunioes: number
  } | null>(null)

  const carregarPlaud = useCallback(async () => {
    try {
      const r = await fetch("/api/integracoes/plaud/status", { cache: "no-store" })
      if (r.ok) setPlaud(await r.json())
    } catch { /* a tela mostra o estado anterior */ }
  }, [])

  useEffect(() => { if (aba === "integracoes") carregarPlaud() }, [aba, carregarPlaud])

  /* Google Drive — onde a cópia do sistema vai parar.
     Fica no Drive da empresa, e não em outra pasta do mesmo fornecedor que
     hospeda o sistema: backup que mora junto com o que ele protege é cópia. */
  const [drive, setDrive] = useState<{
    conectado: boolean; pasta: string | null
    conectadoEm: string | null; ultimoEnvio: string | null
  } | null>(null)
  const [driveOcupado, setDriveOcupado] = useState(false)
  const [driveAviso, setDriveAviso] = useState("")

  const carregarDrive = useCallback(async () => {
    try {
      const r = await fetch("/api/integracoes/google/drive", { cache: "no-store" })
      if (r.ok) setDrive(await r.json())
    } catch { /* a tela mostra o estado anterior */ }
  }, [])

  useEffect(() => { if (aba === "integracoes") carregarDrive() }, [aba, carregarDrive])

  /* O retorno do consentimento volta pela URL — é o Google que redireciona, e
     a tela precisa dizer o que aconteceu sem que ninguém recarregue. */
  useEffect(() => {
    const estado = new URLSearchParams(window.location.search).get("drive")
    if (!estado) return
    const mensagens: Record<string, string> = {
      ok: "Drive conectado. A pasta de backups foi criada.",
      cancelado: "Autorização cancelada.",
      "sem-refresh": "O Google não devolveu acesso permanente. Revogue o app na conta Google e conecte de novo.",
      "sem-credencial": "Faltam Client ID e Secret do Google nesta tela.",
      "pasta-erro": "Autorizou, mas não deu para criar a pasta. Confira se a Google Drive API está habilitada.",
      "token-erro": "O Google recusou a troca de credenciais.",
      erro: "Não foi possível conectar.",
    }
    setDriveAviso(mensagens[estado] ?? "")
    carregarDrive()
    window.history.replaceState({}, "", window.location.pathname)
  }, [carregarDrive])

  async function acaoDrive(acao: "autorizar" | "testar" | "limpar") {
    setDriveOcupado(true); setDriveAviso("")
    try {
      const r = await fetch("/api/integracoes/google/drive", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ acao }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { setDriveAviso(j.error ?? "Não foi possível."); return }
      if (acao === "autorizar" && j.url) { window.location.href = j.url; return }
      if (acao === "testar") setDriveAviso("Arquivo de teste enviado para a pasta.")
      if (acao === "limpar") setDriveAviso(`${j.apagados} backup(s) antigo(s) removido(s).`)
      await carregarDrive()
    } catch { setDriveAviso("Falha de conexão.") }
    finally { setDriveOcupado(false) }
  }

  async function desconectarDrive() {
    const ok = await confirmar({
      titulo: "Desconectar o Drive?",
      texto: "Os backups já enviados continuam lá. O sistema só deixa de mandar novos.",
      confirmar: "Desconectar", perigo: true,
    })
    if (!ok) return
    setDriveOcupado(true); setDriveAviso("")
    try {
      const r = await fetch("/api/integracoes/google/drive", { method: "DELETE" })
      if (!r.ok) { setDriveAviso("Não foi possível desconectar."); return }
      await carregarDrive()
    } catch { setDriveAviso("Falha de conexão.") }
    finally { setDriveOcupado(false) }
  }

  /* Números extras do WhatsApp. Ficam como lista na tela e viram JSON no
     salvar — o banco guarda texto, mas editar JSON à mão numa caixa é o tipo
     de campo em que uma vírgula perdida derruba a notificação inteira. */
  const [extrasWpp, setExtrasWpp] = useState<{ numero: string; apikey?: string; nome?: string }[]>([])
  /* O número de cada pessoa da equipe vem do perfil dela, editável só por
     ela e invisível aqui. Sem esta chave o admin via aviso saindo para um
     telefone que não tinha como enxergar nem desligar. */
  const [notificarEquipe, setNotificarEquipe] = useState(true)

  /* Quais integrações aparecem na lista principal.

     A tela mostrava tudo o que já foi escrito para o sistema — Pluga,
     ContaAzul, Plaud — mesmo em empresa que nunca vai usar nenhum. Quem
     precisa do Olist rolava por seis cartões que não lhe dizem respeito.
     Ligar aqui é organização de TELA: o desligado some da lista e continua na
     gaveta "Adicionar integração". Nada para de funcionar por isto — desligar
     por engano não pode cortar o envio de pedido de ninguém. */
  const [integracoesAtivas, setIntegracoesAtivas] = useState<string[]>([])
  const [gaveta, setGaveta] = useState(false)
  /* Por onde os avisos saem. O WhatsApp gratuito tem cota por número e para
     de entregar sem avisar; o Telegram não tem cota. Ligar os dois faz a
     mesma pessoa receber duas vezes — caminho curto para silenciar tudo. */
  const [canalAvisos, setCanalAvisos] = useState("TELEGRAM")


  const [tokensPlaud, setTokensPlaud] = useState("")
  const [conectandoPlaud, setConectandoPlaud] = useState(false)
  const [erroPlaud, setErroPlaud] = useState("")
  const [buscandoPlaud, setBuscandoPlaud] = useState(false)
  const [resultadoPlaud, setResultadoPlaud] = useState("")

  /* Conectar é colar o arquivo que `plaud login` gera. Não é OAuth porque não
     pode ser: a plataforma que lê as gravações pessoais não emite credencial
     para aplicações de terceiros — a registrada é a do próprio CLI. */
  async function conectarPlaud() {
    setConectandoPlaud(true); setErroPlaud("")
    try {
      const r = await fetch("/api/integracoes/plaud/conectar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tokens: tokensPlaud }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { setErroPlaud(j.error || "Não foi possível conectar."); return }
      setTokensPlaud("")
      await carregarPlaud()
    } catch { setErroPlaud("Falha de conexão.") }
    finally { setConectandoPlaud(false) }
  }

  async function buscarReunioes() {
    setBuscandoPlaud(true); setResultadoPlaud(""); setErroPlaud("")
    try {
      const r = await fetch("/api/integracoes/plaud/sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ forcar: true }),
      })
      const j = await r.json()
      if (!r.ok || j.erro) { setErroPlaud(j.erro || j.error || "Falha ao buscar."); return }
      setResultadoPlaud(
        `${j.novas} nova(s)` +
        (j.semTranscricao ? ` · ${j.semTranscricao} ainda sendo transcrita(s) pelo Plaud` : "") +
        (j.jaTinha ? ` · ${j.jaTinha} já baixada(s)` : ""))
      await carregarPlaud()
    } catch { setErroPlaud("Falha de conexão.") }
    finally { setBuscandoPlaud(false) }
  }

  async function desconectarPlaud() {
    if (!await confirmar({ titulo: "Desconectar o Plaud? O acesso é revogado também do lado do Plaud."
      + " As reuniões já baixadas continuam aqui.", perigo: true })) return
    await fetch("/api/integracoes/plaud/status", { method: "DELETE" }).catch(() => {})
    await carregarPlaud()
  }

  const [uploadingLogo, setUploadingLogo] = useState(false)
  const [logoErro, setLogoErro] = useState("")

  // ---- Integrações ----
  const [integForm, setIntegForm] = useState({
    pluga_api_token: "", contaazul_client_id: "", contaazul_client_secret: "",
    tiny_api_token: "", google_client_id: "", google_client_secret: "", telegram_bot_token: "",
    whatsapp_numero: "", whatsapp_apikey: "", whatsapp_extras: "",
    evolution_url: "", evolution_instance: "", evolution_apikey: "",
  })
  const [testandoWpp, setTestandoWpp] = useState(false)
  const [savingInteg, setSavingInteg] = useState(false)
  const [integSaved, setIntegSaved] = useState(false)
  const [showSecrets, setShowSecrets] = useState(false)
  const [googleStatus, setGoogleStatus] = useState<{ conectado: boolean; expirado: boolean } | null>(null)
  const [loadingGoogleStatus, setLoadingGoogleStatus] = useState(false)
  const [olistStatus, setOlistStatus] = useState<{ conectado: boolean; expirado: boolean } | null>(null)

  /* Estas ajudantes ficam DEPOIS de `integForm` e `olistStatus` de propósito.
     Elas leem os dois durante a renderização, e declaradas acima o React
     avaliava `guardadas` antes de os estados existirem — a página inteira de
     Configurações morria com "Cannot access before initialization" e o
     navegador só mostrava "This page couldn't load". */
  /* Uma integração JÁ CONFIGURADA nunca some da tela, mesmo desligada na
     lista. Esconder o que está em uso é como quebrá-la: quem precisasse
     ajustar o token não acharia onde. */
  function integracaoConfigurada(id: string): boolean {
    switch (id) {
      case "olist":     return !!integForm.tiny_api_token || !!olistStatus?.conectado
      case "telegram":  return !!integForm.telegram_bot_token
      case "whatsapp":  return !!integForm.whatsapp_numero || !!integForm.evolution_url
      case "drive":     return !!integForm.google_client_id
      case "calendar":  return !!integForm.google_client_id
      case "pluga":     return !!integForm.pluga_api_token
      case "contaazul": return !!integForm.contaazul_client_id
      default:          return false
    }
  }
  const mostrarIntegracao = (id: string) =>
    integracoesAtivas.includes(id) || integracaoConfigurada(id)

  const guardadas = INTEGRACOES.filter(i => !mostrarIntegracao(i.id))

  async function ligarIntegracao(id: string) {
    const novas = [...integracoesAtivas, id]
    setIntegracoesAtivas(novas)
    await fetch("/api/empresa", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ integracoes_ativas: JSON.stringify(novas) }),
    }).catch(() => {})
  }

  async function desligarIntegracao(id: string) {
    const novas = integracoesAtivas.filter(x => x !== id)
    setIntegracoesAtivas(novas)
    await fetch("/api/empresa", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ integracoes_ativas: JSON.stringify(novas) }),
    }).catch(() => {})
  }
  const [vaultConfigured, setVaultConfigured] = useState<Record<string, boolean>>({})
  const [vaultForm, setVaultForm] = useState<Record<string, string>>({})
  const [savingVault, setSavingVault] = useState<Record<string, boolean>>({})
  const [vaultSaved, setVaultSaved] = useState<Record<string, boolean>>({})

  // ============================================================
  // Loaders
  // ============================================================
  const loadUsers = useCallback(async () => {
    setLoadingUsers(true)
    try {
      const res = await fetch("/api/usuarios")
      if (res.ok) setUsuarios((await res.json()).users)
    } finally {
      setLoadingUsers(false)
    }
  }, [])

  const loadEmpresa = useCallback(async () => {
    const res = await fetch("/api/empresa")
    if (res.ok) {
      const data: Empresa = await res.json()
      setEmpresa(data)
      setEmpresaForm({
        nome_empresa: data.nome_empresa,
        cnpj_cpf: data.cnpj_cpf,
        endereco_base: data.endereco_base ?? "",
        email_contato: data.email_contato ?? "",
        telefone_contato: data.telefone_contato ?? "",
        desconto_maximo: String(data.desconto_maximo ?? 10),
      })
      setIntegForm({
        pluga_api_token: data.pluga_api_token ?? "",
        contaazul_client_id: data.contaazul_client_id ?? "",
        contaazul_client_secret: data.contaazul_client_secret ?? "",
        tiny_api_token: data.tiny_api_token ?? "",
        google_client_id: data.google_client_id ?? "",
        google_client_secret: data.google_client_secret ?? "",
        telegram_bot_token: data.telegram_bot_token ?? "",
        whatsapp_numero: data.whatsapp_numero ?? "",
        whatsapp_apikey: data.whatsapp_apikey ?? "",
        whatsapp_extras: data.whatsapp_extras ?? "",
        evolution_url: data.evolution_url ?? "",
        evolution_instance: data.evolution_instance ?? "",
        evolution_apikey: data.evolution_apikey ?? "",
      })
      setNotificarEquipe(data.notificar_equipe_whatsapp !== false)
      setCanalAvisos(data.canal_avisos ?? "TELEGRAM")
      try {
        const lista = JSON.parse(data.integracoes_ativas ?? "null")
        // Conta sem escolha feita vê o conjunto padrão, não uma tela vazia.
        setIntegracoesAtivas(Array.isArray(lista) ? lista : INTEGRACOES_PADRAO)
      } catch { setIntegracoesAtivas(INTEGRACOES_PADRAO) }
      try {
        const lista = JSON.parse(data.whatsapp_extras ?? "[]")
        if (Array.isArray(lista)) setExtrasWpp(lista)
      } catch { /* texto inválido: começa vazio em vez de quebrar a tela */ }
    }
  }, [])

  async function loadGoogleStatus() {
    setLoadingGoogleStatus(true)
    try {
      const res = await fetch("/api/integracoes/google/status")
      if (res.ok) setGoogleStatus(await res.json())
    } finally {
      setLoadingGoogleStatus(false)
    }
  }

  async function desconectarGoogle() {
    await fetch("/api/integracoes/google/sync-obra/noop", { method: "DELETE" })
    loadGoogleStatus()
  }

  async function loadOlistStatus() {
    const res = await fetch("/api/integracoes/olist/status")
    if (res.ok) setOlistStatus(await res.json())
  }

  async function desconectarOlist() {
    await fetch("/api/integracoes/olist/status", { method: "DELETE" })
    loadOlistStatus()
  }

  useEffect(() => {
    loadUsers()
    loadConvites()
    loadEmpresa()
    loadGoogleStatus()
    loadOlistStatus()
    fetch("/api/empresa/vault").then(r => r.ok ? r.json() : null).then(d => { if (d) setVaultConfigured(d.configured ?? {}) })
    // Checa parâmetro de retorno do OAuth
    const params = new URLSearchParams(window.location.search)
    const googleParam = params.get("google")
    if (googleParam === "conectado") {
      setIntegSaved(true)
      setTimeout(() => setIntegSaved(false), 4000)
      loadGoogleStatus()
      window.history.replaceState({}, "", "/configuracoes")
    }
    const olistParam = params.get("olist")
    if (olistParam === "conectado") {
      setIntegSaved(true)
      setTimeout(() => setIntegSaved(false), 4000)
      loadOlistStatus()
      window.history.replaceState({}, "", "/configuracoes")
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loadUsers, loadEmpresa])

  // ============================================================
  // Usuários
  // ============================================================
  function abrirNovoUser() {
    setEditUserId(null)
    setUserForm({ ...EMPTY_USER_FORM })
    setUserErro("")
    setUserOpen(true)
  }

  function abrirEdicaoUser(u: Usuario) {
    setEditUserId(u.id)
    setUserForm({ nome: u.nome, email: u.email, senha: "", role: u.role, roles: u.roles ?? [] })
    setUserErro("")
    setUserOpen(true)
  }

  async function salvarUser() {
    setUserErro("")
    if (!editUserId) return // criação é só por convite (colaborador cria a senha)
    if (!userForm.nome.trim()) {
      setUserErro("Nome é obrigatório.")
      return
    }
    setSavingUser(true)
    try {
      // Admin nunca altera senha: só nome, perfil principal e perfis extras.
      const body = { nome: userForm.nome, role: userForm.role, roles: userForm.roles }
      const res = await fetch(`/api/usuarios/${editUserId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      })
      const data = await res.json()
      if (!res.ok) { setUserErro(data.error || "Erro ao salvar."); return }
      setUserOpen(false)
      loadUsers()
    } finally {
      setSavingUser(false)
    }
  }

  async function excluirUser(id: string) {
    setDeletingId(id)
    try {
      await fetch(`/api/usuarios/${id}`, { method: "DELETE" })
      loadUsers()
    } finally {
      setDeletingId(null)
    }
  }

  // ============================================================
  // Empresa
  // ============================================================
  async function salvarEmpresa() {
    setSavingEmpresa(true)
    try {
      const res = await fetch("/api/empresa", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...empresaForm,
          desconto_maximo: Number(empresaForm.desconto_maximo),
        }),
      })
      if (res.ok) {
        setEmpresaSaved(true)
        setTimeout(() => setEmpresaSaved(false), 3000)
        loadEmpresa()
      }
    } finally {
      setSavingEmpresa(false)
    }
  }

  /** @param campo qual marca está sendo trocada — a do sistema ou a dos documentos. */
  async function uploadLogo(file: File, campo: "logo_url" | "logo_proposta_url" = "logo_url") {
    setUploadingLogo(true)
    setLogoErro("")
    try {
      const fd = new FormData()
      fd.append("file", file)
      // inline=1: o logo vira data URI e passa a abrir em qualquer lugar
      // (link do cliente, PDF, e-mail) sem depender do token do Blob.
      const res = await fetch("/api/upload?inline=1", { method: "POST", body: fd })
      if (!res.ok) {
        // O erro era engolido aqui: a barra sumia e nada acontecia, sem pista
        // nenhuma do motivo.
        const j = await res.json().catch(() => ({}))
        setLogoErro(j.error || `Falha ao enviar (HTTP ${res.status}).`)
        return
      }
      const { url } = await res.json()
      const salvou = await fetch("/api/empresa", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ [campo]: url }),
      })
      if (!salvou.ok) { setLogoErro("Imagem enviada, mas não foi possível salvar."); return }
      loadEmpresa()
    } catch {
      setLogoErro("Falha de conexão ao enviar a imagem.")
    } finally {
      setUploadingLogo(false)
    }
  }

  async function removerLogo(campo: "logo_url" | "logo_proposta_url" = "logo_url") {
    // Sem confirmação, um clique no X apagava o logo direto — foi o que
    // aconteceu com o logo oficial. Agora pede confirmação antes.
    const alvo = campo === "logo_url" ? "do sistema" : "das propostas e contratos"
    if (!await confirmar({ titulo: `Remover o logo ${alvo}?`, perigo: true })) return
    await fetch("/api/empresa", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ [campo]: "" }),
    })
    loadEmpresa()
  }

  // ============================================================
  // Integrações
  // ============================================================
  async function salvarVault(role: string) {
    const senha = vaultForm[role]?.trim()
    if (!senha || senha.length < 4) return
    setSavingVault(v => ({ ...v, [role]: true }))
    try {
      const res = await fetch("/api/empresa/vault", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role, senha }),
      })
      if (res.ok) {
        setVaultConfigured(v => ({ ...v, [role]: true }))
        setVaultForm(f => ({ ...f, [role]: "" }))
        setVaultSaved(v => ({ ...v, [role]: true }))
        setTimeout(() => setVaultSaved(v => ({ ...v, [role]: false })), 2500)
      }
    } finally {
      setSavingVault(v => ({ ...v, [role]: false }))
    }
  }

  async function salvarInteg() {
    setSavingInteg(true)
    try {
      const res = await fetch("/api/empresa", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        /* A lista vira JSON só na hora de salvar. Guardar texto no banco é
           detalhe de armazenamento; quem edita mexe em campos separados. */
        body: JSON.stringify({
          ...integForm,
          whatsapp_extras: JSON.stringify(
            extrasWpp
              .map(e => ({ ...e, numero: e.numero.replace(/[^\d+]/g, "") }))
              .filter(e => e.numero.replace(/\D/g, "").length >= 10)),
          notificar_equipe_whatsapp: notificarEquipe,
          integracoes_ativas: JSON.stringify(integracoesAtivas),
          canal_avisos: canalAvisos,
        }),
      })
      if (res.ok) {
        setIntegSaved(true)
        setTimeout(() => setIntegSaved(false), 3000)
      }
    } finally {
      setSavingInteg(false)
    }
  }

  // ============================================================
  // Render
  // ============================================================
  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-6">
      {/* Toast empresa */}
      {empresaSaved && (
        <div className="fixed top-4 right-4 z-50 bg-green-600 text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2">
          <CheckCheck className="w-4 h-4" /> Configurações salvas!
        </div>
      )}
      {integSaved && (
        <div className="fixed top-4 right-4 z-50 bg-green-600 text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-2">
          <CheckCheck className="w-4 h-4" /> Tokens salvos com sucesso!
        </div>
      )}

      <CabecalhoPagina
        icone={Settings}
        titulo="Configurações"
        contexto="Empresa, usuários, integrações e backups"
      />

      {/* Ou o índice, ou uma seção, nunca os dois. Com as abas abertas
          embaixo, o painel virava enfeite: a pessoa já via tudo antes de
          escolher, que é o oposto de compactar. */}
      {aba === null && (
      <div className="grid gap-3 sm:gap-4 lg:grid-cols-2">
        <Bloco titulo="Conta">
          <div className="space-y-2">
            <LinhaAtalho titulo="Dados da empresa" contexto="Razão social, CNPJ, endereço"
              acao="Editar" aoClicar={() => setAba("empresa")} />
            <LinhaAtalho titulo="Identidade visual" contexto="Logo e textos padrão das propostas"
              acao="Editar" aoClicar={() => setAba("empresa")} />
            <LinhaAtalho titulo="Usuários e permissões"
              contexto={`${usuarios.length} cadastrado${usuarios.length === 1 ? "" : "s"}`}
              acao="Gerenciar" aoClicar={() => setAba("usuarios")} />
          </div>
        </Bloco>

        <Bloco titulo="Sistema">
          <div className="space-y-2">
            <LinhaAtalho titulo="Integrações" contexto="WhatsApp, Google Agenda, Olist"
              acao="Configurar" aoClicar={() => setAba("integracoes")} />
            <LinhaAtalho titulo="Base de conhecimento" contexto="Documentos que o CORE consulta"
              acao="Abrir" aoClicar={() => setAba("conhecimento")} />
            <LinhaAtalho titulo="Backup e exportação" contexto="Cópia dos dados da empresa"
              acao="Exportar" aoClicar={() => setAba("backups")} />
          </div>
        </Bloco>
      </div>
      )}

      {aba !== null && (
      <>
      <button type="button" onClick={() => setAba(null)}
        className="flex items-center gap-1.5 text-[13px] text-muted-foreground transition-colors hover:text-foreground">
        <ChevronLeft className="h-4 w-4" /> Configurações
      </button>

      <Tabs value={aba ?? "empresa"} onValueChange={setAba}>
        <TabsList className="h-auto p-0 bg-transparent border-b border-border w-full rounded-none justify-start gap-0">
          <TabsTrigger value="empresa" className="rounded-none h-9 px-4 text-[13px] border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none text-muted-foreground data-[state=active]:text-foreground font-normal data-[state=active]:font-medium">
            Empresa
          </TabsTrigger>
          <TabsTrigger value="usuarios" className="rounded-none h-9 px-4 text-[13px] border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none text-muted-foreground data-[state=active]:text-foreground font-normal data-[state=active]:font-medium">
            Usuários
          </TabsTrigger>
          <TabsTrigger value="integracoes" className="rounded-none h-9 px-4 text-[13px] border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none text-muted-foreground data-[state=active]:text-foreground font-normal data-[state=active]:font-medium">
            Integrações
          </TabsTrigger>
          <TabsTrigger value="conhecimento" className="rounded-none h-9 px-4 text-[13px] border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none text-muted-foreground data-[state=active]:text-foreground font-normal data-[state=active]:font-medium">
            CORE
          </TabsTrigger>
          <TabsTrigger value="backups" className="rounded-none h-9 px-4 text-[13px] border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none text-muted-foreground data-[state=active]:text-foreground font-normal data-[state=active]:font-medium">
            Backups
          </TabsTrigger>
          {ehAdmin && (
            <TabsTrigger value="sistema" className="rounded-none h-9 px-4 text-[13px] border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none text-muted-foreground data-[state=active]:text-foreground font-normal data-[state=active]:font-medium">
              Sistema
            </TabsTrigger>
          )}
          <TabsTrigger value="admin" className="rounded-none h-9 px-4 text-[13px] border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none text-muted-foreground data-[state=active]:text-foreground font-normal data-[state=active]:font-medium">
            Admin
          </TabsTrigger>
        </TabsList>

        {/* ===================== ABA: CORE (base de conhecimento) ===================== */}
        <TabsContent value="conhecimento" className="mt-6">
          <ConhecimentoTab />
        </TabsContent>

        {/* ===================== ABA: BACKUPS ===================== */}
        <TabsContent value="backups" className="mt-6">
          <BackupsTab />
        </TabsContent>

        {/* ===================== ABA: EMPRESA ===================== */}
        <TabsContent value="empresa" className="mt-6 space-y-4">

          {/* Os dois logos lado a lado: são a mesma decisão vista de dois
              lugares — o que a equipe vê e o que o cliente recebe —, e comparar
              um com o outro é justamente o que evita trocar o errado. */}
          <div className="grid gap-4 lg:grid-cols-2">

          <div className="ios-card p-5 space-y-4">
            <div>
              <h2 className="text-foreground font-medium">Logo do sistema</h2>
              <p className="mt-0.5 text-xs text-muted-foreground">Barra lateral e ícone do aplicativo.</p>
            </div>
            <div className="flex items-center gap-4 flex-wrap">
              {empresa?.logo_url ? (
                <div className="relative">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={proxiedImg(empresa.logo_url)} alt="Logo"
                    className="w-20 h-20 object-contain rounded-xl bg-muted border border-border p-2" />
                  <button onClick={() => removerLogo("logo_url")}
                    className="absolute -top-1.5 -right-1.5 bg-red-500 rounded-full p-0.5 text-white hover:bg-red-600 transition-colors">
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ) : (
                <div className="w-20 h-20 rounded-xl bg-muted border border-border flex items-center justify-center">
                  <Building2 className="w-8 h-8 text-muted-foreground/30" />
                </div>
              )}
              <div className="space-y-2">
                <input type="file" id="logo-upload" accept="image/*" className="hidden"
                  onChange={e => { const f = e.target.files?.[0]; if (f) uploadLogo(f) }} />
                <label htmlFor="logo-upload"
                  className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-muted border border-border text-muted-foreground hover:text-foreground text-sm transition-colors">
                  <Upload className="w-4 h-4" />
                  {uploadingLogo ? "Enviando..." : "Fazer upload da logo"}
                </label>
                <p className="text-muted-foreground/60 text-xs">PNG, JPG ou SVG. Máx. 800 KB.</p>
                {logoErro && <p className="text-ios-red text-xs">{logoErro}</p>}
              </div>
            </div>
          </div>

          {/* Marca dos documentos: campo separado de propósito. O logo do
              sistema é trocado com frequência (ícone do app, barra lateral) e
              a cada troca o da proposta ia junto — virava o símbolo quadrado,
              sem o nome escrito, no documento que o cliente recebe. */}
          <div className="ios-card p-5 space-y-4">
            <div>
              <h2 className="text-foreground font-medium">Logo das propostas e contratos</h2>
              <p className="mt-0.5 text-xs text-muted-foreground">
                É o que o cliente vê no documento. Independente do logo do sistema, trocar
                um não mexe no outro.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-4">
              {empresa?.logo_proposta_url ? (
                <div className="relative">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={proxiedImg(empresa.logo_proposta_url)} alt="Logo das propostas"
                    className="h-20 w-32 rounded-xl border border-border bg-white object-contain p-2" />
                  <button onClick={() => removerLogo("logo_proposta_url")}
                    className="absolute -right-1.5 -top-1.5 rounded-full bg-ios-red p-0.5 text-background transition-colors hover:opacity-90">
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ) : (
                <div className="flex h-20 w-32 items-center justify-center rounded-xl border border-border bg-muted">
                  <FileText className="h-8 w-8 text-muted-foreground/30" />
                </div>
              )}
              <div className="space-y-2">
                <input type="file" id="logo-proposta-upload" accept="image/*" className="hidden"
                  onChange={e => { const f = e.target.files?.[0]; if (f) uploadLogo(f, "logo_proposta_url") }} />
                <label htmlFor="logo-proposta-upload"
                  className="inline-flex cursor-pointer items-center gap-1.5 rounded-xl border border-border bg-muted px-3 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground">
                  <Upload className="h-4 w-4" />
                  {uploadingLogo ? "Enviando..." : "Trocar logo dos documentos"}
                </label>
                <p className="text-xs text-muted-foreground/60">
                  Use a versão com o nome escrito — é a que assina o documento.
                </p>
              </div>
            </div>
          </div>

          </div>

          {/* Dados da empresa */}
          <div className="ios-card p-5 space-y-4">
            <h2 className="text-foreground font-medium">Dados Cadastrais</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Razão Social / Nome da Empresa">
                <TextInput
                  value={empresaForm.nome_empresa}
                  onChange={v => setEmpresaForm(f => ({ ...f, nome_empresa: v }))}
                  placeholder="Controllares Automação Ltda"
                />
              </Field>
              <Field label="CNPJ / CPF">
                <TextInput
                  value={empresaForm.cnpj_cpf}
                  onChange={v => setEmpresaForm(f => ({ ...f, cnpj_cpf: v }))}
                  placeholder="00.000.000/0001-00"
                />
              </Field>
              <Field label="Endereço-base da Sede">
                <TextInput
                  value={empresaForm.endereco_base}
                  onChange={v => setEmpresaForm(f => ({ ...f, endereco_base: v }))}
                  placeholder="Rua Exemplo, 100 - São Paulo/SP"
                />
              </Field>
              {/* Contato público: é o que o cliente vê no topo da proposta enviada */}
              <Field label="E-mail de contato (aparece na proposta)">
                <TextInput
                  value={empresaForm.email_contato}
                  onChange={v => setEmpresaForm(f => ({ ...f, email_contato: v }))}
                  placeholder="contato@suaempresa.com.br"
                />
              </Field>
              <Field label="Telefone de contato (aparece na proposta)">
                <TextInput
                  value={empresaForm.telefone_contato}
                  onChange={v => setEmpresaForm(f => ({ ...f, telefone_contato: v }))}
                  placeholder="(79) 90000-0000"
                />
              </Field>
              <Field label="Desconto máximo para Vendedores (%)">
                <TextInput
                  type="number"
                  value={empresaForm.desconto_maximo}
                  onChange={v => setEmpresaForm(f => ({ ...f, desconto_maximo: v }))}
                  placeholder="10"
                />
              </Field>
            </div>
            <div className="flex justify-end pt-2">
              <Button onClick={salvarEmpresa} disabled={savingEmpresa}
                className="gap-1.5">
                {savingEmpresa
                  ? <><RefreshCw className="w-4 h-4 animate-spin" /> Salvando...</>
                  : <><Save className="w-4 h-4" /> Salvar Dados</>
                }
              </Button>
            </div>
          </div>
        </TabsContent>

        {/* ===================== ABA: USUÁRIOS ===================== */}
        <TabsContent value="usuarios" className="mt-6 space-y-4">

          {/* 2FA, proteção extra da conta ADMIN */}
          <div className="ios-card p-5 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <h2 className="text-foreground font-medium flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-ios-green" /> Verificação em duas etapas (2FA)
                </h2>
                <p className="text-muted-foreground text-[13px] mt-0.5">
                  Além da senha, sua conta pede um código do app autenticador a cada login.
                </p>
              </div>
              {tfaEnabled !== null && !tfaQr && !tfaDesativando && (
                tfaEnabled ? (
                  <div className="flex items-center gap-2">
                    <span className="text-[12px] font-medium bg-ios-green/10 text-ios-green px-2.5 py-1 rounded-full">Ativo</span>
                    <Button size="sm" variant="outline" onClick={() => { setTfaDesativando(true); setTfaCodigo("") }}
                      className="h-8 text-xs text-ios-red border-ios-red/30 hover:bg-ios-red/10">Desativar</Button>
                  </div>
                ) : (
                  <Button size="sm" onClick={tfaIniciar} disabled={tfaBusy} className="h-9">
                    {tfaBusy ? "Gerando..." : "Ativar 2FA"}
                  </Button>
                )
              )}
            </div>

            {tfaQr && (
              <div className="flex flex-col sm:flex-row items-start gap-4 pt-1">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={tfaQr} alt="QR code 2FA" className="w-40 h-40 rounded-xl bg-white p-2 flex-shrink-0" />
                <div className="space-y-2.5 flex-1 min-w-[220px]">
                  <p className="text-[13px] text-muted-foreground">
                    1. Escaneie o QR com Google Authenticator, 1Password ou similar.<br />
                    2. Digite o código de 6 dígitos gerado para confirmar.
                  </p>
                  <div className="flex gap-2">
                    <Input value={tfaCodigo} onChange={e => setTfaCodigo(e.target.value.replace(/\D/g, ""))}
                      placeholder="000000" maxLength={6} inputMode="numeric"
                      className="w-32 text-center font-mono tracking-[0.3em]" />
                    <Button onClick={tfaConfirmar} disabled={tfaBusy || tfaCodigo.length < 6} className="h-11">
                      Confirmar
                    </Button>
                    <Button variant="ghost" onClick={() => { setTfaQr(null); setTfaErro("") }} className="h-11">
                      Cancelar
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {tfaDesativando && (
              <div className="flex items-center gap-2 pt-1 flex-wrap">
                <p className="text-[13px] text-muted-foreground w-full">Digite o código atual do autenticador para desativar:</p>
                <Input value={tfaCodigo} onChange={e => setTfaCodigo(e.target.value.replace(/\D/g, ""))}
                  placeholder="000000" maxLength={6} inputMode="numeric"
                  className="w-32 text-center font-mono tracking-[0.3em]" />
                <Button onClick={tfaDesativar} disabled={tfaBusy || tfaCodigo.length < 6}
                  className="h-11 bg-ios-red hover:bg-ios-red/90 text-background">Desativar 2FA</Button>
                <Button variant="ghost" onClick={() => { setTfaDesativando(false); setTfaErro("") }} className="h-11">Cancelar</Button>
              </div>
            )}

            {tfaErro && <p className="text-ios-red text-[13px]">{tfaErro}</p>}
          </div>

          {/* Convidar colaborador, e-mail + categoria geram link de convite */}
          <div className="ios-card p-5 space-y-3">
            <h2 className="text-foreground font-medium">Convidar colaborador</h2>
            <p className="text-muted-foreground text-[13px] -mt-1.5">
              O convidado recebe um link, cria a própria senha e entra direto com a categoria escolhida.
            </p>
            <div className="flex gap-2 flex-wrap">
              <Input value={convEmail} onChange={e => setConvEmail(e.target.value)}
                placeholder="email@colaborador.com" type="email" className="flex-1 min-w-[200px]" />
              <select value={convRole} onChange={e => setConvRole(e.target.value)}
                className="h-11 px-3 rounded-[16px] bg-muted border border-border text-foreground text-sm outline-none">
                {(Object.keys(ROLE_LABEL) as Role[]).map(r => (
                  <option key={r} value={r}>{ROLE_LABEL[r]}</option>
                ))}
              </select>
              <Button
                onClick={() => convRole === "ADMIN" ? setAvisoAdmin(true) : criarConvite()}
                disabled={convEnviando || !convEmail.trim()} className="h-11">
                {convEnviando ? "Gerando..." : "Convidar"}
              </Button>
            </div>

            {/* Convidar ADMIN troca quem administra a empresa: precisa ser uma
                escolha consciente, não um clique a mais. */}
            {convRole === "ADMIN" && (
              <div className="flex items-start gap-2.5 rounded-xl bg-ios-orange/10 px-3.5 py-3">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-ios-orange" />
                <p className="text-[13px] leading-relaxed text-foreground/90">
                  Ao aceitar o convite, essa pessoa vira <b>a administradora da empresa</b> e
                  você deixa de ser. Seu acesso continua, mas com perfil de Vendedor.
                  Nenhuma proposta ou obra é apagada.
                </p>
              </div>
            )}
            {convErro && <p className="text-ios-red text-[13px]">{convErro}</p>}
            {convLinkCopiado && <p className="text-ios-green text-[13px]">{convLinkCopiado}</p>}

            <Dialog open={avisoAdmin} onOpenChange={setAvisoAdmin}>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-ios-orange/15">
                    <ShieldCheck className="h-7 w-7 text-ios-orange" />
                  </div>
                  <DialogTitle className="text-center text-xl">Passar a administração?</DialogTitle>
                </DialogHeader>
                <div className="space-y-3 px-5 pb-1 text-[13px] leading-relaxed text-muted-foreground sm:px-6">
                  <p>
                    O convite vai para <b className="text-foreground">{convEmail.trim() || "—"}</b> com
                    perfil de Administrador.
                  </p>
                  <p>
                    Quando essa pessoa aceitar, ela assume a administração da empresa e a sua conta
                    passa a Vendedor, só um Administrador por empresa.
                  </p>
                  <p className="rounded-xl bg-muted px-3 py-2.5 text-foreground">
                    Propostas, obras e todo o resto do conteúdo continuam intactos. Muda só quem administra.
                  </p>
                </div>
                <DialogFooter className="gap-2 px-5 pb-4 sm:px-6">
                  <Button variant="outline" onClick={() => setAvisoAdmin(false)}>Cancelar</Button>
                  <Button onClick={() => { setAvisoAdmin(false); criarConvite() }} disabled={convEnviando}>
                    Enviar convite de Admin
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            {/* Só convites PENDENTES. Aceito virou usuário e já aparece na lista
                de usuários acima — repetir aqui dava a impressão de que ainda
                havia algo a fazer com ele. */}
            {convites.some(c => !c.usedAt) && (
              <div className="space-y-2 pt-1">
                <p className="text-[11px] uppercase tracking-wide text-muted-foreground font-medium">Convites pendentes</p>
                {convites.filter(c => !c.usedAt).map(c => {
                  const aceito = false
                  return (
                  <div key={c.id} className="flex items-center justify-between gap-3 bg-surface-1 border border-hairline rounded-xl px-4 py-2.5 flex-wrap">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-foreground text-sm truncate">{c.email}</p>
                        {aceito && <span className="text-[10px] font-medium bg-ios-green/10 text-ios-green px-1.5 py-0.5 rounded-full flex-shrink-0">aceito</span>}
                      </div>
                      <p className="text-muted-foreground text-[11px]">
                        {ROLE_LABEL[c.role as Role] ?? c.role}{!aceito && ` · expira ${new Date(c.expiresAt).toLocaleDateString("pt-BR")}`}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {!aceito && (
                        <Button size="sm" variant="outline" onClick={() => copiarLinkConvite(c.token)} className="h-8 text-xs">
                          Copiar link
                        </Button>
                      )}
                      <Button size="sm" variant="ghost"
                        title={aceito ? "Revoga o convite E desativa a conta criada por ele" : "Revoga o link"}
                        onClick={async () => {
                          await fetch(`/api/usuarios/convites/${c.id}`, { method: "DELETE" }); loadConvites(); loadUsers()
                        }} className="h-8 text-xs text-ios-red hover:bg-ios-red/10">
                        {aceito ? "Revogar acesso" : "Revogar"}
                      </Button>
                    </div>
                  </div>
                  )
                })}
              </div>
            )}
          </div>

          {/* Fila de aprovação, cadastros pendentes */}
          {usuarios.some(u => u.status === "PENDENTE") && (
            <div className="bg-ios-orange/5 border border-ios-orange/25 rounded-2xl p-5 space-y-3">
              <h2 className="text-foreground font-medium flex items-center gap-2">
                Aguardando aprovação
                <span className="text-[11px] font-semibold bg-ios-orange/15 text-ios-orange px-2 py-0.5 rounded-full">
                  {usuarios.filter(u => u.status === "PENDENTE").length}
                </span>
              </h2>
              <div className="space-y-2">
                {usuarios.filter(u => u.status === "PENDENTE").map(u => (
                  <div key={u.id} className="flex items-center justify-between gap-3 bg-surface-1 border border-hairline rounded-xl px-4 py-3 flex-wrap">
                    <div className="min-w-0">
                      <p className="text-foreground font-medium text-sm">{u.nome}</p>
                      <p className="text-muted-foreground text-xs mt-0.5">{u.email}</p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <select id={`aprovar-role-${u.id}`} defaultValue="VENDEDOR"
                        className="h-9 px-2.5 rounded-xl bg-muted border border-hairline text-foreground text-sm">
                        {(Object.keys(ROLE_LABEL) as Role[]).map(r => (
                          <option key={r} value={r}>{ROLE_LABEL[r]}</option>
                        ))}
                      </select>
                      <Button size="sm" onClick={async () => {
                        const role = (document.getElementById(`aprovar-role-${u.id}`) as HTMLSelectElement)?.value
                        await fetch(`/api/usuarios/${u.id}`, {
                          method: "PATCH", headers: { "Content-Type": "application/json" },
                          body: JSON.stringify({ status: "ATIVO", role }),
                        })
                        loadUsers()
                      }} className="h-9">Aprovar</Button>
                      <Button size="sm" variant="outline" onClick={async () => {
                        await fetch(`/api/usuarios/${u.id}`, { method: "DELETE" })
                        loadUsers()
                      }} className="h-9 text-ios-red border-ios-red/30 hover:bg-ios-red/10">Recusar</Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Lista de usuários */}
          <div className="ios-card p-5 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <h2 className="text-foreground font-medium">Colaboradores ({usuarios.length})</h2>
              <p className="text-muted-foreground/70 text-xs">Novos colaboradores entram pelo convite acima.</p>
            </div>

            {loadingUsers ? (
              <div className="text-center text-muted-foreground py-8">Carregando...</div>
            ) : (
              <div className="space-y-2">
                {usuarios.map(u => {
                  const desativado = u.status === "DESATIVADO"
                  return (
                  <div key={u.id}
                    className={`flex items-center justify-between gap-3 border border-border rounded-xl px-4 py-3 ${desativado ? "bg-muted/20 opacity-60" : "bg-muted/50"}`}>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-foreground font-medium text-sm">{u.nome}</p>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${ROLE_COLOR[u.role]}`}>
                          {ROLE_LABEL[u.role]}
                        </span>
                        {(u.roles ?? []).map(r => (
                          <span key={r} className={`text-xs px-2 py-0.5 rounded-full font-medium ${ROLE_COLOR[r]} opacity-80`}>
                            {ROLE_LABEL[r]}
                          </span>
                        ))}
                        {desativado && (
                          <span className="text-[11px] px-2 py-0.5 rounded-full font-medium bg-ios-red/10 text-ios-red">Desativado</span>
                        )}
                      </div>
                      <p className="text-muted-foreground text-xs mt-0.5">{u.email}</p>
                    </div>
                    <div className="flex gap-1 flex-shrink-0">
                      <Button size="sm" variant="ghost" title={desativado ? "Reativar acesso" : "Desativar acesso (bloqueia login)"}
                        onClick={async () => {
                          await fetch(`/api/usuarios/${u.id}`, {
                            method: "PATCH", headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ status: desativado ? "ATIVO" : "DESATIVADO" }),
                          })
                          loadUsers()
                        }}
                        className={`h-8 px-2 text-[11px] ${desativado ? "text-ios-green hover:bg-ios-green/10" : "text-ios-orange hover:bg-ios-orange/10"}`}>
                        {desativado ? "Reativar" : "Desativar"}
                      </Button>
                      <Button size="sm" variant="ghost" title="Forçar troca de senha no próximo login"
                        onClick={async () => {
                          await fetch(`/api/usuarios/${u.id}`, {
                            method: "PATCH", headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ must_change_password: true }),
                          })
                        }}
                        className="h-8 w-8 p-0 text-muted-foreground hover:text-ios-yellow">
                        <RefreshCw className="w-3.5 h-3.5" />
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => abrirEdicaoUser(u)}
                        className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground">
                        <Pencil className="w-3.5 h-3.5" />
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => excluirUser(u.id)}
                        disabled={deletingId === u.id}
                        className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive">
                        {deletingId === u.id
                          ? <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          : <Trash2 className="w-3.5 h-3.5" />}
                      </Button>
                    </div>
                  </div>
                  )
                })}
              </div>
            )}
          </div>
        </TabsContent>

        {/* ===================== ABA: INTEGRAÇÕES ===================== */}
        <TabsContent value="integracoes" className="mt-6 space-y-4">

          {/* Olist (Tiny), token simples. O caminho OAuth V3 foi retirado a pedido:
              um só jeito de conectar, sem escolha entre dois. */}
          {mostrarIntegracao("olist") && (
          <div className="ios-card p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-foreground font-medium flex items-center gap-2">
                  <span className="w-6 h-6 rounded bg-emerald-500/20 flex items-center justify-center text-emerald-400 text-xs font-bold">O</span>
                  Olist ERP
                </h2>
                <p className="text-muted-foreground text-xs mt-0.5">Envio de pedidos por token de API</p>
              </div>
              {integForm.tiny_api_token && (
                <span className="text-xs bg-green-500/10 text-green-400 px-2.5 py-1 rounded-full border border-green-500/20 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-400" /> Configurado
                </span>
              )}
            </div>
            <Recolhivel titulo="Token de acesso"
              resumo={integForm.tiny_api_token ? "Configurado" : "Falta o token, sem ele nada é enviado"}>
            <Field label="API Token">
              <div className="relative">
                <input
                  type={showSecrets ? "text" : "password"}
                  value={integForm.tiny_api_token}
                  onChange={e => setIntegForm(f => ({ ...f, tiny_api_token: e.target.value }))}
                  placeholder="Cole aqui o token da API do Tiny..."
                  className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 pr-10 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30"
                />
                <button type="button" onClick={() => setShowSecrets(s => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showSecrets ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-muted-foreground/60 text-xs mt-1">
                Encontre no Olist: Minha Conta → API → Gerar Token
              </p>
            </Field>
            </Recolhivel>

            <Recolhivel titulo="Sincronizar com o Olist"
              resumo="Catálogo, estoque, kits e fornecedores">

            {/* Espelho do catálogo. Fica aqui, junto do token, porque é a
                primeira coisa a fazer depois de conectar: sem os produtos
                cadastrados lá, o pedido entra com item avulso e não move
                estoque. */}
            {integForm.tiny_api_token && (
              <div className="rounded-xl border border-hairline bg-surface-1 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-[14px] font-medium text-foreground">Catálogo no Olist</p>
                    <p className="mt-0.5 text-[12px] text-muted-fg">
                      {catalogo
                        ? catalogo.faltando > 0
                          ? `${catalogo.faltando} de ${catalogo.nossos} produtos ainda não estão lá.`
                          : `Todos os ${catalogo.nossos} produtos já estão no Olist.`
                        : "Compare o que existe aqui com o que existe lá."}
                    </p>
                  </div>
                  <div className="flex shrink-0 gap-2">
                    <Button variant="outline" size="sm" className="h-8" disabled={conferindoCatalogo}
                      onClick={conferirCatalogo}>
                      {conferindoCatalogo ? "Conferindo..." : "Conferir"}
                    </Button>
                    {!!catalogo?.faltando && (
                      <Button size="sm" className="h-8" disabled={enviandoCatalogo} onClick={enviarCatalogo}>
                        {enviandoCatalogo ? `Enviando... ${enviadosCatalogo}` : "Enviar os que faltam"}
                      </Button>
                    )}
                  </div>
                </div>
                <p className="mt-2.5 text-[12px] text-muted-fg">
                  Só cria o que falta, comparando pelo SKU. Nada que já está no Olist é
                  alterado ou excluído. O Olist limita chamadas por minuto, então o envio
                  vai em lotes com pausa, deixe a aba aberta até terminar.
                </p>
                {erroCatalogo && <p className="mt-2 text-[12px] text-ios-red">{erroCatalogo}</p>}
              </div>
            )}

            {/* Espelho do saldo. Direção única: daqui para lá. */}
            {integForm.tiny_api_token && (
              <div className="rounded-xl border border-hairline bg-surface-1 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-[14px] font-medium text-foreground">Saldo de estoque</p>
                    <p className="mt-0.5 text-[12px] text-muted-fg">
                      {resultadoEstoque
                        ? `${resultadoEstoque.enviados.length} saldo(s) espelhado(s)`
                          + (resultadoEstoque.semCadastro.length
                            ? ` · ${resultadoEstoque.semCadastro.length} ainda sem cadastro lá` : "")
                        : "Envia a contagem daqui para o Olist."}
                    </p>
                  </div>
                  <Button size="sm" variant="outline" className="h-8 shrink-0"
                    disabled={enviandoEstoque} onClick={enviarEstoque}>
                    {enviandoEstoque ? "Enviando..." : "Espelhar saldo"}
                  </Button>
                </div>
                <p className="mt-2.5 text-[12px] text-muted-fg">
                  O Controllares é a fonte da verdade: quem conta o material é este sistema, e o
                  Olist guarda a cópia. O saldo nunca é lido de volta, o Olist baixa estoque
                  ao faturar, e essa baixa desfaria a contagem feita na obra.
                </p>
                {erroEstoque && <p className="mt-2 text-[12px] text-ios-red">{erroEstoque}</p>}
              </div>
            )}

            {/* Kits e fornecedores. Vêm depois do catálogo de propósito: o kit
                referencia os componentes por id, e componente que não está lá
                impede o pacote inteiro. */}
            {integForm.tiny_api_token && ([
              { rota: "kits" as const, titulo: "Kits", dados: kits,
                vazio: "Envia os pacotes montados aqui como kit no Olist.",
                nota: "O kit vira um produto com a lista de componentes. Envie o catálogo antes: componente que não existe lá impede o kit." },
              { rota: "fornecedores" as const, titulo: "Fornecedores", dados: fornecedores,
                vazio: "Envia os fornecedores daqui como contatos no Olist.",
                nota: "Sem o fornecedor cadastrado, não dá para lançar compra nem conta a pagar contra ele. Só cria quem ainda não existe." },
            ]).map(({ rota, titulo, dados, vazio, nota }) => (
              <div key={rota} className="rounded-xl border border-hairline bg-surface-1 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-[14px] font-medium text-foreground">{titulo}</p>
                    <p className="mt-0.5 text-[12px] text-muted-fg">
                      {dados
                        ? dados.faltando > 0
                          ? `${dados.faltando} de ${dados.nossos} ainda não estão lá.`
                          : `Todos os ${dados.nossos} já estão no Olist.`
                        : vazio}
                    </p>
                  </div>
                  <div className="flex shrink-0 gap-2">
                    <Button variant="outline" size="sm" className="h-8"
                      disabled={!!ocupado} onClick={() => conferirEspelho(rota)}>
                      {ocupado === `conferir-${rota}` ? "Conferindo..." : "Conferir"}
                    </Button>
                    {!!dados?.faltando && (
                      <Button size="sm" className="h-8"
                        disabled={!!ocupado} onClick={() => enviarEspelho(rota)}>
                        {ocupado === `enviar-${rota}` ? "Enviando..." : "Enviar os que faltam"}
                      </Button>
                    )}
                  </div>
                </div>
                <p className="mt-2.5 text-[12px] text-muted-fg">{nota}</p>
                {dados?.aviso && <p className="mt-2 text-[12px] text-ios-orange">{dados.aviso}</p>}
              </div>
            ))}
            {integForm.tiny_api_token && erroEspelho && (
              <p className="text-[12px] text-ios-red">{erroEspelho}</p>
            )}
            </Recolhivel>
          </div>
          )}

          {/* Google Drive, onde a cópia do sistema fica guardada */}
          {mostrarIntegracao("drive") && (
          <div className="ios-card p-5 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="min-w-0">
                <h2 className="text-foreground font-medium flex items-center gap-2">
                  <HardDrive className="w-5 h-5 text-sky-400" /> Google Drive
                </h2>
                <p className="text-muted-foreground text-xs mt-0.5">
                  O backup diário do sistema também vai para o seu Drive
                </p>
              </div>
              <span className="text-xs text-muted-foreground">
                {drive?.conectado ? "conectado" : "não conectado"}
              </span>
            </div>

            {drive?.conectado ? (
              <div className="space-y-3">
                <div className="text-[13px] text-muted-fg space-y-1">
                  <p>
                    Pasta <strong className="text-foreground">{drive.pasta}</strong> no seu Drive.
                  </p>
                  <p className="text-[12px]">
                    {drive.ultimoEnvio
                      ? `Último envio em ${new Date(drive.ultimoEnvio).toLocaleString("pt-BR")}.`
                      : "Nenhum backup enviado ainda. O próximo sai na madrugada."}
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button variant="outline" size="sm" disabled={driveOcupado}
                    onClick={() => acaoDrive("testar")} className="gap-1.5">
                    <Upload className="w-3.5 h-3.5" /> Enviar teste agora
                  </Button>
                  <Button variant="outline" size="sm" disabled={driveOcupado}
                    onClick={() => acaoDrive("limpar")}>
                    Limpar antigos
                  </Button>
                  <Button variant="ghost" size="sm" disabled={driveOcupado}
                    onClick={desconectarDrive} className="gap-1.5 text-ios-red">
                    <Unlink className="w-3.5 h-3.5" /> Desconectar
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-2.5">
                <p className="text-[12px] leading-relaxed text-muted-fg">
                  Hoje o backup fica no mesmo lugar que hospeda o sistema. Conectar o Drive
                  põe uma cópia num lugar que é seu e que você abre sozinho, sem depender
                  de painel nenhum.
                </p>
                <Button size="sm" disabled={driveOcupado}
                  onClick={() => acaoDrive("autorizar")} className="gap-1.5">
                  <Link2 className="w-3.5 h-3.5" />
                  {driveOcupado ? "Abrindo..." : "Conectar Google Drive"}
                </Button>
              </div>
            )}

            {!!driveAviso && <p className="text-[12px] text-muted-fg">{driveAviso}</p>}

            {/* O alcance do acesso, dito antes de ser concedido. */}
            <p className="text-[12px] leading-relaxed text-muted-fg">
              O sistema só enxerga os arquivos que ele mesmo criar, o resto do seu Drive
              continua fora do alcance. Desconectar não apaga nada: o que já foi enviado
              é seu.
            </p>
          </div>
          )}

          {/* Plaud, gravador de reunião */}
          {mostrarIntegracao("plaud") && (
          <div className="ios-card p-5 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="min-w-0">
                <h2 className="text-foreground font-medium flex items-center gap-2">
                  <Mic className="w-5 h-5 text-violet-400" /> Plaud
                </h2>
                <p className="text-muted-foreground text-xs mt-0.5">
                  A reunião gravada vira proposta em rascunho, com os itens já montados
                </p>
              </div>
              <div className="flex items-center gap-2">
                {plaud?.conectado ? (
                  <>
                    <span className="text-xs bg-green-500/10 text-green-400 px-2.5 py-1 rounded-full border border-green-500/20 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-400" /> Conectado
                    </span>
                    <Button variant="ghost" size="sm" onClick={desconectarPlaud}
                      className="text-red-400 hover:text-red-300 hover:bg-red-500/10 h-7 text-xs gap-1">
                      <Unlink className="w-3.5 h-3.5" /> Desconectar
                    </Button>
                  </>
                ) : (
                  <span className="text-xs text-muted-fg">não conectado</span>
                )}
              </div>
            </div>


            {plaud?.conectado && (
              <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
                <div className="rounded-xl bg-foreground/[0.04] p-3">
                  <p className="text-[20px] font-semibold leading-none text-foreground">{plaud.reunioes}</p>
                  <p className="mt-1.5 text-[12px] text-muted-fg">reuniões baixadas</p>
                </div>
                <div className="rounded-xl bg-foreground/[0.04] p-3">
                  <p className="text-[12px] text-muted-fg">Última busca</p>
                  <p className="mt-1 text-[13px] text-foreground">
                    {plaud.ultimoSync ? new Date(plaud.ultimoSync).toLocaleString("pt-BR") : "ainda não rodou"}
                  </p>
                </div>
              </div>
            )}

            {plaud?.conectado ? (
              <div className="flex flex-wrap items-center gap-2">
                <Button size="sm" variant="outline" className="h-8 text-xs"
                  disabled={buscandoPlaud} onClick={buscarReunioes}>
                  {buscandoPlaud ? "Buscando..." : "Buscar reuniões agora"}
                </Button>
                {resultadoPlaud && (
                  <span className="text-[12px] text-foreground/80">{resultadoPlaud}</span>
                )}
              </div>
            ) : (
              <div className="space-y-2.5">
                {/* O passo manual existe por limitação da plataforma, não por
                    preguiça de automatizar — e é uma vez só. */}
                <p className="text-[12px] leading-relaxed text-muted-fg">
                  O Plaud não oferece conexão automática para ler as próprias
                  gravações. Rode os dois comandos abaixo uma vez, no seu
                  computador, e cole aqui o arquivo que o segundo gerar. Depois
                  disso quem busca é o servidor, seu computador sai da jogada.
                </p>
                <code className="block rounded-lg bg-foreground/[0.06] px-2.5 py-2 text-[11px] leading-relaxed text-foreground/80">
                  npm install -g @plaud-ai/cli<br />plaud login
                </code>
                {/* Escolher o arquivo, não colar o conteúdo.
                    Colado à mão o texto vem truncado com facilidade — o token é
                    uma linha só, de milhares de caracteres, e a seleção pára no
                    meio sem que nada avise. O Plaud então recusa um token que
                    estava perfeito, e o erro aponta para o lugar errado. */}
                <p className="text-[12px] text-muted-fg">
                  Depois escolha o arquivo <code className="text-foreground/80">~/.plaud/tokens.json</code>
                  {" "}que o comando gerou:
                </p>
                <input
                  type="file" accept=".json,application/json"
                  onChange={async e => {
                    const f = e.target.files?.[0]
                    if (!f) return
                    setErroPlaud("")
                    const txt = await f.text()
                    try {
                      const j = JSON.parse(txt)
                      if (!j.access_token) {
                        setErroPlaud("Esse arquivo não tem access_token. Confira se é o ~/.plaud/tokens.json.")
                        return
                      }
                      /* Sem refresh_token o acesso morre em 24h e você refaz
                         isto amanhã. Vale avisar agora, não amanhã. */
                      if (!j.refresh_token) {
                        setErroPlaud("O arquivo não traz refresh_token. A conexão venceria em 24h."
                          + " Rode `plaud login` de novo e escolha o arquivo novo.")
                        return
                      }
                      setTokensPlaud(txt)
                    } catch {
                      setErroPlaud("Arquivo inválido: não é um JSON completo.")
                    }
                  }}
                  className="w-full rounded-xl border border-border bg-muted px-3 py-2 text-[12px] text-foreground outline-none file:mr-3 file:rounded-lg file:border-0 file:bg-foreground/10 file:px-2.5 file:py-1 file:text-[12px] file:text-foreground"
                />
                {!!tokensPlaud && !erroPlaud && (
                  <p className="text-[12px] text-ios-green">Arquivo lido. Pode conectar.</p>
                )}
                <Button size="sm" className="h-8 text-xs gap-1.5"
                  disabled={conectandoPlaud || tokensPlaud.trim().length < 40}
                  onClick={conectarPlaud}>
                  <Link2 className="w-3.5 h-3.5" />
                  {conectandoPlaud ? "Conferindo..." : "Conectar Plaud"}
                </Button>
              </div>
            )}

            {erroPlaud && <p className="text-[12px] text-ios-red">{erroPlaud}</p>}

            {/* O alcance do acesso, dito antes de ser concedido. */}
            <p className="text-[12px] leading-relaxed text-muted-fg">
              O acesso alcança todas as gravações desta conta Plaud, não só as de
              trabalho, por isso vale usar uma conta separada para as reuniões.
              Fica guardado cifrado e pode ser revogado aqui a qualquer momento.
            </p>
            <p className="text-[12px] leading-relaxed text-muted-fg">
              O Plaud não avisa quando há gravação nova, então o sistema busca
              toda vez que você abre as reuniões, e uma vez por dia, de manhã,
              para o caso de ninguém abrir. E não
              permite apagar pela API: limpar o aparelho continua sendo pelo
              aplicativo, a transcrição fica guardada aqui antes disso.
            </p>
          </div>
          )}

          {/* Google Calendar */}
          {mostrarIntegracao("calendar") && (
          <div className="ios-card p-5 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <h2 className="text-foreground font-medium flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-sky-400" /> Google Calendar
                </h2>
                <p className="text-muted-foreground text-xs mt-0.5">Sincronize agendamentos de obra com seu Google Calendar</p>
              </div>
              <div className="flex items-center gap-2">
                {loadingGoogleStatus ? (
                  <RefreshCw className="w-4 h-4 text-muted-foreground animate-spin" />
                ) : googleStatus?.conectado ? (
                  <>
                    <span className="text-xs bg-green-500/10 text-green-400 px-2.5 py-1 rounded-full border border-green-500/20 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-400" />
                      {googleStatus.expirado ? "Token expirado" : "Conectado"}
                    </span>
                    <Button variant="ghost" size="sm" onClick={desconectarGoogle}
                      className="text-red-400 hover:text-red-300 hover:bg-red-500/10 h-7 text-xs gap-1">
                      <Unlink className="w-3.5 h-3.5" /> Desconectar
                    </Button>
                  </>
                ) : (
                  <Button
                    size="sm"
                    onClick={() => window.location.href = "/api/integracoes/google/auth"}
                    className="gap-1.5 h-8 text-xs"
                    disabled={!integForm.google_client_id || !integForm.google_client_secret}
                  >
                    <Link2 className="w-3.5 h-3.5" /> Conectar Google Calendar
                  </Button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Client ID (Google Cloud)">
                <input
                  type={showSecrets ? "text" : "password"}
                  value={integForm.google_client_id}
                  onChange={e => setIntegForm(f => ({ ...f, google_client_id: e.target.value }))}
                  placeholder="1234567890-abc....apps.googleusercontent.com"
                  className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30"
                />
              </Field>
              <Field label="Client Secret (Google Cloud)">
                <input
                  type={showSecrets ? "text" : "password"}
                  value={integForm.google_client_secret}
                  onChange={e => setIntegForm(f => ({ ...f, google_client_secret: e.target.value }))}
                  placeholder="GOCSPX-••••••••••••"
                  className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30"
                />
              </Field>
            </div>
            <p className="text-muted-foreground/60 text-xs">
              URI de redirecionamento autorizada: <code className="text-muted-foreground">{typeof window !== "undefined" ? window.location.origin : ""}/api/integracoes/google/callback</code>
            </p>
          </div>
          )}

          {/* Pluga.co */}
          {mostrarIntegracao("pluga") && (
          <div className="ios-card p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-foreground font-medium">Pluga.co</h2>
                <p className="text-muted-foreground text-xs mt-0.5">Automações e webhooks entre ferramentas</p>
              </div>
            </div>
            <Field label="API Token">
              <div className="relative">
                <input
                  type={showSecrets ? "text" : "password"}
                  value={integForm.pluga_api_token}
                  onChange={e => setIntegForm(f => ({ ...f, pluga_api_token: e.target.value }))}
                  placeholder="plg_••••••••••••••••••••••••"
                  className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 pr-10 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30"
                />
                <button type="button" onClick={() => setShowSecrets(s => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showSecrets ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </Field>
          </div>
          )}

          {/* ContaAzul */}
          {mostrarIntegracao("contaazul") && (
          <div className="ios-card p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-foreground font-medium">ContaAzul</h2>
                <p className="text-muted-foreground text-xs mt-0.5">Sincronização financeira e emissão de NF-e</p>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Client ID">
                <input
                  type={showSecrets ? "text" : "password"}
                  value={integForm.contaazul_client_id}
                  onChange={e => setIntegForm(f => ({ ...f, contaazul_client_id: e.target.value }))}
                  placeholder="ca_client_••••••••"
                  className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30"
                />
              </Field>
              <Field label="Client Secret">
                <input
                  type={showSecrets ? "text" : "password"}
                  value={integForm.contaazul_client_secret}
                  onChange={e => setIntegForm(f => ({ ...f, contaazul_client_secret: e.target.value }))}
                  placeholder="ca_secret_••••••••"
                  className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30"
                />
              </Field>
            </div>
          </div>
          )}

          {/* Telegram, bot da empresa para os grupos de obra */}
          {/* Canal dos avisos. Fica acima dos dois cartões porque é a escolha
              que decide qual deles importa. */}
          <div className="ios-card p-5 space-y-3">
            <div>
              <h2 className="text-foreground font-medium">Por onde saem os avisos</h2>
              <p className="text-muted-foreground text-xs mt-0.5">
                Proposta lida, aceita, revisão pedida, faturamento.
              </p>
            </div>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
              {([
                ["TELEGRAM", "Telegram", "Sem cota, sem custo. Cada pessoa conecta no próprio perfil."],
                ["WHATSAPP", "WhatsApp", "CallMeBot tem cota por número e para sem avisar."],
                ["AMBOS", "Os dois", "Mesma pessoa recebe duas vezes o mesmo aviso."],
              ] as const).map(([id, titulo, desc]) => (
                <button key={id} type="button" onClick={() => setCanalAvisos(id)}
                  className={`ios-tap rounded-xl border p-3 text-left transition-colors ${
                    canalAvisos === id ? "border-primary bg-primary/10" : "border-border hover:border-border/70"
                  }`}>
                  <span className="block text-sm font-semibold text-foreground">{titulo}</span>
                  <span className="mt-0.5 block text-[11px] leading-relaxed text-muted-foreground">{desc}</span>
                </button>
              ))}
            </div>
            <p className="text-[12px] text-muted-foreground">
              Salvar em &ldquo;Salvar integrações&rdquo;, no fim da página.
            </p>
          </div>

          {mostrarIntegracao("telegram") && (
          <div className="ios-card p-5 space-y-4">
            <div>
              <h2 className="text-foreground font-medium">Telegram</h2>
              <p className="text-muted-foreground text-xs mt-0.5">
                Bot para os grupos de obra. Crie com o @BotFather e cole o token aqui. Depois é
                só adicionar o bot aos grupos, o vínculo com a obra é feito sozinho.
              </p>
            </div>
            <Field label="Bot Token">
              <input
                type={showSecrets ? "text" : "password"}
                value={integForm.telegram_bot_token}
                onChange={e => setIntegForm(f => ({ ...f, telegram_bot_token: e.target.value }))}
                placeholder="123456789:AA••••••••"
                className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30"
              />
            </Field>

            <div className="border-t border-border pt-4">
              <TelegramGruposTab />
            </div>
          </div>
          )}

          {/* WhatsApp, notificações via CallMeBot (grátis) */}
          {mostrarIntegracao("whatsapp") && (
          <div className="ios-card p-5 space-y-4">
            <div>
              <h2 className="text-foreground font-medium flex items-center gap-2">
                <span className="w-6 h-6 rounded bg-green-500/20 flex items-center justify-center text-green-400 text-xs font-bold">W</span>
                WhatsApp (notificações)
              </h2>
              <p className="text-muted-foreground text-xs mt-1 leading-relaxed">
                Grátis via CallMeBot. Como ativar: 1) adicione <b>+34 623 78 95 95</b> aos contatos;
                2) mande <b>&ldquo;I allow callmebot to send me messages&rdquo;</b> por WhatsApp para esse número;
                3) você recebe uma <b>apikey</b>, cole abaixo junto com o número (com DDI, ex: +5579999999999).
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Field label="Número (com DDI)">
                <input value={integForm.whatsapp_numero}
                  onChange={e => setIntegForm(f => ({ ...f, whatsapp_numero: e.target.value }))}
                  placeholder="+5579999999999"
                  className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30" />
              </Field>
              <Field label="API Key (CallMeBot)">
                <input type={showSecrets ? "text" : "password"} value={integForm.whatsapp_apikey}
                  onChange={e => setIntegForm(f => ({ ...f, whatsapp_apikey: e.target.value }))}
                  placeholder="123456"
                  className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30" />
              </Field>
            </div>

            {/* Números extras, recebem exatamente as mesmas mensagens.

                Existem porque nem todo mundo que precisa saber tem usuário no
                sistema: o sócio que acompanha de fora, o técnico terceirizado.
                Cada um carrega a própria apikey porque no CallMeBot ela é
                amarrada ao aparelho — a chave de um não envia para o outro. */}
            <div className="rounded-xl border border-border bg-muted/30 p-3 space-y-2.5">
              <div className="flex items-center justify-between gap-3">
                <p className="text-[13px] text-foreground">Outros números que recebem o mesmo aviso</p>
                <Button type="button" variant="outline" size="sm" className="h-7 text-xs"
                  onClick={() => setExtrasWpp(l => [...l, { numero: "", apikey: "", nome: "" }])}>
                  <Plus className="w-3.5 h-3.5 mr-1" /> Adicionar
                </Button>
              </div>

              {/* A equipe é a única parte desta lista que não se vê aqui: o
                  número sai do perfil de cada um. O interruptor é o que dá ao
                  admin a chance de desligar o que ele não consegue enxergar. */}
              <label className="flex items-start gap-2 rounded-lg bg-muted/40 px-2.5 py-2">
                <input type="checkbox" checked={notificarEquipe}
                  onChange={e => setNotificarEquipe(e.target.checked)}
                  className="mt-0.5 h-4 w-4 accent-primary" />
                <span className="text-[12px] leading-relaxed text-muted-foreground">
                  <span className="text-foreground">Enviar também para a equipe</span>, cada pessoa
                  recebe no número que cadastrou no próprio perfil, com a apikey dela.
                  Desligado, só os números desta tela recebem.
                </span>
              </label>

              {extrasWpp.length === 0 ? (
                <p className="text-[12px] text-muted-foreground/70">
                  Nenhum número extra{notificarEquipe ? ". A equipe cadastrada com WhatsApp no perfil já recebe." : " e a equipe está desligada: só o número da empresa recebe."}
                </p>
              ) : extrasWpp.map((e, i) => (
                <div key={i} className="grid grid-cols-1 gap-2 sm:grid-cols-[1fr_1fr_1fr_auto]">
                  <input value={e.nome ?? ""} placeholder="Nome (opcional)"
                    onChange={ev => setExtrasWpp(l => l.map((x, k) => k === i ? { ...x, nome: ev.target.value } : x))}
                    className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30" />
                  <input value={e.numero} placeholder="+5517999999999"
                    onChange={ev => setExtrasWpp(l => l.map((x, k) => k === i ? { ...x, numero: ev.target.value } : x))}
                    className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30" />
                  <input type={showSecrets ? "text" : "password"} value={e.apikey ?? ""}
                    placeholder="apikey do CallMeBot"
                    onChange={ev => setExtrasWpp(l => l.map((x, k) => k === i ? { ...x, apikey: ev.target.value } : x))}
                    className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30" />
                  <button type="button" onClick={() => setExtrasWpp(l => l.filter((_, k) => k !== i))}
                    className="justify-self-start rounded-lg p-2 text-muted-foreground hover:text-ios-red sm:justify-self-auto">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}

              <p className="text-[12px] leading-relaxed text-muted-foreground/70">
                Cada número precisa da própria apikey: no CallMeBot ela é amarrada ao
                aparelho. Com a Evolution API abaixo, a apikey deixa de ser necessária.
              </p>
            </div>

            {/* Evolution API fica como alternativa opcional: se preencher, ela
                assume no lugar do CallMeBot. */}
            <details className="rounded-xl border border-border bg-muted/30 px-3 py-2">
              <summary className="cursor-pointer text-xs text-muted-foreground">
                Usar Evolution API no lugar do CallMeBot (opcional)
              </summary>
              <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
                <Field label="URL da Evolution">
                  <input value={integForm.evolution_url}
                    onChange={e => setIntegForm(f => ({ ...f, evolution_url: e.target.value }))}
                    placeholder="https://evo.seudominio.com.br"
                    className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30" />
                </Field>
                <Field label="Instância">
                  <input value={integForm.evolution_instance}
                    onChange={e => setIntegForm(f => ({ ...f, evolution_instance: e.target.value }))}
                    placeholder="controllares"
                    className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30" />
                </Field>
                <Field label="API Key da instância">
                  <input type={showSecrets ? "text" : "password"} value={integForm.evolution_apikey}
                    onChange={e => setIntegForm(f => ({ ...f, evolution_apikey: e.target.value }))}
                    placeholder="••••••••"
                    className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30" />
                </Field>
              </div>
            </details>

            <Button variant="outline" size="sm"
              disabled={testandoWpp || !integForm.whatsapp_numero || (!integForm.whatsapp_apikey && !integForm.evolution_url)}
              onClick={async () => {
                setTestandoWpp(true)
                try {
                  await fetch("/api/empresa", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(integForm) })
                  const r = await fetch("/api/integracoes/whatsapp/testar", { method: "POST" })
                  const j = await r.json().catch(() => ({}))
                  if (!r.ok) {
                    await confirmar({ titulo: j.error || "Falha no envio.", apenasAviso: true })
                    return
                  }
                  /* Resultado número a número. "Enviado com sucesso" quando um
                     dos destinos falhou é pior que erro nenhum: some com o
                     problema e alguém segue sem receber aviso de proposta. */
                  const linhas = (j.resultados ?? []).map(
                    (x: { rotulo: string; numero: string; ok: boolean; motivo?: string }) =>
                      `${x.ok ? "✅" : "❌"} ${x.rotulo} (${x.numero})`
                      + (x.motivo ? `, ${x.motivo}` : ""))
                  await confirmar({
                    titulo: `Teste enviado para ${j.enviados} de ${j.total} número(s)`,
                    texto: [linhas.join("\n"), j.dica].filter(Boolean).join("\n\n"),
                    apenasAviso: true,
                  })
                } finally { setTestandoWpp(false) }
              }}
              className="gap-1.5">
              {testandoWpp ? <><RefreshCw className="w-4 h-4 animate-spin" /> Enviando...</> : "Enviar teste"}
            </Button>
          </div>
          )}

          {/* Gaveta das integrações guardadas.

              A tela listava tudo o que já foi escrito para o sistema, e quem
              precisava do Olist rolava por seis cartões que não lhe dizem
              respeito. O que não está em uso fica aqui, a um clique — some da
              lista principal sem sumir do sistema. */}
          <div className="ios-card p-5">
            <button type="button" onClick={() => setGaveta(v => !v)}
              className="flex w-full items-center justify-between gap-3 text-left">
              <div>
                <h2 className="text-foreground font-medium">Adicionar integração</h2>
                <p className="text-muted-foreground text-xs mt-0.5">
                  {guardadas.length
                    ? `${guardadas.length} disponíve${guardadas.length === 1 ? "l" : "is"} para ativar`
                    : "Todas já estão na lista acima"}
                </p>
              </div>
              <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${gaveta ? "rotate-180" : ""}`} />
            </button>

            {gaveta && (
              <div className="mt-4 space-y-2">
                {guardadas.map(i => (
                  <div key={i.id}
                    className="flex items-center justify-between gap-3 rounded-xl border border-border bg-muted/30 px-3 py-2.5">
                    <div className="min-w-0">
                      <p className="text-[14px] text-foreground">{i.nome}</p>
                      <p className="text-[12px] text-muted-foreground">{i.desc}</p>
                    </div>
                    <Button type="button" size="sm" variant="outline" className="h-8 text-xs"
                      onClick={() => ligarIntegracao(i.id)}>
                      Ativar
                    </Button>
                  </div>
                ))}

                {/* Tirar da lista o que está ativo mas não configurado. O que
                    já tem token continua na tela por segurança e não aparece
                    aqui — esconder o que está em uso é como quebrá-lo. */}
                {INTEGRACOES.filter(i => integracoesAtivas.includes(i.id) && !integracaoConfigurada(i.id)).length > 0 && (
                  <div className="pt-3 mt-1 border-t border-border">
                    <p className="text-[11px] uppercase tracking-wider text-muted-foreground/70 mb-2">Na lista, ainda sem configurar</p>
                    {INTEGRACOES.filter(i => integracoesAtivas.includes(i.id) && !integracaoConfigurada(i.id)).map(i => (
                      <div key={i.id} className="flex items-center justify-between gap-3 px-1 py-1.5">
                        <p className="text-[13px] text-muted-foreground">{i.nome}</p>
                        <button type="button" onClick={() => desligarIntegracao(i.id)}
                          className="text-xs text-muted-foreground underline underline-offset-2 hover:text-foreground">
                          Guardar
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="flex items-center justify-between">
            <button type="button" onClick={() => setShowSecrets(s => !s)}
              className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground text-xs transition-colors">
              {showSecrets ? <><EyeOff className="w-3.5 h-3.5" /> Ocultar tokens</> : <><Eye className="w-3.5 h-3.5" /> Mostrar tokens</>}
            </button>
            <Button onClick={salvarInteg} disabled={savingInteg}
              className="gap-1.5">
              {savingInteg
                ? <><RefreshCw className="w-4 h-4 animate-spin" /> Salvando...</>
                : <><Save className="w-4 h-4" /> Salvar Configurações</>
              }
            </Button>
          </div>

          {/* Senhas do Cofre (CORE) */}
          <div className="ios-card p-5 space-y-4">
            <div>
              <h3 className="text-foreground font-medium text-sm">Senhas do Cofre, Assistente CORE</h3>
              <p className="text-muted-foreground text-xs mt-0.5">Senha independente do login, pedida pelo CORE ao acessar credenciais confidenciais. Configure por perfil.</p>
            </div>
            <div className="space-y-3">
              {[
                { role: "ADMIN", label: "Administrador" },
                { role: "RESPONSAVEL_TECNICO", label: "Resp. Técnico" },
                { role: "INSTALADOR", label: "Instalador" },
                { role: "ENGENHEIRO_PROJETOS", label: "Engenheiro" },
                { role: "VENDEDOR", label: "Vendedor" },
                { role: "FINANCEIRO", label: "Financeiro" },
              ].map(({ role, label }) => (
                <div key={role} className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
                  <div className="sm:w-36 sm:flex-shrink-0">
                    <p className="text-sm text-foreground">{label}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {vaultConfigured[role] ? "Senha configurada" : "Sem senha"}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 flex-1 min-w-0">
                    <input
                      type="password"
                      placeholder="Nova senha (mín. 4 chars)"
                      value={vaultForm[role] ?? ""}
                      onChange={e => setVaultForm(f => ({ ...f, [role]: e.target.value }))}
                      onKeyDown={e => e.key === "Enter" && salvarVault(role)}
                      className="flex-1 min-w-0 h-9 rounded-xl bg-muted/50 border border-border px-3 text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-ring"
                    />
                    <Button
                      size="sm"
                      variant={vaultSaved[role] ? "outline" : "default"}
                      onClick={() => salvarVault(role)}
                      disabled={savingVault[role] || !vaultForm[role]?.trim()}
                      className="gap-1.5 w-20 flex-shrink-0"
                    >
                      {vaultSaved[role] ? "Salvo" : savingVault[role] ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : "Salvar"}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        {/* ===================== ABA: ADMIN ===================== */}
        {/* ===================== ABA: SEGURANÇA (só Admin) ===================== */}
        <TabsContent value="sistema" className="mt-6 space-y-4">
          {/* Porta do painel. Sem o codigo do autenticador, nada abaixo carrega —
              e nada e buscado do servidor: as rotas exigem a mesma liberacao. */}
          {!liberado ? (
            <div className="ios-card mx-auto max-w-md p-6 text-center">
              <div className="mx-auto mb-3 grid size-12 place-items-center rounded-2xl bg-ios-blue/10">
                <ShieldAlert className="h-6 w-6 text-ios-blue" />
              </div>
              <h2 className="text-[16px] font-medium text-foreground">Painel Sistema</h2>
              <p className="mx-auto mt-2 max-w-sm text-[13px] leading-relaxed text-muted-fg">
                Esta tela mostra tentativas de invasao, enderecos de acesso e o que
                ainda esta aberto no sistema. Confirme o codigo do seu aplicativo
                autenticador para entrar, estar logado como Admin nao basta.
              </p>

              {!temSegundoFator ? (
                <p className="mt-5 rounded-xl bg-ios-orange/10 px-3.5 py-3 text-[13px] leading-relaxed text-ios-orange">
                  Sua conta ainda nao tem segundo fator. Ative em Configuracoes e
                  Empresa, depois volte aqui.
                </p>
              ) : (
                <>
                  <input
                    value={codigoSistema} inputMode="numeric" maxLength={6}
                    autoComplete="one-time-code"
                    onChange={e => setCodigoSistema(e.target.value.replace(/\D/g, ""))}
                    onKeyDown={e => { if (e.key === "Enter" && codigoSistema.length === 6) abrirPorta() }}
                    placeholder="000000"
                    className="mt-5 h-12 w-full rounded-xl border border-border bg-muted text-center font-mono text-[22px] tracking-[.35em] text-foreground outline-none focus:border-ring"
                  />
                  {erroPorta && <p className="mt-2.5 text-[13px] text-ios-red">{erroPorta}</p>}
                  <Button className="mt-3 h-11 w-full"
                    disabled={abrindoPorta || codigoSistema.length !== 6} onClick={abrirPorta}>
                    {abrindoPorta ? "Conferindo..." : "Entrar"}
                  </Button>
                  <p className="mt-4 text-[12px] leading-relaxed text-muted-fg">
                    A liberacao dura 20 minutos. Quando um tecnico precisar mexer no
                    sistema, ele entra com o login dele, o codigo sai do seu aparelho.
                  </p>
                </>
              )}
            </div>
          ) : (
          <>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-[13px] text-muted-fg">
              Liberado por 20 minutos. {carregandoVigia && "Lendo eventos..."}
            </p>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="h-8" onClick={carregarVigia}>
                Atualizar
              </Button>
              <Button variant="outline" size="sm" className="h-8" onClick={sairDoPainel}>
                Fechar painel
              </Button>
            </div>
          </div>

          {vigia && (
            <div className="ios-card p-5">
              <h2 className="text-[15px] font-medium text-foreground">O que destoa</h2>
              {vigia.anomalias.length === 0 ? (
                <p className="mt-2 text-[13px] text-muted-fg">
                  Nada fora do padrao nos ultimos 7 dias.
                </p>
              ) : (
                <div className="mt-3 space-y-2.5">
                  {vigia.anomalias.map(a => (
                    <div key={a.chave}
                      className={`rounded-xl border p-3.5 ${a.gravidade === "alta" ? "border-ios-red/30 bg-ios-red/[0.06]" : "border-ios-orange/30 bg-ios-orange/[0.06]"}`}>
                      <p className={`text-[14px] font-medium ${a.gravidade === "alta" ? "text-ios-red" : "text-ios-orange"}`}>
                        {a.titulo}
                      </p>
                      <p className="mt-1 text-[13px] leading-relaxed text-foreground/80">{a.detalhe}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Acesso de endereco novo nao acusa nada sozinho: viagem e rede movel
              tambem produzem IP novo. Serve para o Admin reconhecer o time. */}
          {!!vigia?.lugaresNovos?.length && (
            <div className="ios-card p-5">
              <h2 className="text-[15px] font-medium text-foreground">Entradas de lugar novo</h2>
              <p className="mt-1 text-[12px] text-muted-fg">
                Endereco que essa conta nunca tinha usado. Viagem e rede de celular
                aparecem aqui tambem, o que importa e voce reconhecer a pessoa.
              </p>
              <div className="mt-3 space-y-2">
                {vigia.lugaresNovos.map((l, i) => (
                  <div key={i} className="rounded-lg bg-foreground/[0.04] px-3 py-2.5">
                    <p className="text-[13px] text-foreground">{l.email}</p>
                    <p className="text-[12px] text-muted-fg">
                      {l.ip} · {new Date(l.quando).toLocaleString("pt-BR")}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {!!vigia?.contasEstranhas?.length && (
            <div className="ios-card p-5">
              <h2 className="text-[15px] font-medium text-foreground">Contas nao ativas</h2>
              <p className="mt-1 text-[12px] text-muted-fg">
                Cadastro pendente e o caminho mais silencioso para alguem aparecer
                dentro da empresa sem ninguem reparar.
              </p>
              <div className="mt-3 space-y-2">
                {vigia.contasEstranhas.map(c => (
                  <div key={c.id} className="flex items-center justify-between gap-3 rounded-lg bg-foreground/[0.04] px-3 py-2.5">
                    <div className="min-w-0">
                      <p className="truncate text-[13px] text-foreground">{c.nome} · {c.email}</p>
                      <p className="text-[12px] text-muted-fg">{c.role}</p>
                    </div>
                    <span className="shrink-0 rounded-full bg-ios-orange/15 px-2 py-0.5 text-[11px] text-ios-orange">
                      {c.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {!!vigia?.bloqueios?.length && (
            <div className="ios-card p-5">
              <h2 className="text-[15px] font-medium text-foreground">Bloqueios em vigor</h2>
              <div className="mt-3 space-y-2">
                {vigia.bloqueios.map((b, i) => (
                  <div key={i} className="rounded-lg bg-foreground/[0.04] px-3 py-2.5">
                    <p className="text-[13px] text-foreground">{b.chave}</p>
                    <p className="text-[12px] text-muted-fg">
                      {b.tentativas} tentativas · ate {new Date(b.bloqueadoAte).toLocaleString("pt-BR")}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Fichas do catálogo. Fica aqui porque gasta cota de busca e reescreve
              campo de produto — e porque a regra que governa isso é de risco:
              sem fonte, nada é preenchido. */}
          <div className="ios-card p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <h2 className="text-[15px] font-medium text-foreground">Fichas do catálogo</h2>
                <p className="mt-1 text-[13px] leading-relaxed text-muted-fg">
                  Busca a especificação no site do fabricante e grava o link da fonte
                  junto. O que não tiver fonte fica vazio e entra na lista abaixo —
                  nada é preenchido por estimativa.
                </p>
              </div>
              <Button size="sm" className="h-8 shrink-0"
                disabled={enriquecendo || !ficha?.pendentes} onClick={enriquecerFichas}>
                {enriquecendo ? "Buscando..." : "Preencher o que der"}
              </Button>
            </div>

            {ficha && (
              <div className="mt-4 grid grid-cols-3 gap-2.5">
                <div className="rounded-xl bg-foreground/[0.04] p-3">
                  <p className="text-[22px] font-semibold leading-none text-ios-green">{ficha.encontradas}</p>
                  <p className="mt-1.5 text-[12px] text-muted-fg">com ficha</p>
                </div>
                <div className="rounded-xl bg-foreground/[0.04] p-3">
                  <p className="text-[22px] font-semibold leading-none text-foreground">{ficha.pendentes}</p>
                  <p className="mt-1.5 text-[12px] text-muted-fg">na fila</p>
                </div>
                <div className="rounded-xl bg-foreground/[0.04] p-3">
                  <p className="text-[22px] font-semibold leading-none text-ios-orange">{ficha.semFonte}</p>
                  <p className="mt-1.5 text-[12px] text-muted-fg">sem fonte</p>
                </div>
              </div>
            )}

            {progressoFicha && (
              <p className="mt-3 text-[13px] text-foreground/80">{progressoFicha}</p>
            )}
            {erroFicha && <p className="mt-3 text-[13px] text-ios-red">{erroFicha}</p>}

            {!!ficha?.marcas?.length && (
              <>
                <p className="mt-4 text-[12px] text-muted-fg">Ainda na fila, por marca:</p>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {ficha.marcas.slice(0, 14).map(m => (
                    <span key={m.marca}
                      className="rounded-full bg-foreground/[0.06] px-2.5 py-1 text-[11px] text-muted-fg">
                      {m.marca} · {m.pendentes}
                    </span>
                  ))}
                </div>
              </>
            )}

            {!!ficha?.semFonte && (
              <p className="mt-4 rounded-xl bg-ios-orange/10 px-3.5 py-3 text-[12px] leading-relaxed text-ios-orange">
                {ficha.semFonte} produto(s) sem fonte encontrada. Para esses, o
                catálogo do fabricante precisa vir de você, sem material, o campo
                continua vazio de propósito.
              </p>
            )}
          </div>

          {/* O resumo diz que houve falhas; so a lista mostra de onde vieram. */}
          {!!vigia?.eventos?.length && (
            <div className="ios-card p-5">
              <h2 className="text-[15px] font-medium text-foreground">Ultimos eventos</h2>
              <div className="mt-3 max-h-[420px] space-y-1.5 overflow-y-auto pr-1">
                {vigia.eventos.map(e => (
                  <div key={e.id} className="flex items-start gap-2.5 rounded-lg px-2.5 py-2 hover:bg-foreground/[0.04]">
                    <span className={`mt-1.5 size-1.5 shrink-0 rounded-full ${e.gravidade === "alta" ? "bg-ios-red" : e.gravidade === "media" ? "bg-ios-orange" : "bg-ios-green"}`} />
                    <div className="min-w-0 flex-1">
                      <p className="text-[13px] leading-snug text-foreground">{e.descricao}</p>
                      <p className="text-[11px] text-muted-fg">
                        {new Date(e.createdAt).toLocaleString("pt-BR")}
                        {e.ip && ` · ${e.ip}`}
                        {e.email && ` · ${e.email}`}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="ios-card p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <h2 className="flex items-center gap-2 text-[15px] font-medium text-foreground">
                  <ShieldAlert className="h-4 w-4 text-ios-blue" /> Estado da segurança
                </h2>
                <p className="mt-1 text-[13px] leading-relaxed text-muted-fg">
                  Cada linha é medida agora, não escrita à mão. O que não dá para
                  verificar daqui aparece como externo, um item honesto vale mais
                  que um verde inventado.
                </p>
              </div>
              <Button variant="outline" size="sm" className="h-8 shrink-0"
                disabled={carregandoSeg} onClick={carregarSeguranca}>
                {carregandoSeg ? "Medindo..." : "Medir de novo"}
              </Button>
            </div>
            {medidoEm && (
              <p className="mt-2.5 text-[12px] text-muted-fg">
                Última medição: {new Date(medidoEm).toLocaleString("pt-BR")}
              </p>
            )}
            {erroSeg && <p className="mt-2 text-[12px] text-ios-red">{erroSeg}</p>}
          </div>

          {/* Contagem por estado: o resumo é o que se olha antes de ler tudo. */}
          {seguranca && (
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
              {([
                { e: "ok", rot: "Em dia", cor: "text-ios-green" },
                { e: "atencao", rot: "Atenção", cor: "text-ios-orange" },
                { e: "falta", rot: "Falta fazer", cor: "text-ios-red" },
                { e: "externo", rot: "Fora do sistema", cor: "text-muted-fg" },
              ] as const).map(({ e, rot, cor }) => (
                <div key={e} className="rounded-xl border border-hairline bg-surface-1 p-3.5">
                  <p className={`text-[24px] font-semibold leading-none ${cor}`}>
                    {seguranca.filter(i => i.estado === e).length}
                  </p>
                  <p className="mt-1.5 text-[12px] text-muted-fg">{rot}</p>
                </div>
              ))}
            </div>
          )}

          {seguranca?.map(item => {
            const Icone = item.estado === "ok" ? CircleCheck
              : item.estado === "falta" ? CircleX
              : item.estado === "externo" ? ExternalLink : CircleAlert
            const cor = item.estado === "ok" ? "text-ios-green"
              : item.estado === "falta" ? "text-ios-red"
              : item.estado === "externo" ? "text-muted-fg" : "text-ios-orange"
            return (
              <div key={item.chave} className="rounded-xl border border-hairline bg-surface-1 p-4">
                <div className="flex items-start gap-3">
                  <Icone className={`mt-0.5 h-4 w-4 shrink-0 ${cor}`} />
                  <div className="min-w-0 flex-1">
                    <p className="text-[14px] font-medium text-foreground">{item.titulo}</p>
                    <p className="mt-0.5 text-[13px] leading-relaxed text-muted-fg">{item.detalhe}</p>
                    {/* A evidência é o que sustenta o estado, sem ela o painel
                        volta a ser uma lista de afirmações. */}
                    <p className="mt-2 rounded-lg bg-foreground/[0.04] px-2.5 py-2 text-[12px] leading-relaxed text-foreground/75">
                      {item.evidencia}
                    </p>
                    {item.acao && item.estado !== "ok" && (
                      <p className="mt-1.5 text-[12px] leading-relaxed text-muted-fg">
                        <span className="text-foreground/70">O que fazer:</span> {item.acao}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )
          })}

          {!seguranca && !carregandoSeg && !erroSeg && (
            <div className="rounded-xl border border-hairline bg-surface-1 p-8 text-center">
              <p className="text-[13px] text-muted-fg">Abrindo a medição...</p>
            </div>
          )}
          </>
          )}
        </TabsContent>

        <TabsContent value="admin" className="mt-6">
          <AdminView />
        </TabsContent>
      </Tabs>
      </>
      )}

      {/* Dialog criar/editar usuário */}
      <Dialog open={userOpen} onOpenChange={setUserOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editUserId ? "Editar Colaborador" : "Novo Colaborador"}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 px-5 sm:px-6 py-4">
            <Field label="Nome completo *">
              <TextInput value={userForm.nome}
                onChange={v => setUserForm(f => ({ ...f, nome: v }))}
                placeholder="João Silva" />
            </Field>

            <Field label="E-mail *">
              <TextInput value={userForm.email} type="email"
                disabled={!!editUserId}
                onChange={v => setUserForm(f => ({ ...f, email: v }))}
                placeholder="joao@empresa.com" />
              {editUserId && <p className="text-muted-foreground/60 text-xs mt-1">E-mail não pode ser alterado</p>}
            </Field>

            <p className="text-muted-foreground/70 text-xs bg-muted/40 border border-border rounded-xl px-3 py-2">
              🔒 A senha é criada pelo próprio colaborador pelo link de convite. O admin nunca vê nem define senha.
            </p>

            <Field label="Perfil de acesso *">
              <select value={userForm.role}
                onChange={e => setUserForm(f => ({ ...f, role: e.target.value as Role }))}
                className="w-full bg-muted/50 border border-border rounded-xl px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/30">
                {(Object.keys(ROLE_LABEL) as Role[]).map(r => (
                  <option key={r} value={r}>{ROLE_LABEL[r]}</option>
                ))}
              </select>
              <p className="text-muted-foreground/60 text-xs mt-1">{ROLE_DESC[userForm.role]}</p>
            </Field>

            <Field label="Perfis adicionais (opcional)">
              <div className="flex flex-wrap gap-2">
                {(Object.keys(ROLE_LABEL) as Role[]).filter(r => r !== userForm.role).map(r => {
                  const sel = userForm.roles.includes(r)
                  return (
                    <button key={r} type="button"
                      onClick={() => setUserForm(f => ({
                        ...f, roles: sel ? f.roles.filter(x => x !== r) : [...f.roles, r],
                      }))}
                      className={`px-3 py-1 rounded-full text-xs border transition-colors ${
                        sel ? "bg-foreground text-background border-foreground" : "bg-muted/60 border-border text-foreground/80 hover:text-foreground"
                      }`}>
                      {ROLE_LABEL[r]}
                    </button>
                  )
                })}
              </div>
              <p className="text-muted-foreground/60 text-xs mt-1">O colaborador acumula os acessos do perfil principal + os adicionais.</p>
            </Field>

            {userErro && (
              <p className="text-red-400 text-xs bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
                {userErro}
              </p>
            )}
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setUserOpen(false)} disabled={savingUser}
              className="">
              Cancelar
            </Button>
            <Button onClick={salvarUser} disabled={savingUser}
              className="gap-1.5">
              {savingUser
                ? <><RefreshCw className="w-4 h-4 animate-spin" /> Salvando...</>
                : "Salvar"
              }
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

/** Linha do painel de entrada: o que é, em que estado está e o verbo da ação. */
function LinhaAtalho({ titulo, contexto, acao, aoClicar }: {
  titulo: string
  contexto: string
  acao: string
  aoClicar: () => void
}) {
  return (
    <button type="button" onClick={aoClicar}
      className="flex w-full items-center justify-between gap-3 rounded-2xl bg-foreground/[0.03] px-4 py-3 text-left transition-colors hover:bg-foreground/[0.06]">
      <span className="min-w-0">
        <span className="block truncate text-[14px] font-medium text-foreground">{titulo}</span>
        <span className="block truncate text-[12px] text-muted-foreground">{contexto}</span>
      </span>
      <span className="shrink-0 text-[13px] font-medium text-muted-foreground">{acao}</span>
    </button>
  )
}
