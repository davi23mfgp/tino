"use client"

/**
 * Base de conhecimento do CORE.
 *
 * O CORE já sabe responder sobre os dados do sistema. Aqui entra o que é texto
 * corrido — manual de equipamento, norma, procedimento interno, memorial. O
 * conteúdo é fatiado e indexado; nas perguntas, os trechos mais próximos vão
 * junto no prompt e o CORE cita a origem.
 */
import { useState, useEffect, useCallback } from "react"
import { BookOpen, Trash2, RefreshCw, AlertCircle, FileText, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useConfirmar } from "@/components/confirmar"

interface Doc {
  id: string
  titulo: string
  origem: string
  fonte: string | null
  roles: string[]
  tags: string[]
  status: string
  erro: string | null
  chars: number
  chunks: number
  createdAt: string
}



/**
 * A pasta do Drive que alimenta o CORE.
 *
 * Escolher a pasta é a configuração inteira: dali em diante o que a equipe já
 * guarda vira base de conhecimento sozinho, e o que sai da pasta sai da base —
 * procedimento revogado que continuasse respondendo seria pior que não ter base.
 */
function PastaDrive({ aoSincronizar }: { aoSincronizar: () => void }) {
  const [estado, setEstado] = useState<{
    conectado: boolean; pastaId: string | null; pastaNome: string | null
    ultimaSync: string | null; documentos: number
    pastas: { id: string; nome: string }[]
  } | null>(null)
  const [ocupado, setOcupado] = useState(false)
  const [aviso, setAviso] = useState("")

  const ler = useCallback(async () => {
    const r = await fetch("/api/integracoes/google/drive/conhecimento", { cache: "no-store" })
      .catch(() => null)
    if (r?.ok) setEstado(await r.json())
  }, [])
  useEffect(() => { ler() }, [ler])

  async function escolher(pastaId: string) {
    const pasta = estado?.pastas.find(p => p.id === pastaId)
    setOcupado(true); setAviso("")
    await fetch("/api/integracoes/google/drive/conhecimento", {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pastaId, pastaNome: pasta?.nome ?? "" }),
    }).catch(() => {})
    await ler()
    setOcupado(false)
  }

  async function sincronizar() {
    setOcupado(true); setAviso("")
    try {
      const r = await fetch("/api/integracoes/google/drive/conhecimento", { method: "POST" })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { setAviso(j.error ?? "Não foi possível sincronizar."); return }
      const partes = [
        j.indexados ? `${j.indexados} novo(s)` : "",
        j.atualizados ? `${j.atualizados} atualizado(s)` : "",
        j.removidos ? `${j.removidos} removido(s)` : "",
        j.ignorados ? `${j.ignorados} sem mudança` : "",
      ].filter(Boolean)
      setAviso(partes.length ? partes.join(", ") + "." : "Nada novo na pasta.")
      /* O motivo de cada arquivo que ficou de fora, e não só a contagem: PDF
         escaneado e arquivo grande demais pedem ações diferentes. */
      if (j.erros?.length) {
        setAviso(a => a + " " + j.erros
          .map((e: { arquivo: string; motivo: string }) => `${e.arquivo}: ${e.motivo}`)
          .join("; "))
      }
      aoSincronizar()
      await ler()
    } catch { setAviso("Falha de conexão.") }
    finally { setOcupado(false) }
  }

  if (!estado) return null

  if (!estado.conectado) {
    return (
      <div className="rounded-xl border border-hairline bg-surface-1 p-4">
        <p className="text-[13px] text-foreground">Google Drive não conectado.</p>
        <p className="mt-1 text-[12px] leading-relaxed text-muted-foreground">
          A base do CORE vem de uma pasta do seu Drive. Conecte em{" "}
          <strong className="text-foreground">Integrações → Google Drive</strong> e volte aqui
          para escolher a pasta.
        </p>
      </div>
    )
  }

  return (
    <div className="rounded-xl border border-hairline bg-surface-1 p-4 space-y-3">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <label className="min-w-0 flex-1 space-y-1">
          <span className="text-[11px] text-muted-foreground">Pasta do Drive</span>
          <select value={estado.pastaId ?? ""} disabled={ocupado}
            onChange={e => escolher(e.target.value)}
            className="h-10 w-full rounded-xl border border-border bg-muted px-2.5 text-[13px] text-foreground outline-none">
            <option value="">Escolha a pasta</option>
            {estado.pastas.map(p => <option key={p.id} value={p.id}>{p.nome}</option>)}
          </select>
        </label>
        <Button size="sm" disabled={ocupado || !estado.pastaId}
          onClick={sincronizar} className="gap-1.5">
          <RefreshCw className={`h-3.5 w-3.5 ${ocupado ? "animate-spin" : ""}`} />
          {ocupado ? "Lendo a pasta..." : "Sincronizar agora"}
        </Button>
      </div>

      <p className="text-[12px] leading-relaxed text-muted-foreground">
        {estado.documentos} documento(s) vindos do Drive.{" "}
        {estado.ultimaSync
          ? `Última leitura em ${new Date(estado.ultimaSync).toLocaleString("pt-BR")}.`
          : "Ainda não foi lida."}
        {" "}A pasta é lida de novo todo dia, junto com o backup, arquivo que não mudou
        não é processado outra vez.
      </p>

      {!!aviso && <p className="text-[12px] leading-relaxed text-foreground/80">{aviso}</p>}
    </div>
  )
}

export function ConhecimentoTab() {
  const confirmar = useConfirmar()
  const [docs, setDocs] = useState<Doc[] | null>(null)
  const [embeddingsOk, setEmbeddingsOk] = useState(true)
  const [erro, setErro] = useState("")
  const [lista, setLista] = useState(false)

  const carregar = useCallback(async () => {
    const r = await fetch("/api/ai/conhecimento", { cache: "no-store" })
    if (!r.ok) {
      setErro((await r.json().catch(() => ({}))).error ?? "Falha ao listar.")
      setDocs([])
      return
    }
    const j = await r.json()
    setDocs(j.docs ?? [])
    setEmbeddingsOk(j.embeddingsOk !== false)
  }, [])
  useEffect(() => { carregar() }, [carregar])

  async function excluir(d: Doc) {
    if (!await confirmar({ titulo: `Remover "${d.titulo}" da base? O CORE deixa de usar este conteúdo.`, perigo: true })) return
    const r = await fetch(`/api/ai/conhecimento/${d.id}`, { method: "DELETE" })
    if (r.ok) carregar()
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="flex items-center gap-2 font-medium text-foreground">
            <BookOpen className="h-4 w-4 text-primary" /> Base de conhecimento do CORE
          </h2>
          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
            Manuais, normas e procedimentos que o CORE consulta ao responder. A fonte é
            uma pasta do seu Google Drive: o que estiver lá é lido, fatiado e indexado.
          </p>
        </div>
      </div>

      {/* A pasta do Drive é a fonte, e por isso vem antes de tudo.

          O upload manual saiu: base que depende de alguém lembrar de subir
          arquivo envelhece calada — o procedimento muda, o PDF novo fica na
          pasta da equipe, e o CORE segue respondendo pelo antigo. */}
      <PastaDrive aoSincronizar={carregar} />

      {!embeddingsOk && (
        <div className="flex items-start gap-2.5 rounded-xl bg-ios-orange/10 px-3.5 py-3">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-ios-orange" />
          <p className="text-[13px] leading-relaxed text-foreground/90">
            Falta configurar a chave de embeddings. Defina <code>EMBED_API_KEY</code> (ou
            reaproveite <code>AI_API_KEY</code>) nas variáveis de ambiente, sem ela não dá
            para indexar nem buscar.
          </p>
        </div>
      )}

      {erro && <p className="text-sm text-ios-red">{erro}</p>}

      {docs === null ? (
        <p className="text-sm text-muted-foreground">Carregando…</p>
      ) : docs.length === 0 ? (
        <div className="ios-card px-5 py-10 text-center">
          <FileText className="mx-auto mb-2 h-5 w-5 text-muted-fg" strokeWidth={1.5} />
          <p className="text-sm font-medium text-foreground">Nenhum documento ainda</p>
          <p className="mt-0.5 text-xs text-muted-fg">
            Suba um manual ou cole um procedimento para o CORE começar a usar.
          </p>
        </div>
      ) : (
        <div className="overflow-hidden ios-card">
          {/* Fechada por padrão: a lista de documentos é conferência, não
              trabalho do dia. O que precisa estar à vista é quantos entraram e
              se algum falhou — e isso cabe no cabeçalho. */}
          <button type="button" onClick={() => setLista(v => !v)}
            className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left">
            <span className="min-w-0">
              <span className="block text-sm font-medium text-foreground">
                {docs.length} documento{docs.length === 1 ? "" : "s"} na base
              </span>
              <span className="block text-xs text-muted-fg">
                {(() => {
                  const comErro = docs.filter(d => d.status === "ERRO").length
                  const trechos = docs.reduce((n, d) => n + d.chunks, 0)
                  return comErro
                    ? `${comErro} com erro · ${trechos} trecho(s) indexado(s)`
                    : `${trechos} trecho(s) indexado(s)`
                })()}
              </span>
            </span>
            <ChevronDown className={`h-4 w-4 shrink-0 text-muted-fg transition-transform ${lista ? "rotate-180" : ""}`} />
          </button>

          {lista && (
          <div className="divide-y divide-hairline border-t border-hairline">
          {docs.map(d => (
            <div key={d.id} className="flex items-center gap-3 px-4 py-3">
              <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${
                d.status === "PRONTO" ? "bg-ios-green" : d.status === "ERRO" ? "bg-ios-red" : "bg-muted-fg/40"
              }`} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-foreground">{d.titulo}</p>
                <p className="mt-0.5 truncate text-xs text-muted-fg">
                  {d.chunks} trecho{d.chunks === 1 ? "" : "s"}
                  {d.chars > 0 && ` · ${Math.round(d.chars / 1000)} mil caracteres`}
                  {d.roles.length > 0 && ` · restrito a ${d.roles.length} perfil(is)`}
                  {d.fonte && ` · ${d.fonte}`}
                </p>
                {d.erro && (
                  <p className="mt-1 flex items-start gap-1.5 text-xs text-ios-red">
                    <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {d.erro}
                  </p>
                )}
              </div>
              <button onClick={() => excluir(d)} title="Remover da base"
                className="shrink-0 p-1.5 text-muted-fg transition-colors hover:text-ios-red">
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))}
          </div>
          )}
        </div>
      )}

    </div>
  )
}
