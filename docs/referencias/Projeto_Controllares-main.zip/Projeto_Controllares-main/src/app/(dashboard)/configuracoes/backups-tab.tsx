"use client"

/**
 * Backups da empresa.
 *
 * A restauração é aditiva de propósito: só recria o que sumiu, nunca
 * sobrescreve o que existe hoje. Restaurar um backup antigo não pode apagar
 * o trabalho feito depois dele.
 */
import { useState, useEffect, useCallback } from "react"
import { Database, Download, RotateCcw, RefreshCw, AlertCircle, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"

interface Backup {
  id: string
  origem: string
  resumo: Record<string, number>
  tamanho_bytes: number
  erro: string | null
  createdAt: string
  temArquivo: boolean
}

const fmtData = (iso: string) =>
  new Date(iso).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" })

const fmtTamanho = (b: number) =>
  b >= 1_048_576 ? `${(b / 1_048_576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`

export function BackupsTab() {
  const [backups, setBackups] = useState<Backup[] | null>(null)
  const [gerando, setGerando] = useState(false)
  const [erro, setErro] = useState("")
  const [restaurar, setRestaurar] = useState<Backup | null>(null)
  const [restaurando, setRestaurando] = useState(false)
  const [resultado, setResultado] = useState<string>("")

  /* Trinta snapshots empilhados, um por dia, todos com o mesmo texto: a lista
     vira parede e achar o de uma data específica é rolar contando. Filtro por
     origem e por mês, e só o mês corrente aberto — o resto fica a um clique. */
  const [filtroOrigem, setFiltroOrigem] = useState<"todos" | "AUTOMATICO" | "MANUAL">("todos")
  const [mesAberto, setMesAberto] = useState<string | null>(null)

  const visiveis = (backups ?? []).filter(b => filtroOrigem === "todos" || b.origem === filtroOrigem)

  /* Agrupa por mês preservando a ordem que veio do servidor (mais novo
     primeiro). Um Map mantém a ordem de inserção; um objeto comum reordenaria
     as chaves e agosto viria depois de setembro. */
  const grupos = (() => {
    const mapa = new Map<string, typeof visiveis>()
    for (const b of visiveis) {
      const d = new Date(b.createdAt)
      const chave = d.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })
      const atual = mapa.get(chave)
      if (atual) atual.push(b)
      else mapa.set(chave, [b])
    }
    return [...mapa.entries()]
  })()

  const carregar = useCallback(async () => {
    const r = await fetch("/api/backups", { cache: "no-store" })
    if (!r.ok) { setErro((await r.json().catch(() => ({}))).error ?? "Falha ao listar."); setBackups([]); return }
    setBackups((await r.json()).backups ?? [])
  }, [])
  useEffect(() => { carregar() }, [carregar])

  async function gerarAgora() {
    setGerando(true); setErro("")
    try {
      const r = await fetch("/api/backups", { method: "POST" })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { setErro(j.error ?? "Falha ao gerar backup."); return }
      await carregar()
    } finally { setGerando(false) }
  }

  async function confirmarRestauracao() {
    if (!restaurar) return
    setRestaurando(true); setResultado("")
    try {
      const r = await fetch(`/api/backups/${restaurar.id}`, { method: "POST" })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { setResultado(j.error ?? "Falha ao restaurar."); return }
      setResultado(
        `${j.restauradas} proposta(s) recriada(s). ${j.jaExistiam} já existiam e foram mantidas intactas.` +
        (j.falhas?.length ? ` Falhas: ${j.falhas.join("; ")}` : "")
      )
    } finally { setRestaurando(false) }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="flex items-center gap-2 font-medium text-foreground">
            <Database className="h-4 w-4 text-primary" /> Backups
          </h2>
          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
            Um snapshot automático por dia, às 6h. Guarda propostas, obras, catálogo e cadastros —
            sem senhas nem tokens. Ficam os 30 mais recentes.
          </p>
        </div>
        <Button size="sm" onClick={gerarAgora} disabled={gerando} className="gap-1.5">
          {gerando ? <><RefreshCw className="h-4 w-4 animate-spin" /> Gerando…</> : "Gerar backup agora"}
        </Button>
      </div>

      {erro && <p className="text-sm text-ios-red">{erro}</p>}

      {backups === null ? (
        <p className="text-sm text-muted-foreground">Carregando…</p>
      ) : backups.length === 0 ? (
        <div className="ios-card px-5 py-8 text-center">
          <p className="text-sm font-medium text-foreground">Nenhum backup ainda</p>
          <p className="mt-1 text-xs text-muted-fg">O primeiro automático roda amanhã às 6h.</p>
        </div>
      ) : (
        <>
          {/* Filtro por origem. O backup manual é o que alguém tirou antes de
              uma mudança grande — é o que se procura sob pressão, e ele estava
              perdido no meio dos automáticos. */}
          <div className="flex flex-wrap items-center gap-2">
            {([["todos", "Todos"], ["MANUAL", "Manuais"], ["AUTOMATICO", "Automáticos"]] as const).map(([id, label]) => {
              const quantos = id === "todos" ? backups.length : backups.filter(b => b.origem === id).length
              return (
                <button key={id} type="button" onClick={() => setFiltroOrigem(id)}
                  className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
                    filtroOrigem === id
                      ? "bg-foreground text-background"
                      : "bg-muted text-muted-fg hover:text-foreground"
                  }`}>
                  {label}
                  <span className={`rounded-full px-1.5 text-[10px] font-bold ${
                    filtroOrigem === id ? "bg-background/20" : "bg-hairline"
                  }`}>{quantos}</span>
                </button>
              )
            })}
          </div>

          {grupos.length === 0 ? (
            <div className="ios-card px-5 py-8 text-center">
              <p className="text-sm text-muted-fg">Nenhum backup com esse filtro.</p>
            </div>
          ) : grupos.map(([mes, lista], i) => {
            // O mês mais recente abre sozinho: é onde está o backup de ontem.
            const aberto = mesAberto === null ? i === 0 : mesAberto === mes
            return (
              <div key={mes} className="ios-card overflow-hidden">
                <button type="button"
                  onClick={() => setMesAberto(aberto ? "" : mes)}
                  className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left transition-colors hover:bg-muted/40">
                  <span className="text-sm font-medium capitalize text-foreground">{mes}</span>
                  <span className="flex items-center gap-2">
                    <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-medium text-muted-fg">
                      {lista.length} backup{lista.length === 1 ? "" : "s"}
                    </span>
                    <ChevronDown className={`h-4 w-4 text-muted-fg transition-transform ${aberto ? "rotate-180" : ""}`} />
                  </span>
                </button>

                {aberto && (
                  <div className="divide-y divide-hairline border-t border-hairline">
                    {lista.map(b => (
            <div key={b.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-2 text-sm text-foreground">
                  {fmtData(b.createdAt)}
                  <span className="rounded-full bg-muted px-2 py-0.5 text-[10px] uppercase tracking-wide text-muted-fg">
                    {b.origem === "MANUAL" ? "manual" : "automático"}
                  </span>
                </p>
                <p className="mt-0.5 text-xs text-muted-fg">
                  {Object.entries(b.resumo ?? {})
                    .filter(([, n]) => n > 0)
                    .map(([k, n]) => `${n} ${k}`)
                    .join(" · ") || "vazio"}
                  {" · "}{fmtTamanho(b.tamanho_bytes)}
                </p>
                {b.erro && (
                  <p className="mt-1 flex items-center gap-1.5 text-xs text-ios-red">
                    <AlertCircle className="h-3.5 w-3.5 shrink-0" /> {b.erro}
                  </p>
                )}
              </div>
              <div className="flex shrink-0 items-center gap-1.5">
                <a href={`/api/backups/${b.id}`}
                  className="inline-flex h-8 items-center gap-1.5 rounded-full px-3 text-xs font-medium text-muted-fg transition-colors hover:bg-muted hover:text-foreground">
                  <Download className="h-3.5 w-3.5" /> Baixar
                </a>
                <button type="button" onClick={() => { setRestaurar(b); setResultado("") }}
                  className="inline-flex h-8 items-center gap-1.5 rounded-full px-3 text-xs font-medium text-muted-fg transition-colors hover:bg-muted hover:text-foreground">
                  <RotateCcw className="h-3.5 w-3.5" /> Restaurar
                </button>
              </div>
            </div>
                    ))}
                  </div>
                )}
              </div>
            )
          })}
        </>
      )}

      <Dialog open={!!restaurar} onOpenChange={o => { if (!o) { setRestaurar(null); setResultado("") } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-xl">Restaurar backup</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 px-5 py-2 text-sm text-muted-foreground sm:px-6">
            <p>
              Do backup de <b className="text-foreground">{restaurar && fmtData(restaurar.createdAt)}</b>,
              serão recriadas apenas as propostas que <b>não existem mais</b>.
            </p>
            <p>
              O que está no sistema hoje permanece como está, restaurar não sobrescreve
              nem apaga nada.
            </p>
            {resultado && (
              <p className="rounded-xl bg-muted px-3 py-2.5 text-foreground">{resultado}</p>
            )}
          </div>
          <DialogFooter className="gap-2 px-5 pb-4 sm:px-6">
            <Button variant="outline" onClick={() => { setRestaurar(null); setResultado("") }}>
              {resultado ? "Fechar" : "Cancelar"}
            </Button>
            {!resultado && (
              <Button onClick={confirmarRestauracao} disabled={restaurando} className="gap-1.5">
                {restaurando ? <><RefreshCw className="h-4 w-4 animate-spin" /> Restaurando…</> : "Restaurar"}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
