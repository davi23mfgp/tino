"use client"

/**
 * Grupos do Telegram por obra.
 *
 * O bot não cria grupos — a Bot API do Telegram não tem esse método. O que dá
 * para automatizar é o resto: a pessoa cria o grupo, adiciona o bot, e o
 * sistema registra e conecta à obra pelo nome no título. Aqui ficam os grupos
 * detectados e o vínculo manual dos que não casaram sozinhos.
 */
import { useState, useEffect, useCallback } from "react"
import { Send, RefreshCw, Link2, Unlink, AlertCircle, Check } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Grupo {
  id: string
  chatId: string
  titulo: string
  automatico: boolean
  createdAt: string
  obra: { id: string; client_name: string } | null
}

interface ObraLite { id: string; client_name: string }

export function TelegramGruposTab() {
  const [grupos, setGrupos] = useState<Grupo[] | null>(null)
  const [obras, setObras] = useState<ObraLite[]>([])
  const [botConfigurado, setBotConfigurado] = useState(true)
  const [webhookConfigurado, setWebhookConfigurado] = useState(true)
  const [msg, setMsg] = useState("")
  const [erro, setErro] = useState("")
  const [ocupado, setOcupado] = useState(false)

  const carregar = useCallback(async () => {
    const [g, o] = await Promise.all([
      fetch("/api/integracoes/telegram/grupos", { cache: "no-store" }).then(r => r.ok ? r.json() : null),
      fetch("/api/obras", { cache: "no-store" }).then(r => r.ok ? r.json() : { obras: [] }),
    ])
    if (g) {
      setGrupos(g.grupos ?? [])
      setBotConfigurado(g.botConfigurado !== false)
      setWebhookConfigurado(g.webhookConfigurado !== false)
    } else setGrupos([])
    setObras(o?.obras ?? [])
  }, [])
  useEffect(() => { carregar() }, [carregar])

  async function acao(payload: Record<string, unknown>, sucesso?: string) {
    setOcupado(true); setErro(""); setMsg("")
    try {
      const r = await fetch("/api/integracoes/telegram/grupos", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { setErro(j.error ?? "Falha na operação."); return }
      if (sucesso) setMsg(sucesso)
      await carregar()
    } finally { setOcupado(false) }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="flex items-center gap-2 font-medium text-foreground">
            <Send className="h-4 w-4 text-primary" /> Grupos do Telegram
          </h2>
          <p className="mt-1 max-w-2xl text-xs leading-relaxed text-muted-foreground">
            Crie o grupo no Telegram e adicione o bot da empresa. Se o título tiver o nome do
            cliente (ex.: <b>EXECUÇÃO, Julio Filho</b>), o vínculo com a obra é feito na hora.
            Os que não casarem aparecem aqui para ligar à mão.
          </p>
        </div>
        <Button size="sm" variant="outline" disabled={ocupado || !botConfigurado}
          onClick={() => acao({ acao: "registrar_webhook" }, "Bot conectado, já detecta novos grupos.")}
          className="gap-1.5">
          {ocupado ? <><RefreshCw className="h-4 w-4 animate-spin" /> …</> : "Ativar detecção"}
        </Button>
      </div>

      {!botConfigurado && (
        <div className="flex items-start gap-2.5 rounded-xl bg-ios-orange/10 px-3.5 py-3">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-ios-orange" />
          <p className="text-[13px] leading-relaxed text-foreground/90">
            Falta o token do bot. Crie um com o <b>@BotFather</b> no Telegram e cole em
            Integrações → Telegram.
          </p>
        </div>
      )}
      {botConfigurado && !webhookConfigurado && (
        <div className="flex items-start gap-2.5 rounded-xl bg-ios-orange/10 px-3.5 py-3">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-ios-orange" />
          <p className="text-[13px] leading-relaxed text-foreground/90">
            Falta <code>TELEGRAM_WEBHOOK_SECRET</code> no ambiente, é o que autentica o Telegram
            na nossa rota. Sem ele a detecção automática fica desligada.
          </p>
        </div>
      )}

      {erro && <p className="text-sm text-ios-red">{erro}</p>}
      {msg && <p className="flex items-center gap-1.5 text-sm text-ios-green"><Check className="h-4 w-4" /> {msg}</p>}

      {grupos === null ? (
        <p className="text-sm text-muted-foreground">Carregando…</p>
      ) : grupos.length === 0 ? (
        <div className="ios-card px-5 py-8 text-center">
          <p className="text-sm font-medium text-foreground">Nenhum grupo detectado</p>
          <p className="mt-0.5 text-xs text-muted-fg">
            Adicione o bot a um grupo do Telegram e ele aparece aqui.
          </p>
        </div>
      ) : (
        <div className="divide-y divide-hairline overflow-hidden ios-card">
          {grupos.map(g => (
            <div key={g.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
              <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${g.obra ? "bg-ios-green" : "bg-muted-fg/40"}`} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-foreground">{g.titulo}</p>
                <p className="mt-0.5 truncate text-xs text-muted-fg">
                  {g.obra
                    ? `Obra: ${g.obra.client_name}${g.automatico ? " · conectado pelo nome" : ""}`
                    : "Sem obra vinculada"}
                </p>
              </div>
              {g.obra ? (
                <button onClick={() => acao({ acao: "desvincular", grupoId: g.id })}
                  disabled={ocupado}
                  className="flex h-8 shrink-0 items-center gap-1.5 rounded-full px-3 text-xs font-medium text-muted-fg transition-colors hover:bg-muted hover:text-ios-red">
                  <Unlink className="h-3.5 w-3.5" /> Desvincular
                </button>
              ) : (
                <select
                  defaultValue=""
                  disabled={ocupado}
                  onChange={e => { if (e.target.value) acao({ acao: "vincular", grupoId: g.id, obraId: e.target.value }) }}
                  className="h-8 shrink-0 rounded-full bg-muted px-3 text-xs text-foreground outline-none">
                  <option value="">Vincular a…</option>
                  {obras.map(o => <option key={o.id} value={o.id}>{o.client_name}</option>)}
                </select>
              )}
            </div>
          ))}
        </div>
      )}

      <div className="rounded-xl bg-muted/40 px-3.5 py-3">
        <p className="flex items-start gap-2 text-xs leading-relaxed text-muted-foreground">
          <Link2 className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span>
            O Telegram não permite que um bot crie grupos, é limite da plataforma, não do
            sistema. Por isso o grupo é criado por uma pessoa; o resto (detectar, vincular,
            enviar mensagem e arquivo) é automático.
          </span>
        </p>
      </div>
    </div>
  )
}
