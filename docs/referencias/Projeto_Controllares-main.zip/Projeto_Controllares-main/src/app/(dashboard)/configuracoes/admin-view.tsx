"use client"

/**
 * Painel Admin — controle geral num lugar só:
 * números de atividade, integrações, contas vinculadas e mapa de permissões.
 */
import { useState, useEffect } from "react"
import Link from "next/link"
import { ShieldCheck, CheckCircle2, XCircle, KeyRound, CalendarDays } from "lucide-react"
import { PageLoader } from "@/components/ui/bouncing-dots"

interface Overview {
  numeros: { logins_hoje: number; logins_semana: number; cofre_semana: number; eventos_semana: number }
  integracoes: Record<string, boolean>
  usuarios: {
    id: string; nome: string; email: string; role: string; status: string
    twofa: boolean; login_google: boolean; agenda_google: boolean; desde: string
  }[]
  ultimos_eventos: { id: string; tipo: string; descricao: string; usuario: string; timestamp: string }[]
}

const INTEG_LABEL: Record<string, string> = {
  google_oauth: "Google OAuth (login/agenda)",
  telegram: "Telegram (grupos de obra)",
  tiny: "Olist (pedidos)",
  resend: "Resend (e-mails)",
  cofre_configurado: "Senhas do cofre",
}

/**
 * O que cada perfil alcança, escrito a partir do que o menu realmente libera.
 *
 * Este cartão é a única explicação de permissão que existe no produto, e por
 * isso ele diz o que a pessoa TEM, não o que lhe falta. A versão anterior
 * terminava em "Sem obras/financeiro", "Sem credenciais de campo" — cada perfil
 * apresentado pela ausência. Ninguém abre esta tela para descobrir o que não
 * pode; abre para saber onde trabalhar.
 *
 * A lista tem de bater com a tabela de rotas do menu. Descrição que não bate
 * com a permissão é pior que nenhuma: alguém deixa de usar uma tela que já tem,
 * ou pede acesso ao que nunca esteve bloqueado.
 */
const ROLE_PERMS: { role: string; resumo: string }[] = [
  { role: "Administrador", resumo: "Tudo, telas, configurações, análises, financeiro e cofre" },
  { role: "Vendedor", resumo: "CRM inteiro: leads, clientes e parceiros. Propostas, catálogo, categorias, kits e modelos" },
  { role: "Financeiro", resumo: "Todo o financeiro, todo o comercial e todo o operacional. Clientes, parceiros e análises" },
  { role: "Responsável Técnico", resumo: "Todo o operacional: obras sob sua responsabilidade, estoque, agenda e quadro. Suporte e o cofre com senha" },
  { role: "Instalador", resumo: "Obras alocadas, vistorias, agenda e quadro" },
  { role: "Engenheiro de Projetos", resumo: "Obras, projetos, blueprints e anexos técnicos. Agenda, quadro e suporte" },
]

const PARA_TODOS = "Agenda, Quadro e Suporte são de todos os perfis."

export function AdminView() {
  const [data, setData] = useState<Overview | null>(null)
  const [erro, setErro] = useState("")

  useEffect(() => {
    fetch("/api/admin/overview").then(async r => {
      if (r.ok) setData(await r.json())
      else setErro("Sem permissão ou erro ao carregar.")
    }).catch(() => setErro("Erro de conexão."))
  }, [])

  if (erro) return <p className="text-ios-red text-sm py-8 text-center">{erro}</p>
  if (!data) return <PageLoader message="Carregando painel..." />

  const n = data.numeros
  return (
    <div className="space-y-4">
      {/* Números da semana */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
        {[
          { label: "Logins hoje", v: n.logins_hoje, cor: "text-ios-green" },
          { label: "Logins na semana", v: n.logins_semana, cor: "text-ios-blue" },
          { label: "Cofre (7 dias)", v: n.cofre_semana, cor: "text-ios-yellow" },
          { label: "Eventos (7 dias)", v: n.eventos_semana, cor: "text-ios-purple" },
        ].map(c => (
          <div key={c.label} className="ios-card px-4 py-3 flex items-baseline justify-between gap-2">
            <p className="text-[11px] uppercase tracking-[0.08em] text-muted-fg leading-tight">{c.label}</p>
            <p className={`text-[22px] font-bold tracking-tight tabular-nums leading-none ${c.cor}`}>{c.v}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Integrações */}
        <div className="ios-card p-5 space-y-3">
          <h2 className="text-foreground font-medium">Integrações da empresa</h2>
          <div className="space-y-1.5">
            {Object.entries(data.integracoes).map(([k, ok]) => (
              <div key={k} className="flex items-center justify-between py-1">
                <span className="text-[14px] text-foreground/80">{INTEG_LABEL[k] ?? k}</span>
                {ok
                  ? <span className="flex items-center gap-1 text-[12px] font-medium text-ios-green"><CheckCircle2 className="w-3.5 h-3.5" /> Ativa</span>
                  : <span className="flex items-center gap-1 text-[12px] text-muted-fg"><XCircle className="w-3.5 h-3.5" /> Não configurada</span>}
              </div>
            ))}
          </div>
        </div>

        {/* Permissões por perfil */}
        <div className="ios-card p-5 space-y-3">
          <h2 className="text-foreground font-medium">Permissões por perfil</h2>
          <div className="space-y-2">
            {ROLE_PERMS.map(r => (
              <div key={r.role} className="py-1">
                <p className="text-[13px] font-semibold text-foreground">{r.role}</p>
                <p className="text-[12px] text-muted-fg leading-snug">{r.resumo}</p>
              </div>
            ))}
          </div>
          <p className="text-[12px] text-muted-fg leading-snug border-t border-hairline pt-3">
            {PARA_TODOS}
          </p>
        </div>
      </div>

      {/* Contas vinculadas */}
      <div className="ios-card p-5 space-y-3">
        <h2 className="text-foreground font-medium">Contas e vínculos</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-muted-fg text-[11px] uppercase tracking-wide border-b border-hairline">
                <th className="text-left py-2 pr-3 font-medium">Colaborador</th>
                <th className="text-center py-2 px-2 font-medium">Status</th>
                <th className="text-center py-2 px-2 font-medium" title="2FA ativo"><ShieldCheck className="w-3.5 h-3.5 inline" /></th>
                <th className="text-center py-2 px-2 font-medium" title="Login via Google"><KeyRound className="w-3.5 h-3.5 inline" /></th>
                <th className="text-center py-2 px-2 font-medium" title="Google Agenda conectada"><CalendarDays className="w-3.5 h-3.5 inline" /></th>
              </tr>
            </thead>
            <tbody>
              {data.usuarios.map(u => (
                <tr key={u.id} className="border-b border-hairline/50 last:border-0">
                  <td className="py-2.5 pr-3">
                    <p className="text-foreground font-medium text-[13px]">{u.nome}</p>
                    <p className="text-muted-fg text-[11px]">{u.email} · {u.role}</p>
                  </td>
                  <td className="text-center px-2">
                    <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full ${
                      u.status === "ATIVO" ? "bg-ios-green/10 text-ios-green"
                      : u.status === "PENDENTE" ? "bg-ios-orange/10 text-ios-orange"
                      : "bg-ios-red/10 text-ios-red"
                    }`}>{u.status}</span>
                  </td>
                  <td className="text-center px-2">{u.twofa ? "✓" : <span className="text-muted-fg/40">—</span>}</td>
                  <td className="text-center px-2">{u.login_google ? "✓" : <span className="text-muted-fg/40">—</span>}</td>
                  <td className="text-center px-2">{u.agenda_google ? "✓" : <span className="text-muted-fg/40">—</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Últimos eventos */}
      <div className="ios-card p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-foreground font-medium">Últimos eventos</h2>
          <Link href="/logs" className="text-[12px] text-ios-blue hover:underline">Ver todos os logs →</Link>
        </div>
        <div className="divide-y divide-hairline/50">
          {data.ultimos_eventos.map(e => (
            <div key={e.id} className="flex items-center gap-3 py-2">
              <span className="text-[10px] font-semibold uppercase text-muted-fg bg-surface-2 rounded-md px-1.5 py-0.5 flex-shrink-0 w-24 text-center truncate">{e.tipo}</span>
              <p className="flex-1 text-[13px] text-foreground/80 truncate">{e.descricao}</p>
              <span className="text-[11px] text-muted-fg flex-shrink-0">
                {new Date(e.timestamp).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}
              </span>
            </div>
          ))}
          {data.ultimos_eventos.length === 0 && <p className="text-muted-fg text-sm py-4 text-center">Nenhum evento ainda.</p>}
        </div>
      </div>
    </div>
  )
}
