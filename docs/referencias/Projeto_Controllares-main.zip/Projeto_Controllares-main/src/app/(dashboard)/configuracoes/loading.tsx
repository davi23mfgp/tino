export default function Loading() {
  return (
    <div className="flex flex-col gap-4 p-5 animate-pulse">
      <div className="h-7 w-36 bg-muted rounded-xl" />
      {Array.from({ length: 3 }).map((_, i) => (
        <div key={i} className="h-40 bg-card rounded-2xl border border-border" />
      ))}
    </div>
  )
}
