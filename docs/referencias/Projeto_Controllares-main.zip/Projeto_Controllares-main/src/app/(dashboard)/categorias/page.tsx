﻿"use client"

import { useState, useEffect, useCallback } from "react"
import { Plus, Pencil, Trash2, X, Check, Search, Tag, Package, Upload, Settings2, Building2, ChevronRight } from "lucide-react"
import { EmptyState } from "@/components/ui/empty-state"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { proxiedImg } from "@/lib/img"
import { CabecalhoPagina } from "@/components/ui/cabecalho-pagina"
import { useMemoriaDeFiltro } from "@/hooks/usar-memoria-filtro"
import { brl } from "@/lib/formato"

interface Product {
  id: string; nome: string; sku: string; marca?: string | null; imagem_url: string | null; status: string; categoryId: string | null
  supplierId: string | null; supplier?: { id: string; nome: string } | null
}

interface Supplier { id: string; nome: string }

interface ServicoPreDef {
  id: string; nome: string; tipo: "percentual" | "fixo"; valor: string
}

interface Category {
  id: string; nome: string; imagem_url: string | null; servicos: ServicoPreDef[] | null
  _count: { products: number }
  products?: Product[]
}


export default function CategoriasPage() {
  const [categories, setCategories] = useState<Category[]>([])
  const [allProducts, setAllProducts] = useState<Product[]>([])
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [filtroMarca, setFiltroMarca] = useMemoriaDeFiltro<string>("categorias:marca", "")
  const [selected, setSelected] = useState<Category | null>(null)
  const [loading, setLoading] = useState(true)
  const [novaCategoria, setNovaCategoria] = useState("")
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editingNome, setEditingNome] = useState("")
  const [searchProd, setSearchProd] = useState("")
  const [addingProducts, setAddingProducts] = useState(false)
  const [uploadingImg, setUploadingImg] = useState(false)
  const [savingServicos, setSavingServicos] = useState(false)
  const [servicos, setServicos] = useState<ServicoPreDef[]>([])
  const [criandoCategoria, setCriandoCategoria] = useState(false)
  const [erroCategoria, setErroCategoria] = useState("")
  const [imgMode, setImgMode] = useState<"url" | "file">("file")
  const [imgUrlInput, setImgUrlInput] = useState("")
  const [savingImgUrl, setSavingImgUrl] = useState(false)
  /* Aba própria, no lugar do componente Tabs: o desenho pede pílulas
     arredondadas dentro de um trilho de vidro, e o Tabs traz o próprio
     visual junto. */
  const [aba, setAba] = useMemoriaDeFiltro<"produtos" | "servicos">("categorias:aba", "produtos")

  const fetchCategories = useCallback(async () => {
    const res = await fetch("/api/categorias?withProducts=true")
    const data = await res.json()
    setCategories(data.categories || [])
    setLoading(false)
  }, [])

  const fetchAllProducts = useCallback(async () => {
    const res = await fetch("/api/produtos?limit=500")
    const data = await res.json()
    setAllProducts(data.products || [])
  }, [])

  const fetchSuppliers = useCallback(async () => {
    const res = await fetch("/api/fornecedores")
    if (res.ok) setSuppliers((await res.json()).fornecedores || [])
  }, [])

  useEffect(() => { fetchCategories(); fetchAllProducts(); fetchSuppliers() }, [fetchCategories, fetchAllProducts, fetchSuppliers])

  // Sync selected when categories refresh
  useEffect(() => {
    if (selected) {
      const r = categories.find(c => c.id === selected.id)
      if (r) { setSelected(r); setServicos(r.servicos ?? []) }
    }
  }, [categories]) // eslint-disable-line

  // Sincroniza o campo de URL ao trocar de categoria
  useEffect(() => {
    setImgUrlInput(selected?.imagem_url ?? "")
  }, [selected?.id]) // eslint-disable-line

  async function criarCategoria() {
    const nome = novaCategoria.trim()
    if (!nome) return
    setCriandoCategoria(true)
    setErroCategoria("")
    try {
      const res = await fetch("/api/categorias", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ nome }) })
      if (!res.ok) {
        const json = await res.json().catch(() => ({}))
        setErroCategoria(json.error || `Erro ${res.status}`)
        return
      }
      setNovaCategoria("")
      await fetchCategories()
    } catch {
      setErroCategoria("Falha de conexão. Tente novamente.")
    } finally {
      setCriandoCategoria(false)
    }
  }

  async function renomear(id: string) {
    const nome = editingNome.trim()
    if (!nome) return
    await fetch(`/api/categorias/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ nome }) })
    setEditingId(null); fetchCategories()
  }

  async function deletarCategoria(id: string) {
    if (selected?.id === id) setSelected(null)
    await fetch(`/api/categorias/${id}`, { method: "DELETE" })
    fetchCategories(); fetchAllProducts()
  }

  async function assignProduct(productId: string, categoryId: string | null) {
    const prod = allProducts.find(p => p.id === productId)
    const antigaCat = prod?.categoryId ?? null

    // ── Update otimista (UI instantânea, sem esperar rede/refetch) ──
    setAllProducts(prev => prev.map(p => p.id === productId ? { ...p, categoryId } : p))
    setCategories(prev => prev.map(c => {
      let count = c._count.products
      let products = c.products
      if (c.id === antigaCat) {
        count = Math.max(0, count - 1)
        products = products?.filter(p => p.id !== productId)
      }
      if (c.id === categoryId && prod) {
        count = count + 1
        const jaTem = products?.some(p => p.id === productId)
        if (!jaTem) products = [...(products ?? []), { id: prod.id, sku: prod.sku, nome: prod.nome, status: prod.status, imagem_url: prod.imagem_url, categoryId, supplierId: prod.supplierId }]
      }
      return { ...c, _count: { products: count }, products }
    }))
    setSelected(prev => {
      if (!prev) return prev
      if (prev.id === antigaCat) return { ...prev, _count: { products: Math.max(0, prev._count.products - 1) }, products: prev.products?.filter(p => p.id !== productId) }
      if (prev.id === categoryId && prod) {
        const jaTem = prev.products?.some(p => p.id === productId)
        return { ...prev, _count: { products: prev._count.products + 1 }, products: jaTem ? prev.products : [...(prev.products ?? []), { id: prod.id, sku: prod.sku, nome: prod.nome, status: prod.status, imagem_url: prod.imagem_url, categoryId, supplierId: prod.supplierId }] }
      }
      return prev
    })

    // Persiste em background; só refaz fetch se der erro.
    const res = await fetch(`/api/produtos/${productId}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ categoryId }) })
    if (!res.ok) { fetchCategories(); fetchAllProducts() }
  }

  async function uploadImagem(file: File) {
    if (!selected) return
    setUploadingImg(true)
    try {
      const fd = new FormData(); fd.append("file", file); fd.append("companyId", "auto")
      const res = await fetch("/api/upload", { method: "POST", body: fd })
      const json = await res.json()
      if (json.url) {
        await fetch(`/api/categorias/${selected.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ imagem_url: json.url }) })
        fetchCategories()
      }
    } finally { setUploadingImg(false) }
  }

  async function salvarImagemUrl() {
    if (!selected) return
    const url = imgUrlInput.trim()
    setSavingImgUrl(true)
    try {
      await fetch(`/api/categorias/${selected.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ imagem_url: url || null }) })
      fetchCategories()
    } finally { setSavingImgUrl(false) }
  }

  async function saveServicos() {
    if (!selected) return
    setSavingServicos(true)
    await fetch(`/api/categorias/${selected.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ servicos }) })
    setSavingServicos(false); fetchCategories()
  }

  function addServico() {
    setServicos(prev => [...prev, { id: crypto.randomUUID(), nome: "", tipo: "fixo", valor: "" }])
  }
  function updateServico(id: string, key: keyof ServicoPreDef, value: string) {
    setServicos(prev => prev.map(s => s.id === id ? { ...s, [key]: value } : s))
  }
  function removeServico(id: string) {
    setServicos(prev => prev.filter(s => s.id !== id))
  }

  const produtosNaCategoria = selected?.products ?? []
  const marcaNome = suppliers.find(s => s.id === filtroMarca)?.nome ?? ""
  const qp = searchProd.toLowerCase()
  const produtosDisponiveis = allProducts.filter(p =>
    p.categoryId !== selected?.id &&
    // supplierId OU marca — itens sem vínculo de fornecedor não somem
    (!filtroMarca || p.supplierId === filtroMarca || (p.marca ?? "").toLowerCase() === marcaNome.toLowerCase()) &&
    (!qp || p.nome.toLowerCase().includes(qp) || p.sku.toLowerCase().includes(qp) || (p.marca ?? "").toLowerCase().includes(qp))
  )

  const totalProdutos = categories.reduce((a, c) => a + (c._count?.products ?? 0), 0)


  const ativa = selected

  return (
    <div className="cat-shell mx-auto flex max-w-[1560px] flex-col gap-3 p-4 sm:gap-4 sm:p-6">
      {/* Superfícies desta tela, e SÓ desta tela.

          O desenho pedia tokens novos em :root, o que repintaria a plataforma
          inteira — Propostas, Catálogo, Obras. Aqui a mudança é de Categorias,
          então tudo mora sob .cat-shell e reaproveita os tokens que o sistema
          já usa; nada fora desta página muda de aparência. */}
      <style>{`
        .cat-shell {
          --cat-shadow-float: 0 20px 50px -18px oklch(0 0 0 / 0.55);
          --cat-shadow-ios: 0 4px 24px -8px oklch(0 0 0 / 0.35);
        }
        /* Halos de fundo: profundidade sem colorir nada. */
        .cat-shell::before {
          content: "";
          position: fixed;
          inset: 0;
          pointer-events: none;
          z-index: -1;
          background:
            radial-gradient(circle at 20% 10%, oklch(0.55 0 0 / 0.07), transparent 35%),
            radial-gradient(circle at 85% 80%, oklch(0.40 0 0 / 0.05), transparent 35%);
        }
        .cat-card {
          border-radius: 28px;
          background: color-mix(in oklab, var(--surface-1, #17171a) 88%, transparent);
          backdrop-filter: blur(28px) saturate(180%);
          -webkit-backdrop-filter: blur(28px) saturate(180%);
          border: 1px solid oklch(1 0 0 / 0.08);
          box-shadow: var(--cat-shadow-float);
        }
        .cat-glass { background: color-mix(in oklab, var(--surface-1, #17171a) 55%, transparent); }
        .cat-tap { transition: transform .12s ease, background-color .15s ease; cursor: pointer; }
        .cat-tap:active { transform: scale(.97); }
      `}</style>

      <CabecalhoPagina
        icone={Tag}
        titulo="Categorias"
        contexto={`${categories.length} categoria${categories.length === 1 ? "" : "s"} · ${totalProdutos} produto${totalProdutos === 1 ? "" : "s"}`}
      />

      <div className="grid items-start gap-3 sm:gap-4 lg:grid-cols-[300px_minmax(0,1fr)]">
        {/* Chips roláveis no celular.

            A sidebar comprimida obrigava a sair do detalhe para trocar de
            categoria e voltar. Com os chips a troca acontece sem perder de
            vista o que está sendo editado. */}
        <div className="cat-card flex gap-2 overflow-x-auto p-2.5 lg:hidden">
          {categories.length === 0 ? (
            <span className="px-2 py-1 text-[13px] text-muted-foreground">Nenhuma categoria ainda</span>
          ) : categories.map(cat => {
            const ativo = selected?.id === cat.id
            return (
              <button key={cat.id} type="button"
                onClick={() => { setSelected(cat); setServicos(cat.servicos ?? []); setAddingProducts(false); setSearchProd("") }}
                className={`cat-tap flex flex-shrink-0 items-center gap-2 rounded-full py-1.5 pl-2 pr-3 text-[13px] font-medium ${
                  ativo ? "bg-foreground text-background" : "cat-glass text-muted-foreground"
                }`}>
                {cat.imagem_url ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={proxiedImg(cat.imagem_url)} alt="" className="h-6 w-6 rounded-full object-cover" />
                ) : (
                  <span className="grid h-6 w-6 place-items-center rounded-full border border-hairline">
                    <Tag className="h-3 w-3" />
                  </span>
                )}
                <span className="max-w-[140px] truncate">{cat.nome}</span>
                <span className={`rounded-full px-1.5 text-[11px] font-bold ${ativo ? "bg-background/20" : "bg-muted"}`}>
                  {cat._count.products}
                </span>
              </button>
            )
          })}
        </div>

        {/* Lista no desktop */}
        <section className="cat-card hidden p-3 lg:block">
          <div className="flex gap-2">
            <input value={novaCategoria}
              onChange={e => { setNovaCategoria(e.target.value); setErroCategoria("") }}
              onKeyDown={e => e.key === "Enter" && criarCategoria()}
              disabled={criandoCategoria}
              placeholder="Nova categoria..."
              className="cat-glass min-w-0 flex-1 rounded-full border border-hairline px-3.5 py-2 text-[13px] text-foreground outline-none placeholder:text-muted-foreground focus:ring-1 focus:ring-primary/40" />
            <button type="button" onClick={criarCategoria}
              disabled={criandoCategoria || !novaCategoria.trim()}
              className="cat-tap grid h-9 w-9 shrink-0 place-items-center rounded-full bg-foreground text-background disabled:opacity-40">
              <Plus className="h-4 w-4" strokeWidth={2.4} />
            </button>
          </div>
          {erroCategoria && <p className="mt-1.5 px-1 text-[12px] text-ios-red">{erroCategoria}</p>}

          <div className="mt-3 max-h-[calc(100vh-320px)] space-y-1 overflow-y-auto pr-1">
            {loading ? (
              <p className="py-8 text-center text-[13px] text-muted-foreground">Carregando...</p>
            ) : categories.length === 0 ? (
              <p className="py-8 text-center text-[13px] text-muted-foreground">Nenhuma categoria ainda</p>
            ) : categories.map(cat => {
              const ativo = selected?.id === cat.id
              if (editingId === cat.id) {
                return (
                  <div key={cat.id} className="flex items-center gap-1 rounded-2xl border border-hairline p-1.5">
                    <input autoFocus value={editingNome} onChange={e => setEditingNome(e.target.value)}
                      onKeyDown={e => { if (e.key === "Enter") renomear(cat.id); if (e.key === "Escape") setEditingId(null) }}
                      className="cat-glass min-w-0 flex-1 rounded-full px-2.5 py-1 text-[13px] text-foreground outline-none" />
                    <button onClick={() => renomear(cat.id)} className="text-foreground"><Check className="h-4 w-4" /></button>
                    <button onClick={() => setEditingId(null)} className="text-muted-foreground"><X className="h-4 w-4" /></button>
                  </div>
                )
              }
              return (
                <div key={cat.id}
                  onClick={() => { setSelected(cat); setServicos(cat.servicos ?? []); setAddingProducts(false); setSearchProd("") }}
                  className={`group cat-tap flex w-full items-center gap-2.5 rounded-2xl p-2.5 text-left ${
                    ativo ? "bg-foreground text-background" : "hover:bg-muted/60"
                  }`}>
                  {cat.imagem_url ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={proxiedImg(cat.imagem_url)} alt="" className="h-8 w-8 shrink-0 rounded-full object-cover" />
                  ) : (
                    <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-full ${
                      ativo ? "bg-background/15" : "cat-glass border border-hairline"
                    }`}>
                      <Tag className="h-4 w-4" />
                    </span>
                  )}
                  <span className="min-w-0 flex-1 truncate text-[14px] font-medium">{cat.nome}</span>
                  <span className={`rounded-full px-2 py-0.5 text-[11px] font-bold ${
                    ativo ? "bg-background/20" : "bg-muted text-muted-foreground"
                  }`}>
                    {cat._count.products}
                  </span>
                  {/* Renomear e excluir só no hover: são raras e destrutivas, e
                      visíveis o tempo todo competiam com o alvo da linha, que é
                      selecionar. */}
                  <span className="hidden shrink-0 items-center gap-1.5 group-hover:flex" onClick={e => e.stopPropagation()}>
                    <button type="button" onClick={() => { setEditingId(cat.id); setEditingNome(cat.nome) }}
                      className="opacity-60 hover:opacity-100"><Pencil className="h-3.5 w-3.5" /></button>
                    <button type="button" onClick={() => deletarCategoria(cat.id)}
                      className="opacity-60 hover:opacity-100"><Trash2 className="h-3.5 w-3.5" /></button>
                  </span>
                </div>
              )
            })}
          </div>
        </section>

        {/* Detalhe */}
        <section className="cat-card min-w-0 p-4 sm:p-5">
          {!ativa ? (
            <div className="grid place-items-center rounded-2xl border border-dashed border-hairline px-4 py-16 text-center">
              <Tag className="h-8 w-8 text-muted-foreground" strokeWidth={1.6} />
              <p className="mt-3 text-[13px] font-semibold text-foreground">Nenhuma categoria selecionada</p>
              <p className="mt-1 max-w-sm text-[12px] text-muted-foreground">
                Escolha uma categoria para configurar imagem, serviços e produtos.
              </p>
            </div>
          ) : (
            <>
              <header className="flex flex-wrap items-center gap-3 sm:gap-4">
                <div className="grid h-14 w-14 shrink-0 place-items-center overflow-hidden rounded-3xl bg-muted text-foreground shadow-[var(--cat-shadow-float)] sm:h-16 sm:w-16">
                  {uploadingImg ? (
                    <span className="h-5 w-5 animate-spin rounded-full border-2 border-foreground border-t-transparent" />
                  ) : ativa.imagem_url ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={proxiedImg(ativa.imagem_url)} alt={ativa.nome} className="h-full w-full object-cover"
                      onError={e => { (e.target as HTMLImageElement).style.opacity = "0.2" }} />
                  ) : (
                    <Tag className="h-6 w-6 sm:h-7 sm:w-7" strokeWidth={2} />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <h2 className="truncate text-[19px] font-semibold tracking-tight text-foreground sm:text-[24px]">{ativa.nome}</h2>
                  <p className="mt-0.5 truncate text-[12px] text-muted-foreground">
                    {produtosNaCategoria.length} produto{produtosNaCategoria.length === 1 ? "" : "s"}
                    {" · "}{servicos.length} serviço{servicos.length === 1 ? "" : "s"}
                  </p>
                </div>
                <button type="button" onClick={() => { setAddingProducts(v => !v); setSearchProd("") }}
                  className="cat-tap flex shrink-0 items-center justify-center gap-1.5 rounded-full bg-foreground px-4 py-2 text-[13px] font-semibold text-background max-sm:w-full">
                  {addingProducts
                    ? <><X className="h-4 w-4" strokeWidth={2.4} /> Fechar</>
                    : <><Plus className="h-4 w-4" strokeWidth={2.4} /> Adicionar produtos</>}
                </button>
              </header>

              {/* Identidade da categoria */}
              <div className="cat-glass mt-5 rounded-2xl border border-hairline p-3.5">
                <div className="flex flex-wrap items-center gap-3">
                  <div className="flex items-center rounded-full bg-muted p-1">
                    {(["url", "file"] as const).map(m => (
                      <button key={m} type="button" onClick={() => setImgMode(m)}
                        className={`cat-tap rounded-full px-3.5 py-1.5 text-[12px] ${
                          imgMode === m
                            ? "bg-surface-1 font-semibold text-foreground shadow-[var(--cat-shadow-ios)]"
                            : "font-medium text-muted-foreground"
                        }`}>
                        {m === "url" ? "URL" : "Anexar arquivo"}
                      </button>
                    ))}
                  </div>

                  {imgMode === "url" ? (
                    <div className="flex min-w-0 flex-1 items-center gap-2">
                      <input value={imgUrlInput} onChange={e => setImgUrlInput(e.target.value)}
                        placeholder="https://.../imagem.jpg"
                        className="cat-glass min-w-0 flex-1 rounded-full border border-hairline px-3.5 py-2 text-[12px] text-foreground outline-none placeholder:text-muted-foreground" />
                      <button type="button" onClick={salvarImagemUrl} disabled={savingImgUrl}
                        className="cat-tap shrink-0 rounded-full bg-foreground px-3.5 py-2 text-[12px] font-semibold text-background disabled:opacity-40">
                        {savingImgUrl ? "Salvando..." : "Salvar"}
                      </button>
                    </div>
                  ) : (
                    <label className="cat-tap flex items-center gap-2 rounded-full border border-hairline px-3.5 py-2 text-[12px] font-medium text-muted-foreground hover:bg-muted/60">
                      <Upload className="h-3.5 w-3.5" />
                      {uploadingImg ? "Enviando..." : "Escolher arquivo"}
                      <input type="file" accept="image/*" className="hidden" disabled={uploadingImg}
                        onChange={e => { const f = e.target.files?.[0]; if (f) uploadImagem(f) }} />
                    </label>
                  )}
                </div>
                <p className="mt-2.5 text-[11px] text-muted-foreground">
                  {imgMode === "url"
                    ? "Cole a URL direta do arquivo de imagem (.jpg/.png/.webp)."
                    : "Envie um arquivo do computador. PNG ou SVG, fundo transparente."}
                </p>
              </div>

              {/* Abas */}
              <div className="cat-glass mt-5 flex items-center gap-1 rounded-full p-1 sm:inline-flex">
                {([["produtos", "Produtos"], ["servicos", "Serviços Pré-definidos"]] as const).map(([id, label]) => (
                  <button key={id} type="button" onClick={() => setAba(id)}
                    className={`cat-tap flex-1 rounded-full px-4 py-2 text-[13px] sm:flex-none ${
                      aba === id ? "bg-foreground font-semibold text-background" : "font-medium text-muted-foreground"
                    }`}>
                    {label}
                  </button>
                ))}
              </div>

              {aba === "produtos" ? (
                <>
                  {addingProducts && (
                    <div className="cat-glass mt-4 space-y-3 rounded-2xl border border-hairline p-3.5">
                      {suppliers.length > 0 && (
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="flex shrink-0 items-center gap-1 text-[12px] text-muted-foreground">
                            <Building2 className="h-3.5 w-3.5" /> Marca:
                          </span>
                          <select value={filtroMarca} onChange={e => setFiltroMarca(e.target.value)}
                            className="cat-glass h-9 min-w-0 flex-1 rounded-full border border-hairline px-3 text-[13px] text-foreground outline-none sm:max-w-[260px]">
                            <option value="">Todas as marcas</option>
                            {suppliers.map(s => <option key={s.id} value={s.id}>{s.nome}</option>)}
                          </select>
                        </div>
                      )}
                      <div className="relative">
                        <Search className="pointer-events-none absolute left-3.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                        <input autoFocus value={searchProd} onChange={e => setSearchProd(e.target.value)}
                          placeholder="Nome ou SKU..."
                          className="cat-glass w-full rounded-full border border-hairline py-2 pl-9 pr-3.5 text-[13px] text-foreground outline-none placeholder:text-muted-foreground" />
                      </div>
                      <div className="max-h-52 space-y-1.5 overflow-y-auto">
                        {produtosDisponiveis.length === 0 ? (
                          <p className="py-4 text-center text-[12px] text-muted-foreground">
                            {searchProd ? "Nenhum produto encontrado" : "Todos os produtos já estão aqui"}
                          </p>
                        ) : produtosDisponiveis.slice(0, 20).map(p => (
                          <button key={p.id} type="button" onClick={() => assignProduct(p.id, ativa.id)}
                            className="cat-tap flex w-full items-center gap-3 rounded-2xl p-2 text-left hover:bg-muted/50">
                            {p.imagem_url ? (
                              // eslint-disable-next-line @next/next/no-img-element
                              <img src={proxiedImg(p.imagem_url)} alt="" className="h-8 w-8 shrink-0 rounded-xl object-cover" />
                            ) : (
                              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-muted">
                                <Package className="h-4 w-4 text-muted-foreground" />
                              </span>
                            )}
                            <span className="min-w-0 flex-1">
                              <span className="block truncate text-[13px] font-medium text-foreground">{p.nome}</span>
                              <span className="block truncate text-[11px] text-muted-foreground">{p.sku}</span>
                            </span>
                            <Plus className="h-4 w-4 shrink-0 text-muted-foreground" />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {produtosNaCategoria.length === 0 ? (
                    <div className="mt-4 grid place-items-center rounded-2xl border border-dashed border-hairline px-4 py-12 text-center">
                      <Package className="h-8 w-8 text-muted-foreground" strokeWidth={1.6} />
                      <p className="mt-3 text-[13px] font-semibold text-foreground">Nenhum produto nesta categoria</p>
                      <p className="mt-1 text-[12px] text-muted-foreground">
                        Use &ldquo;Adicionar produtos&rdquo; para começar a montar o catálogo.
                      </p>
                    </div>
                  ) : (
                    <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 xl:grid-cols-4">
                      {produtosNaCategoria.map(p => (
                        <div key={p.id} className="group cat-glass cat-tap overflow-hidden rounded-2xl border border-hairline">
                          <div className="relative grid aspect-[4/3] place-items-center bg-muted">
                            {p.imagem_url ? (
                              // eslint-disable-next-line @next/next/no-img-element
                              <img src={proxiedImg(p.imagem_url)} alt={p.nome} className="h-full w-full object-cover" />
                            ) : (
                              <Package className="h-9 w-9 text-muted-foreground" strokeWidth={1.6} />
                            )}
                            <button type="button" onClick={() => assignProduct(p.id, null)} title="Remover da categoria"
                              className="absolute right-1.5 top-1.5 grid h-6 w-6 place-items-center rounded-full bg-background/80 text-foreground opacity-0 transition-opacity group-hover:opacity-100">
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                          <div className="p-3">
                            <p className="truncate text-[13px] font-semibold text-foreground">{p.nome}</p>
                            <p className="mt-0.5 truncate text-[11px] text-muted-foreground">{p.sku}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <div className="mt-4 space-y-3">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0">
                      <h3 className="flex items-center gap-2 text-[14px] font-semibold text-foreground">
                        <Settings2 className="h-4 w-4" /> Serviços automáticos
                      </h3>
                      <p className="mt-0.5 text-[12px] text-muted-foreground">
                        Sugeridos sozinhos quando esta categoria entra numa proposta.
                      </p>
                    </div>
                    <button type="button" onClick={addServico}
                      className="cat-tap flex shrink-0 items-center gap-1.5 rounded-full bg-foreground px-3.5 py-2 text-[12px] font-semibold text-background">
                      <Plus className="h-3.5 w-3.5" strokeWidth={2.4} /> Adicionar
                    </button>
                  </div>

                  {servicos.length === 0 ? (
                    <div className="grid place-items-center rounded-2xl border border-dashed border-hairline px-4 py-12 text-center">
                      <Settings2 className="h-8 w-8 text-muted-foreground" strokeWidth={1.6} />
                      <p className="mt-3 text-[13px] font-semibold text-foreground">Nenhum serviço pré-definido</p>
                      <p className="mt-1 text-[12px] text-muted-foreground">
                        Instalação, configuração, projeto executivo, o que sempre acompanha esta categoria.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {servicos.map(s => {
                        const valorNum = parseFloat(s.valor) || 0
                        return (
                          <div key={s.id} className="cat-glass rounded-2xl border border-hairline p-3.5">
                            <div className="flex flex-wrap items-center gap-2">
                              <input value={s.nome} onChange={e => updateServico(s.id, "nome", e.target.value)}
                                placeholder="Nome do serviço"
                                className="cat-glass min-w-0 flex-1 rounded-full border border-hairline px-3.5 py-2 text-[13px] text-foreground outline-none placeholder:text-muted-foreground" />
                              <div className="flex shrink-0 items-center rounded-full bg-muted p-1">
                                {(["fixo", "percentual"] as const).map(t => (
                                  <button key={t} type="button" onClick={() => updateServico(s.id, "tipo", t)}
                                    className={`cat-tap rounded-full px-3 py-1 text-[12px] font-semibold ${
                                      s.tipo === t ? "bg-foreground text-background" : "text-muted-foreground"
                                    }`}>
                                    {t === "percentual" ? "%" : "R$"}
                                  </button>
                                ))}
                              </div>
                              <input type="number" step="0.01" value={s.valor}
                                onChange={e => updateServico(s.id, "valor", e.target.value)}
                                placeholder={s.tipo === "percentual" ? "%" : "0,00"}
                                className="cat-glass w-24 shrink-0 rounded-full border border-hairline px-3 py-2 text-right text-[13px] tabular-nums text-foreground outline-none" />
                              <button type="button" onClick={() => removeServico(s.id)}
                                className="shrink-0 text-muted-foreground hover:text-ios-red">
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                            <p className="mt-2 text-[12px] text-muted-foreground"
                              title="Cobrado uma vez sobre o valor dos produtos desta categoria na proposta. Não acumula com outros.">
                              {s.tipo === "percentual" ? `${valorNum}% dos produtos da categoria` : brl(valorNum)}
                            </p>
                          </div>
                        )
                      })}
                    </div>
                  )}

                  <div className="flex justify-end">
                    <button type="button" onClick={saveServicos} disabled={savingServicos}
                      className="cat-tap rounded-full bg-foreground px-4 py-2 text-[13px] font-semibold text-background disabled:opacity-40">
                      {savingServicos ? "Salvando..." : "Salvar serviços"}
                    </button>
                  </div>
                </div>
              )}
            </>
          )}
        </section>
      </div>
    </div>
  )
}
