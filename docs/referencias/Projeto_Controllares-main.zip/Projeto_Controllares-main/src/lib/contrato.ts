import { prisma } from "@/lib/prisma"
import { formatarDocumento } from "@/lib/documento"
import { valorDoServico, type ServicoProposta } from "@/lib/servicos-proposta"
import { brl } from "@/lib/formato"

/**
 * GET /api/propostas/[id]/contrato?modeloId=... — contrato pronto para
 * imprimir ou salvar em PDF (Ctrl+P → Salvar como PDF).
 *
 * O contrato era redigido fora do sistema, com os dados copiados à mão da
 * proposta — é onde nome, valor e condição de pagamento divergiam do que o
 * cliente aceitou. Aqui o texto vem do modelo e os dados vêm da proposta.
 */
const esc = (v: unknown) =>
  String(v ?? "").replace(/[&<>"']/g, c =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!))


const QUEBRA = String.fromCharCode(10)

const FORMA: Record<string, string> = {
  CARTAO: "Cartão de crédito",
  AVISTA: "À vista",
  OBRA: "Parcelado na obra",
  PERSONALIZADO: "Condição personalizada",
  // Formas escolhidas parcela a parcela na condição personalizada.
  PIX: "Pix",
  BOLETO: "Boleto",
  TRANSFERENCIA: "Transferência",
  DINHEIRO: "Dinheiro",
  CHEQUE: "Cheque",
}


/**
 * Cidade da sede a partir do endereço em texto livre.
 *
 * O endereço vem de busca por CEP, num formato estável o bastante:
 * "Rua X, 123 - Bairro, Cidade - UF, 00000-000". A cidade é o trecho antes da
 * UF de duas letras. O CEP sai antes de qualquer coisa porque o hífen dele
 * confunde qualquer separação por hífen.
 */
function cidadeDaSede(enderecoBase: string | null | undefined): string {
  const texto = String(enderecoBase ?? "").replace(/\b\d{5}-?\d{3}\b/g, "").trim()
  if (!texto) return ""
  const comUf = texto.match(/([^,]+?)\s*[-\/]\s*([A-Za-z]{2})\s*(?:,|$)/)
  if (comUf) return comUf[1].trim()
  // Sem UF reconhecível, a última parte separada por vírgula é o melhor palpite.
  const partes = texto.split(",").map(x => x.trim()).filter(Boolean)
  return partes.length ? partes[partes.length - 1] : ""
}


/**
 * Põe as duas assinaturas lado a lado.
 *
 * O modelo escreve CONTRATANTE e CONTRATADA um abaixo do outro, porque em texto
 * corrido não há outro jeito. Empilhadas ocupam meia folha, e a última página
 * sai com dois blocos soltos e muito branco.
 *
 * Procura os dois últimos traços de assinatura: o primeiro abre a coluna da
 * esquerda, o segundo a da direita, que termina na primeira linha em branco —
 * o que vier depois (o anexo, por exemplo) fica fora. Modelo sem esse par sai
 * intacto: nenhum é obrigado a seguir este formato.
 */
function assinaturasLadoALado(corpo: string): string {
  const marcas = [...corpo.matchAll(/^[ \t]*_{6,}.*$/gm)]
  if (marcas.length < 2) return corpo

  const [a, b] = marcas.slice(-2)
  const inicio = a.index!
  const meio = b.index!
  const apos = corpo.slice(meio).search(/\n[ \t]*\n/)
  const fim = apos === -1 ? corpo.length : meio + apos

  /* Fora os underscores. Eles eram a linha de assinatura no texto puro, mas têm
     comprimento fixo: lado a lado, os dois traços encostam e viram uma régua só
     atravessando a folha. A linha passa a ser a borda da coluna, que acompanha
     a largura de cada uma. */
  const semTraco = (bloco: string) => bloco.replace(/^[ 	]*_{6,}.*$/gm, "").trim()

  const esquerda = semTraco(corpo.slice(inicio, meio))
  const direita = semTraco(corpo.slice(meio, fim))
  if (!esquerda || !direita) return corpo

  return corpo.slice(0, inicio)
    + `<div class="duplas"><div>${esquerda}</div><div>${direita}</div></div>`
    + corpo.slice(fim)
}

/**
 * O anexo inteiro começa na folha nova — título, abertura e tabela juntos.
 *
 * A quebra estava na tabela. O título ("ANEXO I — ...") e o parágrafo de
 * abertura são texto do modelo, e ficavam na folha anterior: o contrato saía
 * com o anexo anunciado no alto de uma página quase vazia e a tabela sozinha
 * na seguinte. O `break-after:avoid` no elemento anterior não segurava os dois
 * juntos porque antes da tabela vem um nó de texto, e não um elemento —
 * `*:has(+ .anexo)` nunca casava com nada.
 *
 * Agora quem quebra é o bloco: acha o título do anexo mais próximo acima da
 * tabela e embrulha dali até o fim dela num elemento só. Modelo sem esse
 * título continua quebrando na tabela, como antes — nenhum é obrigado a
 * escrever o cabeçalho do anexo do mesmo jeito.
 */
function anexoEmFolhaPropria(corpo: string): string {
  const inicioTabela = corpo.indexOf('<table class="itens anexo"')
  if (inicioTabela === -1) return corpo

  const fecha = corpo.indexOf("</table>", inicioTabela)
  if (fecha === -1) return corpo
  const fim = fecha + "</table>".length

  /* Só a linha que ABRE com "ANEXO" conta: o corpo do contrato cita o anexo no
     meio das cláusulas ("conforme o ANEXO I"), e essas menções não são título.
     Entre os títulos, o último antes da tabela é o dela. */
  const titulos = [...corpo.slice(0, inicioTabela).matchAll(/^[ \t]*ANEXO\b.*$/gim)]
  const inicio = titulos.length ? titulos[titulos.length - 1].index! : inicioTabela

  /* As linhas em branco antes do título iam virar espaço no topo da folha
     nova: sob `pre-line` cada quebra do modelo é uma linha de verdade. */
  return corpo.slice(0, inicio).replace(/\s+$/, "")
    + `<div class="anexo-bloco">${corpo.slice(inicio, fim)}</div>`
    + corpo.slice(fim)
}

/**
 * Monta o HTML do contrato. Fica aqui, e não na rota, porque dois caminhos
 * precisam dele: a tela interna (com sessão) e o link público que vai no
 * e-mail do cliente.
 *
 * @param publico esconde os botões de ação — no link do cliente não faz
 *                sentido oferecer "enviar ao cliente".
 */
export async function montarContrato(
  id: string,
  companyId: string,
  modeloId: string,
  opcoes: { publico?: boolean } = {},
): Promise<string | null> {
  const [proposal, modelo, empresa] = await Promise.all([
    prisma.proposal.findFirst({
      where: { id, companyId: companyId },
      include: {
        vendedor: { select: { nome: true } },
        installments: { orderBy: { numero_parcela: "asc" } },
        environments: { include: { proposalItems: { include: { product: true } } } },
      },
    }),
    prisma.pageTemplate.findFirst({
      where: { id: modeloId, companyId: companyId, tipo: "CONTRATO" },
    }),
    prisma.company.findUnique({
      where: { id: companyId },
      select: {
        nome_empresa: true, cnpj_cpf: true, logo_url: true,
        logo_proposta_url: true, endereco_base: true,
      },
    }),
  ])
  if (!proposal) return null
  if (!modelo) return null

  /* O endereço de faturamento é o que vale no contrato — é o cadastro
     conferido para a nota, não o que foi digitado na correria da proposta. */
  const endereco = [
    proposal.fat_logradouro && `${proposal.fat_logradouro}, ${proposal.fat_numero ?? "s/n"}`,
    proposal.fat_complemento,
    proposal.fat_bairro,
    [proposal.fat_cidade, proposal.fat_uf].filter(Boolean).join("/"),
  ].filter(Boolean).join(" — ")

  const parcelas = proposal.parcelas_forma ?? 0
  const pagamento = [
    proposal.forma_pagamento ? FORMA[proposal.forma_pagamento] ?? proposal.forma_pagamento : null,
    parcelas > 1 ? `em ${parcelas}x` : null,
    Number(proposal.valor_entrada) > 0 ? `entrada de ${brl(Number(proposal.valor_entrada))}` : null,
  ].filter(Boolean).join(", ")

  /* Endereço da OBRA é outro do endereço de faturamento: o contrato descreve
     onde o serviço será executado, e é comum a cobrança ir para um endereço e
     a instalação acontecer em outro. Sem obra cadastrada, cai no faturamento. */
  const enderecoObra = [
    proposal.obra_logradouro && `${proposal.obra_logradouro}, ${proposal.obra_numero ?? "s/n"}`,
    proposal.obra_complemento,
    proposal.obra_bairro,
    [proposal.obra_cidade, proposal.obra_uf].filter(Boolean).join("/"),
  ].filter(Boolean).join(" — ")

  /* Cronograma em texto, uma parcela por linha. Quando o financeiro ainda não
     gerou, descreve a condição aceita — melhor isso que uma lacuna no contrato. */
  /* A entrada NÃO é a parcela 01. Ela é pagamento à parte: num "entrada + 6x"
     as parcelas vão de 01 a 06 e a entrada aparece nomeada. Numerada como
     primeira, o contrato dizia sete parcelas onde foram combinadas seis mais a
     entrada — e o cliente conta uma a mais do que assinou. */
  let ordemParcela = 0
  const listaParcelas = proposal.installments.length
    ? proposal.installments
        .map(p => (p.entrada
            ? `Entrada de ${brl(Number(p.valor))}`
            : `Parcela ${String(++ordemParcela).padStart(2, "0")} de ${brl(Number(p.valor))}`)
          + ` — Vencimento: ${new Date(p.data_vencimento).toLocaleDateString("pt-BR")}`)
        .join(QUEBRA)
    : (pagamento || "Condição a combinar")

  /* Relação dos itens com valores: o contrato dizia só o total, e o que estava
     sendo contratado ficava a cargo da proposta, num documento separado.

     Vai como tabela, não como lista de linhas: em texto corrido os valores não
     alinham e a conferência item a item — que é para o que o anexo existe —
     obriga a ler cada linha inteira até achar o número. */
  const subtotalProdutos = proposal.environments.reduce((s, env) =>
    s + env.proposalItems.reduce((t, it) => t + Number(it.valor_total), 0), 0)

  /* A base do percentual sai de `servicos-proposta`, a mesma da proposta do
     cliente e do pedido do Olist. Calculada aqui sobre o total, a instalação
     de um sistema cobrava sobre a proposta inteira — e o contrato ficava
     divergente do documento que o cliente aprovou. */
  const itensParaServico = proposal.environments.flatMap(env =>
    env.proposalItems.map(it => ({
      environmentId: env.id,
      categoryId: it.categoryId ?? it.product?.categoryId ?? null,
      valor_total: Number(it.valor_total),
    })))

  const servicos = (Array.isArray(proposal.servicos_detalhe)
    ? (proposal.servicos_detalhe as unknown as ServicoProposta[])
    : [])
    .filter(sv => sv?.nome)
    .map(sv => ({ nome: String(sv.nome), valor: valorDoServico(sv, itensParaServico) }))
    .filter(sv => sv.valor > 0)

  /* Instalação e projeto não são persistidos linha a linha — só o total da
     proposta sobrevive. O que sobra depois dos serviços nomeados é essa
     parcela, e sem ela a tabela não fecha.

     O resíduo sai do serviço GRAVADO, não do total da proposta: o total já vem
     com o desconto aplicado, e medir a sobra contra ele fazia o desconto sumir
     dentro de uma linha de serviço — ou, quando o desconto era maior que a
     sobra, virar resíduo negativo e desaparecer. */
  const somaServicos = servicos.reduce((t, sv) => t + sv.valor, 0)
  const residuo = Number((Number(proposal.valor_servico ?? 0) - somaServicos).toFixed(2))
  if (residuo > 0.01) servicos.push({ nome: "Instalação e projeto", valor: residuo })

  const linhaTabela = (desc: string, qtd: string, unit: string, total: string) =>
    `<tr><td>${esc(desc)}</td><td class="c">${esc(qtd)}</td>`
    + `<td class="d">${esc(unit)}</td><td class="d">${esc(total)}</td></tr>`

  const blocosProdutos = proposal.environments
    .filter(env => env.proposalItems.length)
    .map(env =>
      `<tr class="grupo"><td colspan="4">${esc(env.nome)}</td></tr>`
      + env.proposalItems.map(it => linhaTabela(
          /* Nome REAL do catalogo, com marca e modelo, nunca o generico.

             O generico existe para a proposta que vai ao cliente, onde nao
             interessa entregar o modelo exato antes de fechar. O contrato e o
             oposto: define o que foi comprado, e "caixa acustica embutida" no
             lugar de "Sonance VP66R" nao identifica nada na hora de conferir a
             entrega. */
          it.product?.nome ?? it.nome_snapshot ?? "Item",
          String(it.quantidade),
          brl(Number(it.valor_unitario)),
          brl(Number(it.valor_total)),
        )).join(""))
    .join("")

  const blocoServicos = servicos.length
    ? `<tr class="grupo"><td colspan="4">Serviços</td></tr>`
      + servicos.map(sv => linhaTabela(sv.nome, "1", brl(sv.valor), brl(sv.valor))).join("")
    : ""

  /* O DESCONTO no anexo, com nome e valor.

     A tabela listava produtos e serviços e fechava com o total do contrato —
     que já vem descontado. As linhas somavam 8.900 e o rodapé dizia 8.000, sem
     nada no meio explicando os 900: quem conferia o contrato encontrava uma
     diferença sem dono, que é exatamente o que um anexo de conferência não
     pode produzir.

     Agora a conta aparece inteira: subtotal, o que foi abatido e o total. */
  const totalContrato = Number(proposal.valor_total ?? 0)
  const subtotalAnexo = subtotalProdutos + servicos.reduce((t, sv) => t + sv.valor, 0)
  const descontoPct = Number(proposal.desconto_aplicado ?? 0)
  const descontoNegociado = descontoPct > 0
    ? Number((subtotalAnexo * descontoPct / 100).toFixed(2))
    : 0
  /* O que ainda falta para chegar no total fechado. Campanha entra aqui quando
     foi concedida; qualquer outra diferença aparece como abatimento, com valor,
     em vez de ficar escondida na subtração do rodapé. */
  const restante = Number((subtotalAnexo - descontoNegociado - totalContrato).toFixed(2))
  const campanha = proposal.aplicar_desconto_campanha !== false
    ? Number(proposal.desconto_campanha ?? 0)
    : 0

  const linhaValor = (desc: string, valor: string) =>
    `<tr><td colspan="3">${esc(desc)}</td><td class="d">${esc(valor)}</td></tr>`

  const blocoDesconto = (descontoNegociado > 0.01 || Math.abs(restante) > 0.01)
    ? linhaValor("Subtotal", brl(subtotalAnexo))
      /* Sem o percentual no rótulo: o desconto é guardado como percentual e
         digitado em reais, então ele sai com a precisão da divisão —
         "Desconto concedido (10.1124%)" no contrato parece um número mal
         arredondado. O que o cliente confere é o valor abatido. */
      + (descontoNegociado > 0.01
        ? linhaValor("Desconto concedido", `- ${brl(descontoNegociado)}`)
        : "")
      + (restante > 0.01
        ? linhaValor(
          campanha > 0 && Math.abs(restante - campanha) < 0.02 ? "Desconto de campanha" : "Abatimento concedido",
          `- ${brl(restante)}`)
        : "")
      + (restante < -0.01 ? linhaValor("Acréscimo", brl(-restante)) : "")
    : ""

  /* O anexo começa em página nova.

     Ele é a relação item a item que dá lastro ao valor do contrato, e vinha
     emendado no fim da última cláusula: metade da tabela na folha do fecho,
     metade na seguinte. Documento que se confere linha a linha começa em folha
     própria. */
  const tabelaItens = (blocosProdutos || blocoServicos)
    ? `<table class="itens anexo">
        <thead><tr><th>Descrição</th><th class="c">Qtd.</th>`
      + `<th class="d">Valor unit.</th><th class="d">Total</th></tr></thead>
        <tbody>${blocosProdutos}${blocoServicos}${blocoDesconto}</tbody>
        <tfoot><tr><td colspan="3">Valor total do contrato</td>`
      + `<td class="d">${esc(brl(Number(proposal.valor_total ?? 0)))}</td></tr></tfoot>
       </table>`
    : ""

  /* Cronograma como TABELA, no mesmo formato do anexo dos itens.

     Em texto corrido — "Parcela 01 de R$ 10.000,00 — Vencimento: ..." — os
     valores não alinham e conferir o combinado obriga a ler cada linha
     inteira. A entrada aparece nomeada, e não como "Parcela 01": ela é um
     pagamento à parte, e chamá-la de primeira parcela é o que fazia o cliente
     contar uma parcela a menos do que o acordado. */
  let ordemTabela = 0
  const tabelaParcelas = proposal.installments.length
    ? `<table class="itens">
        <thead><tr><th>Parcela</th><th class="c">Vencimento</th>`
      + `<th class="d">Forma</th><th class="d">Valor</th></tr></thead>
        <tbody>`
      + proposal.installments.map((p, i) => {
          const rotulo = p.entrada
            ? "Entrada"
            : `Parcela ${String(++ordemTabela).padStart(2, "0")}`
          return `<tr><td>${esc(rotulo)}</td>`
            + `<td class="c">${esc(new Date(p.data_vencimento).toLocaleDateString("pt-BR"))}</td>`
            + `<td class="d">${esc(FORMA[p.forma ?? ""] ?? p.forma ?? "A combinar")}</td>`
            + `<td class="d">${esc(brl(Number(p.valor)))}</td></tr>`
        }).join("")
      + `</tbody>
        <tfoot><tr><td colspan="3">Total</td>`
      + `<td class="d">${esc(brl(proposal.installments.reduce((t, p) => t + Number(p.valor), 0)))}</td></tr></tfoot>
       </table>`
    : ""

  const valores: Record<string, string> = {
    cliente: proposal.fat_razao_social || proposal.client_name || "",
    documento: proposal.fat_documento ? formatarDocumento(proposal.fat_documento) : "",
    endereco,
    proposta: proposal.numero,
    valor: brl(Number(proposal.valor_total)),
    pagamento: pagamento || "a combinar",
    data: new Date().toLocaleDateString("pt-BR"),
    empresa: empresa?.nome_empresa ?? "",
    cnpj_empresa: empresa?.cnpj_cpf ? formatarDocumento(empresa.cnpj_cpf) : "",
    endereco_obra: enderecoObra || endereco,
    parcelas: listaParcelas,
    /* Cidade da sede, para o fecho "Cidade, data".

       Saía do split de `endereco_base` por vírgula e hífen, pegando a penúltima
       parte. O CEP "15015-600" também quebra nesse hífen, então a penúltima
       parte virava "15015" e o contrato fechava com um número no lugar da
       cidade. Aqui o CEP sai antes e a cidade vem do padrão "Cidade - UF". */
    cidade_empresa: cidadeDaSede(empresa?.endereco_base),
    /* Referência do pedido. Sem envio ao Olist ainda não existe número lá, e o
       número da proposta é a referência equivalente — melhor que um traço no
       meio da frase. */
    pedido_venda: proposal.olist_pedido_numero || proposal.numero,
  }

  /* Variável sem valor vira um traço, não o próprio "{{cliente}}": um contrato
     impresso com chaves no meio é pior que um campo visivelmente vazio. */
  const faltando: string[] = []
  const corpo = modelo.conteudo.replace(/\{\{\s*([a-z_]+)\s*\}\}/gi, (_m, chave: string) => {
    const nome = chave.toLowerCase()
    /* `itens` é o único valor que entra como HTML: a tabela é montada aqui, com
       cada célula já escapada. Passar pelo `esc` geral imprimiria as tags. */
    if (nome === "itens") {
      if (!tabelaItens) { faltando.push(nome); return "—————" }
      return tabelaItens
    }
    /* Mesma exceção de `itens`: a tabela das parcelas já sai daqui com as
       células escapadas, e passar pelo `esc` geral imprimiria as tags. */
    /* `parcelas` e `tabela_parcelas` produzem a MESMA tabela. O modelo em uso
       chama `parcelas`, e trocar a variável no modelo exigiria reeditar cada
       contrato cadastrado — sai a tabela nos dois nomes. Sem cronograma
       gravado, sobra o texto da condição. */
    if (nome === "tabela_parcelas" || nome === "parcelas") {
      if (tabelaParcelas) return tabelaParcelas
      if (!listaParcelas) { faltando.push(nome); return "—————" }
      return esc(listaParcelas).split(QUEBRA).join("<br>")
    }
    const v = valores[nome]
    if (v === undefined) return "—"
    if (!v) { faltando.push(nome); return "—————" }
    return esc(v)
  })

  /* As assinaturas viram duas colunas só depois da substituição: o nome do
     cliente entra por variável, e antes disso o bloco ainda não está completo. */
  const corpoFinal = anexoEmFolhaPropria(assinaturasLadoALado(corpo))

  const aviso = faltando.length
    ? `<div class="aviso no-print">Sem preenchimento: ${esc([...new Set(faltando)].join(", "))}.
       Complete os dados de faturamento da proposta e gere de novo.</div>`
    : ""

  /* O modelo oficial já termina com as linhas de assinatura. Acrescentar as
     nossas deixava duas áreas para assinar na mesma folha, e nenhuma delas
     claramente a que vale. */
  const temAssinaturaNoModelo = /CONTRATANTE|CONTRATADA/i.test(modelo.conteudo)

  // Mesma marca da proposta: o cliente recebe os dois documentos.
  const logoDoc = empresa?.logo_proposta_url || empresa?.logo_url

  const html = `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"/>
  <title>Contrato ${esc(proposal.numero)} — ${esc(valores.cliente)}</title><style>
    *{box-sizing:border-box}
    body{font-family:Georgia,"Times New Roman",serif;margin:0;padding:32px 24px;color:#111;line-height:1.65}
    .folha{max-width:760px;margin:0 auto}
    .acoes{max-width:760px;margin:0 auto 20px}
    .acoes{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
    .acoes button{background:#111;color:#fff;border:0;padding:10px 20px;border-radius:8px;cursor:pointer;font-family:system-ui,sans-serif;font-size:14px}
    .acoes button.secundario{background:#fff;color:#111;border:1px solid #d4d4d8}
    .acoes span{font-family:system-ui,sans-serif;font-size:13px;color:#555}
    .acoes span.ok{color:#15803d}
    .acoes span.erro{color:#b91c1c}
    .aviso{max-width:760px;margin:0 auto 20px;border:1px solid #e0b400;background:#fff8e1;color:#6b5200;
      border-radius:8px;padding:12px 14px;font-family:system-ui,sans-serif;font-size:13px;line-height:1.5}
    .topo{display:flex;align-items:center;gap:16px;border-bottom:2px solid #111;padding-bottom:16px;margin-bottom:28px}
    .topo img{max-height:52px;max-width:200px}
    .topo .quem{font-family:system-ui,sans-serif;font-size:12px;color:#555;margin-left:auto;text-align:right}
    h1{font-size:20px;text-align:center;letter-spacing:.04em;text-transform:uppercase;margin:0 0 28px}
    .corpo{white-space:pre-line;font-size:15px;text-align:justify}
    /* A tabela precisa sair do fluxo pre-line: dentro dele cada quebra do HTML
       viraria uma linha em branco entre as linhas da tabela. */
    .corpo .itens{white-space:normal;width:100%;border-collapse:collapse;margin:14px 0 4px;
      font-family:system-ui,sans-serif;font-size:12.5px;text-align:left}
    .corpo .itens th{border-bottom:1.5px solid #111;padding:7px 8px;font-weight:600;
      text-transform:uppercase;letter-spacing:.03em;font-size:11px}
    .corpo .itens td{border-bottom:1px solid #e4e4e7;padding:7px 8px;vertical-align:top}
    .corpo .itens tr.grupo td{background:#f4f4f5;font-weight:600;padding-top:9px;padding-bottom:9px}
    .corpo .itens td.c,.corpo .itens th.c{text-align:center;white-space:nowrap}
    .corpo .itens td.d,.corpo .itens th.d{text-align:right;white-space:nowrap}
    .corpo .itens tfoot td{border-top:1.5px solid #111;border-bottom:0;font-weight:700;
      padding-top:10px;font-size:13.5px}
    /* Uma linha da tabela nunca deve ficar sozinha na virada de página. */
    @media print{.corpo .itens tr{page-break-inside:avoid}
      .corpo .itens thead{display:table-header-group}
      /* O anexo abre em folha nova como um bloco só: a quebra é do conjunto
         título + abertura + tabela, montado em anexoEmFolhaPropria(). Na
         tabela sozinha, o título ficava para trás na folha anterior. */
      .corpo .anexo-bloco{break-before:page;page-break-before:always}
      /* O título não se separa da tabela nem dentro do bloco. */
      .corpo .anexo-bloco>.itens{break-before:avoid;page-break-before:avoid}}
    /* Na tela não há folha nova que separe o anexo do que vem antes. O
       respiro fica só aqui: em impressão, margem no topo da página vira
       espaço em branco somado à margem do @page. */
    @media screen{.corpo .anexo-bloco{margin-top:48px}}
    /* Assinaturas do modelo lado a lado: empilhadas, a folha terminava com
       dois blocos soltos e sobrava espaco em branco. */
    .corpo .duplas{display:flex;gap:56px;margin-top:64px;align-items:flex-start}
    /* Uma linha por assinatura, do tamanho da coluna, e o nome centrado sob
       ela — é como o papel é assinado. */
    .corpo .duplas>div{flex:1;min-width:0;text-align:center;border-top:1px solid #111;
      padding-top:10px;font-size:14px;line-height:1.55}
    /* As duas assinaturas são um bloco só: separar na virada de página deixaria
       o contratante numa folha e a contratada na seguinte. */
    @media print{.corpo .duplas{break-inside:avoid;page-break-inside:avoid}}
    /* No celular não cabem duas colunas de assinatura. */
    @media screen and (max-width:640px){.corpo .duplas{display:block}
      .corpo .duplas>div+div{margin-top:40px}}
    .assinaturas{margin-top:64px;display:flex;gap:48px}
    .assinaturas div{flex:1;text-align:center;border-top:1px solid #111;padding-top:8px;font-size:13px;
      font-family:system-ui,sans-serif}
    /* Mesma ideia do link da proposta: copiar o contrato inteiro para fora é o
       caminho curto para ele circular. Não é proteção — imprimir continua
       liberado, e é o caminho legítimo. */
    body{-webkit-user-select:none;user-select:none}
    input,textarea{-webkit-user-select:text;user-select:text}
    @media print{body{-webkit-user-select:auto;user-select:auto}}
    @page{margin:22mm 18mm}
    @media print{.acoes,.no-print{display:none} body{padding:0}}
  </style></head><body>
    ${opcoes.publico ? "" : `<div class="acoes">
      <button onclick="window.print()">Imprimir / salvar em PDF</button>
      <!-- Enviar daqui: quem acabou de conferir o contrato é quem manda, sem
           voltar para a tela da proposta e procurar o botão. -->
      <button class="secundario" onclick="enviarContrato()">Enviar ao cliente por e-mail</button>
      <span id="aviso-envio"></span>
    </div>
    <script>
      async function enviarContrato() {
        var destino = prompt(
          "Enviar o contrato para qual e-mail?",
          ${JSON.stringify(proposal.fat_email || proposal.client_email || "")}
        )
        if (!destino) return
        if (!confirm("Confirma o envio do contrato para " + destino + "?")) return
        var aviso = document.getElementById("aviso-envio")
        aviso.textContent = "Enviando..."
        try {
          var r = await fetch(${JSON.stringify(`/api/propostas/${id}/contrato/enviar`)}, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email: destino }),
          })
          var j = await r.json()
          aviso.textContent = r.ok ? "Enviado para " + j.destino : (j.error || "Falha no envio")
          aviso.className = r.ok ? "ok" : "erro"
        } catch (e) {
          aviso.textContent = "Falha de conexão"
          aviso.className = "erro"
        }
      }
    </script>`}
    ${aviso}
    <div class="folha">
      <div class="topo">
        ${logoDoc ? `<img src="${esc(logoDoc)}" alt="${esc(valores.empresa)}"/>` : `<b>${esc(valores.empresa)}</b>`}
        <div class="quem">Proposta ${esc(proposal.numero)}<br/>${esc(valores.data)}</div>
      </div>
      <h1>${esc(modelo.nome)}</h1>
      <div class="corpo">${corpoFinal}</div>
      ${temAssinaturaNoModelo ? "" : `<div class="assinaturas">
        <div>${esc(valores.empresa)}<br/>CONTRATADA</div>
        <div>${esc(valores.cliente)}<br/>CONTRATANTE</div>
      </div>`}
    </div>
  </body></html>`

  /* Marca que o contrato foi gerado. É o que permite bloquear a conclusão de
     uma proposta cujo contrato ninguém chegou a produzir — antes o kanban só
     sabia em que coluna o card estava. */
  await prisma.proposal.update({
    where: { id },
    data: { contrato_gerado_em: new Date(), contrato_modelo_id: modelo.id },
  }).catch(() => {})


  return html
}