/**
 * Força de senha — a mesma regra no navegador e no servidor.
 *
 * A única exigência era ter 8 caracteres, então "12345678" e "senha123"
 * passavam. Contar tipo de caractere também não resolve: "Senha@1" tem
 * maiúscula, minúscula, número e símbolo em 7 caracteres, e cai numa lista de
 * ataque comum; "cadeira armario janela" não tem nenhum símbolo e é muito mais
 * difícil de quebrar.
 *
 * O que decide de fato é quanto trabalho a senha dá para adivinhar. O
 * comprimento é o que mais pesa — cada caractere multiplica as combinações,
 * enquanto um símbolo a mais só amplia o alfabeto uma vez. Por isso o cálculo
 * parte do tamanho e desconta o que torna a senha previsível: palavra de lista
 * conhecida, sequência de teclado, repetição, e o próprio nome ou e-mail de
 * quem está cadastrando.
 *
 * Não é um medidor de entropia real e não pretende ser: serve para barrar o
 * que cai em minutos e para dizer à pessoa, em português, o que está faltando.
 */

export type NivelSenha = "fraca" | "razoavel" | "boa" | "forte"

export interface AvaliacaoSenha {
  /** 0 a 100 — só para a barra; o que vale é `nivel`. */
  pontos: number
  nivel: NivelSenha
  rotulo: string
  /** O que fazer para melhorar, em ordem de impacto. Vazio quando está forte. */
  sugestoes: string[]
  /** Regra dura: abaixo disso a senha é recusada pelo servidor. */
  aceitavel: boolean
}

/* Bases mais usadas em ataque de dicionário em português e inglês. Lista curta
   de propósito: cobre o que aparece de verdade, sem virar um arquivo de
   milhares de linhas que ninguém revisa. */
const COMUNS = [
  "senha", "password", "123456", "12345678", "qwerty", "abc123", "111111",
  "admin", "administrador", "usuario", "user", "login", "acesso", "master",
  "brasil", "flamengo", "corinthians", "palmeiras", "saopaulo", "gremio",
  "amor", "familia", "casa", "deus", "jesus", "iloveyou", "welcome",
  "controllares", "flowdeal", "automacao", "empresa", "teste", "mudar123",
  "letmein", "monkey", "dragon", "sunshine", "princess", "football",
]

const SEQUENCIAS = [
  "abcdefghijklmnopqrstuvwxyz",
  "qwertyuiop", "asdfghjkl", "zxcvbnm",
  "01234567890",
]

const semAcento = (s: string) =>
  s.normalize("NFD").replace(/\p{Diacritic}/gu, "").toLowerCase()

/** Troca de letra por número que atacante testa primeiro: p@ssw0rd é password. */
const desofuscar = (s: string) =>
  s.replace(/[@4]/g, "a").replace(/[3]/g, "e").replace(/[1!|]/g, "i")
   .replace(/[0]/g, "o").replace(/[5$]/g, "s").replace(/[7]/g, "t")

/** Contém uma sequência de 4+ do teclado ou do alfabeto, para frente ou de trás. */
function temSequencia(texto: string): boolean {
  const t = texto.toLowerCase()
  for (const base of SEQUENCIAS) {
    const invertida = [...base].reverse().join("")
    for (const fonte of [base, invertida]) {
      for (let i = 0; i + 4 <= fonte.length; i++) {
        if (t.includes(fonte.slice(i, i + 4))) return true
      }
    }
  }
  return false
}

/** "aaaa", "abababab" — padrão que não acrescenta trabalho nenhum. */
function temRepeticao(texto: string): boolean {
  if (/(.)\1{2,}/.test(texto)) return true
  return /^(.{1,3})\1{2,}$/.test(texto)
}

/**
 * Avalia a senha.
 *
 * @param contexto nome e e-mail de quem cadastra. Senha feita do próprio nome
 *                 é a primeira coisa que alguém tenta, e sem isso o medidor
 *                 aprovaria "JoaoSilva2026" com nota alta.
 */
export function avaliarSenha(
  senha: string,
  contexto: { nome?: string | null; email?: string | null } = {},
): AvaliacaoSenha {
  const s = senha ?? ""
  const sugestoes: string[] = []

  if (!s) {
    return { pontos: 0, nivel: "fraca", rotulo: "Muito fraca", aceitavel: false,
      sugestoes: ["Use pelo menos 10 caracteres."] }
  }

  /* Duas formas do texto, para dois usos diferentes.

     `plano` mantém os dígitos: é nele que se procuram sequências, porque
     desofuscar transforma "12345678" em "iaeasbt8" e a sequência numérica
     desaparece justamente na senha mais comum do mundo.

     `letras` troca número por letra parecida, e serve só para casar com a
     lista de palavras: p@ssw0rd tem de bater com password. */
  const plano = semAcento(s)
  const letras = desofuscar(plano)

  /* Comprimento é a base. Cresce rápido até 16 e depois estabiliza: passar de
     20 para 24 caracteres não muda a decisão de ninguém. */
  let pontos = Math.min(55, Math.max(0, (s.length - 4) * 5))

  const temMinuscula = /[a-z]/.test(s)
  const temMaiuscula = /[A-Z]/.test(s)
  const temNumero = /\d/.test(s)
  const temSimbolo = /[^a-zA-Z0-9]/.test(s)
  const variedade = [temMinuscula, temMaiuscula, temNumero, temSimbolo].filter(Boolean).length

  pontos += variedade * 8

  // Caracteres distintos: "aaaaaaaaaaaa" é longa e não vale nada.
  const distintos = new Set(s).size
  pontos += Math.min(13, distintos)

  /* ---- descontos: o que torna a senha previsível ---- */

  const comum = COMUNS.find(p => letras.includes(p) || plano.includes(p))
  if (comum) {
    pontos -= 35
    sugestoes.push(`Evite "${comum}" — está nas primeiras listas que um ataque testa.`)
  }

  if (temSequencia(plano)) {
    pontos -= 22
    sugestoes.push("Evite sequências do teclado ou do alfabeto (abcd, 1234, qwer).")
  }

  if (temRepeticao(s)) {
    pontos -= 20
    sugestoes.push("Evite repetir o mesmo trecho.")
  }

  /* Ano isolado no fim é o padrão mais comum de todos: Senha2026. */
  if (/(19|20)\d{2}$/.test(s)) {
    pontos -= 12
    sugestoes.push("Terminar com o ano é o padrão mais previsível que existe.")
  }

  const pessoais = [
    contexto.nome ?? "",
    (contexto.email ?? "").split("@")[0] ?? "",
  ]
    .flatMap(v => semAcento(v).split(/[^a-z0-9]+/))
    .filter(p => p.length >= 4)

  if (pessoais.some(p => letras.includes(p) || plano.includes(p))) {
    pontos -= 30
    sugestoes.push("Não use seu nome nem o começo do seu e-mail.")
  }

  /* ---- o que ainda falta ---- */

  if (s.length < 10) {
    sugestoes.unshift("Use pelo menos 10 caracteres — o tamanho é o que mais protege.")
  } else if (s.length < 14 && variedade < 3) {
    sugestoes.push("Misture maiúsculas, números ou símbolos — ou alongue a senha.")
  }

  pontos = Math.max(0, Math.min(100, pontos))

  /* Frase longa passa mesmo com pouca variedade: 16 caracteres de palavras
     soltas dão mais trabalho que 8 com símbolo. */
  const fraseLonga = s.length >= 16 && !comum && !temSequencia(plano) && !temRepeticao(s)

  let nivel: NivelSenha
  if (pontos >= 75 || (fraseLonga && pontos >= 60)) nivel = "forte"
  else if (pontos >= 55) nivel = "boa"
  else if (pontos >= 35) nivel = "razoavel"
  else nivel = "fraca"

  /* Teto para senha construída sobre algo previsível.

     Sem isto, "Controllares1" somava pontos por tamanho e variedade e chegava a
     "razoável" — mas quem ataca a empresa começa pelo nome dela, e acrescentar
     um dígito não muda nada. O mesmo vale para sequência de teclado e para o
     próprio nome do usuário: nenhum desses vira senha aceitável só por ficar
     mais comprido. Frase longa de verdade escapa do teto, porque aí o tamanho
     realmente protege. */
  const previsivel = !!comum || temSequencia(plano) || temRepeticao(s)
  if (previsivel && !fraseLonga) nivel = "fraca"

  const ROTULOS: Record<NivelSenha, string> = {
    fraca: "Fraca", razoavel: "Razoável", boa: "Boa", forte: "Forte",
  }

  /* Mínimo aceito: 8 caracteres e nota acima de fraca. Barra o que cai em
     minutos sem obrigar a decorar uma senha impossível. */
  const aceitavel = s.length >= 8 && nivel !== "fraca"

  return {
    pontos,
    nivel,
    rotulo: ROTULOS[nivel],
    sugestoes: nivel === "forte" ? [] : sugestoes.slice(0, 3),
    aceitavel,
  }
}
