import { prisma } from "@/lib/prisma"
import type { JWTPayload } from "@/lib/auth"
import { registrarNoHistorico } from "@/lib/historico-lead"
import { faturamentoCompleto } from "@/lib/faturamento"
import { formatarDocumento } from "@/lib/documento"

/**
 * Devolve o cadastro conferido na proposta para a ficha do cliente no funil.
 *
 * Os dados de faturamento nasciam e morriam dentro da proposta. O mesmo
 * cliente voltava seis meses depois para a segunda obra e alguém pedia CPF,
 * CEP e endereço de novo — dados que a empresa já tinha, conferidos, num
 * contrato assinado. Pior: redigitado, o endereço voltava diferente.
 *
 * O caminho é de mão única, da proposta para o lead. O contrário reescreveria
 * proposta antiga quando o cliente muda de endereço, e proposta assinada é
 * retrato do que foi combinado, não um espelho do cadastro de hoje.
 *
 * Nunca derruba quem chamou: perder o espelhamento custa uma redigitação;
 * derrubar a geração do contrato para o cliente que está esperando custa mais.
 */
export async function espelharFaturamentoNoLead(
  session: JWTPayload,
  leadId: string | null | undefined,
  dados: {
    fat_razao_social?: string | null; fat_documento?: string | null
    fat_ie?: string | null; fat_email?: string | null
    fat_nascimento?: Date | string | null
    fat_cep?: string | null; fat_logradouro?: string | null; fat_numero?: string | null
    fat_complemento?: string | null; fat_bairro?: string | null
    fat_cidade?: string | null; fat_uf?: string | null
  },
  motivo: string,
  numeroProposta?: string | null,
) {
  try {
    if (!leadId) return
    /* Cadastro pela metade não sobrescreve cadastro inteiro. O vendedor salva o
       faturamento em duas sentadas — CNPJ agora, endereço quando o cliente
       responder —, e espelhar a primeira apagaria o que já estava certo. */
    if (!faturamentoCompleto(dados)) return

    const lead = await prisma.lead.findFirst({
      where: { id: leadId, companyId: session.companyId },
      select: { id: true, fat_documento: true },
    })
    if (!lead) return

    const documento = dados.fat_documento ?? null
    const trocouDocumento = !!lead.fat_documento && lead.fat_documento !== documento

    await prisma.lead.update({
      where: { id: lead.id },
      data: {
        fat_razao_social: dados.fat_razao_social ?? null,
        fat_documento: documento,
        fat_ie: dados.fat_ie ?? null,
        fat_email: dados.fat_email ?? null,
        fat_nascimento: dados.fat_nascimento ? new Date(dados.fat_nascimento) : null,
        fat_cep: dados.fat_cep ?? null,
        fat_logradouro: dados.fat_logradouro ?? null,
        fat_numero: dados.fat_numero ?? null,
        fat_complemento: dados.fat_complemento ?? null,
        fat_bairro: dados.fat_bairro ?? null,
        fat_cidade: dados.fat_cidade ?? null,
        fat_uf: dados.fat_uf ?? null,
        fat_confirmado_em: new Date(),
        fat_origem_proposta: numeroProposta ?? null,
      },
    })

    /* Troca de documento vira linha do histórico. Mudar o CPF de um cadastro
       para um CNPJ é o tipo de coisa que ninguém lembra de ter feito quando a
       nota sai no nome errado — e é exatamente o que o histórico existe para
       responder. */
    await registrarNoHistorico(session, {
      leadId: lead.id,
      etapa: "CADASTRO",
      tipo: "SISTEMA",
      texto: trocouDocumento
        ? `Cadastro do cliente atualizado (${motivo}) — documento alterado de ${formatarDocumento(lead.fat_documento!)} para ${formatarDocumento(documento ?? "")}.`
        : `Dados de faturamento guardados no cadastro (${motivo})${numeroProposta ? ` — proposta ${numeroProposta}` : ""}.`,
    })
  } catch {
    /* silêncio proposital: ver o comentário do topo */
  }
}
