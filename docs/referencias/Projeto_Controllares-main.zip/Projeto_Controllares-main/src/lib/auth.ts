import { SignJWT, jwtVerify } from "jose";

// Sem fallback: subir sem JWT_SECRET assinaria tokens com segredo público
// (qualquer um forjaria sessão). Falha explícita > brecha silenciosa.
if (!process.env.JWT_SECRET) {
  throw new Error("JWT_SECRET não configurado — defina a env var antes de iniciar.");
}
const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET);

export interface JWTPayload {
  userId: string;
  email: string;
  nome: string;
  role: string;
  roles?: string[];
  companyId: string;
}

export async function createToken(payload: JWTPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(JWT_SECRET);
}

export async function verifyToken(token: string): Promise<JWTPayload | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload as unknown as JWTPayload;
  } catch {
    return null;
  }
}
