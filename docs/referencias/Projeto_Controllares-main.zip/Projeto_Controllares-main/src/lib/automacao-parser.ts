/**
 * Parser do texto de ligação de módulos colado pelo usuário.
 * Formato real usado em campo (ver planilha/print):
 *
 *   Ligação módulos Superior
 *   M-03
 *   Entradas
 *   01 a 02 (KP-22; KP-31; KP-32)
 *   03 (KP-17)
 *
 *   Saidas
 *   01= Mini Spots Circulação
 *   02= Spots Chuveiro
 *
 * Regras:
 *  - "01 a 02 (...)" vira DUAS entradas (01 e 02), cada uma com os mesmos keypads
 *    — vários keypads na mesma entrada = ligados juntos.
 *  - Cabeçalhos "Entradas"/"Saidas" alternam a seção corrente.
 *  - Linha "M-03" (ou "MOD 3", "Módulo 3") abre um novo módulo.
 *  - Tolerante a acento, maiúsc/minúsc, "=" ou "-" como separador.
 */

export interface SaidaParsed { numero: string; descricao: string }
export interface EntradaParsed { numero: string; keypads: string[] }
export interface ModuloParsed {
  nome: string
  entradas: EntradaParsed[]
  saidas: SaidaParsed[]
}

const semAcento = (s: string) =>
  s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()

/** "01" | "1" → "01" (2 dígitos quando numérico) */
function pad(n: string): string {
  const num = parseInt(n, 10)
  return Number.isFinite(num) ? String(num).padStart(2, "0") : n.trim()
}

/** Extrai keypads de "(KP-22; KP-31, KP-32)" → ["KP-22","KP-31","KP-32"] */
function extrairKeypads(trecho: string): string[] {
  return trecho
    .split(/[;,/]+/)
    .map(s => s.trim().replace(/[()]/g, ""))
    .filter(Boolean)
}

export function parseLigacaoModulos(texto: string): ModuloParsed[] {
  const modulos: ModuloParsed[] = []
  let atual: ModuloParsed | null = null
  let secao: "entrada" | "saida" | null = null


  for (const linhaBruta of texto.split(/\r?\n/)) {
    const linha = linhaBruta.trim()
    if (!linha) continue
    const plain = semAcento(linha)

    // Cabeçalho de seção
    if (/^entradas?\b/.test(plain)) { secao = "entrada"; continue }
    if (/^saidas?\b/.test(plain)) { secao = "saida"; continue }

    // Novo módulo: "M-03", "M03", "MOD 3", "Módulo 3"
    const mModulo = linha.match(/^(?:m[-\s]?0*(\d+)|m[oó]dulo\s*0*(\d+)|mod\s*0*(\d+))\s*$/i)
    if (mModulo) {
      const n = mModulo[1] ?? mModulo[2] ?? mModulo[3]
      atual = { nome: `M-${pad(n)}`, entradas: [], saidas: [] }
      modulos.push(atual)
      secao = null
      continue
    }

    // Ignora títulos soltos ("Ligação módulos Superior") antes do 1º módulo
    if (!atual) continue

    if (secao === "entrada") {
      // "01 a 02 (KP-22; KP-31)" — faixa vira uma entrada por número
      const faixa = linha.match(/^(\d+)\s*(?:a|até|-|–)\s*(\d+)\s*\(([^)]*)\)/i)
      if (faixa) {
        const de = parseInt(faixa[1], 10), ate = parseInt(faixa[2], 10)
        const kps = extrairKeypads(faixa[3])
        for (let i = de; i <= ate; i++) atual.entradas.push({ numero: pad(String(i)), keypads: kps })
        continue
      }
      // "03 (KP-17)"
      const unica = linha.match(/^(\d+)\s*\(([^)]*)\)/)
      if (unica) {
        atual.entradas.push({ numero: pad(unica[1]), keypads: extrairKeypads(unica[2]) })
        continue
      }
      // "05" sem keypad
      const so = linha.match(/^(\d+)\s*$/)
      if (so) { atual.entradas.push({ numero: pad(so[1]), keypads: [] }); continue }
      continue
    }

    if (secao === "saida") {
      // "01= Mini Spots Circulação"  /  "01 - Spots"  /  "01: Spots"
      const m = linha.match(/^(\d+)\s*[=:\-–]\s*(.+)$/)
      if (m) { atual.saidas.push({ numero: pad(m[1]), descricao: m[2].trim() }); continue }
    }
  }

  // Só devolve módulos com algum conteúdo
  return modulos.filter(m => m.entradas.length > 0 || m.saidas.length > 0)
}
