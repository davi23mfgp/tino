/**
 * O vocabulário da ficha do cliente, num lugar só.
 *
 * As mesmas listas são usadas para validar no servidor e para desenhar os
 * botões na tela. Escritas duas vezes, elas divergem no primeiro campo novo —
 * a opção aparece na tela e a API a rejeita sem dizer por quê.
 */

/** Quem é a pessoa no projeto. */
export const PAPEIS_CONTATO = [
  { id: "CLIENTE",     label: "Cliente" },
  { id: "CONJUGE",     label: "Cônjuge" },
  { id: "ARQUITETO",   label: "Arquiteto" },
  { id: "ENGENHEIRO",  label: "Engenheiro" },
  { id: "MESTRE_OBRA", label: "Mestre de obra" },
  { id: "FINANCEIRO",  label: "Financeiro" },
  { id: "SINDICO",     label: "Síndico" },
  { id: "OUTRO",       label: "Outro" },
] as const

/** O quanto o cliente está perto de decidir — diferente da etapa do funil. */
export const TEMPERATURAS = [
  { id: "QUENTE", label: "Quente", cor: "bg-ios-red",    texto: "text-ios-red",    nota: "Decide nas próximas semanas" },
  { id: "MORNO",  label: "Morno",  cor: "bg-ios-orange", texto: "text-ios-orange", nota: "Interessado, sem data" },
  { id: "FRIO",   label: "Frio",   cor: "bg-ios-blue",   texto: "text-ios-blue",   nota: "Só pesquisando" },
] as const

export const TIPOS_IMOVEL = [
  { id: "CASA",        label: "Casa" },
  { id: "APARTAMENTO", label: "Apartamento" },
  { id: "COMERCIAL",   label: "Comercial" },
  { id: "CORPORATIVO", label: "Corporativo" },
  { id: "OUTRO",       label: "Outro" },
] as const

/**
 * Em que pé está a obra — o campo que decide QUANDO retomar.
 *
 * Infra em alvenaria pede decisão agora, porque depois o cabo não passa;
 * acabamento ainda dá tempo; imóvel pronto vira solução sem obra. Ligar na
 * etapa errada é perder a venda por tempo, não por preço.
 */
export const ETAPAS_OBRA = [
  { id: "PROJETO",    label: "Em projeto",  nota: "Ainda na planta" },
  { id: "FUNDACAO",   label: "Fundação",    nota: "Eletroduto na laje ainda cabe no projeto" },
  { id: "ALVENARIA",  label: "Alvenaria",   nota: "Hora da infra — depois o cabo não passa" },
  { id: "ACABAMENTO", label: "Acabamento",  nota: "Ainda dá tempo de prever pontos" },
  { id: "PRONTO",     label: "Pronto",      nota: "Sem obra — solução sem fio" },
  { id: "REFORMA",    label: "Reforma",     nota: "Obra em imóvel habitado" },
] as const

/** O que ele quer. Quase nunca é um só — e a lista mostra o que ficou fora. */
export const SISTEMAS = [
  { id: "AUTOMACAO",    label: "Automação" },
  { id: "SOM",          label: "Som ambiente" },
  { id: "HOME_THEATER", label: "Home theater" },
  { id: "REDE",         label: "Rede / Wi-Fi" },
  { id: "CFTV",         label: "CFTV" },
  { id: "ILUMINACAO",   label: "Iluminação" },
  { id: "CLIMATIZACAO", label: "Climatização" },
  { id: "PERSIANAS",    label: "Persianas" },
] as const

export const PAPEIS_VALIDOS: string[] = PAPEIS_CONTATO.map(p => p.id)
export const SISTEMAS_VALIDOS: string[] = SISTEMAS.map(s => s.id)
export const TEMPERATURAS_VALIDAS: string[] = TEMPERATURAS.map(t => t.id)
export const TIPOS_IMOVEL_VALIDOS: string[] = TIPOS_IMOVEL.map(t => t.id)
export const ETAPAS_OBRA_VALIDAS: string[] = ETAPAS_OBRA.map(e => e.id)

/** Rótulo de um id, para a tela não precisar de um `find` em cada linha. */
export function rotulo(
  lista: readonly { id: string; label: string }[],
  id: string | null | undefined,
): string {
  if (!id) return "—"
  return lista.find(x => x.id === id)?.label ?? id
}
