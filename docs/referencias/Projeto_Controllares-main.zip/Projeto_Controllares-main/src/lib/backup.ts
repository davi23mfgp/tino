import { prisma } from "@/lib/prisma"
import { put } from "@vercel/blob"
import { enviarParaDrive } from "@/lib/google-drive"

/**
 * Backup diário por empresa.
 *
 * Guarda o que é trabalho acumulado e caro de refazer: propostas (com itens,
 * parcelas e páginas), obras (com ambientes, vistorias e quadros de automação)
 * e os cadastros que sustentam tudo isso.
 *
 * NÃO entra aqui: senha, token de integração e chave de API. Backup é para
 * recuperar trabalho perdido, não para virar um segundo lugar onde credencial
 * pode vazar.
 */

export interface ResumoBackup {
  [tabela: string]: number
}

/** Monta o conteúdo do backup de uma empresa. */
export async function montarBackup(companyId: string) {
  const [
    propostas, obras, produtos, categorias, kits,
    clientes, campanhas, templates, usuarios,
  ] = await Promise.all([
    prisma.proposal.findMany({
      where: { companyId },
      include: {
        environments: { include: { proposalItems: true } },
        installments: true,
        extraPages: true,
        versions: true,
      },
    }),
    prisma.obra.findMany({
      where: { companyId },
      include: {
        environments: { include: { proposalItems: true } },
        automacaoQuadros: { include: { modulos: { include: { entradas: true, saidas: true } } } },
        keypads: { include: { acoes: true } },
        automacaoPontos: true,
        projectStages: true,
        ganttTasks: true,
        maintenanceTickets: true,
      },
    }),
    prisma.catalogProduct.findMany({ where: { companyId } }),
    prisma.category.findMany({ where: { companyId } }),
    prisma.kit.findMany({ where: { companyId }, include: { items: true } }),
    prisma.lead.findMany({ where: { companyId } }),
    prisma.discountCampaign.findMany({ where: { companyId } }),
    prisma.proposalTemplate.findMany({ where: { companyId } }),
    // Só identificação: nada de senha ou 2FA.
    prisma.user.findMany({
      where: { companyId },
      select: { id: true, nome: true, email: true, role: true, roles: true, status: true, createdAt: true },
    }),
  ])

  const conteudo = {
    versao: 1,
    companyId,
    geradoEm: new Date().toISOString(),
    propostas, obras, produtos, categorias, kits,
    clientes, campanhas, templates, usuarios,
  }

  const resumo: ResumoBackup = {
    propostas: propostas.length,
    obras: obras.length,
    produtos: produtos.length,
    categorias: categorias.length,
    kits: kits.length,
    clientes: clientes.length,
    campanhas: campanhas.length,
    templates: templates.length,
    usuarios: usuarios.length,
  }

  return { conteudo, resumo }
}

function tokenBlob(): string | undefined {
  return (
    process.env.BLOB_READ_WRITE_TOKEN ||
    Object.entries(process.env).find(([k]) => k.endsWith("_READ_WRITE_TOKEN"))?.[1]
  )
}

/**
 * Gera e grava um snapshot. Guarda no Blob quando há token (privado, é o certo
 * para backup) e cai para JSON na própria linha quando não há — assim o
 * ambiente local também funciona.
 */
export async function gerarBackup(companyId: string, origem: "AUTO" | "MANUAL" = "AUTO") {
  const { conteudo, resumo } = await montarBackup(companyId)
  const json = JSON.stringify(conteudo)
  const tamanho = Buffer.byteLength(json, "utf8")
  const token = tokenBlob()

  let arquivo_url: string | null = null
  let dados: object | null = null
  let erro: string | null = null

  // O backup carrega a base inteira da empresa: propostas, obras, clientes.
  // Só vai para o Blob se ele aceitar arquivo PRIVADO. Numa Store pública, a
  // URL é aberta a quem a tiver, e um dump completo lá seria vazamento — nesse
  // caso o conteúdo fica guardado na própria linha do banco.
  if (token) {
    try {
      const nome = `backups/${companyId}/${new Date().toISOString().slice(0, 10)}-${Date.now()}.json`
      const blob = await put(nome, json, {
        access: "private",
        token,
        contentType: "application/json",
        addRandomSuffix: true,
      })
      arquivo_url = blob.url
    } catch (e) {
      const msg = e instanceof Error ? e.message : ""
      // Store pública: não é erro, é só o caminho de guardar no banco.
      if (!/public store|private access/i.test(msg)) {
        erro = msg || "falha ao gravar no Blob"
      }
    }
  }

  // Sem Blob privado: guarda inline, desde que caiba com folga.
  if (!arquivo_url) {
    if (tamanho <= 4_000_000) dados = conteudo
    else erro = (erro ? `${erro}; ` : "") + `backup de ${Math.round(tamanho / 1024)} KB grande demais para guardar no banco — configure uma Blob Store privada`
  }

  /* Cópia no Drive da empresa.
     O Blob fica no mesmo fornecedor que hospeda o sistema — backup que mora
     junto com o que ele protege é cópia, não backup. O Drive é outro lugar, e
     é um lugar que o dono abre sozinho, sem depender de painel nenhum.

     Falha aqui não derruba a rotina: o snapshot local já está pronto, e ficar
     sem a cópia externa é pior do que ficar sem backup nenhum apenas se
     ninguém for avisado — por isso o motivo entra em `erro`. */
  let drive_url: string | null = null
  const envio = await enviarParaDrive(
    companyId,
    `${new Date().toISOString().slice(0, 10)}-backup.json`,
    json,
  ).catch(() => ({ erro: "falha ao falar com o Drive" }))

  if ("url" in envio) drive_url = envio.url
  else if (envio.erro !== "Drive não conectado.") {
    erro = (erro ? `${erro}; ` : "") + envio.erro
  }

  return prisma.backupSnapshot.create({
    data: {
      companyId,
      origem,
      // Sem Blob privado, a URL do Drive é o único endereço do arquivo.
      arquivo_url: arquivo_url ?? drive_url,
      dados: dados as never,
      resumo: resumo as never,
      tamanho_bytes: tamanho,
      erro,
    },
    select: { id: true, createdAt: true, resumo: true, tamanho_bytes: true, erro: true, origem: true },
  })
}

/** Mantém os N snapshots mais recentes por empresa; o resto sai. */
export async function limparBackupsAntigos(companyId: string, manter = 30) {
  const antigos = await prisma.backupSnapshot.findMany({
    where: { companyId },
    orderBy: { createdAt: "desc" },
    skip: manter,
    select: { id: true },
  })
  if (!antigos.length) return 0
  await prisma.backupSnapshot.deleteMany({ where: { id: { in: antigos.map(a => a.id) } } })
  return antigos.length
}

/** Lê o conteúdo de um snapshot, venha do Blob ou de dentro da linha. */
export async function lerBackup(id: string, companyId: string) {
  const snap = await prisma.backupSnapshot.findFirst({ where: { id, companyId } })
  if (!snap) return null
  if (snap.dados) return snap.dados as Record<string, unknown>
  if (!snap.arquivo_url) return null

  const token = tokenBlob()
  const r = await fetch(snap.arquivo_url, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  })
  if (!r.ok) return null
  return (await r.json()) as Record<string, unknown>
}
