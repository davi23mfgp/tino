/**
 * Como número, dinheiro e data aparecem na tela.
 *
 * Isto existia em 20 cópias espalhadas: cada tela declarava o seu `brl` no
 * topo do arquivo. A maioria era idêntica, mas não todas — três telas usavam
 * `maximumFractionDigits: 0` de propósito, para caber o valor numa lista
 * apertada. Quando a regra mora em 20 lugares, mudar o formato do dinheiro
 * vira caça ao tesouro, e a variação de propósito fica indistinguível do
 * esquecimento.
 *
 * Aqui cada variação tem nome, e quem lê o código sabe qual está usando.
 *
 * Para campo que se formata enquanto a pessoa digita, veja lib/mascara.ts —
 * este arquivo é só leitura.
 */

/* O Intl separa "R$" do número com espaço NÃO SEPARÁVEL (U+00A0), que é
   invisível e não é igual ao espaço do teclado. Quem comparar o texto, buscar
   por "R$ " num teste ou colar o valor num e-mail leva um susto silencioso. */
const semEspacoEstranho = (s: string) => s.replace(/ /g, " ")

const fmtReal = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" })
const fmtRealSemCentavos = new Intl.NumberFormat("pt-BR", {
  style: "currency", currency: "BRL", maximumFractionDigits: 0,
})
const fmtNumero = new Intl.NumberFormat("pt-BR")

/** "R$ 1.234,56" — o padrão. */
export const brl = (v: number) => semEspacoEstranho(fmtReal.format(v))

/**
 * "R$ 1.235" — sem centavos.
 *
 * Para lista e cartão, onde o centavo não muda decisão nenhuma e só rouba
 * largura. Nunca em documento que vai ao cliente: lá o valor precisa fechar
 * com a soma.
 */
export const brlSemCentavos = (v: number) => semEspacoEstranho(fmtRealSemCentavos.format(v))

/**
 * "R$ 1,2M", "R$ 350k" — para eixo de gráfico, onde não cabe o número inteiro.
 *
 * Só serve para rótulo de eixo. Em qualquer outro lugar, o arredondamento
 * engana: "R$ 2M" pode ser 1,5 milhão.
 */
export const brlCurto = (v: number) =>
  v >= 1_000_000 ? `R$ ${(v / 1_000_000).toLocaleString("pt-BR", { maximumFractionDigits: 1 })}M`
  : v >= 1_000 ? `R$ ${Math.round(v / 1_000)}k`
  : `R$ ${v}`

/** "1.234,5" — número comum, com separador de milhar. */
export const num = (v: number, casas = 0) =>
  casas === 0 ? fmtNumero.format(v)
  : v.toLocaleString("pt-BR", { minimumFractionDigits: 0, maximumFractionDigits: casas })

/** "12,5%" */
export const pct = (v: number, casas = 1) =>
  `${v.toLocaleString("pt-BR", { maximumFractionDigits: casas })}%`

/** "31/12/2026". Data ausente vira travessão, não "Invalid Date". */
export const data = (d: string | Date | null | undefined) => {
  if (!d) return "—"
  const dt = d instanceof Date ? d : new Date(d)
  return Number.isNaN(dt.getTime()) ? "—" : dt.toLocaleDateString("pt-BR")
}

/** "31/12/2026 14:30" */
export const dataHora = (d: string | Date | null | undefined) => {
  if (!d) return "—"
  const dt = d instanceof Date ? d : new Date(d)
  if (Number.isNaN(dt.getTime())) return "—"
  return `${dt.toLocaleDateString("pt-BR")} ${dt.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}`
}

/**
 * "257,2 mm" — número com unidade, do mesmo jeito que o campo mascarado mostra.
 *
 * Não converte unidade: recebe o número já na unidade que vai aparecer.
 */
export const medida = (v: number | null | undefined, unidade: string, casas = 2) =>
  v === null || v === undefined || !Number.isFinite(Number(v))
    ? "—"
    : `${num(Number(v), casas)}${unidade ? " " + unidade : ""}`
