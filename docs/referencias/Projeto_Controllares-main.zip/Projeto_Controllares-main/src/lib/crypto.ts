import crypto from "crypto";

// Criptografia simétrica AES-256-GCM para dados sensíveis "at-rest"
// (senhas do cofre técnico, tokens de proposta, etc).
// A chave vem da variável de ambiente ENCRYPTION_KEY (32 bytes em hex).

const ALGORITHM = "aes-256-gcm";

function getKey(): Buffer {
  const raw = process.env.ENCRYPTION_KEY;
  if (!raw) {
    throw new Error("ENCRYPTION_KEY não definida no .env");
  }
  // Aceita chave em hex (64 chars = 32 bytes). Caso contrário, deriva via SHA-256.
  if (/^[0-9a-fA-F]{64}$/.test(raw)) {
    return Buffer.from(raw, "hex");
  }
  return crypto.createHash("sha256").update(raw).digest();
}

// Criptografa um texto e devolve string no formato: iv:authTag:cipherText (tudo em hex)
export function encrypt(plainText: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGORITHM, getKey(), iv);
  const encrypted = Buffer.concat([
    cipher.update(plainText, "utf8"),
    cipher.final(),
  ]);
  const authTag = cipher.getAuthTag();
  return [iv.toString("hex"), authTag.toString("hex"), encrypted.toString("hex")].join(":");
}

// Descriptografa a string gerada por encrypt()
export function decrypt(payload: string): string {
  const [ivHex, tagHex, dataHex] = payload.split(":");
  if (!ivHex || !tagHex || !dataHex) {
    throw new Error("Formato de dado criptografado inválido");
  }
  const decipher = crypto.createDecipheriv(ALGORITHM, getKey(), Buffer.from(ivHex, "hex"));
  decipher.setAuthTag(Buffer.from(tagHex, "hex"));
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(dataHex, "hex")),
    decipher.final(),
  ]);
  return decrypted.toString("utf8");
}

// Gera um token aleatório seguro (para link_token de propostas, por ex.)
export function generateSecureToken(bytes = 24): string {
  return crypto.randomBytes(bytes).toString("hex");
}
