import crypto from "crypto"
import { cookies } from "next/headers"

/**
 * Segunda porta do painel Sistema.
 *
 * Estar logado como Admin não basta para abrir esta tela. Ela mostra tentativas
 * de invasão, endereços, o que ainda está aberto no sistema — é o mapa que
 * alguém de fora usaria para saber por onde entrar. E o risco concreto não é
 * invasão remota: é a sessão do Admin já aberta numa máquina, com o técnico ou
 * o programador do lado, precisando mexer no sistema.
 *
 * Por isso o código do segundo fator é pedido na hora de entrar, e não só no
 * login. Quem senta na cadeira precisa do aparelho do Admin naquele instante.
 * A liberação dura pouco de propósito: sair da mesa devolve a porta ao lugar.
 */

/* Curto: é o tempo de olhar o painel, não de deixar aberto a tarde toda. */
const VALIDADE_MIN = 20
const COOKIE = "sistema_acesso"

function segredo(): string {
  const raw = process.env.ENCRYPTION_KEY || process.env.NEXTAUTH_SECRET
  if (!raw) throw new Error("ENCRYPTION_KEY não definida — o acesso ao painel não pode ser assinado")
  return raw
}

const hmac = (v: string) => crypto.createHmac("sha256", segredo()).update(v).digest("hex")

function iguais(a: string, b: string): boolean {
  const ba = Buffer.from(a), bb = Buffer.from(b)
  if (ba.length !== bb.length) return false
  return crypto.timingSafeEqual(ba, bb)
}

/* O cookie é atrelado ao usuário: uma liberação não vale para outra conta que
   venha a usar o mesmo navegador depois. */
function montar(userId: string): string {
  const expira = Date.now() + VALIDADE_MIN * 60_000
  return `${expira}.${hmac(`${userId}.${expira}`)}`
}

export async function abrirSessaoSistema(userId: string) {
  const jar = await cookies()
  jar.set(COOKIE, montar(userId), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",     // painel sensível: nem em navegação vinda de fora
    path: "/",
    maxAge: VALIDADE_MIN * 60,
  })
}

export async function fecharSessaoSistema() {
  const jar = await cookies()
  jar.set(COOKIE, "", { httpOnly: true, path: "/", expires: new Date(0) })
}

/** O Admin desta sessão já confirmou o segundo fator há pouco? */
export async function temSessaoSistema(userId: string): Promise<boolean> {
  const jar = await cookies()
  const valor = jar.get(COOKIE)?.value
  if (!valor) return false
  const [expiraStr, assinatura] = valor.split(".")
  const expira = Number(expiraStr)
  if (!expira || !assinatura || expira < Date.now()) return false
  return iguais(assinatura, hmac(`${userId}.${expira}`))
}

export const VALIDADE_SESSAO_SISTEMA_MIN = VALIDADE_MIN
