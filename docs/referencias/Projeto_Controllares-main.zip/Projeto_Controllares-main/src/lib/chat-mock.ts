/**
 * Dado fictício pra pré-visualizar a tela de Chat antes do wacrm estar no
 * ar de verdade (sem Supabase/Meta configurados ainda). Quando o
 * WACRM_API_URL/WACRM_API_KEY existirem, essa tela troca pra
 * `src/lib/wacrm.ts` (proxy real) — nada aqui sobrevive além do preview.
 */

export interface ChatMessage {
  id: string
  direction: "inbound" | "outbound"
  contentType: "text" | "audio" | "image" | "menu"
  text?: string
  audioDurationSec?: number
  /** Só pra contentType "menu" — a lista que o WhatsApp mostra como botão
   *  "Selecione uma opção", igual o send_list das automações. */
  menuOptions?: string[]
  status: "sent" | "delivered" | "read"
  createdAt: string
  /** Só existe pra áudio gravado ao vivo na pré-visualização (blob: URL local). */
  _previewUrl?: string
}

export interface HandoffSummary {
  /** Setor/pessoa que atendeu naquele trecho antigo, resetado da visão. */
  fromSetor: string
  fromAgent: string
  /** Quando esse trecho foi atendido (não é agora). */
  periodo: string
  texto: string
}

export interface ChatConversation {
  id: string
  contactName: string
  contactPhone: string
  avatarInitial: string
  setor: string
  lastMessage: string
  lastMessageAt: string
  unread: number
  messages: ChatMessage[]
  /** Resumo salvo de um atendimento anterior desse mesmo contato, gerado
   *  por IA no momento do handoff (antes do reset da migration 042)
   *  apagar a visão. Só aparece pra quem atendeu aquele trecho. */
  handoffSummary?: HandoffSummary
}

export const MOCK_CONVERSATIONS: ChatConversation[] = [
  {
    id: "c1",
    contactName: "Marina Kowalski",
    contactPhone: "+55 11 98421-7730",
    avatarInitial: "M",
    setor: "Comercial",
    lastMessage: "Perfeito, vou aguardar o orçamento então",
    lastMessageAt: "09:41",
    unread: 2,
    messages: [
      { id: "m1", direction: "inbound", contentType: "text", text: "Oi, vi o anúncio de vocês no Instagram", status: "read", createdAt: "09:12" },
      { id: "m2", direction: "outbound", contentType: "text", text: "Olá Marina! Tudo bem? Você foi direcionada para o setor Comercial.", status: "read", createdAt: "09:13" },
      { id: "m3", direction: "inbound", contentType: "audio", audioDurationSec: 18, status: "read", createdAt: "09:20" },
      { id: "m4", direction: "outbound", contentType: "text", text: "Recebido! Vou preparar um orçamento pra sala de cinema que você descreveu.", status: "delivered", createdAt: "09:25" },
      { id: "m5", direction: "inbound", contentType: "text", text: "Perfeito, vou aguardar o orçamento então", status: "read", createdAt: "09:41" },
    ],
  },
  {
    id: "c2",
    contactName: "Rogério Assunção",
    contactPhone: "+55 21 99887-1123",
    avatarInitial: "R",
    setor: "Suporte",
    lastMessage: "🎤 Mensagem de voz",
    lastMessageAt: "ontem",
    unread: 0,
    messages: [
      { id: "m1", direction: "inbound", contentType: "text", text: "O controle não tá ligando a tela", status: "read", createdAt: "18:02" },
      { id: "m2", direction: "outbound", contentType: "audio", audioDurationSec: 34, status: "read", createdAt: "18:10" },
    ],
  },
  {
    id: "c3",
    contactName: "Bianca Ferraz",
    contactPhone: "+55 11 97733-4021",
    avatarInitial: "B",
    setor: "Financeiro",
    lastMessage: "Obrigada, já caiu aqui certinho",
    lastMessageAt: "ontem",
    unread: 0,
    messages: [
      { id: "m1", direction: "inbound", contentType: "text", text: "Bom dia, poderia reenviar o boleto?", status: "read", createdAt: "14:00" },
      { id: "m2", direction: "outbound", contentType: "text", text: "Bom dia Bianca! Segue o boleto atualizado.", status: "read", createdAt: "14:05" },
      { id: "m3", direction: "inbound", contentType: "text", text: "Obrigada, já caiu aqui certinho", status: "read", createdAt: "14:22" },
    ],
  },
  {
    id: "c4",
    contactName: "Felipe Nakashima",
    contactPhone: "+55 11 96612-9987",
    avatarInitial: "F",
    setor: "Agendar Showroom",
    lastMessage: "Vamos agendar sua visita! Débora vai confirmar.",
    lastMessageAt: "seg",
    unread: 1,
    messages: [
      { id: "m1", direction: "inbound", contentType: "text", text: "Queria conhecer o showroom de vocês", status: "read", createdAt: "seg" },
      { id: "m2", direction: "outbound", contentType: "text", text: "Vamos agendar sua visita! Débora vai confirmar o melhor horário com você.", status: "delivered", createdAt: "seg" },
    ],
  },
  {
    id: "c5",
    contactName: "Yasmin Prado",
    contactPhone: "+55 11 99045-2287",
    avatarInitial: "Y",
    setor: "Comercial",
    lastMessage: "Você foi direcionado(a) para o setor Comercial.",
    lastMessageAt: "10:52",
    unread: 0,
    // Simula o pedido de troca de setor: cliente já tava em Suporte (com
    // Davi), pede pra falar com outro setor no meio da conversa, o bot
    // manda o mesmo menu inicial de novo, cliente escolhe, e a conversa
    // muda de dono — igual o exemplo do Controlart que o usuário mandou.
    messages: [
      { id: "m1", direction: "inbound", contentType: "text", text: "Meu controle não liga a tela", status: "read", createdAt: "10:20" },
      { id: "m2", direction: "outbound", contentType: "text", text: "Você foi direcionado(a) para o setor Suporte.\nEm breve um atendente entrará em contato. Se possível descreva sua necessidade e agilizaremos seu atendimento.", status: "read", createdAt: "10:20" },
      { id: "m3", direction: "outbound", contentType: "text", text: "Davi:\nOlá, tudo certo? Me chamo Davi, sou o responsável pelo seu atendimento hoje. Como posso ajudar?", status: "read", createdAt: "10:24" },
      { id: "m4", direction: "inbound", contentType: "text", text: "Na verdade já resolvi isso, queria falar sobre um orçamento novo mesmo", status: "read", createdAt: "10:48" },
      { id: "m5", direction: "inbound", contentType: "text", text: "Menu", status: "read", createdAt: "10:49" },
      {
        id: "m6",
        direction: "outbound",
        contentType: "menu",
        text: "Bem-vindo(a)! Selecione abaixo o setor que você precisa:",
        menuOptions: ["Comercial", "Engenharia / Execução", "Suporte", "Financeiro", "Agendar Showroom"],
        status: "read",
        createdAt: "10:49",
      },
      { id: "m7", direction: "inbound", contentType: "text", text: "1 Comercial", status: "read", createdAt: "10:52" },
      { id: "m8", direction: "outbound", contentType: "text", text: "Você foi direcionado(a) para o setor Comercial.\nEm breve um atendente entrará em contato.", status: "read", createdAt: "10:52" },
    ],
  },
  {
    id: "c6",
    contactName: "Otávio Ramires",
    contactPhone: "+55 11 98812-4456",
    avatarInitial: "O",
    setor: "Suporte",
    lastMessage: "O mesmo problema de novo? Vou já olhar isso pra você",
    lastMessageAt: "hoje",
    unread: 1,
    // Cenário do resumo de handoff: Otávio já foi atendido pelo Davi meses
    // atrás (resolvido), depois passou pro Comercial pra fechar outra
    // compra, e agora voltou de novo pro Suporte com o MESMO tipo de
    // problema. A migration 042 reseta a visão do Davi pro que rolou nesse
    // meio tempo — mas o resumo salvo (gerado antes do reset, mandado por
    // push na hora) reaparece aqui pra ele não perder o contexto de quando
    // ele mesmo já tinha atendido esse cliente.
    handoffSummary: {
      fromSetor: "Suporte",
      fromAgent: "Davi",
      periodo: "14 de julho",
      texto:
        "Cliente relatou controle remoto sem resposta no sensor de IV. Orientado a trocar " +
        "as pilhas e reposicionar o receptor — resolveu na hora, sem precisar de visita técnica. " +
        "Nenhuma pendência ficou em aberto.",
    },
    messages: [
      { id: "m1", direction: "inbound", contentType: "text", text: "Boa tarde! O controle da sala tá travando nas mesmas de julho de novo", status: "read", createdAt: "hoje 09:10" },
      { id: "m2", direction: "outbound", contentType: "text", text: "Você foi direcionado(a) para o setor Suporte.\nEm breve um atendente entrará em contato.", status: "read", createdAt: "hoje 09:10" },
      { id: "m3", direction: "outbound", contentType: "text", text: "Davi:\nO mesmo problema de novo? Vou já olhar isso pra você", status: "delivered", createdAt: "hoje 09:14" },
    ],
  },
]
