import type { Prisma, PrismaClient } from "@prisma/client"
import { valorDoServico, type ServicoProposta } from "@/lib/servicos-proposta"

type Db = PrismaClient | Prisma.TransactionClient

/**
 * O cliente levou só parte dos sistemas.
 *
 * Proposta com automação, som e rede é uma decisão por sistema, não uma só: ele
 * fecha um agora e adia o resto. Antes isso obrigava o vendedor a refazer a
 * proposta inteira, e o que ficou de fora se perdia na conversa.
 *
 * O que ele não escolheu vira GUARDADO — sai do documento e do valor, mas
 * continua no histórico do cliente, pronto para virar proposta depois (ficha do
 * lead → "Histórico de sistemas"). O que segue adiante (obra, contrato,
 * financeiro) é só o que ele marcou.
 *
 * Recebe o client do Prisma para poder rodar dentro de transação — é o que
 * permite testar contra o banco de verdade sem deixar rastro
 * (scripts/verificar-escolha-sistemas.mts).
 *
 * Devolve o que sobrou, ou null quando não há nada a fazer (escolheu tudo, não
 * escolheu nada reconhecível, ou a proposta tem um sistema só).
 */
export async function aplicarEscolhaDeSistemas(
  db: Db,
  proposalId: string,
  escolhidos: string[] | undefined,
  descontoPct: number,
  /* Projeto e instalação é um bloco da escolha, como os sistemas: o cliente
     pode levar os produtos e deixar a instalação de fora. Sem isto o serviço
     era cobrado de qualquer jeito, contrariando o que ele marcou. */
  manterServico = true,
): Promise<{ guardados: number; sobraram: number; valorTotal: number } | null> {
  const listaValida = Array.isArray(escolhidos) && escolhidos.length > 0
  if (!listaValida && manterServico) return null

  const envs = await db.environment.findMany({
    where: { proposalId, status: "ATIVO" },
    select: {
      id: true,
      proposalItems: { select: { valor_total: true, categoryId: true } },
    },
  })
  const marcados = new Set(
    listaValida
      ? escolhidos!.filter(id => envs.some(e => e.id === id))
      : envs.map(e => e.id),
  )
  /* Escolheu tudo (ou nada reconhecível): a proposta segue como está — a menos
     que ele tenha dispensado o projeto e instalação, que também muda o valor. */
  if (marcados.size === 0) return null
  if (marcados.size === envs.length && manterServico) return null

  const guardar = envs.filter(e => !marcados.has(e.id)).map(e => e.id)
  await db.environment.updateMany({
    where: { id: { in: guardar } },
    data: { status: "GUARDADO" },
  })

  const proposta = await db.proposal.findUnique({
    where: { id: proposalId },
    select: { servicos_detalhe: true, valor_servico: true },
  })

  const itens = envs
    .filter(e => marcados.has(e.id))
    .flatMap(e => e.proposalItems.map(i => ({
      environmentId: e.id,
      categoryId: i.categoryId ?? null,
      valor_total: Number(i.valor_total),
    })))
  const produtos = itens.reduce((s, i) => s + i.valor_total, 0)

  /* Serviço acompanha o que ficou: percentual recalcula sobre a nova base e
     serviço preso a um sistema guardado sai junto com ele. Proposta antiga, sem
     a composição detalhada, só dá para ratear pelo valor dos produtos — é a
     única divisão que o dado sustenta. */
  const detalhe = Array.isArray(proposta?.servicos_detalhe)
    ? (proposta.servicos_detalhe as unknown as ServicoProposta[])
    : []
  let servico: number
  if (!manterServico) {
    servico = 0
  } else if (detalhe.length) {
    servico = detalhe
      .filter(s => !s.environmentId || marcados.has(s.environmentId))
      .reduce((sum, s) => sum + valorDoServico(s, itens), 0)
  } else {
    const produtosAntes = envs.flatMap(e => e.proposalItems)
      .reduce((s, i) => s + Number(i.valor_total), 0)
    const fatia = produtosAntes > 0 ? produtos / produtosAntes : 0
    servico = Number(proposta?.valor_servico ?? 0) * fatia
  }

  /* Parcelas montadas com o valor cheio não valem mais. Elas ainda são projeção
     — a proposta não foi aceita até agora —, então saem e o cronograma é refeito
     do valor novo no aceite. */
  await db.installment.deleteMany({ where: { proposalId } })

  const valorTotal = (produtos + servico) * (1 - descontoPct / 100)
  await db.proposal.update({
    where: { id: proposalId },
    data: { valor_servico: servico, valor_total: valorTotal },
  })

  return { guardados: guardar.length, sobraram: marcados.size, valorTotal }
}
