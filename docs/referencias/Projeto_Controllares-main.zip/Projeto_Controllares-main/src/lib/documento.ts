/**
 * CPF, CNPJ e CEP: normalização, validação e formatação.
 *
 * Validar antes de mandar ao Olist evita o pior caso: a nota é recusada lá,
 * alguém precisa descobrir por quê, e a obra atrasa por causa de um dígito.
 */

/** Só os dígitos — é assim que o documento é guardado. */
export const soDigitos = (v: string | null | undefined) => (v ?? "").replace(/\D/g, "")

/** Dígito verificador no padrão da Receita (CPF e CNPJ usam a mesma ideia). */
function digitoVerificador(base: string, pesos: number[]): number {
  const soma = base.split("").reduce((s, d, i) => s + Number(d) * pesos[i], 0)
  const resto = soma % 11
  return resto < 2 ? 0 : 11 - resto
}

export function validarCPF(valor: string): boolean {
  const cpf = soDigitos(valor)
  if (cpf.length !== 11) return false
  // 111.111.111-11 e afins passam na conta dos dígitos, mas não existem.
  if (/^(\d)\1{10}$/.test(cpf)) return false
  const d1 = digitoVerificador(cpf.slice(0, 9), [10, 9, 8, 7, 6, 5, 4, 3, 2])
  const d2 = digitoVerificador(cpf.slice(0, 10), [11, 10, 9, 8, 7, 6, 5, 4, 3, 2])
  return cpf[9] === String(d1) && cpf[10] === String(d2)
}

export function validarCNPJ(valor: string): boolean {
  const cnpj = soDigitos(valor)
  if (cnpj.length !== 14) return false
  if (/^(\d)\1{13}$/.test(cnpj)) return false
  const p1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
  const p2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
  const d1 = digitoVerificador(cnpj.slice(0, 12), p1)
  const d2 = digitoVerificador(cnpj.slice(0, 13), p2)
  return cnpj[12] === String(d1) && cnpj[13] === String(d2)
}

export type TipoDocumento = "CPF" | "CNPJ" | "INVALIDO"

/** Descobre o tipo pelo tamanho e confere os dígitos. */
export function tipoDocumento(valor: string): TipoDocumento {
  const d = soDigitos(valor)
  if (d.length === 11) return validarCPF(d) ? "CPF" : "INVALIDO"
  if (d.length === 14) return validarCNPJ(d) ? "CNPJ" : "INVALIDO"
  return "INVALIDO"
}

export function formatarDocumento(valor: string): string {
  const d = soDigitos(valor)
  if (d.length === 11) return d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")
  if (d.length === 14) return d.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, "$1.$2.$3/$4-$5")
  return valor
}

/**
 * Telefone brasileiro com o DDD entre parênteses.
 *
 * Aceita 10 ou 11 dígitos e devolve "(17) 98821-1987". Número fora desses
 * tamanhos volta como veio: pode ser ramal, número internacional ou algo que
 * alguém digitou à mão — e cortar dígito para caber na máscara estraga o
 * contato justamente de quem mais precisa ser encontrado.
 */
export const formatarTelefone = (valor: string | null | undefined) => {
  const d = soDigitos(valor ?? "")
  if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`
  if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`
  return valor ?? ""
}

export const formatarCEP = (valor: string) => {
  const d = soDigitos(valor).slice(0, 8)
  return d.length > 5 ? `${d.slice(0, 5)}-${d.slice(5)}` : d
}

export interface EnderecoCEP {
  cep: string
  logradouro: string
  bairro: string
  cidade: string
  uf: string
}

export interface DadosCNPJ {
  razao_social: string
  nome_fantasia?: string | null
  email?: string | null
  cep?: string | null
  logradouro?: string | null
  numero?: string | null
  complemento?: string | null
  bairro?: string | null
  cidade?: string | null
  uf?: string | null
  situacao?: string | null
  /* Abaixo, o que a Receita publica e serve para conferir a empresa antes de
     faturar. Não vira campo do cadastro: aparece na confirmação da busca, que é
     o momento em que alguém decide se é mesmo esta a empresa. */
  telefone?: string | null
  porte?: string | null
  natureza_juridica?: string | null
  atividade?: string | null
  /** Muda a tributação da nota — o financeiro precisa saber antes de emitir. */
  simples?: boolean | null
  mei?: boolean | null
  abertura?: string | null
  socios?: string[] | null
}
