import { prisma } from "@/lib/prisma"
import { encrypt, decrypt } from "@/lib/crypto"

/**
 * Google Drive da empresa — onde o backup do sistema vai parar.
 *
 * O backup já existia, mas ficava no Blob da Vercel: mesmo fornecedor que
 * hospeda o sistema. Backup que mora junto com o que ele protege não é backup —
 * é cópia. O Drive resolve isso por ser outro lugar, e por ser um lugar que o
 * dono da empresa abre sozinho, sem depender de painel nenhum.
 *
 * O token fica na empresa, não no usuário que autorizou. Quem grava é o cron da
 * madrugada, quando ninguém está logado; e token de pessoa some quando a pessoa
 * sai da empresa, levando o backup junto.
 *
 * Escopo `drive.file`: o app enxerga apenas o que ele mesmo criou. Não é
 * economia de permissão por formalidade — é a diferença entre um vazamento
 * expor os backups e expor o Drive inteiro de quem autorizou.
 */

const OAUTH = "https://oauth2.googleapis.com/token"
const API = "https://www.googleapis.com/drive/v3"
const UPLOAD = "https://www.googleapis.com/upload/drive/v3/files"

/* Dois escopos, dois propósitos.

   `drive.file` permite criar e enxergar apenas o que o próprio app criou — é o
   que o backup precisa, e nada além disso.

   `drive.readonly` permite ler o que VOCÊ põe no Drive, e é o que a base de
   conhecimento exige: não há como indexar um manual que o app nunca criou.
   É leitura, nunca escrita: o app não altera nem apaga nada seu. */
export const ESCOPO_DRIVE = [
  "https://www.googleapis.com/auth/drive.file",
  "https://www.googleapis.com/auth/drive.readonly",
].join(" ")

function credenciais(empresa: { google_client_id: string | null; google_client_secret: string | null }) {
  const id = empresa.google_client_id || process.env.GOOGLE_CLIENT_ID
  const secret = empresa.google_client_secret || process.env.GOOGLE_CLIENT_SECRET
  return id && secret ? { id, secret } : null
}

/**
 * Access token novo a partir do refresh token guardado.
 *
 * Não guarda o access token: ele vale uma hora, e o backup roda uma vez por
 * dia. Guardar exigiria controlar validade para economizar uma chamada por dia.
 */
async function accessToken(companyId: string): Promise<string | null> {
  const empresa = await prisma.company.findUnique({
    where: { id: companyId },
    select: { drive_refresh_token: true, google_client_id: true, google_client_secret: true },
  })
  if (!empresa?.drive_refresh_token) return null
  const cred = credenciais(empresa)
  if (!cred) return null

  let refresh: string
  try { refresh = decrypt(empresa.drive_refresh_token) } catch { return null }

  const r = await fetch(OAUTH, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: cred.id,
      client_secret: cred.secret,
      refresh_token: refresh,
      grant_type: "refresh_token",
    }),
  })
  if (!r.ok) {
    /* Refresh recusado é conexão morta: acesso revogado no Google, ou app
       trocado. Limpar aqui faz a tela dizer "não conectado" em vez de tentar
       de novo toda noite em silêncio. */
    if (r.status === 400 || r.status === 401) {
      await prisma.company.update({
        where: { id: companyId },
        data: { drive_refresh_token: null, drive_pasta_id: null, drive_conectado_em: null },
      }).catch(() => {})
    }
    return null
  }
  const j = await r.json() as { access_token?: string }
  return j.access_token ?? null
}

/** Guarda o refresh token da conexão e cria a pasta dos backups. */
export async function conectarDrive(
  companyId: string,
  refreshToken: string,
  accessTokenInicial: string,
  nomeEmpresa: string,
): Promise<{ pastaId: string; pastaNome: string } | null> {
  const pastaNome = `Backups ${nomeEmpresa}`.trim()

  const r = await fetch(`${API}/files`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessTokenInicial}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      name: pastaNome,
      mimeType: "application/vnd.google-apps.folder",
    }),
  })
  if (!r.ok) return null
  const pasta = await r.json() as { id: string }

  await prisma.company.update({
    where: { id: companyId },
    data: {
      drive_refresh_token: encrypt(refreshToken),
      drive_pasta_id: pasta.id,
      drive_pasta_nome: pastaNome,
      drive_conectado_em: new Date(),
    },
  })
  return { pastaId: pasta.id, pastaNome }
}

export async function desconectarDrive(companyId: string) {
  /* Só esquece o acesso. Os arquivos já enviados ficam no Drive de quem é dono
     deles — apagar backup de terceiro por causa de um clique em "desconectar"
     seria destruir o que a integração existe para proteger. */
  await prisma.company.update({
    where: { id: companyId },
    data: {
      drive_refresh_token: null, drive_pasta_id: null,
      drive_pasta_nome: null, drive_conectado_em: null,
    },
  })
}

/**
 * Envia um arquivo para a pasta de backups.
 *
 * Devolve a URL do arquivo no Drive, ou null com o motivo em `erro` — o backup
 * local já está gravado quando isto roda, e falha no envio não pode derrubar a
 * rotina inteira.
 */
export async function enviarParaDrive(
  companyId: string,
  nome: string,
  conteudo: string,
  tipo = "application/json",
): Promise<{ url: string } | { erro: string }> {
  const empresa = await prisma.company.findUnique({
    where: { id: companyId },
    select: { drive_pasta_id: true },
  })
  if (!empresa?.drive_pasta_id) return { erro: "Drive não conectado." }

  const token = await accessToken(companyId)
  if (!token) return { erro: "Acesso ao Drive expirou — reconecte em Integrações." }

  /* Upload multipart: metadados e conteúdo numa requisição só. Em duas partes o
     arquivo pode chegar sem nome nem pasta se a segunda falhar. */
  const limite = "-------controllares-backup"
  const corpo =
    `--${limite}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n`
    + JSON.stringify({ name: nome, parents: [empresa.drive_pasta_id] })
    + `\r\n--${limite}\r\nContent-Type: ${tipo}\r\n\r\n`
    + conteudo
    + `\r\n--${limite}--`

  const r = await fetch(`${UPLOAD}?uploadType=multipart&fields=id,webViewLink`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": `multipart/related; boundary=${limite}`,
    },
    body: corpo,
  })
  if (!r.ok) {
    const txt = await r.text().catch(() => "")
    return { erro: `Drive recusou o envio (erro ${r.status}). ${txt.slice(0, 120)}` }
  }

  const j = await r.json() as { id: string; webViewLink?: string }
  await prisma.company.update({
    where: { id: companyId },
    data: { drive_ultimo_envio: new Date() },
  }).catch(() => {})

  return { url: j.webViewLink ?? `https://drive.google.com/file/d/${j.id}/view` }
}

/** Apaga backups antigos do Drive, guardando os `manter` mais recentes. */
export async function limparNoDrive(companyId: string, manter = 30): Promise<number> {
  const empresa = await prisma.company.findUnique({
    where: { id: companyId },
    select: { drive_pasta_id: true },
  })
  if (!empresa?.drive_pasta_id) return 0
  const token = await accessToken(companyId)
  if (!token) return 0

  const q = encodeURIComponent(`'${empresa.drive_pasta_id}' in parents and trashed = false`)
  const r = await fetch(
    `${API}/files?q=${q}&orderBy=createdTime desc&fields=files(id,createdTime)&pageSize=200`,
    { headers: { Authorization: `Bearer ${token}` } })
  if (!r.ok) return 0

  const { files } = await r.json() as { files: { id: string }[] }
  const sobrando = files.slice(manter)
  let apagados = 0
  for (const f of sobrando) {
    const d = await fetch(`${API}/files/${f.id}`, {
      method: "DELETE", headers: { Authorization: `Bearer ${token}` },
    })
    if (d.ok) apagados++
  }
  return apagados
}


/* ─────────────── leitura: a pasta que alimenta o CORE ─────────────── */

export interface ArquivoDrive {
  id: string
  nome: string
  mimeType: string
  modificadoEm: string
  tamanho: number | null
}

/** Google Docs, Sheets e Slides não baixam como arquivo: exportam. */
const EXPORTA: Record<string, { mime: string; ext: string }> = {
  "application/vnd.google-apps.document": { mime: "text/plain", ext: "txt" },
  "application/vnd.google-apps.spreadsheet": { mime: "text/csv", ext: "csv" },
  "application/vnd.google-apps.presentation": { mime: "text/plain", ext: "txt" },
}

/** Pastas do Drive que a conta enxerga, para escolher qual alimenta o CORE. */
export async function listarPastas(companyId: string): Promise<{ id: string; nome: string }[]> {
  const token = await accessToken(companyId)
  if (!token) return []
  const q = encodeURIComponent(
    "mimeType = 'application/vnd.google-apps.folder' and trashed = false")
  const r = await fetch(`${API}/files?q=${q}&fields=files(id,name)&pageSize=100&orderBy=name`,
    { headers: { Authorization: `Bearer ${token}` } })
  if (!r.ok) return []
  const { files } = await r.json() as { files: { id: string; name: string }[] }
  return files.map(f => ({ id: f.id, nome: f.name }))
}

/** Arquivos de uma pasta, incluindo os de subpastas. */
export async function listarArquivos(companyId: string, pastaId: string): Promise<ArquivoDrive[]> {
  const token = await accessToken(companyId)
  if (!token) return []

  const achados: ArquivoDrive[] = []
  /* Percorre subpastas: quem organiza manuais por marca não deveria ter que
     achatar tudo numa pasta só para o sistema enxergar. */
  const fila = [pastaId]
  const visitadas = new Set<string>()

  while (fila.length) {
    const atual = fila.shift()!
    if (visitadas.has(atual)) continue
    visitadas.add(atual)

    const q = encodeURIComponent(`'${atual}' in parents and trashed = false`)
    const r = await fetch(
      `${API}/files?q=${q}&fields=files(id,name,mimeType,modifiedTime,size)&pageSize=200`,
      { headers: { Authorization: `Bearer ${token}` } })
    if (!r.ok) break

    const { files } = await r.json() as {
      files: { id: string; name: string; mimeType: string; modifiedTime: string; size?: string }[]
    }
    for (const f of files) {
      if (f.mimeType === "application/vnd.google-apps.folder") { fila.push(f.id); continue }
      achados.push({
        id: f.id, nome: f.name, mimeType: f.mimeType,
        modificadoEm: f.modifiedTime,
        tamanho: f.size ? Number(f.size) : null,
      })
    }
  }
  return achados
}

/**
 * Conteúdo de um arquivo do Drive, já em texto.
 *
 * Devolve também a extensão, porque quem extrai o texto decide pelo formato — e
 * um Google Doc não tem extensão nenhuma no nome.
 */
export async function baixarArquivo(
  companyId: string, arquivo: ArquivoDrive,
): Promise<{ conteudo: ArrayBuffer; ext: string } | { erro: string }> {
  const token = await accessToken(companyId)
  if (!token) return { erro: "Acesso ao Drive expirou." }

  const exporta = EXPORTA[arquivo.mimeType]
  const url = exporta
    ? `${API}/files/${arquivo.id}/export?mimeType=${encodeURIComponent(exporta.mime)}`
    : `${API}/files/${arquivo.id}?alt=media`

  const r = await fetch(url, { headers: { Authorization: `Bearer ${token}` } })
  if (!r.ok) return { erro: `Drive recusou o download (erro ${r.status}).` }

  return {
    conteudo: await r.arrayBuffer(),
    ext: exporta ? exporta.ext : (arquivo.nome.split(".").pop() ?? "").toLowerCase(),
  }
}
