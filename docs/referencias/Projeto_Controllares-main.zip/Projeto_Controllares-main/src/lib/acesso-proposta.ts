import crypto from "crypto"
import { cookies } from "next/headers"
import { prisma } from "@/lib/prisma"

/**
 * Acesso ao link público da proposta e do contrato.
 *
 * O link era a credencial inteira: quem o recebesse — encaminhado num grupo,
 * colado num chat, achado no histórico de um navegador emprestado — via
 * valores, escopo, condições e o contrato. Aceitar já exigia confirmar o
 * e-mail, mas LER não exigia nada.
 *
 * Agora o link não basta. Para abrir é preciso também receber um código de seis
 * dígitos na caixa do contratante. São duas coisas em mãos diferentes: o link,
 * que circula, e o e-mail, que não. Repassar o link deixa de dar acesso.
 *
 * Isso não é sigilo absoluto e não pretende ser: quem abrir o documento pode
 * fotografar a tela ou imprimir. O que fecha é o acesso remoto por link solto,
 * que é como um documento de fato vaza.
 */

/** Vale por um dia: o cliente costuma reler a proposta antes de decidir. */
const VALIDADE_SESSAO_H = 24
/** O código expira rápido — é para usar na hora em que chega. */
const VALIDADE_CODIGO_MIN = 20
/** Depois disso o código morre, mesmo dentro do prazo. */
const MAX_TENTATIVAS = 5

const PREFIXO_COOKIE = "prop_acesso_"

function segredo(): string {
  /* Reaproveita a chave que já existe. Sem ela, a assinatura seria previsível e
     qualquer um forjaria o cookie de acesso. */
  const raw = process.env.ENCRYPTION_KEY || process.env.NEXTAUTH_SECRET
  if (!raw) throw new Error("ENCRYPTION_KEY não definida — acesso ao link não pode ser assinado")
  return raw
}

const hmac = (valor: string) =>
  crypto.createHmac("sha256", segredo()).update(valor).digest("hex")

/** Compara em tempo constante: `===` vaza o tamanho do prefixo correto. */
function iguais(a: string, b: string): boolean {
  const ba = Buffer.from(a)
  const bb = Buffer.from(b)
  if (ba.length !== bb.length) return false
  return crypto.timingSafeEqual(ba, bb)
}

/** Código de 6 dígitos, sorteado sem viés de módulo. */
export function gerarCodigo(): string {
  return String(crypto.randomInt(0, 1_000_000)).padStart(6, "0")
}

/** Os endereços autorizados a receber o código desta proposta. */
export function emailsAutorizados(p: { fat_email: string | null; client_email: string | null }) {
  return [p.fat_email, p.client_email]
    .map(e => (e ?? "").trim().toLowerCase())
    .filter(Boolean)
}

/**
 * Cria e guarda o código. Devolve o valor em claro só para o envio do e-mail —
 * no banco fica o hash, para que ler o banco não dê acesso às propostas.
 */
export async function emitirCodigo(proposalId: string, email: string, ip: string | null) {
  const codigo = gerarCodigo()
  /* Códigos anteriores morrem: dois válidos ao mesmo tempo dobram a chance de
     acerto de quem estiver tentando adivinhar. */
  await prisma.proposalAccessCode.updateMany({
    where: { proposalId, usado_em: null },
    data: { usado_em: new Date(), tentativas: MAX_TENTATIVAS },
  })
  await prisma.proposalAccessCode.create({
    data: {
      proposalId,
      email: email.trim().toLowerCase(),
      codigo_hash: hmac(codigo),
      expira_em: new Date(Date.now() + VALIDADE_CODIGO_MIN * 60_000),
      ip,
    },
  })
  return { codigo, validadeMin: VALIDADE_CODIGO_MIN }
}

type Resultado = { ok: true } | { ok: false; erro: string }

/** Confere o código digitado e consome-o no acerto. */
export async function conferirCodigo(proposalId: string, codigo: string): Promise<Resultado> {
  const digitado = String(codigo ?? "").replace(/\D/g, "")
  if (digitado.length !== 6) return { ok: false, erro: "O código tem 6 dígitos." }

  const registro = await prisma.proposalAccessCode.findFirst({
    where: { proposalId, usado_em: null },
    orderBy: { createdAt: "desc" },
  })
  if (!registro) return { ok: false, erro: "Peça um código novo." }
  if (registro.expira_em < new Date()) {
    return { ok: false, erro: "O código expirou. Peça um novo." }
  }
  if (registro.tentativas >= MAX_TENTATIVAS) {
    return { ok: false, erro: "Tentativas demais. Peça um código novo." }
  }

  if (!iguais(registro.codigo_hash, hmac(digitado))) {
    /* Conta a tentativa ANTES de responder: sem isso, um script tenta o milhão
       de combinações à vontade. */
    await prisma.proposalAccessCode.update({
      where: { id: registro.id },
      data: { tentativas: { increment: 1 } },
    })
    const restam = MAX_TENTATIVAS - registro.tentativas - 1
    return {
      ok: false,
      erro: restam > 0
        ? `Código incorreto. Restam ${restam} tentativa(s).`
        : "Código incorreto. Peça um novo.",
    }
  }

  await prisma.proposalAccessCode.update({
    where: { id: registro.id },
    data: { usado_em: new Date() },
  })
  return { ok: true }
}

/* ───────────────── sessão de leitura (cookie assinado) ───────────────── */

/**
 * O cookie carrega o próprio prazo e uma assinatura sobre ele. Guardar só um
 * "true" deixaria qualquer um criar o cookie na mão; assinar com a chave do
 * servidor torna o valor infalsificável sem ela.
 */
function montarValor(token: string): string {
  const expira = Date.now() + VALIDADE_SESSAO_H * 3_600_000
  return `${expira}.${hmac(`${token}.${expira}`)}`
}

function valorValido(token: string, valor: string | undefined): boolean {
  if (!valor) return false
  const [expiraStr, assinatura] = valor.split(".")
  const expira = Number(expiraStr)
  if (!expira || !assinatura) return false
  if (expira < Date.now()) return false
  return iguais(assinatura, hmac(`${token}.${expira}`))
}

export async function abrirSessao(token: string) {
  const jar = await cookies()
  jar.set(PREFIXO_COOKIE + token, montarValor(token), {
    httpOnly: true,           // fora do alcance de script na página
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: VALIDADE_SESSAO_H * 3_600,
  })
}

/** O visitante já provou que recebeu o código desta proposta? */
export async function temSessao(token: string): Promise<boolean> {
  const jar = await cookies()
  return valorValido(token, jar.get(PREFIXO_COOKIE + token)?.value)
}
