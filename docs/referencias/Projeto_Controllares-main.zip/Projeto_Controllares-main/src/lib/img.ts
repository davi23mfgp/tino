/**
 * Retorna uma URL de imagem segura para usar em <img src>.
 * URLs externas (http/https de outro domínio) passam pelo proxy do servidor,
 * que contorna bloqueio de hotlink/CORS/referer.
 * URLs locais (/uploads/...) ou data: são retornadas como estão.
 */
/**
 * @param propostaToken  token do link público. Só é necessário nas telas que
 *   o cliente abre sem login — o proxy exige sessão ou um link de proposta
 *   válido, para não virar proxy aberto.
 */
export function proxiedImg(url?: string | null, propostaToken?: string): string {
  if (!url) return ""
  // Locais ou data URIs não precisam de proxy
  if (url.startsWith("/") || url.startsWith("data:")) return url
  // Só proxia http/https
  if (!/^https?:\/\//i.test(url)) return url
  const p = propostaToken ? `&p=${encodeURIComponent(propostaToken)}` : ""
  return `/api/img-proxy?url=${encodeURIComponent(url)}${p}`
}
