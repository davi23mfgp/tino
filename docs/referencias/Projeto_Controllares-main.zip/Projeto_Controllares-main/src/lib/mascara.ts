/**
 * Máscara que se forma enquanto a pessoa digita.
 *
 * O problema que isto resolve: hoje cada tela trata o campo do seu jeito. O
 * telefone entra como "17988211987" numa tela e "(17) 98821-1987" em outra, o
 * preço entra com ponto num lugar e vírgula em outro. Quem digita não deveria
 * precisar saber disso.
 *
 * A ideia: quem digita vê o formato pronto, e o estado do formulário recebe
 * sempre o valor cru — dígitos no caso de documento e telefone, número no caso
 * de dinheiro e medida. Uma máscara, um lugar, o sistema inteiro.
 *
 * Cada máscara é um par de funções puras:
 *
 *   aoDigitar(textoDigitado) -> { texto, bruto }
 *       texto  = o que aparece na tela
 *       bruto  = o que vai para o estado do formulário e para o banco
 *
 *   exibir(bruto) -> texto
 *       usada quando o valor já vem pronto do banco
 *
 * Nada aqui toca em React. O componente que usa isto é
 * components/ui/campo-mascarado.tsx.
 */

export const soDigitos = (v: string | null | undefined) => (v ?? "").replace(/\D/g, "")

export interface Formatado {
  texto: string
  bruto: string
}

export interface Mascara {
  aoDigitar: (digitado: string) => Formatado
  exibir: (bruto: string | number | null | undefined) => string
  /** Teclado que o celular abre. */
  teclado: "text" | "numeric" | "decimal" | "tel"
  /** Onde o cursor quer ficar depois de formatar. */
  cursor: "preservar" | "fim" | "manter"
}

/* ------------------------------------------------------------------ *
 * Telefone
 * ------------------------------------------------------------------ */

/**
 * "(17) 98821-1987", montado dígito a dígito.
 *
 * Aceita até 11 dígitos. Celular quebra em 5+4, fixo em 4+4 — a quebra só é
 * decidida quando o nono dígito chega, porque antes disso os dois são iguais.
 */
function telefoneTexto(d: string): string {
  if (!d) return ""
  if (d.length <= 2) return `(${d}`
  const ddd = d.slice(0, 2)
  const resto = d.slice(2)
  const corte = resto.length > 8 ? 5 : 4
  if (resto.length <= corte) return `(${ddd}) ${resto}`
  return `(${ddd}) ${resto.slice(0, corte)}-${resto.slice(corte)}`
}

export const telefone: Mascara = {
  aoDigitar: (digitado) => {
    const d = soDigitos(digitado).slice(0, 11)
    return { texto: telefoneTexto(d), bruto: d }
  },
  exibir: (bruto) => telefoneTexto(soDigitos(String(bruto ?? "")).slice(0, 11)),
  teclado: "tel",
  cursor: "preservar",
}

/* ------------------------------------------------------------------ *
 * CPF / CNPJ
 * ------------------------------------------------------------------ */

/**
 * Um campo só para os dois. Até 11 dígitos formata como CPF, daí em diante
 * vira CNPJ — que é como a pessoa digita: ela não avisa antes qual vai ser.
 */
function documentoTexto(d: string): string {
  if (d.length <= 11) {
    if (d.length <= 3) return d
    if (d.length <= 6) return `${d.slice(0, 3)}.${d.slice(3)}`
    if (d.length <= 9) return `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6)}`
    return `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6, 9)}-${d.slice(9)}`
  }
  return `${d.slice(0, 2)}.${d.slice(2, 5)}.${d.slice(5, 8)}/${d.slice(8, 12)}${d.length > 12 ? "-" + d.slice(12) : ""}`
}

export const documento: Mascara = {
  aoDigitar: (digitado) => {
    const d = soDigitos(digitado).slice(0, 14)
    return { texto: documentoTexto(d), bruto: d }
  },
  exibir: (bruto) => documentoTexto(soDigitos(String(bruto ?? "")).slice(0, 14)),
  teclado: "numeric",
  cursor: "preservar",
}

/* ------------------------------------------------------------------ *
 * CEP
 * ------------------------------------------------------------------ */

const cepTexto = (d: string) => (d.length > 5 ? `${d.slice(0, 5)}-${d.slice(5)}` : d)

export const cep: Mascara = {
  aoDigitar: (digitado) => {
    const d = soDigitos(digitado).slice(0, 8)
    return { texto: cepTexto(d), bruto: d }
  },
  exibir: (bruto) => cepTexto(soDigitos(String(bruto ?? "")).slice(0, 8)),
  teclado: "numeric",
  cursor: "preservar",
}

/* ------------------------------------------------------------------ *
 * Dinheiro
 * ------------------------------------------------------------------ */

const fmtBRLInterno = new Intl.NumberFormat("pt-BR", {
  style: "currency", currency: "BRL", minimumFractionDigits: 2, maximumFractionDigits: 2,
})

/**
 * O Intl separa "R$" do número com espaço NÃO SEPARÁVEL (U+00A0), que é
 * invisível e não é igual ao espaço do teclado. Quem comparar o texto, buscar
 * por "R$ " ou colar o valor num e-mail leva um susto silencioso. Aqui sai
 * espaço comum, sempre.
 */
const fmtBRL = { format: (v: number) => fmtBRLInterno.format(v).replace(/\u00A0/g, " ") }

/**
 * Dinheiro entra pelos centavos, da direita para a esquerda.
 *
 * Digitou 1, vira R$ 0,01. Digitou 1987, vira R$ 19,87. É assim que caixa de
 * loja e aplicativo de banco funcionam aqui, e é o único jeito em que ninguém
 * precisa digitar a vírgula nem se perguntar onde ela vai cair.
 *
 * O cursor fica no fim de propósito: no modo centavos não existe "editar o
 * meio" — apagar uma tecla desloca a vírgula inteira, e é isso que se espera.
 */
export const moeda: Mascara = {
  aoDigitar: (digitado) => {
    const d = soDigitos(digitado).slice(0, 13).replace(/^0+(?=\d)/, "")
    if (!d) return { texto: "", bruto: "" }
    const valor = Number(d) / 100
    return { texto: fmtBRL.format(valor), bruto: String(valor) }
  },
  exibir: (bruto) => {
    if (bruto === null || bruto === undefined || bruto === "") return ""
    const n = Number(bruto)
    return Number.isFinite(n) ? fmtBRL.format(n) : ""
  },
  teclado: "numeric",
  cursor: "fim",
}

/* ------------------------------------------------------------------ *
 * Número com unidade (mm, cm, kg, %, ...)
 * ------------------------------------------------------------------ */

/**
 * Número decimal com vírgula e unidade colada no fim.
 *
 * Diferente do dinheiro, aqui a vírgula é digitada por quem preenche: "12,5"
 * sai "12,5 mm". Quem digita "12.5" também acerta — ponto e vírgula fazem a
 * mesma coisa, porque metade das pessoas usa o ponto do teclado numérico.
 *
 * A unidade é enfeite de tela. O que vai para o estado é o número puro, na
 * unidade que o campo já usa: esta função não converte cm em mm, e não deveria.
 * Conversão escondida é como medida errada entra no catálogo.
 */
export function medida(_unidade: string, casas = 2): Mascara {
  /* A unidade NÃO vai dentro do campo: o rótulo já diz "(cm)". Com o sufixo
     colado no texto, o cursor ia parar depois de " cm", o backspace comia a
     unidade em vez do número e a pessoa via "1 cm|" ao tentar corrigir. */
  const sufixo = ""

  const limpar = (digitado: string) => {
    // Qualquer separador vira vírgula, e só a primeira sobrevive: "1.2.3" -> "1,23"
    const so = digitado.replace(/[^\d.,]/g, "").replace(/[.,]/g, ",")
    const partes = so.split(",")
    const inteiro = (partes.shift() ?? "").replace(/^0+(?=\d)/, "")
    const decimal = partes.join("").slice(0, casas)
    return { inteiro, decimal, temVirgula: casas > 0 && so.includes(",") }
  }

  return {
    aoDigitar: (digitado) => {
      const { inteiro, decimal, temVirgula } = limpar(digitado)
      if (!inteiro && !decimal && !temVirgula) return { texto: "", bruto: "" }
      // Enquanto a vírgula está lá mas o decimal ainda não chegou, o texto
      // precisa manter a vírgula — senão ela some embaixo do dedo.
      const corpo = temVirgula ? `${inteiro || "0"},${decimal}` : inteiro
      const bruto = `${inteiro || "0"}${decimal ? "." + decimal : ""}`
      return { texto: corpo + sufixo, bruto }
    },
    exibir: (bruto) => {
      if (bruto === null || bruto === undefined || bruto === "") return ""
      const n = Number(bruto)
      if (!Number.isFinite(n)) return ""
      return n.toLocaleString("pt-BR", { minimumFractionDigits: 0, maximumFractionDigits: casas }) + sufixo
    },
    teclado: "decimal",
    cursor: "manter",
  }
}

/* ------------------------------------------------------------------ *
 * Catálogo
 * ------------------------------------------------------------------ */

export const MASCARAS = {
  telefone,
  documento,
  cep,
  moeda,
  mm: medida("mm", 1),
  // 3 casas em cm = 0,01 mm, a mesma precisão das medidas gravadas em mm
  cm: medida("cm", 3),
  m: medida("m", 2),
  kg: medida("kg", 3),
  porcentagem: medida("%", 2),
  quantidade: medida("", 0),
} as const

export type NomeMascara = keyof typeof MASCARAS

/**
 * Onde o cursor deve ficar depois que o texto mudou de tamanho.
 *
 * Sem isto, editar o meio de "(17) 98821-1987" joga o cursor para o fim a cada
 * tecla. A conta é simples: conta quantos dígitos existiam antes do cursor e
 * põe o cursor depois do mesmo tanto de dígitos no texto novo.
 */
export function cursorDepois(textoNovo: string, digitosAntesDoCursor: number): number {
  if (digitosAntesDoCursor <= 0) return 0
  let vistos = 0
  for (let i = 0; i < textoNovo.length; i++) {
    if (/\d/.test(textoNovo[i])) {
      vistos++
      if (vistos === digitosAntesDoCursor) return i + 1
    }
  }
  return textoNovo.length
}
