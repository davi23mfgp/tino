/**
 * "2026-07-24" vindo de <input type="date"> é lido pelo JS como meia-noite UTC.
 * No Brasil (UTC-3) isso volta um dia na exibição (aparece 23/07).
 * Ancoramos ao MEIO-DIA local para a data exibida bater com a digitada.
 */
export function dataLocal(s: string | Date): Date {
  if (s instanceof Date) return s
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s).trim())
  if (!m) return new Date(s)
  return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), 12, 0, 0)
}
