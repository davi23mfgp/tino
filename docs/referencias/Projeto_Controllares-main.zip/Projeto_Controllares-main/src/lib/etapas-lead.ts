/**
 * As etapas do lead, num lugar só.
 *
 * O funil estava escrito três vezes — na validação da API, no quadro e na tela
 * da proposta —, e foi assim que "Elaborando proposta" entrou em uma e faltou
 * nas outras: o card mudava de coluna e a API devolvia 400 sem dizer por quê.
 *
 * A ORDEM DA LISTA É O FLUXO. A seta "próxima fase" do card lê daqui, então
 * mover uma etapa de lugar aqui muda o caminho na tela inteira.
 */
export const ETAPAS_LEAD = [
  { id: "NOVO",                label: "Novo",                curto: "Novo" },
  { id: "CONTATADO",           label: "Contatado",           curto: "Contato feito" },
  { id: "QUALIFICADO",         label: "Qualificado",         curto: "Visita" },
  /* Onde o vendedor ainda decide. A proposta está sendo montada e ainda não
     saiu para o cliente — antes as duas coisas moravam em "Proposta enviada",
     e o funil dizia que o cliente tinha recebido um documento que ninguém
     tinha terminado de escrever. */
  { id: "ELABORANDO_PROPOSTA", label: "Criação de Proposta", curto: "Elaborando" },
  /* A partir daqui quem anda é o DOCUMENTO, não o vendedor: a proposta saiu e
     o próximo passo depende da resposta do cliente. */
  { id: "PROPOSTA_ENVIADA",    label: "Proposta Enviada",    curto: "Enviada" },
  { id: "GANHO",               label: "Ganho",               curto: "Ganho" },
  { id: "PERDIDO",             label: "Perdido",             curto: "Perdido" },
] as const

export type EtapaLead = (typeof ETAPAS_LEAD)[number]["id"]

export const STATUS_LEAD_VALIDOS: string[] = ETAPAS_LEAD.map(e => e.id)

/** Nome de exibição de uma etapa, tanto do lead quanto da proposta. */
export function rotuloEtapa(id: string | null | undefined): string {
  if (!id) return "—"
  const e = ETAPAS_LEAD.find(x => x.id === id)
  if (e) return e.label
  // Etapas do lado da proposta (RASCUNHO, ENVIADA, ACEITA…) chegam aqui.
  return id.charAt(0) + id.slice(1).toLowerCase().replace(/_/g, " ")
}
