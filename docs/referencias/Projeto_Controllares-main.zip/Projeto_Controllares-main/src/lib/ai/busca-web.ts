/**
 * Busca técnica na internet para o CORE.
 *
 * Serve a um caso específico: dado de catálogo que não está no sistema —
 * amperagem de um canal, tensão de operação, faixa de temperatura, protocolo
 * suportado. O time pergunta isso o tempo todo e hoje sai do sistema para
 * procurar.
 *
 * Duas travas de propósito:
 *  1. Só dispara em pergunta técnica (ver `ehPerguntaTecnica`). O CORE é
 *     ferramenta de trabalho, não buscador geral.
 *  2. O resultado entra como CONTEXTO com a fonte junto, para o modelo citar
 *     de onde veio — e o usuário poder conferir.
 *
 * Provedor, na ordem em que é procurado:
 *   BUSCA_API_KEY    Tavily ou Brave (BUSCA_PROVIDER escolhe qual)
 *   GEMINI_API_KEY   Gemini com pesquisa do Google acoplada — não exige
 *                    contratar mais um serviço além do que o Google já dá
 * Sem nenhuma, a busca não acontece e o CORE responde com o que tem.
 */

export interface ResultadoWeb {
  titulo: string
  url: string
  trecho: string
}

/** Termos que caracterizam pergunta técnica de equipamento/instalação. */
const RE_TECNICA = new RegExp(
  [
    // grandezas elétricas e físicas
    "\\b(amperagem|amper|amps?|\\d+\\s*a\\b|volt(agem|s)?|tens[ãa]o|watt|pot[êe]ncia|carga m[áa]xima",
    "|corrente|consumo|dimmer|rel[ée]|canal|canais|sa[íi]da|entrada|circuito|bitola|cabo|par tran[çc]ado",
    "|temperatura|umidade|ip\\d{2}\\b|dbm|ganho|frequ[êe]ncia|banda|latenc|throughput|poe\\b)",
    // vocabulário de especificação
    "|\\b(especifica[çc][ãa]o|datasheet|ficha t[ée]cnica|manual|suporta|compat[íi]vel|protocolo",
    "|limite|m[áa]ximo|m[íi]nimo|capacidade|requisito|instala[çc][ãa]o|liga[çc][ãa]o|esquema)\\b",
    // marcas do setor
    "|\\b(control4|savant|crestron|lutron|unifi|ubiquiti|home\\s*manager|smart\\s*center|shelly",
    "|sonos|denon|marantz|yamaha|epson|sony|intelbras|hikvision|dahua|zigbee|z-?wave|knx|dali|dmx)\\b",
  ].join(""),
  "i",
)

/**
 * Só vale buscar quando a pergunta é técnica E não é sobre os dados da
 * empresa. "quantas obras eu tenho" tem "obras", mas a resposta está no banco.
 */
const RE_DADOS_INTERNOS =
  /\b(minha|minhas|meu|meus|nossa|nossas|da empresa|no sistema|cadastrad|proposta|obra|cliente|parcela|estoque|agenda|tarefa)\b/i

export function ehPerguntaTecnica(msg: string): boolean {
  if (RE_DADOS_INTERNOS.test(msg)) return false
  return RE_TECNICA.test(msg)
}

function config() {
  /* Sem chave dedicada de busca, usa o próprio Gemini com pesquisa do Google
     acoplada. É a diferença entre precisar contratar mais um serviço e usar a
     chave que o sistema já tem — e para a pergunta técnica do dia a dia o
     resultado é o mesmo. */
  const dedicada = process.env.BUSCA_API_KEY
  if (dedicada) {
    const provider = (process.env.BUSCA_PROVIDER
      || (dedicada.startsWith("tvly-") ? "tavily" : "brave")).toLowerCase()
    return { apiKey: dedicada, provider }
  }

  /* Chave do Google, e só ela. Reaproveitar `AI_API_KEY` seria conveniente até
     o dia em que o provedor do chat for outro — Groq e OpenAI usam a mesma
     variável, e a chamada ao Google falharia com "API_KEY_INVALID" sem que
     nada na tela explicasse por quê. */
  const gemini = process.env.GEMINI_API_KEY || process.env.BUSCA_GEMINI_KEY
  if (gemini) return { apiKey: gemini, provider: "gemini" }

  return { apiKey: undefined, provider: "nenhum" }
}

/**
 * Busca pelo Gemini com a pesquisa do Google acoplada (grounding).
 *
 * O modelo responde e devolve, junto, as páginas que sustentaram a resposta.
 * São essas páginas que viram os resultados — o CORE cita a fonte, e quem
 * perguntou consegue conferir em vez de acreditar.
 */
async function viaGemini(consulta: string, apiKey: string): Promise<ResultadoWeb[]> {
  /* Alias, não versão fixa: o Google aposenta nome de modelo para chaves novas
     — "gemini-2.5-flash" já responde 404 para quem criou a chave depois do
     corte —, e o alias segue apontando para a versão vigente. */
  const modelo = process.env.BUSCA_MODEL || "gemini-flash-latest"
  const r = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${modelo}:generateContent`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
      body: JSON.stringify({
        contents: [{ parts: [{ text: consulta }] }],
        tools: [{ google_search: {} }],
      }),
    })
  if (!r.ok) return []

  const j = await r.json() as {
    candidates?: {
      content?: { parts?: { text?: string }[] }
      groundingMetadata?: {
        groundingChunks?: { web?: { uri?: string; title?: string } }[]
      }
    }[]
  }

  const c = j.candidates?.[0]
  const resposta = (c?.content?.parts ?? []).map(p => p.text ?? "").join(" ").trim()
  const fontes = c?.groundingMetadata?.groundingChunks ?? []

  if (!fontes.length) {
    // Respondeu sem consultar nada: é conhecimento do modelo, não busca.
    return resposta ? [{ titulo: "Resposta do buscador", url: "", trecho: resposta }] : []
  }

  /* A resposta vem uma vez só, e as fontes em lista. O trecho vai na primeira
     para não repetir o mesmo texto em cada linha. */
  return fontes.slice(0, 5).map((f, i) => ({
    titulo: f.web?.title || "Fonte",
    url: f.web?.uri || "",
    trecho: i === 0 ? resposta.slice(0, 1200) : "",
  })).filter(f => f.url || f.trecho)
}

export function buscaConfigurada(): boolean {
  return !!config().apiKey
}

async function viaTavily(consulta: string, apiKey: string): Promise<ResultadoWeb[]> {
  const r = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      api_key: apiKey,
      query: consulta,
      max_results: 4,
      search_depth: "basic",
      include_answer: false,
    }),
    signal: AbortSignal.timeout(12_000),
  })
  if (!r.ok) throw new Error(`Tavily HTTP ${r.status}`)
  const j = await r.json() as { results?: { title: string; url: string; content: string }[] }
  return (j.results ?? []).map(x => ({
    titulo: x.title, url: x.url, trecho: (x.content ?? "").slice(0, 700),
  }))
}

async function viaBrave(consulta: string, apiKey: string): Promise<ResultadoWeb[]> {
  const url = `https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(consulta)}&count=4`
  const r = await fetch(url, {
    headers: { Accept: "application/json", "X-Subscription-Token": apiKey },
    signal: AbortSignal.timeout(12_000),
  })
  if (!r.ok) throw new Error(`Brave HTTP ${r.status}`)
  const j = await r.json() as { web?: { results?: { title: string; url: string; description: string }[] } }
  return (j.web?.results ?? []).map(x => ({
    titulo: x.title, url: x.url, trecho: (x.description ?? "").slice(0, 700),
  }))
}

/** Busca na web. Erro nunca sobe: sem resultado, o CORE segue com o que tem. */
export async function buscarNaWeb(consulta: string): Promise<ResultadoWeb[]> {
  const { apiKey, provider } = config()
  if (!apiKey) return []
  try {
    if (provider === "gemini") return await viaGemini(consulta, apiKey)
    return provider === "tavily"
      ? await viaTavily(consulta, apiKey)
      : await viaBrave(consulta, apiKey)
  } catch {
    return []
  }
}

/** Bloco de contexto com os resultados, para o modelo citar a fonte. */
export function formatarResultados(rs: ResultadoWeb[]): string {
  if (rs.length === 0) return ""
  const itens = rs.map((r, i) => `[W${i + 1}] ${r.titulo} — ${r.url}\n${r.trecho}`)
  return [
    "## CONSULTA TÉCNICA NA INTERNET",
    "Resultados de busca para a pergunta. São fonte externa, não dados da empresa.",
    "Use só o que responder objetivamente e cite a fonte pelo marcador [W1], [W2]…",
    "Se os resultados divergirem ou não responderem, diga isso — não invente número.",
    "Para valor elétrico crítico, oriente conferir no manual do fabricante antes de aplicar.",
    "",
    itens.join("\n\n"),
  ].join("\n")
}
