/**
 * Detecção de intenção da mensagem do usuário, feita ANTES de chamar a IA.
 * Isso garante que segredos (cofre) nunca cheguem ao modelo e que anexos/ações
 * sejam tratados de forma determinística e segura no servidor.
 */

export type Intent = "CONFIDENCIAL" | "ANEXO" | "ACAO" | "DADOS"

// Dois grupos: palavras exatas (com \b) e prefixos que não precisam de \b final
// "central" é ambíguo ("central de custos" ≠ credencial), então só conta como
// confidencial quando qualificado por automação/marca. As marcas (savant/control4/
// crestron) seguem valendo sozinhas.
const RE_CONFIDENCIAL =
  /\b(senha|password|credencial|credenciais|cofre|login|wi-?fi|roteador|c[aâ]mera|dvr|nvr|savant|control4|crestron|smart\s*center)\b|\bcentral\s+(de\s+autom\w*|savant|control4|crestron|control|automa\w*)\b|\b(ip|usu[aá]rio|endere[çc]o\s+ip|mac)\s+(d[aeo]|do|da|de|[a-z])/i

// "projeto" sozinho é ambíguo — só vira ANEXO se acompanhado de ação explícita de arquivo
const RE_ANEXO =
  /\b(planta|plantas|contrato|planilha|arquivo|anexo|anexos|pdf|dwg|xlsx|documento|blueprint|baixar|download)\b|\b(mand(e|ar?)|envi(e|ar?)|me\s+d[áa]|abre|abrir|ver?)\b.{0,40}\b(planta|projeto|contrato|arquivo|anexo|planilha|pdf|dwg)\b/i

const RE_ACAO =
  /\b(emit(e|ir|a)|cancel(e|ar|a)|envi(e|ar|a)\s+(a|o)\s+nf|gera(r)?\s+nota|marcar?\s+como\s+pago|dar?\s+baixa|excluir|deletar|apagar)\b/i

/** Detecta a intenção principal. Ordem importa: confidencial > ação > anexo > dados. */
export function detectarIntent(msg: string): Intent {
  const t = msg.toLowerCase()
  // "emitir nota/nf" é ação, mesmo contendo "nota"
  if (RE_ACAO.test(t)) return "ACAO"
  if (RE_CONFIDENCIAL.test(t)) return "CONFIDENCIAL"
  if (RE_ANEXO.test(t)) return "ANEXO"
  return "DADOS"
}

/** Detecção de ação específica (para o fluxo de confirmação). */
export function detectarAcao(msg: string): { acao: "emitir_nf" | "cancelar_nf" | null } {
  const t = msg.toLowerCase()
  if (/emit/.test(t) && /(nf|nota)/.test(t)) return { acao: "emitir_nf" }
  if (/cancel/.test(t) && /(nf|nota)/.test(t)) return { acao: "cancelar_nf" }
  return { acao: null }
}

/**
 * Saudação/ajuda "pura": mensagem curta que é só cumprimento ou pedido de ajuda,
 * sem outro conteúdo. Deixa o CORE responder na hora, sem gastar LLM.
 * "bom dia" → sim | "bom dia, qual meu saldo" → não (tem pergunta junto).
 */
const RE_SAUDACAO = /^\s*(oi+|ol[áa]|e?\s*a[íi]|bom\s*dia|boa\s*tarde|boa\s*noite|opa|hey|menu|ajuda|help|in[íi]cio|come[çc]ar|o\s*que\s+voc[êe]\s+faz|o\s*que\s+vc\s+faz|pode\s+me\s+ajudar)\s*[?!.]*\s*$/i
export function ehSaudacao(msg: string): boolean {
  return RE_SAUDACAO.test(msg.trim())
}

/** Grupos oferecidos por perfil no menu inicial do CORE. */
export function gruposPorPerfil(role: string): string[] {
  const G = {
    obras: "Obras", propostas: "Propostas", financeiro: "Financeiro",
    agenda: "Agenda", credenciais: "Credenciais", documentos: "Documentos",
  }
  switch (role) {
    case "ADMIN": return [G.obras, G.propostas, G.financeiro, G.agenda, G.credenciais, G.documentos]
    case "VENDEDOR": return [G.propostas, G.agenda]
    case "FINANCEIRO": return [G.propostas, G.financeiro, G.agenda]
    case "RESPONSAVEL_TECNICO": return [G.obras, G.agenda, G.credenciais, G.documentos]
    case "INSTALADOR": return [G.obras, G.agenda, G.credenciais, G.documentos]
    case "ENGENHEIRO_PROJETOS": return [G.obras, G.agenda, G.credenciais, G.documentos]
    default: return [G.obras, G.agenda]
  }
}

/** Extrai um número de proposta da mensagem (ex.: "#42", "proposta 42"). */
export function extrairNumeroProposta(msg: string): string | null {
  const m = msg.match(/(?:proposta|#|n[ºo]\.?)\s*#?\s*(\d{1,8})/i) ?? msg.match(/#(\d{1,8})/)
  return m ? m[1] : null
}

/**
 * Quais blocos de dados a pergunta realmente precisa.
 *
 * O contexto era montado inteiro em toda mensagem: obras, propostas, parcelas,
 * agenda, leads e fichas de produto, sempre. Perguntar "quais leads eu tenho"
 * mandava junto o financeiro e a agenda da semana — e o plano gratuito do Groq
 * dá 8 mil tokens por minuto. O assistente batia no teto respondendo a segunda
 * pergunta do dia, e o erro que aparecia na tela era um 429 cru.
 *
 * Aqui a pergunta escolhe o que vai. Não é economia por economia: contexto
 * menor também é resposta melhor, porque o modelo para de escolher entre seis
 * assuntos para achar o que foi perguntado.
 *
 * A regra de segurança não muda — o que cada bloco mostra continua sendo
 * decidido pelo perfil, em `scope.ts`. Isto aqui só decide o ASSUNTO.
 *
 * Cada assunto desta lista TEM de ter um bloco que o atenda em `scope.ts`.
 * Chegou-se a declarar aqui "clientes", "estoque" e "manutencao" sem escrever
 * os blocos: a pergunta sobre estoque passava a selecionar um assunto que
 * ninguem preenchia, e o CORE recebia contexto VAZIO -- pior que antes, quando
 * pelo menos caía no conjunto padrão. Assunto sem bloco nao e uma promessa,
 * e um buraco.
 */
export type Bloco = "obras" | "propostas" | "financeiro" | "agenda" | "leads" | "produtos"
  | "clientes"

const PISTAS: Record<Bloco, RegExp> = {
  obras: /\bobra|obras|instala[çc][ãa]o|instalar|cronograma|etapa|andamento|vistoria|campo|t[ée]cnico|equipe\b/i,
  propostas: /\bproposta|propostas|or[çc]amento|or[çc]amentos|contrato|assinatur|fechad|aceit|pipeline|funil\s+de\s+venda|venda|vendi\b/i,
  financeiro: /\bparcela|parcelas|receb|pag(ar|amento|o)|fatur|nota|nf|boleto|fluxo\s+de\s+caixa|inadimpl|atrasad|vencer|vencimento|cobran|financeiro|dinheiro|R\$\b/i,
  agenda: /\bagenda|hoje|amanh[ãa]|semana|compromisso|tarefa|tarefas|reuni[ãa]o|hor[áa]rio|marcad|agendad|calend[áa]rio\b/i,
  leads: /\blead|leads|cliente\s+novo|prospec|contato|funil|indica[çc][ãa]o|qualificad|perdid|ganho\b/i,
  clientes: /\bcliente|clientes|comprador|cnpj|cpf|raz[ãa]o\s+social|carteira|quem\s+comprou|faturamento\s+d[eo]\b/i,
  produtos: /\bproduto|cat[áa]logo|ficha|especifica|dimens[ãa]o|dimens[õo]es|medida|peso|pesa|pesam|embutir|sobrepor|modelo|equipamento|caixa\s+ac[úu]stica|c[âa]mera|switch|cabo\b/i,
}

/* Quando a pergunta não diz do que se trata — "e aí?", "resumo", "o que temos" —
   estes são os que valem: o que está em aberto agora. Mandar tudo seria voltar
   ao problema; mandar nada seria um assistente que não sabe nada. */
const PADRAO: Bloco[] = ["agenda", "propostas"]

export function blocosNecessarios(msg: string): Set<Bloco> {
  const achados = (Object.keys(PISTAS) as Bloco[]).filter(b => PISTAS[b].test(msg))

  /* Pergunta que menciona quase tudo ("me dá um resumo geral de tudo") cai no
     mesmo problema de mandar tudo. Acima de quatro assuntos, é resumo — e
     resumo se responde com o que está em aberto. */
  if (!achados.length || achados.length > 4) return new Set(PADRAO)
  return new Set(achados)
}
