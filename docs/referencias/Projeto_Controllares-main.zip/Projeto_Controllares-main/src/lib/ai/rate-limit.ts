import { prisma } from "@/lib/prisma"

const LIMITE_HORA = 30

/**
 * Verifica e incrementa o limite de mensagens do usuário (30/hora).
 * Retorna { permitido, restamMin } — se bloqueado, restamMin diz quanto falta.
 */
export async function checarRateLimit(userId: string, companyId: string) {
  const agora = new Date()
  let rl = await prisma.aiRateLimit.findUnique({ where: { userId } })

  if (!rl) {
    rl = await prisma.aiRateLimit.create({
      data: { userId, companyId, mensagens_hora: 0, janela_inicio: agora },
    })
  }

  // Janela de 1h expirou? zera o contador.
  const janelaExpirou = agora.getTime() - rl.janela_inicio.getTime() > 3600_000
  if (janelaExpirou) {
    rl = await prisma.aiRateLimit.update({
      where: { userId },
      data: { mensagens_hora: 0, janela_inicio: agora },
    })
  }

  if (rl.mensagens_hora >= LIMITE_HORA) {
    const restamMin = Math.ceil(
      (rl.janela_inicio.getTime() + 3600_000 - agora.getTime()) / 60_000
    )
    return { permitido: false, restamMin: Math.max(1, restamMin) }
  }

  await prisma.aiRateLimit.update({
    where: { userId },
    data: { mensagens_hora: { increment: 1 } },
  })
  return { permitido: true, restamMin: 0 }
}

/** Estado de bloqueio do cofre (3 senhas erradas = 10 min). */
export async function cofreBloqueado(userId: string) {
  const rl = await prisma.aiRateLimit.findUnique({ where: { userId } })
  if (!rl?.bloqueado_ate) return false
  return rl.bloqueado_ate > new Date()
}
