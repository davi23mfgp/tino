/**
 * Extração de texto dos arquivos que alimentam a base de conhecimento.
 *
 * PDF digital sai direto. PDF escaneado (imagem pura) não tem texto para
 * extrair — nesse caso o erro é explícito, em vez de indexar um documento
 * vazio que depois nunca aparece nas buscas.
 */

export interface TextoExtraido {
  texto: string
  paginas: number | null
}

const EXT_TEXTO = ["txt", "md", "markdown", "csv", "json", "log", "yml", "yaml", "html", "htm", "xml"]
const EXT_PLANILHA = ["xlsx", "xlsm", "xls"]
const EXT_TEXTO_RICO = ["docx"]

export function extensaoSuportada(ext: string): boolean {
  const e = ext.toLowerCase()
  return e === "pdf" || EXT_TEXTO.includes(e)
    || EXT_PLANILHA.includes(e) || EXT_TEXTO_RICO.includes(e)
}

export async function extrairTexto(arquivo: File): Promise<TextoExtraido> {
  const ext = (arquivo.name.split(".").pop() ?? "").toLowerCase()

  if (EXT_TEXTO.includes(ext)) {
    const texto = await arquivo.text()
    return { texto, paginas: null }
  }

  if (ext === "pdf") {
    // Import dinâmico: a lib é pesada e só precisa existir quando há PDF.
    const { extractText, getDocumentProxy } = await import("unpdf")
    const buffer = new Uint8Array(await arquivo.arrayBuffer())
    const pdf = await getDocumentProxy(buffer)
    const { text, totalPages } = await extractText(pdf, { mergePages: false })

    // Marca a página em cada bloco: é o que permite citar "página 12" depois.
    const paginas = Array.isArray(text) ? text : [String(text)]
    const juntado = paginas
      .map((p, i) => {
        const conteudo = String(p ?? "").trim()
        return conteudo ? `[página ${i + 1}]\n${conteudo}` : ""
      })
      .filter(Boolean)
      .join("\n\n")

    if (!juntado.trim()) {
      throw new Error(
        "Este PDF não tem texto selecionável (provavelmente é digitalizado). " +
        "Converta com OCR antes de subir, ou cole o conteúdo como texto."
      )
    }
    return { texto: juntado, paginas: totalPages ?? paginas.length }
  }

  if (EXT_PLANILHA.includes(ext)) {
    /* Planilha vira texto linha a linha, com o nome da aba e o cabeçalho
       repetido em cada linha: "Ambiente: Sala | Produto: Amplificador".

       Despejar a grade crua produziria pedaços cheios de números soltos, sem
       dizer de que coluna são — e é justamente a coluna que dá sentido ao
       número na hora da busca. */
    const ExcelJS = (await import("exceljs")).default
    const wb = new ExcelJS.Workbook()
    await wb.xlsx.load(await arquivo.arrayBuffer() as never)

    const partes: string[] = []
    wb.eachSheet(aba => {
      const linhas: string[] = [`[aba ${aba.name}]`]
      let cabecalho: string[] = []

      aba.eachRow((row, n) => {
        const celulas: string[] = []
        row.eachCell({ includeEmpty: true }, cel => {
          const v = cel.value
          const texto =
            v == null ? ""
            : typeof v === "object" && "result" in v ? String((v as { result: unknown }).result ?? "")
            : typeof v === "object" && "text" in v ? String((v as { text: unknown }).text ?? "")
            : v instanceof Date ? v.toLocaleDateString("pt-BR")
            : String(v)
          celulas.push(texto.trim())
        })

        /* Cabeçalho é a primeira linha com vários rótulos DIFERENTES.
           Planilha de obra quase sempre abre com um título mesclado
           ("PAVIMENTO TÉRREO") que o Excel repete em cada célula da faixa —
           tomar aquilo como cabeçalho produziria "PAVIMENTO TÉRREO: 3" em toda
           coluna, e o nome real da coluna se perderia. */
        const preenchidas = celulas.filter(Boolean)
        if (!cabecalho.length) {
          const distintos = new Set(preenchidas).size
          if (preenchidas.length > 1 && distintos > 1) {
            cabecalho = celulas
            linhas.push(preenchidas.join(" | "))
          } else if (preenchidas.length) {
            // Título da faixa: entra como contexto, sem virar rótulo.
            linhas.push(preenchidas[0])
          }
          return
        }
        if (!celulas.some(Boolean)) return

        const rotulada = celulas
          .map((c, i) => (c ? `${cabecalho[i] ? `${cabecalho[i]}: ` : ""}${c}` : ""))
          .filter(Boolean)
          .join(" | ")
        if (rotulada) linhas.push(`linha ${n}: ${rotulada}`)
      })

      if (linhas.length > 1) partes.push(linhas.join("\n"))
    })

    const texto = partes.join("\n\n")
    if (!texto.trim()) throw new Error("A planilha está vazia.")
    return { texto, paginas: null }
  }

  if (EXT_TEXTO_RICO.includes(ext)) {
    const mammoth = await import("mammoth")
    const { value } = await mammoth.extractRawText({
      buffer: Buffer.from(await arquivo.arrayBuffer()),
    })
    if (!value.trim()) throw new Error("O documento está vazio.")
    return { texto: value, paginas: null }
  }

  throw new Error(
    `Formato .${ext} não suportado. Use PDF, Word, Excel, TXT, MD, CSV ou HTML.`)
}
