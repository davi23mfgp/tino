import { prisma } from "@/lib/prisma"
import { decrypt } from "@/lib/crypto"
import bcrypt from "bcryptjs"
import { minutosBloqueado, registrarFalha, limparFalhas } from "@/lib/trava-tentativas"
import { rotuloEtapa } from "@/lib/etapas-lead"
import { blocosNecessarios, type Bloco } from "@/lib/ai/intent"
import type { Prisma } from "@prisma/client"

export interface AiUser {
  userId: string
  role: string
  roles?: string[]
  companyId: string
  nome: string
}

/**
 * Valida a senha do cofre para o usuário.
 *
 * SEM senha configurada o cofre fica FECHADO — antes havia um padrão fixo
 * ("4454") no código, então qualquer pessoa com acesso ao sistema (ou que
 * lesse o repositório) abria as credenciais de qualquer empresa que ainda não
 * tivesse configurado o seu. Segredo em código não é segredo.
 *
 * A comparação usa bcrypt mesmo quando não há hash, para o tempo de resposta
 * não denunciar se aquele perfil já tem cofre configurado.
 */
const HASH_INEXISTENTE = "$2a$12$0000000000000000000000000000000000000000000000000000"

export async function validarSenhaCofre(companyId: string, role: string, password: string): Promise<boolean> {
  const company = await prisma.company.findUnique({
    where: { id: companyId },
    select: { vault_passwords: true },
  })
  const vp = (company?.vault_passwords ?? {}) as Record<string, string>
  const hash = vp[role]

  if (!hash) {
    await bcrypt.compare(password, HASH_INEXISTENTE).catch(() => false)
    return false
  }
  return bcrypt.compare(password, hash)
}

/** O perfil já tem cofre configurado? Serve para a tela orientar em vez de só negar. */
/**
 * Igual a validarSenhaCofre, mas com trava anti-força-bruta por usuário.
 *
 * A senha do cofre é curta por natureza (o usuário digita a toda hora), então
 * sem trava ela cai em minutos por tentativa e erro. Use SEMPRE esta versão em
 * rotas HTTP; a versão sem trava fica só para uso interno.
 *
 * A chave é o userId: bloquear por empresa deixaria um usuário trancar os
 * colegas de propósito.
 */
export async function validarSenhaCofreComTrava(
  userId: string, companyId: string, role: string, password: string,
): Promise<{ ok: boolean; bloqueadoMin: number }> {
  const k = `cofre:${userId}`
  const bloqueadoMin = await minutosBloqueado(k)
  if (bloqueadoMin > 0) return { ok: false, bloqueadoMin }

  const ok = await validarSenhaCofre(companyId, role, password)
  if (ok) await limparFalhas(k)
  else await registrarFalha(k)
  return { ok, bloqueadoMin: 0 }
}

export async function cofreConfigurado(companyId: string, role: string): Promise<boolean> {
  const company = await prisma.company.findUnique({
    where: { id: companyId },
    select: { vault_passwords: true },
  })
  const vp = (company?.vault_passwords ?? {}) as Record<string, string>
  return !!vp[role]
}

// ===== Permissões por papel (multi-perfil) =====
// Aceita um papel único (string) OU o usuário inteiro (com roles[]).
type PapelOuUser = string | { role: string; roles?: string[] | null }
const papeis = (p: PapelOuUser): string[] =>
  typeof p === "string" ? [p] : [...new Set([p.role, ...(p.roles ?? [])])]
const algum = (p: PapelOuUser, alvo: string[]) => {
  const ps = papeis(p)
  return ps.includes("ADMIN") || alvo.some(r => ps.includes(r))
}
/**
 * O CORE lê o sistema inteiro; entrega só o que o perfil já podia ver.
 *
 * O assistente é um atalho para o que a pessoa alcançaria clicando, e não uma
 * porta lateral. Sem isso ele viraria o vazamento mais fácil do produto: o
 * instalador não abre a tela de propostas, mas perguntaria "quanto fechou a obra
 * do Ricardo" e teria resposta — sem passar por tela nenhuma, sem deixar
 * rastro numa auditoria de acesso, e por escrito.
 *
 * Cada bloco de contexto é fechado por um destes testes, e o filtro vai na
 * consulta ao banco, não numa instrução ao modelo: "não conte X" é exatamente o
 * tipo de regra que uma pergunta insistente contorna.
 *
 * A exceção é a ficha técnica — especificação, dimensão, peso. Ela vale para
 * todos os perfis, inclusive quem não abre o catálogo: é a medida do recorte e
 * o peso da peça, o que quem está em obra precisa e o que não revela nem preço
 * nem modelo. Ver `fichaTecnica`.
 */
export const podeFinanceiro = (p: PapelOuUser) => algum(p, ["ADMIN", "FINANCEIRO"])
export const podeCredenciais = (p: PapelOuUser) => algum(p, ["ADMIN", "RESPONSAVEL_TECNICO", "INSTALADOR", "ENGENHEIRO_PROJETOS"])
export const podeObras = (p: PapelOuUser) => algum(p, ["ADMIN", "FINANCEIRO", "RESPONSAVEL_TECNICO", "INSTALADOR", "ENGENHEIRO_PROJETOS"])
export const podePropostas = (p: PapelOuUser) => algum(p, ["ADMIN", "VENDEDOR", "FINANCEIRO"])
export const podeLeads = (p: PapelOuUser) => algum(p, ["ADMIN", "VENDEDOR"])
export const podeClientes = (p: PapelOuUser) => algum(p, ["ADMIN", "VENDEDOR", "FINANCEIRO"])

/** Filtro Prisma das obras que o usuário pode acessar. null = nenhuma. */
export function filtroObras(u: AiUser): Prisma.ObraWhereInput | null {
  if (!podeObras(u)) return null
  if (u.role === "ADMIN" || u.role === "FINANCEIRO" || u.role === "ENGENHEIRO_PROJETOS") {
    return { companyId: u.companyId }
  }
  if (u.role === "RESPONSAVEL_TECNICO") {
    return { companyId: u.companyId, resp_tecnico_id: u.userId }
  }
  if (u.role === "INSTALADOR") {
    return { companyId: u.companyId, colaboradores_ids: { has: u.userId } }
  }
  return null
}

/** Filtro Prisma das propostas que o usuário pode acessar. null = nenhuma. */
export function filtroPropostas(u: AiUser): Prisma.ProposalWhereInput | null {
  if (!podePropostas(u)) return null
  if (u.role === "VENDEDOR") return { companyId: u.companyId, vendedorId: u.userId }
  return { companyId: u.companyId } // ADMIN, FINANCEIRO
}

interface ObraMatch { id: string; client_name: string; etapa?: string | null }
interface AcharObraResult {
  single: ObraMatch | null
  multiple: ObraMatch[] // length > 1 = ambíguo
}

/** Acha a(s) obra(s) mencionada(s) na mensagem (entre as acessíveis). */
async function acharObra(u: AiUser, msg: string): Promise<AcharObraResult> {
  const where = filtroObras(u)
  if (!where) return { single: null, multiple: [] }
  const obras = await prisma.obra.findMany({
    where,
    select: { id: true, client_name: true, etapa: true },
  })
  const t = msg.toLowerCase()
  const matches = obras.filter(o =>
    o.client_name
      .toLowerCase()
      .split(/\s+/)
      .filter(w => w.length >= 3)
      .some(w => t.includes(w))
  )
  if (matches.length === 0) return { single: null, multiple: [] }
  if (matches.length === 1) return { single: matches[0], multiple: [] }
  // Tenta afinar: se a mensagem contém o nome completo de uma só, usa ela
  const exato = matches.find(o => t.includes(o.client_name.toLowerCase()))
  if (exato) return { single: exato, multiple: [] }
  // Ambíguo
  return { single: null, multiple: matches }
}

/**
 * Monta um bloco de contexto compacto e JÁ FILTRADO por papel, para injetar no
 * prompt da IA. Só inclui o mínimo necessário para responder.
 */
/** Os assuntos que este arquivo realmente sabe preencher. */
const BLOCOS_IMPLEMENTADOS = new Set<Bloco>([
  "obras", "propostas", "financeiro", "agenda", "leads", "produtos", "clientes",
])

export async function montarContexto(u: AiUser, msg: string): Promise<string> {
  const partes: string[] = []

  /* A pergunta escolhe os assuntos; o perfil escolhe o que cada assunto mostra.
     São dois filtros diferentes e nenhum substitui o outro: sem o primeiro, o
     contexto estoura o limite do provedor em duas mensagens; sem o segundo,
     vaza. */
  const blocos = blocosNecessarios(msg)

  /* Assunto escolhido que nenhum bloco atende devolveria contexto vazio, e o
     CORE responderia "não encontrei" sobre algo que existe. Já aconteceu: o
     seletor ganhou "estoque" e "manutencao" antes dos blocos serem escritos.
     Aqui o descompasso vira aviso no log e o padrão assume, em vez de virar
     uma resposta errada com cara de certa. */
  const semBloco = [...blocos].filter(b => !BLOCOS_IMPLEMENTADOS.has(b))
  if (semBloco.length) {
    console.warn(`[ai/scope] assunto sem bloco: ${semBloco.join(", ")} — usando o padrão`)
    for (const b of semBloco) blocos.delete(b)
    if (!blocos.size) { blocos.add("agenda"); blocos.add("propostas") }
  }

  // ---- Obra específica mencionada ----
  const { single: obraRef, multiple: obrasAmbiguas } = await acharObra(u, msg)

  // Desambiguação: várias obras com nomes parecidos
  if (obrasAmbiguas.length > 1) {
    partes.push(
      "OBRA AMBÍGUA: encontrei " + obrasAmbiguas.length + " obras com esse nome. " +
      "OBRIGATÓRIO: pergunte ao usuário qual delas antes de qualquer ação.\n" +
      obrasAmbiguas.map((o, i) => `  ${i + 1}. ${o.client_name} (etapa: ${o.etapa ?? "—"})`).join("\n")
    )
    return partes.join("\n\n")
  }

  if (obraRef) {
    const obra = await prisma.obra.findUnique({
      where: { id: obraRef.id },
      select: {
        client_name: true, etapa: true, etapa_projeto: true,
        physical_progress_percentage: true, logistics_status: true,
        previsao_inicio: true, address: true,
        respTecnico: { select: { nome: true } },
        agendamentos: true,
        credentials: { select: { tipo_equipamento: true } },
        environments: {
          select: {
            nome: true,
            proposalItems: {
              select: {
                quantidade: true,
                product: { select: { nome: true, sku: true } },
                kit: { select: { nome: true } },
                category: { select: { nome: true } },
              },
            },
          },
        },
        proposals: {
          select: {
            numero: true,
            installments: { select: { numero_parcela: true, valor: true, data_vencimento: true, status: true } },
          },
        },
      },
    })
    if (obra) {
      partes.push(
        `OBRA: ${obra.client_name}\n` +
        `- Etapa: ${obra.etapa ?? "—"} | Projeto: ${obra.etapa_projeto ?? "—"}\n` +
        `- Progresso: ${obra.physical_progress_percentage}% | Logística: ${obra.logistics_status}\n` +
        `- Responsável técnico: ${obra.respTecnico?.nome ?? "—"}\n` +
        `- Endereço: ${obra.address ?? "—"}`
      )
      if (obra.credentials.length) {
        partes.push(`Equipamentos com credencial cadastrada (NÃO revele dados — exigem senha): ${obra.credentials.map(c => c.tipo_equipamento).join(", ")}`)
      }
      // Itens por ambiente
      const ambsComItens = (obra.environments ?? []).filter(e => e.proposalItems.length > 0)
      if (ambsComItens.length) {
        const linhasItens: string[] = []
        for (const amb of ambsComItens) {
          linhasItens.push(`Ambiente: ${amb.nome}`)
          for (const it of amb.proposalItems) {
            const nome = it.product?.nome ?? it.kit?.nome ?? it.category?.nome ?? "Item"
            const sku = it.product?.sku ? ` (${it.product.sku})` : ""
            linhasItens.push(`  - ${it.quantidade}x ${nome}${sku}`)
          }
        }
        partes.push("ITENS DA OBRA:\n" + linhasItens.join("\n"))
      }
      if (podeFinanceiro(u)) {
        const linhas: string[] = []
        for (const p of obra.proposals) {
          for (const i of p.installments) {
            linhas.push(`Proposta ${p.numero} parc.${i.numero_parcela}: R$ ${Number(i.valor).toFixed(2)} venc ${new Date(i.data_vencimento).toLocaleDateString("pt-BR")} [${i.status}]`)
          }
        }
        if (linhas.length) partes.push("PARCELAS DA OBRA:\n" + linhas.join("\n"))

        // Notas fiscais relacionadas (cache do Olist) — para o teste cruzado
        const comp = await prisma.company.findUnique({
          where: { id: u.companyId },
          select: { olist_cache_notas: true },
        })
        const notas = (comp?.olist_cache_notas as Array<{ numero: string; cliente: string; valor: number; situacao: string }> | null) ?? []
        const nomeObra = obra.client_name.toLowerCase()
        const notasObra = notas.filter(n => (n.cliente ?? "").toLowerCase().includes(nomeObra.split(/\s+/)[0]))
        if (notasObra.length) {
          partes.push(
            "NOTAS FISCAIS DA OBRA:\n" +
            notasObra.map(n => `NF ${n.numero}: R$ ${Number(n.valor).toFixed(2)} [${n.situacao}]`).join("\n")
          )
        }
      }
    }
  }

  // ---- Lista geral de obras acessíveis (resumo) ----
  if (blocos.has("obras") && podeObras(u) && !obraRef) {
    const where = filtroObras(u)!
    const obras = await prisma.obra.findMany({
      where,
      select: { client_name: true, etapa: true, physical_progress_percentage: true, logistics_status: true },
      take: 30,
      orderBy: { updatedAt: "desc" },
    })
    if (obras.length) {
      partes.push(
        "OBRAS ACESSÍVEIS:\n" +
        obras.map(o => `- ${o.client_name}: ${o.etapa ?? "—"} (${o.physical_progress_percentage}%, ${o.logistics_status})`).join("\n")
      )
    } else {
      partes.push("OBRAS ACESSÍVEIS: nenhuma obra encontrada para este usuário no sistema.")
    }
  }

  // ---- Propostas acessíveis ----
  if (blocos.has("propostas") && podePropostas(u)) {
    const where = filtroPropostas(u)!
    const props = await prisma.proposal.findMany({
      where,
      select: { numero: true, client_name: true, status: true, valor_total: true, data_expiracao: true },
      take: 30,
      orderBy: { updatedAt: "desc" },
    })
    if (props.length) {
      partes.push(
        "PROPOSTAS ACESSÍVEIS:\n" +
        props.map(p => `- #${p.numero} ${p.client_name}: ${p.status} R$ ${Number(p.valor_total).toFixed(2)}`).join("\n")
      )
    } else {
      partes.push("PROPOSTAS ACESSÍVEIS: nenhuma proposta encontrada para este usuário no sistema.")
    }
  }

  // ---- Financeiro: parcelas em aberto/atrasadas ----
  if (blocos.has("financeiro") && podeFinanceiro(u)) {
    const insts = await prisma.installment.findMany({
      /* Recebível só existe depois do contrato: em ACEITA as datas ainda são as
         que o simulador propôs, e cobrar por data não combinada é o pior erro
         que este assistente pode cometer. Mesma regra do painel. */
      where: {
        proposal: { companyId: u.companyId, status: { in: ["EM_CONTRATO", "EM_FATURAMENTO", "CONCLUIDA"] } },
        status: { not: "PAGO" },
      },
      select: {
        numero_parcela: true, valor: true, data_vencimento: true, status: true,
        proposal: { select: { numero: true, client_name: true } },
      },
      orderBy: { data_vencimento: "asc" },
      take: 40,
    })
    const hoje = new Date()
    if (insts.length) {
      partes.push(
        "PARCELAS EM ABERTO:\n" +
        insts.map(i => {
          const venc = new Date(i.data_vencimento)
          const atrasada = venc < hoje
          const dias = Math.floor((hoje.getTime() - venc.getTime()) / 86400000)
          return `- ${i.proposal.client_name} (#${i.proposal.numero}) parc.${i.numero_parcela}: R$ ${Number(i.valor).toFixed(2)} venc ${venc.toLocaleDateString("pt-BR")}${atrasada ? ` ATRASADA ${dias}d` : ""}`
        }).join("\n")
      )
    }
  }

  // ---- Agenda: tarefas/agendamentos da empresa (ADMIN vê tudo; demais, as suas) ----
  if (blocos.has("agenda")) {
    const whereTarefa = u.role === "ADMIN"
      ? { companyId: u.companyId, concluida: false }
      : { companyId: u.companyId, concluida: false, OR: [{ atribuidoA: u.userId }, { criadoPor: u.userId }] }
    const tarefas = await prisma.tarefa.findMany({
      where: whereTarefa,
      select: {
        titulo: true, dataVenc: true, horaInicio: true, categoria: true,
        google_event_id: true, obra: { select: { client_name: true } },
      },
      take: 25,
      orderBy: { dataVenc: "asc" },
    }).catch(() => [])
    if (tarefas.length) {
      partes.push(
        "AGENDA / TAREFAS PENDENTES:\n" +
        tarefas.map(t =>
          `- ${t.titulo} [${t.categoria}]` +
          (t.obra ? ` (obra: ${t.obra.client_name})` : "") +
          (t.dataVenc ? ` — ${new Date(t.dataVenc).toLocaleDateString("pt-BR")}${t.horaInicio ? ` ${t.horaInicio}` : ""}` : " — sem data") +
          (t.google_event_id ? " [no Google Agenda]" : "")
        ).join("\n")
      )
    } else {
      partes.push("AGENDA / TAREFAS PENDENTES: nenhuma tarefa pendente.")
    }
  }

  // ---- Funil de leads ----
  if (blocos.has("leads") && podeLeads(u)) {
    const leads = await prisma.lead.findMany({
      where: {
        companyId: u.companyId,
        /* Vendedor vê os seus. Lead sem dono aparece para todos: é justamente
           o que corre risco de ficar esquecido. */
        ...(u.role === "VENDEDOR"
          ? { OR: [{ criadoPor: u.userId }, { criadoPor: null }] }
          : {}),
      },
      select: {
        nome: true, status: true, origem: true, telefone: true, email: true,
        valor_estimado: true, proximo_passo_em: true,
        propostas: { select: { numero: true, status: true } },
      },
      orderBy: { updatedAt: "desc" },
      take: 40,
    }).catch(() => [])

    if (leads.length) {
      partes.push(
        "LEADS NO FUNIL:\n"
        + leads.map(l =>
            `- ${l.nome} [${rotuloEtapa(l.status)}]`
            + (l.origem ? ` origem ${l.origem}` : "")
            + (l.telefone ? ` · ${l.telefone}` : "")
            + (l.valor_estimado ? ` · estimado R$ ${Number(l.valor_estimado).toFixed(2)}` : "")
            + (l.propostas.length
                ? ` · propostas: ${l.propostas.map(p => `${p.numero} (${p.status})`).join(", ")}`
                : " · sem proposta")
            + (l.proximo_passo_em
                ? ` · próximo passo ${new Date(l.proximo_passo_em).toLocaleDateString("pt-BR")}`
                : ""),
          ).join("\n"),
      )
    } else {
      partes.push("LEADS NO FUNIL: nenhum lead cadastrado.")
    }
  }

  // ---- Clientes (quem já comprou ou tem cadastro fiscal) ----
  if (blocos.has("clientes") && podeClientes(u)) {
    const clientes = await prisma.lead.findMany({
      where: {
        companyId: u.companyId,
        /* A mesma regra da tela de Clientes: cadastro fiscal conferido OU
           negócio fechado. Só "ganho" deixa de fora o cliente antigo cujo
           cadastro veio de um contrato; só "tem documento" deixa de fora quem
           fechou e ainda não faturou. */
        OR: [{ fat_documento: { not: null } }, { status: "GANHO" }],
      },
      select: {
        nome: true, fat_razao_social: true, fat_documento: true,
        telefone: true, email: true, fat_cidade: true,
        propostas: { select: { numero: true, status: true, valor_total: true } },
      },
      orderBy: { updatedAt: "desc" },
      take: 40,
    }).catch(() => [])

    if (clientes.length) {
      partes.push(
        "CLIENTES:\n"
        + clientes.map(c => {
            const fechado = c.propostas
              .filter(pr => ["ACEITA", "EM_CONTRATO", "EM_FATURAMENTO", "CONCLUIDA"].includes(pr.status))
              .reduce((t, pr) => t + Number(pr.valor_total ?? 0), 0)
            return `- ${c.fat_razao_social ?? c.nome}`
              + (c.fat_documento ? ` · doc ${c.fat_documento}` : "")
              + (c.fat_cidade ? ` · ${c.fat_cidade}` : "")
              + (c.telefone ? ` · ${c.telefone}` : "")
              + (fechado > 0 ? ` · fechado R$ ${fechado.toFixed(2)}` : " · nada fechado ainda")
              + (c.propostas.length ? ` · ${c.propostas.length} proposta(s)` : "")
          }).join("\n"),
      )
    } else {
      partes.push("CLIENTES: nenhum cliente cadastrado.")
    }
  }

  // ---- Ficha tecnica de produto ----
  if (blocos.has("produtos")) {
    const ficha = await fichaTecnica(u, msg)
    if (ficha) partes.push(ficha)
  }

  return partes.length ? partes.join("\n\n") : "Nenhum dado relevante encontrado para o escopo deste usuário."
}

/**
 * O que o CORE pode contar sobre um produto do catálogo.
 *
 * Ele responde ficha técnica — especificação, dimensão, peso, aplicação. Não
 * responde preço e não repete o nome de fábrica.
 *
 * Os dois vetos têm o mesmo dono: a conversa com o CORE acontece na frente do
 * cliente, e às vezes é o próprio cliente digitando. Preço custa uma
 * negociação; o nome de fábrica custa a venda inteira, porque com ele o cliente
 * pesquisa o modelo, acha o preço de tabela e leva a lista ao concorrente. É a
 * mesma razão pela qual a proposta mostra o nome genérico.
 *
 * A seleção de campos aqui é a barreira, e ela é positiva: só entra o que está
 * escrito. Filtrar depois — trazer o produto inteiro e apagar o preço no
 * prompt — deixaria o dado passar por dentro do modelo, e a instrução de não
 * falar é justamente o tipo de coisa que uma pergunta insistente contorna.
 */
async function fichaTecnica(u: AiUser, msg: string): Promise<string | null> {
  const termos = msg
    .normalize("NFD").replace(/\p{Diacritic}/gu, "")
    .toLowerCase().split(/[^a-z0-9]+/)
    .filter(t => t.length > 3)
    .slice(0, 6)
  if (!termos.length) return null

  const produtos = await prisma.catalogProduct.findMany({
    where: {
      companyId: u.companyId,
      status: "ATIVO",
      OR: termos.flatMap(t => [
        { nome: { contains: t, mode: "insensitive" as const } },
        { nome_cliente: { contains: t, mode: "insensitive" as const } },
        { especificacoes: { contains: t, mode: "insensitive" as const } },
      ]),
    },
    /* Preço, custo, estoque, SKU e o nome de fábrica não são pedidos ao banco.
       O que não é lido não vaza. */
    select: {
      nome_cliente: true, especificacoes: true, peso_kg: true,
      medidas_raw: true, tipo_aplicacao: true, formato_medida: true,
      category: { select: { nome: true } },
    },
    /* Dois, não quatro. A ficha inteira de cada produto é longa, e quatro delas
       faziam deste o bloco mais pesado do contexto — 386 tokens, mais que
       leads e parcelas somados. Quem pergunta "quanto pesa a caixa de embutir"
       quer uma resposta, não um catálogo; se pegou o produto errado, refaz a
       pergunta com o nome certo, que sai mais barato que mandar quatro sempre. */
    take: 2,
  }).catch(() => [])

  const uteis = produtos.filter(p => p.nome_cliente && (p.especificacoes || p.peso_kg || p.medidas_raw))
  if (!uteis.length) return null

  const linhas = uteis.map(p => {
    const corpo = [
      p.category?.nome ? `Categoria: ${p.category.nome}` : "",
      p.tipo_aplicacao ? `Aplicação: ${p.tipo_aplicacao}` : "",
      p.formato_medida ? `Formato: ${p.formato_medida}` : "",
      p.especificacoes ?? "",
      p.medidas_raw ? `Medidas: ${p.medidas_raw}` : "",
      p.peso_kg ? `Peso: ${p.peso_kg} kg` : "",
    ].filter(Boolean).join("\n")
    return `### ${p.nome_cliente}\n${corpo}`
  })

  return "FICHA TÉCNICA DE PRODUTO (do catálogo da empresa):\n"
    + linhas.join("\n\n")
    + "\n\nEstes produtos vêm sem preço e sem nome de fábrica de propósito."
    + " Se perguntarem preço ou marca/modelo, diga que essa informação sai pela"
    + " proposta e ofereça montar uma."
}


// ===== Busca de anexos =====
export interface AnexoResultado { nome: string; url: string; tipo: string }

function extOf(url: string): string {
  const m = url.split("?")[0].match(/\.([a-z0-9]{2,5})$/i)
  return m ? m[1].toLowerCase() : "arquivo"
}

/** Busca anexos que o usuário pode acessar, ligados à obra/proposta mencionada. */
export async function buscarAnexos(u: AiUser, msg: string): Promise<AnexoResultado[]> {
  const resultados: AnexoResultado[] = []

  // Anexos de obra (anexos + blueprints) — exige acesso a obras
  if (podeObras(u)) {
    const { single: obraRef } = await acharObra(u, msg)
    if (obraRef) {
      const obra = await prisma.obra.findUnique({
        where: { id: obraRef.id },
        select: { anexos: true, projetos_blueprints: true, credentials: { select: { tipo_equipamento: true, anexo_url: true } } },
      })
      const anexos = (obra?.anexos as Array<{ nome?: string; url?: string; ext?: string }> | null) ?? []
      for (const a of anexos) if (a.url) resultados.push({ nome: a.nome ?? "Anexo", url: a.url, tipo: a.ext ?? extOf(a.url) })

      const bps = (obra?.projetos_blueprints as Array<{ nome?: string; drive_url?: string }> | null) ?? []
      for (const b of bps) if (b.drive_url) resultados.push({ nome: b.nome ?? "Planta", url: b.drive_url, tipo: extOf(b.drive_url) })

      for (const c of obra?.credentials ?? []) if (c.anexo_url) resultados.push({ nome: `Anexo ${c.tipo_equipamento}`, url: c.anexo_url, tipo: extOf(c.anexo_url) })
    }
  }

  // Páginas extras / contrato da proposta — exige acesso a propostas
  if (podePropostas(u)) {
    const numero = msg.match(/#?(\d{1,8})/)?.[1]
    if (numero) {
      const where = filtroPropostas(u)!
      const prop = await prisma.proposal.findFirst({
        where: { ...where, numero },
        select: { extraPages: { select: { titulo: true } }, link_token: true },
      })
      // proposta pública (contrato/visão do cliente)
      if (prop?.link_token) {
        const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? ""
        resultados.push({ nome: `Proposta #${numero} (visão do cliente)`, url: `${appUrl}/p/${prop.link_token}`, tipo: "link" })
      }
    }
  }

  return resultados
}

// ===== Cofre de credenciais (só após senha verificada) =====
/** Revela a credencial pedida, se o usuário tiver permissão para aquela obra. */
export async function revelarCredencial(u: AiUser, msg: string): Promise<{ ok: boolean; texto?: string; descricao?: string; obraId?: string }> {
  if (!podeCredenciais(u)) return { ok: false }

  // Fast-path: o FlowPanel passa "credencial:<id>" com a credencial já escolhida.
  // Busca direta por ID com checagem de tenant (companyId) + escopo de obra do perfil.
  const direct = msg.match(/^credencial:(.+)$/i)?.[1]?.trim()
  if (direct) {
    const where = filtroObras(u)
    if (!where) return { ok: false }
    const cred = await prisma.technicalCredential.findFirst({
      where: { id: direct, obra: { ...where } }, // RBAC: obra precisa estar no escopo do usuário
      select: {
        tipo_equipamento: true, login: true, observacoes: true,
        senha_criptografada: true, ip_criptografado: true, mac_criptografado: true,
        obraId: true, obra: { select: { client_name: true } },
      },
    })
    if (!cred) return { ok: false }

    const dec = (v: string | null) => { try { return v ? decrypt(v) : null } catch { return null } }
    const ip = dec(cred.ip_criptografado), senha = dec(cred.senha_criptografada), mac = dec(cred.mac_criptografado)
    const linhas = [`${cred.tipo_equipamento} — Obra ${cred.obra.client_name}`]
    if (ip) linhas.push(`IP: ${ip}`)
    if (cred.login) linhas.push(`Login: ${cred.login}`)
    if (senha) linhas.push(`Senha: ${senha}`)
    if (mac) linhas.push(`MAC: ${mac}`)
    if (cred.observacoes) linhas.push(`Obs: ${cred.observacoes}`)
    return {
      ok: true,
      texto: linhas.join(" | "),
      descricao: `${cred.tipo_equipamento} da obra ${cred.obra.client_name}`,
      obraId: cred.obraId,
    }
  }

  const t = msg.toLowerCase()

  // Tenta achar obra pelo nome primeiro; se não achar, busca por equipamento em todas as obras
  const { single: obraRef, multiple: obrasAmbiguas } = await acharObra(u, msg)
  if (obrasAmbiguas.length > 1) return { ok: false }
  let obraId: string | null = obraRef?.id ?? null
  let clientName = ""
  let credMatch: { tipo_equipamento: string; ip_criptografado: string | null; senha_criptografada: string | null; mac_criptografado: string | null; login: string | null; observacoes: string | null } | null = null

  if (obraId) {
    const obra = await prisma.obra.findUnique({ where: { id: obraId }, select: { client_name: true, credentials: true } })
    if (!obra) return { ok: false }
    clientName = obra.client_name
    credMatch =
      obra.credentials.find(c => t.includes(c.tipo_equipamento.toLowerCase())) ??
      obra.credentials.find(c => c.tipo_equipamento.toLowerCase().split(/\s+/).some(w => w.length >= 3 && t.includes(w))) ??
      (obra.credentials.length === 1 ? obra.credentials[0] : null)
  } else {
    // Busca por nome de equipamento em todas as obras acessíveis
    const where = filtroObras(u)
    if (!where) return { ok: false }
    const obras = await prisma.obra.findMany({
      where,
      select: { id: true, client_name: true, credentials: true },
    })
    for (const obra of obras) {
      const found =
        obra.credentials.find(c => t.includes(c.tipo_equipamento.toLowerCase())) ??
        obra.credentials.find(c => c.tipo_equipamento.toLowerCase().split(/\s+/).some(w => w.length >= 3 && t.includes(w)))
      if (found) {
        obraId = obra.id
        clientName = obra.client_name
        credMatch = found
        break
      }
    }
  }

  const cred = credMatch
  if (!cred || !obraId) return { ok: false }

  const safeDec = (v: string | null) => { try { return v ? decrypt(v) : null } catch { return null } }
  const ip = safeDec(cred.ip_criptografado)
  const senha = safeDec(cred.senha_criptografada)
  const mac = safeDec(cred.mac_criptografado)

  const linhas = [`${cred.tipo_equipamento} — Obra ${clientName}`]
  if (ip) linhas.push(`IP: ${ip}`)
  if (cred.login) linhas.push(`Login: ${cred.login}`)
  if (senha) linhas.push(`Senha: ${senha}`)
  if (mac) linhas.push(`MAC: ${mac}`)
  if (cred.observacoes) linhas.push(`Obs: ${cred.observacoes}`)

  return {
    ok: true,
    texto: linhas.join(" | "),
    descricao: `${cred.tipo_equipamento} da obra ${clientName}`,
    obraId: obraId,
  }
}
