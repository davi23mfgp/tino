import { prisma } from "@/lib/prisma"
import { gerarEmbedding, gerarEmbeddings, embeddingsConfigurado } from "@/lib/ai/embeddings"
import type { AiUser } from "@/lib/ai/scope"

/**
 * RAG do CORE: base de conhecimento própria da empresa.
 *
 * O CORE já responde sobre os DADOS do sistema (obras, propostas, estoque)
 * consultando o banco. Isto aqui cobre o outro lado: manuais, normas,
 * procedimentos internos e memoriais — texto corrido, que não cabe em consulta
 * estruturada e precisa de busca por significado.
 *
 * Fluxo: documento → pedaços → embedding de cada pedaço → busca por
 * similaridade de cosseno (pgvector) → os melhores trechos entram no prompt.
 */

/** Tamanho do pedaço em caracteres, com sobreposição para não cortar ideia no meio. */
const TAMANHO_CHUNK = 1200
const SOBREPOSICAO = 200

export interface TrechoEncontrado {
  texto: string
  titulo: string
  fonte: string | null
  referencia: string | null
  /** 0 a 1 — quanto mais perto de 1, mais parecido com a pergunta. */
  similaridade: number
}

/**
 * Fatia o texto tentando quebrar em parágrafo, depois em frase, e só então no
 * limite bruto — cortar no meio de uma frase estraga o sentido do pedaço e
 * piora a busca.
 */
export function fatiar(texto: string): { texto: string; referencia: string | null }[] {
  const limpo = texto.replace(/\r\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim()
  if (!limpo) return []

  const pedacos: { texto: string; referencia: string | null }[] = []
  let inicio = 0

  while (inicio < limpo.length) {
    let fim = Math.min(inicio + TAMANHO_CHUNK, limpo.length)

    if (fim < limpo.length) {
      const janela = limpo.slice(inicio, fim)
      const quebraParagrafo = janela.lastIndexOf("\n\n")
      const quebraFrase = Math.max(janela.lastIndexOf(". "), janela.lastIndexOf(".\n"))
      // Só aceita a quebra se ela não jogar o pedaço para menos de 40% do alvo.
      const minimo = TAMANHO_CHUNK * 0.4
      if (quebraParagrafo > minimo) fim = inicio + quebraParagrafo
      else if (quebraFrase > minimo) fim = inicio + quebraFrase + 1
    }

    const trecho = limpo.slice(inicio, fim).trim()
    if (trecho) {
      // Marca de página, quando o extrator deixou (ex.: "[página 12]").
      const marca = trecho.match(/\[p[áa]gina\s+(\d+)\]/i)
      pedacos.push({ texto: trecho, referencia: marca ? `página ${marca[1]}` : null })
    }

    if (fim >= limpo.length) break
    inicio = Math.max(fim - SOBREPOSICAO, inicio + 1)
  }

  return pedacos
}

/**
 * Indexa um documento já criado: fatia, gera os vetores e grava os pedaços.
 * Reindexar apaga os pedaços antigos antes — evita duplicar conteúdo.
 */
export async function indexarDocumento(docId: string, texto: string): Promise<{ chunks: number }> {
  const doc = await prisma.knowledgeDoc.findUnique({
    where: { id: docId },
    select: { id: true, companyId: true },
  })
  if (!doc) throw new Error("Documento não encontrado")

  const pedacos = fatiar(texto)
  if (pedacos.length === 0) throw new Error("Documento sem texto aproveitável.")

  const vetores = await gerarEmbeddings(pedacos.map(p => p.texto))

  await prisma.knowledgeChunk.deleteMany({ where: { docId } })

  // O Prisma não escreve em coluna `vector`, então a inserção é SQL puro.
  for (let i = 0; i < pedacos.length; i++) {
    const literal = `[${vetores[i].join(",")}]`
    await prisma.$executeRawUnsafe(
      `INSERT INTO "knowledge_chunks" ("id","docId","companyId","ordem","texto","referencia","embedding","createdAt")
       VALUES (gen_random_uuid()::text, $1, $2, $3, $4, $5, $6::vector, NOW())`,
      doc.id, doc.companyId, i, pedacos[i].texto, pedacos[i].referencia, literal,
    )
  }

  await prisma.knowledgeDoc.update({
    where: { id: docId },
    data: { status: "PRONTO", erro: null, chars: texto.length },
  })

  return { chunks: pedacos.length }
}

/**
 * Busca os trechos mais próximos da pergunta, respeitando o perfil de quem
 * pergunta: documento com `roles` preenchido só aparece para esses perfis.
 */
export async function buscarConhecimento(
  u: AiUser,
  pergunta: string,
  opcoes?: { limite?: number; minimo?: number },
): Promise<TrechoEncontrado[]> {
  if (!embeddingsConfigurado()) return []

  const limite = opcoes?.limite ?? 5
  // Abaixo disso o trecho quase sempre é ruído e só polui o prompt.
  const minimo = opcoes?.minimo ?? 0.35

  let vetor: number[]
  try {
    vetor = await gerarEmbedding(pergunta)
  } catch {
    // Busca semântica indisponível não pode derrubar o chat: o CORE segue
    // respondendo com os dados estruturados.
    return []
  }

  const literal = `[${vetor.join(",")}]`
  const perfis = [...new Set([u.role, ...(u.roles ?? [])])]

  const linhas = await prisma.$queryRawUnsafe<
    { texto: string; titulo: string; fonte: string | null; referencia: string | null; distancia: number }[]
  >(
    `SELECT c."texto", d."titulo", d."fonte", c."referencia",
            (c."embedding" <=> $1::vector) AS distancia
       FROM "knowledge_chunks" c
       JOIN "knowledge_docs" d ON d."id" = c."docId"
      WHERE c."companyId" = $2
        AND d."status" = 'PRONTO'
        AND c."embedding" IS NOT NULL
        AND (cardinality(d."roles") = 0 OR d."roles" && $3::text[])
      ORDER BY c."embedding" <=> $1::vector
      LIMIT $4`,
    literal, u.companyId, perfis, limite,
  )

  return linhas
    // `<=>` devolve distância de cosseno (0 = idêntico); vira similaridade.
    .map(l => ({
      texto: l.texto,
      titulo: l.titulo,
      fonte: l.fonte,
      referencia: l.referencia,
      similaridade: 1 - Number(l.distancia),
    }))
    .filter(t => t.similaridade >= minimo)
}

/** Monta o bloco de contexto que entra no prompt do CORE. */
export function formatarTrechos(trechos: TrechoEncontrado[]): string {
  if (trechos.length === 0) return ""
  const partes = trechos.map((t, i) => {
    const origem = [t.titulo, t.fonte, t.referencia].filter(Boolean).join(" · ")
    return `[${i + 1}] ${origem}\n${t.texto}`
  })
  return [
    "## BASE DE CONHECIMENTO DA EMPRESA — FONTE PREFERENCIAL",
    "Trechos dos documentos que a própria empresa guardou: manuais dos"
      + " equipamentos que ela instala, na versão que ela tem.",
    "REGRA: se estes trechos respondem a pergunta, responda POR ELES e cite a"
      + " origem entre colchetes, ex.: [1]. Não responda por conhecimento geral"
      + " nem por página da internet quando a resposta está aqui — o manual da"
      + " casa é o que vale na obra.",
    "Se de fato não responderem, diga que não encontrou na base — não force o"
      + " encaixe e não invente.",
    "",
    partes.join("\n\n"),
  ].join("\n")
}
