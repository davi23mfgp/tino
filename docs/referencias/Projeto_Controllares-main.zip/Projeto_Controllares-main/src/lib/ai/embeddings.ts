/**
 * Geração de embeddings para o RAG do CORE.
 *
 * A Anthropic não oferece endpoint de embeddings, então este módulo usa
 * qualquer provedor compatível com o formato OpenAI (`POST /embeddings`):
 * Google Gemini, OpenAI, Voyage, Ollama local, etc.
 *
 * O padrão é o Gemini, porque tem camada gratuita: o Google expõe um endpoint
 * compatível com OpenAI e o gemini-embedding-001 aceita `dimensions`, então dá
 * para pedir os 1536 que a coluna espera sem migrar nada. Groq não serve —
 * não tem endpoint de embeddings.
 *
 * Variáveis:
 *   EMBED_BASE_URL   padrão: https://generativelanguage.googleapis.com/v1beta/openai
 *   EMBED_API_KEY    chave do provedor; cai em AI_API_KEY / OPENAI_API_KEY
 *   EMBED_MODEL      padrão: gemini-embedding-001
 *
 * A dimensão precisa bater com a coluna `vector(1536)` da migração. Por isso
 * `dimensions` vai em toda requisição: tanto o Gemini quanto o
 * text-embedding-3-small da OpenAI truncam o vetor para o tamanho pedido.
 */

export const DIMENSOES = 1536

function config() {
  const baseUrl = (process.env.EMBED_BASE_URL || "https://generativelanguage.googleapis.com/v1beta/openai").replace(/\/+$/, "")
  const apiKey = process.env.EMBED_API_KEY || process.env.AI_API_KEY || process.env.OPENAI_API_KEY
  const model = process.env.EMBED_MODEL || "gemini-embedding-001"
  return { baseUrl, apiKey, model }
}

export function embeddingsConfigurado(): boolean {
  return !!config().apiKey
}

/**
 * Gera o vetor de cada texto. Manda em lote — um documento longo pode ter
 * centenas de pedaços, e uma chamada por pedaço estouraria o tempo da request.
 */
export async function gerarEmbeddings(textos: string[]): Promise<number[][]> {
  if (textos.length === 0) return []
  const { baseUrl, apiKey, model } = config()
  if (!apiKey) throw new Error("Embeddings não configurados: defina EMBED_API_KEY (ou AI_API_KEY).")

  const vetores: number[][] = []
  /* Lote menor que o limite do provedor. O gratuito do Google conta
     requisições por minuto e textos por requisição — 64 de uma vez passa do
     teto e derruba o documento inteiro com 429. */
  const LOTE = Number(process.env.EMBED_LOTE) || 16
  /* Pausa entre lotes, para não gastar a cota do minuto em três segundos. */
  const PAUSA_MS = Number(process.env.EMBED_PAUSA_MS) || 1_200

  const espera = (ms: number) => new Promise(r => setTimeout(r, ms))

  for (let i = 0; i < textos.length; i += LOTE) {
    const lote = textos.slice(i, i + LOTE)
    if (i > 0) await espera(PAUSA_MS)

    /* Estourar a cota não é erro do documento: é o provedor pedindo para
       esperar. Repetir com intervalo crescente resolve na maioria das vezes, e
       é o que evita perder um manual inteiro por causa de um pico. */
    let r: Response | null = null
    for (let tentativa = 0; tentativa < 4; tentativa++) {
      r = await fetch(`${baseUrl}/embeddings`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
        body: JSON.stringify({ model, input: lote, dimensions: DIMENSOES }),
        signal: AbortSignal.timeout(60_000),
      })
      if (r.status !== 429) break

      /* O Google diz quanto esperar; quando não diz, o intervalo dobra a cada
         tentativa: 5s, 10s, 20s. */
      const corpo = await r.clone().text().catch(() => "")
      const pedido = corpo.match(/"retryDelay"\s*:\s*"(\d+)s"/)?.[1]
      const segundos = pedido ? Number(pedido) : 5 * 2 ** tentativa
      await espera(Math.min(segundos, 60) * 1000)
    }

    if (!r || !r.ok) {
      const corpo = r ? await r.text().catch(() => "") : ""
      if (r?.status === 429) {
        throw new Error(
          "Cota do provedor de embeddings esgotada. O plano gratuito tem limite"
          + " diário — os documentos que faltaram entram na próxima sincronização,"
          + " ou antes disso ativando o faturamento no Google AI Studio.")
      }
      throw new Error(`Falha ao gerar embeddings (HTTP ${r?.status ?? "sem resposta"}): ${corpo.slice(0, 300)}`)
    }

    const j = await r.json() as { data?: { embedding: number[]; index: number }[] }
    const dados = (j.data ?? []).slice().sort((a, b) => a.index - b.index)
    if (dados.length !== lote.length) {
      throw new Error(`Provedor devolveu ${dados.length} vetores para ${lote.length} textos.`)
    }
    for (const d of dados) {
      if (d.embedding.length !== DIMENSOES) {
        throw new Error(
          `Modelo devolveu vetor de ${d.embedding.length} dimensões; a base espera ${DIMENSOES}. ` +
          `Ajuste EMBED_MODEL (o modelo precisa aceitar "dimensions") ou migre a coluna.`
        )
      }
      vetores.push(d.embedding)
    }
  }

  return vetores
}

/** Embedding de um texto só — usado na pergunta do usuário. */
export async function gerarEmbedding(texto: string): Promise<number[]> {
  const [v] = await gerarEmbeddings([texto])
  return v
}
