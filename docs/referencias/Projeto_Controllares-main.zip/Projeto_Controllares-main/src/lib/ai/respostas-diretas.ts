import { prisma } from "@/lib/prisma"
import { filtroObras, filtroPropostas, podeFinanceiro, type AiUser } from "@/lib/ai/scope"
import { brl } from "@/lib/formato"

/**
 * Respostas que o servidor sabe dar sozinho, sem chamar o modelo.
 *
 * Boa parte do que se pergunta ao CORE é contagem ou lista: "quantas obras
 * tenho", "o que tenho hoje", "quais propostas estão pendentes". Consultar o
 * banco e responder direto é mais rápido, mais exato — o modelo não erra conta
 * que não faz — e não consome a cota do plano gratuito, que fica reservada
 * para as perguntas que realmente exigem raciocínio.
 *
 * Regra: só responde quando a pergunta é inequívoca. Na dúvida, devolve null e
 * o fluxo normal com a IA assume.
 */


function hojeISO(): string {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`
}

/** Normaliza para casar padrão sem depender de acento ou caixa. */
function norm(s: string): string {
  return s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim()
}

// ── Padrões reconhecidos ──────────────────────────────────────────────────
const RE_QTD_OBRAS = /\b(quant(as|os)|numero de|total de)\s+obras?\b/
const RE_MINHAS_OBRAS = /\b(minhas|meus)\s+obras?\b|\bobras?\s+(minhas|sob minha|que eu)\b/
const RE_AGENDA_HOJE = /\b(o que|oque|tenho|agenda|tarefas?|compromissos?)\b.*\bhoje\b|\bhoje\b.*\b(agenda|tarefas?|compromissos?)\b/
const RE_QTD_PROPOSTAS = /\b(quant(as|os)|numero de|total de)\s+propostas?\b/
const RE_PROPOSTAS_ABERTAS = /\bpropostas?\b.*\b(aberta|pendente|em aberto|aguardando|sem resposta)\b/
const RE_PROPOSTAS_VENCER = /\bpropostas?\b.*\b(vencer|vencendo|expira|expirando|prazo)\b/
const RE_A_RECEBER = /\b(a receber|contas a receber|recebimentos?|parcelas? (a vencer|pendentes?))\b/

export interface RespostaDireta {
  texto: string
  /** Só para métrica: mostra que a resposta não custou cota de IA. */
  semIA: true
}

export async function responderDireto(u: AiUser, msg: string): Promise<RespostaDireta | null> {
  const t = norm(msg)

  // ── Obras ───────────────────────────────────────────────────────────────
  if (RE_QTD_OBRAS.test(t) || RE_MINHAS_OBRAS.test(t)) {
    const where = filtroObras(u)
    if (!where) return { texto: "Teu perfil não tem acesso às obras.", semIA: true }

    const obras = await prisma.obra.findMany({
      where,
      select: { client_name: true, etapa: true, physical_progress_percentage: true },
      orderBy: { updatedAt: "desc" },
      take: 15,
    })
    if (obras.length === 0) return { texto: "Nenhuma obra ativa no teu escopo.", semIA: true }

    const linhas = obras.map(o =>
      `• ${o.client_name} — ${o.etapa ?? "sem etapa"} (${o.physical_progress_percentage ?? 0}%)`
    )
    const total = await prisma.obra.count({ where })
    return {
      texto: `${total} obra${total === 1 ? "" : "s"}:\n${linhas.join("\n")}` +
        (total > obras.length ? `\n…e mais ${total - obras.length}.` : ""),
      semIA: true,
    }
  }

  // ── Agenda de hoje ──────────────────────────────────────────────────────
  if (RE_AGENDA_HOJE.test(t)) {
    const hoje = hojeISO()
    const inicio = new Date(`${hoje}T00:00:00`)
    const fim = new Date(`${hoje}T23:59:59`)

    const tarefas = await prisma.tarefa.findMany({
      where: {
        companyId: u.companyId,
        concluida: false,
        dataVenc: { gte: inicio, lte: fim },
        ...(u.role === "ADMIN" ? {} : {
          OR: [{ atribuidoA: u.userId }, { criadoPor: u.userId }],
        }),
      },
      select: { titulo: true, horaInicio: true, obra: { select: { client_name: true } } },
      orderBy: [{ horaInicio: "asc" }],
      take: 20,
    })

    if (tarefas.length === 0) return { texto: "Nada marcado para hoje.", semIA: true }

    const linhas = tarefas.map(x =>
      `• ${x.horaInicio ? `${x.horaInicio} — ` : ""}${x.titulo}${x.obra ? ` (${x.obra.client_name})` : ""}`
    )
    return { texto: `Hoje tens ${tarefas.length}:\n${linhas.join("\n")}`, semIA: true }
  }

  // ── Propostas ───────────────────────────────────────────────────────────
  if (RE_QTD_PROPOSTAS.test(t) || RE_PROPOSTAS_ABERTAS.test(t) || RE_PROPOSTAS_VENCER.test(t)) {
    const where = filtroPropostas(u)
    if (!where) return { texto: "Teu perfil não tem acesso às propostas.", semIA: true }

    if (RE_PROPOSTAS_VENCER.test(t)) {
      const limite = new Date(Date.now() + 7 * 86_400_000)
      const props = await prisma.proposal.findMany({
        where: {
          ...where,
          status: { in: ["ENVIADA", "LIDA", "EM_REVISAO"] },
          data_expiracao: { not: null, lte: limite, gte: new Date() },
        },
        select: { numero: true, client_name: true, data_expiracao: true, valor_total: true },
        orderBy: { data_expiracao: "asc" },
        take: 15,
      })
      if (props.length === 0) return { texto: "Nenhuma proposta vencendo nos próximos 7 dias.", semIA: true }
      const linhas = props.map(p =>
        `• ${p.numero} — ${p.client_name} · vence ${new Date(p.data_expiracao!).toLocaleDateString("pt-BR")} · ${brl(Number(p.valor_total))}`
      )
      return { texto: `${props.length} vencendo em 7 dias:\n${linhas.join("\n")}`, semIA: true }
    }

    if (RE_PROPOSTAS_ABERTAS.test(t)) {
      const props = await prisma.proposal.findMany({
        where: { ...where, status: { in: ["ENVIADA", "LIDA", "EM_REVISAO"] } },
        select: { numero: true, client_name: true, status: true, valor_total: true },
        orderBy: { createdAt: "desc" },
        take: 15,
      })
      if (props.length === 0) return { texto: "Nenhuma proposta aguardando resposta.", semIA: true }
      const soma = props.reduce((s, p) => s + Number(p.valor_total), 0)
      const linhas = props.map(p =>
        `• ${p.numero} — ${p.client_name} · ${p.status.toLowerCase().replace(/_/g, " ")} · ${brl(Number(p.valor_total))}`
      )
      return {
        texto: `${props.length} em aberto, somando ${brl(soma)}:\n${linhas.join("\n")}`,
        semIA: true,
      }
    }

    // Contagem por status
    const grupos = await prisma.proposal.groupBy({
      by: ["status"],
      where,
      _count: true,
    })
    if (grupos.length === 0) return { texto: "Nenhuma proposta cadastrada.", semIA: true }
    const total = grupos.reduce((s, g) => s + g._count, 0)
    const linhas = grupos
      .sort((a, b) => b._count - a._count)
      .map(g => `• ${g.status.toLowerCase().replace(/_/g, " ")}: ${g._count}`)
    return { texto: `${total} proposta${total === 1 ? "" : "s"}:\n${linhas.join("\n")}`, semIA: true }
  }

  // ── Financeiro ──────────────────────────────────────────────────────────
  if (RE_A_RECEBER.test(t)) {
    if (!podeFinanceiro(u)) {
      return { texto: "Dados financeiros são restritos ao Admin e ao Financeiro.", semIA: true }
    }
    const parcelas = await prisma.installment.findMany({
      where: {
        proposal: { companyId: u.companyId },
        status: { in: ["PENDENTE", "ATRASADO"] },
      },
      select: {
        valor: true, data_vencimento: true, status: true,
        proposal: { select: { numero: true, client_name: true } },
      },
      orderBy: { data_vencimento: "asc" },
      take: 15,
    })
    if (parcelas.length === 0) return { texto: "Nada pendente a receber.", semIA: true }

    const soma = parcelas.reduce((s, p) => s + Number(p.valor), 0)
    const atrasadas = parcelas.filter(p => p.status === "ATRASADO").length
    const linhas = parcelas.slice(0, 10).map(p =>
      `• ${new Date(p.data_vencimento).toLocaleDateString("pt-BR")} — ${p.proposal.client_name} · ${brl(Number(p.valor))}${p.status === "ATRASADO" ? " (atrasada)" : ""}`
    )
    return {
      texto: `${parcelas.length} parcela(s) a receber, somando ${brl(soma)}` +
        (atrasadas > 0 ? ` — ${atrasadas} atrasada(s)` : "") +
        `:\n${linhas.join("\n")}`,
      semIA: true,
    }
  }

  return null
}
