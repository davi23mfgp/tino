import { prisma } from "@/lib/prisma"
import { listarArquivos, baixarArquivo, type ArquivoDrive } from "@/lib/google-drive"
import { extensaoSuportada, extrairTexto } from "@/lib/ai/extrair-texto"
import { indexarDocumento } from "@/lib/ai/rag"

/**
 * A pasta do Drive é a base de conhecimento do CORE.
 *
 * Antes, um manual só entrava por upload na tela — e base que depende de alguém
 * lembrar de subir arquivo envelhece calada: o procedimento muda, o PDF novo
 * fica na pasta da equipe, e o CORE segue respondendo pelo antigo. Apontando
 * para a pasta, o lugar onde a equipe já guarda documento passa a ser a fonte.
 *
 * O que entra aqui não é o arquivo inteiro: cada documento é fatiado em pedaços
 * e cada pedaço vira um vetor. Na hora da pergunta o CORE busca só os pedaços
 * parecidos com ela — um manual de 200 páginas responde em três parágrafos, com
 * a página citada.
 */

/** Arquivo grande demais custa caro para vetorizar e raramente é manual. */
const LIMITE_BYTES = 20 * 1024 * 1024

/* Abaixo disto o arquivo não tem o que responder. Uma planta traz meia dúzia
   de rótulos soltos ("PLANTA BAIXA", "ESC 1:50"); um manual de uma página
   passa fácil dos 400 caracteres. */
const MINIMO_UTIL = 400

export interface ResultadoSyncConhecimento {
  indexados: number
  atualizados: number
  ignorados: number
  removidos: number
  erros: { arquivo: string; motivo: string }[]
}

function extensaoDe(arq: ArquivoDrive): string {
  if (arq.mimeType.startsWith("application/vnd.google-apps.")) {
    return arq.mimeType.endsWith("spreadsheet") ? "csv" : "txt"
  }
  return (arq.nome.split(".").pop() ?? "").toLowerCase()
}

export async function sincronizarConhecimento(
  companyId: string,
): Promise<ResultadoSyncConhecimento> {
  const r: ResultadoSyncConhecimento = {
    indexados: 0, atualizados: 0, ignorados: 0, removidos: 0, erros: [],
  }

  const empresa = await prisma.company.findUnique({
    where: { id: companyId },
    select: { drive_conhecimento_id: true },
  })
  if (!empresa?.drive_conhecimento_id) {
    r.erros.push({ arquivo: "—", motivo: "Nenhuma pasta escolhida." })
    return r
  }

  const arquivos = await listarArquivos(companyId, empresa.drive_conhecimento_id)

  /* O que já foi indexado a partir do Drive. A comparação é por id de arquivo,
     não por nome: renomear um manual não pode criar um documento duplicado. */
  const existentes = await prisma.knowledgeDoc.findMany({
    where: { companyId, drive_file_id: { not: null } },
    select: { id: true, drive_file_id: true, drive_modificado: true },
  })
  const porArquivo = new Map(existentes.map(d => [d.drive_file_id!, d]))
  const vistos = new Set<string>()

  for (const arq of arquivos) {
    vistos.add(arq.id)
    const ext = extensaoDe(arq)

    if (!extensaoSuportada(ext)) { r.ignorados++; continue }
    if (arq.tamanho && arq.tamanho > LIMITE_BYTES) {
      r.erros.push({ arquivo: arq.nome, motivo: "maior que 20 MB" })
      continue
    }

    const jaTem = porArquivo.get(arq.id)
    const modificado = new Date(arq.modificadoEm)

    /* Arquivo que não mudou desde a última vez não é baixado nem vetorizado de
       novo: embedding custa dinheiro e tempo, e o resultado seria idêntico. */
    if (jaTem?.drive_modificado && jaTem.drive_modificado >= modificado) {
      r.ignorados++
      continue
    }

    const baixado = await baixarArquivo(companyId, arq)
    if ("erro" in baixado) {
      r.erros.push({ arquivo: arq.nome, motivo: baixado.erro })
      continue
    }

    let texto: string
    try {
      /* O extrator decide pelo formato, e o nome é o que carrega a extensão —
         um Google Doc exportado não tem extensão nenhuma no nome original. */
      const arquivoFalso = new File([baixado.conteudo], `documento.${baixado.ext}`)
      texto = (await extrairTexto(arquivoFalso)).texto
    } catch (e) {
      r.erros.push({
        arquivo: arq.nome,
        motivo: e instanceof Error ? e.message : "não foi possível ler o arquivo",
      })
      continue
    }

    if (texto.trim().length < MINIMO_UTIL) {
      /* Sem texto suficiente para responder pergunta nenhuma.

         São dois casos, e nenhum é defeito: planta de arquitetura, que é
         desenho, e PDF escaneado, que é imagem. A pasta da equipe tem os dois
         no meio dos manuais, e marcá-los em vermelho encheria a tela de alarme
         para arquivos que estão certos — some com o alarme de verdade quando
         ele aparecer. Entram como ignorados, e o documento nem chega a existir. */
      r.ignorados++
      /* Se já existia da rodada anterior, sai: era o registro de um erro que
         não era erro. */
      if (jaTem) await prisma.knowledgeDoc.delete({ where: { id: jaTem.id } }).catch(() => {})
      continue
    }

    const doc = jaTem
      ? await prisma.knowledgeDoc.update({
          where: { id: jaTem.id },
          data: {
            titulo: arq.nome, status: "PENDENTE",
            drive_modificado: modificado,
            fonte: `Google Drive · ${arq.nome}`,
          },
          select: { id: true },
        })
      : await prisma.knowledgeDoc.create({
          data: {
            companyId, titulo: arq.nome, origem: "DRIVE",
            fonte: `Google Drive · ${arq.nome}`,
            drive_file_id: arq.id, drive_modificado: modificado,
            status: "PENDENTE",
          },
          select: { id: true },
        })

    /* Reindexar apaga os pedaços antigos antes: sem isso a versão anterior do
       manual continuaria sendo encontrada ao lado da nova, e o CORE
       responderia com as duas. */
    if (jaTem) {
      await prisma.knowledgeChunk.deleteMany({ where: { docId: doc.id } })
    }

    try {
      await indexarDocumento(doc.id, texto)
      await prisma.knowledgeDoc.update({
        where: { id: doc.id },
        data: { status: "PRONTO", erro: null },
      })
      if (jaTem) r.atualizados++; else r.indexados++
    } catch (e) {
      const motivo = e instanceof Error ? e.message : "falha ao indexar"
      await prisma.knowledgeDoc.update({
        where: { id: doc.id },
        /* O motivo fica gravado junto do documento. "0 trechos" sozinho não
           distingue arquivo ilegível de chave de embeddings faltando, e são
           problemas com soluções completamente diferentes. */
        data: { status: "ERRO", erro: motivo.slice(0, 400) },
      }).catch(() => {})
      r.erros.push({
        arquivo: arq.nome,
        motivo,
      })
    }
  }

  /* Sumiu da pasta, sai da base. Documento apagado no Drive que continuasse
     respondendo seria pior que não ter base: o procedimento foi revogado
     justamente porque deixou de valer. */
  const sumidos = existentes.filter(d => !vistos.has(d.drive_file_id!))
  if (sumidos.length) {
    await prisma.knowledgeDoc.deleteMany({ where: { id: { in: sumidos.map(d => d.id) } } })
    r.removidos = sumidos.length
  }

  await prisma.company.update({
    where: { id: companyId },
    data: { drive_conhecimento_sync: new Date() },
  }).catch(() => {})

  return r
}
