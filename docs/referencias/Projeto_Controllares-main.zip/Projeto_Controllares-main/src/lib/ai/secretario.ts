import { prisma } from "@/lib/prisma"
import type { AiUser } from "@/lib/ai/scope"
import { podeObras, podePropostas } from "@/lib/ai/scope"

/**
 * O CORE como secretário: entende um pedido em português, monta a ação e
 * devolve para confirmação. Quem executa é `executarAcaoSecretario`, só depois
 * do "sim" do usuário.
 *
 * Duas decisões que valem explicar:
 *
 *  - Interpretação é determinística, não é o modelo que decide. Ação que grava
 *    no banco não pode depender de o modelo ter entendido certo; um regex que
 *    falha devolve null e vira conversa normal, o que é seguro. Um modelo que
 *    "alucina" um agendamento, não.
 *
 *  - Nada executa sem confirmação explícita, e a permissão é checada duas
 *    vezes: ao montar e ao executar. A primeira é para não prometer o que não
 *    pode; a segunda porque a confirmação chega em outra requisição.
 */

export type TipoAcao = "criar_tarefa" | "agendar" | "concluir_tarefa" | "anotar_obra"

export interface AcaoProposta {
  acao: TipoAcao
  params: Record<string, unknown>
  /** O que o usuário vai ler antes de confirmar. */
  descricao: string
}

const DIAS = ["domingo", "segunda", "terça", "quarta", "quinta", "sexta", "sábado"]

function norm(s: string): string {
  return s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()
}

/** Interpreta "hoje", "amanhã", "sexta", "dia 12", "12/03". */
function extrairData(t: string): { data: Date; rotulo: string } | null {
  const hoje = new Date()
  hoje.setHours(0, 0, 0, 0)

  if (/\bhoje\b/.test(t)) return { data: hoje, rotulo: "hoje" }
  if (/\bamanha\b/.test(t)) {
    const d = new Date(hoje); d.setDate(d.getDate() + 1)
    return { data: d, rotulo: "amanhã" }
  }
  if (/\bdepois de amanha\b/.test(t)) {
    const d = new Date(hoje); d.setDate(d.getDate() + 2)
    return { data: d, rotulo: "depois de amanhã" }
  }

  // Dia da semana: pega a próxima ocorrência.
  const semana = ["domingo", "segunda", "terca", "quarta", "quinta", "sexta", "sabado"]
  for (let i = 0; i < semana.length; i++) {
    if (new RegExp(`\\b${semana[i]}(-feira)?\\b`).test(t)) {
      const d = new Date(hoje)
      const delta = (i - d.getDay() + 7) % 7 || 7
      d.setDate(d.getDate() + delta)
      return { data: d, rotulo: `${DIAS[i]} (${d.toLocaleDateString("pt-BR")})` }
    }
  }

  // 12/03 ou 12/03/2026
  const m = t.match(/\b(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\b/)
  if (m) {
    const dia = Number(m[1]), mes = Number(m[2]) - 1
    const ano = m[3] ? (m[3].length === 2 ? 2000 + Number(m[3]) : Number(m[3])) : hoje.getFullYear()
    const d = new Date(ano, mes, dia)
    if (!isNaN(d.getTime())) return { data: d, rotulo: d.toLocaleDateString("pt-BR") }
  }

  return null
}

/**
 * Interpreta "às 14h", "14:30", "as 9".
 *
 * Tira a data antes de procurar: em "dia 12/03 às 9h" o `12` casaria como
 * hora e o compromisso iria para o horário errado.
 */
function extrairHora(t: string): string | null {
  const semData = t.replace(/\b\d{1,2}\/\d{1,2}(\/\d{2,4})?\b/g, " ")

  // Só conta como hora quando vier marcada: "9h", "14:30" ou "às 9".
  const m =
    semData.match(/\b(\d{1,2}):(\d{2})\b/) ??
    semData.match(/\b(\d{1,2})\s*(?:h|hs|horas)\b/) ??
    semData.match(/\b(?:as|às)\s+(\d{1,2})\b/)
  if (!m) return null

  const h = Number(m[1])
  if (h > 23) return null
  const min = m[2] && /^\d{2}$/.test(m[2]) ? m[2] : "00"
  return `${String(h).padStart(2, "0")}:${min}`
}

/** Acha a obra citada no texto pelo nome do cliente. */
async function acharObra(u: AiUser, t: string): Promise<{ id: string; nome: string } | null> {
  const obras = await prisma.obra.findMany({
    where: { companyId: u.companyId },
    select: { id: true, client_name: true },
  })
  // Nome mais longo primeiro: "Silva Costa" ganha de "Silva".
  const casadas = obras
    .filter(o => norm(o.client_name).length >= 4 && t.includes(norm(o.client_name)))
    .sort((a, b) => b.client_name.length - a.client_name.length)
  return casadas[0] ? { id: casadas[0].id, nome: casadas[0].client_name } : null
}

const RE_CRIAR_TAREFA = /\b(cri(a|ar|e)|anot(a|ar|e)|adicion(a|ar|e)|lembr(a|ar|e)[- ]?me|coloc(a|ar|e))\b.{0,25}\b(tarefa|lembrete|pendencia|to-?do)\b/
const RE_AGENDAR = /\b(agend(a|ar|e)|marc(a|ar|e))\b/
const RE_CONCLUIR = /\b(conclu(i|ir|a)|finaliz(a|ar|e)|marc(a|ar|e)\s+como\s+(feit|conclu)|dar?\s+baixa\s+na\s+tarefa)\b/
const RE_ANOTAR_OBRA = /\b(anot(a|ar|e)|registr(a|ar|e)|adicion(a|ar|e)\s+(uma\s+)?nota)\b.{0,30}\bobra\b/

/**
 * Lê o pedido e monta a ação. Devolve null quando não é pedido de ação ou
 * quando falta informação essencial — nesse caso o fluxo normal responde e
 * pode pedir o que falta.
 */
export async function interpretarPedido(u: AiUser, msg: string): Promise<AcaoProposta | null> {
  const t = norm(msg)

  // ── Anotar na obra ──────────────────────────────────────────────────────
  if (RE_ANOTAR_OBRA.test(t)) {
    if (!podeObras(u)) return null
    const obra = await acharObra(u, t)
    if (!obra) return null
    // O texto da nota é o que sobra depois de "anota na obra X que ..."
    const conteudo = msg.replace(/^.*?\b(que|:)\s*/i, "").trim()
    if (conteudo.length < 3) return null
    return {
      acao: "anotar_obra",
      params: { obraId: obra.id, texto: conteudo },
      descricao: `Anotar na obra ${obra.nome}:\n"${conteudo}"`,
    }
  }

  // ── Concluir tarefa ─────────────────────────────────────────────────────
  if (RE_CONCLUIR.test(t)) {
    const abertas = await prisma.tarefa.findMany({
      where: {
        companyId: u.companyId, concluida: false,
        ...(u.role === "ADMIN" ? {} : { OR: [{ atribuidoA: u.userId }, { criadoPor: u.userId }] }),
      },
      select: { id: true, titulo: true },
      take: 50,
    })
    const casada = abertas.filter(x => norm(x.titulo).length >= 4 && t.includes(norm(x.titulo)))
    if (casada.length !== 1) return null
    return {
      acao: "concluir_tarefa",
      params: { tarefaId: casada[0].id },
      descricao: `Marcar como concluída: "${casada[0].titulo}"`,
    }
  }

  // ── Criar tarefa / agendar ──────────────────────────────────────────────
  const ehAgenda = RE_AGENDAR.test(t)
  if (RE_CRIAR_TAREFA.test(t) || ehAgenda) {
    const quando = extrairData(t)
    const hora = extrairHora(t)
    // Agendamento sem data não é agendamento — melhor perguntar que chutar.
    if (ehAgenda && !quando) return null

    const obra = await acharObra(u, t)

    // Título: tira o verbo de comando, a data e a obra do começo da frase.
    let titulo = msg
      .replace(/^\s*(cria|criar|crie|agenda|agendar|agende|marca|marcar|marque|anota|anotar|anote|adiciona|adicionar|adicione|lembra|lembrar|lembre)[- ]?(me)?\s*/i, "")
      .replace(/\b(uma?\s+)?(tarefa|lembrete|pendencia|compromisso)\s*/i, "")
      .replace(/\b(para|pra|no dia|dia|as|às)\s*/i, " ")
      .replace(/\b\d{1,2}\/\d{1,2}(\/\d{2,4})?\b/, "")
      .replace(/\b\d{1,2}(:\d{2})?\s*(h|hs|horas)?\b/, "")
      .replace(/\b(hoje|amanha|amanhã|depois de amanha)\b/i, "")
      .replace(/\s{2,}/g, " ")
      .trim()
    if (obra) titulo = titulo.replace(new RegExp(obra.nome, "i"), "").replace(/\s{2,}/g, " ").trim()
    titulo = titulo.replace(/^[,\-–—:\s]+|[,\-–—:\s]+$/g, "")

    if (titulo.length < 3) return null

    const partes = [
      quando ? `para ${quando.rotulo}` : "sem data",
      hora ? `às ${hora}` : null,
      obra ? `na obra ${obra.nome}` : null,
    ].filter(Boolean)

    return {
      acao: ehAgenda ? "agendar" : "criar_tarefa",
      params: {
        titulo,
        dataVenc: quando?.data.toISOString() ?? null,
        horaInicio: hora,
        obraId: obra?.id ?? null,
      },
      descricao: `${ehAgenda ? "Agendar" : "Criar tarefa"}: "${titulo}" ${partes.join(" ")}`,
    }
  }

  return null
}

/** Executa a ação já confirmada. Revalida permissão: a confirmação é outra requisição. */
export async function executarAcaoSecretario(
  u: AiUser,
  acao: TipoAcao,
  params: Record<string, unknown>,
): Promise<{ ok: boolean; message: string }> {
  if (acao === "anotar_obra") {
    if (!podeObras(u)) return { ok: false, message: "Teu perfil não pode alterar obras." }
    const obraId = String(params.obraId ?? "")
    const texto = String(params.texto ?? "").trim()
    const obra = await prisma.obra.findFirst({
      where: { id: obraId, companyId: u.companyId },
      select: { id: true, client_name: true, notas: true },
    })
    if (!obra) return { ok: false, message: "Obra não encontrada." }

    const carimbo = `[${new Date().toLocaleString("pt-BR")} · ${u.nome}] ${texto}`
    await prisma.obra.update({
      where: { id: obra.id },
      data: { notas: obra.notas ? `${obra.notas}\n\n${carimbo}` : carimbo },
    })
    return { ok: true, message: `Anotado na obra ${obra.client_name}.` }
  }

  if (acao === "concluir_tarefa") {
    const id = String(params.tarefaId ?? "")
    const t = await prisma.tarefa.findFirst({
      where: { id, companyId: u.companyId },
      select: { id: true, titulo: true },
    })
    if (!t) return { ok: false, message: "Tarefa não encontrada." }
    await prisma.tarefa.update({ where: { id: t.id }, data: { concluida: true } })
    return { ok: true, message: `"${t.titulo}" marcada como concluída.` }
  }

  if (acao === "criar_tarefa" || acao === "agendar") {
    const titulo = String(params.titulo ?? "").trim()
    if (!titulo) return { ok: false, message: "Faltou o título." }

    const obraId = params.obraId ? String(params.obraId) : null
    if (obraId) {
      const obra = await prisma.obra.findFirst({
        where: { id: obraId, companyId: u.companyId }, select: { id: true },
      })
      if (!obra) return { ok: false, message: "Obra não encontrada." }
    }

    const criada = await prisma.tarefa.create({
      data: {
        titulo,
        companyId: u.companyId,
        criadoPor: u.userId,
        atribuidoA: u.userId,
        dataVenc: params.dataVenc ? new Date(String(params.dataVenc)) : null,
        horaInicio: params.horaInicio ? String(params.horaInicio) : null,
        obraId,
        categoria: "GERAL",
      },
      select: { titulo: true, dataVenc: true, horaInicio: true },
    })

    const quando = criada.dataVenc
      ? ` para ${criada.dataVenc.toLocaleDateString("pt-BR")}${criada.horaInicio ? ` às ${criada.horaInicio}` : ""}`
      : ""
    return { ok: true, message: `Pronto — "${criada.titulo}"${quando}. Está na Agenda.` }
  }

  return { ok: false, message: "Ação desconhecida." }
}

/** Só para o prompt saber o que pode oferecer. */
export function podeAgirComo(u: AiUser): string[] {
  const acoes = ["criar tarefa", "agendar compromisso", "concluir tarefa"]
  if (podeObras(u)) acoes.push("anotar na obra")
  if (podePropostas(u)) acoes.push("consultar propostas")
  return acoes
}
