/**
 * Cliente de LLM trocável por .env. Suporta:
 *  - Anthropic (Claude)  → AI_PROVIDER="anthropic"
 *  - Qualquer endpoint compatível com OpenAI → AI_PROVIDER="openai"
 *    (Groq, Google Gemini, OpenRouter, Ollama local, etc.)
 *
 * Variáveis:
 *   AI_PROVIDER   "anthropic" | "openai"  (default: detecta pela chave disponível)
 *   AI_MODEL      nome do modelo
 *   # Anthropic:
 *   ANTHROPIC_API_KEY
 *   # OpenAI-compatível:
 *   AI_BASE_URL   ex.: https://api.groq.com/openai/v1
 *   AI_API_KEY    chave do provedor
 *
 * A chave NUNCA vai para o frontend nem para logs.
 */

export interface ChatMsg {
  role: "user" | "assistant"
  content: string
}

function provider(): "anthropic" | "openai" {
  const p = process.env.AI_PROVIDER?.toLowerCase()
  if (p === "anthropic" || p === "openai") return p
  // auto: se tiver base url + key compatível, usa openai; senão anthropic
  if (process.env.AI_BASE_URL && process.env.AI_API_KEY) return "openai"
  return "anthropic"
}

export function modeloEmUso(): string {
  return (
    process.env.AI_MODEL ??
    // "claude-sonnet-4-6" não existe na API — quebrava o CORE quando
    // AI_PROVIDER=anthropic sem AI_MODEL definido.
    (provider() === "anthropic" ? "claude-sonnet-5" : "llama-3.3-70b-versatile")
  )
}

/** Stream de texto puro (deltas), pronto para repassar via SSE. */
export async function streamAI(
  system: string,
  messages: ChatMsg[]
): Promise<ReadableStream<Uint8Array>> {
  return provider() === "anthropic"
    ? streamAnthropic(system, messages)
    : streamOpenAICompat(system, messages)
}

// ===================== Anthropic =====================
async function streamAnthropic(system: string, messages: ChatMsg[]) {
  const apiKey = process.env.ANTHROPIC_API_KEY
  if (!apiKey) throw new Error("ANTHROPIC_API_KEY não configurada no .env")

  /* Passa pela mesma repetição do caminho sem stream. A primeira versão só
     protegeu aquele — e o chat, que é justamente onde o usuário VÊ o erro, usa
     este. O 429 do plano gratuito aparecia cru na tela do CORE. */
  const upstream = await comRepeticao(() => fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "content-type": "application/json",
    },
    body: JSON.stringify({ model: modeloEmUso(), max_tokens: 2048, system, messages, stream: true }),
  }), "Anthropic")
  if (!upstream.body) throw new Error("IA (Anthropic): resposta sem corpo.")
  return parseSSE(upstream.body, ev => {
    if (ev?.type === "content_block_delta" && ev?.delta?.type === "text_delta") return ev.delta.text as string
    return null
  })
}

// ============ OpenAI-compatível (Groq/Gemini/Ollama/OpenRouter) ============
async function streamOpenAICompat(system: string, messages: ChatMsg[]) {
  const base = process.env.AI_BASE_URL
  const apiKey = process.env.AI_API_KEY
  if (!base) throw new Error("AI_BASE_URL não configurada no .env")

  const upstream = await comRepeticao(() => fetch(`${base.replace(/\/$/, "")}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}), // Ollama local não exige
    },
    body: JSON.stringify({
      model: modeloEmUso(),
      max_tokens: 2048,
      stream: true,
      messages: [{ role: "system", content: system }, ...messages],
    }),
  }), "OpenAI-compat")
  if (!upstream.ok || !upstream.body) {
    const txt = await upstream.text().catch(() => "")

    /* Modelo que não existe mais é o erro mais comum aqui, e o mais confuso.

       Os provedores aposentam modelo sem aviso: o CORE, que funcionava ontem,
       passa a responder um JSON cru de 404 dizendo "model_not_found" — que não
       diz a quem lê nem qual variável mexer nem o que colocar nela. Como a API
       compatível com OpenAI sempre expõe /models, dá para perguntar quais
       existem e responder com a lista. */
    if (upstream.status === 404 && /model/i.test(txt)) {
      const disponiveis = await listarModelos(base, apiKey)
      throw new Error(
        `O modelo "${modeloEmUso()}" não existe mais neste provedor.`
        + " Troque a variável AI_MODEL nas configurações do deploy."
        + (disponiveis.length ? ` Disponíveis agora: ${disponiveis.slice(0, 8).join(", ")}.` : ""),
      )
    }
    throw new Error(`IA (OpenAI-compat) ${upstream.status}: ${txt.slice(0, 200)}`)
  }
  return parseSSE(upstream.body, ev => ev?.choices?.[0]?.delta?.content ?? null)
}

/** Lista os modelos que o provedor aceita hoje. Falhou, devolve vazio: isto é
    ajuda para a mensagem de erro, não pode virar um segundo erro. */
async function listarModelos(base: string, apiKey?: string): Promise<string[]> {
  try {
    const r = await fetch(`${base.replace(/\/$/, "")}/models`, {
      headers: apiKey ? { Authorization: `Bearer ${apiKey}` } : {},
      signal: AbortSignal.timeout(8_000),
    })
    if (!r.ok) return []
    const j = await r.json()
    const lista = (j?.data ?? j?.models ?? []) as { id?: string; name?: string }[]
    return lista.map(m => m.id ?? m.name ?? "").filter(Boolean)
  } catch {
    return []
  }
}

// ===================== Parser SSE genérico =====================
/**
 * Converte o SSE do provedor num stream de texto puro.
 *
 * Escrito com `start` e um laço próprio, e não com `pull`, por um motivo que
 * custou caro: no Node, um `pull()` que termina sem enfileirar nada NUNCA é
 * chamado de novo. O stream fica pendurado para sempre, sem erro e sem fechar.
 *
 * Isso é fatal aqui porque a maioria dos eventos SSE não carrega texto: ping,
 * `[DONE]`, abertura de bloco, e — nos modelos que pensam antes de responder,
 * como o gpt-oss que o CORE usa — dezenas de deltas de raciocínio seguidos. O
 * primeiro evento sem texto encerrava a conversa. Na tela: "O CORE parou de
 * responder", sem nada no log, porque do ponto de vista do código não houve
 * falha nenhuma — a resposta simplesmente nunca chegou.
 *
 * O laço em `start` lê até o fim por conta própria e só usa a fila para o que
 * tem texto. Quantos eventos vazios passarem no caminho deixa de importar.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function parseSSE(
  body: ReadableStream<Uint8Array>,
  pick: (ev: any) => string | null
): ReadableStream<Uint8Array> {
  const reader = body.getReader()
  const decoder = new TextDecoder()
  const encoder = new TextEncoder()

  return new ReadableStream<Uint8Array>({
    async start(controller) {
      let buffer = ""
      try {
        for (;;) {
          const { done, value } = await reader.read()
          if (done) break
          buffer += decoder.decode(value, { stream: true })

          /* Corta em linhas completas; o resto fica no buffer. Um evento pode
             chegar partido no meio, e parsear metade de JSON só produz lixo. */
          const linhas = buffer.split("\n")
          buffer = linhas.pop() ?? ""

          for (const linha of linhas) {
            const l = linha.trim()
            if (!l.startsWith("data:")) continue
            const data = l.slice(5).trim()
            if (data === "[DONE]") continue
            try {
              const txt = pick(JSON.parse(data))
              if (txt) controller.enqueue(encoder.encode(txt))
            } catch {
              /* linha não-JSON (ping) — seguir */
            }
          }
        }
        controller.close()
      } catch (e) {
        /* Erro de rede no meio da resposta precisa chegar a quem lê. Fechar em
           silêncio devolveria uma resposta pela metade como se estivesse
           completa, que é pior que mostrar o erro. */
        controller.error(e)
      }
    },
    cancel() { reader.cancel().catch(() => {}) },
  })
}

/**
 * Uma resposta inteira, sem stream.
 *
 * O chat precisa de stream porque o usuário lê enquanto o texto chega. Já a
 * extração de escopo precisa do JSON completo para dar `JSON.parse` — não há o
 * que mostrar em pedaços.
 *
 * Antes isto acumulava o stream SSE, e era o caminho errado por dois motivos.
 * O barato: montar o texto de volta pedaço a pedaço para depois parsear é
 * trabalho jogado fora. O caro: o wrapper de stream travava sem nunca fechar
 * com modelos que emitem blocos de raciocínio antes da resposta, e como não
 * havia prazo nenhum na chamada, o `POST /reunioes/[id]/processar` ficava
 * pendurado até a Vercel matar a função em 60 s. Quem clicava "Montar proposta"
 * via a tela falhar sem mensagem, e a reunião continuava como RECEBIDA.
 *
 * Aqui é uma requisição comum, com prazo. Falhou, falhou dizendo por quê.
 */
const PRAZO_MS = 45_000

/**
 * Espera e tenta de novo quando o provedor diz "devagar".
 *
 * O plano gratuito do Groq trabalha com 8 mil tokens por minuto. Uma reunião
 * transcrita mais o prompt passam disso com facilidade, e a resposta é um 429 —
 * que não é defeito, é a vez de outro. Sem tratar, o 429 subia como falha
 * qualquer: a extração devolvia escopo vazio, a reunião era marcada sem itens e
 * o vendedor concluía que a gravação não prestava. O erro mais comum do sistema
 * era o mais mal explicado.
 *
 * A API diz em `retry-after` quanto falta. Obedecer isso é mais rápido e mais
 * educado que um intervalo escolhido no chute; o dobro-a-cada-vez fica só para
 * quando ela não diz nada.
 */
const TENTATIVAS = 3

function esperaDe(r: Response, tentativa: number): number {
  const cabecalho = r.headers.get("retry-after")
  const segundos = cabecalho ? Number(cabecalho) : NaN
  if (Number.isFinite(segundos) && segundos > 0) return Math.min(segundos * 1000 + 250, 30_000)
  return Math.min(2_000 * 2 ** tentativa, 30_000)
}

const dormir = (ms: number) => new Promise(r => setTimeout(r, ms))

/** Erro que vale repetir: limite de uso e instabilidade momentânea do provedor. */
const REPETIVEL = new Set([408, 409, 425, 429, 500, 502, 503, 504])

async function comRepeticao(
  chamar: () => Promise<Response>,
  rotulo: string,
): Promise<Response> {
  let ultima: Response | null = null
  for (let tentativa = 0; tentativa < TENTATIVAS; tentativa++) {
    const r = await chamar()
    if (r.ok || !REPETIVEL.has(r.status)) return r
    ultima = r
    if (tentativa < TENTATIVAS - 1) await dormir(esperaDe(r, tentativa))
  }

  /* Esgotou. A mensagem precisa dizer o que fazer, porque quem lê está numa
     tela de proposta e não tem como saber o que é TPM. */
  if (ultima?.status === 429) {
    throw new Error(
      `A IA (${rotulo}) atingiu o limite de uso por minuto do plano.`
      + " Espere um minuto e tente de novo — nada foi perdido.",
    )
  }
  const txt = await ultima!.text().catch(() => "")
  throw new Error(`IA (${rotulo}) ${ultima!.status}: ${txt.slice(0, 200)}`)
}

export async function chamarAI(messages: ChatMsg[], system: string): Promise<string> {
  return provider() === "anthropic"
    ? completarAnthropic(system, messages)
    : completarOpenAICompat(system, messages)
}

async function completarAnthropic(system: string, messages: ChatMsg[]): Promise<string> {
  const apiKey = process.env.ANTHROPIC_API_KEY
  if (!apiKey) throw new Error("ANTHROPIC_API_KEY não configurada no .env")

  const r = await comRepeticao(() => fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "content-type": "application/json",
    },
    body: JSON.stringify({ model: modeloEmUso(), max_tokens: 2048, system, messages }),
    signal: AbortSignal.timeout(PRAZO_MS),
  }), "Anthropic")
  const j = await r.json()
  const blocos = (j?.content ?? []) as { type?: string; text?: string }[]
  return blocos.filter(b => b?.type === "text").map(b => b.text ?? "").join("")
}

async function completarOpenAICompat(system: string, messages: ChatMsg[]): Promise<string> {
  const base = process.env.AI_BASE_URL
  const apiKey = process.env.AI_API_KEY
  if (!base) throw new Error("AI_BASE_URL não configurada no .env")

  const r = await comRepeticao(() => fetch(`${base.replace(/\/$/, "")}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}),
    },
    body: JSON.stringify({
      model: modeloEmUso(),
      max_tokens: 2048,
      messages: [{ role: "system", content: system }, ...messages],
    }),
    signal: AbortSignal.timeout(PRAZO_MS),
  }), "OpenAI-compat")
  if (!r.ok) {
    const txt = await r.text().catch(() => "")
    if (r.status === 404 && /model/i.test(txt)) {
      const disponiveis = await listarModelos(base, apiKey)
      throw new Error(
        `O modelo "${modeloEmUso()}" não existe mais neste provedor.`
        + " Troque a variável AI_MODEL nas configurações do deploy."
        + (disponiveis.length ? ` Disponíveis agora: ${disponiveis.slice(0, 8).join(", ")}.` : ""),
      )
    }
    throw new Error(`IA (OpenAI-compat) ${r.status}: ${txt.slice(0, 200)}`)
  }
  const j = await r.json()
  return String(j?.choices?.[0]?.message?.content ?? "")
}
