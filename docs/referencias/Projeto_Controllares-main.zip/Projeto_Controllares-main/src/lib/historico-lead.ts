import { prisma } from "@/lib/prisma"
import type { JWTPayload } from "@/lib/auth"

/**
 * Escreve uma linha no histórico do cliente.
 *
 * Chamado pelas rotas que MEXEM no lead, não pela tela: se registrar o
 * movimento dependesse de o navegador lembrar de fazer uma segunda chamada, o
 * histórico ficaria com buracos exatamente nas horas em que a conexão caiu —
 * e um histórico com buraco não serve para conferir nada.
 *
 * Nunca derruba a operação que a chamou. Perder a anotação é ruim; perder a
 * proposta porque a anotação falhou é pior.
 */
export async function registrarNoHistorico(
  session: JWTPayload,
  dados: {
    leadId?: string | null
    proposalId?: string | null
    etapa: string
    texto: string
    tipo?: "NOTA" | "ETAPA" | "SISTEMA"
    de?: string | null
    para?: string | null
  },
) {
  try {
    if (!dados.leadId && !dados.proposalId) return null
    return await prisma.nota.create({
      data: {
        companyId: session.companyId,
        leadId: dados.leadId ?? null,
        proposalId: dados.leadId ? null : (dados.proposalId ?? null),
        etapa: dados.etapa,
        tipo: dados.tipo ?? "NOTA",
        de: dados.de ?? null,
        para: dados.para ?? null,
        texto: dados.texto,
        autorId: session.userId,
        autorNome: session.nome,
      },
    })
  } catch {
    return null
  }
}
