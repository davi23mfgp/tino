/**
 * Parser do "Estudo de Teclas" — cola direto do Excel (TSV) ou CSV.
 *
 * Colunas esperadas (cabeçalho, em qualquer ordem, sem exigir acento/caixa):
 *   AMBIENTES | INTERRUPÇÃO | CIRCUITOS | ACABAMENTOS | MEDIDAS
 *   QTD. TECLAS AUTOMAÇÃO | COMPRA PULSADORES | (coluna livre p/ observação)
 *
 * Regras vindas da planilha real:
 *  - Linha só com AMBIENTES e sem keypad = separador de pavimento/setor
 *    (ex.: "PAVIMENTO SUPERIOR") → vira `setor` das linhas seguintes.
 *  - Observação "LIGAR JUNTO KP01" → `ligar_junto = "KP01"`. Esses teclados têm
 *    0 teclas de automação: são paralelos do mestre e entram na MESMA entrada.
 *  - Linha sem keypad mas com teclas (ex.: "SENSOR GARAGEM") é mantida como item
 *    do estudo, sem código.
 */

export interface KeypadParsed {
  codigo: string | null
  ambiente: string | null
  setor: string | null
  acabamento: string | null
  medida: string | null
  teclas_automacao: number | null
  pulsadores_compra: number | null
  ligar_junto: string | null
  circuitos: string[]
  observacao: string | null
}

const norm = (s: string) =>
  s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim()

const numOrNull = (s: string): number | null => {
  const t = (s ?? "").trim()
  if (t === "") return null
  const n = Number(t.replace(",", "."))
  return Number.isFinite(n) ? n : null
}

/** Acha o índice da coluna cujo cabeçalho contém algum dos termos. */
function acharCol(cab: string[], termos: string[]): number {
  for (let i = 0; i < cab.length; i++) {
    const c = norm(cab[i])
    if (termos.some(t => c.includes(t))) return i
  }
  return -1
}

/** Detecta "LIGAR JUNTO KP01" em qualquer célula da linha. */
function acharLigarJunto(celulas: string[]): string | null {
  for (const c of celulas) {
    // aceita "JUNNTO" (erro de digitação real na planilha) e KP com/sem hífen
    const m = c.match(/lig\w*\s+jun\w*\s+(kp[-\s]?\d+)/i)
    if (m) return m[1].toUpperCase().replace(/[-\s]/g, "")
  }
  return null
}

export function parseEstudoTeclas(texto: string): KeypadParsed[] {
  const linhas = texto.replace(/\r/g, "").split("\n").filter(l => l.trim() !== "")
  if (linhas.length === 0) return []

  // TSV (cola do Excel) por padrão; cai para ";" ou "," se não houver tab.
  const sep = linhas[0].includes("\t") ? "\t" : linhas[0].includes(";") ? ";" : ","
  const split = (l: string) => l.split(sep).map(c => c.trim())

  // Primeira linha que parece cabeçalho
  let idxCab = linhas.findIndex(l => {
    const n = norm(l)
    return n.includes("ambiente") && (n.includes("interrup") || n.includes("keypad") || n.includes("tecla"))
  })
  if (idxCab < 0) idxCab = 0

  const cab = split(linhas[idxCab])
  const cAmb = acharCol(cab, ["ambiente"])
  const cKp = acharCol(cab, ["interrup", "keypad", "kp"])
  const cCirc = acharCol(cab, ["circuito"])
  const cAcab = acharCol(cab, ["acabamento"])
  const cMed = acharCol(cab, ["medida"])
  const cTec = acharCol(cab, ["tecla"])
  const cPuls = acharCol(cab, ["pulsador", "compra"])

  const out: KeypadParsed[] = []
  let setorAtual: string | null = null

  for (let i = idxCab + 1; i < linhas.length; i++) {
    const cel = split(linhas[i])
    const val = (idx: number) => (idx >= 0 && idx < cel.length ? cel[idx] : "")

    const ambiente = val(cAmb)
    const codigoRaw = val(cKp)
    const codigo = codigoRaw ? codigoRaw.toUpperCase().replace(/[-\s]/g, "") : ""

    const teclas = numOrNull(val(cTec))
    const pulsadores = numOrNull(val(cPuls))
    // Só o ambiente preenchido, sem mais nada → separador de pavimento/setor
    const soAmbiente = ambiente && !codigo && teclas === null && pulsadores === null &&
      !val(cAcab) && !val(cMed)
    if (soAmbiente) { setorAtual = ambiente; continue }

    // Linha vazia de conteúdo útil
    if (!ambiente && !codigo && teclas === null && pulsadores === null) continue

    // Observação = colunas fora das mapeadas (a planilha usa uma coluna livre)
    const mapeadas = new Set([cAmb, cKp, cCirc, cAcab, cMed, cTec, cPuls].filter(i => i >= 0))
    const extras = cel.filter((c, idx) => c && !mapeadas.has(idx))
    const ligarJunto = acharLigarJunto(extras.length ? extras : cel)
    const observacao = extras.join(" | ") || null

    out.push({
      codigo: codigo || null,
      ambiente: ambiente || null,
      setor: setorAtual,
      acabamento: val(cAcab) || null,
      medida: val(cMed) || null,
      teclas_automacao: teclas,
      pulsadores_compra: pulsadores,
      ligar_junto: ligarJunto,
      circuitos: val(cCirc) ? val(cCirc).split(/[;,/]+/).map(s => s.trim()).filter(Boolean) : [],
      observacao,
    })
  }

  return out
}
