import {
  servicoPorAmbiente,
  valorDoServico,
  type ItemParaServico,
  type ServicoProposta,
} from "@/lib/servicos-proposta"

/**
 * Os blocos que o cliente escolhe na proposta.
 *
 * Cada sistema é um bloco com o seu valor. Projeto e instalação deixou de ser
 * uma linha de "composição do valor" no rodapé e virou bloco também: é assim
 * que ele é vendido e é assim que o cliente decide sobre ele — junto dos
 * outros, com nome e preço à frente, e podendo ficar de fora.
 *
 * O cálculo mora aqui porque três telas mostram o mesmo número (o link do
 * cliente, a via interna e o painel da proposta) e uma conta por tela é como
 * uma delas passa a mentir sem ninguém ver.
 */

/** Id do bloco virtual. Não existe no banco: ele não é um Environment. */
export const BLOCO_SERVICO = "__servico__"

/* Um nome só, nas duas pontas: "Serviços". O bloco já se chamava assim nas
   telas internas, e ter dois nomes para o mesmo bloco obrigava a traduzir de
   cabeça toda vez que a conversa passava do painel para o documento. */
export const NOME_BLOCO_SERVICO = "Serviços"

export interface BlocoProposta {
  id: string
  nome: string
  /** Produtos do sistema; no bloco de serviço, a soma dos serviços. */
  valor: number
  servico: boolean
  /** O que o bloco de serviço cobre, para listar dentro dele. */
  itens?: { nome: string; valor: number }[]
}

export interface AmbienteBloco {
  id: string
  nome?: string | null
}

const nomeDoServico = (s: ServicoProposta) => s.nome?.trim() || NOME_BLOCO_SERVICO

/**
 * Sistemas (só produtos) mais o bloco de projeto e instalação, quando há
 * serviço. Sistema sem produto não vira bloco: o cliente não escolhe o vazio.
 */
export function blocosDaProposta(
  ambientes: AmbienteBloco[],
  itens: ItemParaServico[],
  servicos: ServicoProposta[],
  /* O serviço TOTAL gravado na proposta (`valor_servico`).

     Proposta montada antes de instalação e administração entrarem na
     composição guarda esses dois só aqui, sem nome: a lista detalhada soma
     menos que o gravado, e a diferença sumia do bloco — o cliente via os
     sistemas somando abaixo do total, e a conta parecia errada. O que falta
     entra como uma linha só, com nome, em vez de virar um buraco. */
  totalGravado?: number,
): BlocoProposta[] {
  const blocos: BlocoProposta[] = ambientes
    .map(a => ({
      id: a.id,
      nome: a.nome?.trim() || "Sistema",
      valor: itens.filter(i => i.environmentId === a.id).reduce((s, i) => s + i.valor_total, 0),
      servico: false,
    }))
    .filter(b => itens.some(i => i.environmentId === b.id))

  const detalhe: { nome: string; valor: number }[] = servicos
    .map(s => ({ nome: nomeDoServico(s), valor: valorDoServico(s, itens) }))
    .filter(s => s.valor > 0)

  const somaDetalhe = detalhe.reduce((s, d) => s + d.valor, 0)
  const gravado = Number(totalGravado ?? 0)
  const faltando = gravado - somaDetalhe
  // Um centavo de folga: percentual sobre centavos não fecha exato.
  if (faltando > 0.01) detalhe.push({ nome: NOME_BLOCO_SERVICO, valor: faltando })

  const total = detalhe.reduce((s, d) => s + d.valor, 0)
  if (total > 0) {
    blocos.push({
      id: BLOCO_SERVICO,
      nome: NOME_BLOCO_SERVICO,
      valor: total,
      servico: true,
      itens: detalhe,
    })
  }
  return blocos
}

/**
 * Quanto de projeto e instalação sobra com a escolha do cliente.
 *
 * Serviço preso a um sistema que ficou de fora sai junto com ele; percentual
 * recalcula sobre a base que restou. Mesma regra do que o servidor grava no
 * aceite (`aplicarEscolhaDeSistemas`) — o valor que ele vê é o que ele paga.
 */
export function servicoDaEscolha(
  servicos: ServicoProposta[],
  itens: ItemParaServico[],
  ambientes: string[],
  escolhidos: string[],
): number {
  if (!escolhidos.includes(BLOCO_SERVICO)) return 0
  const porAmbiente = servicoPorAmbiente(servicos, itens, ambientes)
  return ambientes
    .filter(id => escolhidos.includes(id))
    .reduce((s, id) => s + (porAmbiente.get(id) ?? 0), 0)
}

/** O valor de cada bloco já refletindo a escolha (serviço encolhe junto). */
export function blocosComEscolha(
  blocos: BlocoProposta[],
  servicos: ServicoProposta[],
  itens: ItemParaServico[],
  escolhidos: string[],
): BlocoProposta[] {
  const ambientes = blocos.filter(b => !b.servico).map(b => b.id)
  return blocos.map(b =>
    b.servico
      ? { ...b, valor: servicoDaEscolha(servicos, itens, ambientes, [...escolhidos, BLOCO_SERVICO]) }
      : b)
}
