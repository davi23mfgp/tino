import { brl as brlEmail } from "@/lib/formato"
/**
 * Templates de e-mail (HTML inline, compatível com Outlook/Gmail).
 *
 * Tudo em tabela e style inline de propósito: cliente de e-mail ignora
 * <style> externo, flexbox e grid.
 *
 * `layoutEmail` é a moldura única — cartão branco centralizado, tipografia e
 * assinatura. Cada e-mail entra só com o próprio miolo. Antes o convite era
 * caprichado e os demais eram <p> solto, então chegavam como se fossem de
 * sistemas diferentes.
 */

/** Escapa o que vem do banco antes de entrar no HTML. */
function esc(v: string): string {
  return v
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;")
}

const PERFIL_LABEL: Record<string, string> = {
  ADMIN: "Administrador",
  VENDEDOR: "Vendedor",
  RESPONSAVEL_TECNICO: "Responsável Técnico",
  ENGENHEIRO_PROJETOS: "Engenheiro de Projetos",
  INSTALADOR: "Instalador",
  FINANCEIRO: "Financeiro",
}

const AZUL = "#0670DB"
const FONTE = "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', sans-serif"

interface Assinatura {
  nome?: string | null
  cargo?: string | null
  emailContato?: string | null
  site?: string | null
}

interface LayoutArgs {
  /** Texto do preview na caixa de entrada (antes de abrir). */
  preheader: string
  titulo: string
  /** Miolo já em HTML — quem chama monta os parágrafos. */
  corpo: string
  assinatura?: Assinatura
  /** Fecho acima da assinatura. Alguns e-mails não pedem. */
  despedida?: string | null
}

/** Botão principal — mesma pílula azul em todos os e-mails. */
export function botaoEmail(href: string, texto: string): string {
  return `<p style="margin:0;padding:0;font-size:16px;padding-bottom:32px;text-align:center;">
                      <a href="${esc(href)}" target="_blank"
                        style="background-color:${AZUL};color:#ffffff;text-decoration:none;padding:14px 32px;border-radius:6px;font-weight:bold;display:inline-block;font-size:16px;">${esc(texto)}</a>
                    </p>`
}

/** Link em texto, para quando o botão não abre em alguns clientes. */
export function linkAlternativo(href: string): string {
  const h = esc(href)
  return `<p style="margin:0;padding:0;font-size:14px;padding-bottom:16px;color:#6b7280;line-height:1.5;">
                      Caso o botão não funcione, copie e cole o endereço abaixo em seu navegador:<br />
                      <a href="${h}" style="color:${AZUL};text-decoration:underline;word-break:break-all;">${h}</a>
                    </p>`
}

/**
 * Caixa de destaque do corpo.
 *
 * Era âmbar, com borda laranja: parecia alerta de erro no meio de um e-mail de
 * agradecimento. Agora é um bloco neutro com um fio da cor da marca à esquerda,
 * que destaca sem gritar.
 */
export function avisoEmail(html: string): string {
  return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"
                      style="background:#f8fafc;border-left:3px solid ${AZUL};border-radius:6px;margin-bottom:32px;">
                      <tbody><tr><td style="padding:16px 20px;">
                        <p style="margin:0;padding:0;font-size:14px;line-height:1.65;color:#475569;">${html}</p>
                      </td></tr></tbody>
                    </table>`
}

/** Parágrafo padrão do corpo. */
export function pEmail(html: string, espaco = 16): string {
  return `<p style="margin:0;padding:0;font-size:16px;padding-bottom:${espaco}px;color:#4b5563;">${html}</p>`
}

/**
 * O logo da casa, no topo de todo e-mail.
 *
 * Precisa de endereço absoluto: dentro do e-mail não existe "a raiz do site".
 * Sem APP_URL configurada a linha some, em vez de ir um quadrado quebrado. A
 * maioria dos clientes de e-mail bloqueia imagem até o leitor liberar, então o
 * alt carrega o nome da empresa.
 */
function cabecalhoLogo(): string {
  const base = (process.env.APP_URL || process.env.NEXT_PUBLIC_APP_URL || "").replace(/\/+$/, "")
  if (!base) return ""
  return `<tr>
                  <td style="padding:0 0 28px 0;">
                    <img src="${base}/brand/logo-completo.png" alt="Controllares"
                      height="30" style="height:30px;width:auto;display:block;border:0;outline:none;" />
                  </td>
                </tr>`
}

export function layoutEmail(a: LayoutArgs): string {
  const nome = a.assinatura?.nome ? esc(a.assinatura.nome) : null
  const cargo = a.assinatura?.cargo?.trim() ? esc(a.assinatura.cargo.trim()) : null
  const contato = a.assinatura?.emailContato?.trim() ? esc(a.assinatura.emailContato.trim()) : null
  const site = a.assinatura?.site?.trim() ? esc(a.assinatura.site.trim().replace(/^https?:\/\//, "")) : null

  const rodape = nome
    ? `<hr style="border:none;border-top:1px solid #e5e7eb;margin-bottom:24px;" />
${a.despedida ? `                    <p style="margin:0;padding:0;font-size:16px;padding-bottom:8px;color:#374151;">${a.despedida}</p>
                    <p style="margin:0;padding:0;font-size:16px;color:#374151;">Atenciosamente,</p>` : ""}

                    <p style="margin:0;padding:0;font-size:16px;padding-top:${a.despedida ? 24 : 0}px;color:#111827;">
                      <strong>${nome}</strong>${cargo ? `<br /><span style="font-size:14px;color:#4b5563;">${cargo}</span>` : ""}
                    </p>
${contato || site ? `                    <p style="margin:0;padding:0;font-size:14px;padding-top:8px;">
${contato ? `                      <a href="mailto:${contato}" style="color:${AZUL};text-decoration:none;">${contato}</a>${site ? "<br />" : ""}` : ""}
${site ? `                      <a href="https://${site}" target="_blank" style="color:${AZUL};text-decoration:none;">${site}</a>` : ""}
                    </p>` : ""}`
    : ""

  return `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html dir="ltr" lang="pt-BR">
  <head>
    <meta content="width=device-width" name="viewport" />
    <meta content="text/html; charset=UTF-8" http-equiv="Content-Type" />
    <meta name="x-apple-disable-message-reformatting" />
    <meta content="IE=edge" http-equiv="X-UA-Compatible" />
    <meta content="telephone=no,address=no,email=no,date=no,url=no" name="format-detection" />
    <title>${esc(a.titulo)}</title>
  </head>
  <body dir="ltr" lang="pt-BR" style="margin:0;padding:0;background-color:#f9fafb;">
    <div style="display:none;overflow:hidden;line-height:1px;opacity:0;max-height:0;max-width:0" data-skip-in-text="true">
      ${esc(a.preheader)}
    </div>
    <table border="0" width="100%" cellpadding="0" cellspacing="0" role="presentation" align="center">
      <tbody>
        <tr>
          <td dir="ltr" style="margin:0;padding:40px 20px;font-family:${FONTE};font-size:1em;min-height:100%;line-height:155%;color:#333333;">
            <table align="center" width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation"
              style="max-width:600px;width:100%;background-color:#ffffff;border:1px solid #e8eaed;border-radius:14px;padding:44px 44px 36px;">
              <tbody>
${cabecalhoLogo()}
                <tr style="width:100%">
                  <td style="padding:0px;">
${a.corpo}
${rodape}
                  </td>
                </tr>
              </tbody>
            </table>
            <!-- Assinatura da casa embaixo do cartão, como num papel timbrado. -->
            <p style="max-width:600px;margin:18px auto 0;text-align:center;font-size:12px;color:#9aa1ab;">
              Controllares · Automação e Home Cinema
            </p>
          </td>
        </tr>
      </tbody>
    </table>
  </body>
</html>`
}

// ─── 1. Convite de acesso ────────────────────────────────────────────────────

interface ConviteArgs {
  nomeColaborador?: string | null
  perfil: string
  link: string
  empresa: string
  remetenteNome?: string | null
  remetenteCargo?: string | null
  emailContato?: string | null
  site?: string | null
}

export function emailConvite(a: ConviteArgs): { subject: string; html: string } {
  const empresa = esc(a.empresa)
  const perfil = esc(PERFIL_LABEL[a.perfil] ?? a.perfil)
  const saudacao = a.nomeColaborador?.trim()
    ? `<strong>Prezado(a) </strong><code style="padding:4px 8px;background:#e5e7eb;color:#1e293b;border-radius:4px;">${esc(a.nomeColaborador.trim())}</code><strong>,</strong>`
    : `<strong>Olá,</strong>`

  const corpo = `                    <p style="margin:0;padding:0;font-size:16px;padding-bottom:16px;">${saudacao}</p>

                    ${pEmail(`Você foi convidado(a) para ingressar no sistema de gestão da <strong>${empresa}</strong> com o perfil de acesso <code style="padding:4px 8px;background:#e5e7eb;color:#1e293b;border-radius:4px;">${perfil}</code>.`)}

                    ${pEmail("Para ativar sua conta e definir suas credenciais de segurança, clique no botão abaixo. Ao criar sua senha, você será direcionado(a) automaticamente para o painel principal, com todas as suas permissões já configuradas.", 32)}
${a.perfil === "ADMIN" ? `
                    ${avisoEmail(`<strong>Você assume a administração da conta.</strong><br />
                          Ao aceitar, você passa a ser a pessoa administradora da ${empresa} — quem administrava
                          antes continua com acesso, mas com perfil de Vendedor. Todo o conteúdo já cadastrado
                          (propostas, obras, catálogo) permanece disponível.`)}` : ""}

                    ${botaoEmail(a.link, "CRIAR MINHA SENHA E ACESSAR")}

                    ${linkAlternativo(a.link)}

                    <p style="margin:0;padding:0;font-size:14px;padding-bottom:32px;color:#6b7280;line-height:1.5;">
                      Por questões de segurança, este link é de uso único e possui validade limitada. Se você não estava
                      aguardando este convite ou desconhece o remetente, desconsidere esta mensagem.
                    </p>
`

  const html = layoutEmail({
    preheader: "Ative sua conta e acesse o sistema de gestão agora mesmo.",
    titulo: "Ative sua conta e acesse o sistema de gestão.",
    corpo,
    despedida: "Desejamos um excelente trabalho e muito sucesso.",
    assinatura: {
      nome: a.remetenteNome?.trim() || a.empresa,
      cargo: a.remetenteCargo,
      emailContato: a.emailContato,
      site: a.site,
    },
  })

  return { subject: `Convite de Acesso – Plataforma ${a.empresa}`, html }
}

// ─── 2. Recuperação de senha ─────────────────────────────────────────────────

interface RecuperacaoArgs {
  nome?: string | null
  link: string
  empresa?: string | null
}

export function emailRecuperacaoSenha(a: RecuperacaoArgs): { subject: string; html: string } {
  const empresa = a.empresa?.trim() || "Sistema Controllares"

  const corpo = `                    <p style="margin:0;padding:0;font-size:16px;padding-bottom:16px;"><strong>Olá${a.nome?.trim() ? `, ${esc(a.nome.trim())}` : ""},</strong></p>

                    ${pEmail("Recebemos um pedido para redefinir a senha da sua conta. Clique no botão abaixo para criar uma nova.", 32)}

                    ${botaoEmail(a.link, "CRIAR NOVA SENHA")}

                    ${linkAlternativo(a.link)}

                    <p style="margin:0;padding:0;font-size:14px;padding-bottom:32px;color:#6b7280;line-height:1.5;">
                      O link vale por <strong>1 hora</strong> e só pode ser usado uma vez. Se você não pediu a
                      troca, ignore esta mensagem — sua senha continua a mesma e nada foi alterado.
                    </p>
`

  return {
    subject: `Redefinir sua senha – ${empresa}`,
    html: layoutEmail({
      preheader: "Link para criar uma nova senha. Vale por 1 hora.",
      titulo: "Redefinir sua senha",
      corpo,
      assinatura: { nome: empresa },
    }),
  }
}

// ─── 3. Aviso ao Admin: cadastro aguardando aprovação ────────────────────────

interface AprovacaoArgs {
  /** Quem se cadastrou. */
  nomePessoa: string
  emailPessoa: string
  empresa: string
  /** Só no cadastro de empresa nova. */
  cnpjCpf?: string | null
  /** Página onde aprovar. */
  link: string
  /** Google entra por outro caminho; muda só o texto. */
  viaGoogle?: boolean
}

export function emailAguardandoAprovacao(a: AprovacaoArgs): { subject: string; html: string } {
  const pessoa = esc(a.nomePessoa)
  const emailPessoa = esc(a.emailPessoa)
  const empresa = esc(a.empresa)

  const linha = a.cnpjCpf
    ? `<strong>${empresa}</strong> · ${esc(a.cnpjCpf)}<br />Administrador: ${pessoa} (${emailPessoa})`
    : `<strong>${pessoa}</strong> (${emailPessoa})<br />Empresa: ${empresa}`

  const contexto = a.cnpjCpf
    ? "Uma nova empresa se cadastrou na plataforma e aguarda sua autorização."
    : `${pessoa} se cadastrou${a.viaGoogle ? " usando a conta Google" : ""} e aguarda sua aprovação para acessar o sistema.`

  const corpo = `                    <p style="margin:0;padding:0;font-size:16px;padding-bottom:16px;"><strong>Olá,</strong></p>

                    ${pEmail(contexto, 24)}

                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"
                      style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;margin-bottom:32px;">
                      <tbody><tr><td style="padding:16px 18px;">
                        <p style="margin:0;padding:0;font-size:15px;line-height:1.6;color:#1e293b;">${linha}</p>
                      </td></tr></tbody>
                    </table>

                    ${pEmail(a.cnpjCpf ? "Aprove o cadastro para liberar o acesso." : "Aprove o cadastro e escolha o perfil de acesso.", 32)}

                    ${botaoEmail(a.link, a.cnpjCpf ? "REVISAR CADASTRO" : "APROVAR E DEFINIR PERFIL")}

                    ${linkAlternativo(a.link)}

                    <p style="margin:0;padding:0;font-size:14px;padding-bottom:32px;color:#6b7280;line-height:1.5;">
                      Enquanto não for aprovado, este cadastro não tem acesso a nenhum dado do sistema.
                    </p>
`

  return {
    subject: a.cnpjCpf
      ? `Nova empresa aguardando aprovação — ${a.empresa}`
      : `Novo cadastro aguardando aprovação — ${a.nomePessoa}`,
    html: layoutEmail({
      preheader: contexto,
      titulo: "Cadastro aguardando aprovação",
      corpo,
      assinatura: { nome: "Sistema Controllares" },
    }),
  }
}

// ─── 4. Proposta enviada ao cliente ──────────────────────────────────────────

interface PropostaArgs {
  nomeCliente: string
  numero: string
  valorTotal: number
  validade?: Date | string | null
  link: string
  empresa: string
  consultor?: { nome: string; email: string; telefone?: string | null } | null
}

export function emailProposta(a: PropostaArgs): { subject: string; html: string } {
  const cliente = esc(a.nomeCliente)
  const empresa = esc(a.empresa)
  const validade = a.validade ? new Date(a.validade).toLocaleDateString("pt-BR") : null

  const corpo = `                    <p style="margin:0;padding:0;font-size:16px;padding-bottom:16px;"><strong>Olá, ${cliente},</strong></p>

                    ${pEmail(`Sua proposta <strong>${esc(a.numero)}</strong> está pronta. Abra pelo botão abaixo para ver os sistemas, os itens e as condições de pagamento.`, 24)}

${validade ? `                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"
                      style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;margin-bottom:32px;">
                      <tbody><tr><td style="padding:16px 18px;">
                        <p style="margin:0;padding:0;font-size:14px;color:#6b7280;">Este link fica disponível até</p>
                        <p style="margin:0;padding:0;font-size:20px;font-weight:bold;color:#111827;">${validade}</p>
                      </td></tr></tbody>
                    </table>` : ""}

                    ${botaoEmail(a.link, "VER MINHA PROPOSTA")}

                    ${linkAlternativo(a.link)}

                    ${pEmail("No fim do documento você pode aceitar, pedir ajustes ou recusar.", 32)}
                    ${pEmail("Ao abrir, confirme seu e-mail e digite o código que enviaremos. A proposta é confidencial, e o link sozinho não dá acesso a mais ninguém.", 32)}
`

  return {
    subject: `Sua proposta ${a.numero} · ${a.empresa}`,
    html: layoutEmail({
      preheader: `Sua proposta ${a.numero} está pronta.`,
      titulo: `Proposta ${a.numero}`,
      corpo,
      despedida: "Ficamos à disposição para qualquer dúvida.",
      assinatura: a.consultor
        ? { nome: a.consultor.nome, cargo: "Consultor responsável", emailContato: a.consultor.email }
        : { nome: empresa },
    }),
  }
}

// ─── 5. Contrato enviado ao cliente ──────────────────────────────────────────

interface ContratoArgs {
  nomeCliente: string
  numero: string
  empresa: string
  link?: string | null
  consultor?: { nome: string; email: string } | null
}

/**
 * O contrato ia por fora — alguém salvava o PDF e anexava no próprio e-mail.
 * Assim ninguém sabia se tinha sido enviado nem quando, que é justamente a
 * informação que falta quando o cliente demora a assinar.
 */
export function emailContrato(a: ContratoArgs): { subject: string; html: string } {
  const cliente = esc(a.nomeCliente)
  const corpo = `                    <p style="margin:0;padding:0;font-size:16px;padding-bottom:16px;"><strong>Olá, ${cliente},</strong></p>

                    ${pEmail(`Segue o contrato referente à proposta <strong>${esc(a.numero)}</strong>, com as condições que combinamos.`, 24)}

                    ${a.link ? botaoEmail(a.link, "ABRIR O CONTRATO") + linkAlternativo(a.link) : ""}

                    ${pEmail("Confira os dados e, estando tudo certo, devolva o documento assinado. Qualquer ajuste, é só responder este e-mail.", 32)}
`
  return {
    subject: `Contrato da proposta ${esc(a.numero)}`,
    html: layoutEmail({
      preheader: `Contrato da proposta ${a.numero} para assinatura.`,
      titulo: "Contrato para assinatura",
      corpo,
      despedida: "Ficamos no aguardo.",
      assinatura: a.consultor
        ? { nome: a.consultor.nome, cargo: "Consultor responsável", emailContato: a.consultor.email }
        : { nome: esc(a.empresa) },
    }),
  }
}

// ─── 5b. Relatório da obra ────────────────────────────────────────────────

interface RelatorioObraArgs {
  clientName: string
  etapa: string | null
  progresso: number
  link?: string | null
  respTecnico?: { nome: string; email: string } | null
  empresa: string
}

/**
 * Envio manual do relatório da obra — mesmo botão "Enviar agora" que o
 * contrato, com o mesmo motivo: quem recebe fora do sistema (dono da
 * construtora, arquiteto) precisa de um retrato do andamento sem entrar no
 * painel, e antes isso só existia como print de tela mandado por WhatsApp.
 */
export function emailRelatorioObra(a: RelatorioObraArgs): { subject: string; html: string } {
  const cliente = esc(a.clientName)
  const corpo = `                    <p style="margin:0;padding:0;font-size:16px;padding-bottom:16px;"><strong>Olá,</strong></p>

                    ${pEmail(`Segue o andamento da obra de <strong>${cliente}</strong>.`, 20)}

                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 24px;">
                      <tr>
                        <td style="padding:14px 18px;background:#F5F7FA;border-radius:12px;font-family:${FONTE};">
                          <p style="margin:0;font-size:13px;color:#5B6472;">Etapa atual</p>
                          <p style="margin:2px 0 12px;font-size:18px;font-weight:600;color:#1A1D21;">${esc(a.etapa || "Sem etapa definida")}</p>
                          <p style="margin:0;font-size:13px;color:#5B6472;">Progresso físico</p>
                          <p style="margin:2px 0 0;font-size:18px;font-weight:600;color:#1A1D21;">${a.progresso}%</p>
                        </td>
                      </tr>
                    </table>

                    ${a.link ? botaoEmail(a.link, "VER DETALHES") + linkAlternativo(a.link) : ""}

                    ${pEmail("Qualquer dúvida sobre o andamento, é só responder este e-mail.", 32)}
`
  return {
    subject: `Relatório de obra · ${esc(a.clientName)}`,
    html: layoutEmail({
      preheader: `Andamento da obra: ${a.etapa || "sem etapa definida"}, ${a.progresso}% concluído.`,
      titulo: "Relatório de obra",
      corpo,
      despedida: "Seguimos à disposição.",
      assinatura: a.respTecnico
        ? { nome: a.respTecnico.nome, cargo: "Responsável técnico", emailContato: a.respTecnico.email }
        : { nome: esc(a.empresa) },
    }),
  }
}

// ─── 5c. Conteúdo genérico da obra (Dimensionamento e o que mais surgir) ────

interface ConteudoObraArgs {
  titulo: string
  clientName: string
  /** HTML já pronto — o chamador monta (tabelas, listas, o que fizer sentido
   *  pro conteúdo). Não escapamos aqui: quem chama controla o próprio HTML,
   *  não é texto de formulário de cliente externo. */
  corpoHtml: string
  empresa: string
  respTecnico?: { nome: string; email: string } | null
  /** O conteúdo vai como anexo (PDF): a frase de abertura já diz isso. */
  emAnexo?: boolean
}

/**
 * Envelope genérico pra mandar qualquer informação útil da obra por e-mail —
 * o pedido foi literal: escolher O QUE mandar e pra qual e-mail, sem
 * disparo automático nenhum. Em vez de um template por tipo de conteúdo
 * (Dimensionamento hoje, o que mais precisar depois), este só empresta a
 * moldura da casa (cabeçalho, assinatura) pro HTML que o chamador já montou
 * — o Dimensionamento reaproveita literalmente o mesmo HTML que gera pro
 * botão "Imprimir / PDF", só que mandado de verdade em vez de abrir popup.
 */
export function emailConteudoObra(a: ConteudoObraArgs): { subject: string; html: string } {
  const cliente = esc(a.clientName)
  const corpo = `                    <p style="margin:0;padding:0;font-size:16px;padding-bottom:16px;"><strong>Olá,</strong></p>

                    ${pEmail(a.emAnexo
                      ? `Segue em anexo o ${esc(a.titulo).toLowerCase()} de cada item da obra de <strong>${cliente}</strong>.`
                      : `Segue ${esc(a.titulo).toLowerCase()} da obra de <strong>${cliente}</strong>.`, 20)}

                    ${a.corpoHtml}

                    ${pEmail("Qualquer dúvida, é só responder este e-mail.", 32)}
`
  return {
    subject: `${esc(a.titulo)} · ${esc(a.clientName)}`,
    html: layoutEmail({
      preheader: `${a.titulo} da obra de ${a.clientName}.`,
      titulo: a.titulo,
      corpo,
      despedida: "Seguimos à disposição.",
      assinatura: a.respTecnico
        ? { nome: a.respTecnico.nome, cargo: "Responsável técnico", emailContato: a.respTecnico.email }
        : { nome: esc(a.empresa) },
    }),
  }
}

// ─── 6. Aceite confirmado ao cliente ─────────────────────────────────────────

interface AceiteArgs {
  nomeCliente: string
  numero: string
  empresa: string
  consultor?: { nome: string; email: string } | null
  /** O que ele fechou. Com escolha parcial, é só o que ele levou. */
  sistemas?: string[]
  total?: number | null
  /** Link do documento, para ele reler o que aceitou. */
  link?: string | null
}

/** Lista para corpo de e-mail. Sem <ul>: cliente de e-mail come o recuo. */
function listaEmail(itens: string[]): string {
  return itens
    .map(i => `<p style="margin:0;padding:0 0 6px 0;font-size:15px;color:#111827;">• ${esc(i)}</p>`)
    .join("\n")
}



/**
 * Confirmação enviada logo após o aceite. Sem ela o cliente clica em "Aceitar"
 * e não recebe nada: fica sem comprovante de que a decisão chegou, e o silêncio
 * depois de fechar um contrato é onde nasce a desconfiança.
 *
 * Vai junto o que ele fechou. Numa proposta de vários sistemas ele pode ter
 * levado só parte, e este e-mail é o registro dessa escolha; sem a lista, o
 * comprovante não diz de que é.
 */
export function emailAceite(a: AceiteArgs): { subject: string; html: string } {
  const temLista = !!a.sistemas?.length
  const corpo = `                    <p style="margin:0;padding:0 0 16px 0;font-size:22px;font-weight:600;letter-spacing:-0.2px;color:#111827;">Obrigado pela confiança, ${esc(a.nomeCliente)}.</p>

                    ${pEmail(`Seu aceite da proposta <strong>${esc(a.numero)}</strong> foi registrado. É uma alegria ter você com a gente neste projeto.`, 20)}

${temLista ? `                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"
                      style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;margin-bottom:24px;">
                      <tbody><tr><td style="padding:16px 18px;">
                        <p style="margin:0;padding:0 0 10px 0;font-size:13px;color:#6b7280;">O que você fechou</p>
                        ${listaEmail(a.sistemas!)}
${a.total != null ? `                        <p style="margin:12px 0 0 0;padding:12px 0 0 0;border-top:1px solid #e5e7eb;font-size:18px;font-weight:bold;color:#111827;">${brlEmail(a.total)}</p>` : ""}
                      </td></tr></tbody>
                    </table>` : ""}
                    ${pEmail("Nossa equipe entra em contato para acertar os detalhes finais: condição de pagamento, prazos e a data de início. Qualquer dúvida até lá, é só responder este e-mail.", 24)}
${a.link ? `                    ${botaoEmail(a.link, "VER O QUE FOI ACEITO")}` : ""}
                    ${avisoEmail("Vale guardar este e-mail: ele é o registro do seu aceite.")}
`
  return {
    subject: `Aceite confirmado · Proposta ${esc(a.numero)}`,
    html: layoutEmail({
      preheader: `Recebemos o aceite da proposta ${a.numero}.`,
      titulo: "Aceite confirmado",
      corpo,
      despedida: "Em breve falamos com você.",
      assinatura: a.consultor
        ? { nome: a.consultor.nome, cargo: "Consultor responsável", emailContato: a.consultor.email }
        : { nome: esc(a.empresa) },
    }),
  }
}

// ─── 7. Revisão pedida pelo cliente ──────────────────────────────────────────

interface RespostaClienteArgs {
  nomeCliente: string
  numero: string
  empresa: string
  consultor?: { nome: string; email: string } | null
  /** O que ele quer rever. Vazio quando pediu revisão da proposta toda. */
  sistemas?: string[]
  /** O que ele escreveu no pedido. */
  mensagem?: string | null
}

/**
 * Aviso de que o pedido de revisão chegou.
 *
 * Antes o cliente pedia ajuste e não recebia nada: ficava sem saber se o pedido
 * saiu do navegador, e a espera por uma proposta nova começava no escuro.
 */
export function emailRevisao(a: RespostaClienteArgs): { subject: string; html: string } {
  const parcial = !!a.sistemas?.length
  const corpo = `                    <p style="margin:0;padding:0 0 16px 0;font-size:22px;font-weight:600;letter-spacing:-0.2px;color:#111827;">Recebemos seu pedido, ${esc(a.nomeCliente)}.</p>

                    ${pEmail(`Obrigado por dedicar um tempo à proposta <strong>${esc(a.numero)}</strong> e por nos dizer o que precisa mudar. Isso ajuda a chegar no projeto certo.`, 20)}

${parcial ? `                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"
                      style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;margin-bottom:24px;">
                      <tbody><tr><td style="padding:16px 18px;">
                        <p style="margin:0;padding:0 0 10px 0;font-size:13px;color:#6b7280;">O que vamos rever</p>
                        ${listaEmail(a.sistemas!)}
                      </td></tr></tbody>
                    </table>` : ""}
${a.mensagem?.trim() ? `                    ${avisoEmail(`Você escreveu: "${esc(a.mensagem.trim().slice(0, 600))}"`)}` : ""}
                    ${pEmail("Vamos ajustar e mandar o link atualizado para este mesmo e-mail.", 24)}
`
  return {
    subject: `Pedido de ajuste recebido · Proposta ${esc(a.numero)}`,
    html: layoutEmail({
      preheader: `Recebemos seu pedido de ajuste na proposta ${a.numero}.`,
      titulo: "Pedido de ajuste recebido",
      corpo,
      despedida: "Falamos com você em breve.",
      assinatura: a.consultor
        ? { nome: a.consultor.nome, cargo: "Consultor responsável", emailContato: a.consultor.email }
        : { nome: esc(a.empresa) },
    }),
  }
}

// ─── 8. Proposta recusada ────────────────────────────────────────────────────

/**
 * Agradecimento de quem disse não.
 *
 * Sem isto o cliente recusa e o contato termina no silêncio, como se a resposta
 * dele não tivesse chegado. Um "não" bem tratado é o que deixa a porta aberta
 * para a próxima obra.
 */
export function emailRecusa(a: RespostaClienteArgs): { subject: string; html: string } {
  const corpo = `                    <p style="margin:0;padding:0 0 16px 0;font-size:22px;font-weight:600;letter-spacing:-0.2px;color:#111827;">Obrigado pelo retorno, ${esc(a.nomeCliente)}.</p>

                    ${pEmail(`Registramos sua resposta sobre a proposta <strong>${esc(a.numero)}</strong>. Agradecemos de verdade o tempo que você dedicou a analisar o projeto com a gente.`, 20)}

${a.mensagem?.trim() ? `                    ${avisoEmail(`Você escreveu: "${esc(a.mensagem.trim().slice(0, 600))}"`)}` : ""}
`
  return {
    subject: `Obrigado pelo retorno · Proposta ${esc(a.numero)}`,
    html: layoutEmail({
      preheader: `Registramos sua resposta sobre a proposta ${a.numero}.`,
      titulo: "Obrigado pelo retorno",
      corpo,
      despedida: "Esperamos trabalhar com você numa próxima oportunidade.",
      assinatura: a.consultor
        ? { nome: a.consultor.nome, cargo: "Consultor responsável", emailContato: a.consultor.email }
        : { nome: esc(a.empresa) },
    }),
  }
}
