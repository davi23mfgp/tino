import { soDigitos, tipoDocumento } from "@/lib/documento"

/**
 * O que é "dado de faturamento completo" — uma definição só, dos dois lados.
 *
 * A regra morava dentro do componente de tela, e por isso só existia para quem
 * estava olhando o formulário: o servidor gerava contrato com documento em
 * branco sem reclamar. Aqui ela é código puro, sem React, e a mesma função
 * decide se o botão fica ativo e se a rota deixa passar.
 */

/** Os campos que compõem o cadastro do cliente para a nota e o contrato. */
export const CAMPOS_FATURAMENTO = [
  "fat_razao_social", "fat_documento", "fat_ie", "fat_email",
  "fat_cep", "fat_logradouro", "fat_numero", "fat_complemento",
  "fat_bairro", "fat_cidade", "fat_uf",
] as const

export type CampoFaturamento = (typeof CAMPOS_FATURAMENTO)[number]

type Fonte = Partial<Record<CampoFaturamento, string | null>> & {
  fat_nascimento?: Date | string | null
}

const texto = (v: unknown) => String(v ?? "").trim()

/**
 * O mínimo para a nota sair: quem é, documento válido, e onde fatura.
 *
 * Complemento e IE ficam de fora de propósito — endereço sem complemento
 * existe, e pessoa física não tem inscrição estadual. Exigi-los travaria o
 * contrato de um cliente cujo cadastro está, de fato, completo.
 */
export function faturamentoCompleto(d: Fonte): boolean {
  return (
    texto(d.fat_razao_social).length > 2 &&
    tipoDocumento(texto(d.fat_documento)) !== "INVALIDO" &&
    soDigitos(texto(d.fat_cep)).length === 8 &&
    texto(d.fat_logradouro) !== "" &&
    texto(d.fat_numero) !== "" &&
    texto(d.fat_cidade) !== "" &&
    texto(d.fat_uf) !== ""
  )
}

/**
 * O que falta, em português, para quem precisa resolver.
 *
 * "Dados incompletos" manda a pessoa conferir dez campos um a um. Dizer
 * "falta o CEP" resolve em dez segundos.
 */
export function faltaNoFaturamento(d: Fonte): string[] {
  const falta: string[] = []
  if (texto(d.fat_razao_social).length <= 2) falta.push("nome/razão social")
  const doc = texto(d.fat_documento)
  if (!doc) falta.push("CPF ou CNPJ")
  else if (tipoDocumento(doc) === "INVALIDO") falta.push("CPF/CNPJ válido")
  if (soDigitos(texto(d.fat_cep)).length !== 8) falta.push("CEP")
  if (!texto(d.fat_logradouro)) falta.push("logradouro")
  if (!texto(d.fat_numero)) falta.push("número")
  if (!texto(d.fat_cidade)) falta.push("cidade")
  if (!texto(d.fat_uf)) falta.push("UF")
  return falta
}
