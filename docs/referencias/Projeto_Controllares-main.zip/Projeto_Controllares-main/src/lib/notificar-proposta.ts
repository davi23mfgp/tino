import { prisma } from "@/lib/prisma"

/** Lê a lista de números extras; texto inválido não pode derrubar o aviso. */
function extras(json: string | null | undefined): { numero: string; apikey?: string; nome?: string }[] {
  if (!json) return []
  try {
    const v = JSON.parse(json)
    return Array.isArray(v) ? v.filter(x => x && typeof x.numero === "string") : []
  } catch { return [] }
}
import { after } from "next/server"
import { enviarWhatsAppEmLote, type DestinoWhatsApp } from "@/lib/whatsapp"
import { enviarMensagem as enviarTelegram } from "@/lib/telegram"
import { brl } from "@/lib/formato"

/**
 * Ponto único de notificação de propostas.
 *
 * Antes cada rota decidia sozinha se avisava — e só "proposta aberta" mandava
 * WhatsApp. Resultado: revisão solicitada, aceite e perda passavam batido.
 * Agora todo evento de status/resposta passa por aqui e dispara os dois canais:
 * a gaveta de notificações (webhookDebugLog) e o WhatsApp do responsável.
 */

export type EventoProposta =
  | "VISUALIZADA"
  | "ACEITA"
  | "REVISAO_SOLICITADA"
  | "ENVIADA"
  | "LIDA"
  | "EM_FATURAMENTO"
  | "EM_CONTRATO"
  | "CANCELADA"
  | "PROPOSTA_PERDIDA"

interface DadosProposta {
  id: string
  numero: string
  client_name: string
  companyId: string
  /** Dono da proposta: é ele que recebe o aviso, não a equipe de vendas toda. */
  vendedorId?: string | null
  /** Aceita Decimal do Prisma sem precisar converter em cada rota. */
  valor_total?: { toString(): string } | number | string | null
}


/**
 * Texto e rótulo por evento.
 *
 * Notificação boa responde três coisas em cinco segundos: O QUE aconteceu, EM
 * QUE negócio, e O QUE FAZER AGORA. As mensagens antigas respondiam as duas
 * primeiras e paravam — "Proposta enviada / PROP-2026-010 — Lead Teste" avisa
 * sem dizer o que se espera de quem leu, e aviso que não pede ação vira ruído
 * que a pessoa aprende a ignorar.
 *
 * Continuam curtas de propósito: isto chega no celular, entre uma visita e
 * outra. Título, referência, valor e uma linha de próximo passo. Nada de
 * parágrafo — quem precisa do detalhe abre a proposta.
 *
 * `extra` entra como linha final quando quem chamou tem contexto a acrescentar.
 */
function montar(evento: EventoProposta, p: DadosProposta, extra?: string) {
  const valor = p.valor_total != null ? brl(Number(p.valor_total.toString())) : null
  const ref = `${p.numero} · ${p.client_name}`
  /* O valor tem linha própria, e não colado na referência: é o número que a
     pessoa procura primeiro quando o aviso é de aceite. */
  const linhaValor = valor ? `
Valor: ${valor}` : ""
  /* Aviso sem caminho de volta obriga a pessoa a abrir o sistema e caçar a
     proposta na lista. O link cai direto no cartão dela, na etapa em que
     está agora. Sem APP_URL configurada não inventa host: some a linha. */
  const host = process.env.NEXT_PUBLIC_APP_URL ?? process.env.APP_URL ?? ""
  const linhaLink = host ? `
${host.replace(/\/$/, "")}/propostas/${p.id}` : ""

  const mapa: Record<EventoProposta, { titulo: string; texto: string; endpoint: string }> = {
    VISUALIZADA: {
      titulo: "Proposta visualizada",
      texto: `👀 *Proposta visualizada*
${ref}${linhaValor}
O cliente abriu o link agora. Bom momento para o contato.${linhaLink}`,
      endpoint: "internal/proposta-visualizada",
    },
    LIDA: {
      titulo: "Proposta lida",
      texto: `📖 *Proposta lida*
${ref}${linhaValor}
O cliente leu a proposta inteira.${linhaLink}`,
      endpoint: "internal/proposta-lida",
    },
    ENVIADA: {
      titulo: "Proposta enviada",
      texto: `📤 *Proposta enviada ao cliente*
${ref}${linhaValor}
Aguardando a resposta pelo link.${linhaLink}`,
      endpoint: "internal/proposta-enviada",
    },
    ACEITA: {
      titulo: "Proposta aceita",
      texto: `✅ *Proposta ACEITA*
${ref}${linhaValor}
Próximo passo: gerar o contrato.${linhaLink}`,
      endpoint: "internal/proposta-aceita",
    },
    REVISAO_SOLICITADA: {
      titulo: "Revisão solicitada",
      texto: `📝 *Revisão solicitada pelo cliente*
${ref}${linhaValor}
Ajuste o escopo e reenvie para aprovação.${linhaLink}`,
      endpoint: "internal/revisao-solicitada",
    },
    EM_FATURAMENTO: {
      titulo: "Proposta em faturamento",
      texto: `💰 *Liberada para faturamento*
${ref}${linhaValor}
Contrato assinado. Emitir a nota e o pedido.${linhaLink}`,
      endpoint: "internal/proposta-faturamento",
    },
    EM_CONTRATO: {
      titulo: "Proposta em contrato",
      texto: `📄 *Em contrato*
${ref}${linhaValor}
Gerar o documento e enviar para assinatura.${linhaLink}`,
      endpoint: "internal/proposta-contrato",
    },
    CANCELADA: {
      titulo: "Proposta cancelada",
      texto: `🚫 *Proposta cancelada*
${ref}${linhaValor}
Cancelada internamente. Sem ação pendente.`,
      endpoint: "internal/proposta-cancelada",
    },
    PROPOSTA_PERDIDA: {
      titulo: "Proposta perdida",
      texto: `❌ *Proposta perdida*
${ref}${linhaValor}
Registre o motivo para a análise de perdas.${linhaLink}`,
      endpoint: "internal/proposta-perdida",
    },
  }

  const base = mapa[evento]
  return { ...base, texto: extra ? `${base.texto}\n${extra}` : base.texto }
}

/**
 * Dispara notificação do evento. Nunca lança: falha de aviso não pode
 * derrubar aceite de proposta nem abertura de link.
 */
export async function notificarProposta(
  evento: EventoProposta,
  p: DadosProposta,
  opcoes?: { extra?: string; detalhe?: Record<string, unknown> },
): Promise<void> {
  const { titulo, texto, endpoint } = montar(evento, p, opcoes?.extra)

  try {
    await prisma.webhookDebugLog.create({
      data: {
        endpoint,
        payload_json: {
          proposalId: p.id,
          numero: p.numero,
          client_name: p.client_name,
          evento,
          /* Vai no aviso para a gaveta saber a quem ele pertence.

             Sem isto, "quem pode ver" só dava para responder por cargo, e
             vendedor não tem cargo próprio por proposta — ele tem ESTA
             proposta. O id aqui é o que separa "as minhas" de "as dos
             outros" na hora de listar. */
          vendedorId: p.vendedorId ?? null,
          ...(opcoes?.detalhe ?? {}),
        },
        http_status: 200,
        response_body: titulo,
        reenviado: false,
        companyId: p.companyId,
      },
    })
  } catch {
    // gaveta de notificações é best-effort
  }

  /* Telegram: o caminho gratuito e sem cota.

     O CallMeBot corta o número quando as mensagens grátis acabam — e responde
     "enviado" enquanto não envia. A Evolution resolve, mas exige servidor
     próprio. O bot do Telegram não tem cota, não cobra e entrega direto no
     celular de cada pessoa, uma conversa por vez.

     Vai em bloco separado do WhatsApp de propósito: são caminhos independentes
     e a falha de um não pode calar o outro. */
  /* O canal decide por onde o aviso sai. Ligar os dois faz a mesma pessoa
     receber duas vezes o mesmo aviso, e aviso repetido é o caminho mais curto
     para silenciar os dois. */
  const canal = await prisma.company
    .findUnique({ where: { id: p.companyId }, select: { canal_avisos: true } })
    .then(x => x?.canal_avisos ?? "TELEGRAM")
    .catch(() => "TELEGRAM")

  try {
    const token = canal === "WHATSAPP" ? null : await prisma.company
      .findUnique({ where: { id: p.companyId }, select: { telegram_bot_token: true } })
      .then(x => x?.telegram_bot_token ?? null)

    if (token) {
      const pessoas = await prisma.user.findMany({
        where: {
          companyId: p.companyId,
          notificar_telegram: true,
          telegram_chat_id: { not: null },
          OR: [
            { role: { in: ["ADMIN", "FINANCEIRO"] } },
            { roles: { hasSome: ["ADMIN", "FINANCEIRO"] } },
            ...(p.vendedorId ? [{ id: p.vendedorId }] : []),
          ],
        },
        select: { telegram_chat_id: true },
      })

      if (pessoas.length) {
        /* Individual, não em grupo: a mensagem chega na conversa de cada um.
           Em grupo, quem não é do assunto recebe tudo e em pouco tempo silencia
           a conversa — e junto com ela os avisos que importavam.

           Aqui pode ser em paralelo: a API do Telegram aguenta, e o limite dela
           é por chat, não por origem como no CallMeBot. */
        /* Os asteriscos do texto são negrito do WhatsApp. Enviados ao Telegram
           sem parse_mode aparecem crus; com parse_mode, um nome de cliente com
           underline ou colchete derruba a mensagem inteira por erro de sintaxe.
           Tirar é o que sempre chega legível. */
        const semMarcacao = texto.replace(/\*/g, "")
        const disparar = () => Promise.allSettled(
          pessoas.map(u => enviarTelegram(token, u.telegram_chat_id!, semMarcacao)))
        try { after(disparar) } catch { await disparar() }
      }
    }
  } catch {
    // aviso é aviso: não derruba o fluxo de negócio
  }

  if (canal === "TELEGRAM") return

  try {
    const c = await prisma.company.findUnique({
      where: { id: p.companyId },
      select: {
        whatsapp_numero: true, whatsapp_apikey: true, whatsapp_extras: true,
        notificar_equipe_whatsapp: true,
        evolution_url: true, evolution_instance: true, evolution_apikey: true,
      },
    })
    if (!c) return

    /* Quem recebe: o vendedor DAQUELA proposta, mais Admin e Financeiro.

       Antes ia para todo vendedor da empresa. Numa equipe com vários, cada um
       recebia o movimento das propostas dos outros — e aviso que não é seu vira
       ruído: em pouco tempo ninguém lê nenhum, inclusive os que importam.

       Admin e Financeiro continuam recebendo tudo porque é o trabalho deles:
       um responde pela empresa, o outro precisa saber o que vai virar nota.

       A Evolution API é da empresa e serve qualquer destino, então basta trocar
       o número. No CallMeBot a apikey é amarrada ao aparelho: sem a apikey da
       pessoa, o envio para o número dela seria recusado — por isso cada uma
       carrega a sua, e quem não tiver fica de fora sem quebrar o resto. */
    const temEvolution = !!(c.evolution_url && c.evolution_instance && c.evolution_apikey)

    /* A empresa pode desligar a equipe inteira.

       O número de cada pessoa vem do perfil dela, editável só por ela e
       invisível nas Integrações: sem esta chave, o admin via aviso saindo
       para um telefone que não conseguia nem enxergar nem desligar. */
    const equipe = c.notificar_equipe_whatsapp ? await prisma.user.findMany({
      where: {
        companyId: p.companyId,
        notificar_whatsapp: true,
        whatsapp_numero: { not: null },
        OR: [
          // Responde pela empresa e pelo faturamento: recebem todas.
          { role: { in: ["ADMIN", "FINANCEIRO"] } },
          { roles: { hasSome: ["ADMIN", "FINANCEIRO"] } },
          // O vendedor desta proposta, seja qual for o perfil dele.
          ...(p.vendedorId ? [{ id: p.vendedorId }] : []),
        ],
      },
      select: { nome: true, whatsapp_numero: true, whatsapp_apikey: true },
    }) : []

    const destinos: DestinoWhatsApp[] = []
    // Número da empresa continua recebendo: é o histórico de todo mundo.
    if (c.whatsapp_numero) {
      destinos.push({
        rotulo: "Número da empresa",
        numero: c.whatsapp_numero,
        apikey: c.whatsapp_apikey,
      })
    }

    /* Números extras cadastrados nas Integrações: recebem exatamente as mesmas
       notificações. Existem porque nem todo mundo que precisa saber tem
       usuário no sistema — o dono que acompanha de fora, o sócio, o técnico
       terceirizado. */
    for (const e of extras(c.whatsapp_extras)) {
      if (!temEvolution && !e.apikey) continue
      destinos.push({ rotulo: e.nome?.trim() || "Número extra", numero: e.numero, apikey: e.apikey })
    }
    for (const u of equipe) {
      if (!u.whatsapp_numero) continue
      if (!temEvolution && !u.whatsapp_apikey) continue
      destinos.push({ rotulo: u.nome ?? "Equipe", numero: u.whatsapp_numero, apikey: u.whatsapp_apikey })
    }
    if (!destinos.length) return

    /* A fila é sequencial e leva alguns segundos. Presa na resposta, ela
       atrasava justamente a abertura do link pelo cliente — que é o evento
       mais sensível a demora. `after` solta o envio depois da resposta e
       mantém a função viva até terminar; fora de um request (script, cron)
       ele não existe, e aí vale esperar mesmo. */
    const disparar = () => enviarWhatsAppEmLote(c, texto, destinos)
    try { after(disparar) } catch { await disparar() }
  } catch {
    // idem: WhatsApp é aviso, não regra de negócio
  }
}