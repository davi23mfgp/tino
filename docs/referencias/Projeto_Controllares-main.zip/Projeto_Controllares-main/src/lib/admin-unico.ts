import { prisma } from "@/lib/prisma"
import type { Prisma } from "@prisma/client"

/**
 * Regra: um ADMIN ativo por empresa.
 *
 * Quando alguém vira ADMIN, os admins anteriores da mesma empresa perdem o
 * perfil administrativo. É só troca de acesso: nenhuma proposta, obra ou
 * qualquer outro dado é apagado — o conteúdo pertence à empresa, não a quem
 * administra. O usuário rebaixado continua entrando no sistema com o perfil
 * que sobrar (ou como VENDEDOR, se ADMIN era o único que tinha).
 */

/** Para onde cai quem perde o ADMIN e não tem outro perfil sobrando. */
const PERFIL_PADRAO_APOS_REBAIXAR = "VENDEDOR" as const

export interface AdminRebaixado {
  id: string
  nome: string
  email: string
  novoPerfil: string
}

/**
 * Remove o perfil ADMIN dos demais usuários da empresa.
 * `exceto` é o id de quem está assumindo (não pode se rebaixar sozinho).
 * Recebe `tx` para participar da mesma transação de quem chamou, quando houver.
 */
export async function rebaixarOutrosAdmins(
  companyId: string,
  exceto: string,
  tx: Prisma.TransactionClient | typeof prisma = prisma,
): Promise<AdminRebaixado[]> {
  const anteriores = await tx.user.findMany({
    where: {
      companyId,
      id: { not: exceto },
      OR: [{ role: "ADMIN" }, { roles: { has: "ADMIN" } }],
    },
    select: { id: true, nome: true, email: true, role: true, roles: true },
  })

  const rebaixados: AdminRebaixado[] = []

  for (const u of anteriores) {
    const extras = u.roles.filter(r => r !== "ADMIN")
    // Se o principal era ADMIN, promove o primeiro extra a principal.
    // Sem extras, cai no perfil padrão — nunca fica sem nenhum acesso.
    const novoPrincipal = u.role === "ADMIN"
      ? (extras[0] ?? PERFIL_PADRAO_APOS_REBAIXAR)
      : u.role
    const novosExtras = extras.filter(r => r !== novoPrincipal)

    await tx.user.update({
      where: { id: u.id },
      data: { role: novoPrincipal, roles: novosExtras },
    })

    rebaixados.push({ id: u.id, nome: u.nome, email: u.email, novoPerfil: novoPrincipal })
  }

  return rebaixados
}

/** Registra no audit log quem perdeu o ADMIN e por causa de quem. */
export async function registrarRebaixamento(
  companyId: string,
  autorId: string,
  rebaixados: AdminRebaixado[],
): Promise<void> {
  if (!rebaixados.length) return
  const lista = rebaixados.map(r => `${r.nome} (${r.email}) → ${r.novoPerfil}`).join("; ")
  await prisma.aiAuditLog.create({
    data: {
      userId: autorId,
      companyId,
      tipo_acesso: "EDITAR",
      descricao: `Novo Admin assumiu. Perfil administrativo removido de: ${lista}. Nenhum dado foi apagado.`,
    },
  }).catch(() => {})
}
