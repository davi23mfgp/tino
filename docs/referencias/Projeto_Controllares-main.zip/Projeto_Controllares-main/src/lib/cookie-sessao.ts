/**
 * Nome do cookie de sessão.
 *
 * Houve um par legado aqui (`flowdeal_token` / `flowdeal_2fa`), do tempo em
 * que o sistema tinha outro nome. Ele existia para não derrubar quem estava
 * logado no deploy do rename — inclusive no meio de uma proposta.
 *
 * Saiu porque a conta fecha: o rename foi em 10/08/2026 e o token vale 7 dias
 * (`setExpirationTime("7d")` em `auth.ts`). O último cookie antigo válido
 * morreu em 17/08. Continuar lendo aquele nome não mantinha ninguém logado,
 * só dava a impressão de que mantinha.
 *
 * Se um cookie velho ainda estiver parado no navegador de alguém, ele é
 * ignorado: o JWT dentro está expirado e `verifyToken` recusa de qualquer
 * jeito. A pessoa cai no login, que é o certo.
 */
export const COOKIE_SESSAO = "controllares_token"
export const COOKIE_2FA = "controllares_2fa"

type Leitor = { get(nome: string): { value: string } | undefined }

export function lerCookieSessao(jar: Leitor): string | undefined {
  return jar.get(COOKIE_SESSAO)?.value
}

export function lerCookie2fa(jar: Leitor): string | undefined {
  return jar.get(COOKIE_2FA)?.value
}
