/**
 * Envio de e-mail via Resend (HTTP puro, sem SDK).
 * No-op silencioso quando RESEND_API_KEY não está configurada.
 */
export async function enviarEmail(opts: {
  to: string[]; subject: string; html: string
  /** Anexos em base64 (sem o prefixo data:), no formato do Resend. */
  attachments?: { filename: string; content: string }[]
}): Promise<boolean> {
  if (!process.env.RESEND_API_KEY || opts.to.length === 0) return false
  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: process.env.RESEND_FROM || "Controllares <onboarding@resend.dev>",
        to: opts.to,
        subject: opts.subject,
        html: opts.html,
        ...(opts.attachments?.length ? { attachments: opts.attachments } : {}),
      }),
    })
    return r.ok
  } catch {
    return false
  }
}
