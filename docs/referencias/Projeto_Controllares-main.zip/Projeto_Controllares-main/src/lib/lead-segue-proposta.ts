import { prisma } from "@/lib/prisma"
import { rotuloEtapa } from "@/lib/etapas-lead"

/**
 * O lead acompanha o estado das propostas dele, sozinho.
 *
 * O funil parava em "Proposta Enviada" para sempre. O cliente aceitava pelo
 * link, a proposta virava contrato e depois obra, e o cartão continuava lá —
 * porque mover o lead dependia de alguém lembrar de arrastar, e ninguém
 * lembra. Um funil que precisa de manutenção manual vira retrato de um mês
 * atrás, e aí ninguém confia mais nele.
 *
 * A regra é de mão única: a PROPOSTA manda no lead. O contrário faria arrastar
 * um cartão mudar o estado de um documento assinado.
 *
 * E manda nos dois sentidos. A primeira versão só andava para frente, para
 * proteger um "Ganho" marcado na mão; o efeito foi um cartão em "Proposta
 * Enviada" com a proposta de volta em Rascunho, dois lugares do sistema
 * afirmando coisas diferentes sobre o mesmo negócio. Entre respeitar um
 * arrasto antigo e dizer a verdade, o funil tem de dizer a verdade.
 *
 * O estado não sai da proposta que acabou de mudar, e sim da MAIS ADIANTADA
 * entre todas as propostas do lead. Com duas propostas abertas — uma aceita,
 * outra em rascunho —, seguir a última mexida faria o cartão pular de Ganho
 * para Criação de Proposta a cada edição do rascunho. A mais adiantada é
 * estável: só muda quando o negócio realmente anda.
 */
const MAPA: Record<string, string> = {
  RASCUNHO: "ELABORANDO_PROPOSTA",
  ENVIADA: "PROPOSTA_ENVIADA",
  LIDA: "PROPOSTA_ENVIADA",
  EM_REVISAO: "PROPOSTA_ENVIADA",
  ACEITA: "GANHO",
  EM_CONTRATO: "GANHO",
  EM_FATURAMENTO: "GANHO",
  CONCLUIDA: "GANHO",
  PROPOSTA_PERDIDA: "PERDIDO",
  CANCELADA: "PERDIDO",
}

/** Posição da etapa no funil. Serve para não voltar o cartão sem motivo. */
const ORDEM = [
  "NOVO", "CONTATADO", "QUALIFICADO", "ELABORANDO_PROPOSTA",
  "PROPOSTA_ENVIADA", "GANHO",
]

export async function leadSegueProposta(
  proposalId: string,
  statusProposta: string,
  autorNome = "Sistema",
) {
  try {
    const proposta = await prisma.proposal.findUnique({
      where: { id: proposalId },
      select: { companyId: true, numero: true, leadId: true, leadProjetoId: true },
    })
    if (!proposta?.leadId) return

    const lead = await prisma.lead.findUnique({
      where: { id: proposta.leadId },
      select: { id: true, status: true },
    })
    if (!lead) return

    /* Lead com 2+ projetos: cada um tem seu próprio cartão no funil, então o
       projeto DESTA proposta segue ela sozinho — não a mais adiantada entre
       todos os projetos do lead, que é o que o resto desta função calcula
       para o Lead.status. Um projeto pode ganhar enquanto outro ainda nem
       tem proposta; eles não podem puxar um ao outro. */
    if (proposta.leadProjetoId) {
      const projeto = await prisma.leadProjeto.findUnique({
        where: { id: proposta.leadProjetoId },
        select: { id: true, status: true, nome: true },
      })
      if (projeto) {
        const irmasDoProjeto = await prisma.proposal.findMany({
          where: { leadProjetoId: proposta.leadProjetoId },
          select: { id: true, status: true },
        })
        const estadosProjeto = irmasDoProjeto.map(p => p.id === proposalId ? statusProposta : p.status)
        if (!estadosProjeto.includes(statusProposta)) estadosProjeto.push(statusProposta)
        const destinoProjeto = etapaMaisAdiantada(estadosProjeto)
        if (destinoProjeto && destinoProjeto !== projeto.status) {
          await prisma.leadProjeto.update({ where: { id: projeto.id }, data: { status: destinoProjeto } })
          await prisma.nota.create({
            data: {
              companyId: proposta.companyId, leadId: lead.id, etapa: destinoProjeto, tipo: "ETAPA",
              de: projeto.status, para: destinoProjeto,
              texto: `Projeto "${projeto.nome}": ${rotuloEtapa(projeto.status)} → ${rotuloEtapa(destinoProjeto)} pela proposta ${proposta.numero}.`,
              autorNome,
            },
          }).catch(() => {})
        }
      }
    }

    /* Todas as propostas do lead, com a que acabou de mudar já valendo o novo
       status: a transação de quem chamou pode ainda não ter sido gravada. */
    const irmas = await prisma.proposal.findMany({
      where: { leadId: lead.id },
      select: { id: true, status: true },
    })
    const estados = irmas.map(p => p.id === proposalId ? statusProposta : p.status)
    if (!estados.includes(statusProposta)) estados.push(statusProposta)

    const destino = etapaMaisAdiantada(estados)
    if (!destino || lead.status === destino) return

    await prisma.lead.update({ where: { id: lead.id }, data: { status: destino } })

    /* A mudança fica escrita na linha do tempo, com o número da proposta que a
       causou. Sem isso o cartão aparece em outra coluna e ninguém sabe por
       quê — o que é pior que não mover. */
    await prisma.nota.create({
      data: {
        companyId: proposta.companyId,
        leadId: lead.id,
        etapa: destino,
        tipo: "ETAPA",
        de: lead.status,
        para: destino,
        texto: `${rotuloEtapa(lead.status)} → ${rotuloEtapa(destino)} pela proposta ${proposta.numero}.`,
        autorNome,
      },
    }).catch(() => {})
  } catch {
    /* Nunca derruba quem chamou. Perder o acompanhamento custa um cartão fora
       de lugar; derrubar o aceite do cliente custa a venda. */
  }
}

/**
 * A etapa da proposta que foi mais longe.
 *
 * PERDIDO só vale quando TODAS acabaram mal: um lead com uma proposta recusada
 * e outra em andamento não está perdido — está em andamento.
 */
function etapaMaisAdiantada(statusPropostas: string[]): string | null {
  const etapas = statusPropostas.map(s => MAPA[s]).filter(Boolean)
  if (!etapas.length) return null

  const vivas = etapas.filter(e => e !== "PERDIDO")
  if (!vivas.length) return "PERDIDO"

  return vivas.reduce((melhor, e) =>
    ORDEM.indexOf(e) > ORDEM.indexOf(melhor) ? e : melhor)
}
