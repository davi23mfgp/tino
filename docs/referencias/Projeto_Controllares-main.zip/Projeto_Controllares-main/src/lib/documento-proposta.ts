import type { Prisma } from "@prisma/client"

/**
 * O que o documento da proposta precisa carregar.
 *
 * Duas rotas servem o mesmo documento: o link do cliente (`/api/p/[token]`) e
 * a via interna de impressão (`/api/propostas/[id]/documento`). Elas mudam em
 * quem pode abrir, não no que o papel mostra, então a consulta mora aqui. Com
 * uma cópia em cada lado, a que não fosse mexida imprimia um documento
 * diferente do outro.
 */
export const DOCUMENTO_PROPOSTA_INCLUDE = {
  environments: {
    /* O documento mostra só o que está sendo oferecido. Sistema GUARDADO é
       trabalho interno, montado para ficar na ficha e virar proposta depois;
       RECUSADO já levou um não. Nenhum dos dois entra no total. */
    where: { status: "ATIVO" },
    include: {
      proposalItems: {
        include: {
          product: true,
          category: true,
        },
      },
    },
  },
  installments: { orderBy: { numero_parcela: "asc" } },
  extraPages: { orderBy: { ordem: "asc" } },
  vendedor: { select: { nome: true, email: true, telefone: true } },
  company: {
    select: {
      // logo_proposta_url é o logo com o nome, escolhido só para documento.
      // Sem ele no select a página caía no logo_url e imprimia o símbolo.
      nome_empresa: true, logo_url: true, logo_proposta_url: true,
      endereco_base: true, cnpj_cpf: true,
      email_contato: true, telefone_contato: true, site: true, instagram: true,
    },
  },
} satisfies Prisma.ProposalInclude
