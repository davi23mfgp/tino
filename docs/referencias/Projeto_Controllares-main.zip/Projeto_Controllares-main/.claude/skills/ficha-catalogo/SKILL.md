---
name: ficha-catalogo
description: Padrão obrigatório para pesquisar e escrever ficha técnica de produto do catálogo FlowDeal (TI, áudio, vídeo, automação). Use ao pesquisar peso, dimensões, especificações, nome genérico, material, tipo de aplicação ou formato de qualquer SKU; ao montar lote de pesquisa para aprovação; ao conferir divergência apontada por outra ferramenta. Gatilhos: "ficha técnica", "pesquisar produto", "lote do catálogo", "peso e dimensão", "nome genérico", "especificações do SKU".
---

# Ficha de catálogo — padrão da casa

Uma ficha errada não é um campo errado: é um orçamento errado. Bitola de cabo,
peso de frete e medida de recorte saem daqui e chegam ao cliente com preço.
Por isso este padrão é fechado — não é sugestão de formato.

## As três regras que não se negociam

**1. Nunca invente. Procure, e se não achar, deixe como está.**

Nenhum campo é preenchido por dedução, por semelhança com outro modelo da linha
ou por conhecimento geral. Quando o datasheet não diz, o caminho é este, nesta
ordem:

1. **Procure.** Manual, guia de instalação, outra página do fabricante.
2. **Depois, fora do fabricante.** Loja, e-commerce, distribuidor, catálogo de
   revenda. Achou, registre o valor E a origem — anotando que não veio do
   fabricante, porque isso muda o quanto se confia nela.
3. **Não achou: deixe exatamente como está** e mande o SKU para a aba
   **"Em espera"**. Não aproxime, não converta, não complete, não reordene.

O campo em espera é uma pergunta em aberto, e uma pergunta em aberto é
informação. Um número inventado é o contrário: parece resposta, ninguém confere,
e vira orçamento errado.

Isto vale para o valor E para o rótulo. Já aconteceu aqui de rotularmos
"Altura / Largura / Comprimento" em cima de três números que a fonte publica sem
dizer qual é qual — os números estavam certos, a leitura era invenção, e o
resultado foi uma caixa deitada descrita como se estivesse em pé.

Uma busca que não achou também é resultado: escreva onde procurou, para a
próxima pessoa não repetir o caminho.

**2. Só toca no que foi autorizado.** Os campos desta pesquisa são, e são só
estes:

| Campo | Coluna |
|---|---|
| Nome genérico | `nome_cliente` |
| Especificações | `especificacoes` |
| Peso | `peso_kg` |
| Dimensões | `medidas_raw` |
| Tipo de aplicação | `tipo_aplicacao` |
| Formato | `formato_medida` |
| Fonte | `ficha_fonte_url` |

**Preço, custo, estoque, SKU, categoria e status nunca são alterados**, nem
para "corrigir" um valor que pareça errado. Se algo aí estiver errado, aponte
na coluna de observação e siga.

**E dentro desses campos, só o que está VAZIO é preenchido.** Ficha, nome
genérico, peso ou dimensão que já existem no catálogo não são reescritos,
reordenados nem "melhorados" — foram postos ali por alguém que conhece o
produto, e a pesquisa não tem como saber o que aquela pessoa sabia. A pesquisa
completa buraco; não revisa trabalho feito.

**Nada sobe sem aprovação da planilha.** Toda entrega passa por planilha, e a
gravação só acontece depois do "pode subir" explícito, lote a lote. Sem exceção,
nem para o campo mais óbvio, nem quando a fonte é o próprio fabricante.

**3. A marca UniFi é do dono do catálogo.** Ele escreve essas fichas à mão, e
é por isso que elas são a referência de formato do resto. Nenhum SKU UniFi entra
em lote de pesquisa nem em lote de revisão — nem os 001 a 061, que já estão
aprovados, nem os demais, que ele está escrevendo. Duas pessoas mexendo na mesma
ficha é retrabalho garantido para uma das duas.

## Fonte: o que vale e o que não vale

Nesta ordem, e só desta lista:

1. Datasheet ou spec sheet oficial do fabricante (PDF)
2. Página de especificações do site oficial (ex.: `techspecs.ui.com`)
3. Manual oficial do produto

**Não valem como fonte:** loja online, marketplace, revenda, blog, ficha de
distribuidor, resposta de outra IA, nem PDF hospedado por terceiro quando o
fabricante publica o dado. A URL exata da página consultada vai na ficha — não
o domínio, não a busca: a página.

Quando o dado só existe em PDF de integrador (caso da Absolute no Dropbox),
registre assim mesmo e marque na observação que a fonte não é do fabricante.
Link frágil documentado é melhor que dado sem origem.

## Peso e dimensão — onde quase todo erro nasce

**Só rotule o eixo quando a fonte disser qual é qual.** E as fontes divergem:
a Sonance escreve `(L × A × P)` — Largura, Altura, Profundidade. Outras usam
`W × D × H`. A Ubiquiti não escreve nada: publica `31.2 x 16 x 16 mm` e pronto.

Das fichas com três medidas, só uma em cada oito declara a ordem. Nas outras os
números vão como a fonte escreveu, juntos, com a ressalva na célula — e o eixo
fica em branco.

Isso já deu errado aqui: assumir "Comprimento × Largura × Altura" produziu uma
caixa com 34 cm de altura e 20 cm de comprimento, sendo que o produto é deitado.
Número certo no campo errado é o defeito que ninguém pega, porque a célula
parece preenchida. **Medida sem rótulo dá trabalho uma vez, na importação;
medida com rótulo errado dá prejuízo toda vez.**

**Duas unidades, cada uma no seu lugar.** Na ficha, milímetro:
`123 x 52 x 31 mm`. Nos campos de Largura, Altura e Comprimento do cadastro,
centímetro: `5.2`, `12.3`, `3.1` para esse mesmo produto. Peso em **g abaixo de
1 kg** e em **kg daí para cima**: `240 g`, `9,6 kg`. Decimal com vírgula na
ficha.

**Pacote com várias unidades: o peso e a medida são da UNIDADE.** O nome do
produto diz o conteúdo do pacote. Esta é a confusão mais comum e a mais cara —
um coupler Cat6A de 12 peças pesa 7,5 g cada, não 90 g.

**Peso de caixa não é peso de produto.** Datasheet costuma trazer os dois:
"Weight" (produto) e um peso de embalagem ou envio. Vale o do produto. Um
acessório de rack de 600 g virando 1,72 kg é sinal clássico de que alguém leu a
linha da caixa.

**Largura de rack não é largura do produto.** 482,6 mm é a medida do padrão
19", e aparece na ficha de qualquer coisa que monte em rack. Se a fonte diz
280,9 mm, o produto tem 280,9 mm.

**A medida é do produto nu.** Fabricante costuma publicar a dimensão com
ressalva no próprio valor — a McIntosh escreve `17-1/2" (44.45cm) (19" (48.3cm
with mounting ears))` e `4-5/16" (11cm) (including feet)`. No campo de dimensão
vai **sempre o número sem pés e sem orelhas de rack**: é ele que diz se a peça
cabe no vão, e é o único comparável entre fabricantes.

A ressalva não se perde — vai para as especificações, que é onde ela ajuda:
`Largura com orelhas de rack: 48,3 cm`. Assim quem monta o rack encontra o
número que precisa, e quem calcula o recorte não tropeça nele.

**Licença, software, serviço e assinatura não têm peso.** Peso e dimensão ficam
`N/A`, com a justificativa na observação. Nunca zero — zero é um número, e
alguém vai somá-lo.

**Fora esse caso, peso e dimensão são obrigatórios em todo produto.** São eles
que fecham frete e que dizem se a peça cabe no recorte. Não achou no
fabricante: o SKU vai para a aba "Sem dados do fabricante" com a busca
registrada, e alguém pede ao distribuidor. O que não existe é ficha entregue
como pronta faltando os dois.

## O dado tem de ser DAQUELE modelo

O erro mais silencioso da pesquisa não é o número trocado: é o número certo do
produto errado.

Acontece de três jeitos, os três já vistos aqui:

**Ficha do acessório trazendo dados do equipamento.** Uma bandeja de rack
descrita com "Interfaces: 1 porta RJ45, Alimentação: PoE, Consumo: 12,95 W" —
bandeja não tem porta de rede. Isso é a ficha da controladora que ela segura.

**Modelo irmão.** Mesma família, uma letra de diferença, e o datasheet aberto
é o do outro. O nome do modelo no topo da página tem de bater com o do SKU,
conferido caractere a caractere — não "parece que é".

**Página de família.** Uma URL que descreve a linha inteira, com uma tabela de
seis modelos. Copiar a coluna errada é o mais fácil que existe.

Antes de fechar a ficha, três perguntas: o modelo na fonte é exatamente este?
Os campos fazem sentido para este tipo de produto? A fonte é do fabricante?

## Nome genérico — o equilíbrio que define este campo

Ele serve a duas pessoas ao mesmo tempo, e é por isso que é difícil.

**Para quem vende, tem de lembrar o produto original.** Quem abre a proposta
precisa reconhecer qual item é aquele sem consultar o SKU. Um nome vago demais
— "Caixa acústica" — obriga a conferir o código a cada linha.

**Para quem compra, não pode encontrar o produto.** Se o cliente joga o nome no
Google e acha o modelo, ele acha o preço, e a proposta virou lista de compras
para levar ao concorrente.

O ponto de equilíbrio é descrever **o que a coisa é e faz**, com as
características que a distinguem, sem nenhum termo que sirva de chave de busca:

| Não | Por quê | Sim |
|---|---|---|
| Sonance VP66R | marca e modelo | Caixa acústica de embutir no teto 6,5" |
| Caixa Aria Evo X | linha comercial é pesquisável | Caixa acústica bookshelf 2 vias |
| Caixa acústica | não lembra qual é | Caixa acústica de embutir 6,5" com tweeter pivotante |
| Switch USW-Pro-24-PoE | código do fabricante | Switch 24 portas PoE gigabit gerenciável |

Fora: marca, código de modelo, nome de linha ou família comercial. Dentro:
tipo, formato, medida-chave, contagem, tecnologia e o diferencial visível.

A pergunta de teste é literal — **jogue o nome no Google.** Se o primeiro
resultado é o produto, o nome não passou.

## Especificações: o formato exato, sem interpretação

Este é o formato, copiado de uma ficha que o dono do catálogo escreveu e
aprovou. Não é referência a interpretar — é gabarito a reproduzir.

```
ESPECIFICAÇÕES TÉCNICAS:
- Saída de Vídeo: (1) Porta HDMI
- Resoluções de Vídeo Suportadas: 480p / 720p / 1080p / 4K
- Processador e GPU: CPU Octa-Core com (2) ARM® Cortex®-A78 e (6) ARM® Cortex®-A55, GPU Mali-G57 integrada
- Memória: 32 GB de armazenamento e 8 GB de RAM
- Interfaces de Rede e Conectividade: (1) Porta RJ45 GbE, Wi-Fi 6 (802.11 a/b/g/n/ac/ax - 2.4/5 GHz), porta USB-C para teclado/mouse ou alimentação opcional
- Método de Alimentação: (1) GbE RJ45 PoE 48V DC, 0.35A ou (1) USB Type-C 5V DC, 3A (UL 60950-1/62368-1 LPS/PS2 PSU)
- Interface Visual e Botões: LED indicador de status (Branco/Azul) e (1) Botão de reset de fábrica
- Montagem: Suporte para montagem em parede e poste (Diâmetro do poste: 1 a 2" / 25 a 50 mm)
- Software e Aplicação: Exige suporte no UniFi Application Suite (Connect)
- Ambiente de Operação: Temperatura de 0 a 40° C
- Dimensões: Sem suporte: 123 x 52 x 31 mm / Com suporte: 125,1 x 56,3 x 40,8 mm
- Peso: Sem suporte: 240 g / Com suporte: 260 g
```

### As sete regras que esse gabarito fixa

**1. A primeira linha é sempre `ESPECIFICAÇÕES TÉCNICAS:`**, sozinha, sem
bullet. Ficha que começa direto no primeiro campo está fora do padrão.

**2. Toda linha de campo abre com `- `** — hífen e um espaço. Não é enfeite: é
o que faz a ficha ficar legível dentro do campo de texto do formulário.

**3. `- Campo: Valor`, com o nome do campo em Maiúsculas de Título e em
português.** `Método de Alimentação`, não `método de alimentação` nem
`Power Method`. Sigla técnica fica como o fabricante escreve: PoE, RJ45, HDMI,
GbE, USB-C, MIMO, Wi-Fi.

**4. Nome de campo descritivo, não a palavra solta do datasheet.** A Ubiquiti
escreve `Power Method`; a ficha escreve `Método de Alimentação`. Escreve
`Interfaces de Rede e Conectividade`, não `Connectivity`. O nome do campo é
traduzido e completado para dizer o que ali está.

**5. Uma linha `- Dimensões:` e uma linha `- Peso:`**, nesta ordem, sempre as
duas últimas. **Não é uma linha por eixo.** Os três números vão juntos, em
milímetro, separados por ` x `.

**6. Quando o fabricante publica variante, as duas entram na mesma linha**,
separadas por ` / `, cada uma com seu rótulo:
`Sem suporte: 123 x 52 x 31 mm / Com suporte: 125,1 x 56,3 x 40,8 mm`. É o que
resolve a briga do produto nu contra o produto montado: as duas medidas
existem, e quem lê escolhe a que precisa. Vale igual para o peso.

**7. Sem linha em branco entre campos. Sem travessão. Sem texto corrido.**

### Os campos do formulário são outra coisa

Além das especificações, o produto tem `Largura`, `Altura` e `Comprimento` como
campos próprios do cadastro, **e esses são em centímetro**: o mesmo produto de
`123 x 52 x 31 mm` na ficha entra como Largura `5.2`, Altura `12.3`,
Comprimento `3.1`. O formato fica `Padrão (L × A × C)`.

Milímetro na ficha, centímetro nos campos. Os dois, sempre — a ficha é o que o
cliente lê, os campos são o que o sistema calcula.

### Nome exibido na proposta

Curto e sem modelo: `Player de Mídia`. Não `Player de Mídia Display Cast Pro`,
que devolve o produto no Google junto com o preço.

Material tem nome: "Aço SGCC", "alumínio extrudado", "ABS retardante de chama",
"cobre OFC 22 AWG". "Metal" e "plástico" não descrevem nada — não passam.

**Resuma.** A ficha da Ubiquiti tem sessenta linhas; a do catálogo tem doze.
Entra o que o vendedor usa para vender e o instalador para instalar.

## O que garante o formato: um script, não uma leitura

Instrução escrita se interpreta — três rodadas de pesquisa mostraram isso, cada
uma devolvendo um formato diferente do combinado. Por isso a ficha não é dada
como pronta pela leitura de quem escreveu: `scripts/validar-ficha.mts` confere
cada linha contra este gabarito, mecanicamente, e reprova o que não bate.

Toda ficha nova passa por ele antes de entrar na planilha de aprovação:

    npx tsx scripts/validar-ficha.mts

Reprovado não é "quase certo" — é fora do gabarito, e volta para reescrever.

## Entrega do lote

Planilha, para aprovação, **antes** de qualquer escrita no banco. Três abas:

- **Para aprovar** — SKU, nome no sistema, marca, nome genérico, especificações,
  peso e dimensões, fonte (URL), observação, lote
- **Sem fonte** — o que não foi achado, com onde se procurou
- **Sem dados do fabricante** — o que o fabricante não publica
- **Em espera** — o que ficou sem definição depois de procurar fora dele
  também. Vai com o dado original intacto e a busca registrada

Nada entra no sistema sem o "pode subir".

## Divergência apontada por outra ferramenta

Não corrija por autoridade — nem a nossa, nem a dela. Abra a fonte oficial e
leia o campo. Já aconteceu de outra IA apontar cinco erros e os cinco valores
dela estarem errados, tirados de peso de caixa e de largura de rack.

Registre a conferência: SKU, valor nosso, valor apontado, valor lido na fonte,
URL. Só então mude o que precisar mudar.
