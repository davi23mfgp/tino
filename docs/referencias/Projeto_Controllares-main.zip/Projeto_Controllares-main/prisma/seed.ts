// ============================================================
// Seed — popula o banco com dados de exemplo para testes
// Rode com: npm run prisma:seed
// ============================================================

import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import crypto from "crypto";

const prisma = new PrismaClient();

// --- Criptografia inline (espelha src/lib/crypto.ts) para o cofre ---
function getKey(): Buffer {
  const raw = process.env.ENCRYPTION_KEY || "chave-padrao-de-desenvolvimento";
  if (/^[0-9a-fA-F]{64}$/.test(raw)) return Buffer.from(raw, "hex");
  return crypto.createHash("sha256").update(raw).digest();
}
function encrypt(plainText: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", getKey(), iv);
  const enc = Buffer.concat([cipher.update(plainText, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [iv.toString("hex"), tag.toString("hex"), enc.toString("hex")].join(":");
}
function token(bytes = 24): string {
  return crypto.randomBytes(bytes).toString("hex");
}

async function main() {
  console.log("🌱 Iniciando seed...");

  // Limpa dados antigos (ordem respeita as FKs)
  await prisma.workPartner.deleteMany();
  await prisma.keypadEngraving.deleteMany();
  await prisma.ganttTask.deleteMany();
  await prisma.inspectionMedia.deleteMany();
  await prisma.technicalCredential.deleteMany();
  await prisma.maintenanceTicket.deleteMany();
  await prisma.projectStage.deleteMany();
  await prisma.financialTransaction.deleteMany();
  await prisma.extraPage.deleteMany();
  await prisma.installment.deleteMany();
  await prisma.proposalItem.deleteMany();
  await prisma.proposalVersion.deleteMany();
  await prisma.environment.deleteMany();
  await prisma.obra.deleteMany();
  await prisma.proposal.deleteMany();
  await prisma.kitItem.deleteMany();
  await prisma.kit.deleteMany();
  await prisma.catalogProduct.deleteMany();
  await prisma.category.deleteMany();
  await prisma.proposalTemplate.deleteMany();
  await prisma.partnerStakeholder.deleteMany();
  await prisma.webhookDebugLog.deleteMany();
  await prisma.user.deleteMany();
  await prisma.company.deleteMany();

  // 1) Empresa (tenant)
  const company = await prisma.company.create({
    data: {
      nome_empresa: "Controllares Automação",
      cnpj_cpf: "12.345.678/0001-90",
    },
  });
  console.log("✅ Empresa criada:", company.nome_empresa);

  // 2) Usuários (3 roles diferentes)
  const senhaHash = await bcrypt.hash("123456", 12);
  const admin = await prisma.user.create({
    data: { nome: "Davi Marques", email: "admin@controllares.com.br", senha: senhaHash, role: "ADMIN", companyId: company.id },
  });
  const vendedor = await prisma.user.create({
    data: { nome: "Carla Vendas", email: "vendedor@controllares.com.br", senha: senhaHash, role: "VENDEDOR", companyId: company.id },
  });
  const financeiro = await prisma.user.create({
    data: { nome: "Bruno Financeiro", email: "financeiro@controllares.com.br", senha: senhaHash, role: "FINANCEIRO", companyId: company.id },
  });
  console.log("✅ 3 usuários criados (senha de todos: 123456)");

  // 3) Categorias
  const [catAudio, catAutomacao, catRede] = await Promise.all([
    prisma.category.create({ data: { nome: "Áudio", companyId: company.id } }),
    prisma.category.create({ data: { nome: "Automação", companyId: company.id } }),
    prisma.category.create({ data: { nome: "Rede", companyId: company.id } }),
  ]);

  // 4) Produtos do catálogo
  const amplificador = await prisma.catalogProduct.create({
    data: { sku: "AUD-001", nome: "Amplificador Multiroom 8 Zonas", marca: "Sonos", preco_custo: 4200, markup_padrao: 40, preco_venda: 5880, companyId: company.id },
  });
  const caixa = await prisma.catalogProduct.create({
    data: { sku: "AUD-002", nome: "Caixa Embutir Teto 6'", marca: "JBL", preco_custo: 380, markup_padrao: 50, preco_venda: 570, companyId: company.id },
  });
  const central = await prisma.catalogProduct.create({
    data: { sku: "AUT-001", nome: "Central de Automação Pro", marca: "Control4", preco_custo: 8900, markup_padrao: 35, preco_venda: 12015, companyId: company.id },
  });
  const switchRede = await prisma.catalogProduct.create({
    data: { sku: "RDE-001", nome: "Switch Gerenciável 24 Portas", marca: "Ubiquiti", preco_custo: 1500, markup_padrao: 45, preco_venda: 2175, companyId: company.id },
  });
  console.log("✅ 4 produtos criados");

  // 5) Kit com itens
  const kit = await prisma.kit.create({
    data: {
      nome: "Kit Áudio Residencial Premium",
      descricao: "Amplificador + 4 caixas de teto",
      markup_global: 42,
      companyId: company.id,
      items: {
        create: [
          { productId: amplificador.id, quantidade: 1 },
          { productId: caixa.id, quantidade: 4 },
        ],
      },
    },
  });
  console.log("✅ Kit criado com itens");

  // 6) Proposta completa
  const proposal = await prisma.proposal.create({
    data: {
      numero: "PROP-2026-001",
      client_name: "Família Oliveira",
      client_email: "oliveira@email.com",
      client_city: "Belo Horizonte",
      project_type: "RESIDENCIAL",
      status: "ENVIADA",
      valor_total: 18765,
      data_expiracao: new Date(Date.now() + 1000 * 60 * 60 * 24 * 30),
      link_token: token(),
      vendedorId: vendedor.id,
      companyId: company.id,
    },
  });

  // Ambientes da proposta
  const sala = await prisma.environment.create({ data: { nome: "Sala de Estar", proposalId: proposal.id, companyId: company.id } });
  const homeTheater = await prisma.environment.create({ data: { nome: "Home Theater", proposalId: proposal.id, companyId: company.id } });

  // Itens da proposta
  await prisma.proposalItem.createMany({
    data: [
      { proposalId: proposal.id, kitId: kit.id, environmentId: sala.id, categoryId: catAudio.id, quantidade: 1, valor_unitario: 8160, valor_total: 8160 },
      { proposalId: proposal.id, productId: central.id, environmentId: homeTheater.id, categoryId: catAutomacao.id, quantidade: 1, valor_unitario: 12015, valor_total: 12015 },
      { proposalId: proposal.id, productId: switchRede.id, environmentId: homeTheater.id, categoryId: catRede.id, quantidade: 1, valor_unitario: 2175, valor_total: 2175, is_aditivo: true },
    ],
  });

  // Versão histórica
  await prisma.proposalVersion.create({
    data: { proposalId: proposal.id, numero_versao: 1, motivo_alteracao: "Versão inicial", valor_historico: 18765, snapshot_json: { itens: 3, ambientes: 2 } },
  });

  // Parcelas
  await prisma.installment.createMany({
    data: [
      { proposalId: proposal.id, numero_parcela: 1, valor: 9382.5, data_vencimento: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7), status: "PENDENTE" },
      { proposalId: proposal.id, numero_parcela: 2, valor: 9382.5, data_vencimento: new Date(Date.now() + 1000 * 60 * 60 * 24 * 37), status: "PENDENTE" },
    ],
  });

  // Página extra (contrato)
  await prisma.extraPage.create({
    data: { proposalId: proposal.id, titulo: "Termos de Garantia", conteudo_markdown: "## Garantia\n\nTodos os equipamentos possuem **2 anos** de garantia.", ordem: 1 },
  });
  console.log("✅ Proposta completa criada (ambientes, itens, versão, parcelas, página extra)");

  // 7) Obra gerada a partir da proposta (crossover)
  const obra = await prisma.obra.create({
    data: {
      companyId: company.id,
      client_name: "Família Oliveira",
      address: "Rua das Acácias, 123 - Belo Horizonte/MG",
      etapa: "Infraestrutura",
      logistics_status: "AGUARDANDO_EQUIPAMENTOS",
      physical_progress_percentage: 15,
      resp_tecnico_id: admin.id,
      resp_comercial_id: vendedor.id,
      originProposalId: proposal.id,
    },
  });
  // Vincula a proposta à obra (agregação)
  await prisma.proposal.update({ where: { id: proposal.id }, data: { obraId: obra.id } });

  // Cofre de credenciais CRIPTOGRAFADO
  await prisma.technicalCredential.create({
    data: {
      obraId: obra.id,
      tipo_equipamento: "Central Control4",
      login: "admin",
      senha_criptografada: encrypt("SenhaSuperSecreta@2026"),
      observacoes: "Acesso à central principal",
    },
  });

  // Lançamento financeiro
  const parcela1 = await prisma.installment.findFirst({ where: { proposalId: proposal.id, numero_parcela: 1 } });
  await prisma.financialTransaction.create({
    data: { proposalId: proposal.id, installmentId: parcela1?.id, valor: 9382.5, status: "PENDENTE", companyId: company.id, nota_fiscal_status: "NAO_EMITIDA" },
  });

  // Parceiro + vínculo com obra
  const parceiro = await prisma.partnerStakeholder.create({
    data: { name: "Arq. Patrícia Lima", type: "ARQUITETO", email: "patricia@arq.com", phone: "(31) 99999-0000", company_name: "Lima Arquitetura", companyId: company.id },
  });
  await prisma.workPartner.create({ data: { workId: obra.id, partnerId: parceiro.id } });
  console.log("✅ Obra criada com cofre criptografado, financeiro e parceiro vinculado");

  console.log("\n🎉 Seed concluído com sucesso!");
  console.log("👉 Login de teste: admin@controllares.com.br / senha: 123456");
}

main()
  .catch((e) => {
    console.error("❌ Erro no seed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
