ALTER TABLE "obras" ADD COLUMN "telegram_chat_id" TEXT;
ALTER TABLE "companies" ADD COLUMN "telegram_bot_token" TEXT;
