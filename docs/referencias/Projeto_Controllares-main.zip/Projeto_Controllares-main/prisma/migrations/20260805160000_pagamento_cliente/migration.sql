-- Formas oferecidas na proposta e registro de quem fechou a condição
ALTER TABLE "proposals" ADD COLUMN     "formas_oferecidas" TEXT,
ADD COLUMN     "pagamento_definido_em" TIMESTAMP(3),
ADD COLUMN     "pagamento_definido_por" TEXT;
