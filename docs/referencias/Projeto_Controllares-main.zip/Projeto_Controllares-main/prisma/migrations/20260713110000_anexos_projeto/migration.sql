ALTER TABLE "obras" ADD COLUMN "anexos_projeto" JSONB;
