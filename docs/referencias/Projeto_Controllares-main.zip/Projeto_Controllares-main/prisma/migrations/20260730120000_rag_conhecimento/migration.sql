-- pgvector: o tipo vector() precisa da extensão criada antes das tabelas.
CREATE EXTENSION IF NOT EXISTS vector;

-- CreateTable
CREATE TABLE "knowledge_docs" (
    "id" TEXT NOT NULL,
    "companyId" TEXT NOT NULL,
    "titulo" TEXT NOT NULL,
    "origem" TEXT NOT NULL DEFAULT 'UPLOAD',
    "arquivo_url" TEXT,
    "fonte" TEXT,
    "roles" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "tags" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "status" TEXT NOT NULL DEFAULT 'PENDENTE',
    "erro" TEXT,
    "chars" INTEGER NOT NULL DEFAULT 0,
    "criadoPor" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "knowledge_docs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "knowledge_chunks" (
    "id" TEXT NOT NULL,
    "docId" TEXT NOT NULL,
    "companyId" TEXT NOT NULL,
    "ordem" INTEGER NOT NULL,
    "texto" TEXT NOT NULL,
    "referencia" TEXT,
    "embedding" vector(1536),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "knowledge_chunks_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "knowledge_docs_companyId_status_idx" ON "knowledge_docs"("companyId", "status");

-- CreateIndex
CREATE INDEX "knowledge_chunks_companyId_idx" ON "knowledge_chunks"("companyId");

-- CreateIndex
CREATE INDEX "knowledge_chunks_docId_idx" ON "knowledge_chunks"("docId");

-- AddForeignKey
ALTER TABLE "knowledge_docs" ADD CONSTRAINT "knowledge_docs_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "knowledge_chunks" ADD CONSTRAINT "knowledge_chunks_docId_fkey" FOREIGN KEY ("docId") REFERENCES "knowledge_docs"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Índice de similaridade por cosseno. IVFFlat exige ANALYZE depois de carregar
-- dados; com poucos documentos o Postgres cai em varredura sequencial, que
-- ainda é rápida no volume esperado.
CREATE INDEX IF NOT EXISTS knowledge_chunks_embedding_idx
  ON "knowledge_chunks" USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
