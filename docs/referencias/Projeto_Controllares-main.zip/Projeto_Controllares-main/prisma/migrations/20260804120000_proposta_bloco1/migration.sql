-- Cabeçalho da proposta: site e Instagram da empresa
ALTER TABLE "companies" ADD COLUMN     "instagram" TEXT,
ADD COLUMN     "site" TEXT;

-- Entrada: existia só no formulário, nunca era gravada — por isso não aparecia no PDF
ALTER TABLE "proposals" ADD COLUMN     "valor_entrada" DECIMAL(12,2);

-- Assinatura do consultor no rodapé da proposta
ALTER TABLE "users" ADD COLUMN     "telefone" TEXT;
