ALTER TABLE "maintenance_tickets" ADD COLUMN "registro_notas" TEXT;
ALTER TABLE "maintenance_tickets" ADD COLUMN "checklist" JSONB;
ALTER TABLE "maintenance_tickets" ADD COLUMN "anexos" JSONB;
ALTER TABLE "obras" ADD COLUMN "checklist_tecnico" JSONB;
