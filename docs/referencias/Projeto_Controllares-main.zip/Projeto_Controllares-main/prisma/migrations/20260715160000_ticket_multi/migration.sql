ALTER TABLE "maintenance_tickets" ADD COLUMN "itens_usados" JSONB;
ALTER TABLE "maintenance_tickets" ADD COLUMN "data_agendada" TIMESTAMP(3);
