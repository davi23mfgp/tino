-- AlterTable
ALTER TABLE "companies" ADD COLUMN     "email_contato" TEXT,
ADD COLUMN     "telefone_contato" TEXT;

