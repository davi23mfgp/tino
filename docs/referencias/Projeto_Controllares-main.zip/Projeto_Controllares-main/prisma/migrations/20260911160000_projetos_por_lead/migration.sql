-- Vários projetos dentro do mesmo lead.
--
-- A mesma pessoa pode ter negócios independentes: a construtora com quatro
-- apartamentos, o cliente com a casa e a praia. Antes, cada um virava um lead
-- repetido — mesmo telefone e mesmo e-mail duplicados no funil — e a contagem
-- de leads passava a medir projetos, não pessoas.
--
-- Entidade magra de propósito. Não concorre com Obra: existe antes de haver
-- obra, enquanto ainda se decide o que fazer, e é a Obra que nasce quando a
-- proposta daquele projeto é aceita.
CREATE TABLE "lead_projetos" (
  "id"        TEXT NOT NULL,
  "leadId"    TEXT NOT NULL,
  "nome"      TEXT NOT NULL,
  "posicao"   INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "lead_projetos_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "lead_projetos_leadId_idx" ON "lead_projetos"("leadId");

-- Cascade: projeto não sobrevive ao cliente que o encomendou.
ALTER TABLE "lead_projetos"
  ADD CONSTRAINT "lead_projetos_leadId_fkey"
  FOREIGN KEY ("leadId") REFERENCES "leads"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Qual projeto a proposta atende. Anulável: cliente com um negócio só não
-- precisa inventar "Projeto 1", e toda proposta existente continua válida.
ALTER TABLE "proposals"
  ADD COLUMN "leadProjetoId" TEXT;

CREATE INDEX "proposals_leadProjetoId_idx" ON "proposals"("leadProjetoId");

-- SetNull e não Cascade: apagar o projeto não pode levar junto a proposta,
-- que é documento comercial e pode já ter sido enviada ao cliente.
ALTER TABLE "proposals"
  ADD CONSTRAINT "proposals_leadProjetoId_fkey"
  FOREIGN KEY ("leadProjetoId") REFERENCES "lead_projetos"("id") ON DELETE SET NULL ON UPDATE CASCADE;
