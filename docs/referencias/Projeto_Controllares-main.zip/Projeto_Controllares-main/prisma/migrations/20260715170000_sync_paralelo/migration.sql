-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "ProposalStatus" ADD VALUE 'EM_FATURAMENTO';
ALTER TYPE "ProposalStatus" ADD VALUE 'PROPOSTA_PERDIDA';

-- AlterTable
ALTER TABLE "proposal_items" ADD COLUMN     "dimensao_pronta" BOOLEAN NOT NULL DEFAULT false;

-- CreateTable
CREATE TABLE "proposal_view_events" (
    "id" TEXT NOT NULL,
    "proposalId" TEXT NOT NULL,
    "ip_address" TEXT,
    "user_agent" TEXT,
    "viewed_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "proposal_view_events_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "obra_item_dimensionamento" (
    "id" TEXT NOT NULL,
    "obraId" TEXT NOT NULL,
    "proposalItemId" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "nome_item" TEXT NOT NULL,
    "sku" TEXT,
    "ambiente" TEXT NOT NULL,
    "tipo_aplicacao" TEXT,
    "formato_medida" TEXT,
    "largura_mm" DOUBLE PRECISION,
    "altura_mm" DOUBLE PRECISION,
    "profundidade_mm" DOUBLE PRECISION,
    "valor_largura" DOUBLE PRECISION,
    "valor_altura" DOUBLE PRECISION,
    "valor_profundidade" DOUBLE PRECISION,
    "valor_diametro" DOUBLE PRECISION,
    "formato_selecionado" TEXT,
    "incluir_relatorio" BOOLEAN NOT NULL DEFAULT true,
    "notas_dimensionamento" TEXT,
    "criado_por" TEXT,
    "criado_em" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "atualizado_em" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "obra_item_dimensionamento_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "dimensioning_reports" (
    "id" TEXT NOT NULL,
    "obraId" TEXT NOT NULL,
    "titulo" TEXT NOT NULL,
    "gerado_em" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "gerado_por" TEXT,
    "url_pdf" TEXT,
    "status" TEXT NOT NULL DEFAULT 'GERADO',

    CONSTRAINT "dimensioning_reports_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "proposal_view_events_proposalId_idx" ON "proposal_view_events"("proposalId");

-- CreateIndex
CREATE INDEX "proposal_view_events_viewed_at_idx" ON "proposal_view_events"("viewed_at");

-- CreateIndex
CREATE INDEX "obra_item_dimensionamento_obraId_idx" ON "obra_item_dimensionamento"("obraId");

-- CreateIndex
CREATE INDEX "obra_item_dimensionamento_ambiente_idx" ON "obra_item_dimensionamento"("ambiente");

-- CreateIndex
CREATE INDEX "obra_item_dimensionamento_incluir_relatorio_idx" ON "obra_item_dimensionamento"("incluir_relatorio");

-- CreateIndex
CREATE INDEX "dimensioning_reports_obraId_idx" ON "dimensioning_reports"("obraId");

-- AddForeignKey
ALTER TABLE "proposal_view_events" ADD CONSTRAINT "proposal_view_events_proposalId_fkey" FOREIGN KEY ("proposalId") REFERENCES "proposals"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "obra_item_dimensionamento" ADD CONSTRAINT "obra_item_dimensionamento_obraId_fkey" FOREIGN KEY ("obraId") REFERENCES "obras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "dimensioning_reports" ADD CONSTRAINT "dimensioning_reports_obraId_fkey" FOREIGN KEY ("obraId") REFERENCES "obras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

