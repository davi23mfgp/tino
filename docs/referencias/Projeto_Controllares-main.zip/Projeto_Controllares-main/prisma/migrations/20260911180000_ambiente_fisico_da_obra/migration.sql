-- Ambiente físico da obra vira entidade, não texto livre por item.
--
-- A primeira versão (ambiente_obra, texto solto em cada proposal_item) durou
-- só uma sessão: o pedido real era ambiente como algo que se CRIA na obra
-- uma vez e se liga a vários produtos, não redigitado item a item. Como o
-- campo texto acabou de nascer, ainda sem dado real usando ele, a troca é
-- limpa: cai a coluna, entra a tabela + o vínculo.
CREATE TABLE "obra_ambientes" (
  "id"        TEXT NOT NULL,
  "obraId"    TEXT NOT NULL,
  "nome"      TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "obra_ambientes_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "obra_ambientes_obraId_idx" ON "obra_ambientes"("obraId");

-- Cascade: ambiente não sobrevive à obra apagada.
ALTER TABLE "obra_ambientes"
  ADD CONSTRAINT "obra_ambientes_obraId_fkey"
  FOREIGN KEY ("obraId") REFERENCES "obras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "proposal_items" DROP COLUMN IF EXISTS "ambiente_obra";

ALTER TABLE "proposal_items"
  ADD COLUMN "obraAmbienteId" TEXT;

CREATE INDEX "proposal_items_obraAmbienteId_idx" ON "proposal_items"("obraAmbienteId");

-- SetNull e não Cascade: apagar o ambiente devolve o produto pra fila de
-- "sem ambiente", nunca some o produto junto.
ALTER TABLE "proposal_items"
  ADD CONSTRAINT "proposal_items_obraAmbienteId_fkey"
  FOREIGN KEY ("obraAmbienteId") REFERENCES "obra_ambientes"("id") ON DELETE SET NULL ON UPDATE CASCADE;
