-- CreateTable ObraItemDimensionamento
CREATE TABLE "obra_item_dimensionamento" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "obraId" TEXT NOT NULL,
    "proposalItemId" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "nome_item" TEXT NOT NULL,
    "sku" TEXT,
    "ambiente" TEXT NOT NULL,
    -- Dimensões do produto
    "tipo_aplicacao" TEXT,
    "formato_medida" TEXT,
    "largura_mm" REAL,
    "altura_mm" REAL,
    "profundidade_mm" REAL,
    -- Entrada do usuário
    "valor_largura" REAL,
    "valor_altura" REAL,
    "valor_profundidade" REAL,
    "valor_diametro" REAL,
    "formato_selecionado" TEXT,
    -- Inclusão no relatório
    "incluir_relatorio" BOOLEAN NOT NULL DEFAULT true,
    "notas_dimensionamento" TEXT,
    "criado_por" TEXT,
    "criado_em" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "atualizado_em" DATETIME NOT NULL,
    CONSTRAINT "obra_item_dimensionamento_obraId_fkey" FOREIGN KEY ("obraId") REFERENCES "obras" ("id") ON DELETE CASCADE
);

-- CreateIndex
CREATE INDEX "obra_item_dimensionamento_obraId_idx" ON "obra_item_dimensionamento"("obraId");
CREATE INDEX "obra_item_dimensionamento_ambiente_idx" ON "obra_item_dimensionamento"("ambiente");

-- AddColumn para ProposalItem (se necessário para rastreamento)
ALTER TABLE "proposal_items" ADD COLUMN "dimensao_pronta" BOOLEAN NOT NULL DEFAULT false;
