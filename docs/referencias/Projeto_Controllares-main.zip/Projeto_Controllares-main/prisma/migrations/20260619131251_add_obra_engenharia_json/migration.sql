-- AlterTable
ALTER TABLE "obras" ADD COLUMN     "anexos" JSONB,
ADD COLUMN     "projetos_blueprints" JSONB,
ADD COLUMN     "quadros" JSONB;
