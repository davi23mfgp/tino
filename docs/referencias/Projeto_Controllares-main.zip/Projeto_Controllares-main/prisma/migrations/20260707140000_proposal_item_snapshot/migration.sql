ALTER TABLE "proposal_items" ADD COLUMN "nome_snapshot" TEXT;
ALTER TABLE "proposal_items" ADD COLUMN "sku_snapshot" TEXT;
