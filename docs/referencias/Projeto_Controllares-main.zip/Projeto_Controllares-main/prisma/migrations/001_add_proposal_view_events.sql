-- CreateTable ProposalViewEvent
CREATE TABLE "proposal_view_events" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "proposalId" TEXT NOT NULL,
    "ip_address" TEXT,
    "user_agent" TEXT,
    "viewed_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "proposal_view_events_proposalId_fkey" FOREIGN KEY ("proposalId") REFERENCES "proposals" ("id") ON DELETE CASCADE
);

-- CreateIndex
CREATE INDEX "proposal_view_events_proposalId_idx" ON "proposal_view_events"("proposalId");
