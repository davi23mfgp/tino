-- AlterTable
ALTER TABLE "obras" ADD COLUMN     "dimensionamento" JSONB;
