-- CreateEnum
CREATE TYPE "OlistSyncType" AS ENUM ('CONTAS_RECEBER', 'CONTAS_PAGAR', 'NOTAS_FISCAIS');

-- CreateEnum
CREATE TYPE "OlistSyncStatus" AS ENUM ('SUCESSO', 'ERRO', 'SINCRONIZANDO');

-- AlterTable
ALTER TABLE "companies" ADD COLUMN     "olist_access_token" TEXT,
ADD COLUMN     "olist_cache_notas" JSONB,
ADD COLUMN     "olist_cache_pagar" JSONB,
ADD COLUMN     "olist_cache_receber" JSONB,
ADD COLUMN     "olist_refresh_token" TEXT,
ADD COLUMN     "olist_token_expiry" TIMESTAMP(3);

-- CreateTable
CREATE TABLE "olist_sync_logs" (
    "id" TEXT NOT NULL,
    "tipo" "OlistSyncType" NOT NULL,
    "status" "OlistSyncStatus" NOT NULL,
    "detalhes_erro" TEXT,
    "ultima_sync_em" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "companyId" TEXT NOT NULL,

    CONSTRAINT "olist_sync_logs_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "olist_sync_logs_companyId_idx" ON "olist_sync_logs"("companyId");

-- CreateIndex
CREATE INDEX "olist_sync_logs_tipo_idx" ON "olist_sync_logs"("tipo");

-- AddForeignKey
ALTER TABLE "olist_sync_logs" ADD CONSTRAINT "olist_sync_logs_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;
