-- Garantia do produto em dias (mesma unidade da proposta)
ALTER TABLE "catalog_products" ADD COLUMN     "garantia_dias" INTEGER;

-- Converte o que já estava em meses (30 dias por mês) para não perder o cadastro
UPDATE "catalog_products"
   SET "garantia_dias" = "garantia_meses" * 30
 WHERE "garantia_meses" IS NOT NULL AND "garantia_dias" IS NULL;
