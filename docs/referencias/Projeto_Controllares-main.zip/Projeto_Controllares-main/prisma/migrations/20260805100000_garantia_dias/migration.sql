-- Garantia em dias (anos_garantia fica para o histórico das propostas antigas)
ALTER TABLE "proposals" ADD COLUMN     "dias_garantia" INTEGER;

-- Marco do início da garantia: gravado quando a obra entra em "Em instalação"
ALTER TABLE "obras" ADD COLUMN     "data_inicio_garantia" TIMESTAMP(3);
