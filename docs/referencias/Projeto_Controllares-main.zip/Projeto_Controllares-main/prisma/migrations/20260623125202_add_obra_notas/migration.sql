-- AlterTable
ALTER TABLE "obras" ADD COLUMN     "notas" TEXT;
