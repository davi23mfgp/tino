-- AlterTable
ALTER TABLE "stock_inventories" ADD COLUMN     "tipo" TEXT NOT NULL DEFAULT 'PERIODICA';

