-- AlterTable
ALTER TABLE "catalog_products" ADD COLUMN     "especificacoes" TEXT,
ADD COLUMN     "garantia_meses" INTEGER;

