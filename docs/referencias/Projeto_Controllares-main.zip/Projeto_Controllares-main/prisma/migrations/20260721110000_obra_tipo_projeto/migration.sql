-- AlterTable
ALTER TABLE "obras" ADD COLUMN     "tipo_projeto" TEXT NOT NULL DEFAULT 'OBRA';

