-- AlterTable
ALTER TABLE "companies" ADD COLUMN     "google_client_id" TEXT,
ADD COLUMN     "google_client_secret" TEXT,
ADD COLUMN     "tiny_api_token" TEXT;

-- AlterTable
ALTER TABLE "users" ADD COLUMN     "google_access_token" TEXT,
ADD COLUMN     "google_refresh_token" TEXT,
ADD COLUMN     "google_token_expiry" TIMESTAMP(3);
