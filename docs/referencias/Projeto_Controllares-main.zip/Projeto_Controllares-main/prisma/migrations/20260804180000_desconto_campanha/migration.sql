ALTER TABLE "proposals" ADD COLUMN     "desconto_campanha" DECIMAL(12,2);
