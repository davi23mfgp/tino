-- CreateTable
CREATE TABLE "ai_audit_logs" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "tipo_acesso" TEXT NOT NULL,
    "descricao" TEXT NOT NULL,
    "obraId" TEXT,
    "proposalId" TEXT,
    "companyId" TEXT NOT NULL,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ai_audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ai_rate_limits" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "mensagens_hora" INTEGER NOT NULL DEFAULT 0,
    "janela_inicio" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "tentativas_senha" INTEGER NOT NULL DEFAULT 0,
    "bloqueado_ate" TIMESTAMP(3),
    "companyId" TEXT NOT NULL,

    CONSTRAINT "ai_rate_limits_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "ai_audit_logs_userId_idx" ON "ai_audit_logs"("userId");

-- CreateIndex
CREATE INDEX "ai_audit_logs_companyId_idx" ON "ai_audit_logs"("companyId");

-- CreateIndex
CREATE UNIQUE INDEX "ai_rate_limits_userId_key" ON "ai_rate_limits"("userId");

-- AddForeignKey
ALTER TABLE "ai_audit_logs" ADD CONSTRAINT "ai_audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ai_rate_limits" ADD CONSTRAINT "ai_rate_limits_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
