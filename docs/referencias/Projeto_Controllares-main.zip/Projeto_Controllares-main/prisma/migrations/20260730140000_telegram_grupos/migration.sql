-- CreateTable
CREATE TABLE "telegram_grupos" (
    "id" TEXT NOT NULL,
    "companyId" TEXT NOT NULL,
    "chatId" TEXT NOT NULL,
    "titulo" TEXT NOT NULL,
    "obraId" TEXT,
    "automatico" BOOLEAN NOT NULL DEFAULT false,
    "ativo" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "telegram_grupos_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "telegram_grupos_companyId_ativo_idx" ON "telegram_grupos"("companyId", "ativo");

-- CreateIndex
CREATE UNIQUE INDEX "telegram_grupos_companyId_chatId_key" ON "telegram_grupos"("companyId", "chatId");

-- AddForeignKey
ALTER TABLE "telegram_grupos" ADD CONSTRAINT "telegram_grupos_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "telegram_grupos" ADD CONSTRAINT "telegram_grupos_obraId_fkey" FOREIGN KEY ("obraId") REFERENCES "obras"("id") ON DELETE SET NULL ON UPDATE CASCADE;
