-- O serviço da categoria que CADA proposta embutiu no preço dos seus produtos:
-- [{categoryId, servicos:[{nome,tipo,valor}]}].
--
-- Nulo nas propostas existentes, e é o certo: elas embutiram o que a categoria
-- tinha cadastrado, e é por ele que continuam sendo lidas.
--
-- IF NOT EXISTS porque esta coluna pode já ter sido criada à mão durante o
-- incidente em que o schema andou na frente do banco. Rodar de novo não pode
-- derrubar o deploy.
ALTER TABLE "proposals" ADD COLUMN IF NOT EXISTS "servicos_categoria" JSONB;
