-- AlterTable
ALTER TABLE "proposals" ADD COLUMN     "credito_st" DOUBLE PRECISION NOT NULL DEFAULT 0;
