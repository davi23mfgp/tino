-- CreateTable
CREATE TABLE "automacao_pontos" (
    "id" TEXT NOT NULL,
    "obraId" TEXT NOT NULL,
    "tipo" TEXT NOT NULL,
    "codigo" TEXT,
    "ambiente" TEXT,
    "setor" TEXT,
    "equipamento" TEXT,
    "descricao" TEXT,
    "porta" TEXT,
    "ip" TEXT,
    "observacao" TEXT,
    "extras" JSONB,
    "ordem" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "automacao_pontos_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "automacao_pontos_obraId_tipo_idx" ON "automacao_pontos"("obraId", "tipo");

-- AddForeignKey
ALTER TABLE "automacao_pontos" ADD CONSTRAINT "automacao_pontos_obraId_fkey" FOREIGN KEY ("obraId") REFERENCES "obras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

