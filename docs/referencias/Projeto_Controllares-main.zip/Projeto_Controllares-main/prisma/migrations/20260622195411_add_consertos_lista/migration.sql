-- AlterTable
ALTER TABLE "obras" ADD COLUMN     "consertos_lista" JSONB;
