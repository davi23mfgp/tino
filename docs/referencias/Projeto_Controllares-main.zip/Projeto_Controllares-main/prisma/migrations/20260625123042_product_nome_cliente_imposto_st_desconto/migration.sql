-- AlterTable
ALTER TABLE "catalog_products" ADD COLUMN     "desconto_padrao" DOUBLE PRECISION NOT NULL DEFAULT 0,
ADD COLUMN     "imposto_st" DOUBLE PRECISION NOT NULL DEFAULT 0,
ADD COLUMN     "nome_cliente" TEXT;
