-- CreateEnum
CREATE TYPE "TarefaPrioridade" AS ENUM ('BAIXA', 'MEDIA', 'ALTA');

-- CreateTable
CREATE TABLE "tarefas" (
    "id" TEXT NOT NULL,
    "titulo" TEXT NOT NULL,
    "descricao" TEXT,
    "prioridade" "TarefaPrioridade" NOT NULL DEFAULT 'MEDIA',
    "concluida" BOOLEAN NOT NULL DEFAULT false,
    "dataVenc" TIMESTAMP(3),
    "companyId" TEXT NOT NULL,
    "criadoPor" TEXT NOT NULL,
    "atribuidoA" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "tarefas_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "tarefas_companyId_idx" ON "tarefas"("companyId");

-- CreateIndex
CREATE INDEX "tarefas_atribuidoA_idx" ON "tarefas"("atribuidoA");

-- AddForeignKey
ALTER TABLE "tarefas" ADD CONSTRAINT "tarefas_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tarefas" ADD CONSTRAINT "tarefas_criadoPor_fkey" FOREIGN KEY ("criadoPor") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tarefas" ADD CONSTRAINT "tarefas_atribuidoA_fkey" FOREIGN KEY ("atribuidoA") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
