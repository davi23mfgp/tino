-- AlterTable
ALTER TABLE "tarefas" ADD COLUMN     "horaFim" TEXT,
ADD COLUMN     "horaInicio" TEXT;
