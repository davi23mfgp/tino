ALTER TABLE "obras" ADD COLUMN "previsao_finalizacao_instalacao" TIMESTAMP(3);
