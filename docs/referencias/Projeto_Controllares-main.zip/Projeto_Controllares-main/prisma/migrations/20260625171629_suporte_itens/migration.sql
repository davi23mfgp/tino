-- CreateTable
CREATE TABLE "suporte_itens" (
    "id" TEXT NOT NULL,
    "companyId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "tipo" TEXT NOT NULL,
    "titulo" TEXT NOT NULL,
    "descricao" TEXT NOT NULL DEFAULT '',
    "status" TEXT NOT NULL DEFAULT 'ABERTO',
    "resposta" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "suporte_itens_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "suporte_itens_companyId_idx" ON "suporte_itens"("companyId");

-- AddForeignKey
ALTER TABLE "suporte_itens" ADD CONSTRAINT "suporte_itens_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "suporte_itens" ADD CONSTRAINT "suporte_itens_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
