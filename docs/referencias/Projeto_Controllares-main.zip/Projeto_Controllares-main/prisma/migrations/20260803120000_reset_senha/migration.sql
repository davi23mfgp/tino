-- AlterTable: campos de recuperacao de senha
ALTER TABLE "users" ADD COLUMN     "reset_token_expiry" TIMESTAMP(3),
ADD COLUMN     "reset_token_hash" TEXT;

-- CreateIndex
CREATE UNIQUE INDEX "users_reset_token_hash_key" ON "users"("reset_token_hash");
