ALTER TABLE "proposals" ADD COLUMN "motivo_perda" TEXT;
