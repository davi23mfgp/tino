-- Forma de pagamento escolhida na proposta (herdada pelo faturamento)
ALTER TABLE "proposals" ADD COLUMN     "forma_pagamento" TEXT,
ADD COLUMN     "parcelas_forma" INTEGER;
