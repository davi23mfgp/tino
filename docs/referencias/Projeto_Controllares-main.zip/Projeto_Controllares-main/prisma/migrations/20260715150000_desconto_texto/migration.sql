ALTER TABLE "companies" ADD COLUMN "texto_padrao_proposta" TEXT;
CREATE TABLE "discount_approvals" (
  "id" TEXT NOT NULL,
  "companyId" TEXT NOT NULL,
  "proposalId" TEXT,
  "solicitanteId" TEXT NOT NULL,
  "solicitanteNome" TEXT NOT NULL,
  "valor_desconto" DOUBLE PRECISION NOT NULL,
  "teto_permitido" DOUBLE PRECISION NOT NULL,
  "justificativa" TEXT,
  "status" TEXT NOT NULL DEFAULT 'PENDENTE',
  "decididoPorNome" TEXT,
  "decididoEm" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "discount_approvals_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "discount_approvals_companyId_status_idx" ON "discount_approvals"("companyId", "status");
ALTER TABLE "discount_approvals" ADD CONSTRAINT "discount_approvals_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;
