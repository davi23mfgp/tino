CREATE TABLE "stock_inventories" (
  "id" TEXT NOT NULL,
  "companyId" TEXT NOT NULL,
  "nome" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'ABERTO',
  "criadoPorId" TEXT NOT NULL,
  "criadoPorNome" TEXT NOT NULL,
  "fechadoPorNome" TEXT,
  "fechadoEm" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "stock_inventories_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "stock_inventories_companyId_status_idx" ON "stock_inventories"("companyId", "status");
ALTER TABLE "stock_inventories" ADD CONSTRAINT "stock_inventories_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "stock_inventory_items" (
  "id" TEXT NOT NULL,
  "inventoryId" TEXT NOT NULL,
  "productId" TEXT NOT NULL,
  "quantidade" INTEGER NOT NULL DEFAULT 0,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "stock_inventory_items_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "stock_inventory_items_inventoryId_productId_key" ON "stock_inventory_items"("inventoryId", "productId");
CREATE INDEX "stock_inventory_items_productId_idx" ON "stock_inventory_items"("productId");
ALTER TABLE "stock_inventory_items" ADD CONSTRAINT "stock_inventory_items_inventoryId_fkey" FOREIGN KEY ("inventoryId") REFERENCES "stock_inventories"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "stock_inventory_items" ADD CONSTRAINT "stock_inventory_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES "catalog_products"("id") ON DELETE CASCADE ON UPDATE CASCADE;
