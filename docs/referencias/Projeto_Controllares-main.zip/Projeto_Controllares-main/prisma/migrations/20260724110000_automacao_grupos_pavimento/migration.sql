-- AlterTable
ALTER TABLE "automacao_modulo_entradas" ADD COLUMN     "grupo" TEXT;

-- AlterTable
ALTER TABLE "automacao_modulo_saidas" ADD COLUMN     "grupo" TEXT;

-- AlterTable
ALTER TABLE "automacao_modulos" ADD COLUMN     "capacidade" INTEGER,
ADD COLUMN     "pavimento" TEXT;

-- AlterTable
ALTER TABLE "automacao_pontos" ADD COLUMN     "grupo" TEXT;

