ALTER TABLE "catalog_products" ADD COLUMN "tipo_dimensao" TEXT;
ALTER TABLE "catalog_products" ADD COLUMN "outros_descricao" TEXT;
ALTER TABLE "catalog_products" ADD COLUMN "outros_formato" TEXT;
ALTER TABLE "catalog_products" ADD COLUMN "outros_formato_custom" TEXT;
ALTER TABLE "catalog_products" ADD COLUMN "outros_instalacao" TEXT;
ALTER TABLE "catalog_products" ADD COLUMN "outros_instalacao_custom" TEXT;
