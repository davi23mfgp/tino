ALTER TABLE "obras" ADD COLUMN "posicoes_2d" JSONB;
