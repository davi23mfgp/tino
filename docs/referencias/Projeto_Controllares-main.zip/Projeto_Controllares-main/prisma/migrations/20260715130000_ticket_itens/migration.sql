ALTER TABLE "maintenance_tickets" ADD COLUMN "item_catalogo_id" TEXT;
ALTER TABLE "maintenance_tickets" ADD COLUMN "item_servico" JSONB;
ALTER TABLE "maintenance_tickets" ADD COLUMN "quantidade_item" INTEGER NOT NULL DEFAULT 1;
ALTER TABLE "maintenance_tickets" ADD COLUMN "decisao_faturamento" TEXT;
ALTER TABLE "maintenance_tickets" ADD COLUMN "estoque_movimento_id" TEXT;
