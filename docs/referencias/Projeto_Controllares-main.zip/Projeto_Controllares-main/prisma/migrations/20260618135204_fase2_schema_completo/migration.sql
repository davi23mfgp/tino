-- CreateEnum
CREATE TYPE "ProductStatus" AS ENUM ('ATIVO', 'INATIVO');

-- CreateEnum
CREATE TYPE "ProjectType" AS ENUM ('CONDOMINIO', 'RESIDENCIAL', 'APARTAMENTO', 'CORPORATIVO', 'RURAL');

-- CreateEnum
CREATE TYPE "ProposalStatus" AS ENUM ('RASCUNHO', 'ENVIADA', 'LIDA', 'EM_REVISAO', 'ACEITA', 'CANCELADA');

-- CreateEnum
CREATE TYPE "InstallmentStatus" AS ENUM ('PENDENTE', 'PAGO', 'ATRASADO');

-- CreateEnum
CREATE TYPE "FinancialStatus" AS ENUM ('PENDENTE', 'RECEBIDO', 'ATRASADO', 'CANCELADO');

-- CreateEnum
CREATE TYPE "LogisticsStatus" AS ENUM ('AGUARDANDO_EQUIPAMENTOS', 'LIBERADO_INSTALACAO', 'EM_ANDAMENTO', 'FINALIZADA');

-- CreateEnum
CREATE TYPE "TicketStatus" AS ENUM ('NOVA', 'AGUARDANDO', 'EM_ANDAMENTO', 'EM_CONFERENCIA');

-- CreateEnum
CREATE TYPE "MediaType" AS ENUM ('FOTO', 'VIDEO');

-- CreateEnum
CREATE TYPE "GanttLane" AS ENUM ('CONSTRUTORA', 'EMPRESA', 'TERCEIROS');

-- CreateEnum
CREATE TYPE "PartnerType" AS ENUM ('ARQUITETO', 'CONSTRUTORA', 'DESIGNER', 'ENGENHEIRO_CIVIL', 'MESTRE_OBRA');

-- CreateTable
CREATE TABLE "catalog_products" (
    "id" TEXT NOT NULL,
    "sku" TEXT NOT NULL,
    "nome" TEXT NOT NULL,
    "marca" TEXT,
    "preco_custo" DECIMAL(12,2) NOT NULL,
    "markup_padrao" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "preco_venda" DECIMAL(12,2) NOT NULL,
    "status" "ProductStatus" NOT NULL DEFAULT 'ATIVO',
    "imagem_url" TEXT,
    "companyId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "catalog_products_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "kits" (
    "id" TEXT NOT NULL,
    "nome" TEXT NOT NULL,
    "descricao" TEXT,
    "markup_global" DOUBLE PRECISION,
    "desconto" DOUBLE PRECISION,
    "companyId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "kits_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "kit_items" (
    "id" TEXT NOT NULL,
    "kitId" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "quantidade" INTEGER NOT NULL DEFAULT 1,

    CONSTRAINT "kit_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "proposal_templates" (
    "id" TEXT NOT NULL,
    "nome" TEXT NOT NULL,
    "estrutura" JSONB,
    "companyId" TEXT NOT NULL,
    "createdBy" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "proposal_templates_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "proposals" (
    "id" TEXT NOT NULL,
    "numero" TEXT NOT NULL,
    "client_name" TEXT NOT NULL,
    "client_email" TEXT,
    "client_city" TEXT,
    "project_type" "ProjectType" NOT NULL DEFAULT 'RESIDENCIAL',
    "status" "ProposalStatus" NOT NULL DEFAULT 'RASCUNHO',
    "valor_total" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "data_expiracao" TIMESTAMP(3),
    "link_token" TEXT,
    "vendedorId" TEXT NOT NULL,
    "companyId" TEXT NOT NULL,
    "obraId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "proposals_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "proposal_versions" (
    "id" TEXT NOT NULL,
    "proposalId" TEXT NOT NULL,
    "numero_versao" INTEGER NOT NULL,
    "motivo_alteracao" TEXT,
    "valor_historico" DECIMAL(12,2) NOT NULL,
    "snapshot_json" JSONB NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "proposal_versions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "environments" (
    "id" TEXT NOT NULL,
    "nome" TEXT NOT NULL,
    "proposalId" TEXT,
    "obraId" TEXT,
    "companyId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "environments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "categories" (
    "id" TEXT NOT NULL,
    "nome" TEXT NOT NULL,
    "companyId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "proposal_items" (
    "id" TEXT NOT NULL,
    "proposalId" TEXT NOT NULL,
    "productId" TEXT,
    "kitId" TEXT,
    "environmentId" TEXT NOT NULL,
    "categoryId" TEXT,
    "quantidade" INTEGER NOT NULL DEFAULT 1,
    "markup_especifico" DOUBLE PRECISION,
    "desconto_unitario" DECIMAL(12,2),
    "valor_unitario" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "valor_total" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "is_aditivo" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "proposal_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "installments" (
    "id" TEXT NOT NULL,
    "proposalId" TEXT NOT NULL,
    "numero_parcela" INTEGER NOT NULL,
    "valor" DECIMAL(12,2) NOT NULL,
    "data_vencimento" TIMESTAMP(3) NOT NULL,
    "status" "InstallmentStatus" NOT NULL DEFAULT 'PENDENTE',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "installments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "extra_pages" (
    "id" TEXT NOT NULL,
    "proposalId" TEXT NOT NULL,
    "titulo" TEXT NOT NULL,
    "conteudo_markdown" TEXT NOT NULL,
    "ordem" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "extra_pages_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "financial_transactions" (
    "id" TEXT NOT NULL,
    "proposalId" TEXT,
    "installmentId" TEXT,
    "valor" DECIMAL(12,2) NOT NULL,
    "status" "FinancialStatus" NOT NULL DEFAULT 'PENDENTE',
    "companyId" TEXT NOT NULL,
    "nota_fiscal_status" TEXT,
    "contaazul_sale_id" TEXT,
    "contaazul_status" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "financial_transactions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "webhook_debug_logs" (
    "id" TEXT NOT NULL,
    "endpoint" TEXT NOT NULL,
    "payload_json" JSONB,
    "http_status" INTEGER,
    "response_body" TEXT,
    "reenviado" BOOLEAN NOT NULL DEFAULT false,
    "companyId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "webhook_debug_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "obras" (
    "id" TEXT NOT NULL,
    "companyId" TEXT NOT NULL,
    "client_name" TEXT NOT NULL,
    "address" TEXT,
    "cod_cno" TEXT,
    "etapa" TEXT,
    "physical_progress_percentage" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "logistics_status" "LogisticsStatus" NOT NULL DEFAULT 'AGUARDANDO_EQUIPAMENTOS',
    "compra_liberada" BOOLEAN NOT NULL DEFAULT false,
    "latitude" DOUBLE PRECISION,
    "longitude" DOUBLE PRECISION,
    "capa_url" TEXT,
    "foto_atual_url" TEXT,
    "resp_tecnico_id" TEXT,
    "resp_comercial_id" TEXT,
    "originProposalId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "obras_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "project_stages" (
    "id" TEXT NOT NULL,
    "obraId" TEXT NOT NULL,
    "etapa_anterior" TEXT,
    "etapa_nova" TEXT NOT NULL,
    "changed_by" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "project_stages_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "maintenance_tickets" (
    "id" TEXT NOT NULL,
    "obraId" TEXT NOT NULL,
    "titulo" TEXT NOT NULL,
    "descricao" TEXT,
    "status" "TicketStatus" NOT NULL DEFAULT 'NOVA',
    "companyId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "maintenance_tickets_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "technical_credentials_vault" (
    "id" TEXT NOT NULL,
    "obraId" TEXT NOT NULL,
    "tipo_equipamento" TEXT NOT NULL,
    "login" TEXT,
    "senha_criptografada" TEXT NOT NULL,
    "observacoes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "technical_credentials_vault_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "inspections_media" (
    "id" TEXT NOT NULL,
    "obraId" TEXT NOT NULL,
    "environmentId" TEXT,
    "tipo" "MediaType" NOT NULL DEFAULT 'FOTO',
    "url" TEXT NOT NULL,
    "descricao" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "inspections_media_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "gantt_tasks" (
    "id" TEXT NOT NULL,
    "obraId" TEXT NOT NULL,
    "titulo" TEXT NOT NULL,
    "raia" "GanttLane" NOT NULL DEFAULT 'EMPRESA',
    "data_inicio" TIMESTAMP(3) NOT NULL,
    "data_fim" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "gantt_tasks_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "keypad_engravings" (
    "id" TEXT NOT NULL,
    "obraId" TEXT NOT NULL,
    "environmentId" TEXT,
    "descricao_botao" TEXT NOT NULL,
    "posicao" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "keypad_engravings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "partners_stakeholders" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "type" "PartnerType" NOT NULL,
    "email" TEXT,
    "phone" TEXT,
    "company_name" TEXT,
    "companyId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "partners_stakeholders_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "work_partners" (
    "id" TEXT NOT NULL,
    "workId" TEXT NOT NULL,
    "partnerId" TEXT NOT NULL,

    CONSTRAINT "work_partners_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "catalog_products_companyId_idx" ON "catalog_products"("companyId");

-- CreateIndex
CREATE INDEX "catalog_products_status_idx" ON "catalog_products"("status");

-- CreateIndex
CREATE INDEX "catalog_products_nome_idx" ON "catalog_products"("nome");

-- CreateIndex
CREATE UNIQUE INDEX "catalog_products_companyId_sku_key" ON "catalog_products"("companyId", "sku");

-- CreateIndex
CREATE INDEX "kits_companyId_idx" ON "kits"("companyId");

-- CreateIndex
CREATE INDEX "kit_items_kitId_idx" ON "kit_items"("kitId");

-- CreateIndex
CREATE INDEX "kit_items_productId_idx" ON "kit_items"("productId");

-- CreateIndex
CREATE INDEX "proposal_templates_companyId_idx" ON "proposal_templates"("companyId");

-- CreateIndex
CREATE UNIQUE INDEX "proposals_link_token_key" ON "proposals"("link_token");

-- CreateIndex
CREATE INDEX "proposals_companyId_idx" ON "proposals"("companyId");

-- CreateIndex
CREATE INDEX "proposals_status_idx" ON "proposals"("status");

-- CreateIndex
CREATE INDEX "proposals_client_name_idx" ON "proposals"("client_name");

-- CreateIndex
CREATE INDEX "proposals_vendedorId_idx" ON "proposals"("vendedorId");

-- CreateIndex
CREATE INDEX "proposals_data_expiracao_idx" ON "proposals"("data_expiracao");

-- CreateIndex
CREATE UNIQUE INDEX "proposals_companyId_numero_key" ON "proposals"("companyId", "numero");

-- CreateIndex
CREATE INDEX "proposal_versions_proposalId_idx" ON "proposal_versions"("proposalId");

-- CreateIndex
CREATE INDEX "environments_companyId_idx" ON "environments"("companyId");

-- CreateIndex
CREATE INDEX "environments_proposalId_idx" ON "environments"("proposalId");

-- CreateIndex
CREATE INDEX "environments_obraId_idx" ON "environments"("obraId");

-- CreateIndex
CREATE INDEX "categories_companyId_idx" ON "categories"("companyId");

-- CreateIndex
CREATE INDEX "proposal_items_proposalId_idx" ON "proposal_items"("proposalId");

-- CreateIndex
CREATE INDEX "proposal_items_environmentId_idx" ON "proposal_items"("environmentId");

-- CreateIndex
CREATE INDEX "proposal_items_categoryId_idx" ON "proposal_items"("categoryId");

-- CreateIndex
CREATE INDEX "installments_proposalId_idx" ON "installments"("proposalId");

-- CreateIndex
CREATE INDEX "installments_status_idx" ON "installments"("status");

-- CreateIndex
CREATE INDEX "installments_data_vencimento_idx" ON "installments"("data_vencimento");

-- CreateIndex
CREATE INDEX "extra_pages_proposalId_idx" ON "extra_pages"("proposalId");

-- CreateIndex
CREATE INDEX "financial_transactions_companyId_idx" ON "financial_transactions"("companyId");

-- CreateIndex
CREATE INDEX "financial_transactions_status_idx" ON "financial_transactions"("status");

-- CreateIndex
CREATE INDEX "financial_transactions_proposalId_idx" ON "financial_transactions"("proposalId");

-- CreateIndex
CREATE INDEX "webhook_debug_logs_companyId_idx" ON "webhook_debug_logs"("companyId");

-- CreateIndex
CREATE INDEX "webhook_debug_logs_createdAt_idx" ON "webhook_debug_logs"("createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "obras_originProposalId_key" ON "obras"("originProposalId");

-- CreateIndex
CREATE INDEX "obras_companyId_idx" ON "obras"("companyId");

-- CreateIndex
CREATE INDEX "obras_client_name_idx" ON "obras"("client_name");

-- CreateIndex
CREATE INDEX "obras_logistics_status_idx" ON "obras"("logistics_status");

-- CreateIndex
CREATE INDEX "project_stages_obraId_idx" ON "project_stages"("obraId");

-- CreateIndex
CREATE INDEX "maintenance_tickets_obraId_idx" ON "maintenance_tickets"("obraId");

-- CreateIndex
CREATE INDEX "maintenance_tickets_companyId_idx" ON "maintenance_tickets"("companyId");

-- CreateIndex
CREATE INDEX "maintenance_tickets_status_idx" ON "maintenance_tickets"("status");

-- CreateIndex
CREATE INDEX "technical_credentials_vault_obraId_idx" ON "technical_credentials_vault"("obraId");

-- CreateIndex
CREATE INDEX "inspections_media_obraId_idx" ON "inspections_media"("obraId");

-- CreateIndex
CREATE INDEX "inspections_media_environmentId_idx" ON "inspections_media"("environmentId");

-- CreateIndex
CREATE INDEX "gantt_tasks_obraId_idx" ON "gantt_tasks"("obraId");

-- CreateIndex
CREATE INDEX "keypad_engravings_obraId_idx" ON "keypad_engravings"("obraId");

-- CreateIndex
CREATE INDEX "partners_stakeholders_companyId_idx" ON "partners_stakeholders"("companyId");

-- CreateIndex
CREATE INDEX "partners_stakeholders_type_idx" ON "partners_stakeholders"("type");

-- CreateIndex
CREATE INDEX "work_partners_workId_idx" ON "work_partners"("workId");

-- CreateIndex
CREATE INDEX "work_partners_partnerId_idx" ON "work_partners"("partnerId");

-- CreateIndex
CREATE UNIQUE INDEX "work_partners_workId_partnerId_key" ON "work_partners"("workId", "partnerId");

-- CreateIndex
CREATE INDEX "users_companyId_idx" ON "users"("companyId");

-- AddForeignKey
ALTER TABLE "catalog_products" ADD CONSTRAINT "catalog_products_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "kits" ADD CONSTRAINT "kits_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "kit_items" ADD CONSTRAINT "kit_items_kitId_fkey" FOREIGN KEY ("kitId") REFERENCES "kits"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "kit_items" ADD CONSTRAINT "kit_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES "catalog_products"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "proposal_templates" ADD CONSTRAINT "proposal_templates_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "proposal_templates" ADD CONSTRAINT "proposal_templates_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "proposals" ADD CONSTRAINT "proposals_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "proposals" ADD CONSTRAINT "proposals_vendedorId_fkey" FOREIGN KEY ("vendedorId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "proposals" ADD CONSTRAINT "proposals_obraId_fkey" FOREIGN KEY ("obraId") REFERENCES "obras"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "proposal_versions" ADD CONSTRAINT "proposal_versions_proposalId_fkey" FOREIGN KEY ("proposalId") REFERENCES "proposals"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "environments" ADD CONSTRAINT "environments_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "environments" ADD CONSTRAINT "environments_proposalId_fkey" FOREIGN KEY ("proposalId") REFERENCES "proposals"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "environments" ADD CONSTRAINT "environments_obraId_fkey" FOREIGN KEY ("obraId") REFERENCES "obras"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "categories" ADD CONSTRAINT "categories_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "proposal_items" ADD CONSTRAINT "proposal_items_proposalId_fkey" FOREIGN KEY ("proposalId") REFERENCES "proposals"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "proposal_items" ADD CONSTRAINT "proposal_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES "catalog_products"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "proposal_items" ADD CONSTRAINT "proposal_items_kitId_fkey" FOREIGN KEY ("kitId") REFERENCES "kits"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "proposal_items" ADD CONSTRAINT "proposal_items_environmentId_fkey" FOREIGN KEY ("environmentId") REFERENCES "environments"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "proposal_items" ADD CONSTRAINT "proposal_items_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "categories"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "installments" ADD CONSTRAINT "installments_proposalId_fkey" FOREIGN KEY ("proposalId") REFERENCES "proposals"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "extra_pages" ADD CONSTRAINT "extra_pages_proposalId_fkey" FOREIGN KEY ("proposalId") REFERENCES "proposals"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "financial_transactions" ADD CONSTRAINT "financial_transactions_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "financial_transactions" ADD CONSTRAINT "financial_transactions_proposalId_fkey" FOREIGN KEY ("proposalId") REFERENCES "proposals"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "financial_transactions" ADD CONSTRAINT "financial_transactions_installmentId_fkey" FOREIGN KEY ("installmentId") REFERENCES "installments"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "webhook_debug_logs" ADD CONSTRAINT "webhook_debug_logs_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "obras" ADD CONSTRAINT "obras_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "obras" ADD CONSTRAINT "obras_resp_tecnico_id_fkey" FOREIGN KEY ("resp_tecnico_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "obras" ADD CONSTRAINT "obras_resp_comercial_id_fkey" FOREIGN KEY ("resp_comercial_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "obras" ADD CONSTRAINT "obras_originProposalId_fkey" FOREIGN KEY ("originProposalId") REFERENCES "proposals"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "project_stages" ADD CONSTRAINT "project_stages_obraId_fkey" FOREIGN KEY ("obraId") REFERENCES "obras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "project_stages" ADD CONSTRAINT "project_stages_changed_by_fkey" FOREIGN KEY ("changed_by") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenance_tickets" ADD CONSTRAINT "maintenance_tickets_obraId_fkey" FOREIGN KEY ("obraId") REFERENCES "obras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenance_tickets" ADD CONSTRAINT "maintenance_tickets_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "technical_credentials_vault" ADD CONSTRAINT "technical_credentials_vault_obraId_fkey" FOREIGN KEY ("obraId") REFERENCES "obras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inspections_media" ADD CONSTRAINT "inspections_media_obraId_fkey" FOREIGN KEY ("obraId") REFERENCES "obras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inspections_media" ADD CONSTRAINT "inspections_media_environmentId_fkey" FOREIGN KEY ("environmentId") REFERENCES "environments"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "gantt_tasks" ADD CONSTRAINT "gantt_tasks_obraId_fkey" FOREIGN KEY ("obraId") REFERENCES "obras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "keypad_engravings" ADD CONSTRAINT "keypad_engravings_obraId_fkey" FOREIGN KEY ("obraId") REFERENCES "obras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "keypad_engravings" ADD CONSTRAINT "keypad_engravings_environmentId_fkey" FOREIGN KEY ("environmentId") REFERENCES "environments"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "partners_stakeholders" ADD CONSTRAINT "partners_stakeholders_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "work_partners" ADD CONSTRAINT "work_partners_workId_fkey" FOREIGN KEY ("workId") REFERENCES "obras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "work_partners" ADD CONSTRAINT "work_partners_partnerId_fkey" FOREIGN KEY ("partnerId") REFERENCES "partners_stakeholders"("id") ON DELETE CASCADE ON UPDATE CASCADE;
