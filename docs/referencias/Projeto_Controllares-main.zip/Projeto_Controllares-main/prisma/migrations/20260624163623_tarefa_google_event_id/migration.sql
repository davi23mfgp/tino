-- AlterTable
ALTER TABLE "tarefas" ADD COLUMN     "google_event_id" TEXT;
