ALTER TABLE "kit_items" ADD COLUMN "markup_especifico" DOUBLE PRECISION;
ALTER TABLE "kit_items" ADD COLUMN "desconto_unitario" DOUBLE PRECISION;
