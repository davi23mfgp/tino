-- Ferramentas de Projetos (Estudo de keypads e Infraestrutura): estado de cada
-- uma por obra. So acrescenta colunas; nada existente muda.
ALTER TABLE "obras" ADD COLUMN IF NOT EXISTS "estudo_keypads" JSONB;
ALTER TABLE "obras" ADD COLUMN IF NOT EXISTS "estudo_infra" JSONB;
