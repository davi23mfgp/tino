-- AlterTable
ALTER TABLE "companies" ADD COLUMN     "whatsapp_apikey" TEXT,
ADD COLUMN     "whatsapp_numero" TEXT;

