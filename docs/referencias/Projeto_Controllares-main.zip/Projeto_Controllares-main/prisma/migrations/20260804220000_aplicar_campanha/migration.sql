ALTER TABLE "proposals" ADD COLUMN     "aplicar_desconto_campanha" BOOLEAN NOT NULL DEFAULT true;
