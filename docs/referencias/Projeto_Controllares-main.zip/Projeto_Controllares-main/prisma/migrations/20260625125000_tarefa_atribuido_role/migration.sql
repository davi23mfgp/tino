-- AlterTable
ALTER TABLE "tarefas" ADD COLUMN     "atribuido_role" TEXT;
