ALTER TABLE "catalog_products" ADD COLUMN "inativo_proposta" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "catalog_products" ADD COLUMN "ncm" TEXT;
CREATE TABLE "product_components" (
  "id" TEXT NOT NULL,
  "produtoId" TEXT NOT NULL,
  "componenteId" TEXT NOT NULL,
  "quantidade" INTEGER NOT NULL DEFAULT 1,
  CONSTRAINT "product_components_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "product_components_produtoId_componenteId_key" ON "product_components"("produtoId", "componenteId");
CREATE INDEX "product_components_produtoId_idx" ON "product_components"("produtoId");
ALTER TABLE "product_components" ADD CONSTRAINT "product_components_produtoId_fkey" FOREIGN KEY ("produtoId") REFERENCES "catalog_products"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "product_components" ADD CONSTRAINT "product_components_componenteId_fkey" FOREIGN KEY ("componenteId") REFERENCES "catalog_products"("id") ON DELETE CASCADE ON UPDATE CASCADE;
