-- AlterTable
ALTER TABLE "catalog_products" ADD COLUMN     "aliquota_cofins" DOUBLE PRECISION,
ADD COLUMN     "aliquota_icms" DOUBLE PRECISION,
ADD COLUMN     "aliquota_ipi" DOUBLE PRECISION,
ADD COLUMN     "aliquota_pis" DOUBLE PRECISION,
ADD COLUMN     "cest" TEXT,
ADD COLUMN     "cst_cofins" TEXT,
ADD COLUMN     "cst_icms" TEXT,
ADD COLUMN     "cst_pis" TEXT,
ADD COLUMN     "gtin" TEXT,
ADD COLUMN     "origem" TEXT,
ADD COLUMN     "unidade" TEXT;

