-- AlterTable
ALTER TABLE "companies" ADD COLUMN     "contaazul_client_id" TEXT,
ADD COLUMN     "contaazul_client_secret" TEXT,
ADD COLUMN     "desconto_maximo" DOUBLE PRECISION DEFAULT 10,
ADD COLUMN     "endereco_base" TEXT,
ADD COLUMN     "logo_url" TEXT,
ADD COLUMN     "pluga_api_token" TEXT;
