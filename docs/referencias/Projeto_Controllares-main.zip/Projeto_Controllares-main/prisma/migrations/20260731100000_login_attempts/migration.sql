
-- CreateTable
CREATE TABLE "login_attempts" (
    "id" TEXT NOT NULL,
    "chave" TEXT NOT NULL,
    "tentativas" INTEGER NOT NULL DEFAULT 0,
    "bloqueadoAte" TIMESTAMP(3),
    "janelaInicio" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "login_attempts_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "login_attempts_chave_key" ON "login_attempts"("chave");

-- CreateIndex
CREATE INDEX "login_attempts_bloqueadoAte_idx" ON "login_attempts"("bloqueadoAte");

