-- AlterTable
ALTER TABLE "obras" ADD COLUMN     "etapa_projeto" TEXT;
