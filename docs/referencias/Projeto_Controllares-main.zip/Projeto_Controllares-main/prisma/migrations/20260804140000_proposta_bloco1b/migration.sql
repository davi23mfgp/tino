-- Mensagem que o cliente escreve ao pedir revisão / recusar (antes era descartada)
ALTER TABLE "proposals" ADD COLUMN     "mensagem_cliente" TEXT,
ADD COLUMN     "mensagem_cliente_em" TIMESTAMP(3);

-- Valor unitário oculto por padrão; quem monta a proposta decide
ALTER TABLE "proposals" ADD COLUMN     "exibir_valor_unitario" BOOLEAN NOT NULL DEFAULT false;
