-- Condições de pagamento padrão exibidas na proposta (a forma real vem no faturamento)
ALTER TABLE "proposals" ADD COLUMN     "condicoes_pagamento" TEXT;
