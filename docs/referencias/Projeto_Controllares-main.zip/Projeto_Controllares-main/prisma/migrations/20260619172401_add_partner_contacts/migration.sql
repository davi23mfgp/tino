-- AlterTable
ALTER TABLE "partners_stakeholders" ADD COLUMN     "email_especificador" TEXT,
ADD COLUMN     "observacoes" TEXT,
ADD COLUMN     "phone_responsavel" TEXT;
