-- Coluna "Concluída" no kanban de propostas (faturamento fechado)
ALTER TYPE "ProposalStatus" ADD VALUE IF NOT EXISTS 'CONCLUIDA';
