-- AlterTable
ALTER TABLE "technical_credentials_vault" ALTER COLUMN "senha_criptografada" DROP NOT NULL;
