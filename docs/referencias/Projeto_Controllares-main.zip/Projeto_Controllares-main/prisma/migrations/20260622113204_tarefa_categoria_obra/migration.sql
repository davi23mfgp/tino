-- CreateEnum
CREATE TYPE "TarefaCategoria" AS ENUM ('GERAL', 'ADMIN', 'FINANCEIRO', 'OPERACIONAL', 'COMERCIAL', 'ENGENHARIA');

-- AlterTable
ALTER TABLE "tarefas" ADD COLUMN     "categoria" "TarefaCategoria" NOT NULL DEFAULT 'GERAL',
ADD COLUMN     "obraId" TEXT;

-- CreateIndex
CREATE INDEX "tarefas_obraId_idx" ON "tarefas"("obraId");

-- AddForeignKey
ALTER TABLE "tarefas" ADD CONSTRAINT "tarefas_obraId_fkey" FOREIGN KEY ("obraId") REFERENCES "obras"("id") ON DELETE CASCADE ON UPDATE CASCADE;
