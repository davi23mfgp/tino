ALTER TABLE "tarefas" ADD COLUMN "checklist" JSONB;
