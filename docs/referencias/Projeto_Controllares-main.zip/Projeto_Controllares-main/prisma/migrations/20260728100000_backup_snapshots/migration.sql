-- CreateTable
CREATE TABLE "backup_snapshots" (
    "id" TEXT NOT NULL,
    "companyId" TEXT NOT NULL,
    "origem" TEXT NOT NULL DEFAULT 'AUTO',
    "arquivo_url" TEXT,
    "dados" JSONB,
    "resumo" JSONB NOT NULL,
    "tamanho_bytes" INTEGER NOT NULL DEFAULT 0,
    "erro" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "backup_snapshots_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "backup_snapshots_companyId_createdAt_idx" ON "backup_snapshots"("companyId", "createdAt");

-- AddForeignKey
ALTER TABLE "backup_snapshots" ADD CONSTRAINT "backup_snapshots_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

