-- AlterTable
ALTER TABLE "categories" ADD COLUMN     "imagem_url" TEXT,
ADD COLUMN     "servicos" JSONB;

-- AlterTable
ALTER TABLE "companies" ADD COLUMN     "descontos_padrao" JSONB;

-- AlterTable
ALTER TABLE "proposals" ADD COLUMN     "anos_garantia" INTEGER,
ADD COLUMN     "desconto_aplicado" DOUBLE PRECISION,
ADD COLUMN     "payment_methods" TEXT;
