-- O que acontece com cada sistema dentro da proposta.
--
-- ATIVO     vai para o cliente e entra na conta.
-- GUARDADO  montado, mas não enviado (ou enviado e não escolhido).
-- RECUSADO  o cliente viu e disse não.
--
-- O cliente costuma gostar de tudo e fechar um sistema só. Antes, o que ele
-- não levava era apagado da proposta, e seis meses depois — quando ele voltava
-- para fazer o som — o trabalho de montar tinha ido junto.
--
-- Texto e não enum: a lista pode crescer ("EM_ESTUDO", "ADIADO") sem exigir
-- migration de tipo, e nenhum destes valores é usado em JOIN ou índice.
--
-- Default ATIVO: toda proposta que já existe continua exatamente como está,
-- com todos os sistemas contando para o total.
ALTER TABLE "environments"
  ADD COLUMN "status" TEXT NOT NULL DEFAULT 'ATIVO';
