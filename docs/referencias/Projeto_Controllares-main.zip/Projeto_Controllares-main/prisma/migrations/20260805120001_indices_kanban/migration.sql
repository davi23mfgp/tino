-- Kanban lê por empresa+status a cada poucos segundos
CREATE INDEX IF NOT EXISTS "proposals_companyId_status_idx" ON "proposals"("companyId", "status");
CREATE INDEX IF NOT EXISTS "proposals_companyId_createdAt_idx" ON "proposals"("companyId", "createdAt");
