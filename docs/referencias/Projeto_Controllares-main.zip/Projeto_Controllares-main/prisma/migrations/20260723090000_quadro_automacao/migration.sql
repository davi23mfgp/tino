-- CreateTable
CREATE TABLE "automacao_quadros" (
    "id" TEXT NOT NULL,
    "obraId" TEXT NOT NULL,
    "nome" TEXT NOT NULL,
    "local" TEXT,
    "observacoes" TEXT,
    "ordem" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "automacao_quadros_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "automacao_modulos" (
    "id" TEXT NOT NULL,
    "quadroId" TEXT NOT NULL,
    "nome" TEXT NOT NULL,
    "modelo" TEXT,
    "tipo" TEXT,
    "observacoes" TEXT,
    "ordem" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "automacao_modulos_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "automacao_modulo_entradas" (
    "id" TEXT NOT NULL,
    "moduloId" TEXT NOT NULL,
    "numero" TEXT NOT NULL,
    "keypads" TEXT[],
    "observacao" TEXT,
    "ordem" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "automacao_modulo_entradas_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "automacao_modulo_saidas" (
    "id" TEXT NOT NULL,
    "moduloId" TEXT NOT NULL,
    "numero" TEXT NOT NULL,
    "descricao" TEXT NOT NULL,
    "circuito" TEXT,
    "ambiente" TEXT,
    "tipo_carga" TEXT,
    "potencia_w" INTEGER,
    "extras" JSONB,
    "ordem" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "automacao_modulo_saidas_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "keypads" (
    "id" TEXT NOT NULL,
    "obraId" TEXT NOT NULL,
    "codigo" TEXT NOT NULL,
    "ambiente" TEXT,
    "modelo" TEXT,
    "teclas" INTEGER,
    "ordem" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "keypads_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "keypad_acoes" (
    "id" TEXT NOT NULL,
    "keypadId" TEXT NOT NULL,
    "tecla" TEXT NOT NULL,
    "funcao" TEXT NOT NULL,
    "tipo" TEXT,
    "texto_icone" TEXT,
    "nome_tecla" TEXT,
    "circuitos" TEXT[],
    "descricao" TEXT,
    "ordem" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "keypad_acoes_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "automacao_quadros_obraId_idx" ON "automacao_quadros"("obraId");

-- CreateIndex
CREATE INDEX "automacao_modulos_quadroId_idx" ON "automacao_modulos"("quadroId");

-- CreateIndex
CREATE INDEX "automacao_modulo_entradas_moduloId_idx" ON "automacao_modulo_entradas"("moduloId");

-- CreateIndex
CREATE INDEX "automacao_modulo_saidas_moduloId_idx" ON "automacao_modulo_saidas"("moduloId");

-- CreateIndex
CREATE INDEX "keypads_obraId_idx" ON "keypads"("obraId");

-- CreateIndex
CREATE INDEX "keypad_acoes_keypadId_idx" ON "keypad_acoes"("keypadId");

-- AddForeignKey
ALTER TABLE "automacao_quadros" ADD CONSTRAINT "automacao_quadros_obraId_fkey" FOREIGN KEY ("obraId") REFERENCES "obras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "automacao_modulos" ADD CONSTRAINT "automacao_modulos_quadroId_fkey" FOREIGN KEY ("quadroId") REFERENCES "automacao_quadros"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "automacao_modulo_entradas" ADD CONSTRAINT "automacao_modulo_entradas_moduloId_fkey" FOREIGN KEY ("moduloId") REFERENCES "automacao_modulos"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "automacao_modulo_saidas" ADD CONSTRAINT "automacao_modulo_saidas_moduloId_fkey" FOREIGN KEY ("moduloId") REFERENCES "automacao_modulos"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "keypads" ADD CONSTRAINT "keypads_obraId_fkey" FOREIGN KEY ("obraId") REFERENCES "obras"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "keypad_acoes" ADD CONSTRAINT "keypad_acoes_keypadId_fkey" FOREIGN KEY ("keypadId") REFERENCES "keypads"("id") ON DELETE CASCADE ON UPDATE CASCADE;

