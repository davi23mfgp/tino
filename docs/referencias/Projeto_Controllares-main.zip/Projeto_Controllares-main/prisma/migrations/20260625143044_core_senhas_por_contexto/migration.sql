-- AlterTable
ALTER TABLE "users" ADD COLUMN     "senha_fin_bloqueada" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "senha_fin_hash" TEXT,
ADD COLUMN     "senha_op_bloqueada" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "senha_op_hash" TEXT;
