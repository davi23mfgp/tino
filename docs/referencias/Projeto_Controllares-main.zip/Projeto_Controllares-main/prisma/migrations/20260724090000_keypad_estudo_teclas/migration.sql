-- AlterTable
ALTER TABLE "keypads" ADD COLUMN     "acabamento" TEXT,
ADD COLUMN     "circuitos" TEXT[],
ADD COLUMN     "ligar_junto" TEXT,
ADD COLUMN     "medida" TEXT,
ADD COLUMN     "observacao" TEXT,
ADD COLUMN     "pulsadores_compra" INTEGER,
ADD COLUMN     "setor" TEXT,
ADD COLUMN     "teclas_automacao" INTEGER;

