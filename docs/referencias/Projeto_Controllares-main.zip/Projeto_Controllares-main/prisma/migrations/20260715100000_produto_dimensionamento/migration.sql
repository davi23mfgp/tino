ALTER TABLE "catalog_products" ADD COLUMN "tipo_aplicacao" TEXT;
ALTER TABLE "catalog_products" ADD COLUMN "formato_medida" TEXT;
