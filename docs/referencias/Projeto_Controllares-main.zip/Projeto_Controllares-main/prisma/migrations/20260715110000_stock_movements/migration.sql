CREATE TABLE "stock_movements" (
  "id" TEXT NOT NULL,
  "companyId" TEXT NOT NULL,
  "productId" TEXT NOT NULL,
  "tipo" TEXT NOT NULL,
  "quantidade" INTEGER NOT NULL,
  "saldo_novo" INTEGER,
  "motivo" TEXT NOT NULL,
  "origem" TEXT,
  "status" TEXT NOT NULL DEFAULT 'APLICADO',
  "criadoPorId" TEXT NOT NULL,
  "criadoPorNome" TEXT NOT NULL,
  "aprovadoPorNome" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "stock_movements_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "stock_movements_companyId_createdAt_idx" ON "stock_movements"("companyId", "createdAt");
CREATE INDEX "stock_movements_productId_idx" ON "stock_movements"("productId");
CREATE INDEX "stock_movements_companyId_status_idx" ON "stock_movements"("companyId", "status");
ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_productId_fkey" FOREIGN KEY ("productId") REFERENCES "catalog_products"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "catalog_products" ADD COLUMN "inventario_fechado" BOOLEAN NOT NULL DEFAULT false;
