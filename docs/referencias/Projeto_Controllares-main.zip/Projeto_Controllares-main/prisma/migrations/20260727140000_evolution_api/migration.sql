-- AlterTable
ALTER TABLE "companies" ADD COLUMN     "evolution_apikey" TEXT,
ADD COLUMN     "evolution_instance" TEXT,
ADD COLUMN     "evolution_url" TEXT;

