-- AlterTable
ALTER TABLE "proposals" ADD COLUMN     "valor_servico" DECIMAL(12,2) NOT NULL DEFAULT 0;
