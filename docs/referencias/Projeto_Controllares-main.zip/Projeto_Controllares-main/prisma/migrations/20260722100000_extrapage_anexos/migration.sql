-- AlterTable
ALTER TABLE "extra_pages" ADD COLUMN     "anexos" JSONB;

