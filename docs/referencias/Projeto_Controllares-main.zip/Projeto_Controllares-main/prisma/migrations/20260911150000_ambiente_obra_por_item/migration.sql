-- Onde cada item vai ser instalado de fato ("Sala", "Suíte 2", "Varanda").
--
-- Na proposta, `environmentId` passou a significar SISTEMA (automação, som,
-- rede): a fatia que se vende e que o cliente pode escolher ou recusar. Um
-- mesmo sistema se espalha por vários cômodos, então o técnico em campo
-- precisava de outra leitura — com o equipamento na mão, a pergunta é "onde
-- este aqui vai", não "de qual sistema ele é".
--
-- Coluna nova e anulável: nada existente muda, item sem ambiente escrito
-- continua válido (é o estado de toda obra anterior a esta migration).
ALTER TABLE "proposal_items"
  ADD COLUMN "ambiente_obra" TEXT;
