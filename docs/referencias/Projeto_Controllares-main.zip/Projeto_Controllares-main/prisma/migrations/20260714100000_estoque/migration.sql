ALTER TABLE "catalog_products" ADD COLUMN "estoque_qtd" INTEGER;
ALTER TABLE "catalog_products" ADD COLUMN "estoque_minimo" INTEGER;
