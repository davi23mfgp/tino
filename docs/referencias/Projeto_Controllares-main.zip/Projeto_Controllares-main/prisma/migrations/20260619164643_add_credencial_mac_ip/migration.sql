-- AlterTable
ALTER TABLE "technical_credentials_vault" ADD COLUMN     "anexo_url" TEXT,
ADD COLUMN     "ip_criptografado" TEXT,
ADD COLUMN     "mac_criptografado" TEXT;
