// Controllares Service Worker v3
// Estratégias: NetworkFirst (nav), CacheFirst (static/images), StaleWhileRevalidate (API leitura)
// Kill-switch: ?sw=off desregistra o SW

const CACHE_VERSION = "v3"
const CACHE_SHELL   = `controllares-shell-${CACHE_VERSION}`
const CACHE_STATIC  = `controllares-static-${CACHE_VERSION}`
const CACHE_IMAGE   = `controllares-image-${CACHE_VERSION}`
const CACHE_API     = `controllares-api-${CACHE_VERSION}`
const ALL_CACHES    = [CACHE_SHELL, CACHE_STATIC, CACHE_IMAGE, CACHE_API]

// Nunca interceptar — sensíveis / mutáveis
const NEVER_CACHE = ["/api/auth/", "/api/ai/", "/api/admin/", "/api/upload", "/api/cron/"]

// API de leitura com StaleWhileRevalidate
const SWR_API = ["/api/propostas", "/api/obras"]

const MAX_API_ENTRIES = 50
const API_TTL_MS      = 24 * 60 * 60 * 1000  // 24h
const IMAGE_TTL_DAYS  = 30
const MAX_IMAGE       = 60

// ── Install ────────────────────────────────────────────────────────────────────
self.addEventListener("install", e => {
  // Não chama skipWaiting automaticamente; cliente controla via SKIP_WAITING
  e.waitUntil(
    caches.open(CACHE_SHELL)
      .then(c => c.addAll(["/"]).catch(() => {}))
  )
})

// ── Activate ───────────────────────────────────────────────────────────────────
self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys.filter(k => !ALL_CACHES.includes(k)).map(k => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  )
})

// ── Message ────────────────────────────────────────────────────────────────────
self.addEventListener("message", e => {
  if (e.data === "SKIP_WAITING") self.skipWaiting()
})

// ── Fetch ──────────────────────────────────────────────────────────────────────
self.addEventListener("fetch", e => {
  const req = e.request
  if (req.method !== "GET") return

  const url = new URL(req.url)

  // Kill-switch
  if (url.searchParams.get("sw") === "off") {
    e.respondWith(self.registration.unregister().then(() => fetch(req)))
    return
  }

  // Cross-origin — passa
  if (url.origin !== location.origin) return

  const path = url.pathname

  // Sensíveis — nunca interceptar
  if (NEVER_CACHE.some(p => path.startsWith(p))) return

  // Static imutável: CacheFirst, 1 ano
  if (path.startsWith("/_next/static/")) {
    e.respondWith(cacheFirst(req, CACHE_STATIC))
    return
  }

  // Imagens same-origin: CacheFirst, 30d, max 60
  if (/\.(png|jpe?g|webp|svg|ico|gif)$/i.test(path)) {
    e.respondWith(cacheFirstWithExpiry(req, CACHE_IMAGE, IMAGE_TTL_DAYS, MAX_IMAGE))
    return
  }

  // API de leitura: StaleWhileRevalidate, 24h, max 50
  if (SWR_API.some(p => path.startsWith(p))) {
    e.respondWith(staleWhileRevalidate(req, CACHE_API))
    return
  }

  // Demais /api/* — network only
  if (path.startsWith("/api/")) return

  // Navegação HTML: NetworkFirst, timeout 3s
  e.respondWith(networkFirst(req))
})

// ── Estratégias ────────────────────────────────────────────────────────────────

async function cacheFirst(req, cacheName) {
  const cache  = await caches.open(cacheName)
  const cached = await cache.match(req)
  if (cached) return cached
  const res = await fetch(req)
  if (res.ok) cache.put(req, res.clone())
  return res
}

async function cacheFirstWithExpiry(req, cacheName, days, maxEntries) {
  const cache  = await caches.open(cacheName)
  const cached = await cache.match(req)
  if (cached) {
    const dateStr = cached.headers.get("date")
    if (!dateStr || (Date.now() - new Date(dateStr).getTime()) < days * 86400000) {
      return cached
    }
  }
  try {
    const res = await fetch(req)
    if (res.ok) {
      const keys = await cache.keys()
      if (keys.length >= maxEntries) cache.delete(keys[0])
      cache.put(req, res.clone())
    }
    return res
  } catch {
    return cached ?? new Response("Offline", { status: 503 })
  }
}

async function staleWhileRevalidate(req, cacheName) {
  const cache  = await caches.open(cacheName)
  const cached = await cache.match(req)

  const revalidate = fetch(req).then(res => {
    if (!res.ok) return res
    cache.keys().then(keys => { if (keys.length >= MAX_API_ENTRIES) cache.delete(keys[0]) })
    const stamped = new Response(res.body, {
      status: res.status, statusText: res.statusText,
      headers: new Headers({
        ...Object.fromEntries(res.headers.entries()),
        "sw-cached-at": Date.now().toString(),
      }),
    })
    cache.put(req, stamped.clone())
    return stamped
  }).catch(() => null)

  if (cached) {
    const cachedAt = Number(cached.headers.get("sw-cached-at") ?? 0)
    if (cachedAt && Date.now() - cachedAt > API_TTL_MS) {
      return (await revalidate) ?? cached
    }
    revalidate.catch(() => {})
    return cached
  }

  return (await revalidate) ?? new Response("Offline", { status: 503 })
}

async function networkFirst(req) {
  const cache = await caches.open(CACHE_SHELL)
  try {
    const controller = new AbortController()
    const tid = setTimeout(() => controller.abort(), 3000)
    const res = await fetch(req, { signal: controller.signal })
    clearTimeout(tid)
    if (res.ok) cache.put(req, res.clone())
    return res
  } catch {
    const cached = await cache.match(req)
    if (cached) return cached
    const shell = await cache.match("/")
    return shell ?? new Response("Offline", { status: 503 })
  }
}

// ── Push Notifications ─────────────────────────────────────────────────────────
self.addEventListener("push", e => {
  if (!e.data) return
  const data = e.data.json()
  e.waitUntil(
    self.registration.showNotification(data.title ?? "Controllares", {
      body: data.body ?? "",
      icon: "/icon-192.png",
      badge: "/icon-192.png",
      vibrate: [200, 100, 200],
      tag: "controllares-notif",
      data: data.url ? { url: data.url } : undefined,
    })
  )
})

self.addEventListener("notificationclick", e => {
  e.notification.close()
  const url = e.notification.data?.url ?? "/dashboard"
  e.waitUntil(clients.openWindow(url))
})

// ── Background Sync ────────────────────────────────────────────────────────────
self.addEventListener("sync", e => {
  if (e.tag === "vistoria-sync") {
    e.waitUntil(
      self.clients.matchAll().then(cls =>
        cls.forEach(c => c.postMessage({ type: "SYNC_COMPLETE" }))
      )
    )
  }
})
