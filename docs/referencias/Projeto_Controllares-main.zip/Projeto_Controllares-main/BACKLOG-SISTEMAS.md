# Backlog — Sistemas, projetos por lead e avisos da proposta

Anotado a partir do pedido de 11/09/2026. **Todos os itens foram implementados
nesta mesma sessão** — este arquivo agora é registro histórico do raciocínio,
não uma lista de pendências.

---

## 1. Ambiente vira Sistema (na proposta) — FEITO

Na proposta, o bloco que se chamava "Ambiente" passou a se chamar
**Sistema**. Só os rótulos visíveis mudaram: rota (`/api/ambientes/frequentes`),
campo do banco (`environments`) e nomes de variável continuam iguais.

**Não confundir com "Som Ambiente"**, que é categoria de produto e ficou
intacta.

---

## 2. Vários sistemas por proposta, cliente escolhe quais quer — FEITO

`Environment.status` (`ATIVO | GUARDADO | RECUSADO`). Sistema `GUARDADO`/
`RECUSADO` não conta no total da proposta, não aparece na página pública
(`/p/[token]`), e reaparece na ficha do lead (`SistemasGuardados`,
`/api/leads/[id]/sistemas-guardados`) com aviso explícito de que o valor
mostrado **valia na época**, nunca repreçado automaticamente.

---

## 3. Obra: produto primeiro, ambiente escrito por cima — FEITO

Virou entidade real: `ObraAmbiente` (não texto livre). CRUD em
`/api/obras/[id]/ambientes`, atribuição de item em
`/api/obras/[id]/ambiente-item`. Obrigatório: `pendencia_ambiente` calculado
em `/api/obras`, ícone de aviso no dashboard quando algum item ATIVO da obra
não tem ambiente atribuído.

---

## 4. Fundação na etapa da obra — FEITO

## 5. Email do lead não chegava na proposta — FEITO

## 6. Vários projetos para o mesmo lead — FEITO

`LeadProjeto` (entidade leve: `id, leadId, nome, posicao`), não duplica Obra.
`Proposal.leadProjetoId` opcional. Um card por lead no kanban (não um por
projeto), com lista de projetos e botão "→ Proposta" por projeto dentro do
card.

## 7. Avisos de bloqueio no topo, em popup — FEITO

Indicadores de "Condição de pagamento" / "Dados de faturamento" subiram pro
topo da proposta, viram pílulas que ficam verdes quando resolvidos, abrem
`Dialog` ao clicar.

---

## Depois deste backlog (mesma sessão, registrado à parte)

- Fluxo em cadeia ao mover lead Qualificado → Criação de Proposta (multi-
  projeto, rascunho), label "Motivo" → "Comentário".
- Relatório da obra e Dimensionamento: envio manual por e-mail (sem
  automação, por pedido explícito).
- Importar Quadro de Automação: arquivo .xlsx/.csv, múltiplas abas, modelo
  pra baixar.
- Travessão tirado do texto visível de todo o site.
- Limpeza do repositório (ver commit `chore: limpa repositorio e reescreve README`).

## Em aberto, fora deste repo

- **wacrm**: ver `BACKLOG-REORG-UI.md` no repo do wacrm. Decisão central:
  o chat real vai morar dentro do Sistema Controllares (`/chat`, hoje com
  dado fictício em `chat-mock.ts`), consumindo a API do wacrm como backend —
  não o site do wacrm em si. Falta: ligar `/chat` na API real, aberto pra
  todos os perfis; mover automations pra dentro de Configurações; contacts/
  broadcasts viram painel/menu dentro da tela de chat, não telas próprias.
- **wacrm/Meta**: chave Groq em Settings→AI Assistant e restrição de conta
  Meta no número 3232-2600 — ações manuais do Davi, fora do código.
