# Sistema Controllares

ERP interno da Controllares (automação residencial e comercial): funil de
leads, propostas com catálogo e cálculo automático, contratos, obras
(engenharia, dimensionamento, quadro de automação), financeiro, estoque e
integrações (Olist/Tiny, Google Drive, WhatsApp).

Next.js 16 (App Router) + Prisma 5 + PostgreSQL, deploy na Vercel.

## Stack

- **Framework:** Next.js (App Router, React 18)
- **Banco:** PostgreSQL via Prisma 5 (schema em [`prisma/schema.prisma`](prisma/schema.prisma))
- **UI:** Tailwind CSS + Radix UI + [lucide-react](https://lucide.dev)
- **Auth:** JWT em cookie httpOnly, 2FA (TOTP) opcional, login Google
- **E-mail transacional:** Resend
- **Armazenamento de arquivo:** Vercel Blob
- **IA:** provedor trocável (Groq, Gemini, Ollama ou Anthropic) via endpoint compatível OpenAI

## Rodando localmente

```bash
npm install
cp .env.example .env      # preencha DATABASE_URL e os outros valores
npx prisma generate
npx prisma db push        # ou: npm run prisma:migrate, se o banco já tem histórico de migração
npm run dev
```

Abre em `http://localhost:3000`. O primeiro usuário a se cadastrar vira o
Administrador da empresa (uma empresa = um tenant, isolado por `companyId`).

### Variáveis de ambiente

Veja [`.env.example`](.env.example) — cada bloco documenta onde conseguir a
chave (Google OAuth, Olist, IA, WhatsApp/wacrm). As obrigatórias pra rodar são
`DATABASE_URL`, `JWT_SECRET`, `NEXT_PUBLIC_APP_URL` e `ENCRYPTION_KEY`; o
resto é integração opcional.

## Estrutura

```
src/
  app/
    (auth)/          login, convite, redefinir senha
    (dashboard)/     todas as telas autenticadas (uma pasta por módulo)
    api/              rotas server-side, espelhando os módulos acima
    p/[token]/        página pública da proposta (o cliente não faz login)
  components/         componentes compartilhados (ui/, leads/, ...)
  lib/                regras de negócio, e-mail, sessão, integrações
prisma/
  schema.prisma       schema do banco
  migrations/          histórico de migrações
scripts/               utilitários de manutenção (rodar com `npx tsx scripts/<nome>`)
```

Cada módulo do dashboard é uma pasta com o mesmo nome em `(dashboard)/` e em
`api/` — ex.: tela de Obras em `(dashboard)/obras/`, rotas em `api/obras/`.

### Módulos principais

| Módulo | O que faz |
|---|---|
| Leads | Funil kanban; status segue automaticamente o status da proposta vinculada |
| Propostas | Catálogo com preço/markup, múltiplos sistemas por proposta, contrato, aceite público |
| Obras | Engenharia (ambientes físicos), dimensionamento, quadro de automação (keypads/módulos), relatórios |
| Catálogo | Produtos, ficha técnica, estoque, import/export CSV |
| Financeiro | Parcelas, faturamento, notas fiscais |
| Configurações | Usuários, integrações (Olist, Google Drive, IA), backups |

## Scripts úteis

```bash
node scripts/verificar-integracao.mjs   # testa regras de negócio contra o banco real, dentro de uma transação com rollback (não grava nada)
npm run testar:plaud                    # testa a integração com Plaud (gravação de reunião → proposta)
```

## Deploy

Vercel (`projeto-controllares`), branch `main`. `npm run build` roda
`prisma generate && next build` — **não** faz `prisma db push`/`migrate deploy`
automaticamente; migração de schema é passo manual (ver comentário em
[`prisma/migrations/`](prisma/migrations/) sobre o histórico do banco).
